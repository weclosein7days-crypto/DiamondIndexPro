"""Test card image processing on first 5 cards."""
import json, sys, os
sys.path.insert(0, '/home/ubuntu/cardvault')
import process_card_images as m

# Override to use only first 5 cards
with open('/home/ubuntu/cardvault/house_cards.json') as f:
    cards = json.load(f)

m.INPUT_FILE = '/home/ubuntu/cardvault/house_cards.json'

# Process just first 5
print(f"Testing with first 5 cards...")
processed = []
for i, card in enumerate(cards[:5]):
    result = m.process_card(card, i, 5)
    if result:
        processed.append(result)

print(f"\nDone: {len(processed)}/5 processed")
print("Files saved:")
for p in processed:
    path = p.get('processedFrontPath', '')
    if path and os.path.exists(path):
        size = os.path.getsize(path)
        print(f"  {p['player']}: {path} ({size//1024}KB)")
