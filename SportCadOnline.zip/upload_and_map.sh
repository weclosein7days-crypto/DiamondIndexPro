#!/bin/bash
# Upload all house card images and capture CDN URLs into a JSON map
OUTPUT_JSON="/home/ubuntu/cardvault/house_cards_cdn_map.json"
CARDS_DIR="/home/ubuntu/webdev-static-assets/house-cards"

echo "{" > "$OUTPUT_JSON"
first=true

for filepath in "$CARDS_DIR"/house_*.jpg; do
  filename=$(basename "$filepath")
  # Get base name without hash (e.g., house_1_caitlin_clark_front)
  base="${filename%.jpg}"
  
  # Upload and capture CDN URL
  result=$(manus-upload-file --webdev "$filepath" 2>&1)
  cdn_url=$(echo "$result" | grep "CDN URL:" | sed 's/CDN URL: //')
  
  if [ -n "$cdn_url" ]; then
    if [ "$first" = true ]; then
      first=false
    else
      echo "," >> "$OUTPUT_JSON"
    fi
    echo "  \"$base\": \"$cdn_url\"" >> "$OUTPUT_JSON"
    echo "✓ $base -> $cdn_url"
  else
    echo "✗ FAILED: $filename"
  fi
done

echo "}" >> "$OUTPUT_JSON"
echo ""
echo "Done! CDN map saved to $OUTPUT_JSON"
