/**
 * Image Enhancement Pipeline for Card Grading
 * Uses sharp to sharpen, normalize, and optimize card images before AI analysis.
 * Better image quality → more accurate AI grading results.
 */
import sharp from "sharp";

/**
 * Enhance a card image for grading:
 * - Sharpens edges (critical for detecting corner/edge wear)
 * - Normalizes contrast (helps detect surface scratches)
 * - Resizes to optimal grading resolution (max 1600px on longest side)
 * - Returns as base64 JPEG for LLM consumption
 */
export async function enhanceCardImage(input: string): Promise<string> {
  try {
    // Handle both data URIs and plain base64
    let buffer: Buffer;
    if (input.startsWith("data:")) {
      const base64Data = input.split(",")[1];
      if (!base64Data) return input;
      buffer = Buffer.from(base64Data, "base64");
    } else {
      buffer = Buffer.from(input, "base64");
    }

    const enhanced = await sharp(buffer)
      // Resize to max 1600px on longest side — optimal for LLM vision
      .resize(1600, 1600, { fit: "inside", withoutEnlargement: true })
      // Sharpen: sigma=1.2, flat=0.5, jagged=0.5 — enhances card edges without artifacts
      .sharpen({ sigma: 1.2, m1: 0.5, m2: 0.5 })
      // Normalize contrast to bring out surface details
      .normalise()
      // Output as high-quality JPEG
      .jpeg({ quality: 95, progressive: false })
      .toBuffer();

    return `data:image/jpeg;base64,${enhanced.toString("base64")}`;
  } catch (err) {
    // If enhancement fails, return original — never block grading
    console.warn("[imageEnhance] Enhancement failed, using original:", (err as Error).message);
    return input;
  }
}
