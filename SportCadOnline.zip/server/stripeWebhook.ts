/**
 * Stripe webhook handler for CardVault
 * Handles: trade fee payments, card purchases, cart purchases
 */
import type { Request, Response } from "express";
import Stripe from "stripe";
import {
  getTradeById, updateTrade,
  getCardById, updateCard,
  createOrder, createCollectionItem,
} from "./db";
import { sendEmail, emailTemplates } from "./email";
import { notifyOwner } from "./_core/notification";
import { processLoyaltyDeposit, getTierConfig } from "./loyalty";

function genTicket(): string {
  return `SCO-${Date.now().toString(36).toUpperCase()}-${Math.random().toString(36).slice(2, 5).toUpperCase()}`;
}

export async function handleStripeWebhook(req: Request, res: Response) {
  const stripeSecretKey = process.env.STRIPE_SECRET_KEY;
  const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;
  if (!stripeSecretKey || !webhookSecret) {
    console.error("[Stripe Webhook] Missing Stripe keys");
    return res.status(500).json({ error: "Stripe not configured" });
  }
  const stripe = new Stripe(stripeSecretKey, { apiVersion: "2025-02-24.acacia" });
  const sig = req.headers["stripe-signature"] as string;
  let event: Stripe.Event;
  try {
    event = stripe.webhooks.constructEvent(req.body, sig, webhookSecret);
  } catch (err) {
    console.error("[Stripe Webhook] Signature verification failed:", err);
    return res.status(400).json({ error: "Invalid signature" });
  }
  if (event.id.startsWith("evt_test_")) {
    console.log("[Stripe Webhook] Test event detected, returning verification response");
    return res.json({ verified: true });
  }
  console.log(`[Stripe Webhook] Event: ${event.type} (${event.id})`);

  if (event.type === "checkout.session.completed") {
    const session = event.data.object as Stripe.Checkout.Session;
    const metadata = session.metadata || {};
    const orderType = metadata.order_type || metadata.type;

    // ── TRADE FEE ─────────────────────────────────────────────────────────────
    if (orderType === "trade_fee" || metadata.type === "trade_fee") {
      const tradeId = parseInt(metadata.trade_id || "0", 10);
      const role = metadata.role as "initiator" | "receiver";
      const partyEmail = metadata.party_email;
      if (!tradeId || !role) return res.json({ received: true });
      const trade = await getTradeById(tradeId);
      if (!trade) return res.json({ received: true });
      const updates: Record<string, unknown> = {};
      if (role === "initiator") { updates.initiatorFeePaid = true; updates.initiatorFeePaidAt = new Date(); }
      else { updates.receiverFeePaid = true; updates.receiverFeePaidAt = new Date(); }
      const newInitiatorPaid = role === "initiator" ? true : !!trade.initiatorFeePaid;
      const newReceiverPaid = role === "receiver" ? true : !!trade.receiverFeePaid;
      if (newInitiatorPaid && newReceiverPaid) {
        updates.status = "paid_ready_to_ship";
        const shipMsg = {
          subject: `Trade #${tradeId} — Both Fees Paid! Ship Your Cards`,
          html: `<h2>Trade #${tradeId} — Ready to Ship!</h2><p>Both parties have paid the $10 SCG escrow fee.</p><p><strong>SCG Escrow:</strong> SCO Secured Location</p><p>Place cards in an unsealed inner package. SCG will verify, seal, and forward. Log in to enter your tracking number.</p>`,
        };
        sendEmail({ to: trade.initiatorEmail, ...shipMsg }).catch(() => {});
        sendEmail({ to: trade.receiverEmail, ...shipMsg }).catch(() => {});
        notifyOwner({ title: `Trade #${tradeId} Ready to Ship`, content: `Initiator: ${trade.initiatorEmail}, Receiver: ${trade.receiverEmail}` }).catch(() => {});
      } else {
        sendEmail({ to: partyEmail, subject: `Trade #${tradeId} — Fee Confirmed`, html: `<p>Your $10 SCG fee for Trade #${tradeId} is received. Waiting for the other party.</p>` }).catch(() => {});
      }
      await updateTrade(tradeId, updates);
      console.log(`[Stripe Webhook] Trade #${tradeId} fee paid by ${role}`);
    }

    // ── SINGLE CARD PURCHASE ──────────────────────────────────────────────────
    else if (orderType === "card_purchase") {
      const cardId = parseInt(metadata.card_id || "0", 10);
      const buyerEmail = metadata.customer_email || session.customer_email || "";
      const buyerName = metadata.customer_name || "";
      const sellerEmail = metadata.seller_email || "";
      const amountTotal = session.amount_total ? (session.amount_total / 100).toFixed(2) : "0.00";
      const ticketNumber = genTicket();
      const isDropship = metadata.is_dropship === "1";
      const ebayItemId = metadata.ebay_item_id || "";
      // Build eBay fulfillment link for dropship orders
      const ebayFulfillmentLink = isDropship && ebayItemId
        ? `https://www.ebay.com/itm/${ebayItemId}`
        : undefined;
      if (cardId && buyerEmail) {
        const card = await getCardById(cardId);
        await updateCard(cardId, { status: "sold" });
        await createOrder({
          cardId,
          cardTitle: card?.title || "Sports Card",
          cardImageUrl: card?.frontImageUrl || card?.backImageUrl || undefined,
          buyerEmail,
          buyerName,
          sellerEmail,
          price: amountTotal,
          totalAmount: amountTotal,
          platformFee: (parseFloat(amountTotal) * 0.10).toFixed(2),
          sellerPayout: (parseFloat(amountTotal) * 0.90).toFixed(2),
          status: "paid",
          stripePaymentIntentId: session.payment_intent as string || undefined,
          ticketNumber,
          shipByDeadline: new Date(Date.now() + 48 * 60 * 60 * 1000),
          autoReleaseAt: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000),
          fulfillmentPreference: "pending",
          isDropshipOrder: isDropship,
          ebayFulfillmentLink: ebayFulfillmentLink || undefined,
        });
        await createCollectionItem({
          ownerEmail: buyerEmail,
          cardTitle: card?.title || "Sports Card",
          playerName: card?.playerName || "Unknown",
          year: card?.year || undefined,
          setName: card?.setName || undefined,
          cardNumber: card?.cardNumber || undefined,
          sport: (card?.sport as any) || "baseball",
          frontImageUrl: card?.frontImageUrl || undefined,
          backImageUrl: card?.backImageUrl || undefined,
          overallGrade: card?.aiGrade ? String(card.aiGrade) : undefined,
          gradeLabel: card?.aiGradeLabel || undefined,
          centeringScore: card?.aiCentering || undefined,
          cornersScore: card?.aiCorners || undefined,
          edgesScore: card?.aiEdges || undefined,
          surfaceScore: card?.aiSurface || undefined,
          certNumber: card?.aiCertNumber || card?.certNumber || undefined,
          estimatedValueLow: amountTotal,
          estimatedValueHigh: amountTotal,
          listingStatus: "in_sale",
          lifecycleNote: `Purchased via marketplace — Ticket ${ticketNumber}`,
          linkedCardId: cardId,
        });
        if (!isDropship) {
          const tmplSeller = emailTemplates().sellerNewOrder(sellerEmail, {
            orderId: ticketNumber,
            cardTitle: card?.title || "Sports Card",
            buyerName: buyerName || buyerEmail,
            price: parseFloat(amountTotal),
            shipByDeadline: new Date(Date.now() + 48 * 60 * 60 * 1000).toLocaleString("en-US", { weekday: "long", month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" }),
          });
          sendEmail({ to: sellerEmail, ...tmplSeller }).catch(() => {});
        }
        const tmplBuyer = emailTemplates().orderPlaced(buyerName || buyerEmail, {
          id: ticketNumber,
          cardTitle: card?.title || "Sports Card",
          price: parseFloat(amountTotal),
          sellerName: sellerEmail,
        });
        sendEmail({ to: buyerEmail, ...tmplBuyer }).catch(() => {});
        if (isDropship) {
          notifyOwner({ title: `⚡ Dropship Order: ${card?.title}`, content: `Buyer: ${buyerEmail}\nAmount: $${amountTotal}\nTicket: ${ticketNumber}\neBay Item: ${ebayItemId}\nAction required: Purchase on eBay and mark fulfilled in admin panel.` }).catch(() => {});
          // Trigger Best Offer attempt asynchronously (non-blocking)
          if (ebayItemId) {
            const { getDb } = await import("./db");
            const db = await getDb();
            if (db) {
              // Get the order we just created to get its ID
              const { orders: ordersTable } = await import("../drizzle/schema");
              const { desc: descOp, eq: eqOp } = await import("drizzle-orm");
              const [newOrder] = await db.select({ id: ordersTable.id })
                .from(ordersTable)
                .where(eqOp(ordersTable.ticketNumber, ticketNumber))
                .limit(1);
              if (newOrder) {
                const sourcePrice = card?.sourcePrice ? parseFloat(String(card.sourcePrice)) : parseFloat(amountTotal) / 1.2;
                import("./ebayBestOffer").then(({ attemptBestOffer }) => {
                  attemptBestOffer(newOrder.id, ebayItemId, sourcePrice).catch(err => {
                    console.error(`[BestOffer] Background attempt failed for order ${newOrder.id}:`, err.message);
                  });
                }).catch(() => {});
                console.log(`[Stripe Webhook] Best Offer attempt queued for order ${newOrder.id} (eBay item ${ebayItemId})`);
              }
            }
          }
        } else {
          notifyOwner({ title: `Card Sold: ${card?.title}`, content: `Buyer: ${buyerEmail}\nSeller: ${sellerEmail}\nAmount: $${amountTotal}\nTicket: ${ticketNumber}` }).catch(() => {});
        }
        console.log(`[Stripe Webhook] Card #${cardId} sold to ${buyerEmail} — Ticket ${ticketNumber} (dropship: ${isDropship})`);
      }
    }

    // ── CART PURCHASE ─────────────────────────────────────────────────────────
    else if (orderType === "cart_purchase") {
      const buyerEmail = metadata.customer_email || session.customer_email || "";
      const buyerName = metadata.customer_name || "";
      const amountTotal = session.amount_total ? (session.amount_total / 100).toFixed(2) : "0.00";
      const cardIds = (metadata.card_ids || "").split(",").map(Number).filter(Boolean);
      const sellerEmails = (metadata.seller_emails || "").split(",").filter(Boolean);
      const ticketNumber = genTicket();
      if (cardIds.length > 0 && buyerEmail) {
        const cards = await Promise.all(cardIds.map(id => getCardById(id)));
        const perCard = cardIds.length > 0 ? (parseFloat(amountTotal) / cardIds.length).toFixed(2) : amountTotal;
        await Promise.all(cardIds.map(id => updateCard(id, { status: "sold" })));
        await createOrder({
          cardIds,
          cardTitle: `Cart Purchase (${cardIds.length} cards)`,
          buyerEmail,
          buyerName,
          sellerEmails,
          price: amountTotal,
          totalAmount: amountTotal,
          platformFee: (parseFloat(amountTotal) * 0.10).toFixed(2),
          sellerPayout: (parseFloat(amountTotal) * 0.90).toFixed(2),
          status: "paid",
          stripePaymentIntentId: session.payment_intent as string || undefined,
          ticketNumber,
          shipByDeadline: new Date(Date.now() + 48 * 60 * 60 * 1000),
          autoReleaseAt: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000),
          fulfillmentPreference: "pending",
        });
        for (const card of cards) {
          if (!card) continue;
          await createCollectionItem({
            ownerEmail: buyerEmail,
            cardTitle: card.title,
            playerName: card.playerName,
            year: card.year || undefined,
            setName: card.setName || undefined,
            cardNumber: card.cardNumber || undefined,
            sport: (card.sport as any) || "baseball",
            frontImageUrl: card.frontImageUrl || undefined,
            backImageUrl: card.backImageUrl || undefined,
            overallGrade: card.aiGrade ? String(card.aiGrade) : undefined,
            gradeLabel: card.aiGradeLabel || undefined,
            centeringScore: card.aiCentering || undefined,
            cornersScore: card.aiCorners || undefined,
            edgesScore: card.aiEdges || undefined,
            surfaceScore: card.aiSurface || undefined,
            certNumber: card.aiCertNumber || card.certNumber || undefined,
            estimatedValueLow: perCard,
            estimatedValueHigh: perCard,
            listingStatus: "in_sale",
            lifecycleNote: `Purchased via cart — Ticket ${ticketNumber}`,
            linkedCardId: card.id,
          });
        }
        sendEmail({ to: buyerEmail, subject: `Order Confirmed — ${cardIds.length} cards (${ticketNumber})`, html: `<p>Your cart of <strong>${cardIds.length} cards</strong> for <strong>$${amountTotal}</strong> is confirmed. Ticket: <strong>${ticketNumber}</strong>. All cards are now in your Collection.</p>` }).catch(() => {});
        notifyOwner({ title: `Cart Purchase: ${cardIds.length} cards`, content: `Buyer: ${buyerEmail}\nAmount: $${amountTotal}\nTicket: ${ticketNumber}` }).catch(() => {});
        console.log(`[Stripe Webhook] Cart by ${buyerEmail}: ${cardIds.length} cards $${amountTotal} — Ticket ${ticketNumber}`);
      }
    }
  }

  // ── CREDIT PURCHASE ──────────────────────────────────────────────────────
  if (event.type === "checkout.session.completed") {
    const session = event.data.object as Stripe.Checkout.Session;
    const metadata = session.metadata || {};
    const orderType = metadata.order_type || metadata.type;
    if (orderType === "credit_purchase") {
      const userEmail = metadata.customer_email || session.customer_email || "";
      const creditsAmount = parseInt(metadata.credits_amount || "0", 10);
      const amountTotal = session.amount_total ? (session.amount_total / 100).toFixed(2) : "0.00";
      if (userEmail && creditsAmount > 0) {
        try {
          const loyalty = await processLoyaltyDeposit(userEmail, creditsAmount);
          const tierConfig = getTierConfig(loyalty.newTier);
          const bonusSummary: string[] = [];
          if (loyalty.depositBonus > 0) bonusSummary.push(`+${loyalty.depositBonus} deposit bonus (${getTierConfig(loyalty.oldTier).depositBonusPct}%)`);
          if (loyalty.weeklyBonus > 0) bonusSummary.push(`+${loyalty.weeklyBonus} weekly milestone bonus`);
          if (loyalty.monthlyBonus > 0) bonusSummary.push(`+${loyalty.monthlyBonus} monthly milestone bonus`);
          if (loyalty.tierUpBonus > 0) bonusSummary.push(`+${loyalty.tierUpBonus} tier-up bonus (${tierConfig.emoji} ${tierConfig.label}!)`);
          const bonusHtml = bonusSummary.length > 0
            ? `<p><strong>Loyalty Bonuses Earned:</strong><ul>${bonusSummary.map(b => `<li>${b}</li>`).join("")}</ul></p>`
            : "";
          const tierChangeHtml = loyalty.newTier !== loyalty.oldTier
            ? `<p>🎉 <strong>Tier Up!</strong> You are now a ${tierConfig.emoji} ${tierConfig.label} member!</p>`
            : "";
          sendEmail({
            to: userEmail,
            subject: `Credits Added — ${creditsAmount + loyalty.totalBonus} total credits`,
            html: `<h2>Credits Added Successfully!</h2><p>You purchased <strong>${creditsAmount} credits</strong> for <strong>$${amountTotal}</strong>.</p>${bonusHtml}${tierChangeHtml}<p>Total credits added: <strong>${creditsAmount + loyalty.totalBonus}</strong></p><p>Visit <a href="https://www.sportcardsonline.com/game-room">the Game Room</a> to use your credits.</p>`,
          }).catch(() => {});
          console.log(`[Stripe Webhook] Credit purchase: ${userEmail} +${creditsAmount} credits, loyalty bonus +${loyalty.totalBonus}`);
        } catch (err) {
          console.error("[Stripe Webhook] Loyalty processing error:", err);
        }
      }
    }
  }

  return res.json({ received: true });
}
