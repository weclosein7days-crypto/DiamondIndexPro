/**
 * eBay Availability Cron Job
 *
 * Runs every 4 hours to verify all dropship cards are still listed on eBay.
 * Cards that are no longer available (sold, removed, ended) are deleted from
 * the CardVault marketplace so buyers never see unavailable listings.
 *
 * When cards are removed, the site owner receives a notification summary.
 */

import { getDb } from "./db";
import { cards } from "../drizzle/schema";
import { eq, and, sql } from "drizzle-orm";
import { checkEbayAvailability } from "./ebayDropship";
import { notifyOwner } from "./_core/notification";

const INTERVAL_MS = 4 * 60 * 60 * 1000; // 4 hours
const BATCH_SIZE = 10; // concurrent eBay API calls per batch

// In-memory record of the last run result for the admin UI
export let lastAvailabilityRun: {
  ranAt: Date;
  checked: number;
  deleted: number;
  stillActive: number;
  deletedTitles: string[];
} | null = null;

async function runAvailabilityCheck(): Promise<{
  checked: number;
  deleted: number;
  stillActive: number;
  deletedTitles: string[];
}> {
  const db = await getDb();
  if (!db) {
    console.warn("[AvailabilityJobs] DB not available, skipping check");
    return { checked: 0, deleted: 0, stillActive: 0, deletedTitles: [] };
  }

  // Fetch all active dropship cards that have an eBay item ID
  const dropshipCards = await db
    .select({ id: cards.id, ebayItemId: cards.ebayItemId, title: cards.title })
    .from(cards)
    .where(and(sql`${cards.isDropship} = 1`, sql`${cards.ebayItemId} IS NOT NULL`));

  if (dropshipCards.length === 0) {
    console.log("[AvailabilityJobs] No dropship cards to check.");
    lastAvailabilityRun = { ranAt: new Date(), checked: 0, deleted: 0, stillActive: 0, deletedTitles: [] };
    return { checked: 0, deleted: 0, stillActive: 0, deletedTitles: [] };
  }

  console.log(`[AvailabilityJobs] Checking ${dropshipCards.length} eBay dropship cards...`);

  let checked = 0;
  let deleted = 0;
  let stillActive = 0;
  const deletedTitles: string[] = [];

  for (let i = 0; i < dropshipCards.length; i += BATCH_SIZE) {
    const batch = dropshipCards.slice(i, i + BATCH_SIZE);
    await Promise.all(
      batch.map(async (card) => {
        checked++;
        try {
          const result = await checkEbayAvailability(card.ebayItemId!);
          if (!result.available) {
            await db.delete(cards).where(eq(cards.id, card.id));
            deleted++;
            deletedTitles.push(card.title ?? `Card #${card.id}`);
            console.log(`[AvailabilityJobs] Deleted unavailable card #${card.id}: ${card.title}`);
          } else {
            stillActive++;
          }
        } catch (err) {
          // If the eBay API call fails, leave the card in place
          stillActive++;
          console.warn(`[AvailabilityJobs] Check failed for card #${card.id}:`, (err as Error).message);
        }
      })
    );
  }

  const summary = { checked, deleted, stillActive, deletedTitles };

  // Store last run result for admin UI
  lastAvailabilityRun = { ranAt: new Date(), ...summary };

  console.log(
    `[AvailabilityJobs] Done — checked: ${checked}, deleted: ${deleted}, still active: ${stillActive}`
  );

  // Notify owner if any cards were removed
  if (deleted > 0) {
    const cardList = deletedTitles.slice(0, 20).map((t, i) => `${i + 1}. ${t}`).join("\n");
    const extra = deletedTitles.length > 20 ? `\n...and ${deletedTitles.length - 20} more` : "";
    await notifyOwner({
      title: `eBay Auto-Removal: ${deleted} card${deleted !== 1 ? "s" : ""} removed`,
      content: `The automated eBay availability check removed ${deleted} listing${deleted !== 1 ? "s" : ""} that are no longer available on eBay.\n\n${cardList}${extra}\n\nChecked: ${checked} | Still active: ${stillActive} | Removed: ${deleted}\nRan at: ${new Date().toLocaleString()}`,
    }).catch((err) => {
      console.warn("[AvailabilityJobs] Failed to send owner notification:", err);
    });
  }

  return summary;
}

export function startAvailabilityJobs(): void {
  console.log("[AvailabilityJobs] Starting eBay availability checker (4-hour interval)");

  // Run once after a short delay on startup (30 seconds) so the server is fully ready
  setTimeout(() => {
    runAvailabilityCheck().catch(console.error);
  }, 30_000);

  // Then run every 4 hours
  setInterval(() => {
    runAvailabilityCheck().catch(console.error);
  }, INTERVAL_MS);
}

// Export the core function so the admin procedure can call it directly
export { runAvailabilityCheck };
