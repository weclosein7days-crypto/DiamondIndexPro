/**
 * YouTube Auto-Tagger
 * Automatically generates SEO-optimised YouTube tags and authoritative
 * description links for every blog-post video before it is uploaded to YouTube.
 *
 * Mirrors the blogEngine.ts enrichTags / injectAuthoritativeLinks logic but
 * produces YouTube-specific output:
 *   - youtubeAutoTags  → JSON string[]  (≤ 500 chars total, ≤ 15 tags)
 *   - youtubeAutoLinks → JSON { label, url }[]  (injected into YT description)
 */

import { invokeLLM } from "./_core/llm";

// ─── Authoritative external links (same as blogEngine) ───────────────────────
const AUTHORITATIVE_LINKS: { keyword: RegExp; url: string; label: string }[] = [
  { keyword: /\bPSA\b/gi,                   url: "https://www.psacard.com",                                          label: "PSA" },
  { keyword: /\bBeckett\b/gi,               url: "https://www.beckett.com",                                          label: "Beckett" },
  { keyword: /\bBGS\b/gi,                   url: "https://www.beckett.com/grading",                                  label: "Beckett Grading" },
  { keyword: /\bSGC\b/gi,                   url: "https://www.gosgc.com",                                            label: "SGC" },
  { keyword: /\beBay\b/gi,                  url: "https://www.ebay.com/b/Sports-Trading-Cards/212/bn_1893",          label: "eBay Sports Cards" },
  { keyword: /\bTopps\b/gi,                 url: "https://www.topps.com",                                            label: "Topps" },
  { keyword: /\bPanini\b/gi,               url: "https://www.paniniamerica.net",                                    label: "Panini America" },
  { keyword: /\bBowman\b/gi,               url: "https://www.topps.com/collections/bowman",                         label: "Bowman" },
  { keyword: /\bUpper Deck\b/gi,           url: "https://www.upperdeck.com",                                        label: "Upper Deck" },
  { keyword: /\bFleer\b/gi,                url: "https://en.wikipedia.org/wiki/Fleer_Corporation",                  label: "Fleer" },
  { keyword: /\bSports Reference\b/gi,     url: "https://www.sports-reference.com",                                 label: "Sports Reference" },
  { keyword: /\bBaseball Reference\b/gi,   url: "https://www.baseball-reference.com",                               label: "Baseball Reference" },
  { keyword: /\bBasketball Reference\b/gi, url: "https://www.basketball-reference.com",                             label: "Basketball Reference" },
  { keyword: /\bPro Football Reference\b/gi, url: "https://www.pro-football-reference.com",                         label: "Pro Football Reference" },
  { keyword: /\bHockey Reference\b/gi,     url: "https://www.hockey-reference.com",                                 label: "Hockey Reference" },
  { keyword: /\bSCP Auctions\b/gi,         url: "https://www.scpauctions.com",                                      label: "SCP Auctions" },
  { keyword: /\bHeritage Auctions\b/gi,    url: "https://sports.ha.com",                                            label: "Heritage Auctions" },
  { keyword: /\bGoldin\b/gi,               url: "https://goldin.co",                                                label: "Goldin Auctions" },
  { keyword: /\bALT\b/gi,                  url: "https://www.alt.com",                                              label: "ALT" },
  { keyword: /\bPWCC\b/gi,                 url: "https://www.pwccmarketplace.com",                                  label: "PWCC Marketplace" },
  { keyword: /\bCOMC\b/gi,                 url: "https://www.comc.com",                                             label: "COMC" },
];

// ─── Sport-specific YouTube hashtags ─────────────────────────────────────────
const SPORT_HASHTAGS: Record<string, string[]> = {
  baseball:   ["#BaseballCards", "#MLB", "#RookieCards", "#Topps", "#Bowman"],
  basketball: ["#BasketballCards", "#NBA", "#WNBA", "#PaniniPrizm", "#HoopsCards"],
  football:   ["#FootballCards", "#NFL", "#PaniniPrizm", "#NFLCards", "#RookieCards"],
  hockey:     ["#HockeyCards", "#NHL", "#UpperDeck", "#HockeyHobby"],
  soccer:     ["#SoccerCards", "#Football", "#Panini", "#SoccerHobby"],
  other:      ["#SportsCards", "#CardCollecting"],
};

// ─── Base YouTube tags always included ───────────────────────────────────────
const BASE_TAGS = [
  "sports cards",
  "card collecting",
  "SportsCardsOnline",
  "SCO",
  "card grading",
  "buy sports cards",
  "sell sports cards",
];

// ─── Enrich tags with sport-specific and content-specific additions ───────────
function enrichYouTubeTags(tags: string[], sport: string, title: string): string[] {
  const base = new Set([...BASE_TAGS, ...tags.map(t => t.toLowerCase().trim())]);

  if (sport && sport !== "all sports") base.add(sport + " cards");

  // Grading companies
  if (/psa/i.test(title))            base.add("psa graded");
  if (/beckett|bgs/i.test(title))    base.add("beckett grading");
  if (/sgc/i.test(title))            base.add("sgc graded");

  // Content types
  if (/rookie/i.test(title))         base.add("rookie cards");
  if (/invest/i.test(title))         base.add("card investment");
  if (/auction/i.test(title))        base.add("card auctions");
  if (/vintage/i.test(title))        base.add("vintage cards");
  if (/topps/i.test(title))          base.add("topps");
  if (/panini/i.test(title))         base.add("panini");
  if (/bowman/i.test(title))         base.add("bowman");
  if (/prizm/i.test(title))          base.add("prizm");
  if (/refractor/i.test(title))      base.add("refractor");
  if (/auto|autograph/i.test(title)) base.add("autograph card");
  if (/1\/1|one of one/i.test(title)) base.add("1 of 1");

  // Cap at 15 tags (YouTube limit for meaningful SEO)
  return Array.from(base).slice(0, 15);
}

// ─── Build authoritative links for the video description ─────────────────────
function buildAuthoritativeLinks(
  title: string,
  excerpt: string,
  sport: string
): { label: string; url: string }[] {
  const text = `${title} ${excerpt}`;
  const found: { label: string; url: string }[] = [];
  const seen = new Set<string>();

  for (const { keyword, url, label } of AUTHORITATIVE_LINKS) {
    if (keyword.test(text) && !seen.has(url)) {
      found.push({ label, url });
      seen.add(url);
    }
  }

  // Always include sport reference site
  const sportRefMap: Record<string, { label: string; url: string }> = {
    baseball:   { label: "Baseball Reference",    url: "https://www.baseball-reference.com" },
    basketball: { label: "Basketball Reference",  url: "https://www.basketball-reference.com" },
    football:   { label: "Pro Football Reference", url: "https://www.pro-football-reference.com" },
    hockey:     { label: "Hockey Reference",      url: "https://www.hockey-reference.com" },
    soccer:     { label: "FBref",                 url: "https://fbref.com" },
  };
  if (sportRefMap[sport] && !seen.has(sportRefMap[sport].url)) {
    found.push(sportRefMap[sport]);
  }

  return found;
}

// ─── AI-powered tag extraction ────────────────────────────────────────────────
async function extractTagsWithLLM(
  title: string,
  excerpt: string,
  sport: string
): Promise<string[]> {
  try {
    const response = await invokeLLM({
      messages: [
        {
          role: "system",
          content:
            "You are a YouTube SEO expert for sports card collecting. " +
            "Return ONLY a JSON array of 8-10 short YouTube search tags (2-4 words each). " +
            "No explanations, no markdown, just the JSON array.",
        },
        {
          role: "user",
          content:
            `Generate YouTube tags for this sports card video:\n` +
            `Title: ${title}\n` +
            `Sport: ${sport}\n` +
            `Description: ${excerpt}\n\n` +
            `Focus on: player names, card sets, grading companies, year, and collector keywords.`,
        },
      ],
      response_format: {
        type: "json_schema",
        json_schema: {
          name: "youtube_tags",
          strict: true,
          schema: {
            type: "object",
            properties: {
              tags: {
                type: "array",
                items: { type: "string" },
              },
            },
            required: ["tags"],
            additionalProperties: false,
          },
        },
      },
    });

    const rawContent = response?.choices?.[0]?.message?.content;
    const content = typeof rawContent === "string" ? rawContent : null;
    if (!content) return [];
    const parsed = JSON.parse(content);
    return Array.isArray(parsed.tags) ? parsed.tags : [];
  } catch (err) {
    console.warn("[youtubeAutoTagger] LLM tag extraction failed:", err);
    return [];
  }
}

// ─── Main export ──────────────────────────────────────────────────────────────
export interface VideoAutoTagResult {
  youtubeAutoTags: string;   // JSON string[] — store in DB
  youtubeAutoLinks: string;  // JSON { label, url }[] — store in DB
  /** Merged final tags ready to pass to uploadToYouTube() */
  finalTags: string[];
  /** Formatted description block to append to YouTube description */
  authoritativeLinksBlock: string;
  /** YouTube hashtag string to append at end of description */
  hashtagString: string;
}

export async function generateVideoAutoTags(input: {
  title: string;
  excerpt: string;
  sport: string;
  existingTags?: string[];
}): Promise<VideoAutoTagResult> {
  const { title, excerpt, sport, existingTags = [] } = input;

  // 1. AI-extracted tags
  const llmTags = await extractTagsWithLLM(title, excerpt, sport);

  // 2. Merge with existing tags and enrich
  const allTags = [...existingTags, ...llmTags];
  const finalTags = enrichYouTubeTags(allTags, sport, title);

  // 3. Build authoritative links
  const authLinks = buildAuthoritativeLinks(title, excerpt, sport);

  // 4. Build description block
  const authoritativeLinksBlock =
    authLinks.length > 0
      ? "\n\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n" +
        "📚 Learn More:\n" +
        authLinks.map(l => `• ${l.label}: ${l.url}`).join("\n") +
        "\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
      : "";

  // 5. Build hashtag string
  const sportHashtags = SPORT_HASHTAGS[sport] ?? SPORT_HASHTAGS.other;
  const playerHashtags = finalTags
    .filter(t => t.split(" ").length >= 2)
    .slice(0, 3)
    .map(t => "#" + t.replace(/\s+/g, "").replace(/[^a-zA-Z0-9]/g, ""));
  const hashtagString = [...sportHashtags, ...playerHashtags, "#SportsCardsOnline", "#CardCollecting"]
    .slice(0, 10)
    .join(" ");

  console.log(
    `[youtubeAutoTagger] Generated ${finalTags.length} tags and ${authLinks.length} authoritative links for "${title}"`
  );

  return {
    youtubeAutoTags: JSON.stringify(finalTags),
    youtubeAutoLinks: JSON.stringify(authLinks),
    finalTags,
    authoritativeLinksBlock,
    hashtagString,
  };
}
