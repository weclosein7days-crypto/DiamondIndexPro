/**
 * Unit tests for Smart Marketplace Rotation
 * Tests: sport-weighted slots, $500 cap, WNBA house-only rule,
 *        daily seeded rotation, personalization, fallback fill, and no-duplicates.
 */
import { describe, it, expect } from "vitest";

// ── Helpers extracted for isolated testing ─────────────────────────────────

/** Seeded deterministic shuffle (mirrors db.ts implementation) */
function seededShuffle<T>(arr: T[], seed: number): T[] {
  const a = [...arr];
  let s = seed;
  for (let i = a.length - 1; i > 0; i--) {
    s = (s * 1664525 + 1013904223) & 0xffffffff;
    const j = Math.abs(s) % (i + 1);
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

const WNBA_PLAYERS = [
  "Caitlin Clark", "Angel Reese", "Paige Bueckers", "A'ja Wilson", "Sabrina Ionescu",
  "Kate Martin", "Aziaha James", "Rickea Jackson", "Breanna Stewart", "Diana Taurasi",
];

const FEATURED_SLOTS = [
  { key: "wnba",     sport: "basketball", limit: 6, houseOnly: true,  isWnba: true  },
  { key: "nba",      sport: "basketball", limit: 6, houseOnly: false, isWnba: false },
  { key: "football", sport: "football",   limit: 4, houseOnly: false, isWnba: false },
  { key: "baseball", sport: "baseball",   limit: 4, houseOnly: false, isWnba: false },
  { key: "hockey",   sport: "hockey",     limit: 1, houseOnly: false, isWnba: false },
  { key: "soccer",   sport: "soccer",     limit: 1, houseOnly: false, isWnba: false },
  { key: "other",    sport: "other",      limit: 2, houseOnly: false, isWnba: false },
];

/** Simulate the slot-filling logic from getFeaturedCards (mirrors db.ts exactly) */
function simulateFeaturedCards(
  pool: Array<{ id: number; playerName: string; sport: string; price: string; isMainStore: boolean }>,
  dayOfYear: number,
  boostedPlayers: string[] = []
) {
  const usedIds = new Set<number>();
  const result: typeof pool = [];

  for (const slot of FEATURED_SLOTS) {
    // Filter by sport and price cap ($10–$500)
    let filtered = pool.filter(c => {
      const price = parseFloat(c.price);
      return c.sport === slot.sport && price >= 10 && price <= 500;
    });

    // House-only rule for WNBA
    if (slot.houseOnly) {
      filtered = filtered.filter(c => c.isMainStore);
    }

    // WNBA vs NBA split within basketball
    if (slot.isWnba) {
      const wnbaFiltered = filtered.filter(c =>
        WNBA_PLAYERS.some(p => c.playerName.toLowerCase().includes(p.toLowerCase()))
      );
      // Fallback: if no WNBA-named house cards, use any basketball house cards
      filtered = wnbaFiltered.length > 0 ? wnbaFiltered : filtered;
    } else if (slot.sport === "basketball" && !slot.isWnba) {
      filtered = filtered.filter(c =>
        !WNBA_PLAYERS.some(p => c.playerName.toLowerCase().includes(p.toLowerCase()))
      );
    }

    // Skip only if truly no cards for this sport
    if (filtered.length === 0) continue;

    // Remove already-placed cards
    filtered = filtered.filter(c => !usedIds.has(c.id));

    // Personalization split
    const boosted = filtered.filter(c =>
      boostedPlayers.some(p => c.playerName.toLowerCase().includes(p.toLowerCase()))
    );
    const rest = filtered.filter(c =>
      !boostedPlayers.some(p => c.playerName.toLowerCase().includes(p.toLowerCase()))
    );

    const shuffledBoosted = seededShuffle(boosted, dayOfYear + slot.key.charCodeAt(0));
    const shuffledRest    = seededShuffle(rest,    dayOfYear + slot.key.charCodeAt(0) + 1000);

    // Deduplicate by player name, respect slot.limit
    const seenPlayers = new Set<string>();
    const slotCards: typeof pool = [];
    for (const c of [...shuffledBoosted, ...shuffledRest]) {
      const key = c.playerName.toLowerCase();
      if (!seenPlayers.has(key)) {
        seenPlayers.add(key);
        slotCards.push(c);
        usedIds.add(c.id);
      }
      if (slotCards.length >= slot.limit) break;
    }
    result.push(...slotCards);
  }

  // Guarantee fill: top up to 24 from any house cards not already placed
  const TARGET = 24;
  if (result.length < TARGET) {
    const usedPlayers = new Set(result.map(c => c.playerName.toLowerCase()));
    const fillPool = pool.filter(c => {
      const price = parseFloat(c.price);
      return c.isMainStore && price >= 10 && price <= 500 && !usedIds.has(c.id);
    });
    for (const c of fillPool) {
      const playerKey = c.playerName.toLowerCase();
      if (!usedIds.has(c.id) && !usedPlayers.has(playerKey)) {
        result.push(c);
        usedIds.add(c.id);
        usedPlayers.add(playerKey);
      }
      if (result.length >= TARGET) break;
    }
  }

  return result;
}

// ── Test data ──────────────────────────────────────────────────────────────

function makeCard(
  id: number,
  playerName: string,
  sport: string,
  price: string,
  isMainStore: boolean
) {
  return { id, playerName, sport, price, isMainStore };
}

const SAMPLE_POOL = [
  // WNBA house cards
  makeCard(1,  "Caitlin Clark",    "basketball", "150.00", true),
  makeCard(2,  "Angel Reese",      "basketball", "120.00", true),
  makeCard(3,  "Paige Bueckers",   "basketball",  "90.00", true),
  makeCard(4,  "A'ja Wilson",      "basketball",  "80.00", true),
  makeCard(5,  "Sabrina Ionescu",  "basketball",  "70.00", true),
  makeCard(6,  "Kate Martin",      "basketball",  "60.00", true),
  // WNBA eBay card — should be excluded from WNBA slot
  makeCard(7,  "Breanna Stewart",  "basketball", "200.00", false),
  // NBA cards
  makeCard(8,  "LeBron James",     "basketball", "300.00", false),
  makeCard(9,  "Luka Doncic",      "basketball", "250.00", false),
  makeCard(10, "Jayson Tatum",     "basketball", "200.00", false),
  makeCard(11, "Giannis Antetokounmpo", "basketball", "180.00", false),
  makeCard(12, "Nikola Jokic",     "basketball", "160.00", false),
  makeCard(13, "Anthony Edwards",  "basketball", "140.00", false),
  // Football
  makeCard(14, "Patrick Mahomes", "football",   "400.00", false),
  makeCard(15, "Josh Allen",      "football",   "350.00", false),
  makeCard(16, "Lamar Jackson",   "football",   "300.00", false),
  makeCard(17, "Jalen Hurts",     "football",   "250.00", false),
  // Baseball
  makeCard(18, "Paul Skenes",     "baseball",   "200.00", false),
  makeCard(19, "Shohei Ohtani",   "baseball",   "180.00", false),
  makeCard(20, "Aaron Judge",     "baseball",   "160.00", false),
  makeCard(21, "Elly De La Cruz", "baseball",   "140.00", false),
  // Hockey
  makeCard(22, "Connor McDavid",  "hockey",     "300.00", false),
  // Soccer
  makeCard(23, "Lionel Messi",    "soccer",     "500.00", false),
  // Over $500 — must be excluded
  makeCard(24, "Expensive Card",  "football",   "501.00", false),
  // Under $10 — must be excluded
  makeCard(25, "Cheap Card",      "baseball",     "5.00", false),
];

// ── Tests ──────────────────────────────────────────────────────────────────

describe("Smart Marketplace Rotation", () => {
  describe("seededShuffle", () => {
    it("produces the same order for the same seed", () => {
      const arr = [1, 2, 3, 4, 5, 6, 7, 8];
      const a = seededShuffle(arr, 42);
      const b = seededShuffle(arr, 42);
      expect(a).toEqual(b);
    });

    it("produces different orders for different seeds", () => {
      const arr = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
      const a = seededShuffle(arr, 1);
      const b = seededShuffle(arr, 2);
      expect(a).not.toEqual(b);
    });

    it("preserves all elements", () => {
      const arr = [10, 20, 30, 40, 50];
      const shuffled = seededShuffle(arr, 99);
      expect(shuffled.sort()).toEqual([...arr].sort());
    });

    it("does not mutate the original array", () => {
      const arr = [1, 2, 3];
      const copy = [...arr];
      seededShuffle(arr, 7);
      expect(arr).toEqual(copy);
    });
  });

  describe("$500 price cap", () => {
    it("excludes cards priced above $500", () => {
      const result = simulateFeaturedCards(SAMPLE_POOL, 100);
      const ids = result.map(c => c.id);
      expect(ids).not.toContain(24); // "Expensive Card" at $501
    });

    it("includes cards at exactly $500", () => {
      const result = simulateFeaturedCards(SAMPLE_POOL, 100);
      const ids = result.map(c => c.id);
      expect(ids).toContain(23); // Messi at $500
    });

    it("excludes cards priced below $10", () => {
      const result = simulateFeaturedCards(SAMPLE_POOL, 100);
      const ids = result.map(c => c.id);
      expect(ids).not.toContain(25); // "Cheap Card" at $5
    });
  });

  describe("WNBA house-only rule", () => {
    it("WNBA slot only contains house cards (isMainStore=true)", () => {
      const result = simulateFeaturedCards(SAMPLE_POOL, 100);
      const wnbaCards = result.filter(c =>
        WNBA_PLAYERS.some(p => c.playerName.toLowerCase().includes(p.toLowerCase()))
      );
      wnbaCards.forEach(c => {
        expect(c.isMainStore).toBe(true);
      });
    });

    it("WNBA slot does not include NBA players", () => {
      const result = simulateFeaturedCards(SAMPLE_POOL, 100);
      const wnbaSlotCards = result.filter(c =>
        WNBA_PLAYERS.some(p => c.playerName.toLowerCase().includes(p.toLowerCase()))
      );
      const nbaInWnba = wnbaSlotCards.filter(c =>
        ["LeBron James", "Luka Doncic", "Jayson Tatum"].includes(c.playerName)
      );
      expect(nbaInWnba).toHaveLength(0);
    });

    it("WNBA slot falls back to any basketball house card when no WNBA-named cards exist", () => {
      // Pool with basketball house cards but no WNBA player names
      const noWnbaPool = [
        makeCard(300, "House Player A", "basketball", "100.00", true),
        makeCard(301, "House Player B", "basketball",  "90.00", true),
        makeCard(302, "House Player C", "basketball",  "80.00", true),
        makeCard(303, "NBA Star",       "basketball", "200.00", false),
      ];
      const result = simulateFeaturedCards(noWnbaPool, 50);
      // The WNBA slot should be filled with house basketball cards as fallback
      const houseBasketball = result.filter(c => c.sport === "basketball" && c.isMainStore);
      expect(houseBasketball.length).toBeGreaterThan(0);
    });
  });

  describe("sport-weighted slot limits", () => {
    it("WNBA slot returns at most 6 cards", () => {
      const result = simulateFeaturedCards(SAMPLE_POOL, 100);
      const wnbaCards = result.filter(c =>
        WNBA_PLAYERS.some(p => c.playerName.toLowerCase().includes(p.toLowerCase()))
      );
      expect(wnbaCards.length).toBeLessThanOrEqual(6);
    });

    it("NBA slot returns at most 6 cards", () => {
      const result = simulateFeaturedCards(SAMPLE_POOL, 100);
      const nbaCards = result.filter(c =>
        c.sport === "basketball" &&
        !WNBA_PLAYERS.some(p => c.playerName.toLowerCase().includes(p.toLowerCase()))
      );
      expect(nbaCards.length).toBeLessThanOrEqual(6);
    });

    it("football slot returns at most 4 cards", () => {
      const result = simulateFeaturedCards(SAMPLE_POOL, 100);
      const footballCards = result.filter(c => c.sport === "football");
      expect(footballCards.length).toBeLessThanOrEqual(4);
    });

    it("baseball slot returns at most 4 cards", () => {
      const result = simulateFeaturedCards(SAMPLE_POOL, 100);
      const baseballCards = result.filter(c => c.sport === "baseball");
      expect(baseballCards.length).toBeLessThanOrEqual(4);
    });

    it("total featured cards does not exceed 24", () => {
      const result = simulateFeaturedCards(SAMPLE_POOL, 100);
      expect(result.length).toBeLessThanOrEqual(24);
    });

    it("no card ID appears more than once in the result", () => {
      const result = simulateFeaturedCards(SAMPLE_POOL, 100);
      const ids = result.map(c => c.id);
      const uniqueIds = new Set(ids);
      expect(uniqueIds.size).toEqual(ids.length);
    });
  });

  describe("guarantee fill (reaches 24 cards when inventory is sufficient)", () => {
    it("fills up to 24 cards when pool has enough house inventory", () => {
      // Build a pool of 30 house cards across all sports
      const bigPool = [
        ...Array.from({ length: 6 }, (_, i) =>
          makeCard(500 + i, `WNBA Player ${i}`, "basketball", `${50 + i * 10}.00`, true)),
        ...Array.from({ length: 6 }, (_, i) =>
          makeCard(510 + i, `NBA Player ${i}`, "basketball", `${50 + i * 10}.00`, true)),
        ...Array.from({ length: 4 }, (_, i) =>
          makeCard(520 + i, `Football Player ${i}`, "football", `${50 + i * 10}.00`, true)),
        ...Array.from({ length: 4 }, (_, i) =>
          makeCard(530 + i, `Baseball Player ${i}`, "baseball", `${50 + i * 10}.00`, true)),
        ...Array.from({ length: 2 }, (_, i) =>
          makeCard(540 + i, `Hockey Player ${i}`, "hockey", `${50 + i * 10}.00`, true)),
        ...Array.from({ length: 2 }, (_, i) =>
          makeCard(550 + i, `Soccer Player ${i}`, "soccer", `${50 + i * 10}.00`, true)),
        ...Array.from({ length: 6 }, (_, i) =>
          makeCard(560 + i, `Other Player ${i}`, "other", `${50 + i * 10}.00`, true)),
      ];
      const result = simulateFeaturedCards(bigPool, 77);
      expect(result.length).toBe(24);
    });
  });

  describe("daily rotation (seeded by day)", () => {
    it("produces different order on different days", () => {
      const bigPool = Array.from({ length: 30 }, (_, i) =>
        makeCard(i + 100, `NBA Player ${i}`, "basketball", `${50 + i * 5}.00`, false)
      );
      const day1 = simulateFeaturedCards(bigPool, 1);
      const day2 = simulateFeaturedCards(bigPool, 2);
      const ids1 = day1.map(c => c.id).join(",");
      const ids2 = day2.map(c => c.id).join(",");
      expect(ids1).not.toEqual(ids2);
    });

    it("produces the same order on the same day (deterministic)", () => {
      const result1 = simulateFeaturedCards(SAMPLE_POOL, 100);
      const result2 = simulateFeaturedCards(SAMPLE_POOL, 100);
      expect(result1.map(c => c.id)).toEqual(result2.map(c => c.id));
    });
  });

  describe("personalization (visitor search boost)", () => {
    it("boosted player appears before non-boosted players in the same slot", () => {
      const nbaPool = [
        makeCard(200, "LeBron James",    "basketball", "300.00", false),
        makeCard(201, "Luka Doncic",     "basketball", "250.00", false),
        makeCard(202, "Jayson Tatum",    "basketball", "200.00", false),
        makeCard(203, "Giannis Antetokounmpo", "basketball", "180.00", false),
        makeCard(204, "Nikola Jokic",    "basketball", "160.00", false),
        makeCard(205, "Anthony Edwards", "basketball", "140.00", false),
        makeCard(206, "Donovan Mitchell","basketball", "120.00", false),
      ];

      const withoutBoost = simulateFeaturedCards(nbaPool, 50, []);
      const withBoost    = simulateFeaturedCards(nbaPool, 50, ["Donovan Mitchell"]);

      const idxWithout = withoutBoost.findIndex(c => c.id === 206);
      const idxWith    = withBoost.findIndex(c => c.id === 206);

      expect(idxWith).toBeGreaterThanOrEqual(0);
      if (idxWithout > 0) {
        expect(idxWith).toBeLessThan(idxWithout);
      }
    });

    it("non-boosted results still contain cards from multiple sports", () => {
      const result = simulateFeaturedCards(SAMPLE_POOL, 100, []);
      const sports = new Set(result.map(c => c.sport));
      expect(sports.size).toBeGreaterThan(1);
    });
  });

  describe("player deduplication per slot", () => {
    it("each player appears at most once across the entire result", () => {
      const poolWithDupes = [
        ...SAMPLE_POOL,
        makeCard(50, "Caitlin Clark", "basketball", "200.00", true),
        makeCard(51, "Caitlin Clark", "basketball", "180.00", true),
      ];
      const result = simulateFeaturedCards(poolWithDupes, 100);
      const names = result.map(c => c.playerName.toLowerCase());
      const uniqueNames = new Set(names);
      expect(uniqueNames.size).toEqual(names.length);
    });
  });
});
