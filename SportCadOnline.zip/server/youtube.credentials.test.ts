import { describe, it, expect } from "vitest";
import axios from "axios";

describe("YouTube OAuth credentials", () => {
  it("should exchange refresh token for a valid access token", async () => {
    const clientId = process.env.YOUTUBE_CLIENT_ID;
    const clientSecret = process.env.YOUTUBE_CLIENT_SECRET;
    const refreshToken = process.env.YOUTUBE_REFRESH_TOKEN;

    if (!clientId || !clientSecret || !refreshToken) {
      console.log("YouTube credentials not set — skipping test");
      return;
    }

    const response = await axios.post("https://oauth2.googleapis.com/token", {
      client_id: clientId,
      client_secret: clientSecret,
      refresh_token: refreshToken,
      grant_type: "refresh_token",
    });

    expect(response.status).toBe(200);
    expect(response.data.access_token).toBeTruthy();
    expect(response.data.token_type).toBe("Bearer");
    expect(response.data.scope).toContain("youtube");
    console.log("✅ YouTube credentials valid — scopes:", response.data.scope);
  }, 15000);
});
