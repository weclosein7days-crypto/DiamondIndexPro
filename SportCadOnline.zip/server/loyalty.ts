/**
 * SCO Loyalty Program
 * Players earn bonus credits based on weekly and monthly deposit totals.
 * Tiers are calculated from monthly deposits; weekly deposits trigger mid-cycle bonuses.
 */

import { getDb } from "./db";
import { creditAccounts, creditTransactions } from "../drizzle/schema";
import { eq } from "drizzle-orm";

// ─── Tier Definitions ────────────────────────────────────────────────────────

export type LoyaltyTier = "bronze" | "silver" | "gold" | "platinum" | "diamond";

export interface TierConfig {
  name: LoyaltyTier;
  label: string;
  emoji: string;
  color: string;
  // Monthly deposit threshold to reach this tier (in credits)
  monthlyThreshold: number;
  // Weekly deposit threshold for mid-cycle bonus (in credits)
  weeklyThreshold: number;
  // Bonus % on each deposit once at this tier
  depositBonusPct: number;
  // One-time bonus when first reaching this tier (credits)
  tierReachBonus: number;
  // Weekly bonus when weekly threshold is crossed (credits)
  weeklyBonus: number;
  // Monthly bonus when monthly threshold is crossed (credits)
  monthlyBonus: number;
  perks: string[];
}

export const LOYALTY_TIERS: TierConfig[] = [
  {
    name: "bronze",
    label: "Bronze",
    emoji: "🥉",
    color: "#cd7f32",
    monthlyThreshold: 0,
    weeklyThreshold: 0,
    depositBonusPct: 0,
    tierReachBonus: 0,
    weeklyBonus: 0,
    monthlyBonus: 0,
    perks: ["25 free credits on signup", "Access to all free games"],
  },
  {
    name: "silver",
    label: "Silver",
    emoji: "🥈",
    color: "#c0c0c0",
    monthlyThreshold: 50,   // $50/month deposits
    weeklyThreshold: 15,    // $15/week
    depositBonusPct: 3,     // 3% bonus on each deposit
    tierReachBonus: 10,     // 10 bonus credits when you hit Silver
    weeklyBonus: 5,         // 5 credits when weekly threshold crossed
    monthlyBonus: 15,       // 15 credits when monthly threshold crossed
    perks: ["3% bonus on every deposit", "+5 credits weekly reward", "+15 credits monthly reward", "Silver badge on profile"],
  },
  {
    name: "gold",
    label: "Gold",
    emoji: "🥇",
    color: "#ffd700",
    monthlyThreshold: 150,  // $150/month
    weeklyThreshold: 40,    // $40/week
    depositBonusPct: 5,     // 5% bonus on each deposit
    tierReachBonus: 25,
    weeklyBonus: 15,
    monthlyBonus: 40,
    perks: ["5% bonus on every deposit", "+15 credits weekly reward", "+40 credits monthly reward", "Gold badge on profile", "Priority grading queue"],
  },
  {
    name: "platinum",
    label: "Platinum",
    emoji: "💎",
    color: "#e5e4e2",
    monthlyThreshold: 400,  // $400/month
    weeklyThreshold: 100,   // $100/week
    depositBonusPct: 8,     // 8% bonus on each deposit
    tierReachBonus: 75,
    weeklyBonus: 40,
    monthlyBonus: 100,
    perks: ["8% bonus on every deposit", "+40 credits weekly reward", "+100 credits monthly reward", "Platinum badge", "Free auction listing per week", "Dedicated support"],
  },
  {
    name: "diamond",
    label: "Diamond",
    emoji: "💠",
    color: "#b9f2ff",
    monthlyThreshold: 1000, // $1000/month
    weeklyThreshold: 250,   // $250/week
    depositBonusPct: 12,    // 12% bonus on each deposit
    tierReachBonus: 200,
    weeklyBonus: 100,
    monthlyBonus: 300,
    perks: ["12% bonus on every deposit", "+100 credits weekly reward", "+300 credits monthly reward", "Diamond badge", "2 free auction listings per week", "VIP support", "Early access to new features"],
  },
];

export function getTierConfig(tier: LoyaltyTier): TierConfig {
  return LOYALTY_TIERS.find(t => t.name === tier)!;
}

export function calculateTierFromMonthly(monthlyDeposits: number): LoyaltyTier {
  if (monthlyDeposits >= 1000) return "diamond";
  if (monthlyDeposits >= 400) return "platinum";
  if (monthlyDeposits >= 150) return "gold";
  if (monthlyDeposits >= 50) return "silver";
  return "bronze";
}

export function getNextTier(current: LoyaltyTier): TierConfig | null {
  const idx = LOYALTY_TIERS.findIndex(t => t.name === current);
  return idx < LOYALTY_TIERS.length - 1 ? LOYALTY_TIERS[idx + 1] : null;
}

// ─── Loyalty Processing ───────────────────────────────────────────────────────

/**
 * Called after a successful credit purchase.
 * 1. Resets weekly/monthly counters if periods have rolled over
 * 2. Adds the deposit amount to weekly/monthly totals
 * 3. Awards deposit bonus % based on current tier
 * 4. Checks for weekly/monthly threshold crossings and awards bonuses
 * 5. Recalculates tier and awards tier-up bonus if applicable
 * Returns a summary of bonuses awarded.
 */
export async function processLoyaltyDeposit(
  userEmail: string,
  depositCredits: number, // credits purchased (not dollars)
): Promise<{
  depositBonus: number;
  weeklyBonus: number;
  monthlyBonus: number;
  tierUpBonus: number;
  newTier: LoyaltyTier;
  oldTier: LoyaltyTier;
  totalBonus: number;
}> {
  const db = await getDb();
  if (!db) return { depositBonus: 0, weeklyBonus: 0, monthlyBonus: 0, tierUpBonus: 0, newTier: "bronze" as LoyaltyTier, oldTier: "bronze" as LoyaltyTier, totalBonus: 0 };

  const [account] = await db
    .select()
    .from(creditAccounts)
    .where(eq(creditAccounts.userEmail, userEmail));

  if (!account) {
    return { depositBonus: 0, weeklyBonus: 0, monthlyBonus: 0, tierUpBonus: 0, newTier: "bronze", oldTier: "bronze", totalBonus: 0 };
  }

  const now = new Date();
  const oldTier = (account.loyaltyTier as LoyaltyTier) || "bronze";

  // ── Reset weekly counter if >7 days since last reset ──
  let weeklyDeposits = account.weeklyDeposits ?? 0;
  const weeklyResetAt = account.weeklyDepositResetAt;
  if (!weeklyResetAt || (now.getTime() - new Date(weeklyResetAt).getTime()) > 7 * 24 * 60 * 60 * 1000) {
    weeklyDeposits = 0;
  }

  // ── Reset monthly counter if >30 days since last reset ──
  let monthlyDeposits = account.monthlyDeposits ?? 0;
  const monthlyResetAt = account.monthlyDepositResetAt;
  if (!monthlyResetAt || (now.getTime() - new Date(monthlyResetAt).getTime()) > 30 * 24 * 60 * 60 * 1000) {
    monthlyDeposits = 0;
  }

  const prevWeekly = weeklyDeposits;
  const prevMonthly = monthlyDeposits;

  weeklyDeposits += depositCredits;
  monthlyDeposits += depositCredits;

  // ── Calculate bonuses ──
  const tierConfig = getTierConfig(oldTier);
  const depositBonus = Math.floor(depositCredits * tierConfig.depositBonusPct / 100);

  // Weekly threshold bonus (only if crossing the threshold this deposit)
  let weeklyBonus = 0;
  if (tierConfig.weeklyThreshold > 0 &&
      prevWeekly < tierConfig.weeklyThreshold &&
      weeklyDeposits >= tierConfig.weeklyThreshold) {
    weeklyBonus = tierConfig.weeklyBonus;
  }

  // Monthly threshold bonus (only if crossing the threshold this deposit)
  let monthlyBonus = 0;
  if (tierConfig.monthlyThreshold > 0 &&
      prevMonthly < tierConfig.monthlyThreshold &&
      monthlyDeposits >= tierConfig.monthlyThreshold) {
    monthlyBonus = tierConfig.monthlyBonus;
  }

  // ── Recalculate tier from new monthly total ──
  const newTier = calculateTierFromMonthly(monthlyDeposits);
  let tierUpBonus = 0;
  if (newTier !== oldTier) {
    const newTierConfig = getTierConfig(newTier);
    tierUpBonus = newTierConfig.tierReachBonus;
  }

  const totalBonus = depositBonus + weeklyBonus + monthlyBonus + tierUpBonus;

  // ── Persist updates ──
  await db!.update(creditAccounts)
    .set({
      weeklyDeposits,
      monthlyDeposits,
      weeklyDepositResetAt: !weeklyResetAt || (now.getTime() - new Date(weeklyResetAt).getTime()) > 7 * 24 * 60 * 60 * 1000 ? now : weeklyResetAt,
      monthlyDepositResetAt: !monthlyResetAt || (now.getTime() - new Date(monthlyResetAt).getTime()) > 30 * 24 * 60 * 60 * 1000 ? now : monthlyResetAt,
      loyaltyTier: newTier,
      credits: account.credits + totalBonus,
      purchasedCredits: account.purchasedCredits + totalBonus,
      totalLoyaltyBonusEarned: (account.totalLoyaltyBonusEarned ?? 0) + totalBonus,
    })
    .where(eq(creditAccounts.userEmail, userEmail));

  // ── Log bonus transaction ──
  if (totalBonus > 0) {
    const reasons: string[] = [];
    if (depositBonus > 0) reasons.push(`${tierConfig.depositBonusPct}% deposit bonus`);
    if (weeklyBonus > 0) reasons.push(`weekly threshold bonus`);
    if (monthlyBonus > 0) reasons.push(`monthly threshold bonus`);
    if (tierUpBonus > 0) reasons.push(`${newTier} tier-up bonus`);

    await db!.insert(creditTransactions).values({
      userEmail,
      amount: totalBonus,
      type: "purchase",
      reason: `Loyalty bonus: ${reasons.join(", ")}`,
    });
  }

  return { depositBonus, weeklyBonus, monthlyBonus, tierUpBonus, newTier, oldTier, totalBonus };
}

/**
 * Get the current loyalty status for a user (tier, progress, next tier info).
 * Used by the myAccount procedure to attach loyalty data to the account response.
 */
export async function getLoyaltyStatus(userEmail: string) {
  const db = await getDb();
  if (!db) return null;

  const [account] = await db
    .select()
    .from(creditAccounts)
    .where(eq(creditAccounts.userEmail, userEmail))
    .limit(1);

  if (!account) return null;

  const monthlyDeposits = Number(account.monthlyDeposits ?? 0);
  const weeklyDeposits = Number(account.weeklyDeposits ?? 0);
  const tier = (account.loyaltyTier as LoyaltyTier) ?? calculateTierFromMonthly(monthlyDeposits);
  const tierConfig = getTierConfig(tier);
  const nextTier = getNextTier(tier);

  const progressToNext = nextTier
    ? Math.min(100, Math.round((monthlyDeposits / nextTier.monthlyThreshold) * 100))
    : 100;

  return {
    tier,
    tierConfig,
    nextTier,
    monthlyDeposits,
    weeklyDeposits,
    progressToNext,
    totalLoyaltyBonusEarned: Number(account.totalLoyaltyBonusEarned ?? 0),
  };
}
