/**
 * YouTube Upload Service
 * Uploads MP4 videos to the SportsCardsOnline YouTube channel
 * using the YouTube Data API v3 with OAuth2 credentials.
 *
 * Setup: Provide YOUTUBE_CLIENT_ID, YOUTUBE_CLIENT_SECRET, YOUTUBE_REFRESH_TOKEN
 * via environment secrets. See README for how to obtain these.
 */
import axios from "axios";
import { createReadStream, statSync } from "fs";
import { ENV } from "./_core/env";

interface YouTubeUploadInput {
  videoPath: string;   // local file path to the MP4
  title: string;
  description: string;
  tags: string[];
  thumbnailUrl?: string;
}

interface YouTubeUploadResult {
  videoId: string;
  videoUrl: string;
  title: string;
}

// ─── Get a fresh access token from the refresh token ─────────────────────────
async function getAccessToken(): Promise<string> {
  const clientId = process.env.YOUTUBE_CLIENT_ID;
  const clientSecret = process.env.YOUTUBE_CLIENT_SECRET;
  const refreshToken = process.env.YOUTUBE_REFRESH_TOKEN;

  if (!clientId || !clientSecret || !refreshToken) {
    throw new Error("YouTube credentials not configured. Set YOUTUBE_CLIENT_ID, YOUTUBE_CLIENT_SECRET, YOUTUBE_REFRESH_TOKEN in secrets.");
  }

  const response = await axios.post("https://oauth2.googleapis.com/token", {
    client_id: clientId,
    client_secret: clientSecret,
    refresh_token: refreshToken,
    grant_type: "refresh_token",
  });

  return response.data.access_token as string;
}

// ─── Build SEO-optimized description ─────────────────────────────────────────
function buildDescription(title: string, excerpt: string, tags: string[], slug: string): string {
  const siteUrl = "https://www.sportcardsonline.com";
  return `${excerpt}

${title}

🃏 Browse & Buy Sports Cards: ${siteUrl}
📊 Free Card Valuations: ${siteUrl}/marketplace
🏆 Daily Tournaments & Giveaways: ${siteUrl}
⭐ Professional Card Grading: ${siteUrl}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📖 Read the full article: ${siteUrl}/blog/${slug}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Welcome to SportsCardsOnline.com — your #1 source for buying, selling, and grading sports cards online. We drop daily videos on the hottest rookie cards, trending players, card values, and market moves across baseball, football, basketball, hockey, and more.

Whether you're a seasoned collector or just pulling your first pack — this is your channel. Join thousands of collectors who trust SCO for the latest in the hobby. New videos every day. Subscribe and never miss a deal.

🔗 Shop & Grade Cards: ${siteUrl}
📦 Free Card Value Search — No Sign-Up Required
🏆 Daily Tournaments & Giveaways
📬 New Video Every Morning

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
#SportsCards #${tags.slice(0, 5).map(t => t.replace(/\s+/g, '')).join(' #')} #SportCardsOnline #CardCollecting #RookieCards #PSAGraded
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`;
}

// ─── Upload video to YouTube ──────────────────────────────────────────────────
export async function uploadToYouTube(input: YouTubeUploadInput & { excerpt: string; slug: string }): Promise<YouTubeUploadResult> {
  const accessToken = await getAccessToken();

  const fileSize = statSync(input.videoPath).size;
  const description = buildDescription(input.title, input.excerpt, input.tags, input.slug);

  // All SEO tags — YouTube allows up to 500 chars total
  const allTags = [
    ...input.tags,
    "sports cards",
    "buy sports cards",
    "sell sports cards",
    "sports card grading",
    "rookie cards",
    "PSA graded cards",
    "card collecting",
    "SportsCardsOnline",
    "card investment",
    "sports card market",
  ].slice(0, 15);

  // Step 1: Initialize resumable upload
  const initResponse = await axios.post(
    "https://www.googleapis.com/upload/youtube/v3/videos?uploadType=resumable&part=snippet,status",
    {
      snippet: {
        title: input.title.slice(0, 100),
        description,
        tags: allTags,
        categoryId: "17", // Sports
        defaultLanguage: "en",
        defaultAudioLanguage: "en",
      },
      status: {
        privacyStatus: "public",
        selfDeclaredMadeForKids: false,
        madeForKids: false,
      },
    },
    {
      headers: {
        Authorization: `Bearer ${accessToken}`,
        "Content-Type": "application/json",
        "X-Upload-Content-Type": "video/mp4",
        "X-Upload-Content-Length": fileSize,
      },
    }
  );

  const uploadUrl = initResponse.headers.location as string;
  if (!uploadUrl) throw new Error("YouTube did not return an upload URL");

  // Step 2: Upload the video file
  const fileStream = createReadStream(input.videoPath);
  const uploadResponse = await axios.put(uploadUrl, fileStream, {
    headers: {
      "Content-Type": "video/mp4",
      "Content-Length": fileSize,
    },
    maxBodyLength: Infinity,
    maxContentLength: Infinity,
    timeout: 600_000, // 10 minutes
  });

  const videoId = uploadResponse.data?.id as string;
  if (!videoId) throw new Error("YouTube upload failed — no video ID returned");

  const videoUrl = `https://www.youtube.com/watch?v=${videoId}`;
  console.log(`[youtubeService] Uploaded: ${videoUrl}`);

  // Step 3: Set thumbnail if provided
  if (input.thumbnailUrl) {
    try {
      const thumbResponse = await axios.get<ArrayBuffer>(input.thumbnailUrl, {
        responseType: "arraybuffer",
        timeout: 15000,
      });
      await axios.post(
        `https://www.googleapis.com/upload/youtube/v3/thumbnails/set?videoId=${videoId}`,
        thumbResponse.data,
        {
          headers: {
            Authorization: `Bearer ${accessToken}`,
            "Content-Type": "image/jpeg",
          },
        }
      );
      console.log(`[youtubeService] Thumbnail set for ${videoId}`);
    } catch (e) {
      console.warn(`[youtubeService] Thumbnail upload failed:`, (e as Error).message);
    }
  }

  return { videoId, videoUrl, title: input.title };
}

// ─── Check if YouTube credentials are configured ─────────────────────────────
export function isYouTubeConfigured(): boolean {
  return !!(
    process.env.YOUTUBE_CLIENT_ID &&
    process.env.YOUTUBE_CLIENT_SECRET &&
    process.env.YOUTUBE_REFRESH_TOKEN
  );
}
