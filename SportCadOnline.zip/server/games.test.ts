import { describe, it, expect } from "vitest";

// ─── Roulette Logic Tests ─────────────────────────────────────────────────────
describe("Roulette: betWins logic", () => {
  const reds = new Set([1,3,5,7,9,12,14,16,18,19,21,23,25,27,30,32,34,36]);
  function pocketColor(x: number | string) {
    if (x === 0 || x === "00") return "green";
    return reds.has(x as number) ? "red" : "black";
  }

  function betWins(bet: { kind: string; [k: string]: unknown }, n: number | string): boolean {
    switch (bet.kind) {
      case "straight": return bet.number === n;
      case "color": return n !== 0 && n !== "00" && pocketColor(n) === bet.color;
      case "parity": return n !== 0 && n !== "00" && (bet.parity === "odd" ? (n as number) % 2 !== 0 : (n as number) % 2 === 0);
      case "half": return n !== 0 && n !== "00" && (bet.half === "low" ? (n as number) <= 18 : (n as number) >= 19);
      case "dozen": {
        if (n === 0 || n === "00") return false;
        const lo = ((bet.dozen as number) - 1) * 12 + 1;
        return (n as number) >= lo && (n as number) <= lo + 11;
      }
      case "column": {
        if (n === 0 || n === "00") return false;
        return (n as number) % 3 === ((bet.column as number) === 3 ? 0 : (bet.column as number));
      }
      default: return false;
    }
  }

  it("straight bet wins on exact number", () => {
    expect(betWins({ kind: "straight", number: 17 }, 17)).toBe(true);
    expect(betWins({ kind: "straight", number: 17 }, 18)).toBe(false);
    expect(betWins({ kind: "straight", number: "00" }, "00")).toBe(true);
  });

  it("color bet: red wins on red numbers", () => {
    expect(betWins({ kind: "color", color: "red" }, 1)).toBe(true);
    expect(betWins({ kind: "color", color: "red" }, 2)).toBe(false);
    expect(betWins({ kind: "color", color: "red" }, 0)).toBe(false);
    expect(betWins({ kind: "color", color: "red" }, "00")).toBe(false);
  });

  it("color bet: black wins on black numbers", () => {
    expect(betWins({ kind: "color", color: "black" }, 2)).toBe(true);
    expect(betWins({ kind: "color", color: "black" }, 1)).toBe(false);
  });

  it("parity bet: even/odd", () => {
    expect(betWins({ kind: "parity", parity: "even" }, 4)).toBe(true);
    expect(betWins({ kind: "parity", parity: "even" }, 3)).toBe(false);
    expect(betWins({ kind: "parity", parity: "odd" }, 7)).toBe(true);
    expect(betWins({ kind: "parity", parity: "even" }, 0)).toBe(false);
  });

  it("half bet: low/high", () => {
    expect(betWins({ kind: "half", half: "low" }, 1)).toBe(true);
    expect(betWins({ kind: "half", half: "low" }, 18)).toBe(true);
    expect(betWins({ kind: "half", half: "low" }, 19)).toBe(false);
    expect(betWins({ kind: "half", half: "high" }, 36)).toBe(true);
    expect(betWins({ kind: "half", half: "high" }, 0)).toBe(false);
  });

  it("dozen bet: 1st/2nd/3rd dozen", () => {
    expect(betWins({ kind: "dozen", dozen: 1 }, 1)).toBe(true);
    expect(betWins({ kind: "dozen", dozen: 1 }, 12)).toBe(true);
    expect(betWins({ kind: "dozen", dozen: 1 }, 13)).toBe(false);
    expect(betWins({ kind: "dozen", dozen: 2 }, 13)).toBe(true);
    expect(betWins({ kind: "dozen", dozen: 3 }, 36)).toBe(true);
    expect(betWins({ kind: "dozen", dozen: 1 }, 0)).toBe(false);
  });

  it("green pockets (0 and 00) lose all outside bets", () => {
    const outsideBets = [
      { kind: "color", color: "red" },
      { kind: "color", color: "black" },
      { kind: "parity", parity: "even" },
      { kind: "half", half: "low" },
      { kind: "dozen", dozen: 1 },
    ];
    for (const bet of outsideBets) {
      expect(betWins(bet, 0)).toBe(false);
      expect(betWins(bet, "00")).toBe(false);
    }
  });

  it("house edge: 38 pockets, straight bet pays 35:1 → expected return 36/38 = 94.74%", () => {
    const payout = 35; // net profit on win
    const pockets = 38;
    const expectedReturn = (1 * (payout + 1)) / pockets; // 36/38
    expect(expectedReturn).toBeCloseTo(0.9474, 3);
    const houseEdge = 1 - expectedReturn;
    expect(houseEdge).toBeCloseTo(0.0526, 3); // 5.26%
  });
});

// ─── Blackjack Logic Tests ────────────────────────────────────────────────────
describe("Blackjack: hand value calculation", () => {
  function cardVal(v: string): number {
    if (["J","Q","K"].includes(v)) return 10;
    if (v === "A") return 11;
    return parseInt(v);
  }

  function handValue(hand: { suit: string; value: string }[]): number {
    let total = 0, aces = 0;
    for (const c of hand) { total += cardVal(c.value); if (c.value === "A") aces++; }
    while (total > 21 && aces > 0) { total -= 10; aces--; }
    return total;
  }

  it("face cards count as 10", () => {
    expect(handValue([{ suit: "♠", value: "K" }, { suit: "♥", value: "Q" }])).toBe(20);
  });

  it("ace counts as 11 when safe", () => {
    expect(handValue([{ suit: "♠", value: "A" }, { suit: "♥", value: "9" }])).toBe(20);
  });

  it("ace counts as 1 when 11 would bust", () => {
    expect(handValue([{ suit: "♠", value: "A" }, { suit: "♥", value: "9" }, { suit: "♦", value: "5" }])).toBe(15);
  });

  it("natural blackjack = 21 with 2 cards", () => {
    const hand = [{ suit: "♠", value: "A" }, { suit: "♥", value: "K" }];
    expect(handValue(hand)).toBe(21);
  });

  it("bust detection: total > 21 with no aces to reduce", () => {
    const hand = [
      { suit: "♠", value: "K" },
      { suit: "♥", value: "Q" },
      { suit: "♦", value: "5" },
    ];
    expect(handValue(hand)).toBe(25);
    expect(handValue(hand) > 21).toBe(true);
  });

  it("soft 17 stays at 17 (dealer stands)", () => {
    const hand = [{ suit: "♠", value: "A" }, { suit: "♥", value: "6" }];
    expect(handValue(hand)).toBe(17);
  });

  it("double ace: one counts as 1, one as 11", () => {
    const hand = [{ suit: "♠", value: "A" }, { suit: "♥", value: "A" }];
    expect(handValue(hand)).toBe(12);
  });

  it("3:2 payout on natural blackjack", () => {
    const bet = 10;
    const payout = Math.floor(bet * 2.5); // 3:2 = 1.5x profit + bet = 2.5x total
    expect(payout).toBe(25);
    const netProfit = payout - bet;
    expect(netProfit).toBe(15);
  });
});
