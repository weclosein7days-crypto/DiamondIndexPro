/**
 * eBay Marketplace Account Deletion Compliance Endpoint
 * Required by eBay Developer Program for marketplace apps.
 * Handles notification when an eBay user requests account deletion.
 */
import type { Express } from "express";

export function registerEbayDeletionRoute(app: Express): void {
  // eBay sends a GET request to verify the endpoint
  app.get("/api/ebay/account-deletion", (req: any, res: any) => {
    const challenge = req.query.challenge_code;
    if (challenge) {
      // eBay verification: return the challenge code
      res.json({ challengeResponse: challenge });
    } else {
      res.status(200).json({ status: "ok" });
    }
  });

  // eBay sends a POST request when a user deletes their account
  app.post("/api/ebay/account-deletion", (req: any, res: any) => {
    // Log the deletion notification
    console.log("[eBay] Account deletion notification received:", req.body);
    // In a production app, you would delete/anonymize the user's data here
    res.status(200).json({ status: "ok" });
  });
}
