/**
 * CartContext logic tests (pure unit — no DOM needed)
 * Tests the cart item management logic in isolation.
 */
import { describe, it, expect } from "vitest";

// Pure cart logic extracted for testing
function makeCart() {
  const items: { id: number; title: string; price: string }[] = [];
  return {
    addItem(item: { id: number; title: string; price: string }) {
      if (!items.some(i => i.id === item.id)) items.push(item);
    },
    removeItem(id: number) {
      const idx = items.findIndex(i => i.id === id);
      if (idx !== -1) items.splice(idx, 1);
    },
    clearCart() { items.splice(0, items.length); },
    isInCart(id: number) { return items.some(i => i.id === id); },
    get totalCount() { return items.length; },
    get subtotal() { return items.reduce((s, i) => s + parseFloat(i.price), 0); },
    get items() { return [...items]; },
  };
}

describe("Cart logic", () => {
  it("starts empty", () => {
    const cart = makeCart();
    expect(cart.totalCount).toBe(0);
    expect(cart.subtotal).toBe(0);
  });

  it("adds an item", () => {
    const cart = makeCart();
    cart.addItem({ id: 1, title: "Mickey Mantle", price: "150.00" });
    expect(cart.totalCount).toBe(1);
    expect(cart.isInCart(1)).toBe(true);
    expect(cart.subtotal).toBeCloseTo(150);
  });

  it("does not add duplicates", () => {
    const cart = makeCart();
    cart.addItem({ id: 1, title: "Mickey Mantle", price: "150.00" });
    cart.addItem({ id: 1, title: "Mickey Mantle", price: "150.00" });
    expect(cart.totalCount).toBe(1);
  });

  it("removes an item", () => {
    const cart = makeCart();
    cart.addItem({ id: 1, title: "Mickey Mantle", price: "150.00" });
    cart.addItem({ id: 2, title: "Tom Brady", price: "75.00" });
    cart.removeItem(1);
    expect(cart.totalCount).toBe(1);
    expect(cart.isInCart(1)).toBe(false);
    expect(cart.isInCart(2)).toBe(true);
  });

  it("clears the cart", () => {
    const cart = makeCart();
    cart.addItem({ id: 1, title: "Mickey Mantle", price: "150.00" });
    cart.addItem({ id: 2, title: "Tom Brady", price: "75.00" });
    cart.clearCart();
    expect(cart.totalCount).toBe(0);
    expect(cart.subtotal).toBe(0);
  });

  it("calculates subtotal correctly", () => {
    const cart = makeCart();
    cart.addItem({ id: 1, title: "Card A", price: "99.99" });
    cart.addItem({ id: 2, title: "Card B", price: "49.99" });
    cart.addItem({ id: 3, title: "Card C", price: "0.01" });
    expect(cart.subtotal).toBeCloseTo(149.99);
  });

  it("isInCart returns false for unknown id", () => {
    const cart = makeCart();
    expect(cart.isInCart(999)).toBe(false);
  });
});
