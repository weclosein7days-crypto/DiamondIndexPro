import { describe, it, expect } from "vitest";
import { verifySMTP } from "./email";

describe("Email SMTP", () => {
  it("should connect to SMTP server with provided credentials (skipped if not configured)", async () => {
    if (!process.env.SMTP_USER || !process.env.SMTP_PASS) {
      console.log("[Email] SMTP credentials not set — skipping SMTP connection test");
      return;
    }
    const ok = await verifySMTP();
    expect(ok).toBe(true);
  }, 15000);
});
