/**
 * AI Blog Generation Engine
 * Fetches trending sports card news via Google News RSS,
 * invokes the LLM to write an SEO-optimized post, and saves to DB.
 *
 * Auto-features on every generated post:
 *  1. Authoritative outbound links injected for known brands/orgs (PSA, Beckett, eBay, etc.)
 *  2. Internal CTA links to SportsCardsOnline.com pages (marketplace, grading, etc.)
 *  3. Enriched auto-tags: LLM tags + sport + grading + topic-specific tags (up to 10)
 */
import axios from "axios";
import { getDb } from "./db";
import { blogPosts } from "../drizzle/schema";
import { invokeLLM } from "./_core/llm";
import { storagePut } from "./storage";
import { eq, desc } from "drizzle-orm";

// ─── RSS Topics rotated daily ────────────────────────────────────────────────
const TOPICS = [
  "sports cards rookie 2026",
  "baseball cards PSA graded",
  "football cards rookie investment",
  "basketball cards trending 2026",
  "hockey cards collectible",
  "sports cards auction results",
  "Topps Bowman baseball cards",
  "Panini Prizm football cards",
  "sports card market value",
  "vintage baseball cards",
  "sports card grading PSA Beckett SGC",
  "sports card investment portfolio",
  "MLB draft prospects cards",
  "NFL rookie cards 2026",
  "NBA rookie cards 2026",
];

// ─── Authoritative outbound link map ─────────────────────────────────────────
// Each entry: keyword regex → { url, label }
// First occurrence of each keyword in the post is linked; subsequent ones are left plain.
const AUTHORITATIVE_LINKS: { keyword: RegExp; url: string; label: string }[] = [
  { keyword: /\bPSA\b/g,                    url: "https://www.psacard.com",                                          label: "PSA" },
  { keyword: /\bBeckett\b/gi,               url: "https://www.beckett.com",                                          label: "Beckett" },
  { keyword: /\bBGS\b/g,                    url: "https://www.beckett.com/grading",                                  label: "BGS" },
  { keyword: /\bSGC\b/g,                    url: "https://www.sgccard.com",                                          label: "SGC" },
  { keyword: /\beBay\b/gi,                  url: "https://www.ebay.com/b/Sports-Trading-Cards/212/bn_1860753",       label: "eBay" },
  { keyword: /\bTopps\b/gi,                 url: "https://www.topps.com",                                            label: "Topps" },
  { keyword: /\bPanini\b/gi,                url: "https://www.paniniamerica.net",                                    label: "Panini" },
  { keyword: /\bBowman\b/gi,                url: "https://www.topps.com/collections/bowman",                         label: "Bowman" },
  { keyword: /\bUpper Deck\b/gi,            url: "https://www.upperdeck.com",                                        label: "Upper Deck" },
  { keyword: /\bNBA\b/g,                    url: "https://www.nba.com",                                              label: "NBA" },
  { keyword: /\bNFL\b/g,                    url: "https://www.nfl.com",                                              label: "NFL" },
  { keyword: /\bMLB\b/g,                    url: "https://www.mlb.com",                                              label: "MLB" },
  { keyword: /\bNHL\b/g,                    url: "https://www.nhl.com",                                              label: "NHL" },
  { keyword: /\bWNBA\b/g,                   url: "https://www.wnba.com",                                             label: "WNBA" },
  { keyword: /\bSports Card Investor\b/gi,  url: "https://www.sportscardinvestor.com",                               label: "Sports Card Investor" },
  { keyword: /\bAlt\.gg\b/gi,               url: "https://www.alt.gg",                                               label: "Alt.gg" },
  { keyword: /\bGraded Card Investors\b/gi, url: "https://gradedcardinvestors.com",                                  label: "Graded Card Investors" },
  { keyword: /\bCollectZilla\b/gi,          url: "https://www.collectzilla.com",                                     label: "CollectZilla" },
  { keyword: /\bComc\b/gi,                  url: "https://www.comc.com",                                             label: "COMC" },
  { keyword: /\bMySlabs\b/gi,               url: "https://www.myslabs.com",                                          label: "MySlabs" },
];

// ─── Internal CTA link blocks appended to every post ─────────────────────────
const INTERNAL_CTA_BLOCKS: { sport: string | null; links: { text: string; path: string }[] }[] = [
  {
    sport: null, // applies to all posts
    links: [
      { text: "Browse our Marketplace",      path: "/marketplace" },
      { text: "Grade Your Cards with SCG",   path: "/grading" },
      { text: "Sell Your Cards",             path: "/sell" },
    ],
  },
  {
    sport: "basketball",
    links: [
      { text: "Shop Basketball Cards",       path: "/marketplace?sport=basketball" },
    ],
  },
  {
    sport: "football",
    links: [
      { text: "Shop Football Cards",         path: "/marketplace?sport=football" },
    ],
  },
  {
    sport: "baseball",
    links: [
      { text: "Shop Baseball Cards",         path: "/marketplace?sport=baseball" },
    ],
  },
  {
    sport: "hockey",
    links: [
      { text: "Shop Hockey Cards",           path: "/marketplace?sport=hockey" },
    ],
  },
];

/**
 * Inject authoritative outbound links into markdown content.
 * Each keyword is linked at most once per post (first occurrence only).
 * Links are NOT injected inside existing markdown links or code blocks.
 */
function injectAuthoritativeLinks(content: string): string {
  // Collect ranges to skip (existing links and code blocks)
  const SKIP_PATTERNS = [
    /```[\s\S]*?```/g,
    /`[^`]+`/g,
    /\[([^\]]+)\]\([^)]+\)/g,
    /https?:\/\/\S+/g,
  ];
  const skipRanges: [number, number][] = [];
  for (const re of SKIP_PATTERNS) {
    re.lastIndex = 0;
    let m;
    while ((m = re.exec(content)) !== null) {
      skipRanges.push([m.index, m.index + m[0].length]);
    }
  }
  const inSkip = (start: number, len: number) =>
    skipRanges.some(([s, e]) => start < e && start + len > s);

  let result = content;
  let cumulativeOffset = 0;

  for (const { keyword, url, label } of AUTHORITATIVE_LINKS) {
    // Work on a fresh copy of the regex each iteration
    const re = new RegExp(keyword.source, keyword.flags.replace("g", "") + "g");
    re.lastIndex = 0;
    const m = re.exec(result);
    if (!m) continue;
    const pos = m.index;
    if (inSkip(pos, m[0].length)) continue;

    const linked = `[${m[0]}](${url} "${label}")`;
    result = result.slice(0, pos) + linked + result.slice(pos + m[0].length);
    const delta = linked.length - m[0].length;
    cumulativeOffset += delta;

    // Mark the newly inserted link as a skip range so nothing else touches it
    skipRanges.push([pos, pos + linked.length]);
  }

  return result;
}

/**
 * Append internal CTA link section to the end of the post.
 */
function appendInternalCTAs(content: string, sport: string, siteUrl: string): string {
  const applicableBlocks = INTERNAL_CTA_BLOCKS.filter(
    b => b.sport === null || b.sport === sport
  );
  const allLinks = applicableBlocks.flatMap(b => b.links);
  if (allLinks.length === 0) return content;

  const linkList = allLinks
    .map(l => `- [${l.text}](${siteUrl}${l.path})`)
    .join("\n");

  return content.trimEnd() + `\n\n---\n\n## Explore More on SportsCardsOnline\n\n${linkList}\n`;
}

/**
 * Enrich LLM-generated tags with sport-specific and platform tags.
 */
function enrichTags(tags: string[], sport: string, title: string): string[] {
  const base = new Set(tags.map(t => t.toLowerCase().trim()));
  // Always add sport
  if (sport && sport !== "all sports") base.add(sport);
  // Platform tags
  base.add("sports cards");
  base.add("card collecting");
  // Grading tags
  if (/psa/i.test(title)) base.add("psa grading");
  if (/beckett|bgs/i.test(title)) base.add("beckett grading");
  if (/sgc/i.test(title)) base.add("sgc grading");
  // Content type tags
  if (/rookie/i.test(title)) base.add("rookie cards");
  if (/invest/i.test(title)) base.add("card investment");
  if (/auction/i.test(title)) base.add("card auctions");
  if (/vintage/i.test(title)) base.add("vintage cards");
  if (/topps/i.test(title)) base.add("topps");
  if (/panini/i.test(title)) base.add("panini");
  if (/bowman/i.test(title)) base.add("bowman");
  // Deduplicate and cap at 10
  return Array.from(base).slice(0, 10);
}

// ─── Fetch trending headlines from Google News RSS ───────────────────────────
async function fetchTrendingNews(topic: string): Promise<{ title: string; description: string; link: string }[]> {
  const url = `https://news.google.com/rss/search?q=${encodeURIComponent(topic)}&hl=en-US&gl=US&ceid=US:en`;
  try {
    const r = await axios.get<string>(url, {
      timeout: 10000,
      headers: { "User-Agent": "Mozilla/5.0 (compatible; SportsCardsOnline/1.0)" },
    });
    const items: { title: string; description: string; link: string }[] = [];
    const itemRegex = /<item>([\s\S]*?)<\/item>/g;
    let match;
    while ((match = itemRegex.exec(r.data)) !== null && items.length < 8) {
      const block = match[1];
      const title = (block.match(/<title><!\[CDATA\[(.*?)\]\]><\/title>/) || block.match(/<title>(.*?)<\/title>/))?.[1] ?? "";
      const description = (block.match(/<description><!\[CDATA\[(.*?)\]\]><\/description>/) || block.match(/<description>(.*?)<\/description>/))?.[1] ?? "";
      const link = (block.match(/<link>(.*?)<\/link>/))?.[1] ?? "";
      if (title) items.push({ title: title.replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">"), description: description.slice(0, 300), link });
    }
    return items;
  } catch {
    return [];
  }
}

// ─── Generate a slug from a title ────────────────────────────────────────────
function slugify(title: string): string {
  return title
    .toLowerCase()
    .replace(/[^a-z0-9\s-]/g, "")
    .replace(/\s+/g, "-")
    .replace(/-+/g, "-")
    .slice(0, 80)
    + "-" + Date.now().toString(36);
}

// ─── Determine sport from topic ───────────────────────────────────────────────
function sportFromTopic(topic: string): string {
  if (/baseball|mlb|bowman|topps/i.test(topic)) return "baseball";
  if (/football|nfl|panini/i.test(topic)) return "football";
  if (/basketball|nba/i.test(topic)) return "basketball";
  if (/hockey|nhl/i.test(topic)) return "hockey";
  return "all sports";
}

// ─── Main: generate one blog post ────────────────────────────────────────────
export async function generateBlogPost(opts?: { topic?: string; sport?: string }): Promise<{ id: number; title: string; slug: string }> {
  // Pick topic — rotate by day of year
  const dayOfYear = Math.floor((Date.now() - new Date(new Date().getFullYear(), 0, 0).getTime()) / 86400000);
  const topic = opts?.topic ?? TOPICS[dayOfYear % TOPICS.length];
  const sport = sportFromTopic(topic);

  // Fetch news headlines
  const headlines = await fetchTrendingNews(topic);
  const headlineText = headlines.slice(0, 5).map((h, i) => `${i + 1}. ${h.title}`).join("\n");

  // Invoke LLM to write the post
  const systemPrompt = `You are an expert sports card blogger and SEO specialist for SportsCardsOnline.com — a marketplace where collectors buy, sell, and grade sports cards. Write engaging, SEO-optimized blog posts that help collectors discover valuable cards, understand market trends, and make smart buying decisions. Always include a call-to-action linking back to SportsCardsOnline.com.`;

  const userPrompt = `Write a compelling, SEO-optimized blog post for SportsCardsOnline.com about: "${topic}"

Here are today's trending headlines for context:
${headlineText || "No specific headlines today — write based on general knowledge of the topic."}

Requirements:
- Title: Catchy, keyword-rich, 50-70 characters (include year 2026 where relevant)
- Length: 700-900 words
- Structure: Introduction, 3-4 main sections with H2 headers, Conclusion with CTA
- Include: specific player names, card sets, estimated values, grading tips
- SEO keywords to naturally include: sports cards, buy sports cards online, card grading, rookie cards, [sport] cards
- CTA: End with a paragraph directing readers to SportsCardsOnline.com to browse, grade, or sell cards
- Tone: Enthusiastic but informative, like a knowledgeable collector talking to fellow collectors
- Format: Use markdown with ## for H2 headers
- Do NOT add markdown hyperlinks yourself — they will be injected automatically after generation

Return a JSON object with these exact fields:
{
  "title": "...",
  "excerpt": "One compelling sentence, 150-160 chars, for meta description",
  "content": "Full markdown blog post...",
  "tags": ["tag1", "tag2", "tag3", "tag4", "tag5"]
}`;

  const response = await invokeLLM({
    messages: [
      { role: "system", content: systemPrompt },
      { role: "user", content: userPrompt },
    ],
    response_format: {
      type: "json_schema",
      json_schema: {
        name: "blog_post",
        strict: true,
        schema: {
          type: "object",
          properties: {
            title: { type: "string" },
            excerpt: { type: "string" },
            content: { type: "string" },
            tags: { type: "array", items: { type: "string" } },
          },
          required: ["title", "excerpt", "content", "tags"],
          additionalProperties: false,
        },
      },
    },
  });

  const raw = response.choices?.[0]?.message?.content ?? "{}";
  let parsed: { title: string; excerpt: string; content: string; tags: string[] };
  try {
    parsed = typeof raw === "string" ? JSON.parse(raw) : raw;
  } catch {
    throw new Error("LLM returned invalid JSON for blog post");
  }

  const { title, excerpt } = parsed;
  let { content, tags } = parsed;
  const slug = slugify(title);

  // ── Post-process content ──────────────────────────────────────────────────
  // 1. Inject authoritative outbound links (first occurrence of each brand/org)
  content = injectAuthoritativeLinks(content);
  // 2. Append internal CTA links section
  const siteUrl = "https://www.sportcardsonline.com";
  content = appendInternalCTAs(content, sport, siteUrl);
  // 3. Enrich tags
  tags = enrichTags(tags, sport, title);

  console.log(`[blogEngine] Injected ${AUTHORITATIVE_LINKS.length} authoritative link patterns, enriched tags: [${tags.join(", ")}]`);

  // Generate a cover image using the image generation service
  let coverImageUrl: string | null = null;
  try {
    const { generateImage } = await import("./_core/imageGeneration");
    const imgResult = await generateImage({
      prompt: `Professional sports card collector blog thumbnail: ${title}. Dark navy background, gold accents, sports card imagery, modern design, 16:9 aspect ratio, photorealistic`,
    });
    if (imgResult?.url) {
      // Upload to S3 for permanent storage
      const imgResp = await axios.get<ArrayBuffer>(imgResult.url, { responseType: "arraybuffer", timeout: 15000 });
      const buf = Buffer.from(imgResp.data);
      const key = `blog-covers/${slug}.jpg`;
      const s3Result = await storagePut(key, buf, "image/jpeg");
      coverImageUrl = s3Result.url;
    }
  } catch (e) {
    console.warn("[blogEngine] Cover image generation failed:", (e as Error).message);
  }

  // Save to database
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  const [result] = await db.insert(blogPosts).values({
    title,
    slug,
    excerpt,
    content,
    sport,
    tags: JSON.stringify(tags),
    coverImageUrl,
    status: "published",
    publishedAt: new Date(),
  });

  const insertId = (result as any).insertId as number;
  console.log(`[blogEngine] Generated post #${insertId}: "${title}"`);
  return { id: insertId, title, slug };
}

// ─── List published posts ─────────────────────────────────────────────────────
export async function listBlogPosts(limit = 20, offset = 0) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  return db
    .select()
    .from(blogPosts)
    .where(eq(blogPosts.status, "published"))
    .orderBy(desc(blogPosts.publishedAt))
    .limit(limit)
    .offset(offset);
}

// ─── Get post by slug ─────────────────────────────────────────────────────────
export async function getBlogPostBySlug(slug: string) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  const [post] = await db.select().from(blogPosts).where(eq(blogPosts.slug, slug)).limit(1);
  return post ?? null;
}

// ─── Delete post ──────────────────────────────────────────────────────────────
export async function deleteBlogPost(id: number) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.delete(blogPosts).where(eq(blogPosts.id, id));
}

// ─── List ALL posts (admin) ───────────────────────────────────────────────────
export async function listAllBlogPosts(limit = 50) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  return db
    .select()
    .from(blogPosts)
    .orderBy(desc(blogPosts.createdAt))
    .limit(limit);
}

// ─── Update post fields ───────────────────────────────────────────────────────
export async function updateBlogPost(id: number, data: Partial<{ youtubeVideoId: string; youtubeUrl: string; videoUrl: string; videoStatus: string; videoErrorMsg: string; status: string; publishedAt: Date; youtubeAutoTags: string; youtubeAutoLinks: string }>) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.update(blogPosts).set({ ...data, updatedAt: new Date() }).where(eq(blogPosts.id, id));
}
