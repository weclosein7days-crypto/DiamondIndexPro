import nodemailer from "nodemailer";

const ADMIN_EMAIL = "weclosein7days@email.com";

// Create reusable transporter using SMTP env vars
function createTransporter() {
  const user = process.env.SMTP_USER;
  const pass = process.env.SMTP_PASS;
  const from = process.env.SMTP_FROM || `SportCardsOnline <${user}>`;

  if (!user || !pass) {
    console.warn("[Email] SMTP_USER or SMTP_PASS not set — emails will be skipped");
    return null;
  }

  const host = process.env.SMTP_HOST || "smtp.ionos.com";
  const port = parseInt(process.env.SMTP_PORT || "587", 10);
  const secure = port === 465;

  return nodemailer.createTransport({
    host,
    port,
    secure,
    auth: { user, pass },
    tls: { rejectUnauthorized: false },
  });
}

export async function sendEmail(opts: {
  to: string;
  subject: string;
  html: string;
  replyTo?: string;
  attachments?: { filename: string; content: Buffer | string; contentType?: string }[];
}): Promise<boolean> {
  const transporter = createTransporter();
  if (!transporter) return false;

  const from = process.env.SMTP_FROM || process.env.SMTP_USER;
  try {
    await transporter.sendMail({ from, ...opts });
    return true;
  } catch (err: any) {
    console.error("[Email] Send failed:", err.message);
    return false;
  }
}

// Verify SMTP connection (used in test)
export async function verifySMTP(): Promise<boolean> {
  const transporter = createTransporter();
  if (!transporter) return false;
  try {
    await transporter.verify();
    return true;
  } catch (err: any) {
    console.error("[Email] SMTP verify failed:", err.message);
    return false;
  }
}

// ─── Template helpers ────────────────────────────────────────────────────────

function baseTemplate(title: string, body: string): string {
  return `<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>${title}</title>
  <style>
    body { margin:0; padding:0; background:#060e1a; font-family:Arial,sans-serif; color:#e2e8f0; }
    .wrapper { max-width:600px; margin:0 auto; padding:32px 16px; }
    .logo { text-align:center; margin-bottom:24px; }
    .logo img { height:70px; }
    .card { background:#0d1f3c; border:1px solid #1e3a5f; border-radius:12px; padding:32px; }
    h1 { color:#ffffff; font-size:22px; margin:0 0 16px; }
    p { color:#94a3b8; font-size:15px; line-height:1.6; margin:0 0 12px; }
    .highlight { color:#ffffff; font-weight:bold; }
    .btn { display:inline-block; background:#C41E3A; color:#ffffff; padding:12px 28px; border-radius:8px; text-decoration:none; font-weight:bold; margin:16px 0; }
    .divider { border:none; border-top:1px solid #1e3a5f; margin:24px 0; }
    .footer-text { text-align:center; color:#475569; font-size:12px; margin-top:24px; }
    .badge { display:inline-block; background:#1e3a5f; color:#60a5fa; padding:4px 12px; border-radius:20px; font-size:13px; font-weight:bold; }
    .status-green { background:#052e16; color:#4ade80; }
    .status-orange { background:#431407; color:#fb923c; }
    .status-red { background:#450a0a; color:#f87171; }
  </style>
</head>
<body>
  <div class="wrapper">
    <div class="logo">
      <img src="https://d2xsxph8kpxj0f.cloudfront.net/310d9a96-4f4a-4a0d-b0a3-d3a0b5e2c7f1-pasted_file_NDxW0y_image.png" alt="SportCardsOnline" />
    </div>
    <div class="card">
      ${body}
    </div>
    <p class="footer-text">SportCardsOnline.com &mdash; The Collector's Platform &bull; <a href="https://sportcardsonline.com" style="color:#475569">sportcardsonline.com</a></p>
  </div>
</body>
</html>`;
}

// ─── Email Templates ──────────────────────────────────────────────────────────

export function emailTemplates() {
  return {

    welcome: (name: string) => ({
      subject: "Welcome to SportCardsOnline! 🏆",
      html: baseTemplate("Welcome!", `
        <h1>Welcome to SportCardsOnline, ${name}!</h1>
        <p>You've joined the best sports card Arena on the web. Here's what you can do right now:</p>
        <ul style="color:#94a3b8;line-height:2">
          <li>📸 <span class="highlight">Grade your cards</span> with AI-powered SCG grading</li>
          <li>🛒 <span class="highlight">Browse the Arena</span> — thousands of cards available</li>
          <li>🔄 <span class="highlight">Trade cards</span> with collectors nationwide</li>
          <li>🏷️ <span class="highlight">List your cards</span> for sale or auction</li>
        </ul>
        <a href="https://sportcardsonline.com/grade" class="btn">Grade Your First Card</a>
        <hr class="divider" />
        <p>Need help? Reply to this email or visit our <a href="https://sportcardsonline.com" style="color:#60a5fa">Help Center</a>.</p>
      `),
    }),

    orderPlaced: (buyerName: string, orderDetails: { id: string; cardTitle: string; price: number; sellerName: string }) => ({
      subject: `Order Confirmed — ${orderDetails.cardTitle}`,
      html: baseTemplate("Order Confirmed", `
        <h1>Order Confirmed! 🎉</h1>
        <p>Hi ${buyerName}, your order has been placed successfully.</p>
        <hr class="divider" />
        <p><span class="highlight">Order #:</span> ${orderDetails.id}</p>
        <p><span class="highlight">Card:</span> ${orderDetails.cardTitle}</p>
        <p><span class="highlight">Price:</span> $${orderDetails.price.toFixed(2)}</p>
        <p><span class="highlight">Seller:</span> ${orderDetails.sellerName}</p>
        <hr class="divider" />
        <p>Your payment is held in <span class="badge">Escrow</span> until the card is delivered. The seller has been notified to ship.</p>
        <a href="https://sportcardsonline.com/orders" class="btn">Track Your Order</a>
      `),
    }),

    orderSold: (sellerName: string, orderDetails: { id: string; cardTitle: string; price: number; buyerName: string }) => ({
      subject: `Your card sold — ${orderDetails.cardTitle}`,
      html: baseTemplate("Card Sold!", `
        <h1>Your Card Sold! 💰</h1>
        <p>Hi ${sellerName}, great news — someone purchased your card.</p>
        <hr class="divider" />
        <p><span class="highlight">Order #:</span> ${orderDetails.id}</p>
        <p><span class="highlight">Card:</span> ${orderDetails.cardTitle}</p>
        <p><span class="highlight">Sale Price:</span> $${orderDetails.price.toFixed(2)}</p>
        <p><span class="highlight">Buyer:</span> ${orderDetails.buyerName}</p>
        <hr class="divider" />
        <p>Please ship the card within <span class="highlight">3 business days</span> and enter the tracking number in your Orders page. Funds will be released once the buyer confirms receipt.</p>
        <a href="https://sportcardsonline.com/orders" class="btn">Enter Tracking Number</a>
      `),
    }),

    orderShipped: (buyerName: string, orderDetails: { id: string; cardTitle: string; trackingNumber: string; carrier: string }) => ({
      subject: `Your card is on the way — ${orderDetails.cardTitle}`,
      html: baseTemplate("Card Shipped!", `
        <h1>Your Card Has Shipped! 📦</h1>
        <p>Hi ${buyerName}, the seller has shipped your card.</p>
        <hr class="divider" />
        <p><span class="highlight">Card:</span> ${orderDetails.cardTitle}</p>
        <p><span class="highlight">Carrier:</span> ${orderDetails.carrier}</p>
        <p><span class="highlight">Tracking #:</span> <span class="badge">${orderDetails.trackingNumber}</span></p>
        <hr class="divider" />
        <p>Once you receive the card, please confirm delivery in your Orders page. Funds will be released to the seller after confirmation.</p>
        <a href="https://sportcardsonline.com/orders" class="btn">Confirm Delivery</a>
      `),
    }),

    orderDelivered: (sellerName: string, orderDetails: { id: string; cardTitle: string; payout: number }) => ({
      subject: `Payment released — ${orderDetails.cardTitle}`,
      html: baseTemplate("Payment Released", `
        <h1>Payment Released! 🏦</h1>
        <p>Hi ${sellerName}, the buyer has confirmed receipt of your card.</p>
        <hr class="divider" />
        <p><span class="highlight">Card:</span> ${orderDetails.cardTitle}</p>
        <p><span class="highlight">Payout:</span> $${orderDetails.payout.toFixed(2)} <span style="color:#475569;font-size:13px">(after 5% platform fee)</span></p>
        <hr class="divider" />
        <p>Your payout has been processed. Thank you for selling on SportCardsOnline!</p>
        <a href="https://sportcardsonline.com/orders" class="btn">View Order History</a>
      `),
    }),

    tradeOffered: (receiverName: string, tradeDetails: { id: string; offererName: string; offeredCards: string[]; requestedCards: string[] }) => ({
      subject: `Trade offer from ${tradeDetails.offererName}`,
      html: baseTemplate("Trade Offer", `
        <h1>You Have a Trade Offer! 🔄</h1>
        <p>Hi ${receiverName}, <span class="highlight">${tradeDetails.offererName}</span> wants to trade with you.</p>
        <hr class="divider" />
        <p><span class="highlight">They're offering:</span></p>
        <ul style="color:#94a3b8;line-height:1.8">${tradeDetails.offeredCards.map(c => `<li>${c}</li>`).join("")}</ul>
        <p><span class="highlight">They want from you:</span></p>
        <ul style="color:#94a3b8;line-height:1.8">${tradeDetails.requestedCards.map(c => `<li>${c}</li>`).join("")}</ul>
        <hr class="divider" />
        <a href="https://sportcardsonline.com/trades" class="btn">Review Trade Offer</a>
      `),
    }),

    tradeAccepted: (offererName: string, tradeDetails: { id: string; receiverName: string }) => ({
      subject: `Trade accepted by ${tradeDetails.receiverName}!`,
      html: baseTemplate("Trade Accepted", `
        <h1>Trade Accepted! ✅</h1>
        <p>Hi ${offererName}, <span class="highlight">${tradeDetails.receiverName}</span> has accepted your trade offer.</p>
        <hr class="divider" />
        <p>Next steps:</p>
        <ol style="color:#94a3b8;line-height:2">
          <li>Ship your cards to the SCO escrow address</li>
          <li>Enter your tracking number in the Trades page</li>
          <li>Once both parties ship, SCO will verify and forward the cards</li>
        </ol>
        <a href="https://sportcardsonline.com/trades" class="btn">View Trade Details</a>
      `),
    }),

    tradeDeclined: (offererName: string, tradeDetails: { receiverName: string }) => ({
      subject: `Trade declined by ${tradeDetails.receiverName}`,
      html: baseTemplate("Trade Declined", `
        <h1>Trade Declined</h1>
        <p>Hi ${offererName}, <span class="highlight">${tradeDetails.receiverName}</span> has declined your trade offer.</p>
        <hr class="divider" />
        <p>Don't give up — browse the Arena to find other cards you might want to trade for.</p>
        <a href="https://sportcardsonline.com/trades" class="btn">Browse Trades</a>
      `),
    }),

    auctionWon: (winnerName: string, auctionDetails: { id: string; cardTitle: string; winningBid: number; sellerName: string }) => ({
      subject: `You won the auction — ${auctionDetails.cardTitle}!`,
      html: baseTemplate("Auction Won!", `
        <h1>You Won the Auction! 🏆</h1>
        <p>Congratulations ${winnerName}! You won the auction for <span class="highlight">${auctionDetails.cardTitle}</span>.</p>
        <hr class="divider" />
        <p><span class="highlight">Winning Bid:</span> $${auctionDetails.winningBid.toFixed(2)}</p>
        <p><span class="highlight">Seller:</span> ${auctionDetails.sellerName}</p>
        <hr class="divider" />
        <p>Complete your purchase to secure your card. The seller will be notified once payment is confirmed.</p>
        <a href="https://sportcardsonline.com/orders" class="btn">Complete Purchase</a>
      `),
    }),

    auctionEnded: (sellerName: string, auctionDetails: { cardTitle: string; winnerName: string; finalBid: number }) => ({
      subject: `Your auction ended — ${auctionDetails.cardTitle}`,
      html: baseTemplate("Auction Ended", `
        <h1>Your Auction Has Ended! 🎯</h1>
        <p>Hi ${sellerName}, your auction for <span class="highlight">${auctionDetails.cardTitle}</span> has ended.</p>
        <hr class="divider" />
        <p><span class="highlight">Winner:</span> ${auctionDetails.winnerName}</p>
        <p><span class="highlight">Final Bid:</span> $${auctionDetails.finalBid.toFixed(2)}</p>
        <p><span class="highlight">Your Payout:</span> $${(auctionDetails.finalBid * 0.9).toFixed(2)} <span style="color:#475569;font-size:13px">(after 10% platform fee)</span></p>
        <hr class="divider" />
        <p>Once the buyer completes payment, you'll receive shipping instructions.</p>
        <a href="https://sportcardsonline.com/orders" class="btn">View Auction Results</a>
      `),
    }),

    cardGraded: (userName: string, gradeDetails: { cardTitle: string; grade: number; certNumber: string }) => ({
      subject: `Your card has been graded — SCG ${gradeDetails.grade}`,
      html: baseTemplate("Card Graded", `
        <h1>Your Card Has Been Graded! 📋</h1>
        <p>Hi ${userName}, your card has received its SCG grade.</p>
        <hr class="divider" />
        <p><span class="highlight">Card:</span> ${gradeDetails.cardTitle}</p>
        <p><span class="highlight">SCG Grade:</span> <span class="badge ${gradeDetails.grade >= 8 ? "status-green" : gradeDetails.grade >= 6 ? "status-orange" : "status-red"}">${gradeDetails.grade}/10</span></p>
        <p><span class="highlight">Cert #:</span> ${gradeDetails.certNumber}</p>
        <hr class="divider" />
        <p>Your card is now in your collection. You can list it on the Arena, add it to auction, or trade it with other collectors.</p>
        <a href="https://sportcardsonline.com/collection" class="btn">View My Collection</a>
      `),
    }),

    contactFormAdmin: (formData: { name: string; email: string; subject: string; message: string; ip?: string }) => ({
      to: ADMIN_EMAIL,
      subject: `[Contact Form] ${formData.subject} — from ${formData.name}`,
      html: baseTemplate("Contact Form Submission", `
        <h1>New Contact Form Submission</h1>
        <hr class="divider" />
        <p><span class="highlight">Name:</span> ${formData.name}</p>
        <p><span class="highlight">Email:</span> <a href="mailto:${formData.email}" style="color:#60a5fa">${formData.email}</a></p>
        <p><span class="highlight">Subject:</span> ${formData.subject}</p>
        ${formData.ip ? `<p><span class="highlight">IP:</span> ${formData.ip}</p>` : ""}
        <hr class="divider" />
        <p><span class="highlight">Message:</span></p>
        <div style="background:#060e1a;border:1px solid #1e3a5f;border-radius:8px;padding:16px;color:#e2e8f0;white-space:pre-wrap">${formData.message}</div>
        <hr class="divider" />
        <p style="color:#475569;font-size:12px">Submitted at ${new Date().toLocaleString()}</p>
      `),
    }),

    contactFormConfirmation: (name: string, subject: string) => ({
      subject: `We received your message — ${subject}`,
      html: baseTemplate("Message Received", `
        <h1>We Got Your Message! 📬</h1>
        <p>Hi ${name}, thanks for reaching out to SportCardsOnline.</p>
        <hr class="divider" />
        <p>We've received your message about <span class="highlight">"${subject}"</span> and will get back to you within <span class="highlight">24–48 hours</span>.</p>
        <hr class="divider" />
        <p>In the meantime, check out our FAQ for quick answers:</p>
        <a href="https://sportcardsonline.com" class="btn">Visit SportCardsOnline</a>
      `),
    }),

    referralSignup: (referrerName: string, newUserName: string, credits: number) => ({
      subject: `${newUserName} signed up using your referral link! +${credits} credits`,
      html: baseTemplate("Referral Bonus!", `
        <h1>Referral Bonus Earned! 🎁</h1>
        <p>Hi ${referrerName}, great news — <span class="highlight">${newUserName}</span> signed up using your referral link!</p>
        <hr class="divider" />
        <p><span class="highlight">Credits Earned:</span> <span class="badge status-green">+${credits} credits</span></p>
        <hr class="divider" />
        <p>Keep sharing your referral link to earn more credits. Every person who signs up earns you credits equal to their plan value!</p>
        <a href="https://sportcardsonline.com/collection" class="btn">View My Credits</a>
      `),
    }),

    // ─── ORDER FLOW (extended) ───────────────────────────────────────────────

    /** T-01: Seller notified of new order with ship-by deadline */
    sellerNewOrder: (sellerName: string, d: { orderId: string; cardTitle: string; buyerName: string; price: number; shipByDeadline: string }) => ({
      subject: `🛒 New Order #${d.orderId} — ${d.cardTitle}`,
      html: baseTemplate("New Order Received", `
        <h1>You Have a New Order! 🛒</h1>
        <p>Hi ${sellerName}, a buyer has purchased one of your cards. Here’s what you need to do next.</p>
        <hr class="divider" />
        <p><span class="highlight">Order #:</span> ${d.orderId}</p>
        <p><span class="highlight">Card:</span> ${d.cardTitle}</p>
        <p><span class="highlight">Buyer:</span> ${d.buyerName}</p>
        <p><span class="highlight">Sale Price:</span> $${d.price.toFixed(2)}</p>
        <p><span class="highlight">Ship By:</span> <span style="color:#fb923c;font-weight:bold">${d.shipByDeadline}</span></p>
        <hr class="divider" />
        <p><strong>Next Steps:</strong></p>
        <ol style="color:#94a3b8;line-height:2">
          <li>Purchase a shipping label (or use your own carrier)</li>
          <li>Enter the tracking number in your order thread</li>
          <li>Ship the card and mark it as shipped in your Orders page</li>
        </ol>
        <a href="https://sportcardsonline.com/orders" class="btn">View Order &amp; Get Shipping Label</a>
        <hr class="divider" />
        <p style="color:#475569;font-size:12px">Funds are held in escrow and released once the buyer confirms receipt.</p>
      `),
    }),

    /** T-02: Seller ship-by deadline reminder (sent 24 hrs before deadline) */
    sellerShipReminder: (sellerName: string, d: { orderId: string; cardTitle: string; deadline: string }) => ({
      subject: `⚠️ Ship Reminder — Order #${d.orderId} due ${d.deadline}`,
      html: baseTemplate("Ship By Reminder", `
        <h1>Shipping Deadline Approaching ⚠️</h1>
        <p>Hi ${sellerName}, your order for <span class="highlight">${d.cardTitle}</span> needs to ship within 24 hours.</p>
        <hr class="divider" />
        <p><span class="highlight">Order #:</span> ${d.orderId}</p>
        <p><span class="highlight">Ship By:</span> <span style="color:#f87171;font-weight:bold">${d.deadline}</span></p>
        <hr class="divider" />
        <p>Please enter your tracking number and mark the order as shipped as soon as possible. Failure to ship on time may result in order cancellation and a seller penalty.</p>
        <a href="https://sportcardsonline.com/orders" class="btn">Enter Tracking Number Now</a>
      `),
    }),

    /** T-03: Buyer notified when seller enters tracking number */
    buyerTrackingAdded: (buyerName: string, d: { orderId: string; cardTitle: string; trackingNumber: string; carrier: string }) => ({
      subject: `📦 Tracking Added — Your ${d.cardTitle} is on its way!`,
      html: baseTemplate("Tracking Number Added", `
        <h1>Your Card Has Been Shipped! 📦</h1>
        <p>Hi ${buyerName}, the seller has added a tracking number for your order.</p>
        <hr class="divider" />
        <p><span class="highlight">Order #:</span> ${d.orderId}</p>
        <p><span class="highlight">Card:</span> ${d.cardTitle}</p>
        <p><span class="highlight">Carrier:</span> ${d.carrier}</p>
        <p><span class="highlight">Tracking #:</span> <span style="color:#60a5fa;font-weight:bold">${d.trackingNumber}</span></p>
        <hr class="divider" />
        <p>Once your card arrives, please log in and <strong>confirm receipt</strong> so we can release payment to the seller.</p>
        <a href="https://sportcardsonline.com/orders" class="btn">Track My Order</a>
      `),
    }),

    /** T-04: Buyer notified when carrier marks delivered */
    buyerCardDelivered: (buyerName: string, d: { orderId: string; cardTitle: string; autoReleaseTime: string }) => ({
      subject: `✅ Delivered — ${d.cardTitle} — Please Confirm Receipt`,
      html: baseTemplate("Card Delivered", `
        <h1>Your Card Has Been Delivered! ✅</h1>
        <p>Hi ${buyerName}, the carrier has marked your order as delivered.</p>
        <hr class="divider" />
        <p><span class="highlight">Order #:</span> ${d.orderId}</p>
        <p><span class="highlight">Card:</span> ${d.cardTitle}</p>
        <hr class="divider" />
        <p>Please inspect your card and <strong>confirm receipt</strong> in your order thread. This releases payment to the seller and closes the order.</p>
        <div style="background:#052e16;border:1px solid #166534;border-radius:8px;padding:16px;margin:16px 0">
          <p style="color:#4ade80;font-weight:bold;margin:0">⏰ Auto-Release Notice</p>
          <p style="color:#86efac;margin:8px 0 0">If we do not hear from you by <strong>${d.autoReleaseTime}</strong>, funds will be automatically released to the seller.</p>
        </div>
        <a href="https://sportcardsonline.com/orders" class="btn">Confirm Receipt Now</a>
        <hr class="divider" />
        <p>If there is an issue with your card, open a dispute before the auto-release time.</p>
      `),
    }),

    /** T-05: 1-hour auto-release warning to buyer */
    buyerAutoReleaseWarning: (buyerName: string, d: { orderId: string; cardTitle: string; releaseTime: string }) => ({
      subject: `⏰ 1 Hour Left — Confirm Receipt or Funds Auto-Release`,
      html: baseTemplate("Auto-Release Warning", `
        <h1>Action Required — 1 Hour Remaining ⏰</h1>
        <p>Hi ${buyerName}, this is your final reminder to confirm receipt of <span class="highlight">${d.cardTitle}</span>.</p>
        <hr class="divider" />
        <p><span class="highlight">Order #:</span> ${d.orderId}</p>
        <p><span class="highlight">Auto-Release At:</span> <span style="color:#f87171;font-weight:bold">${d.releaseTime}</span></p>
        <hr class="divider" />
        <div style="background:#450a0a;border:1px solid #7f1d1d;border-radius:8px;padding:16px;margin:16px 0">
          <p style="color:#f87171;font-weight:bold;margin:0">⚠️ Funds will be automatically released in 1 hour.</p>
          <p style="color:#fca5a5;margin:8px 0 0">If you have not received your card or there is an issue, open a dispute immediately.</p>
        </div>
        <a href="https://sportcardsonline.com/orders" class="btn">Confirm Receipt Now</a>
      `),
    }),

    /** T-06a: Buyer — order complete after receipt confirmed */
    fundsReleasedBuyer: (buyerName: string, d: { orderId: string; cardTitle: string }) => ({
      subject: `🎉 Order Complete — ${d.cardTitle}`,
      html: baseTemplate("Order Complete", `
        <h1>Order Complete! 🎉</h1>
        <p>Hi ${buyerName}, you’ve confirmed receipt of <span class="highlight">${d.cardTitle}</span>. The order is now closed.</p>
        <hr class="divider" />
        <p><span class="highlight">Order #:</span> ${d.orderId}</p>
        <hr class="divider" />
        <p>The card has been added to your collection. Thank you for shopping on SportCardsOnline!</p>
        <a href="https://sportcardsonline.com/collection" class="btn">View My Collection</a>
      `),
    }),

    /** T-06b: Seller — funds released */
    fundsReleasedSeller: (sellerName: string, d: { orderId: string; cardTitle: string; payout: number; releasedBy: string }) => ({
      subject: `💰 Funds Released — Order #${d.orderId}`,
      html: baseTemplate("Funds Released", `
        <h1>Your Payment Has Been Released! 💰</h1>
        <p>Hi ${sellerName}, the escrow funds for your sale have been released.</p>
        <hr class="divider" />
        <p><span class="highlight">Order #:</span> ${d.orderId}</p>
        <p><span class="highlight">Card:</span> ${d.cardTitle}</p>
        <p><span class="highlight">Payout:</span> <span class="badge status-green">$${d.payout.toFixed(2)}</span></p>
        <p><span class="highlight">Released By:</span> ${d.releasedBy}</p>
        <hr class="divider" />
        <p>Funds will appear in your account within 3–5 business days. Thank you for selling on SportCardsOnline!</p>
        <a href="https://sportcardsonline.com/orders" class="btn">View Order History</a>
      `),
    }),

    /** T-07: Admin notified of auto-release */
    adminAutoRelease: (d: { orderId: string; cardTitle: string; buyerEmail: string; sellerEmail: string; payout: number }) => ({
      to: ADMIN_EMAIL,
      subject: `[Auto-Release] Order #${d.orderId} — Funds Released`,
      html: baseTemplate("Auto-Release Fired", `
        <h1>Escrow Auto-Release Fired</h1>
        <p>The 24-hour auto-release timer expired and funds were automatically released for the following order.</p>
        <hr class="divider" />
        <p><span class="highlight">Order #:</span> ${d.orderId}</p>
        <p><span class="highlight">Card:</span> ${d.cardTitle}</p>
        <p><span class="highlight">Buyer:</span> ${d.buyerEmail}</p>
        <p><span class="highlight">Seller:</span> ${d.sellerEmail}</p>
        <p><span class="highlight">Payout:</span> $${d.payout.toFixed(2)}</p>
        <hr class="divider" />
        <p style="color:#475569;font-size:12px">Released at ${new Date().toLocaleString()}</p>
      `),
    }),

    // ─── TRADE FLOW (extended) ─────────────────────────────────────────────

    /** T-08: Counter offer received */
    tradeCounterOffer: (recipientName: string, d: { tradeId: string; senderName: string; message: string }) => ({
      subject: `🔄 Counter Offer on Trade #${d.tradeId} from ${d.senderName}`,
      html: baseTemplate("Counter Offer", `
        <h1>You Received a Counter Offer 🔄</h1>
        <p>Hi ${recipientName}, <span class="highlight">${d.senderName}</span> has sent a counter offer on Trade #${d.tradeId}.</p>
        <hr class="divider" />
        <p><span class="highlight">Their Message:</span></p>
        <div style="background:#060e1a;border:1px solid #1e3a5f;border-radius:8px;padding:16px;color:#e2e8f0">${d.message}</div>
        <hr class="divider" />
        <p>Log in to review the counter offer and accept, decline, or counter back.</p>
        <a href="https://sportcardsonline.com/trades" class="btn">Review Counter Offer</a>
      `),
    }),

    /** T-09: Both agreed — fee due */
    tradeFeeRequired: (recipientName: string, d: { tradeId: string; feeAmount: number; otherPartyName: string }) => ({
      subject: `✅ Trade #${d.tradeId} Agreed — Pay Your Trade Fee to Proceed`,
      html: baseTemplate("Trade Fee Required", `
        <h1>Trade Agreement Reached! ✅</h1>
        <p>Hi ${recipientName}, you and <span class="highlight">${d.otherPartyName}</span> have both agreed to the trade terms.</p>
        <hr class="divider" />
        <p><span class="highlight">Trade #:</span> ${d.tradeId}</p>
        <p><span class="highlight">Trade Fee:</span> <span class="badge status-orange">$${d.feeAmount.toFixed(2)}</span></p>
        <hr class="divider" />
        <p>To proceed, both parties must pay the trade fee. Once both fees are received, you’ll receive shipping instructions.</p>
        <a href="https://sportcardsonline.com/trades" class="btn">Pay Trade Fee Now</a>
        <hr class="divider" />
        <p style="color:#475569;font-size:12px">The trade will be cancelled if fees are not paid within 48 hours.</p>
      `),
    }),

    /** T-10: Both fees paid — ship your card */
    tradeShipInstructions: (recipientName: string, d: { tradeId: string; shipToAddress: string; otherPartyName: string; deadline: string }) => ({
      subject: `📦 Trade #${d.tradeId} — Ship Your Card Now`,
      html: baseTemplate("Ship Your Card", `
        <h1>Both Fees Paid — Time to Ship! 📦</h1>
        <p>Hi ${recipientName}, both trade fees have been received. Please ship your card to the address below.</p>
        <hr class="divider" />
        <p><span class="highlight">Trade #:</span> ${d.tradeId}</p>
        <p><span class="highlight">Ship To:</span></p>
        <div style="background:#060e1a;border:1px solid #1e3a5f;border-radius:8px;padding:16px;color:#e2e8f0;white-space:pre-wrap">${d.shipToAddress}</div>
        <p><span class="highlight">Ship By:</span> <span style="color:#fb923c;font-weight:bold">${d.deadline}</span></p>
        <hr class="divider" />
        <p>Once shipped, enter your tracking number in the trade thread so both parties can track delivery.</p>
        <a href="https://sportcardsonline.com/trades" class="btn">Enter Tracking Number</a>
      `),
    }),

    /** T-11: Card received at SCG */
    tradeCardReceivedSCG: (recipientName: string, d: { tradeId: string; cardTitle: string }) => ({
      subject: `📬 Trade #${d.tradeId} — Card Received at SCG`,
      html: baseTemplate("Card Received", `
        <h1>Card Received at SCG! 📬</h1>
        <p>Hi ${recipientName}, we’ve received <span class="highlight">${d.cardTitle}</span> as part of Trade #${d.tradeId}.</p>
        <hr class="divider" />
        <p>We’ll inspect the card and ship it to the other party. You’ll receive a confirmation once it’s on its way.</p>
        <a href="https://sportcardsonline.com/trades" class="btn">View Trade Status</a>
      `),
    }),

    /** T-12: Trade completed */
    tradeCompleted: (recipientName: string, d: { tradeId: string; receivedCard: string; sentCard: string }) => ({
      subject: `🎉 Trade #${d.tradeId} Complete!`,
      html: baseTemplate("Trade Complete", `
        <h1>Trade Complete! 🎉</h1>
        <p>Hi ${recipientName}, your trade has been successfully completed.</p>
        <hr class="divider" />
        <p><span class="highlight">Trade #:</span> ${d.tradeId}</p>
        <p><span class="highlight">You Sent:</span> ${d.sentCard}</p>
        <p><span class="highlight">You Received:</span> ${d.receivedCard}</p>
        <hr class="divider" />
        <p>The new card has been added to your collection. Thank you for trading on SportCardsOnline!</p>
        <a href="https://sportcardsonline.com/collection" class="btn">View My Collection</a>
      `),
    }),

    // ─── DISPUTE FLOW ─────────────────────────────────────────────────────────

    /** T-13: Dispute opened — sent to buyer, seller, and admin */
    disputeOpened: (recipientName: string, d: { orderId: string; cardTitle: string; openedBy: string; reason: string; isAdmin?: boolean }) => ({
      subject: `🚨 Dispute Opened — Order #${d.orderId}`,
      html: baseTemplate("Dispute Opened", `
        <h1>${d.isAdmin ? "[Admin] " : ""}Dispute Opened on Order #${d.orderId} 🚨</h1>
        <p>Hi ${recipientName}, a dispute has been opened${d.isAdmin ? " by a user" : ""} for the following order.</p>
        <hr class="divider" />
        <p><span class="highlight">Order #:</span> ${d.orderId}</p>
        <p><span class="highlight">Card:</span> ${d.cardTitle}</p>
        <p><span class="highlight">Opened By:</span> ${d.openedBy}</p>
        <p><span class="highlight">Reason:</span></p>
        <div style="background:#060e1a;border:1px solid #7f1d1d;border-radius:8px;padding:16px;color:#fca5a5">${d.reason}</div>
        <hr class="divider" />
        <p>Funds are frozen while the dispute is under review. Our team will reach out within 24 hours.</p>
        <a href="https://sportcardsonline.com/orders" class="btn">View Dispute</a>
      `),
    }),

    /** T-14: Dispute resolved */
    disputeResolved: (recipientName: string, d: { orderId: string; cardTitle: string; resolution: string; outcome: string }) => ({
      subject: `✅ Dispute Resolved — Order #${d.orderId}`,
      html: baseTemplate("Dispute Resolved", `
        <h1>Dispute Resolved ✅</h1>
        <p>Hi ${recipientName}, the dispute for Order #${d.orderId} has been resolved by our team.</p>
        <hr class="divider" />
        <p><span class="highlight">Order #:</span> ${d.orderId}</p>
        <p><span class="highlight">Card:</span> ${d.cardTitle}</p>
        <p><span class="highlight">Resolution:</span></p>
        <div style="background:#052e16;border:1px solid #166534;border-radius:8px;padding:16px;color:#86efac">${d.resolution}</div>
        <p><span class="highlight">Outcome:</span> ${d.outcome}</p>
        <hr class="divider" />
        <a href="https://sportcardsonline.com/orders" class="btn">View Order</a>
      `),
    }),

  };
}

export { ADMIN_EMAIL };
