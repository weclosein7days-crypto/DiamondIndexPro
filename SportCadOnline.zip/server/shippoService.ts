/**
 * Shippo Shipping Label Service
 * Creates USPS Ground Advantage labels for CardVault orders.
 * Uses the Shippo REST API directly (no SDK dependency on types).
 */
import { ENV } from "./_core/env";
import { COMPANY_ADDRESS } from "../shared/const";

export interface ShippoAddress {
  name: string;
  street1: string;
  street2?: string;
  city: string;
  state: string;
  zip: string;
  country: string;
  phone?: string;
  email?: string;
}

// Standard sports card in toploader + bubble mailer
// ~6.5" x 4.5" x 0.5", 2 oz
export const DEFAULT_CARD_PARCEL = {
  weightOz: 2,
  lengthIn: 6.5,
  widthIn: 4.5,
  heightIn: 0.5,
} as const;

export interface CreateLabelInput {
  toAddress: ShippoAddress;
  weightOz?: number;      // weight in ounces (default: 2 oz)
  lengthIn?: number;      // parcel dimensions in inches (default: 6.5")
  widthIn?: number;       // (default: 4.5")
  heightIn?: number;      // (default: 0.5")
  orderId: number;
  cardTitle: string;
  insuredValue?: number;  // declared value for insurance
}

export interface ShippoLabelResult {
  trackingNumber: string;
  carrier: string;
  labelUrl: string;       // PDF label URL
  rate: string;           // cost in USD
  shippoTransactionId: string;
}

const SHIPPO_API = "https://api.goshippo.com";

async function shippoRequest(path: string, method: "GET" | "POST", body?: unknown) {
  const apiKey = ENV.shippoApiKey;
  if (!apiKey) throw new Error("SHIPPO_API_KEY not configured");

  const res = await fetch(`${SHIPPO_API}${path}`, {
    method,
    headers: {
      "Authorization": `ShippoToken ${apiKey}`,
      "Content-Type": "application/json",
    },
    body: body ? JSON.stringify(body) : undefined,
  });

  const data = await res.json() as Record<string, unknown>;
  if (!res.ok) {
    const msg = (data as { detail?: string; message?: string }).detail
      || (data as { detail?: string; message?: string }).message
      || `Shippo API error ${res.status}`;
    throw new Error(msg);
  }
  return data;
}

export async function createShippingLabel(input: CreateLabelInput): Promise<ShippoLabelResult> {
  const fromAddress = {
    name: COMPANY_ADDRESS.name,
    street1: "735 Taylor Road",
    street2: "Suite 220",
    city: COMPANY_ADDRESS.city,
    state: COMPANY_ADDRESS.state,
    zip: COMPANY_ADDRESS.zip,
    country: COMPANY_ADDRESS.country,
  };

  // Create shipment and get rates
  const shipment = await shippoRequest("/shipments/", "POST", {
    address_from: fromAddress,
    address_to: {
      name: input.toAddress.name,
      street1: input.toAddress.street1,
      street2: input.toAddress.street2 || "",
      city: input.toAddress.city,
      state: input.toAddress.state,
      zip: input.toAddress.zip,
      country: input.toAddress.country || "US",
      phone: input.toAddress.phone || "",
      email: input.toAddress.email || "",
    },
    parcels: [{
        length: String(input.lengthIn ?? DEFAULT_CARD_PARCEL.lengthIn),
        width: String(input.widthIn ?? DEFAULT_CARD_PARCEL.widthIn),
        height: String(input.heightIn ?? DEFAULT_CARD_PARCEL.heightIn),
        distance_unit: "in",
        weight: String(input.weightOz ?? DEFAULT_CARD_PARCEL.weightOz),
        mass_unit: "oz",
      }],
    extra: {
      insurance: input.insuredValue
        ? { amount: String(input.insuredValue), currency: "USD", content: input.cardTitle }
        : undefined,
      reference_1: `Order #${input.orderId}`,
    },
    async: false,
  }) as {
    rates: Array<{
      object_id: string;
      servicelevel: { token: string; name: string };
      provider: string;
      amount: string;
    }>;
  };

  const rates = shipment.rates || [];

  // Prefer USPS Ground Advantage, fallback to cheapest USPS, then cheapest overall
  const uspsGroundAdvantage = rates.find(
    (r) => r.servicelevel?.token === "usps_ground_advantage"
  );
  const cheapestUsps = rates
    .filter((r) => r.provider === "USPS")
    .sort((a, b) => parseFloat(a.amount) - parseFloat(b.amount))[0];
  const cheapestOverall = rates
    .sort((a, b) => parseFloat(a.amount) - parseFloat(b.amount))[0];

  const selectedRate = uspsGroundAdvantage || cheapestUsps || cheapestOverall;
  if (!selectedRate) throw new Error("No shipping rates available for this address");

  // Purchase the label
  const transaction = await shippoRequest("/transactions/", "POST", {
    rate: selectedRate.object_id,
    label_file_type: "PDF",
    async: false,
  }) as {
    status: string;
    tracking_number: string;
    label_url: string;
    object_id: string;
    messages?: Array<{ text: string }>;
  };

  if (transaction.status !== "SUCCESS") {
    const errMsg = transaction.messages?.[0]?.text || "Label purchase failed";
    throw new Error(errMsg);
  }

  return {
    trackingNumber: transaction.tracking_number,
    carrier: selectedRate.provider || "USPS",
    labelUrl: transaction.label_url,
    rate: selectedRate.amount,
    shippoTransactionId: transaction.object_id,
  };
}

/**
 * Validate a Shippo address before creating a label.
 * Returns { valid: boolean, messages: string[] }
 */
export async function validateAddress(addr: ShippoAddress): Promise<{ valid: boolean; messages: string[] }> {
  const result = await shippoRequest("/addresses/", "POST", {
    name: addr.name,
    street1: addr.street1,
    street2: addr.street2 || "",
    city: addr.city,
    state: addr.state,
    zip: addr.zip,
    country: addr.country || "US",
    validate: true,
  }) as {
    validation_results?: {
      is_valid: boolean;
      messages?: Array<{ text: string }>;
    };
  };

  const vr = result.validation_results;
  return {
    valid: vr?.is_valid ?? false,
    messages: vr?.messages?.map((m) => m.text) ?? [],
  };
}
