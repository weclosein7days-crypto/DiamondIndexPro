import { COOKIE_NAME } from "@shared/const";
import { eq, or, desc, and, isNotNull } from "drizzle-orm";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { adminRouter } from "./routers/admin";
import { affiliateRouter } from "./routers/affiliate";
import { collectionRouter } from "./routers/collection";
import { imageProcessorRouter } from "./routers/imageProcessor";
import { kidsTriviaRouter } from "./routers/kidsTrivia";
import { kidsCollectionRouter } from "./routers/kidsCollection";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";
import { invokeLLM } from "./_core/llm";
import { storagePut } from "./storage";
import { getMarketPrice } from "./marketPrice";
import { checkEbayAvailability } from "./ebayDropship";
import { sendEmail, emailTemplates } from "./email";
import { notifyOwner } from "./_core/notification";
import { getShippingFee, getShippingLabel } from "../shared/shipping";
import { compReferences, prizeVault, gamePlays, creditAccounts, userCollection, freeCardPlays, disputes } from "../drizzle/schema";
import {
  searchCards,
  getCardsBySellerForTrade,
  searchSellers,
  getActiveCards,
  getCardById,
  getCardsBySellerEmail,
  createCard,
  updateCard,
  deleteCard,
  getCollectionByOwnerEmail,
  getCollectionItemById,
  createCollectionItem,
  updateCollectionItem,
  deleteCollectionItem,
  getActiveAuctions,
  getAuctionById,
  getAuctionsBySellerEmail,
  getActiveAuctionCountBySellerEmail,
  createAuction,
  updateAuction,
  getBidsByAuctionId,
  createBid,
  getOrdersByBuyerEmail,
  getOrdersBySellerEmail,
  getOrderById,
  createOrder,
  updateOrder,
  getTradesByInitiatorEmail,
  getTradesByReceiverEmail,
  getTradeById,
  createTrade,
  updateTrade,
  getMessagesByConversationId,
  createMessage,
  getCreditAccountByEmail,
  createCreditAccount,
  deductCredits,
  addCredits,
  createGradeRequest,
  getStoreByOwnerEmail,
  createStore,
  upsertUser,
  getUserByOpenId,
  getDb,
  getOrderMessages,
  createOrderMessage,
  markOrderMessagesRead,
  getUserCollectionByUserId,
  getUserCollectionCount,
  getUserCollectionStats,
  searchUserCollection,
  toggleFavorite,
  getFavoriteCardIds,
  getFavoriteCards,
  trackUserInterest,
  getTopInterests,
  getPersonalizedCards,
  getTop50Cards,
  getSeasonalPicks,
  getProRookies,
  getHousePicksForUser,
  getUpAndComingCards,
  getShowcaseCards,
} from "./db";
import { TRPCError } from "@trpc/server";
import { listBlogPosts, getBlogPostBySlug } from "./blogEngine";

export const appRouter = router({
  system: systemRouter,
  admin: adminRouter,
  affiliate: affiliateRouter,
  scpCollection: collectionRouter,
  imageProcessor: imageProcessorRouter,
  kidsTrivia: kidsTriviaRouter,
  kidsCollection: kidsCollectionRouter,

  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  // ============================================================================
  // CARDS (MARKETPLACE)
  // ============================================================================
  cards: router({
    list: publicProcedure
      .input(z.object({ limit: z.number().optional(), sport: z.string().optional(), category: z.string().optional(), search: z.string().optional() }).optional())
      .query(async ({ input }) => {
        return getActiveCards(input?.limit || 200, input?.sport, input?.search);
      }),

    getById: publicProcedure.input(z.object({ id: z.number() })).query(async ({ input }) => {
      return getCardById(input.id);
    }),

    myCards: protectedProcedure.query(async ({ ctx }) => {
      return getCardsBySellerEmail(ctx.user.email!);
    }),

    create: protectedProcedure
      .input(
        z.object({
          title: z.string(),
          playerName: z.string(),
          year: z.string().optional(),
          manufacturer: z.string().optional(),
          cardNumber: z.string().optional(),
          setName: z.string().optional(),
          sport: z.enum(["baseball", "basketball", "football", "hockey", "soccer", "other"]),
          condition: z.enum(["raw", "graded"]),
          gradeCompany: z.enum(["PSA", "Beckett", "SGC", "TGA", "CGC", "other", "none"]).optional(),
          gradeScore: z.string().optional(),
          frontImageUrl: z.string().optional(),
          backImageUrl: z.string().optional(),
          price: z.string().optional(),
          description: z.string().optional(),
          category: z.enum(["rookie", "vintage", "modern", "insert", "parallel", "autograph", "memorabilia", "other"]).optional(),
          status: z.enum(["active", "draft"]).optional(),
          aiGrade: z.string().optional(),
          aiGradeLabel: z.string().optional(),
          aiCentering: z.string().optional(),
          aiCorners: z.string().optional(),
          aiEdges: z.string().optional(),
          aiSurface: z.string().optional(),
          aiCertNumber: z.string().optional(),
          showSlabView: z.boolean().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        const store = await getStoreByOwnerEmail(ctx.user.email!);
        return createCard({
          title: input.title,
          playerName: input.playerName,
          year: input.year,
          manufacturer: input.manufacturer,
          cardNumber: input.cardNumber,
          setName: input.setName,
          sport: input.sport,
          condition: input.condition,
          gradeCompany: input.gradeCompany,
          gradeScore: input.gradeScore,
          frontImageUrl: input.frontImageUrl,
          backImageUrl: input.backImageUrl,
          price: input.price,
          description: input.description,
          category: input.category,
          aiGrade: input.aiGrade,
          aiGradeLabel: input.aiGradeLabel,
          aiCentering: input.aiCentering,
          aiCorners: input.aiCorners,
          aiEdges: input.aiEdges,
          aiSurface: input.aiSurface,
          aiCertNumber: input.aiCertNumber,
          showSlabView: input.showSlabView,
          sellerEmail: ctx.user.email!,
          storeName: store?.name || ctx.user.name || "My Store",
          storeId: store?.id,
          status: input.status || "active",
        });
      }),

    update: protectedProcedure
      .input(z.object({ id: z.number(), data: z.record(z.string(), z.any()) }))
      .mutation(async ({ ctx, input }) => {
        const card = await getCardById(input.id);
        const isAdmin = (ctx.user as any).role === "admin";
        if (!card || (!isAdmin && card.sellerEmail !== ctx.user.email!)) {
          throw new TRPCError({ code: "FORBIDDEN" });
        }
        await updateCard(input.id, input.data);
        return { success: true };
      }),

    delete: protectedProcedure.input(z.object({ id: z.number() })).mutation(async ({ ctx, input }) => {
      const card = await getCardById(input.id);
      const isAdmin = (ctx.user as any).role === "admin";
      if (!card || (!isAdmin && card.sellerEmail !== ctx.user.email!)) {
        throw new TRPCError({ code: "FORBIDDEN" });
      }
      await deleteCard(input.id);
      return { success: true };
    }),

    bulkUpdateStatus: protectedProcedure
      .input(z.object({
        ids: z.array(z.number()),
        status: z.enum(["active", "sold", "draft", "auction", "traded", "casino", "bank"]),
      }))
      .mutation(async ({ ctx, input }) => {
        let updated = 0;
        for (const id of input.ids) {
          const card = await getCardById(id);
          if (!card || card.sellerEmail !== ctx.user.email!) continue;
          await updateCard(id, { status: input.status });
          updated++;
        }
        return { success: true, updated };
      }),

    bulkDelete: protectedProcedure
      .input(z.object({ ids: z.array(z.number()) }))
      .mutation(async ({ ctx, input }) => {
        let deleted = 0;
        for (const id of input.ids) {
          const card = await getCardById(id);
          if (!card || card.sellerEmail !== ctx.user.email!) continue;
          await deleteCard(id);
          deleted++;
        }
        return { success: true, deleted };
      }),

    uploadImage: protectedProcedure
      .input(z.object({ base64: z.string(), filename: z.string(), mimeType: z.string() }))
      .mutation(async ({ ctx, input }) => {
        const buffer = Buffer.from(input.base64, "base64");
        const key = `cards/${ctx.user.openId}/${Date.now()}-${input.filename}`;
        const { url } = await storagePut(key, buffer, input.mimeType);
        return { url };
      }),
    search: publicProcedure
      .input(z.object({ search: z.string(), limit: z.number().optional() }))
      .query(async ({ input }) => {
        if (!input.search) return [];
        return searchCards(input.search, input.limit || 20);
      }),
    // ── Curated landing sections ──────────────────────────────────────────────
    top50: publicProcedure.query(async () => getTop50Cards()),
    seasonalPicks: publicProcedure.query(async () => getSeasonalPicks()),
    proRookies: publicProcedure.query(async () => getProRookies()),
    housePicks: publicProcedure
      .input(z.object({ userId: z.number().optional() }).optional())
      .query(async ({ ctx }) => {
        const userId = (ctx.user as any)?.id ?? undefined;
        return getHousePicksForUser(userId);
      }),
    upAndComing: publicProcedure.query(async () => getUpAndComingCards(20)),
    showcase: publicProcedure.query(async () => getShowcaseCards()),
    // Returns all active cards from a specific seller (for trade right panel)
    getBySeller: publicProcedure
      .input(z.object({ sellerEmail: z.string() }))
      .query(async ({ input }) => {
        return getCardsBySellerForTrade(input.sellerEmail);
      }),
    // Search sellers by name/store/card — returns unique sellers with card counts
    searchSellers: publicProcedure
      .input(z.object({ query: z.string() }))
      .query(async ({ input }) => {
        if (!input.query || input.query.length < 2) return [];
        return searchSellers(input.query);
      }),
    // Admin: bulk delete marketplace cards by ID
    adminBulkDelete: protectedProcedure
      .input(z.object({ ids: z.array(z.number()) }))
      .mutation(async ({ ctx, input }) => {
        if ((ctx.user as any).role !== "admin") throw new TRPCError({ code: "FORBIDDEN" });
        let deleted = 0;
        for (const id of input.ids) {
          await deleteCard(id);
          deleted++;
        }
        return { success: true, deleted };
      }),
    // ── Smart Marketplace Rotation ─────────────────────────────────────────────
    // 25% WNBA (house only), 25% NBA, 15% Football, 15% Baseball,
    // 5% Hockey, 5% Soccer, 10% Other — all capped at $500.
    // Rotates daily (date-seeded) and personalizes per returning visitor.
    getFeatured: publicProcedure
      .input(z.object({ visitorKey: z.string().optional() }).optional())
      .query(async ({ ctx, input }) => {
        const { getFeaturedCards } = await import("./db");
        const userId = (ctx.user as any)?.id;
        const key = userId ? String(userId) : input?.visitorKey;
        return getFeaturedCards(key);
      }),
    // Record a visitor search term for personalization
    recordSearch: publicProcedure
      .input(z.object({
        visitorKey: z.string(),
        query: z.string(),
        sport: z.string().optional(),
        playerName: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const { recordVisitorSearch } = await import("./db");
        const isLoggedIn = !!ctx.user;
        await recordVisitorSearch(
          input.visitorKey,
          input.query,
          input.sport,
          input.playerName,
          isLoggedIn
        );
        return { success: true };
      }),
  }),

  // ============================================================================
  // COLLECTION
  // ============================================================================
  collection: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      return getCollectionByOwnerEmail(ctx.user.email!);
    }),

    getById: protectedProcedure.input(z.object({ id: z.number() })).query(async ({ ctx, input }) => {
      const item = await getCollectionItemById(input.id);
      if (!item || item.ownerEmail !== ctx.user.email!) {
        throw new TRPCError({ code: "FORBIDDEN" });
      }
      return item;
    }),

    add: protectedProcedure
      .input(
        z.object({
          cardTitle: z.string(),
          playerName: z.string(),
          year: z.string().optional(),
          setName: z.string().optional(),
          cardNumber: z.string().optional(),
          sport: z.enum(["baseball", "basketball", "football", "hockey", "soccer", "other"]),
          frontImageUrl: z.string().optional(),
          backImageUrl: z.string().optional(),
          overallGrade: z.string().optional(),
          gradeLabel: z.string().optional(),
          centeringScore: z.string().optional(),
          cornersScore: z.string().optional(),
          edgesScore: z.string().optional(),
          surfaceScore: z.string().optional(),
          estimatedValueLow: z.string().optional(),
          estimatedValueHigh: z.string().optional(),
          certNumber: z.string().optional(),
          description: z.string().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        const item = await createCollectionItem({
          ...input,
          ownerEmail: ctx.user.email!,
        });
        const { createCardEvent } = await import("./db");
        await createCardEvent({
          collectionItemId: item.id,
          userEmail: ctx.user.email!,
          eventType: "added",
          description: `Card added to collection: ${input.cardTitle} (${input.playerName})`,
          metadata: { grade: input.overallGrade, gradeLabel: input.gradeLabel, certNumber: input.certNumber },
        });
        return item;
      }),

    update: protectedProcedure
      .input(
        z.object({
          id: z.number(),
          extraImageUrls: z.array(z.string()).optional(),
          labelColor: z.enum(["dark", "ruby", "light", "silver", "nightlife", "red", "black", "none"]).optional(),
          labelBg: z.string().optional(),
          labelBorder: z.string().optional(),
          labelMode: z.enum(["with_label", "no_label"]).optional(),
          description: z.string().optional(),
          cardTitle: z.string().optional(),
          playerName: z.string().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        const item = await getCollectionItemById(input.id);
        if (!item || item.ownerEmail !== ctx.user.email!) {
          throw new TRPCError({ code: "FORBIDDEN" });
        }
        const { id, ...data } = input;
        return updateCollectionItem(id, data as any);
      }),

    bulkDelete: protectedProcedure
      .input(z.object({ ids: z.array(z.number()) }))
      .mutation(async ({ ctx, input }) => {
        for (const id of input.ids) {
          const item = await getCollectionItemById(id);
          if (item && item.ownerEmail === ctx.user.email!) {
            await deleteCollectionItem(id);
          }
        }
        return { success: true, count: input.ids.length };
      }),

    bulkListToArena: protectedProcedure
      .input(z.object({ ids: z.array(z.number()), price: z.string() }))
      .mutation(async ({ ctx, input }) => {
        const store = await getStoreByOwnerEmail(ctx.user.email!);
        const results = [];
        for (const collectionId of input.ids) {
          const item = await getCollectionItemById(collectionId);
          if (!item || item.ownerEmail !== ctx.user.email!) continue;
          const card = await createCard({
            title: item.cardTitle,
            playerName: item.playerName,
            year: item.year || undefined,
            setName: item.setName || undefined,
            cardNumber: item.cardNumber || undefined,
            sport: item.sport,
            condition: "graded",
            frontImageUrl: item.frontImageUrl || undefined,
            backImageUrl: item.backImageUrl || undefined,
            extraImageUrls: item.extraImageUrls || undefined,
            price: input.price,
            description: item.description || undefined,
            sellerEmail: ctx.user.email!,
            storeName: store?.name || ctx.user.name || "My Store",
            storeId: store?.id,
            status: "active",
            aiGrade: item.overallGrade || undefined,
            aiGradeLabel: item.gradeLabel || undefined,
            aiCentering: item.centeringScore || undefined,
            aiCorners: item.cornersScore || undefined,
            aiEdges: item.edgesScore || undefined,
            aiSurface: item.surfaceScore || undefined,
            aiCertNumber: item.certNumber || undefined,
            showSlabView: true,
          });
          results.push(card);
        }
        return { success: true, count: results.length };
      }),

    delete: protectedProcedure.input(z.object({ id: z.number() })).mutation(async ({ ctx, input }) => {
      const item = await getCollectionItemById(input.id);
      if (!item || item.ownerEmail !== ctx.user.email!) {
        throw new TRPCError({ code: "FORBIDDEN" });
      }
      await deleteCollectionItem(input.id);
      return { success: true };
    }),

    getEvents: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ ctx, input }) => {
        const item = await getCollectionItemById(input.id);
        if (!item || item.ownerEmail !== ctx.user.email!) {
          throw new TRPCError({ code: "FORBIDDEN" });
        }
        const { getCardEvents } = await import("./db");
        return getCardEvents(input.id);
      }),

    addNote: protectedProcedure
      .input(z.object({ id: z.number(), note: z.string().min(1).max(500) }))
      .mutation(async ({ ctx, input }) => {
        const item = await getCollectionItemById(input.id);
        if (!item || item.ownerEmail !== ctx.user.email!) {
          throw new TRPCError({ code: "FORBIDDEN" });
        }
        const { createCardEvent } = await import("./db");
        await createCardEvent({
          collectionItemId: input.id,
          userEmail: ctx.user.email!,
          eventType: "note_added",
          description: input.note,
        });
        return { success: true };
      }),

    listToArena: protectedProcedure
      .input(z.object({ collectionId: z.number(), price: z.string(), description: z.string().optional() }))
      .mutation(async ({ ctx, input }) => {
        const item = await getCollectionItemById(input.collectionId);
        if (!item || item.ownerEmail !== ctx.user.email!) {
          throw new TRPCError({ code: "FORBIDDEN" });
        }
        const store = await getStoreByOwnerEmail(ctx.user.email!);
        const card = await createCard({
          title: item.cardTitle,
          playerName: item.playerName,
          year: item.year || undefined,
          setName: item.setName || undefined,
          cardNumber: item.cardNumber || undefined,
          sport: item.sport,
          condition: "graded",
          frontImageUrl: item.frontImageUrl || undefined,
          backImageUrl: item.backImageUrl || undefined,
          price: input.price,
          description: input.description || item.description || undefined,
          sellerEmail: ctx.user.email!,
          storeName: store?.name || ctx.user.name || "My Store",
          storeId: store?.id,
          status: "active",
          aiGrade: item.overallGrade || undefined,
          aiGradeLabel: item.gradeLabel || undefined,
          aiCentering: item.centeringScore || undefined,
          aiCorners: item.cornersScore || undefined,
          aiEdges: item.edgesScore || undefined,
          aiSurface: item.surfaceScore || undefined,
          aiCertNumber: item.certNumber || undefined,
          showSlabView: true,
        });
        // Fire lifecycle event
        const { createCardEvent: _createEvt } = await import("./db");
        await _createEvt({
          collectionItemId: input.collectionId,
          userEmail: ctx.user.email!,
          eventType: "listed",
          description: `Listed in the Arena for $${input.price}`,
          metadata: { cardId: card.id, price: input.price },
        });
        return card;
      }),
  }),

  // ============================================================================
  // GRADING
  // ============================================================================
  grading: router({
    gradeCard: protectedProcedure
      .input(
        z.object({
          frontImageUrl: z.string(),
          backImageUrl: z.string(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        // Check credits
        const account = await getCreditAccountByEmail(ctx.user.email!);
        if (!account || account.credits < 2) {
          throw new TRPCError({ code: "FORBIDDEN", message: "Insufficient credits. You need 2 credits to grade a card." });
        }

        // Call AI grading
        const selfReportedIssues = (input as any).selfReportedIssues || "";
        const response = await invokeLLM({
          messages: [
            {
              role: "system",
              content: `You are SCG (Sport Cards Grading), an expert sports card grading service. Your grading philosophy is a collective standard derived from PSA, Beckett (BGS), and SGC grading systems, applied fairly and consistently.

=== SCG GRADING PHILOSOPHY ===

OUR CORE PRINCIPLE: "If a card passes the eye test — looks great, centering is decent, corners are solid, no obvious damage — it deserves a high grade. We do not manufacture reasons to lower a grade."

DISCLAIMER: We grade cards AS SHOWN in the images provided. If a collector reports a known issue (bent corner, scratch, crease, etc.), we factor that in. We cannot grade defects we cannot see.

=== WHAT WE NEVER PENALIZE ===
- Chrome, holographic, refractor, prizm, or mirrored finishes — these are MANUFACTURING FEATURES, not defects
- Glare, shine, or reflective surfaces in photos — this is LIGHTING, not card damage
- Slight variations in finish or texture that are part of the card design
- Minor print dots or rosette patterns visible under magnification (common in all cards)
- Natural card stock texture

=== CENTERING STANDARDS (PSA/BGS/SGC Collective) ===
Grade 10 (Gem Mint): 55/45 or better on front; 75/25 or better on back
Grade 9 (Mint): 60/40 or better on front; 80/20 or better on back  
Grade 8 (NM-MT): 65/35 or better
Grade 7 (Near Mint): 70/30 or better
Grade 6 and below: More significant off-centering
IMPORTANT: Estimate centering visually. Slight off-center is acceptable at high grades.

=== CORNERS STANDARDS ===
Grade 10: All four corners appear sharp and fresh under normal viewing. No fraying, bending, or wear visible.
Grade 9: Corners appear sharp. Very minor imperfection allowed on ONE corner only.
Grade 8: Slight wear on up to two corners. No bending or fraying.
Grade 7: Light wear on corners. Still presentable.
Grade 6 and below: Obvious corner wear, fraying, or bending.
IMPORTANT: Only penalize for ACTUAL physical damage — not for the angle of the photo or lighting shadows.

=== EDGES STANDARDS ===
Grade 10: All four edges appear clean and straight with no nicks or chipping.
Grade 9: Edges are clean. Very minor imperfection on one edge allowed.
Grade 8: Slight roughness on one or two edges. No major nicks.
Grade 7: Light edge wear. Card still looks good overall.
IMPORTANT: Do not penalize for slight roughness that is part of the card's cut. Only penalize for obvious nicks, chips, or fraying.

=== SURFACE STANDARDS ===
Grade 10: Surface is clean and free of scratches, stains, creases, or print defects. Gloss is intact.
Grade 9: Surface is clean. Very minor surface flaw allowed (tiny scratch visible only at certain angles).
Grade 8: Minor surface wear. No creases, stains, or significant scratches.
Grade 7: Light surface wear. Card still presents well.
Grade 6 and below: Obvious surface issues — scratches, stains, creases, or print defects.
IMPORTANT: NEVER penalize for shine, glare, or reflective surfaces. These are NOT surface defects.

=== OVERALL GRADE CALCULATION ===
The overall grade is NOT a simple average. Apply the "eye test" first:
1. Does the card look great overall? If yes, start at 9-10.
2. Check each category — only DROP the grade if there is CLEAR, VISIBLE evidence of damage.
3. A card with 10/10/10/9 scores should grade 9.5 or 10, NOT 9.75 rounded down.
4. Be GENEROUS: if you are unsure whether something is a defect or a feature, assume it is a feature.
5. A card that passes the eye test with no major issues should receive at minimum an 8.

GRADE LABELS:
10.0 = Gem Mint (perfect or near-perfect in all categories)
9.5 = Mint+ (exceptional, one very minor flaw)
9.0 = Mint (excellent condition, minor imperfection)
8.5 = Near Mint-Mint+ 
8.0 = Near Mint-Mint (above average, slight wear)
7.0 = Near Mint (light wear, still attractive)
6.0 = Excellent-Mint
5.0 = Excellent
4.0 = Very Good-Excellent
3.0 = Very Good
2.0 = Good
1.0 = Fair
0.5 = Poor

=== SELF-REPORTED ISSUES ===
If the collector has reported known issues, factor them in. Otherwise, grade only what you can see.

Return a JSON object with these exact fields:
{
  "player_name": "string",
  "year": "string",
  "set_name": "string",
  "card_number": "string",
  "manufacturer": "string",
  "sport": "baseball|basketball|football|hockey|soccer|other",
  "centering_score": number (0-10, use 0.5 increments),
  "corners_score": number (0-10, use 0.5 increments),
  "edges_score": number (0-10, use 0.5 increments),
  "surface_score": number (0-10, use 0.5 increments),
  "overall_grade": number (0-10, use 0.5 increments),
  "grade_label": "Gem Mint|Mint+|Mint|Near Mint-Mint+|Near Mint-Mint|Near Mint|Excellent-Mint|Excellent|Very Good-Excellent|Very Good|Good|Fair|Poor",
  "is_ungradeable": boolean,
  "estimated_value_low": number,
  "estimated_value_high": number,
  "notes": "string (brief explanation of grade, mention what was good and what, if anything, caused any deductions)"
}`,
            },
            {
              role: "user",
              content: [
                { type: "text", text: `Please grade this sports card using SCG standards.${selfReportedIssues ? " Collector-reported issues: " + selfReportedIssues : ""} Here is the front:` },
                { type: "image_url", image_url: { url: input.frontImageUrl, detail: "high" } },
                { type: "text", text: "And here is the back:" },
                { type: "image_url", image_url: { url: input.backImageUrl, detail: "high" } },
              ],
            },
          ],
          response_format: {
            type: "json_schema",
            json_schema: {
              name: "card_grade",
              strict: true,
              schema: {
                type: "object",
                properties: {
                  player_name: { type: "string" },
                  year: { type: "string" },
                  set_name: { type: "string" },
                  card_number: { type: "string" },
                  manufacturer: { type: "string" },
                  sport: { type: "string" },
                  centering_score: { type: "number" },
                  corners_score: { type: "number" },
                  edges_score: { type: "number" },
                  surface_score: { type: "number" },
                  overall_grade: { type: "number" },
                  grade_label: { type: "string" },
                  is_ungradeable: { type: "boolean" },
                  estimated_value_low: { type: "number" },
                  estimated_value_high: { type: "number" },
                  notes: { type: "string" },
                },
                required: ["player_name", "year", "set_name", "card_number", "manufacturer", "sport", "centering_score", "corners_score", "edges_score", "surface_score", "overall_grade", "grade_label", "is_ungradeable", "estimated_value_low", "estimated_value_high", "notes"],
                additionalProperties: false,
              },
            },
          },
        });

        const messageContent = response.choices[0]?.message?.content;
        if (!messageContent || typeof messageContent !== "string") throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "AI grading failed" });

        const gradeData = JSON.parse(messageContent);

        // Deduct 1 credit
          await deductCredits(ctx.user.email!, 2, "AI card grading (2 credits)");

        // Generate cert number
        const certNumber = `SCG-${Date.now().toString(36).toUpperCase()}`;

        // Save grade request
        await createGradeRequest({
          frontImageUrl: input.frontImageUrl,
          backImageUrl: input.backImageUrl,
          requesterEmail: ctx.user.email!,
          aiGradeEstimate: gradeData.overall_grade.toString(),
          centeringScore: gradeData.centering_score.toString(),
          cornersScore: gradeData.corners_score.toString(),
          edgesScore: gradeData.edges_score.toString(),
          surfaceScore: gradeData.surface_score.toString(),
          estimatedValueLow: gradeData.estimated_value_low.toString(),
          estimatedValueHigh: gradeData.estimated_value_high.toString(),
          status: "completed",
        });

        // Auto-save to Collection CRM (no manual step required)
        const cardTitle = [gradeData.year, gradeData.manufacturer, gradeData.set_name, gradeData.player_name].filter(Boolean).join(" ") || gradeData.player_name || "Graded Card";

        // ── Auto-price from market data (eBay + SCP + Beckett) ──────────────────
        let suggestedPrice: string | undefined;
        let marketPriceData: Awaited<ReturnType<typeof getMarketPrice>> | undefined;
        try {
          const priceQuery = `${gradeData.player_name} ${gradeData.year || ""} ${gradeData.set_name || ""}`.trim();
          marketPriceData = await getMarketPrice(priceQuery, gradeData.is_ungradeable ? null : gradeData.overall_grade);
          if (marketPriceData.suggestedPrice) {
            suggestedPrice = marketPriceData.suggestedPrice.toFixed(2);
          }
        } catch (e) {
          console.warn("[gradeCard] Market price lookup failed:", e);
        }

        const collectionItem = await createCollectionItem({
          ownerEmail: ctx.user.email!,
          cardTitle,
          playerName: gradeData.player_name || "Unknown",
          year: gradeData.year || undefined,
          setName: gradeData.set_name || undefined,
          cardNumber: gradeData.card_number || undefined,
          sport: (gradeData.sport as any) || "baseball",
          frontImageUrl: input.frontImageUrl,
          backImageUrl: input.backImageUrl,
          overallGrade: gradeData.overall_grade.toString(),
          gradeLabel: gradeData.grade_label,
          centeringScore: gradeData.centering_score.toString(),
          cornersScore: gradeData.corners_score.toString(),
          edgesScore: gradeData.edges_score.toString(),
          surfaceScore: gradeData.surface_score.toString(),
          certNumber,
          estimatedValueLow: suggestedPrice || gradeData.estimated_value_low.toString(),
          estimatedValueHigh: suggestedPrice || gradeData.estimated_value_high.toString(),
          listingStatus: "none",
          lifecycleNote: `SCG graded — ${gradeData.grade_label} (${gradeData.overall_grade})${suggestedPrice ? ` · Market price: $${suggestedPrice}` : ""}`,
        });

        return {
          ...gradeData,
          cert_number: certNumber,
          collection_item_id: collectionItem.id,
          suggested_price: suggestedPrice ? parseFloat(suggestedPrice) : null,
          market_price_data: marketPriceData ? {
            marketAvg: marketPriceData.marketAvg,
            sources: marketPriceData.sources,
            multiplier: marketPriceData.multiplier,
            gradeCategory: marketPriceData.gradeCategory,
          } : null,
        };
      }),

    saveToCollection: protectedProcedure
      .input(
        z.object({
          cardTitle: z.string(),
          playerName: z.string(),
          year: z.string().optional(),
          setName: z.string().optional(),
          cardNumber: z.string().optional(),
          sport: z.enum(["baseball", "basketball", "football", "hockey", "soccer", "other"]),
          frontImageUrl: z.string(),
          backImageUrl: z.string(),
          overallGrade: z.string(),
          gradeLabel: z.string(),
          centeringScore: z.string(),
          cornersScore: z.string(),
          edgesScore: z.string(),
          surfaceScore: z.string(),
          estimatedValueLow: z.string().optional(),
          estimatedValueHigh: z.string().optional(),
          certNumber: z.string(),
          labelBg: z.string().optional(),
          labelBorder: z.string().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        return createCollectionItem({
          ...input,
          ownerEmail: ctx.user.email!,
        });
      }),

    /** Fetch suggested market price for a card (eBay + SCP + Beckett avg × grade multiplier) */
    getMarketPrice: protectedProcedure
      .input(z.object({
        query: z.string(),   // "Player Year Set"
        grade: z.number().nullable(), // numeric grade or null for raw
      }))
      .query(async ({ input }) => {
        return getMarketPrice(input.query, input.grade);
      }),
  }),

  // ============================================================================
  // USER COLLECTION (imported from Sports Cards Pro)
  // ============================================================================
  userCollection: router({
    list: protectedProcedure
      .input(z.object({ limit: z.number().optional(), offset: z.number().optional() }).optional())
      .query(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) return [];
        const user = await getUserByOpenId(ctx.user.openId!);
        if (!user) return [];
        return getUserCollectionByUserId(user.id, input?.limit || 200, input?.offset || 0);
      }),
    stats: protectedProcedure.query(async ({ ctx }) => {
      const db = await getDb();
      if (!db) return { totalCards: 0, totalValue: 0, totalCost: 0 };
      const user = await getUserByOpenId(ctx.user.openId!);
      if (!user) return { totalCards: 0, totalValue: 0, totalCost: 0 };
      return getUserCollectionStats(user.id);
    }),
    search: protectedProcedure
      .input(z.object({ query: z.string() }))
      .query(async ({ ctx, input }) => {
        if (!input.query || input.query.length < 2) return [];
        const user = await getUserByOpenId(ctx.user.openId!);
        if (!user) return [];
        return searchUserCollection(user.id, input.query);
      }),
    count: protectedProcedure.query(async ({ ctx }) => {
      const user = await getUserByOpenId(ctx.user.openId!);
      if (!user) return 0;
      return getUserCollectionCount(user.id);
    }),
  }),

  // ============================================================================
  // AUCTIONS
  // ============================================================================
  auctions: router({
    list: publicProcedure.query(async () => {
      return getActiveAuctions(50);
    }),

    getById: publicProcedure.input(z.object({ id: z.number() })).query(async ({ input }) => {
      return getAuctionById(input.id);
    }),

    myAuctions: protectedProcedure.query(async ({ ctx }) => {
      return getAuctionsBySellerEmail(ctx.user.email!);
    }),

    create: protectedProcedure
      .input(
        z.object({
          cardId: z.number(),
          cardTitle: z.string(),
          cardImageUrl: z.string().optional(),
          startingPrice: z.string(),
          durationDays: z.number().optional(), // ignored — always 3 days
          playerName: z.string().optional(),
          gradeInfo: z.string().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        // Check max active auctions (max 10 per user)
        const activeCount = await getActiveAuctionCountBySellerEmail(ctx.user.email!);
        if (activeCount >= 10) {
          throw new TRPCError({ code: "FORBIDDEN", message: "Maximum 10 active auctions allowed at once." });
        }

        // Flat 1 credit fee for 3-day auction
        const creditsNeeded = 1;
        const deducted = await deductCredits(ctx.user.email!, creditsNeeded, "Auction listing (3 days — 1 credit)");
        if (!deducted) {
          throw new TRPCError({ code: "FORBIDDEN", message: "Insufficient credits. You need 1 credit to list an auction." });
        }

        // Mark card as in auction
        await updateCard(input.cardId, { status: "auction" });

        const store = await getStoreByOwnerEmail(ctx.user.email!);
        const endTime = new Date(Date.now() + 3 * 24 * 60 * 60 * 1000); // always 3 days

        // Always persist image on the auction row so it survives card deletion
        let resolvedImageUrl = input.cardImageUrl;
        if (!resolvedImageUrl) {
          const cardRow = await getCardById(input.cardId);
          resolvedImageUrl = cardRow?.frontImageUrl ?? undefined;
        }

        const newAuction = await createAuction({
          cardId: input.cardId,
          cardTitle: input.cardTitle,
          cardImageUrl: resolvedImageUrl,
          sellerEmail: ctx.user.email!,
          storeName: store?.name || ctx.user.name || "My Store",
          startingPrice: input.startingPrice,
          currentBid: "0.00",
          durationDays: 3,
          listingCreditsPaid: creditsNeeded,
          endTime,
          playerName: input.playerName,
          gradeInfo: input.gradeInfo,
        });
        // Log auction start to card history
        const { createCardEvent: logAuctionEvent } = await import("./db");
        await logAuctionEvent({
          cardId: input.cardId,
          userEmail: ctx.user.email!,
          eventType: "auction_started",
          description: `Listed for auction at $${input.startingPrice} starting bid (3 days)`,
          metadata: { auctionId: newAuction.id, startingPrice: input.startingPrice, durationDays: 3, endTime: endTime.toISOString() },
        });
        return newAuction;
      }),

    placeBid: protectedProcedure
      .input(z.object({ auctionId: z.number(), bidAmount: z.string() }))
      .mutation(async ({ ctx, input }) => {
        const auction = await getAuctionById(input.auctionId);
        if (!auction || auction.status !== "active") {
          throw new TRPCError({ code: "NOT_FOUND", message: "Auction not found or has ended." });
        }
        if (auction.sellerEmail === ctx.user.email!) {
          throw new TRPCError({ code: "FORBIDDEN", message: "You cannot bid on your own auction." });
        }

        const bidAmount = parseFloat(input.bidAmount);
        const currentBid = parseFloat(auction.currentBid || "0");
        const startingPrice = parseFloat(auction.startingPrice);
        const minBid = Math.max(startingPrice, currentBid > 0 ? currentBid + Math.max(1, currentBid * 0.05) : startingPrice);

        if (bidAmount < minBid) {
          throw new TRPCError({ code: "BAD_REQUEST", message: `Minimum bid is $${minBid.toFixed(2)}` });
        }

        await createBid({
          auctionId: input.auctionId,
          bidderEmail: ctx.user.email!,
          bidderName: ctx.user.name || undefined,
          bidAmount: input.bidAmount,
        });

        await updateAuction(input.auctionId, {
          currentBid: input.bidAmount,
          highestBidderEmail: ctx.user.email!,
          highestBidderName: ctx.user.name || undefined,
          bidCount: (auction.bidCount || 0) + 1,
        });

        return { success: true };
      }),

    getBids: publicProcedure.input(z.object({ auctionId: z.number() })).query(async ({ input }) => {
      return getBidsByAuctionId(input.auctionId);
    }),

    /** Renew an ended auction for 1 credit — extends by 3 more days */
    renew: protectedProcedure
      .input(z.object({ auctionId: z.number() }))
      .mutation(async ({ ctx, input }) => {
        const auction = await getAuctionById(input.auctionId);
        if (!auction) throw new TRPCError({ code: "NOT_FOUND", message: "Auction not found." });
        if (auction.sellerEmail !== ctx.user.email!) throw new TRPCError({ code: "FORBIDDEN" });
        if (auction.status === "active") throw new TRPCError({ code: "BAD_REQUEST", message: "Auction is still active." });

        // Check max active auctions
        const activeCount = await getActiveAuctionCountBySellerEmail(ctx.user.email!);
        if (activeCount >= 10) throw new TRPCError({ code: "FORBIDDEN", message: "Maximum 10 active auctions allowed at once." });

        const deducted = await deductCredits(ctx.user.email!, 1, `Auction renewal #${input.auctionId} (3 days)`);
        if (!deducted) throw new TRPCError({ code: "FORBIDDEN", message: "Insufficient credits. You need 1 credit to renew an auction." });

        const newEndTime = new Date(Date.now() + 3 * 24 * 60 * 60 * 1000);
        await updateAuction(input.auctionId, {
          status: "active",
          endTime: newEndTime,
          currentBid: "0.00",
          highestBidderEmail: null,
          highestBidderName: null,
          bidCount: 0,
        });
        await updateCard(auction.cardId, { status: "auction" });
        return { success: true, newEndTime };
      }),

    adminDelete: protectedProcedure
      .input(z.object({ auctionId: z.number() }))
      .mutation(async ({ ctx, input }) => {
        if ((ctx.user as any).role !== "admin") throw new TRPCError({ code: "FORBIDDEN" });
        const auction = await getAuctionById(input.auctionId);
        if (!auction) throw new TRPCError({ code: "NOT_FOUND" });
        // Cancel the auction record and delete the underlying card
        await updateAuction(input.auctionId, { status: "cancelled" });
        if (auction.cardId) {
          await deleteCard(auction.cardId);
        }
        return { success: true };
      }),
    adminBulkDelete: protectedProcedure
      .input(z.object({ auctionIds: z.array(z.number()) }))
      .mutation(async ({ ctx, input }) => {
        if ((ctx.user as any).role !== "admin") throw new TRPCError({ code: "FORBIDDEN" });
        let deleted = 0;
        for (const auctionId of input.auctionIds) {
          const auction = await getAuctionById(auctionId);
          if (!auction) continue;
          await updateAuction(auctionId, { status: "cancelled" });
          if (auction.cardId) {
            await deleteCard(auction.cardId);
          }
          deleted++;
        }
        return { success: true, deleted };
      }),
  }),
  // ============================================================================
  // ORDERS
  // ============================================================================
  orders: router({
    myPurchases: protectedProcedure.query(async ({ ctx }) => {
      return getOrdersByBuyerEmail(ctx.user.email!);
    }),

    myBuyerOrders: protectedProcedure.query(async ({ ctx }) => {
      return getOrdersByBuyerEmail(ctx.user.email!);
    }),

    mySales: protectedProcedure.query(async ({ ctx }) => {
      return getOrdersBySellerEmail(ctx.user.email!);
    }),

    mySellerOrders: protectedProcedure.query(async ({ ctx }) => {
      return getOrdersBySellerEmail(ctx.user.email!);
    }),

    getById: protectedProcedure.input(z.object({ id: z.number() })).query(async ({ ctx, input }) => {
      const order = await getOrderById(input.id);
      if (!order || (order.buyerEmail !== ctx.user.email! && order.sellerEmail !== ctx.user.email!)) {
        throw new TRPCError({ code: "FORBIDDEN" });
      }
      return order;
    }),

    create: protectedProcedure
      .input(
        z.object({
          cardId: z.number(),
          cardTitle: z.string(),
          cardImageUrl: z.string().optional(),
          sellerEmail: z.string(),
          sellerStoreName: z.string().optional(),
          price: z.string(),
          shippingAddress: z.string().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        const price = parseFloat(input.price);
        const platformFee = Math.max(1.5, price * 0.05);
        const sellerPayout = price - platformFee;

        const order = await createOrder({
          cardId: input.cardId,
          cardTitle: input.cardTitle,
          cardImageUrl: input.cardImageUrl,
          buyerEmail: ctx.user.email!,
          buyerName: ctx.user.name || undefined,
          sellerEmail: input.sellerEmail,
          sellerStoreName: input.sellerStoreName,
          price: input.price,
          totalAmount: price.toFixed(2),
          platformFee: platformFee.toFixed(2),
          sellerPayout: sellerPayout.toFixed(2),
          status: "paid",
          shippingAddress: input.shippingAddress,
        });

        // Mark card as sold
        await updateCard(input.cardId, { status: "sold" });
        // Send confirmation emails (fire-and-forget)
        const tmpl = emailTemplates();
        const buyerTmpl = tmpl.orderPlaced(ctx.user.name || "Collector", {
          id: String(order.id),
          cardTitle: input.cardTitle,
          price: parseFloat(input.price),
          sellerName: input.sellerStoreName || input.sellerEmail,
        });
        sendEmail({ to: ctx.user.email!, ...buyerTmpl }).catch(() => {});
        const sellerTmpl = tmpl.orderSold(input.sellerEmail, {
          id: String(order.id),
          cardTitle: input.cardTitle,
          price: parseFloat(input.price),
          buyerName: ctx.user.name || ctx.user.email!,
        });
        sendEmail({ to: input.sellerEmail, ...sellerTmpl }).catch(() => {});
        return order;
      }),

    addTracking: protectedProcedure
      .input(z.object({ orderId: z.number(), trackingNumber: z.string(), shippingMethod: z.enum(["usps_first_class", "usps_priority", "ups_ground", "ups_2day", "ups_next_day"]).optional() }))
      .mutation(async ({ ctx, input }) => {
        const order = await getOrderById(input.orderId);
        if (!order || order.sellerEmail !== ctx.user.email!) {
          throw new TRPCError({ code: "FORBIDDEN" });
        }
        await updateOrder(input.orderId, {
          trackingNumber: input.trackingNumber,
          shippingMethod: input.shippingMethod,
          status: "shipped",
        });
        // In-app message to buyer
        await createOrderMessage({ orderId: input.orderId, senderEmail: "system", senderName: "SportCardsOnline", senderRole: "system", messageText: `Seller has shipped your card. Tracking: ${input.trackingNumber} via ${input.shippingMethod || "carrier"}. Please confirm receipt once it arrives.` });
        // Email buyer: tracking added
        const shipTmpl = emailTemplates().buyerTrackingAdded(order.buyerEmail, {
          orderId: String(order.id),
          cardTitle: order.cardTitle || "Card",
          trackingNumber: input.trackingNumber,
          carrier: input.shippingMethod || "Carrier",
        });
        sendEmail({ to: order.buyerEmail, ...shipTmpl }).catch(() => {});
        return { success: true };
      }),
    confirmDelivery: protectedProcedure.input(z.object({ orderId: z.number() })).mutation(async ({ ctx, input }) => {
      const order = await getOrderById(input.orderId);
      if (!order || order.buyerEmail !== ctx.user.email!) {
        throw new TRPCError({ code: "FORBIDDEN" });
      }
      const now = new Date();
      await updateOrder(input.orderId, { status: "confirmed", confirmedAt: now, fundsReleasedAt: now });
      await createOrderMessage({ orderId: input.orderId, senderEmail: "system", senderName: "SportCardsOnline", senderRole: "system", messageText: "Buyer confirmed receipt. Funds have been released to the seller. Ticket complete." });
      // Email buyer: order complete
      const tmplBuyer = emailTemplates().fundsReleasedBuyer(ctx.user.name || ctx.user.email!, {
        orderId: String(order.id),
        cardTitle: order.cardTitle || "Sports Card",
      });
      sendEmail({ to: order.buyerEmail, ...tmplBuyer }).catch(() => {});
      // Email seller: funds released
      if (order.sellerEmail) {
        const payout = order.sellerPayout ? parseFloat(String(order.sellerPayout)) : parseFloat(String(order.price || "0")) * 0.9;
        const tmplSeller = emailTemplates().fundsReleasedSeller(order.sellerEmail, {
          orderId: String(order.id),
          cardTitle: order.cardTitle || "Sports Card",
          payout,
          releasedBy: "Buyer Confirmation",
        });
        sendEmail({ to: order.sellerEmail, ...tmplSeller }).catch(() => {});
      }
      return { success: true };
    }),

    setLabelCreated: protectedProcedure
      .input(z.object({ orderId: z.number(), trackingNumber: z.string().optional() }))
      .mutation(async ({ ctx, input }) => {
        const order = await getOrderById(input.orderId);
        if (!order || order.sellerEmail !== ctx.user.email!) throw new TRPCError({ code: "FORBIDDEN" });
        await updateOrder(input.orderId, { status: "label_created", labelPurchased: true, trackingNumber: input.trackingNumber });
        await createOrderMessage({ orderId: input.orderId, senderEmail: ctx.user.email!, senderName: ctx.user.name || "Seller", senderRole: "seller", messageText: `Shipping label created${input.trackingNumber ? ` \u2014 Tracking: ${input.trackingNumber}` : ""}.` });
        return { success: true };
      }),

    getMessages: protectedProcedure
      .input(z.object({ orderId: z.number() }))
      .query(async ({ ctx, input }) => {
        const order = await getOrderById(input.orderId);
        if (!order || (order.buyerEmail !== ctx.user.email! && order.sellerEmail !== ctx.user.email!)) {
          throw new TRPCError({ code: "FORBIDDEN" });
        }
        await markOrderMessagesRead(input.orderId, ctx.user.email!);
        return getOrderMessages(input.orderId);
      }),

    sendMessage: protectedProcedure
      .input(z.object({ orderId: z.number(), messageText: z.string().min(1).max(2000) }))
      .mutation(async ({ ctx, input }) => {
        const order = await getOrderById(input.orderId);
        if (!order || (order.buyerEmail !== ctx.user.email! && order.sellerEmail !== ctx.user.email!)) {
          throw new TRPCError({ code: "FORBIDDEN" });
        }
        const role: "buyer" | "seller" = order.buyerEmail === ctx.user.email! ? "buyer" : "seller";
        return createOrderMessage({ orderId: input.orderId, senderEmail: ctx.user.email!, senderName: ctx.user.name || ctx.user.email!, senderRole: role, messageText: input.messageText });
      }),
    /** Create a Stripe checkout session to buy a single card (Buy Now) */
    createCheckoutSession: protectedProcedure
      .input(z.object({
        cardId: z.number(),
        cardTitle: z.string(),
        cardImageUrl: z.string().optional(),
        sellerEmail: z.string(),
        sellerStoreName: z.string().optional(),
        price: z.string(),
        origin: z.string(),
      }))
      .mutation(async ({ ctx, input }) => {
        // eBay availability check before charging
        const dbConn = await getDb();
        if (dbConn) {
          const [cardRows] = await (dbConn as any).execute("SELECT ebayItemId FROM cards WHERE id = ? AND status = 'active' LIMIT 1", [input.cardId]) as any;
          const cardRow = (cardRows as any[])[0];
          if (cardRow?.ebayItemId) {
            const avail = await checkEbayAvailability(cardRow.ebayItemId);
            if (!avail.available) {
              // Hard-delete the card so it's fully removed from the marketplace (consistent with cron job behavior)
              await (dbConn as any).execute("DELETE FROM cards WHERE id = ?", [input.cardId]);
              throw new TRPCError({ code: "BAD_REQUEST", message: "Sorry, this card was just sold on eBay and is no longer available. It has been removed from the marketplace." });
            }
          }
        }
        const Stripe = (await import("stripe")).default;
        const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, { apiVersion: "2025-01-27.acacia" as any });
        const priceInCents = Math.round(parseFloat(input.price) * 100);
        const images = input.cardImageUrl ? [input.cardImageUrl] : [];
        // Fetch card to determine if it's a dropship (eBay) card for shipping calc
        const dbConn2 = await getDb();
        let isDropship = false;
        if (dbConn2) {
          const [rows] = await (dbConn2 as any).execute("SELECT isDropship FROM cards WHERE id = ? LIMIT 1", [input.cardId]) as any;
          isDropship = !!(rows as any[])[0]?.isDropship;
        }
        const cardPrice = parseFloat(input.price);
        // Check for admin-set shipping override on the card
        let shippingFeeOverride: number | null = null;
        if (dbConn2) {
          const [feeRows] = await (dbConn2 as any).execute("SELECT cardShippingFee FROM cards WHERE id = ? LIMIT 1", [input.cardId]) as any;
          const feeVal = (feeRows as any[])[0]?.cardShippingFee;
          if (feeVal !== null && feeVal !== undefined) shippingFeeOverride = parseFloat(feeVal);
        }
        const shippingFee = shippingFeeOverride !== null ? shippingFeeOverride : getShippingFee(cardPrice, isDropship);
        const shippingLabel = getShippingLabel(cardPrice, isDropship);
        const shippingCents = Math.round(shippingFee * 100);
        const lineItems: any[] = [{
          price_data: {
            currency: "usd",
            product_data: {
              name: input.cardTitle,
              images,
              description: `Sold by ${input.sellerStoreName || input.sellerEmail}`,
            },
            unit_amount: priceInCents,
          },
          quantity: 1,
        }];
        if (shippingCents > 0) {
          lineItems.push({
            price_data: {
              currency: "usd",
              product_data: { name: `Shipping — ${shippingLabel}` },
              unit_amount: shippingCents,
            },
            quantity: 1,
          });
        }
        // Fetch ebayItemId for dropship metadata
        let ebayItemId = "";
        if (dbConn2) {
          const [eiRows] = await (dbConn2 as any).execute("SELECT ebayItemId FROM cards WHERE id = ? LIMIT 1", [input.cardId]) as any;
          ebayItemId = (eiRows as any[])[0]?.ebayItemId || "";
        }
        const session = await stripe.checkout.sessions.create({
          payment_method_types: ["card"],
          mode: "payment",
          customer_email: ctx.user.email!,
          line_items: lineItems,
          client_reference_id: ctx.user.id.toString(),
          metadata: {
            user_id: ctx.user.id.toString(),
            customer_email: ctx.user.email!,
            customer_name: ctx.user.name || "",
            card_id: input.cardId.toString(),
            seller_email: input.sellerEmail,
            order_type: "card_purchase",
            is_dropship: isDropship ? "1" : "0",
            ebay_item_id: ebayItemId,
          },
          success_url: `${input.origin}/orders?success=1&card=${input.cardId}`,
          cancel_url: `${input.origin}/marketplace`,
          allow_promotion_codes: true,
        });
        return { checkoutUrl: session.url! };
      }),
    /** Create a Stripe checkout session for multiple cart items */
    createCartCheckoutSession: protectedProcedure
      .input(z.object({
        items: z.array(z.object({
          cardId: z.number(),
          cardTitle: z.string(),
          cardImageUrl: z.string().optional(),
          sellerEmail: z.string(),
          sellerStoreName: z.string().optional(),
          price: z.string(),
        })),
        origin: z.string(),
      }))
      .mutation(async ({ ctx, input }) => {
        if (input.items.length === 0) throw new TRPCError({ code: "BAD_REQUEST", message: "Cart is empty" });
        const Stripe = (await import("stripe")).default;
        const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, { apiVersion: "2025-01-27.acacia" as any });
        const lineItems = input.items.map(item => ({
          price_data: {
            currency: "usd",
            product_data: {
              name: item.cardTitle,
              images: item.cardImageUrl ? [item.cardImageUrl] : [],
              description: `Sold by ${item.sellerStoreName || item.sellerEmail}`,
            },
            unit_amount: Math.round(parseFloat(item.price) * 100),
          },
          quantity: 1 as const,
        }));
        const cardIds = input.items.map(i => i.cardId).join(",");
        const session = await stripe.checkout.sessions.create({
          payment_method_types: ["card"],
          mode: "payment",
          customer_email: ctx.user.email!,
          line_items: lineItems,
          client_reference_id: ctx.user.id.toString(),
          metadata: {
            user_id: ctx.user.id.toString(),
            customer_email: ctx.user.email!,
            customer_name: ctx.user.name || "",
            card_ids: cardIds,
            seller_emails: input.items.map(i => i.sellerEmail).join(","),
            order_type: "cart_purchase",
          },
          success_url: `${input.origin}/orders?success=1&cart=1`,
          cancel_url: `${input.origin}/marketplace`,
          allow_promotion_codes: true,
        });
        return { checkoutUrl: session.url! };
      }),

    /** Check if a dropship card is still available on eBay before checkout */
    checkDropshipAvailability: protectedProcedure
      .input(z.object({ cardId: z.number(), ebayItemId: z.string() }))
      .mutation(async ({ input }) => {
        const result = await checkEbayAvailability(input.ebayItemId);
        if (!result.available) {
          // Auto-delist the card so no one else can buy it
          const { getDb } = await import("./db");
          const { cards } = await import("../drizzle/schema");
          const db = await getDb();
          if (db) {
            await db.update(cards).set({ status: "sold" }).where(eq(cards.id, input.cardId));
          }
        }
        return result;
      }),
  }),

  // ============================================================================
  // TRADES
  // ============================================================================
  trades: router({
    incoming: protectedProcedure.query(async ({ ctx }) => {
      return getTradesByReceiverEmail(ctx.user.email!);
    }),

    myReceivedTrades: protectedProcedure.query(async ({ ctx }) => {
      return getTradesByReceiverEmail(ctx.user.email!);
    }),

    outgoing: protectedProcedure.query(async ({ ctx }) => {
      return getTradesByInitiatorEmail(ctx.user.email!);
    }),

    mySentTrades: protectedProcedure.query(async ({ ctx }) => {
      return getTradesByInitiatorEmail(ctx.user.email!);
    }),

    getById: protectedProcedure.input(z.object({ id: z.number() })).query(async ({ ctx, input }) => {
      const trade = await getTradeById(input.id);
      if (!trade || (trade.initiatorEmail !== ctx.user.email! && trade.receiverEmail !== ctx.user.email!)) {
        throw new TRPCError({ code: "FORBIDDEN" });
      }
      return trade;
    }),

    propose: protectedProcedure
      .input(
        z.object({
          receiverEmail: z.string(),
          receiverName: z.string().optional(),
          offeredCardIds: z.array(z.number()),
          offeredCardTitles: z.array(z.string()),
          offeredCardImages: z.array(z.string()),
          requestedCardIds: z.array(z.number()),
          requestedCardTitles: z.array(z.string()),
          requestedCardImages: z.array(z.string()),
          message: z.string().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        return createTrade({
          ...input,
          initiatorEmail: ctx.user.email!,
          initiatorName: ctx.user.name || undefined,
          status: "pending",
        });
      }),

    respond: protectedProcedure
      .input(z.object({ tradeId: z.number(), status: z.enum(["accepted", "rejected", "cancelled"]) }))
      .mutation(async ({ ctx, input }) => {
        const trade = await getTradeById(input.tradeId);
        if (!trade) throw new TRPCError({ code: "NOT_FOUND" });
        if (trade.receiverEmail !== ctx.user.email! && trade.initiatorEmail !== ctx.user.email!) {
          throw new TRPCError({ code: "FORBIDDEN" });
        }
        await updateTrade(input.tradeId, { status: input.status });
        return { success: true };
      }),
    myTrades: protectedProcedure.query(async ({ ctx }) => {
      const sent = await getTradesByInitiatorEmail(ctx.user.email!);
      const received = await getTradesByReceiverEmail(ctx.user.email!);
      return [...sent, ...received];
    }),
    create: protectedProcedure
      .input(
        z.object({
          receiverEmail: z.string(),
          receiverName: z.string().optional(),
          offeredCardIds: z.array(z.number()),
          offeredCardTitles: z.array(z.string()),
          offeredCardImages: z.array(z.string()),
          offeredCardGrades: z.array(z.string()).optional(),
          requestedCardIds: z.array(z.number()),
          requestedCardTitles: z.array(z.string()),
          requestedCardImages: z.array(z.string()),
          requestedCardGrades: z.array(z.string()).optional(),
          message: z.string().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        const newTrade = await createTrade({
          initiatorEmail: ctx.user.email!,
          initiatorName: ctx.user.name || undefined,
          receiverEmail: input.receiverEmail,
          receiverName: input.receiverName,
          offeredCardIds: input.offeredCardIds,
          offeredCardTitles: input.offeredCardTitles,
          offeredCardImages: input.offeredCardImages,
          requestedCardIds: input.requestedCardIds,
          requestedCardTitles: input.requestedCardTitles,
          requestedCardImages: input.requestedCardImages,
          message: input.message,
          status: "pending",
        });
        // Build trade contract message
        const senderName = ctx.user.name || ctx.user.email!;
        const receiverName = input.receiverName || input.receiverEmail;
        const offeredList = input.offeredCardTitles.map(t => `• ${t}`).join("\n");
        const requestedList = input.requestedCardTitles.map(t => `• ${t}`).join("\n");
        const contractMsg = `🤝 TRADE OFFER #${newTrade.id}\n\n` +
          `From: ${senderName}\n` +
          `To: ${receiverName}\n\n` +
          `📦 CARDS OFFERED:\n${offeredList}\n\n` +
          `🎯 CARDS REQUESTED:\n${requestedList}\n\n` +
          `${input.message ? `Message: "${input.message}"\n\n` : ""}` +
          `🔒 PROTECTED BY SCG ESCROW\n` +
          `Both parties ship cards to our secure facility after agreeing:\n` +
          `  SCO Secured Location\n\n` +
          `📋 NEXT STEPS:\n` +
          `1. Receiver accepts or counters the offer\n` +
          `2. Both parties digitally agree to the trade\n` +
          `3. Each party ships cards to SCG facility\n` +
          `4. SCG verifies, seals, and forwards cards\n\n` +
          `💰 Trade fee: $10.00 per party (payable after agreement)\n` +
          `Visit /trades to view and respond.`;

        // Send in-app message to receiver
        createMessage({
          conversationId: `trade-${newTrade.id}`,
          senderEmail: ctx.user.email!,
          senderName,
          receiverEmail: input.receiverEmail,
          receiverName: input.receiverName || input.receiverEmail,
          messageText: contractMsg,
        }).catch(() => {});

        // Send confirmation in-app message to initiator
        createMessage({
          conversationId: `trade-${newTrade.id}-confirm`,
          senderEmail: "system@sportscardsonline.com",
          senderName: "SCG Trade System",
          receiverEmail: ctx.user.email!,
          receiverName: senderName,
          messageText: `✅ Your trade offer #${newTrade.id} has been sent to ${receiverName}.\n\n${contractMsg}`,
        }).catch(() => {});

        // Email trade offer to receiver
        const tradeTmpl = emailTemplates();
        const offerTmpl = tradeTmpl.tradeOffered(input.receiverName || input.receiverEmail, {
          id: String(newTrade.id),
          offererName: ctx.user.name || ctx.user.email!,
          offeredCards: input.offeredCardTitles,
          requestedCards: input.requestedCardTitles,
        });
        sendEmail({ to: input.receiverEmail, ...offerTmpl }).catch(() => {});

        // Notify admin
        notifyOwner({
          title: `New Trade #${newTrade.id}`,
          content: `${senderName} sent a trade offer to ${receiverName}.\nOffered: ${input.offeredCardTitles.join(", ")}\nRequested: ${input.requestedCardTitles.join(", ")}`,
        }).catch(() => {});

        return newTrade;
      }),
    updateStatus: protectedProcedure
      .input(z.object({ id: z.number(), status: z.enum(["accepted", "rejected", "cancelled", "countered"]) }))
      .mutation(async ({ ctx, input }) => {
        const trade = await getTradeById(input.id);
        if (!trade) throw new TRPCError({ code: "NOT_FOUND" });
        if (trade.receiverEmail !== ctx.user.email! && trade.initiatorEmail !== ctx.user.email!) {
          throw new TRPCError({ code: "FORBIDDEN" });
        }
        await updateTrade(input.id, { status: input.status });
        // Send email notifications for accepted/rejected trades
        const tmpl = emailTemplates();
        if (input.status === "accepted") {
          const acceptTmpl = tmpl.tradeAccepted(trade.initiatorName || trade.initiatorEmail, {
            id: String(trade.id),
            receiverName: trade.receiverName || trade.receiverEmail,
          });
          sendEmail({ to: trade.initiatorEmail, ...acceptTmpl }).catch(() => {});
        } else if (input.status === "rejected") {
          const declineTmpl = tmpl.tradeDeclined(trade.initiatorName || trade.initiatorEmail, {
            receiverName: trade.receiverName || trade.receiverEmail,
          });
          sendEmail({ to: trade.initiatorEmail, ...declineTmpl }).catch(() => {});
        }
        return { success: true };
      }),
    agreeToTrade: protectedProcedure
      .input(z.object({
        id: z.number(),
        address: z.string().optional(),
        city: z.string().optional(),
        state: z.string().optional(),
        zip: z.string().optional(),
        phone: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const trade = await getTradeById(input.id);
        if (!trade) throw new TRPCError({ code: "NOT_FOUND" });
        const isInitiator = trade.initiatorEmail === ctx.user.email!;
        const isReceiver = trade.receiverEmail === ctx.user.email!;
        if (!isInitiator && !isReceiver) throw new TRPCError({ code: "FORBIDDEN" });
        const updates: Record<string, unknown> = {};
        if (isInitiator) {
          updates.initiatorAgreed = true;
          updates.initiatorSignedAt = new Date();
          if (input.address) updates.initiatorAddress = input.address;
          if (input.city) updates.initiatorCity = input.city;
          if (input.state) updates.initiatorState = input.state;
          if (input.zip) updates.initiatorZip = input.zip;
          if (input.phone) updates.initiatorPhone = input.phone;
        }
        if (isReceiver) {
          updates.receiverAgreed = true;
          updates.receiverSignedAt = new Date();
          if (input.address) updates.receiverAddress = input.address;
          if (input.city) updates.receiverCity = input.city;
          if (input.state) updates.receiverState = input.state;
          if (input.zip) updates.receiverZip = input.zip;
          if (input.phone) updates.receiverPhone = input.phone;
        }
        // Check if both agreed after this update
        const newInitiatorAgreed = isInitiator ? true : !!trade.initiatorAgreed;
        const newReceiverAgreed = isReceiver ? true : !!trade.receiverAgreed;
        if (newInitiatorAgreed && newReceiverAgreed) {
          updates.status = "agreed";
          // Lock all involved collection cards as in_trade and remove from marketplace
          const allCardIds = [
            ...((trade.offeredCardIds as number[]) || []),
            ...((trade.requestedCardIds as number[]) || []),
          ];
          const { updateCollectionItem, updateCard } = await import("./db");
          for (const cardId of allCardIds) {
            try {
              await updateCollectionItem(cardId, {
                listingStatus: "in_trade" as any,
                lifecycleNote: `Locked in Trade #${input.id} — awaiting fee payment and shipment to SCG`,
              });
              // Also deactivate any marketplace listing for this card
              const { cards } = await import("../drizzle/schema");
              const { eq } = await import("drizzle-orm");
              const db = await import("./db").then(m => m.getDb());
              if (db) {
                await db.update(cards).set({ status: "sold" }).where(eq(cards.id, cardId)).catch(() => {});
              }
            } catch (_) {}
          }
          // Set agreement timestamp and ticket number
          updates.agreementSentAt = new Date();
          const ticketNum = `SCO-${input.id}-${Date.now().toString().slice(-6)}`;
          updates.ticketNumber = ticketNum;

          // Build rich next-steps in-app message for both parties
          const offeredList = ((trade.offeredCardTitles as string[]) || []).map(t => `  • ${t}`).join("\n");
          const requestedList = ((trade.requestedCardTitles as string[]) || []).map(t => `  • ${t}`).join("\n");
          const nextStepsMsg =
            `✅ TRADE AGREEMENT CONFIRMED — #${ticketNum}\n\n` +
            `Both parties have digitally agreed to this trade. Here is what happens next:\n\n` +
            `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
            `📋 TRADE SUMMARY\n` +
            `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
            `${trade.initiatorName || trade.initiatorEmail} is sending:\n${offeredList}\n\n` +
            `${trade.receiverName || trade.receiverEmail} is sending:\n${requestedList}\n\n` +
            `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
            `📦 YOUR NEXT STEPS\n` +
            `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
            `1️⃣  PREPARE YOUR PACKAGE\n` +
            `   • Place your cards in a protective sleeve or top loader\n` +
            `   • Put them in an UNSEALED inner envelope with your name\n` +
            `   • Write Trade ID #${input.id} on the outside of the package\n\n` +
            `2️⃣  SHIP TO SCO ESCROW\n` +
            `   SportCardsOnline.com — SCO Secured Location\n` +
            `   Attn: Trade Escrow Dept. | Trade ID: #${input.id}\n` +
            `   Use USPS Priority, UPS, or FedEx with tracking\n\n` +
            `3️⃣  SUBMIT YOUR TRACKING NUMBER\n` +
            `   Log in to sportcardsonline.com/trades\n` +
            `   Open this trade and click "Add Tracking Number"\n` +
            `   Both tracking numbers must be submitted before SCO processes the trade\n\n` +
            `4️⃣  PAY THE $10 ESCROW FEE\n` +
            `   Each party pays $10 to cover SCO verification and forwarding\n` +
            `   Payment link available on your Trades page\n\n` +
            `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
            `📄 PRINTABLE AGREEMENT\n` +
            `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
            `Your signed trade agreement is available to print or download from:\n` +
            `sportcardsonline.com/trades → Open Trade #${input.id} → View Agreement\n\n` +
            `A copy has also been emailed to both parties.\n\n` +
            `Questions? Email support@sportcardsonline.com\n` +
            `Trade ID: #${input.id} | Agreement: ${ticketNum}`;

          const { createMessage } = await import("./db");
          // Send next-steps message to initiator
          createMessage({
            conversationId: `trade-${input.id}-agreed`,
            senderEmail: "system@sportcardsonline.com",
            senderName: "SCO Trade System",
            receiverEmail: trade.initiatorEmail,
            receiverName: trade.initiatorName || trade.initiatorEmail,
            messageText: nextStepsMsg,
          }).catch(() => {});
          // Send next-steps message to receiver
          createMessage({
            conversationId: `trade-${input.id}-agreed-recv`,
            senderEmail: "system@sportcardsonline.com",
            senderName: "SCO Trade System",
            receiverEmail: trade.receiverEmail,
            receiverName: trade.receiverName || trade.receiverEmail,
            messageText: nextStepsMsg,
          }).catch(() => {});

          // Notify both parties that trade is agreed and fee is due
          const { sendEmail } = await import("./email");
          const feeHtml = `
            <div style="font-family:Arial,sans-serif;max-width:600px;margin:0 auto">
              <div style="background:#C41E3A;padding:20px;text-align:center">
                <img src="https://d2xsxph8kpxj0f.cloudfront.net/310/pasted_file_NDxW0y_image.png" height="50" alt="SportCardsOnline" />
                <h2 style="color:white;margin:8px 0 0">Trade Agreement Confirmed</h2>
              </div>
              <div style="padding:24px;background:#f9f9f9">
                <p style="font-size:15px">Both parties have agreed to <strong>Trade #${input.id}</strong> (${ticketNum}).</p>
                <h3 style="color:#1a237e;margin-top:20px">Your Next Steps:</h3>
                <ol style="line-height:2">
                  <li><strong>Prepare your cards</strong> in a protective sleeve, unsealed inner envelope with your name, and write Trade ID #${input.id} on the package</li>
                  <li><strong>Ship to SCO:</strong> SportCardsOnline.com — SCO Secured Location, Attn: Trade Escrow Dept., Trade ID: #${input.id}</li>
                  <li><strong>Submit your tracking number</strong> at sportcardsonline.com/trades</li>
                  <li><strong>Pay the $10 escrow fee</strong> via the link on your Trades page</li>
                </ol>
                <div style="background:#e8f5e9;border:1px solid #a5d6a7;border-radius:6px;padding:14px;margin-top:20px">
                  <p style="margin:0;font-size:13px"><strong>📄 Your signed agreement is available to print/download</strong> at sportcardsonline.com/trades — open Trade #${input.id} and click "View Agreement".</p>
                </div>
                <p style="margin-top:20px;font-size:12px;color:#777">Questions? Email support@sportcardsonline.com | Trade ID: #${input.id}</p>
              </div>
            </div>`;
          sendEmail({ to: trade.initiatorEmail, subject: `✅ Trade #${input.id} Agreed — Next Steps Inside`, html: feeHtml }).catch(() => {});
          sendEmail({ to: trade.receiverEmail, subject: `✅ Trade #${input.id} Agreed — Next Steps Inside`, html: feeHtml }).catch(() => {});
          // Notify admin
          const { notifyOwner } = await import("./_core/notification");
          notifyOwner({ title: `Trade #${input.id} Agreed`, content: `Both parties agreed. Initiator: ${trade.initiatorEmail}, Receiver: ${trade.receiverEmail}. Ticket: ${ticketNum}. Awaiting $10 fee from each.` }).catch(() => {});
        }
        await updateTrade(input.id, updates);
        return { success: true, bothAgreed: newInitiatorAgreed && newReceiverAgreed };
      }),
    counterOffer: protectedProcedure
      .input(z.object({
        id: z.number(),
        offeredCardIds: z.array(z.number()),
        offeredCardTitles: z.array(z.string()),
        offeredCardImages: z.array(z.string()),
        requestedCardIds: z.array(z.number()),
        requestedCardTitles: z.array(z.string()),
        requestedCardImages: z.array(z.string()),
        message: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const trade = await getTradeById(input.id);
        if (!trade) throw new TRPCError({ code: "NOT_FOUND" });
        const isInitiator = trade.initiatorEmail === ctx.user.email!;
        const isReceiver = trade.receiverEmail === ctx.user.email!;
        if (!isInitiator && !isReceiver) throw new TRPCError({ code: "FORBIDDEN" });
        // Save revision history
        const db = await getDb();
        if (db) {
          const { tradeRevisions } = await import("../drizzle/schema");
          await db.insert(tradeRevisions).values({
            tradeId: input.id,
            revisedByEmail: ctx.user.email!,
            revisedByName: ctx.user.name || undefined,
            offeredCardIds: input.offeredCardIds,
            offeredCardTitles: input.offeredCardTitles,
            offeredCardImages: input.offeredCardImages,
            requestedCardIds: input.requestedCardIds,
            requestedCardTitles: input.requestedCardTitles,
            requestedCardImages: input.requestedCardImages,
            message: input.message,
            revisionNumber: (trade.revisionCount ?? 0) + 1,
          });
        }
        // Update the trade with new card sets, flip initiator/receiver perspective
        await updateTrade(input.id, {
          offeredCardIds: input.offeredCardIds,
          offeredCardTitles: input.offeredCardTitles,
          offeredCardImages: input.offeredCardImages,
          requestedCardIds: input.requestedCardIds,
          requestedCardTitles: input.requestedCardTitles,
          requestedCardImages: input.requestedCardImages,
          counterMessage: input.message,
          status: "countered",
          revisionCount: (trade.revisionCount ?? 0) + 1,
          initiatorAgreed: false,
          receiverAgreed: false,
        });
        // Notify the other party via the proper tradeCounterOffer template
        const otherEmail = isInitiator ? trade.receiverEmail : trade.initiatorEmail;
        const otherName = isInitiator ? (trade.receiverName || trade.receiverEmail) : (trade.initiatorName || trade.initiatorEmail);
        const myName = ctx.user.name || ctx.user.email!;
        const counterTmpl = emailTemplates().tradeCounterOffer(
          String(otherName ?? otherEmail),
          {
            tradeId: String(input.id),
            senderName: myName,
            message: input.message || `${myName} has sent a counter-offer on Trade #${input.id}. Log in to review the new card selection and respond.`,
          }
        );
        sendEmail({ to: otherEmail, ...counterTmpl }).catch(() => {});
        return { success: true };
      }),

    addTracking: protectedProcedure
      .input(z.object({ id: z.number(), trackingNumber: z.string() }))
      .mutation(async ({ ctx, input }) => {
        const trade = await getTradeById(input.id);
        if (!trade) throw new TRPCError({ code: "NOT_FOUND" });
        const isInitiator = trade.initiatorEmail === ctx.user.email!;
        const isReceiver = trade.receiverEmail === ctx.user.email!;
        if (!isInitiator && !isReceiver) throw new TRPCError({ code: "FORBIDDEN" });
        const updates: Record<string, unknown> = {};
        if (isInitiator) updates.initiatorTracking = input.trackingNumber;
        if (isReceiver) updates.receiverTracking = input.trackingNumber;
        // If both have tracking, mark as shipped
        const newInitiatorTracking = isInitiator ? input.trackingNumber : trade.initiatorTracking;
        const newReceiverTracking = isReceiver ? input.trackingNumber : trade.receiverTracking;
        if (newInitiatorTracking && newReceiverTracking) {
          updates.status = "shipped";
          updates.shippingStatus = "both_received";
          // Update collection items to shipped status
          const allCardIds = [
            ...((trade.offeredCardIds as number[]) || []),
            ...((trade.requestedCardIds as number[]) || []),
          ];
          const { updateCollectionItem } = await import("./db");
          for (const cardId of allCardIds) {
            try { await updateCollectionItem(cardId, { listingStatus: "shipped" as any }); } catch (_) {}
          }
        } else {
          updates.shippingStatus = "awaiting_packages";
        }
        await updateTrade(input.id, updates);
        return { success: true };
      }),

    payTradeFee: protectedProcedure
      .input(z.object({ id: z.number(), origin: z.string() }))
      .mutation(async ({ ctx, input }) => {
        const trade = await getTradeById(input.id);
        if (!trade) throw new TRPCError({ code: "NOT_FOUND" });
        const isInitiator = trade.initiatorEmail === ctx.user.email!;
        const isReceiver = trade.receiverEmail === ctx.user.email!;
        if (!isInitiator && !isReceiver) throw new TRPCError({ code: "FORBIDDEN" });
        // Check if already paid
        if (isInitiator && trade.initiatorFeePaid) return { alreadyPaid: true, url: null };
        if (isReceiver && trade.receiverFeePaid) return { alreadyPaid: true, url: null };
        const { createTradeFeeSession } = await import("./stripe");
        const session = await createTradeFeeSession({
          tradeId: input.id,
          partyEmail: ctx.user.email!,
          partyName: ctx.user.name || ctx.user.email!,
          role: isInitiator ? "initiator" : "receiver",
          origin: input.origin,
        });
        // Save session ID
        const sessionUpdate: Record<string, unknown> = {};
        if (isInitiator) sessionUpdate.initiatorFeeSessionId = session.id;
        else sessionUpdate.receiverFeeSessionId = session.id;
        await updateTrade(input.id, sessionUpdate);
        return { alreadyPaid: false, url: session.url };
      }),
  }),

  // ============================================================================
  // MESSAGES
  // ============================================================================
  messages: router({
    myConversations: protectedProcedure.query(async ({ ctx }) => {
      const messages = await getDb().then(db => db?.select().from(require("../drizzle/schema").messages).where(require("drizzle-orm").or(require("drizzle-orm").eq(require("../drizzle/schema").messages.senderEmail, ctx.user.email!), require("drizzle-orm").eq(require("../drizzle/schema").messages.receiverEmail, ctx.user.email!))).orderBy(require("drizzle-orm").desc(require("../drizzle/schema").messages.createdAt)));
      if (!messages) return [];
      const convMap = new Map<string, any>();
      messages.forEach(m => {
        const conv = m.conversationId;
        if (!convMap.has(conv)) {
          const otherEmail = m.senderEmail === ctx.user.email! ? m.receiverEmail : m.senderEmail;
          const otherName = m.senderEmail === ctx.user.email! ? m.receiverName : m.senderName;
          convMap.set(conv, { conversationId: conv, otherEmail, otherName, lastMessage: m.messageText, lastMessageTime: m.createdAt });
        }
      });
      return Array.from(convMap.values());
    }),

    getConversation: protectedProcedure.input(z.object({ conversationId: z.string() })).query(async ({ ctx, input }) => {
      return getMessagesByConversationId(input.conversationId);
    }),

    send: protectedProcedure
      .input(
        z.object({
          conversationId: z.string(),
          receiverEmail: z.string(),
          receiverName: z.string().optional(),
          messageText: z.string(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        await createMessage({
          conversationId: input.conversationId,
          senderEmail: ctx.user.email!,
          senderName: ctx.user.name || undefined,
          receiverEmail: input.receiverEmail,
          receiverName: input.receiverName,
          messageText: input.messageText,
        });
        return { success: true };
      }),
  }),

  // ============================================================================
  // CREDITS
  // ============================================================================
  credits: router({
    myAccount: protectedProcedure.query(async ({ ctx }) => {
      let account = await getCreditAccountByEmail(ctx.user.email!);
      if (!account) {
        account = await createCreditAccount({
          userEmail: ctx.user.email!,
          userName: ctx.user.name || undefined,
          credits: 25, // Free tier starts with 25 credits
        });
      }
      // Attach loyalty tier info
      const { getLoyaltyStatus } = await import("./loyalty");
      const loyaltyStatus = await getLoyaltyStatus(ctx.user.email!);
      return { ...account, loyaltyStatus };
    }),

    addCredits: protectedProcedure
      .input(z.object({ amount: z.number(), reason: z.string().optional() }))
      .mutation(async ({ ctx, input }) => {
        await addCredits(ctx.user.email!, input.amount, input.reason || "Credit purchase");
        return { success: true };
      }),

    /** Create a Stripe checkout session to purchase credits */
    buyCredits: protectedProcedure
      .input(z.object({
        packageId: z.enum(["25", "50", "100", "250", "500", "1000"]),
        returnPath: z.string().optional(), // where to redirect after purchase
        origin: z.string(),
      }))
      .mutation(async ({ ctx, input }) => {
        const Stripe = (await import("stripe")).default;
        const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, { apiVersion: "2025-01-27.acacia" });

        // Credit packages: base credits, bonus credits, price in cents
        const PACKAGES: Record<string, { base: number; bonus: number; priceCents: number; label: string }> = {
          "25":   { base: 25,   bonus: 0,   priceCents: 2500,  label: "25 Credits" },
          "50":   { base: 50,   bonus: 0,   priceCents: 5000,  label: "50 Credits" },
          "100":  { base: 100,  bonus: 0,   priceCents: 10000, label: "100 Credits" },
          "250":  { base: 250,  bonus: 6,   priceCents: 25000, label: "250 Credits + 6 Bonus" },
          "500":  { base: 500,  bonus: 25,  priceCents: 50000, label: "500 Credits + 25 Bonus" },
          "1000": { base: 1000, bonus: 100, priceCents: 100000, label: "1000 Credits + 100 Bonus" },
        };

        const pkg = PACKAGES[input.packageId];
        const totalCredits = pkg.base + pkg.bonus;

        const session = await stripe.checkout.sessions.create({
          mode: "payment",
          customer_email: ctx.user.email!,
          allow_promotion_codes: true,
          line_items: [{
            quantity: 1,
            price_data: {
              currency: "usd",
              unit_amount: pkg.priceCents,
              product_data: {
                name: `SCO ${pkg.label}`,
                description: `${totalCredits} credits for SportCardsOnline.com games, grading & auctions`,
                images: [],
              },
            },
          }],
          metadata: {
            order_type: "credit_purchase",
            user_id: ctx.user.id.toString(),
            customer_email: ctx.user.email!,
            customer_name: ctx.user.name || "",
            package_id: input.packageId,
            credits_amount: totalCredits.toString(),
            credits_to_add: totalCredits.toString(),
          },
          client_reference_id: ctx.user.id.toString(),
          success_url: `${input.origin}${input.returnPath || "/credits"}?success=1&credits=${totalCredits}`,
          cancel_url: `${input.origin}${input.returnPath || "/credits"}?cancelled=1`,
        });

        return { url: session.url };
      }),
  }),

  // ============================================================================
  // STORES
  // ============================================================================
  stores: router({
    myStore: protectedProcedure.query(async ({ ctx }) => {
      return getStoreByOwnerEmail(ctx.user.email!);
    }),

    create: protectedProcedure
      .input(z.object({ name: z.string(), description: z.string().optional() }))
      .mutation(async ({ ctx, input }) => {
        const existing = await getStoreByOwnerEmail(ctx.user.email!);
        if (existing) return existing;
        return createStore({
          name: input.name,
          ownerEmail: ctx.user.email!,
          ownerName: ctx.user.name || undefined,
          description: input.description,
        });
      }),
  }),

  // ============================================================================
  // CONTACT FORM
  // ============================================================================
  contact: router({
    submit: publicProcedure
      .input(z.object({
        name: z.string().min(1),
        email: z.string().email(),
        subject: z.string().min(1),
        message: z.string().min(10),
      }))
      .mutation(async ({ ctx, input }) => {
        const tmpl = emailTemplates();
        // Email admin
        const adminTmpl = tmpl.contactFormAdmin({
          name: input.name,
          email: input.email,
          subject: input.subject,
          message: input.message,
          ip: (ctx.req as any).ip || (ctx.req as any).headers?.['x-forwarded-for'] || undefined,
        });
        sendEmail(adminTmpl).catch(() => {});
        // Confirmation email to user
        const confirmTmpl = tmpl.contactFormConfirmation(input.name, input.subject);
        sendEmail({ to: input.email, ...confirmTmpl }).catch(() => {});
        // Admin notification in back office
        notifyOwner({
          title: `Contact Form: ${input.subject}`,
          content: `From: ${input.name} <${input.email}>\n\n${input.message}`,
        }).catch(() => {});
        return { success: true };
      }),
  }),
  // ============================================================================
  // EBAY IMPORT
  // ============================================================================
  ebay: router({
    // Fetch active listings for a given eBay seller username
    fetchSellerListings: protectedProcedure
      .input(z.object({ sellerUsername: z.string().min(1) }))
      .query(async ({ input }) => {
        const clientId = process.env.EBAY_CLIENT_ID;
        const clientSecret = process.env.EBAY_CLIENT_SECRET;
        if (!clientId || !clientSecret) {
          throw new TRPCError({ code: "PRECONDITION_FAILED", message: "eBay API credentials not configured. Please add EBAY_CLIENT_ID and EBAY_CLIENT_SECRET in Settings → Secrets." });
        }
        // Auto-detect sandbox vs production based on Client ID
        const isSandbox = clientId.includes("-SBX-");
        const ebayBase = isSandbox ? "https://api.sandbox.ebay.com" : "https://api.ebay.com";
        const creds = Buffer.from(`${clientId}:${clientSecret}`).toString("base64");
        const tokenRes = await fetch(`${ebayBase}/identity/v1/oauth2/token`, {
          method: "POST",
          headers: { "Authorization": `Basic ${creds}`, "Content-Type": "application/x-www-form-urlencoded" },
          body: "grant_type=client_credentials&scope=https%3A%2F%2Fapi.ebay.com%2Foauth%2Fapi_scope",
        });
        const tokenData = await tokenRes.json() as any;
        if (!tokenData.access_token) {
          throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: `Failed to authenticate with eBay ${isSandbox ? 'Sandbox' : 'Production'}. Check your API credentials in Settings → Secrets.` });
        }
        // Search listings by seller
        const searchRes = await fetch(
          `${ebayBase}/buy/browse/v1/item_summary/search?filter=sellers%3A%7B${encodeURIComponent(input.sellerUsername)}%7D%2CshippingOptions%3A%7BFREE_SHIPPING%7D&limit=50&fieldgroups=EXTENDED`,
          { headers: { "Authorization": `Bearer ${tokenData.access_token}`, "X-EBAY-C-MARKETPLACE-ID": "EBAY_US" } }
        );
        const searchData = await searchRes.json() as any;
        if (!searchRes.ok) {
          throw new TRPCError({ code: "BAD_REQUEST", message: searchData.errors?.[0]?.message || "eBay search failed" });
        }
        const items = (searchData.itemSummaries || []).map((item: any) => ({
          ebayItemId: item.itemId,
          title: item.title,
          price: item.price?.value || "0",
          currency: item.price?.currency || "USD",
          imageUrl: item.image?.imageUrl || null,
          additionalImages: (item.additionalImages || []).map((img: any) => img.imageUrl),
          condition: item.condition || "Unknown",
          itemUrl: item.itemWebUrl,
          seller: item.seller?.username || input.sellerUsername,
          // LOCKED RULE: only free shipping eBay cards
          freeShipping: (item.shippingOptions || []).some((s: any) => s.shippingCostType === 'FREE' || parseFloat(s.shippingCost?.value || '1') === 0),
        }));
        // LOCKED RULE: only import cards with free shipping
        const freeItems = items.filter((i: any) => i.freeShipping);
        return { items: freeItems, total: freeItems.length };
      }),

    // Fetch recently SOLD eBay listings for a card title (market comp data)
    getSoldComps: publicProcedure
      .input(z.object({ query: z.string().min(2), limit: z.number().min(1).max(20).default(10) }))
      .query(async ({ input }) => {
        const clientId = process.env.EBAY_CLIENT_ID;
        const clientSecret = process.env.EBAY_CLIENT_SECRET;
        if (!clientId || !clientSecret) return { sales: [], error: "eBay not configured" };
        const isSandbox = clientId.includes("-SBX-");
        // Use eBay Browse API (OAuth) — much more reliable for sold/completed items
        try {
          // Step 1: Get OAuth token
          const creds = Buffer.from(`${clientId}:${clientSecret}`).toString("base64");
          const tokenBase = isSandbox ? "https://api.sandbox.ebay.com" : "https://api.ebay.com";
          const tokenRes = await fetch(`${tokenBase}/identity/v1/oauth2/token`, {
            method: "POST",
            headers: { "Authorization": `Basic ${creds}`, "Content-Type": "application/x-www-form-urlencoded" },
            body: "grant_type=client_credentials&scope=https%3A%2F%2Fapi.ebay.com%2Foauth%2Fapi_scope",
          });
          const tokenData = await tokenRes.json() as any;
          if (!tokenData.access_token) {
            return { sales: [], error: isSandbox ? "eBay sandbox: limited sold data in test mode" : "eBay auth failed" };
          }
          // Step 2: Search sold/completed items via Browse API
          const browseBase = isSandbox ? "https://api.sandbox.ebay.com" : "https://api.ebay.com";
          const searchParams = new URLSearchParams({
            q: input.query,
            category_ids: "212",
            filter: "buyingOptions:{AUCTION|FIXED_PRICE},conditions:{USED|LIKE_NEW|VERY_GOOD|GOOD|ACCEPTABLE|NEW},deliveryCountry:US",
            sort: "-price",
            limit: String(input.limit),
            fieldgroups: "EXTENDED",
          });
          const searchRes = await fetch(`${browseBase}/buy/browse/v1/item_summary/search?${searchParams.toString()}`, {
            headers: {
              "Authorization": `Bearer ${tokenData.access_token}`,
              "X-EBAY-C-MARKETPLACE-ID": "EBAY_US",
              "Content-Type": "application/json",
            },
          });
          if (!searchRes.ok) {
            const errText = await searchRes.text();
            return { sales: [], error: `eBay search failed: ${searchRes.status}` };
          }
          const searchData = await searchRes.json() as any;
          const items = searchData?.itemSummaries || [];
          if (items.length === 0) {
            return { sales: [], error: isSandbox ? "eBay sandbox has limited data — live mode will show real comps" : "No sold comps found for this search" };
          }
          const sales = items.map((item: any) => ({
            title: item.title || "Unknown",
            price: parseFloat(item.price?.value || "0"),
            currency: item.price?.currency || "USD",
            condition: item.condition || "Unknown",
            soldDate: item.itemEndDate || item.itemCreationDate || null,
            imageUrl: item.image?.imageUrl || item.thumbnailImages?.[0]?.imageUrl || null,
            itemUrl: item.itemWebUrl || null,
          }));
          return { sales };
        } catch (e: any) {
          return { sales: [], error: `eBay comps error: ${e?.message || "Unknown error"}` };
        }
      }),

    // Import selected eBay listings into the user's collection
      importListings: protectedProcedure
        .input(z.object({
          items: z.array(z.object({
            ebayItemId: z.string(),
            title: z.string(),
            price: z.string(),
            imageUrl: z.string().nullable(),
            condition: z.string(),
            itemUrl: z.string(),
          }))
        }))
        .mutation(async ({ ctx, input }) => {
          const results = [];
          for (const item of input.items) {
            const titleParts = item.title.split(" ");
            const playerName = titleParts.slice(0, 3).join(" ");
            const created = await createCollectionItem({
              cardTitle: item.title,
              playerName,
              sport: "other",
              frontImageUrl: item.imageUrl || undefined,
              ownerEmail: ctx.user.email!,
              estimatedValueLow: item.price,
              estimatedValueHigh: item.price,
              description: `Imported from eBay (${item.itemUrl})`,
            });
            results.push(created);
          }
          return { imported: results.length };
        }),

      // Single-card import — used by the frontend for per-card progress tracking
      importSingle: protectedProcedure
        .input(z.object({
          ebayItemId: z.string(),
          title: z.string(),
          price: z.string(),
          imageUrl: z.string().nullable(),
          condition: z.string(),
          itemUrl: z.string(),
        }))
        .mutation(async ({ ctx, input }) => {
          const titleParts = input.title.split(" ");
          const playerName = titleParts.slice(0, 3).join(" ");
          await createCollectionItem({
            cardTitle: input.title,
            playerName,
            sport: "other",
            frontImageUrl: input.imageUrl || undefined,
            ownerEmail: ctx.user.email!,
            estimatedValueLow: input.price,
            estimatedValueHigh: input.price,
            description: `Imported from eBay (${input.itemUrl})`,
          });
          return { success: true, title: input.title };
        }),
  }),

  // ============================================================================
  // CARD SEARCH (SportsCardsPro API + comp values)
  // ============================================================================
  cardSearch: router({
    search: publicProcedure
      .input(z.object({ query: z.string().min(2) }))
      .query(async ({ input }) => {
        // Use SportsCardsPro public API — returns up to 20 matching cards
        const token = process.env.SPORTSCARDSPRO_API_TOKEN || "c0b53bce27c1bdab90b1605249e600dc43dfd1d5";
        const url = `https://www.sportscardspro.com/api/products?t=${token}&q=${encodeURIComponent(input.query)}`;
        const res = await fetch(url);
        if (!res.ok) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Card search unavailable" });
        const data = await res.json() as { status: string; products?: Array<{ id: string; "product-name": string; "console-name": string; "image": string | null }> };
        if (data.status !== "success" || !data.products) return [];
        return data.products.map(p => ({
          id: p.id,
          name: p["product-name"],
          consoleName: p["console-name"],
          imageUrl: p["image"] || null,
        }));
      }),

    /**
     * Get grade-specific pricing for a card using eBay Browse API.
     * Input: { id: "<scpId>", name: string, consoleName: string }
     * Returns grade buckets with avg/min/max from eBay active listings.
     */
    getComps: publicProcedure
      .input(z.object({ id: z.string(), name: z.string().optional(), consoleName: z.string().optional() }))
      .query(async ({ input }) => {
        const clientId = process.env.EBAY_CLIENT_ID;
        const clientSecret = process.env.EBAY_CLIENT_SECRET;
        if (!clientId || !clientSecret) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "eBay not configured" });

        // Get OAuth token
        const creds = Buffer.from(`${clientId}:${clientSecret}`).toString("base64");
        const tokenRes = await fetch("https://api.ebay.com/identity/v1/oauth2/token", {
          method: "POST",
          headers: { "Authorization": `Basic ${creds}`, "Content-Type": "application/x-www-form-urlencoded" },
          body: "grant_type=client_credentials&scope=https://api.ebay.com/oauth/api_scope",
        });
        const tokenData = await tokenRes.json() as { access_token?: string; error?: string };
        if (!tokenData.access_token) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "eBay auth failed" });
        const token = tokenData.access_token;

        // Base card name for queries
        const cardName = input.name || input.id;

        // Helper: fetch eBay Browse API and return avg price
        const fetchGradePrice = async (grade: string): Promise<{ avg: number; min: number; max: number; count: number } | null> => {
          try {
            const q = encodeURIComponent(`${cardName} ${grade}`);
            const url = `https://api.ebay.com/buy/browse/v1/item_summary/search?q=${q}&filter=buyingOptions%3A%7BFIXED_PRICE%7D&limit=10&sort=price`;
            const res = await fetch(url, {
              headers: { "Authorization": `Bearer ${token}`, "X-EBAY-C-MARKETPLACE-ID": "EBAY_US" },
              signal: AbortSignal.timeout(8000),
            });
            if (!res.ok) return null;
            const data = await res.json() as { itemSummaries?: Array<{ price?: { value: string } }> };
            const prices = (data.itemSummaries || [])
              .map(i => parseFloat(i.price?.value || "0"))
              .filter(p => p > 0 && p < 50000); // filter out obvious outliers
            if (prices.length === 0) return null;
            const avg = prices.reduce((a, b) => a + b, 0) / prices.length;
            return { avg: Math.round(avg * 100) / 100, min: Math.min(...prices), max: Math.max(...prices), count: prices.length };
          } catch {
            return null;
          }
        };

        // Fetch all grade tiers in parallel
        const [psa10, psa9, psa8, psa7, bgs95, bgs9, sgc10, ungraded] = await Promise.all([
          fetchGradePrice("PSA 10"),
          fetchGradePrice("PSA 9"),
          fetchGradePrice("PSA 8"),
          fetchGradePrice("PSA 7"),
          fetchGradePrice("BGS 9.5"),
          fetchGradePrice("BGS 9"),
          fetchGradePrice("SGC 10"),
          fetchGradePrice("ungraded raw"),
        ]);

        const psaGrades = [
          { grade: "PSA 10", ...(psa10 || {}) },
          { grade: "PSA 9",  ...(psa9  || {}) },
          { grade: "PSA 8",  ...(psa8  || {}) },
          { grade: "PSA 7",  ...(psa7  || {}) },
        ].filter(g => (g as any).avg != null) as Array<{ grade: string; avg: number; min: number; max: number; count: number }>;

        const bgsGrades = [
          { grade: "BGS 9.5", ...(bgs95 || {}) },
          { grade: "BGS 9",   ...(bgs9  || {}) },
        ].filter(g => (g as any).avg != null) as Array<{ grade: string; avg: number; min: number; max: number; count: number }>;

        const sgcGrades = [
          { grade: "SGC 10", ...(sgc10 || {}) },
        ].filter(g => (g as any).avg != null) as Array<{ grade: string; avg: number; min: number; max: number; count: number }>;

        // SCG estimated value: best available grade avg × 1.10
        const topAvg = psa10?.avg ?? bgs95?.avg ?? psa9?.avg ?? null;
        const scgAvg = topAvg ? Math.round(topAvg * 1.10 * 100) / 100 : null;

        return {
          id: input.id,
          name: cardName,
          set: input.consoleName || "",
          psaGrades,
          bgsGrades,
          sgcGrades,
          scgAvg,
          ungradedPrice: ungraded?.avg ?? null,
          source: "eBay Browse API",
        };
      }),
  }),

  // ============================================================================
  // SPORTS NEWS (ESPN RSS FEEDS — live headlines, refreshed every 15 min)
  // ============================================================================
  news: router({
    getTicker: publicProcedure.query(async () => {
      // ESPN public RSS feeds — no API key required
      const feeds = [
        { url: "https://www.espn.com/espn/rss/nba/news",  category: "NBA",  emoji: "🏀" },
        { url: "https://www.espn.com/espn/rss/mlb/news",  category: "MLB",  emoji: "⚾" },
        { url: "https://www.espn.com/espn/rss/nfl/news",  category: "NFL",  emoji: "🏈" },
        { url: "https://www.espn.com/espn/rss/nhl/news",  category: "NHL",  emoji: "🏒" },
        { url: "https://www.espn.com/espn/rss/wnba/news", category: "WNBA", emoji: "🏀" },
        { url: "https://www.espn.com/espn/rss/golf/news", category: "Golf", emoji: "⛳" },
      ];

      const results = await Promise.allSettled(
        feeds.map(async (feed) => {
          const res = await fetch(feed.url, {
            headers: { "User-Agent": "Mozilla/5.0 (compatible; SCO-Ticker/1.0)" },
            signal: AbortSignal.timeout(6000),
          });
          if (!res.ok) return [] as Array<{ id: number; text: string; category: string }>;
          const xml = await res.text();
          // Extract titles from <item> blocks (skip the first channel-level <title>)
          const itemBlocks = xml.split("<item");
          const items: Array<{ id: number; text: string; category: string }> = [];
          for (let i = 1; i < itemBlocks.length && items.length < 3; i++) {
            const titleMatch = itemBlocks[i].match(/<title>(?:<!\[CDATA\[)?([\s\S]*?)(?:\]\]>)?<\/title>/);
            const title = titleMatch?.[1]?.trim();
            if (title && title.length > 10) {
              items.push({ id: i, text: `${feed.emoji} ${title}`, category: feed.category });
            }
          }
          return items;
        })
      );

      const allItems: Array<{ id: number; text: string; category: string }> = [];
      let globalId = 1;
      for (const result of results) {
        if (result.status === "fulfilled") {
          for (const item of result.value) {
            allItems.push({ ...item, id: globalId++ });
          }
        }
      }

      // Fallback if all feeds fail
      if (allItems.length === 0) {
        return [
          { id: 1, text: "🏀 NBA: Check ESPN for the latest scores and standings", category: "NBA" },
          { id: 2, text: "⚾ MLB: Season underway — follow your favorite teams live", category: "MLB" },
          { id: 3, text: "🏈 NFL Draft: Coming up soon — top prospects being evaluated", category: "NFL" },
          { id: 4, text: "⚾ Sports card market: PSA graded cards trending up in 2026", category: "Cards" },
        ];
      }

      return allItems;
    }),

    // Live betting odds from ESPN (DraftKings lines) for the Game Room ticker
    getBettingOdds: publicProcedure.query(async () => {
      const sports = [
        { sport: "basketball", league: "nba",     label: "NBA", emoji: "🏀" },
        { sport: "baseball",   league: "mlb",     label: "MLB", emoji: "⚾" },
        { sport: "hockey",     league: "nhl",     label: "NHL", emoji: "🏒" },
        { sport: "football",   league: "nfl",     label: "NFL", emoji: "🏈" },
      ];

      type OddsItem = {
        id: string;
        sport: string;
        emoji: string;
        awayTeam: string;
        homeTeam: string;
        awayAbbr: string;
        homeAbbr: string;
        spread: string;
        overUnder: number | null;
        awayML: number | null;
        homeML: number | null;
        gameTime: string;
        status: string;
        eventId: string;
      };

      const allOdds: OddsItem[] = [];

      await Promise.allSettled(
        sports.map(async ({ sport, league, label, emoji }) => {
          try {
            const sbRes = await fetch(
              `https://site.api.espn.com/apis/site/v2/sports/${sport}/${league}/scoreboard`,
              { headers: { "User-Agent": "Mozilla/5.0" }, signal: AbortSignal.timeout(6000) }
            );
            if (!sbRes.ok) return;
            const sbData = await sbRes.json() as { events?: Array<{
              id: string; date: string;
              competitions?: Array<{
                competitors?: Array<{ team: { abbreviation: string; displayName: string }; homeAway: string }>;
                status?: { type?: { description?: string } };
                odds?: Array<{ details?: string; overUnder?: number; awayTeamOdds?: { moneyLine?: number }; homeTeamOdds?: { moneyLine?: number } }>;
              }>;
            }> };
            const events = sbData.events ?? [];

            await Promise.allSettled(
              events.slice(0, 8).map(async (event) => {
                try {
                  const comp = event.competitions?.[0];
                  if (!comp) return;
                  const competitors = comp.competitors ?? [];
                  const away = competitors.find((c) => c.homeAway === "away") ?? competitors[0];
                  const home = competitors.find((c) => c.homeAway === "home") ?? competitors[1];
                  if (!away || !home) return;

                  const status = comp.status?.type?.description ?? "Scheduled";

                  // Try ESPN core odds API
                  const oddsRes = await fetch(
                    `https://sports.core.api.espn.com/v2/sports/${sport}/leagues/${league}/events/${event.id}/competitions/${event.id}/odds`,
                    { headers: { "User-Agent": "Mozilla/5.0" }, signal: AbortSignal.timeout(5000) }
                  );
                  if (!oddsRes.ok) return;
                  const oddsData = await oddsRes.json() as { items?: Array<{ details?: string; overUnder?: number; awayTeamOdds?: { moneyLine?: number }; homeTeamOdds?: { moneyLine?: number } }> };
                  const oddsItem = oddsData.items?.[0];
                  if (!oddsItem || !oddsItem.details) return;

                  allOdds.push({
                    id: `${league}-${event.id}`,
                    sport: label,
                    emoji,
                    awayTeam: away.team.displayName,
                    homeTeam: home.team.displayName,
                    awayAbbr: away.team.abbreviation,
                    homeAbbr: home.team.abbreviation,
                    spread: oddsItem.details ?? "",
                    overUnder: oddsItem.overUnder ?? null,
                    awayML: oddsItem.awayTeamOdds?.moneyLine ?? null,
                    homeML: oddsItem.homeTeamOdds?.moneyLine ?? null,
                    gameTime: event.date,
                    status,
                    eventId: event.id,
                  });
                } catch {
                  // skip individual event errors
                }
              })
            );
          } catch {
            // skip sport errors
          }
        })
      );

      return allOdds;
    }),
  }),
  // ============================================================================
  // COMP REFERENCES (save eBay sold prices as price references for collection items)
  // ============================================================================
  comps: router({
    save: protectedProcedure
      .input(z.object({
        collectionItemId: z.number(),
        salePrice: z.number(),
        saleDate: z.string().optional(),
        condition: z.string().optional(),
        platform: z.string().default("eBay"),
        sourceUrl: z.string().optional(),
        title: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new Error("DB unavailable");
        await db.insert(compReferences).values({
          userId: ctx.user.id,
          collectionItemId: input.collectionItemId,
          salePrice: input.salePrice.toFixed(2),
          saleDate: input.saleDate,
          condition: input.condition,
          platform: input.platform,
          sourceUrl: input.sourceUrl,
          title: input.title,
        });
        return { success: true };
      }),

    getForItem: protectedProcedure
      .input(z.object({ collectionItemId: z.number() }))
      .query(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) return [];
        const refs = await db
          .select()
          .from(compReferences)
          .where(eq(compReferences.collectionItemId, input.collectionItemId))
          .orderBy(desc(compReferences.createdAt))
          .limit(50);
        return refs.filter((r: typeof refs[0]) => r.userId === ctx.user.id);
      }),

    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new Error("DB unavailable");
        const [ref] = await db.select().from(compReferences).where(eq(compReferences.id, input.id)).limit(1);
        if (!ref || ref.userId !== ctx.user.id) throw new Error("Not found");
        await db.delete(compReferences).where(eq(compReferences.id, input.id));
        return { success: true };
      }),
  }),

  // ============================================================================
  // GAME ROOM
  // ============================================================================
  game: router({
    /** Get all active prize vault cards (jackpots + featured + standard) */
    getPrizeVault: publicProcedure.query(async () => {
      const db = await getDb();
      if (!db) return [];
      return db.select().from(prizeVault)
        .where(eq(prizeVault.isActive, true))
        .orderBy(desc(prizeVault.estimatedValue));
    }),

    /** Fetch top 100 house cards for Pack Rip prize pool preview */
    getPackRipPool: publicProcedure.query(async () => {
      const db = await getDb();
      if (!db) return [];
      const { cards: cT } = await import("../drizzle/schema");
      const { or: dor, eq: deq, and: dand, isNotNull: dnn } = await import("drizzle-orm");
      // Include active (marketplace), casino, and bank cards — all house inventory
      return db.select({
        id: cT.id, playerName: cT.playerName, year: cT.year, setName: cT.setName,
        gradeScore: cT.gradeScore, gradeCompany: cT.gradeCompany,
        frontImageUrl: cT.frontImageUrl, price: cT.price, condition: cT.condition,
      }).from(cT)
        .where(dand(
          dor(deq(cT.status, "active"), deq(cT.status, "bank"), deq(cT.status, "casino")),
          dnn(cT.price)
        ))
        .orderBy(desc(cT.price)).limit(100);
    }),

    /** Play a pack rip — costs credits, returns real house card as prize */
    playPackRip: protectedProcedure
      .input(z.object({ packType: z.enum(["standard", "premium", "elite"]) }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new Error("DB unavailable");

        // Max 10 credits per pack
        const PACK_COST = { standard: 5, premium: 8, elite: 10 };
        const cost = PACK_COST[input.packType];

        // Check credits
        const [acct] = await db.select().from(creditAccounts).where(eq(creditAccounts.userEmail, ctx.user.email!)).limit(1);
        if (!acct || acct.credits < cost) throw new Error("Not enough credits");

        // Deduct credits upfront
        await db.update(creditAccounts).set({ credits: acct.credits - cost }).where(eq(creditAccounts.id, acct.id));

        // ── Fetch real house cards (top 100 by value: active + casino + bank) ───
        const { cards: cT } = await import("../drizzle/schema");
        const { or: dor, eq: deq, and: dand, isNotNull: dnn } = await import("drizzle-orm");
        const houseCards = await db.select().from(cT)
          .where(dand(
            dor(deq(cT.status, "active"), deq(cT.status, "bank"), deq(cT.status, "casino")),
            dnn(cT.price)
          ))
          .orderBy(desc(cT.price)).limit(100);

        // Tier pools: elite=top10, premium=top50, standard=all100
        const tierPool = {
          elite:    houseCards.slice(0, Math.min(10, houseCards.length)),
          premium:  houseCards.slice(0, Math.min(50, houseCards.length)),
          standard: houseCards,
        }[input.packType];

        // ── Odds scale with pack tier ───────────────────────────────────────────
        const ODDS = {
          standard: { jackpot: 0.001, miniJackpot: 0.005, cardPrize: 0.04, rare: 0.03, uncommon: 0.13 },
          premium:  { jackpot: 0.003, miniJackpot: 0.015, cardPrize: 0.08, rare: 0.05, uncommon: 0.15 },
          elite:    { jackpot: 0.008, miniJackpot: 0.030, cardPrize: 0.15, rare: 0.07, uncommon: 0.17 },
        }[input.packType];

        const roll = Math.random();
        type OutcomeType = "jackpot" | "mini_jackpot" | "card_prize" | "credits" | "bust";
        let result: { outcome: OutcomeType; creditsWon: number; label: string; emoji: string; prizeCardId?: number };
        let cumulative = 0;

        if (roll < (cumulative += ODDS.jackpot) && houseCards.length > 0) {
          // MEGA JACKPOT — the single most valuable card
          result = { outcome: "jackpot", creditsWon: 0, label: `💎 MEGA JACKPOT! ${houseCards[0].playerName} is yours!`, emoji: "💎", prizeCardId: houseCards[0].id };
        } else if (roll < (cumulative += ODDS.miniJackpot) && houseCards.length > 1) {
          // MINI JACKPOT — random from top 10
          const pool = houseCards.slice(0, Math.min(10, houseCards.length));
          const picked = pool[Math.floor(Math.random() * pool.length)];
          result = { outcome: "mini_jackpot", creditsWon: 0, label: `🏆 MINI JACKPOT! ${picked.playerName} is yours!`, emoji: "🏆", prizeCardId: picked.id };
        } else if (roll < (cumulative += ODDS.cardPrize) && tierPool.length > 0) {
          // Card prize — random from tier pool
          const picked = tierPool[Math.floor(Math.random() * tierPool.length)];
          result = { outcome: "card_prize", creditsWon: 0, label: `🃏 Card Win! ${picked.playerName}!`, emoji: "🃏", prizeCardId: picked.id };
        } else if (roll < (cumulative += ODDS.rare)) {
          const mult = 1.6 + Math.random() * 0.4;
          const won = Math.floor(cost * mult);
          result = { outcome: "credits", creditsWon: won, label: `⭐ Rare Pull! +${won} credits`, emoji: "⭐" };
        } else if (roll < (cumulative += ODDS.uncommon)) {
          const mult = 0.8 + Math.random() * 0.4;
          const won = Math.floor(cost * mult);
          result = { outcome: "credits", creditsWon: won, label: `✨ Nice Pull! +${won} credits`, emoji: "✨" };
        } else {
          const mult = 0.1 + Math.random() * 0.4;
          const won = Math.max(0, Math.floor(cost * mult));
          result = won > 0
            ? { outcome: "credits", creditsWon: won, label: `+${won} credits`, emoji: "🃏" }
            : { outcome: "bust", creditsWon: 0, label: "No pull this time", emoji: "😔" };
        }

        // Credit back if credits won
        let newBalance = acct.credits - cost;
        if (result.creditsWon > 0) {
          newBalance = acct.credits - cost + result.creditsWon;
          await db.update(creditAccounts).set({ credits: newBalance }).where(eq(creditAccounts.id, acct.id));
        }

        // Resolve prize card details
        let prizeCard: typeof houseCards[0] | null = null;
        if (result.prizeCardId) {
          prizeCard = houseCards.find(c => c.id === result.prizeCardId) ?? null;
        }

        // Fallback: if card win but no house cards, give credits instead
        if ((result.outcome === "jackpot" || result.outcome === "mini_jackpot" || result.outcome === "card_prize") && !prizeCard) {
          const fallback = cost * 3;
          newBalance = acct.credits - cost + fallback;
          await db.update(creditAccounts).set({ credits: newBalance }).where(eq(creditAccounts.id, acct.id));
          result = { outcome: "credits", creditsWon: fallback, label: `+${fallback} credits`, emoji: "🃏" };
        }

        // Log the play
        await db.insert(gamePlays).values({
          userId: ctx.user.id, gameType: "pack_rip",
          creditsSpent: cost, creditsWon: result.creditsWon,
          outcome: result.outcome,
          outcomeData: { ...result, prizeCardId: result.prizeCardId, packType: input.packType },
        });

        return {
          outcome: result.outcome, label: result.label, emoji: result.emoji,
          creditsWon: result.creditsWon, creditsSpent: cost, newBalance,
          prizeCard: prizeCard ? {
            id: prizeCard.id, playerName: prizeCard.playerName,
            year: prizeCard.year ?? "", setName: prizeCard.setName ?? "",
            gradeScore: prizeCard.gradeScore ?? null, gradeCompany: prizeCard.gradeCompany ?? null,
            frontImageUrl: prizeCard.frontImageUrl ?? null,
            price: prizeCard.price ? parseFloat(String(prizeCard.price)) : 0,
          } : null,
        };
      }),

    /**
     * Claim a card won in ANY game (Pack Rip, Blackjack jackpot, Roulette, Spin Wheel, etc.)
     * choice = "credits" → award card value as credits, mark card casino-reserved
     * choice = "vault"   → add to winner's SCO Vault collection, hold physically at SCO
     * choice = "ship"    → create shipping order ($4.99 fee), notify admin to ship
     */
    claimCardPrize: protectedProcedure
      .input(z.object({
        cardId: z.number(),
        choice: z.enum(["credits", "vault", "ship"]),
        shippingAddress: z.string().optional(),
        shippingName: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "DB unavailable" });
        const { cards: cT, orders: oT, users: uT, userCollection: ucT } = await import("../drizzle/schema");
        const { eq: deq } = await import("drizzle-orm");

        const [card] = await db.select().from(cT).where(deq(cT.id, input.cardId)).limit(1);
        if (!card) throw new TRPCError({ code: "NOT_FOUND", message: "Card not found" });
        const cardValue = card.price ? parseFloat(String(card.price)) : 0;

        if (input.choice === "credits") {
          const creditsToAward = Math.max(1, Math.ceil(cardValue));
          const [acct] = await db.select().from(creditAccounts).where(eq(creditAccounts.userEmail, ctx.user.email!)).limit(1);
          if (acct) await db.update(creditAccounts).set({ credits: acct.credits + creditsToAward }).where(eq(creditAccounts.id, acct.id));
          await db.update(cT).set({ status: "casino" }).where(deq(cT.id, input.cardId));
          await notifyOwner({ title: "Card Won — Credits Taken", content: `${ctx.user.name || ctx.user.email} won card #${card.id} (${card.playerName}) and took ${creditsToAward} credits.` });
          return { success: true, creditsAwarded: creditsToAward, message: `+${creditsToAward} credits added to your account!` };

        } else if (input.choice === "vault") {
          const [user] = await db.select().from(uT).where(deq(uT.openId, ctx.user.openId)).limit(1);
          if (!user) throw new TRPCError({ code: "NOT_FOUND", message: "User not found" });
          await db.insert(ucT).values({
            userId: user.id,
            scpId: `game-win-${card.id}-${Date.now()}`,
            productName: card.title,
            consoleName: card.setName ?? "House Collection",
            priceInPennies: Math.round(cardValue * 100),
            condition: card.gradeScore ? `${card.gradeCompany} ${card.gradeScore}` : card.condition,
            imageUrl: card.frontImageUrl ?? undefined,
            imageBackUrl: card.backImageUrl ?? undefined,
            playerName: card.playerName,
            notes: `Won in SCO Game Room. Physically held at SCO facility (Vaulted).`,
          });
          await db.update(cT).set({ isVaulted: true, status: "casino" }).where(deq(cT.id, input.cardId));
          await notifyOwner({ title: "Card Won — Vaulted", content: `${ctx.user.name || ctx.user.email} won card #${card.id} (${card.playerName}) and chose to vault it.` });
          return { success: true, creditsAwarded: 0, message: `${card.playerName} added to your SCO Vault! We'll hold it safely for you.` };

        } else {
          if (!input.shippingAddress) throw new TRPCError({ code: "BAD_REQUEST", message: "Shipping address required" });
          const ticketNum = `SHIP-${Date.now().toString(36).toUpperCase()}`;
          await db.insert(oT).values({
            cardId: card.id,
            cardTitle: card.title,
            cardImageUrl: card.frontImageUrl ?? undefined,
            buyerEmail: ctx.user.email!,
            buyerName: input.shippingName || ctx.user.name || ctx.user.email!,
            sellerEmail: process.env.SMTP_FROM || "admin@sportcardsonline.com",
            sellerStoreName: "SCO House",
            price: "4.99", totalAmount: "4.99", platformFee: "0", sellerPayout: "0",
            status: "paid",
            shippingAddress: input.shippingAddress,
            fulfillmentPreference: "ship",
            ticketNumber: ticketNum,
          });
          await db.update(cT).set({ status: "casino" }).where(deq(cT.id, input.cardId));
          await notifyOwner({ title: `Card Won — Ship Request #${ticketNum}`, content: `${ctx.user.name || ctx.user.email} won card #${card.id} (${card.playerName}) — ship to: ${input.shippingAddress}. Ticket: ${ticketNum}` });
          return { success: true, creditsAwarded: 0, message: `Shipping order created! Ticket #${ticketNum}. We'll ship ${card.playerName} within 3-5 business days.` };
        }
      }),

    /** Spin the wheel — costs 10 credits */
    playSpin: protectedProcedure.mutation(async ({ ctx }) => {
      const db = await getDb();
      if (!db) throw new Error("DB unavailable");
      const cost = 10;
      const [acct] = await db.select().from(creditAccounts).where(eq(creditAccounts.userEmail, ctx.user.email!)).limit(1);
      if (!acct || acct.credits < cost) throw new Error("Not enough credits");
      await db.update(creditAccounts).set({ credits: acct.credits - cost }).where(eq(creditAccounts.id, acct.id));

      const roll = Math.random();
      const SEGMENTS = [
        { label: "2x Credits",    credits: 20,  color: "#f59e0b", probability: 0.20 },
        { label: "Bust",          credits: 0,   color: "#374151", probability: 0.25 },
        { label: "5 Credits",     credits: 5,   color: "#3b82f6", probability: 0.20 },
        { label: "15 Credits",    credits: 15,  color: "#10b981", probability: 0.15 },
        { label: "Bust",          credits: 0,   color: "#374151", probability: 0.10 },
        { label: "50 Credits!",   credits: 50,  color: "#8b5cf6", probability: 0.06 },
        { label: "MINI JACKPOT",  credits: 0,   color: "#ef4444", probability: 0.03 },
        { label: "MEGA JACKPOT",  credits: 0,   color: "#fbbf24", probability: 0.01 },
      ];
      let cumulative = 0;
      let landed = SEGMENTS[0];
      let segmentIndex = 0;
      for (let i = 0; i < SEGMENTS.length; i++) {
        cumulative += SEGMENTS[i].probability;
        if (roll <= cumulative) { landed = SEGMENTS[i]; segmentIndex = i; break; }
      }

      const outcome = landed.label.includes("JACKPOT") ? (landed.label.includes("MEGA") ? "jackpot" : "mini_jackpot") : landed.credits > 0 ? "credits" : "bust";
      if (landed.credits > 0) {
        await db.update(creditAccounts).set({ credits: acct.credits - cost + landed.credits }).where(eq(creditAccounts.id, acct.id));
      }
      await db.insert(gamePlays).values({
        userId: ctx.user.id, gameType: "spin_wheel", creditsSpent: cost,
        creditsWon: landed.credits, outcome, outcomeData: { segment: landed, segmentIndex },
      });
      return { segment: landed, segmentIndex, outcome, creditsWon: landed.credits, newBalance: acct.credits - cost + landed.credits };
    }),

    /** Claim a prize card — creates a prize_claims record and Stripe checkout for $2.50 shipping */
    claimPrize: protectedProcedure
      .input(z.object({
        cardTitle: z.string(),
        cardValue: z.number().optional(),
        gamePlayId: z.number().optional(),
        prizeVaultId: z.number().optional(),
        claimType: z.enum(["game_win", "showcase_redeem"]),
        creditsRedeemed: z.number().optional(),
        shippingName: z.string(),
        shippingAddress: z.string(),
        shippingCity: z.string(),
        shippingState: z.string(),
        shippingZip: z.string(),
        origin: z.string(),
      }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new Error("DB unavailable");

        // Insert prize claim record using raw SQL via drizzle's sql tag
        const { sql: sqlTag } = await import("drizzle-orm");
        await db.execute(sqlTag`
          INSERT INTO prize_claims (userId, gamePlayId, prizeVaultId, cardTitle, cardValue, claimType,
            shippingName, shippingAddress, shippingCity, shippingState, shippingZip,
            shippingPaid, shippingFee, status, creditsRedeemed)
          VALUES (
            ${ctx.user.id},
            ${input.gamePlayId ?? null},
            ${input.prizeVaultId ?? null},
            ${input.cardTitle},
            ${input.cardValue ?? 0},
            ${input.claimType},
            ${input.shippingName},
            ${input.shippingAddress},
            ${input.shippingCity},
            ${input.shippingState},
            ${input.shippingZip},
            0, 2.50, 'pending_payment',
            ${input.creditsRedeemed ?? 0}
          )
        `);

        // Create Stripe checkout for $2.50 shipping
        const Stripe = (await import("stripe")).default;
        const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, { apiVersion: "2025-01-27.acacia" });
        const session = await stripe.checkout.sessions.create({
          mode: "payment",
          customer_email: ctx.user.email!,
          line_items: [{
            price_data: {
              currency: "usd",
              product_data: {
                name: `Shipping: ${input.cardTitle}`,
                description: "Flat rate card shipping — SportCardsOnline.com",
              },
              unit_amount: 250, // $2.50
            },
            quantity: 1,
          }],
          success_url: `${input.origin}/game-room?shipping=paid`,
          cancel_url: `${input.origin}/game-room`,
          metadata: { userId: ctx.user.id.toString(), type: "shipping", cardTitle: input.cardTitle },
        });

        // Auto-add won card to user's collection as pending_gm
        const { collections } = await import("../drizzle/schema");
        const { eq } = await import("drizzle-orm");
        await db.insert(collections).values({
          ownerEmail: ctx.user.email!,
          cardTitle: input.cardTitle,
          playerName: input.cardTitle,
          sport: "basketball" as const,
          listingStatus: "pending_gm" as const,
          lifecycleNote: `Won via ${input.claimType === "game_win" ? "Game Room" : "Prize Showcase"} — awaiting shipment`,
          gameSource: input.claimType,
          estimatedValueLow: input.cardValue ? String(input.cardValue * 0.8) as unknown as any : undefined,
          estimatedValueHigh: input.cardValue ? String(input.cardValue) as unknown as any : undefined,
        });

        // Notify owner
        await notifyOwner({
          title: `New Prize Claim: ${input.cardTitle}`,
          content: `${ctx.user.name || ctx.user.email} won ${input.cardTitle} and submitted shipping to:\n${input.shippingName}\n${input.shippingAddress}\n${input.shippingCity}, ${input.shippingState} ${input.shippingZip}`,
        });

        return { success: true, checkoutUrl: session.url };
      }),

    /** Register for a tournament — deducts buy-in credits */
    registerTournament: protectedProcedure
      .input(z.object({ tournamentConfigId: z.string() }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new Error("DB unavailable");

        // Tournament configs (mirrors client-side gameEconomy.ts)
        const CONFIGS: Record<string, { buyInCredits: number; minSeats: number; name: string }> = {
          "micro-wta":    { buyInCredits: 5,   minSeats: 2, name: "Micro — Winner Take All" },
          "micro-top2":   { buyInCredits: 5,   minSeats: 2, name: "Micro — Top 2 Split" },
          "standard-top2":{ buyInCredits: 10,  minSeats: 3, name: "Standard — $10 Buy-In" },
          "standard-top3":{ buyInCredits: 10,  minSeats: 3, name: "Standard — $10 Top 3" },
          "mid-top3":     { buyInCredits: 35,  minSeats: 4, name: "Mid Stakes — $35 Buy-In" },
          "high-top3":    { buyInCredits: 50,  minSeats: 4, name: "High Roller — $50 Buy-In" },
          "elite-top3":   { buyInCredits: 100, minSeats: 4, name: "Elite — $100 Buy-In" },
        };

        const config = CONFIGS[input.tournamentConfigId];
        if (!config) throw new TRPCError({ code: "BAD_REQUEST", message: "Unknown tournament" });

        const [acct] = await db.select().from(creditAccounts)
          .where(eq(creditAccounts.userEmail, ctx.user.email!)).limit(1);
        if (!acct || acct.credits < config.buyInCredits)
          throw new TRPCError({ code: "FORBIDDEN", message: `Need ${config.buyInCredits} credits to register` });

        // Deduct buy-in
        await db.update(creditAccounts)
          .set({ credits: acct.credits - config.buyInCredits })
          .where(eq(creditAccounts.id, acct.id));

        // Log as a game play entry
        await db.insert(gamePlays).values({
          userId: ctx.user.id,
          gameType: "tournament",
          creditsSpent: config.buyInCredits,
          creditsWon: 0,
          outcome: "registered",
          outcomeData: { tournamentConfigId: input.tournamentConfigId, name: config.name },
        });

        return { success: true, minSeats: config.minSeats, name: config.name };
      }),

    /** Play American Roulette — max 5 credits total bet, 5.26% house edge */
    playRoulette: protectedProcedure
      .input(z.object({
        bets: z.array(z.object({
          bet: z.object({
            kind: z.enum(["straight", "color", "parity", "half", "dozen", "column"]),
            number: z.union([z.number(), z.literal("00")]).optional(),
            color: z.enum(["red", "black"]).optional(),
            parity: z.enum(["odd", "even"]).optional(),
            half: z.enum(["low", "high"]).optional(),
            dozen: z.union([z.literal(1), z.literal(2), z.literal(3)]).optional(),
            column: z.union([z.literal(1), z.literal(2), z.literal(3)]).optional(),
          }),
          amount: z.number().min(0.5).max(5),
        }))
      }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new Error("DB unavailable");
        const totalBet = input.bets.reduce((s, b) => s + b.amount, 0);
        if (totalBet > 5) throw new TRPCError({ code: "BAD_REQUEST", message: "Max total bet is 5 credits" });

        const [acct] = await db.select().from(creditAccounts).where(eq(creditAccounts.userEmail, ctx.user.email!)).limit(1);
        if (!acct || acct.credits < totalBet) throw new TRPCError({ code: "FORBIDDEN", message: "Not enough credits" });

        // Deduct bet
        await db.update(creditAccounts).set({ credits: acct.credits - totalBet }).where(eq(creditAccounts.id, acct.id));

        // Spin: pick random pocket from American wheel (38 pockets)
        const WHEEL_ORDER: (number | string)[] = [
          0, 28, 9, 26, 30, 11, 7, 20, 32, 17, 5, 22, 34, 15, 3, 24, 36, 13, 1,
          "00", 27, 10, 25, 29, 12, 8, 19, 31, 18, 6, 21, 33, 16, 4, 23, 35, 14, 2,
        ];
        const resultNumber = WHEEL_ORDER[Math.floor(Math.random() * 38)];
        const n = resultNumber;

        const reds = new Set([1,3,5,7,9,12,14,16,18,19,21,23,25,27,30,32,34,36]);
        function pocketColor(x: number | string) {
          if (x === 0 || x === "00") return "green";
          return reds.has(x as number) ? "red" : "black";
        }

        // Calculate winnings
        let winnings = 0;
        for (const { bet, amount } of input.bets) {
          let wins = false;
          switch (bet.kind) {
            case "straight": wins = bet.number === n; break;
            case "color": wins = n !== 0 && n !== "00" && pocketColor(n) === bet.color; break;
            case "parity": wins = n !== 0 && n !== "00" && (bet.parity === "odd" ? (n as number) % 2 !== 0 : (n as number) % 2 === 0); break;
            case "half": wins = n !== 0 && n !== "00" && (bet.half === "low" ? (n as number) <= 18 : (n as number) >= 19); break;
            case "dozen": {
              if (n === 0 || n === "00") break;
              const lo = ((bet.dozen ?? 1) - 1) * 12 + 1;
              wins = (n as number) >= lo && (n as number) <= lo + 11;
              break;
            }
            case "column": {
              if (n === 0 || n === "00") break;
              wins = (n as number) % 3 === ((bet.column ?? 1) === 3 ? 0 : (bet.column ?? 1));
              break;
            }
          }
          if (wins) {
            const payout = bet.kind === "straight" ? 35 : ["color","parity","half"].includes(bet.kind) ? 1 : 2;
            winnings += amount * (payout + 1); // return bet + profit
          }
        }

        const netWin = winnings - totalBet;
        // Round to integers for DB int columns (credits allow 0.5 bets but DB stores ints)
        const newBalanceInt = Math.round(acct.credits - totalBet + winnings);
        await db.update(creditAccounts).set({ credits: newBalanceInt }).where(eq(creditAccounts.id, acct.id));

        await db.insert(gamePlays).values({
          userId: ctx.user.id,
          gameType: "roulette",
          creditsSpent: Math.round(totalBet),
          creditsWon: Math.round(winnings),
          outcome: winnings > totalBet ? "credits" : winnings > 0 ? "credits" : "bust",
          outcomeData: { resultNumber, bets: input.bets, winnings: parseFloat(winnings.toFixed(2)), netWin: parseFloat(netWin.toFixed(2)) },
        });

        return { resultNumber, winnings: parseFloat(winnings.toFixed(2)), netWin: parseFloat(netWin.toFixed(2)), newBalance: newBalanceInt };
      }),

    /** Play Blackjack — max 10 credits, dealer stands on 17, natural pays 3:2 */
    playBlackjack: protectedProcedure
      .input(z.object({
        bet: z.number().min(1).max(10),
        action: z.enum(["deal", "hit", "stand", "double", "split"]),
        gameState: z.object({
          playerHand: z.array(z.object({ suit: z.string(), value: z.string() })).optional(),
          dealerHand: z.array(z.object({ suit: z.string(), value: z.string() })).optional(),
          deck: z.array(z.object({ suit: z.string(), value: z.string() })).optional(),
          phase: z.enum(["betting", "playing", "dealer", "result"]).optional(),
          doubled: z.boolean().optional(),
        }).optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new Error("DB unavailable");

        const [acct] = await db.select().from(creditAccounts).where(eq(creditAccounts.userEmail, ctx.user.email!)).limit(1);
        if (!acct) throw new TRPCError({ code: "NOT_FOUND", message: "Account not found" });

        const SUITS = ["♠","♥","♦","♣"];
        const VALUES = ["A","2","3","4","5","6","7","8","9","10","J","Q","K"];

        function freshDeck() {
          const d: {suit:string;value:string}[] = [];
          for (const s of SUITS) for (const v of VALUES) d.push({suit:s,value:v});
          // shuffle
          for (let i = d.length-1; i > 0; i--) { const j = Math.floor(Math.random()*(i+1)); [d[i],d[j]]=[d[j],d[i]]; }
          return d;
        }

        function cardVal(v: string): number {
          if (["J","Q","K"].includes(v)) return 10;
          if (v === "A") return 11;
          return parseInt(v);
        }

        function handValue(hand: {suit:string;value:string}[]): number {
          let total = 0, aces = 0;
          for (const c of hand) { total += cardVal(c.value); if (c.value === "A") aces++; }
          while (total > 21 && aces > 0) { total -= 10; aces--; }
          return total;
        }

        if (input.action === "deal") {
          if (acct.credits < input.bet) throw new TRPCError({ code: "FORBIDDEN", message: "Not enough credits" });
          const deck = freshDeck();
          const playerHand = [deck.pop()!, deck.pop()!];
          const dealerHand = [deck.pop()!, deck.pop()!];
          const playerVal = handValue(playerHand);
          const dealerVal = handValue(dealerHand);

          // Check for natural blackjack
          if (playerVal === 21) {
            const payout = dealerVal === 21 ? input.bet : Math.floor(input.bet * 2.5); // 3:2 pays 2.5x total
            const netChange = dealerVal === 21 ? 0 : payout - input.bet;
            const newBalance = acct.credits + netChange;
            await db.update(creditAccounts).set({ credits: newBalance }).where(eq(creditAccounts.id, acct.id));
            const outcome = dealerVal === 21 ? "push" : "blackjack";
            const dbOutcome1 = dealerVal === 21 ? "bust" as const : "credits" as const;
            await db.insert(gamePlays).values({ userId: ctx.user.id, gameType: "blackjack", creditsSpent: input.bet, creditsWon: outcome === "push" ? input.bet : payout, outcome: dbOutcome1, outcomeData: { playerHand, dealerHand, playerVal, dealerVal, outcome } });
            return { phase: "result" as const, playerHand, dealerHand, deck, playerVal, dealerVal, outcome, winnings: outcome === "push" ? 0 : netChange, newBalance };
          }

          // Deduct bet for normal hand
          await db.update(creditAccounts).set({ credits: acct.credits - input.bet }).where(eq(creditAccounts.id, acct.id));
          return { phase: "playing" as const, playerHand, dealerHand, deck, playerVal, dealerVal: null, outcome: null, winnings: null, newBalance: acct.credits - input.bet };
        }

        // Continuing hand — reconstruct state from client
        const gs = input.gameState;
        if (!gs?.playerHand || !gs?.dealerHand || !gs?.deck) throw new TRPCError({ code: "BAD_REQUEST", message: "Missing game state" });

        let { playerHand, dealerHand, deck } = gs as { playerHand: {suit:string;value:string}[]; dealerHand: {suit:string;value:string}[]; deck: {suit:string;value:string}[] };
        const doubled = gs.doubled ?? false;
        const effectiveBet = doubled ? input.bet * 2 : input.bet;

        if (input.action === "hit") {
          playerHand = [...playerHand, deck.pop()!];
          const pv = handValue(playerHand);
          if (pv > 21) {
            // Bust — bet already deducted
            await db.insert(gamePlays).values({ userId: ctx.user.id, gameType: "blackjack", creditsSpent: effectiveBet, creditsWon: 0, outcome: "bust", outcomeData: { playerHand, dealerHand, playerVal: pv } });
            return { phase: "result" as const, playerHand, dealerHand, deck, playerVal: pv, dealerVal: handValue(dealerHand), outcome: "bust", winnings: -effectiveBet, newBalance: acct.credits };
          }
          return { phase: "playing" as const, playerHand, dealerHand, deck, playerVal: pv, dealerVal: null, outcome: null, winnings: null, newBalance: acct.credits };
        }

        if (input.action === "double") {
          if (acct.credits < input.bet) throw new TRPCError({ code: "FORBIDDEN", message: "Not enough credits for double" });
          await db.update(creditAccounts).set({ credits: acct.credits - input.bet }).where(eq(creditAccounts.id, acct.id));
          playerHand = [...playerHand, deck.pop()!];
          const pv = handValue(playerHand);
          if (pv > 21) {
            await db.insert(gamePlays).values({ userId: ctx.user.id, gameType: "blackjack", creditsSpent: input.bet * 2, creditsWon: 0, outcome: "bust", outcomeData: { playerHand, dealerHand, playerVal: pv, doubled: true } });
            return { phase: "result" as const, playerHand, dealerHand, deck, playerVal: pv, dealerVal: handValue(dealerHand), outcome: "bust", winnings: -(input.bet * 2), newBalance: acct.credits - input.bet };
          }
          // Fall through to dealer play
          input.action = "stand";
        }

        // Stand or after double — dealer plays
        const pv = handValue(playerHand);
        while (handValue(dealerHand) < 17) dealerHand = [...dealerHand, deck.pop()!];
        const dv = handValue(dealerHand);

        let outcome: string;
        let winnings: number;
        if (dv > 21 || pv > dv) { outcome = "win"; winnings = effectiveBet; } // player wins
        else if (pv === dv) { outcome = "push"; winnings = 0; } // push — return bet
        else { outcome = "lose"; winnings = -effectiveBet; } // dealer wins

        const newBalance = acct.credits + (outcome === "push" ? effectiveBet : outcome === "win" ? effectiveBet * 2 : 0);
        await db.update(creditAccounts).set({ credits: newBalance }).where(eq(creditAccounts.id, acct.id));
        const dbOutcome2 = outcome === "win" ? "credits" as const : outcome === "push" ? "bust" as const : "bust" as const;
        await db.insert(gamePlays).values({ userId: ctx.user.id, gameType: "blackjack", creditsSpent: effectiveBet, creditsWon: outcome === "win" ? effectiveBet * 2 : outcome === "push" ? effectiveBet : 0, outcome: dbOutcome2, outcomeData: { playerHand, dealerHand, playerVal: pv, dealerVal: dv, doubled, outcome } });

        return { phase: "result" as const, playerHand, dealerHand, deck, playerVal: pv, dealerVal: dv, outcome, winnings, newBalance };
      }),

    /** Free daily spin — no credits required, one per day per user */
    freeSpin: protectedProcedure.mutation(async ({ ctx }) => {
      const db = await getDb();
      if (!db) throw new Error("DB unavailable");
      // Check if user already spun today
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      const recentSpins = await db.select().from(gamePlays)
        .where(eq(gamePlays.userId, ctx.user.id))
        .orderBy(desc(gamePlays.createdAt))
        .limit(10);
      const spunToday = recentSpins.some(s => s.gameType === "free_spin" && new Date(s.createdAt) >= today);
      if (spunToday) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "You already used your free spin today. Come back tomorrow!" });
      }
      // Free spin segments with probabilities
      const SPIN_SEGS = [
        { label: "5 Credits",    credits: 5,   probability: 0.30, type: "credits" },
        { label: "Try Again",    credits: 0,   probability: 0.25, type: "none" },
        { label: "10 Credits",   credits: 10,  probability: 0.20, type: "credits" },
        { label: "Try Again",    credits: 0,   probability: 0.10, type: "none" },
        { label: "25 Credits",   credits: 25,  probability: 0.08, type: "credits" },
        { label: "50 Credits!",  credits: 50,  probability: 0.04, type: "credits" },
        { label: "Try Again",    credits: 0,   probability: 0.01, type: "none" },
        { label: "100 Credits!", credits: 100, probability: 0.015, type: "credits" },
        { label: "Try Again",    credits: 0,   probability: 0.005, type: "none" },
        { label: "JACKPOT! 🏆",  credits: 500, probability: 0.005, type: "jackpot" },
        { label: "Try Again",    credits: 0,   probability: 0.005, type: "none" },
        { label: "15 Credits",   credits: 15,  probability: 0.005, type: "credits" },
      ];
      const roll = Math.random();
      let cumulative = 0;
      let landed = SPIN_SEGS[0];
      let segmentIndex = 0;
      for (let i = 0; i < SPIN_SEGS.length; i++) {
        cumulative += SPIN_SEGS[i].probability;
        if (roll <= cumulative) { landed = SPIN_SEGS[i]; segmentIndex = i; break; }
      }
      // Award credits if won
      if (landed.credits > 0) {
        const [acct] = await db.select().from(creditAccounts).where(eq(creditAccounts.userEmail, ctx.user.email!)).limit(1);
        if (acct) {
          await db.update(creditAccounts).set({ credits: acct.credits + landed.credits }).where(eq(creditAccounts.id, acct.id));
        }
      }
      await db.insert(gamePlays).values({
        userId: ctx.user.id, gameType: "free_spin", creditsSpent: 0,
        creditsWon: landed.credits, outcome: landed.type === "jackpot" ? "jackpot" : landed.credits > 0 ? "credits" : "bust",
        outcomeData: { segment: landed, segmentIndex },
      });
      return { segment: landed, segmentIndex, outcome: landed.type, creditsWon: landed.credits };
    }),

    /** Get user's game history */
    myHistory: protectedProcedure.query(async ({ ctx }) => {
      const db = await getDb();
      if (!db) return [];
      return db.select().from(gamePlays)
        .where(eq(gamePlays.userId, ctx.user.id))
        .orderBy(desc(gamePlays.createdAt))
        .limit(20);
    }),

    /**
     * Get the user's free card play status:
     * - How many free cards used today (max 2)
     * - Time until next free card is available (30-min cooldown)
     * - The next available house card to win ($1-$10 value)
     */
    getFreeCardStatus: protectedProcedure.query(async ({ ctx }) => {
      const db = await getDb();
      if (!db) return { playsToday: 0, maxPerDay: 2, nextPlayAt: null, canPlay: true, nextCard: null };
      const { cards: cT } = await import("../drizzle/schema");
      const { and: dand, gte: dgte, lte: dlte, eq: deq, or: dor, isNotNull: dnn, gte: dgte2 } = await import("drizzle-orm");
      const now = new Date();
      const startOfDay = new Date(now);
      startOfDay.setHours(0, 0, 0, 0);
      const endOfDay = new Date(now);
      endOfDay.setHours(23, 59, 59, 999);
      // Count plays today
      const todayPlays = await db.select().from(freeCardPlays)
        .where(dand(
          deq(freeCardPlays.userId, ctx.user.id),
          dgte(freeCardPlays.playedAt, startOfDay),
          dlte(freeCardPlays.playedAt, endOfDay)
        ));
      const playsToday = todayPlays.length;
      // Find last play time for cooldown
      const lastPlay = todayPlays.sort((a, b) => b.playedAt.getTime() - a.playedAt.getTime())[0];
      const cooldownMs = 30 * 60 * 1000; // 30 minutes
      let nextPlayAt: Date | null = null;
      let canPlay = playsToday < 2;
      if (lastPlay && playsToday < 2) {
        const timeSinceLast = now.getTime() - lastPlay.playedAt.getTime();
        if (timeSinceLast < cooldownMs) {
          canPlay = false;
          nextPlayAt = new Date(lastPlay.playedAt.getTime() + cooldownMs);
        }
      }
      // Get a random house card valued $1-$10 from casino/bank/active inventory
      let nextCard = null;
      if (canPlay) {
        const houseCandidates = await db.select({
          id: cT.id, title: cT.title, playerName: cT.playerName, year: cT.year,
          frontImageUrl: cT.frontImageUrl, price: cT.price, sport: cT.sport,
          gradeScore: cT.gradeScore, gradeCompany: cT.gradeCompany,
        }).from(cT)
          .where(dand(
            dor(deq(cT.status, "casino"), deq(cT.status, "bank")),
            dnn(cT.price),
            dgte(cT.price, "1.00"),
            dlte(cT.price, "10.00"),
          ))
          .limit(50);
        if (houseCandidates.length > 0) {
          nextCard = houseCandidates[Math.floor(Math.random() * houseCandidates.length)];
        }
      }
      return { playsToday, maxPerDay: 2, nextPlayAt, canPlay, nextCard };
    }),

    /**
     * Claim a free card play — distributes a random house card ($1-$10) to the user's collection.
     * Enforces: max 2 per day, 30-min cooldown between plays.
     */
    claimFreeCard: protectedProcedure.mutation(async ({ ctx }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      const { cards: cT } = await import("../drizzle/schema");
      const { and: dand, gte: dgte, lte: dlte, eq: deq, or: dor, isNotNull: dnn } = await import("drizzle-orm");
      const now = new Date();
      const startOfDay = new Date(now);
      startOfDay.setHours(0, 0, 0, 0);
      const endOfDay = new Date(now);
      endOfDay.setHours(23, 59, 59, 999);
      // Check daily limit
      const todayPlays = await db.select().from(freeCardPlays)
        .where(dand(
          deq(freeCardPlays.userId, ctx.user.id),
          dgte(freeCardPlays.playedAt, startOfDay),
          dlte(freeCardPlays.playedAt, endOfDay)
        ));
      if (todayPlays.length >= 2) {
        throw new TRPCError({ code: "TOO_MANY_REQUESTS", message: "You've used both free cards for today. Come back tomorrow!" });
      }
      // Check 30-min cooldown
      const lastPlay = todayPlays.sort((a, b) => b.playedAt.getTime() - a.playedAt.getTime())[0];
      if (lastPlay) {
        const timeSinceLast = now.getTime() - lastPlay.playedAt.getTime();
        const cooldownMs = 30 * 60 * 1000;
        if (timeSinceLast < cooldownMs) {
          const waitMins = Math.ceil((cooldownMs - timeSinceLast) / 60000);
          throw new TRPCError({ code: "TOO_MANY_REQUESTS", message: `Please wait ${waitMins} more minute${waitMins !== 1 ? 's' : ''} before your next free card.` });
        }
      }
      // Pick a random house card $1-$10
      const houseCandidates = await db.select().from(cT)
        .where(dand(
          dor(deq(cT.status, "casino"), deq(cT.status, "bank")),
          dnn(cT.price),
          dgte(cT.price, "1.00"),
          dlte(cT.price, "10.00"),
        ))
        .limit(50);
      if (houseCandidates.length === 0) {
        throw new TRPCError({ code: "NOT_FOUND", message: "No free cards available right now. Check back soon!" });
      }
      const card = houseCandidates[Math.floor(Math.random() * houseCandidates.length)];
      // Record the free play
      await db.insert(freeCardPlays).values({
        userId: ctx.user.id,
        cardId: card.id,
        cardTitle: card.title,
        cardValue: card.price!,
        claimed: true,
        claimedAt: now,
      });
      // Add card to user's collection
      const { collections } = await import("../drizzle/schema");
      await db.insert(collections).values({
        ownerEmail: ctx.user.email!,
        cardTitle: card.title,
        playerName: card.playerName,
        year: card.year || undefined,
        setName: card.setName || undefined,
        cardNumber: card.cardNumber || undefined,
        sport: card.sport,
        frontImageUrl: card.frontImageUrl || undefined,
        backImageUrl: card.backImageUrl || undefined,
        overallGrade: card.aiGrade ? String(card.aiGrade) : undefined,
        gradeLabel: card.aiGradeLabel || undefined,
        estimatedValueLow: card.price || undefined,
        estimatedValueHigh: card.price || undefined,
        listingStatus: "none",
        gameSource: "free_card_play",
      });
      // Mark the source card as sold/distributed
      await db.update(cT).set({ status: "sold" }).where(deq(cT.id, card.id));
      return {
        success: true,
        card: {
          id: card.id,
          title: card.title,
          playerName: card.playerName,
          year: card.year,
          frontImageUrl: card.frontImageUrl,
          price: card.price,
          sport: card.sport,
          gradeScore: card.gradeScore,
          gradeCompany: card.gradeCompany,
        },
        playsRemaining: 1 - todayPlays.length,
      };
    }),
  }),

  // ============================================================================
  // FAVORITES
  // ============================================================================
  favorites: router({
    toggle: protectedProcedure
      .input(z.object({ cardId: z.number() }))
      .mutation(async ({ ctx, input }) => {
        return toggleFavorite(ctx.user.id, input.cardId);
      }),

    myIds: protectedProcedure.query(async ({ ctx }) => {
      return getFavoriteCardIds(ctx.user.id);
    }),

    myCards: protectedProcedure.query(async ({ ctx }) => {
      const rows = await getFavoriteCards(ctx.user.id);
      return rows.map((r: any) => r.card);
    }),
  }),

  // ============================================================================
  // PERSONALIZATION / INTERESTS
  // ============================================================================
  interests: router({
    track: protectedProcedure
      .input(z.object({
        playerName: z.string(),
        sport: z.string().nullable().optional(),
        avgPrice: z.number().nullable().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        await trackUserInterest(ctx.user.id, input.playerName, input.sport ?? null, input.avgPrice ?? null);
        return { success: true };
      }),

    myTop: protectedProcedure.query(async ({ ctx }) => {
      return getTopInterests(ctx.user.id, 10);
    }),

    personalizedFeed: protectedProcedure
      .input(z.object({ limit: z.number().optional() }))
      .query(async ({ ctx, input }) => {
        return getPersonalizedCards(ctx.user.id, input?.limit || 24);
      }),

    similarCards: publicProcedure
      .input(z.object({ playerName: z.string(), sport: z.string().optional(), price: z.number().optional(), limit: z.number().optional() }))
      .query(async ({ input }) => {
        const db = await getDb();
        if (!db) return [];
        const { cards } = await import("../drizzle/schema");
        const { eq: deq, and: dand, gte, lte, ne } = await import("drizzle-orm");
        const limit = input.limit || 8;
        const price = input.price || 0;
        // Same player first
        const samePlayer = await db.select().from(cards)
          .where(dand(deq(cards.status, "active"), deq(cards.playerName, input.playerName)))
          .orderBy(desc(cards.price))
          .limit(limit);
        if (samePlayer.length >= limit) return samePlayer;
        // Fill with similar price range (within 50% of price)
        const minP = (price * 0.5).toFixed(2);
        const maxP = (price * 1.5).toFixed(2);
        const similar = await db.select().from(cards)
          .where(dand(
            deq(cards.status, "active"),
            ne(cards.playerName, input.playerName),
            gte(cards.price, minP),
            lte(cards.price, maxP)
          ))
          .orderBy(desc(cards.price))
          .limit(limit - samePlayer.length);
        return [...samePlayer, ...similar];
      }),
  }),

  // ============================================================================
  // VAULT
  // ============================================================================
  vault: router({
    // List all vaulted cards for the current user
    list: protectedProcedure.query(async ({ ctx }) => {
      const db = await getDb();
      if (!db) return [];
      const { collections } = await import("../drizzle/schema");
      const { eq, inArray } = await import("drizzle-orm");
      const vaultStatuses = ["vaulted", "vault_listed", "vault_auction", "vault_sold", "vault_shipped"] as const;
      const all = await db.select().from(collections)
        .where(eq(collections.ownerEmail, ctx.user.email!))
        .orderBy(desc(collections.createdAt));
      return all.filter(c => vaultStatuses.includes(c.listingStatus as any));
    }),

    // Move a collection card to vault
    moveToVault: protectedProcedure
      .input(z.object({
        collectionId: z.number(),
        source: z.enum(["game_room_win", "user_deposited"]).default("game_room_win"),
        shippingFee: z.number().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
        const { collections } = await import("../drizzle/schema");
        const { eq } = await import("drizzle-orm");
        await db.update(collections)
          .set({
            listingStatus: "vaulted",
            vaultSource: input.source,
            shippingFee: (input.shippingFee ?? 9.99).toFixed(2) as any,
            lifecycleNote: `Card moved to SCO Vault (${input.source === "game_room_win" ? "Game Room Win" : "User Deposited"}). Stored and shipped by SportCards Online.`,
          })
          .where(eq(collections.id, input.collectionId));
        return { success: true };
      }),

    // Alias for list — used by My Collection VAULT tab
    myVault: protectedProcedure.query(async ({ ctx }) => {
      const db = await getDb();
      if (!db) return [];
      const { collections } = await import("../drizzle/schema");
      const { eq } = await import("drizzle-orm");
      const vaultStatuses = ["vaulted", "vault_listed", "vault_auction", "vault_sold", "vault_shipped"] as const;
      const all = await db.select().from(collections)
        .where(eq(collections.ownerEmail, ctx.user.email!))
        .orderBy(desc(collections.createdAt));
      return all.filter((c: any) => vaultStatuses.includes(c.listingStatus as any));
    }),

    // Request ship-to-me for a vaulted card
    requestShipToMe: protectedProcedure
      .input(z.object({
        collectionId: z.number(),
        name: z.string(),
        address: z.string(),
        city: z.string(),
        state: z.string(),
        zip: z.string(),
        country: z.string().default("US"),
      }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
        const { collections } = await import("../drizzle/schema");
        const { eq } = await import("drizzle-orm");
        const shippingNote = `Ship-to-me: ${input.name}, ${input.address}, ${input.city}, ${input.state} ${input.zip}, ${input.country}`;
        await db.update(collections)
          .set({ listingStatus: "vault_shipped" as any, lifecycleNote: shippingNote })
          .where(eq(collections.id, input.collectionId));
        await notifyOwner({
          title: "\uD83D\uDE9A Vault Ship-to-Me Request",
          content: `User ${ctx.user.email} requested shipping of item #${input.collectionId}: ${shippingNote}`,
        });
        return { success: true };
      }),

    // List a vaulted card on the marketplace
    listVaultCard: protectedProcedure
      .input(z.object({ collectionId: z.number(), price: z.string() }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
        const { collections, cards } = await import("../drizzle/schema");
        const { eq } = await import("drizzle-orm");
        // Get the collection item
        const [item] = await db.select().from(collections).where(eq(collections.id, input.collectionId)).limit(1);
        if (!item || item.ownerEmail !== ctx.user.email) throw new TRPCError({ code: "FORBIDDEN" });
        // Create a marketplace listing with isVaulted=true
        await db.insert(cards).values({
          title: item.cardTitle,
          playerName: item.playerName,
          year: item.year ?? undefined,
          setName: item.setName ?? undefined,
          sport: item.sport,
          condition: "graded" as any,
          frontImageUrl: item.frontImageUrl ?? undefined,
          backImageUrl: item.backImageUrl ?? undefined,
          price: input.price as any,
          status: "active" as any,
          sellerEmail: ctx.user.email,
          showSlabView: true,
          isVaulted: true,
          cardShippingFee: "9.99" as any,
          description: "This card is physically stored and shipped by SportCards Online. SCO Vault Guarantee applies.",
        });
        // Update collection status
        await db.update(collections)
          .set({ listingStatus: "vault_listed" as any, lifecycleNote: `Listed on Marketplace at $${input.price} — SCO Vaulted & Guaranteed` })
          .where(eq(collections.id, input.collectionId));
        return { success: true };
      }),

    // Send a vaulted card to auction
    auctionVaultCard: protectedProcedure
      .input(z.object({ collectionId: z.number(), startingPrice: z.string(), durationDays: z.number().default(7) }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
        const { collections } = await import("../drizzle/schema");
        const { eq } = await import("drizzle-orm");
        await db.update(collections)
          .set({ listingStatus: "vault_auction" as any, lifecycleNote: `Auction starting at $${input.startingPrice} for ${input.durationDays} days — SCO Vaulted & Guaranteed` })
          .where(eq(collections.id, input.collectionId));
        return { success: true };
      }),

    // Sell a vaulted card for player credits (10% vault fee)
    // Card returns to House collection and gets auto-listed at auction (75% min bid / 125% buy-now, 3-day relist)
    sellForCredits: protectedProcedure
      .input(z.object({ collectionId: z.number() }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
        const { collections, cards: cardsTable } = await import("../drizzle/schema");
        const { eq } = await import("drizzle-orm");

        // 1. Fetch the collection item
        const [item] = await db.select().from(collections).where(eq(collections.id, input.collectionId)).limit(1);
        if (!item) throw new TRPCError({ code: "NOT_FOUND", message: "Vault item not found" });
        if (item.ownerEmail !== ctx.user.email!) throw new TRPCError({ code: "FORBIDDEN" });
        if (item.listingStatus !== "vaulted") throw new TRPCError({ code: "BAD_REQUEST", message: "Card must be in vault to exchange for credits" });

        // 2. Determine card value
        const rawValue = parseFloat(item.estimatedValueHigh ?? item.estimatedValueLow ?? "0");
        if (rawValue <= 0) throw new TRPCError({ code: "BAD_REQUEST", message: "Card has no estimated value. Please set a value first." });

        // 3. Apply 10% vault fee — user gets 90%
        const creditValue = Math.floor(rawValue * 0.9);

        // 4. Add credits to user account
        await addCredits(ctx.user.email!, creditValue, `Vault card exchange: ${item.cardTitle} (10% vault fee on $${rawValue.toFixed(2)})`);

        // 5. Mark collection item as vault_sold
        await db.update(collections)
          .set({
            listingStatus: "vault_sold" as any,
            lifecycleNote: `Exchanged for ${creditValue} credits (10% vault fee on $${rawValue.toFixed(2)})`
          })
          .where(eq(collections.id, input.collectionId));

        // 6. If there's a linked card, transfer to House and auto-auction it
        if (item.linkedCardId) {
          const HOUSE_EMAIL = process.env.OWNER_NAME ? `${process.env.OWNER_NAME}@sportcardsonline.com` : "house@sportcardsonline.com";
          const minBid = Math.round(rawValue * 0.75 * 100) / 100;
          const buyNow = Math.round(rawValue * 1.25 * 100) / 100;

          await db.update(cardsTable)
            .set({
              sellerEmail: HOUSE_EMAIL,
              price: minBid.toFixed(2),
              buyNowPrice: buyNow.toFixed(2),
              status: "auction" as any,
              isVaulted: true,
              description: `SCO House Vault Auction — Min Bid: $${minBid.toFixed(2)} | Buy Now: $${buyNow.toFixed(2)}`,
            })
            .where(eq(cardsTable.id, item.linkedCardId));

          const [card] = await db.select().from(cardsTable).where(eq(cardsTable.id, item.linkedCardId)).limit(1);
          if (card) {
            const endTime = new Date(Date.now() + 3 * 24 * 60 * 60 * 1000);
            await createAuction({
              cardId: card.id,
              cardTitle: card.title,
              cardImageUrl: card.frontImageUrl ?? undefined,
              sellerEmail: HOUSE_EMAIL,
              storeName: "SCO House",
              startingPrice: minBid.toFixed(2),
              currentBid: "0.00",
              bidCount: 0,
              endTime,
              status: "active",
              playerName: card.playerName,
              gradeInfo: card.aiGradeLabel ?? undefined,
              durationDays: 3,
              listingCreditsPaid: 0,
              buyNowPrice: buyNow.toFixed(2),
              minBidPrice: minBid.toFixed(2),
              autoRenew: true,
              renewCount: 0,
              isVaulted: true,
            });
          }
        }

        return { success: true, creditsAwarded: creditValue, cardValue: rawValue };
      }),

    // Update vault card status (for shipping updates)
    updateStatus: protectedProcedure
      .input(z.object({
        collectionId: z.number(),
        status: z.enum(["vaulted", "vault_listed", "vault_auction", "vault_sold", "vault_shipped"]),
        trackingNumber: z.string().optional(),
        lifecycleNote: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
        const { collections } = await import("../drizzle/schema");
        const { eq } = await import("drizzle-orm");
        const updates: Record<string, unknown> = { listingStatus: input.status };
        if (input.trackingNumber) updates.trackingNumber = input.trackingNumber;
        if (input.lifecycleNote) updates.lifecycleNote = input.lifecycleNote;
        await db.update(collections).set(updates as any).where(eq(collections.id, input.collectionId));
        return { success: true };
      }),
  }),
  // ============================================================================
  // SPORTS DATA (Game Times + Ticker News)
  // ============================================================================
  sportsData: router({
  // Returns today's games across all major leagues, prioritized by season
  gamesToday: publicProcedure.query(async () => {
    const month = new Date().getMonth() + 1;
    type GameEntry = { league: string; leagueLabel: string; home: string; away: string; homeScore?: string; awayScore?: string; status: string; time: string; isLive: boolean; isRanked?: boolean; homeRank?: number; awayRank?: number };
    const results: GameEntry[] = [];

    const fetchScoreboard = async (url: string, leagueLabel: string, ranked = false) => {
      try {
        const res = await fetch(url);
        if (!res.ok) return;
        const data = await res.json() as any;
        const events = (data.events || []) as any[];
        for (const e of events.slice(0, 8)) {
          const comp = e.competitions?.[0];
          if (!comp) continue;
          const teams = comp.competitors || [];
          const home = teams.find((t: any) => t.homeAway === "home") || teams[0];
          const away = teams.find((t: any) => t.homeAway === "away") || teams[1];
          if (!home || !away) continue;
          const statusType = e.status?.type?.name || "";
          const statusDesc = e.status?.type?.description || "Scheduled";
          const isLive = statusType === "STATUS_IN_PROGRESS" || statusType === "STATUS_HALFTIME";
          const isFinal = statusType === "STATUS_FINAL";
          const gameDate = new Date(e.date);
          const timeStr = isFinal ? "Final" : isLive ? "LIVE" : gameDate.toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit", timeZoneName: "short" });
          const homeRank = ranked ? (home.curatedRank?.current || home.rank || undefined) : undefined;
          const awayRank = ranked ? (away.curatedRank?.current || away.rank || undefined) : undefined;
          results.push({
            league: leagueLabel,
            leagueLabel,
            home: home.team?.abbreviation || home.team?.shortDisplayName || "?",
            away: away.team?.abbreviation || away.team?.shortDisplayName || "?",
            homeScore: home.score,
            awayScore: away.score,
            status: statusDesc,
            time: timeStr,
            isLive,
            isRanked: ranked,
            homeRank: homeRank && homeRank <= 25 ? homeRank : undefined,
            awayRank: awayRank && awayRank <= 25 ? awayRank : undefined,
          });
        }
      } catch { /* ignore */ }
    };

    // Priority order based on month
    const fetches: Array<Promise<void>> = [];

    // NCAA Men's Basketball (March-April: Final Four season)
    if (month >= 11 || month <= 4) {
      fetches.push(fetchScoreboard("https://site.api.espn.com/apis/site/v2/sports/basketball/mens-college-basketball/scoreboard?limit=12&groups=50", "NCAA Men's", true));
    }
    // NCAA Women's Basketball
    if (month >= 11 || month <= 4) {
      fetches.push(fetchScoreboard("https://site.api.espn.com/apis/site/v2/sports/basketball/womens-college-basketball/scoreboard?limit=8&groups=50", "NCAA Women's", true));
    }
    // MLB (April-October)
    if (month >= 3 && month <= 10) {
      fetches.push(fetchScoreboard("https://site.api.espn.com/apis/site/v2/sports/baseball/mlb/scoreboard?limit=10", "MLB"));
    }
    // NHL (October-June)
    if (month >= 10 || month <= 6) {
      fetches.push(fetchScoreboard("https://site.api.espn.com/apis/site/v2/sports/hockey/nhl/scoreboard?limit=10", "NHL"));
    }
    // NBA (October-June)
    if (month >= 10 || month <= 6) {
      fetches.push(fetchScoreboard("https://site.api.espn.com/apis/site/v2/sports/basketball/nba/scoreboard?limit=10", "NBA"));
    }
    // NFL (September-February)
    if (month >= 9 || month <= 2) {
      fetches.push(fetchScoreboard("https://site.api.espn.com/apis/site/v2/sports/football/nfl/scoreboard?limit=10", "NFL"));
    }
    // College Football (August-January)
    if (month >= 8 || month <= 1) {
      fetches.push(fetchScoreboard("https://site.api.espn.com/apis/site/v2/sports/football/college-football/scoreboard?limit=10&groups=80", "CFB", true));
    }
    // MLS / US Soccer (March-October)
    if (month >= 3 && month <= 10) {
      fetches.push(fetchScoreboard("https://site.api.espn.com/apis/site/v2/sports/soccer/usa.1/scoreboard?limit=8", "MLS"));
    }

    await Promise.all(fetches);
    return results;
  }),

  // Returns top sports headlines for the ticker
  tickerNews: publicProcedure.query(async () => {
    type NewsItem = { type: string; text: string; league?: string };
    const items: NewsItem[] = [];

    // Card release dates (static, curated)
    const cardReleases: NewsItem[] = [
      { type: "release", text: "🃏 2025-26 Panini Prizm Basketball releasing soon — watch for Flagg & Bueckers RCs" },
      { type: "release", text: "🃏 2025 Topps Series 1 Baseball — Skenes & De La Cruz rookies in packs now" },
      { type: "release", text: "🃏 2025 Bowman Chrome Baseball — top prospect autos dropping this month" },
      { type: "release", text: "🃏 2025 Panini Contenders Football — Cam Ward & Travis Hunter RCs available" },
      { type: "release", text: "🃏 2025-26 Upper Deck Young Guns Hockey — Celebrini RC in Series 1" },
    ];
    items.push(...cardReleases);

    // Fetch live sports news
    const newsLeagues = [
      { url: "https://site.api.espn.com/apis/site/v2/sports/basketball/nba/news?limit=3", label: "NBA" },
      { url: "https://site.api.espn.com/apis/site/v2/sports/baseball/mlb/news?limit=3", label: "MLB" },
      { url: "https://site.api.espn.com/apis/site/v2/sports/basketball/mens-college-basketball/news?limit=3", label: "NCAA" },
      { url: "https://site.api.espn.com/apis/site/v2/sports/hockey/nhl/news?limit=2", label: "NHL" },
      { url: "https://site.api.espn.com/apis/site/v2/sports/football/nfl/news?limit=2", label: "NFL" },
    ];
    await Promise.all(newsLeagues.map(async ({ url, label }) => {
      try {
        const res = await fetch(url);
        if (!res.ok) return;
        const data = await res.json() as any;
        for (const a of (data.articles || []).slice(0, 3)) {
          if (a.headline) items.push({ type: "news", text: `📰 [${label}] ${a.headline}`, league: label });
        }
      } catch { /* ignore */ }
    }));

    return items;
  }),
  }),
  // ─── Public Blog procedures ──────────────────────────────────────────────────
  blog: router({
    listPosts: publicProcedure
      .input(z.object({ limit: z.number().optional(), offset: z.number().optional() }).optional())
      .query(async ({ input }) => {
        return listBlogPosts(input?.limit ?? 12, input?.offset ?? 0);
      }),
    getPost: publicProcedure
      .input(z.object({ slug: z.string() }))
      .query(async ({ input }) => {
        const post = await getBlogPostBySlug(input.slug);
        if (!post) throw new TRPCError({ code: "NOT_FOUND", message: "Post not found" });
        return post;
      }),
    trackView: publicProcedure
      .input(z.object({ postId: z.number(), referrer: z.string().optional() }))
      .mutation(async ({ input }) => {
        const { getDb } = await import("./db");
        const { sql } = await import("drizzle-orm");
        const db = await getDb();
        if (!db) return { ok: false };
        await db.execute(sql`UPDATE blog_posts SET view_count = view_count + 1, updatedAt = NOW() WHERE id = ${input.postId}`);
        const today = new Date().toISOString().slice(0, 10);
        await db.execute(
          sql`INSERT INTO content_metrics (post_id, date, views, referrer) VALUES (${input.postId}, ${today}, 1, ${input.referrer ?? null})
              ON DUPLICATE KEY UPDATE views = views + 1`
        );
        return { ok: true };
      }),
    trackClick: publicProcedure
      .input(z.object({ postId: z.number() }))
      .mutation(async ({ input }) => {
        const { getDb } = await import("./db");
        const { sql } = await import("drizzle-orm");
        const db = await getDb();
        if (!db) return { ok: false };
        await db.execute(sql`UPDATE blog_posts SET click_count = click_count + 1, updatedAt = NOW() WHERE id = ${input.postId}`);
        const today = new Date().toISOString().slice(0, 10);
        await db.execute(
          sql`INSERT INTO content_metrics (post_id, date, clicks) VALUES (${input.postId}, ${today}, 1)
              ON DUPLICATE KEY UPDATE clicks = clicks + 1`
        );
        return { ok: true };
      }),
    getContentDashboard: protectedProcedure
      .query(async () => {
        const { getDb } = await import("./db");
        const { sql } = await import("drizzle-orm");
        const db = await getDb();
        if (!db) return { totals: {}, sportBreakdown: [], topPosts: [], dailyTrend: [], recentPosts: [] };
        // Total stats
        const totalsResult = await db.execute(sql`
          SELECT
            COUNT(*) as totalPosts,
            SUM(CASE WHEN status = 'published' THEN 1 ELSE 0 END) as publishedPosts,
            SUM(CASE WHEN videoStatus = 'ready' THEN 1 ELSE 0 END) as postsWithVideo,
            SUM(CASE WHEN youtubeVideoId IS NOT NULL THEN 1 ELSE 0 END) as postsOnYouTube,
            COALESCE(SUM(view_count), 0) as totalViews,
            COALESCE(SUM(click_count), 0) as totalClicks,
            SUM(CASE WHEN DATE(createdAt) = CURDATE() THEN 1 ELSE 0 END) as postsToday,
            SUM(CASE WHEN DATE(createdAt) >= DATE_SUB(CURDATE(), INTERVAL 7 DAY) THEN 1 ELSE 0 END) as postsThisWeek,
            SUM(CASE WHEN DATE(createdAt) >= DATE_SUB(CURDATE(), INTERVAL 30 DAY) THEN 1 ELSE 0 END) as postsThisMonth
          FROM blog_posts
        `) as any;
        // Sport breakdown
        const sportBreakdown = await db.execute(sql`
          SELECT sport, COUNT(*) as count, COALESCE(SUM(view_count), 0) as views
          FROM blog_posts
          WHERE sport IS NOT NULL
          GROUP BY sport
          ORDER BY count DESC
        `) as any;
        // Top posts by views
        const topPosts = await db.execute(sql`
          SELECT id, title, slug, sport, view_count, click_count, youtubeVideoId, coverImageUrl, publishedAt, videoStatus
          FROM blog_posts
          WHERE status = 'published'
          ORDER BY view_count DESC
          LIMIT 10
        `) as any;
        // Daily views trend (last 30 days)
        const dailyTrend = await db.execute(sql`
          SELECT date, SUM(views) as views, SUM(clicks) as clicks
          FROM content_metrics
          WHERE date >= DATE_FORMAT(DATE_SUB(CURDATE(), INTERVAL 29 DAY), '%Y-%m-%d')
          GROUP BY date
          ORDER BY date ASC
        `) as any;
        // Recent posts (last 10)
        const recentPosts = await db.execute(sql`
          SELECT id, title, slug, sport, status, videoStatus, youtubeVideoId, view_count, click_count, publishedAt, createdAt
          FROM blog_posts
          ORDER BY createdAt DESC
          LIMIT 10
        `) as any;
        return {
          totals: (totalsResult as any[])[0] ?? {},
          sportBreakdown: sportBreakdown as any[],
          topPosts: topPosts as any[],
          dailyTrend: dailyTrend as any[],
          recentPosts: recentPosts as any[],
        };
      }),
    getAudienceMetrics: protectedProcedure
      .query(async () => {
        const { getDb } = await import("./db");
        const { sql } = await import("drizzle-orm");
        const db = await getDb();
        if (!db) return { referralSources: [], topReferrers: [], sportViews: [], engagementRate: 0, totalViews: 0, totalClicks: 0, avgViewsPerPost: 0, postsWithViews: 0 };

        // Referral source breakdown — classify by referrer domain
        const referrerRows = await db.execute(sql`
          SELECT
            COALESCE(referrer, '') as referrer,
            SUM(views) as views,
            SUM(clicks) as clicks
          FROM content_metrics
          WHERE referrer IS NOT NULL OR referrer IS NULL
          GROUP BY referrer
        `) as any[];

        // Classify referrers into source categories
        const sourceMap: Record<string, { views: number; clicks: number }> = {
          Direct: { views: 0, clicks: 0 },
          Search: { views: 0, clicks: 0 },
          Social: { views: 0, clicks: 0 },
          Internal: { views: 0, clicks: 0 },
          Other: { views: 0, clicks: 0 },
        };
        const domainCount: Record<string, number> = {};

        const SEARCH_PATTERNS = ["google", "bing", "yahoo", "duckduckgo", "baidu", "yandex", "ecosia"];
        const SOCIAL_PATTERNS = ["facebook", "twitter", "x.com", "instagram", "tiktok", "reddit", "linkedin", "youtube", "pinterest", "snapchat"];
        const INTERNAL_PATTERNS = ["manus.space", "sportcardsonline.com", "localhost", "127.0.0.1"];

        for (const row of referrerRows as any[]) {
          const ref = (row.referrer ?? "").toLowerCase();
          const v = Number(row.views ?? 0);
          const c = Number(row.clicks ?? 0);

          // Extract domain for top referrers table
          if (ref) {
            try {
              const domain = new URL(ref.startsWith("http") ? ref : `https://${ref}`).hostname.replace(/^www\./, "");
              domainCount[domain] = (domainCount[domain] ?? 0) + v;
            } catch { /* ignore malformed URLs */ }
          }

          let category = "Direct";
          if (!ref) {
            category = "Direct";
          } else if (SEARCH_PATTERNS.some((p) => ref.includes(p))) {
            category = "Search";
          } else if (SOCIAL_PATTERNS.some((p) => ref.includes(p))) {
            category = "Social";
          } else if (INTERNAL_PATTERNS.some((p) => ref.includes(p))) {
            category = "Internal";
          } else {
            category = "Other";
          }
          sourceMap[category].views += v;
          sourceMap[category].clicks += c;
        }

        const referralSources = Object.entries(sourceMap)
          .map(([source, { views, clicks }]) => ({ source, views, clicks }))
          .filter((s) => s.views > 0 || s.source === "Direct");

        // Top referrer domains (top 10)
        const topReferrers = Object.entries(domainCount)
          .sort((a, b) => b[1] - a[1])
          .slice(0, 10)
          .map(([domain, views]) => ({ domain, views }));

        // Sport views breakdown
        const sportViewsRows = await db.execute(sql`
          SELECT bp.sport, COALESCE(SUM(bp.view_count), 0) as views, COALESCE(SUM(bp.click_count), 0) as clicks, COUNT(*) as posts
          FROM blog_posts bp
          WHERE bp.sport IS NOT NULL AND bp.status = 'published'
          GROUP BY bp.sport
          ORDER BY views DESC
        `) as any[];

        // Overall engagement stats
        const statsRow = await db.execute(sql`
          SELECT
            COALESCE(SUM(view_count), 0) as totalViews,
            COALESCE(SUM(click_count), 0) as totalClicks,
            COUNT(CASE WHEN view_count > 0 THEN 1 END) as postsWithViews,
            COUNT(CASE WHEN status = 'published' THEN 1 END) as publishedPosts
          FROM blog_posts
        `) as any[];

        const stats = (statsRow as any[])[0] ?? {};
        const totalViews = Number(stats.totalViews ?? 0);
        const totalClicks = Number(stats.totalClicks ?? 0);
        const publishedPosts = Number(stats.publishedPosts ?? 1);
        const postsWithViews = Number(stats.postsWithViews ?? 0);
        const engagementRate = totalViews > 0 ? parseFloat(((totalClicks / totalViews) * 100).toFixed(2)) : 0;
        const avgViewsPerPost = publishedPosts > 0 ? parseFloat((totalViews / publishedPosts).toFixed(1)) : 0;

        return {
          referralSources,
          topReferrers,
          sportViews: sportViewsRows as any[],
          engagementRate,
          totalViews,
          totalClicks,
          avgViewsPerPost,
          postsWithViews,
        };
      }),
  }),

  // ─── Kids Corner ───────────────────────────────────────────────────────────
  kids: router({
    /**
     * Get or create a DB-backed kid profile from localStorage identity.
     * Used by TriviaPopup to get a stable kidId for question tracking.
     */
    getOrCreateProfile: publicProcedure
      .input(z.object({
        username: z.string().min(1).max(64),
        displayName: z.string().min(1).max(128),
        birthdate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional().default("2012-01-01"),
        avatarEmoji: z.string().optional().default("🏆"),
      }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "DB unavailable" });
        // Try to find existing profile by username
        const { kidsProfiles } = await import("../drizzle/schema");
        const [existing] = await db.select().from(kidsProfiles).where(eq(kidsProfiles.username, input.username)).limit(1);
        if (existing) return { id: existing.id, isNew: false };
        // Create new profile
        const result = await db.insert(kidsProfiles).values({
          parentUserId: 0,
          username: input.username,
          displayName: input.displayName,
          birthdate: input.birthdate,
          avatarEmoji: input.avatarEmoji,
          credits: 25,
          totalCreditsEarned: 25,
          level: 1,
          xp: 0,
          isActive: true,
          shareToken: Math.random().toString(36).slice(2, 10),
        });
        return { id: (result as any).insertId as number, isNew: true };
      }),

    /**
     * Claim daily 25-credit bonus (once per day per kid profile).
     */
    claimDailyBonus: publicProcedure
      .input(z.object({ kidId: z.number().int() }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
        const { kidsProfiles } = await import("../drizzle/schema");
        const [profile] = await db.select().from(kidsProfiles).where(eq(kidsProfiles.id, input.kidId)).limit(1);
        if (!profile) throw new TRPCError({ code: "NOT_FOUND" });
        const today = new Date().toISOString().slice(0, 10);
        const lastClaim = profile.lastDailyClaimAt ? new Date(profile.lastDailyClaimAt).toISOString().slice(0, 10) : null;
        if (lastClaim === today) return { claimed: false, credits: profile.credits };
        await db.update(kidsProfiles).set({
          credits: (profile.credits || 0) + 25,
          totalCreditsEarned: (profile.totalCreditsEarned || 0) + 25,
          lastDailyClaimAt: new Date(),
        }).where(eq(kidsProfiles.id, input.kidId));
        return { claimed: true, credits: (profile.credits || 0) + 25 };
      }),

    /**
     * Get kid profile with credits and today's play time.
     */
    getProfile: publicProcedure
      .input(z.object({ kidId: z.number().int() }))
      .query(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
        const { kidsProfiles, kidsPlaySessions, kidsTimeAllowances } = await import("../drizzle/schema");
        const [profile] = await db.select().from(kidsProfiles).where(eq(kidsProfiles.id, input.kidId)).limit(1);
        if (!profile) throw new TRPCError({ code: "NOT_FOUND" });
        const today = new Date().toISOString().slice(0, 10);
        const sessions = await db.select().from(kidsPlaySessions)
          .where(eq(kidsPlaySessions.kidId, input.kidId));
        const todaySessions = sessions.filter((s: any) => s.sessionDate === today);
        const todaySeconds = todaySessions.reduce((sum: number, s: any) => sum + (s.durationSeconds || 0), 0);
        const allowances = await db.select().from(kidsTimeAllowances)
          .where(eq(kidsTimeAllowances.kidId, input.kidId));
        const todayBonus = allowances
          .filter((a: any) => a.allowanceDate === today)
          .reduce((sum: number, a: any) => sum + (a.bonusSeconds || 0), 0);
        const baseLimit = 3600; // 1 hour
        const totalAllowed = baseLimit + todayBonus;
        return {
          ...profile,
          todayPlaySeconds: todaySeconds,
          totalAllowedSeconds: totalAllowed,
          remainingSeconds: Math.max(0, totalAllowed - todaySeconds),
          isTimedOut: todaySeconds >= totalAllowed,
        };
      }),

    /**
     * Start a play session (called on Kids Corner login).
     */
    startSession: publicProcedure
      .input(z.object({ kidId: z.number().int() }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
        const { kidsPlaySessions } = await import("../drizzle/schema");
        const today = new Date().toISOString().slice(0, 10);
        const result = await db.insert(kidsPlaySessions).values({
          kidId: input.kidId,
          sessionDate: today,
          startedAt: new Date(),
          durationSeconds: 0,
        });
        return { sessionId: (result as any).insertId as number };
      }),

    /**
     * End a play session and record duration.
     */
    endSession: publicProcedure
      .input(z.object({ sessionId: z.number().int(), durationSeconds: z.number().int() }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
        const { kidsPlaySessions } = await import("../drizzle/schema");
        await db.update(kidsPlaySessions).set({
          endedAt: new Date(),
          durationSeconds: input.durationSeconds,
        }).where(eq(kidsPlaySessions.id, input.sessionId));
        return { success: true };
      }),

    /**
     * Parent grants bonus play time to a kid (auto-approved).
     */
    grantBonusTime: protectedProcedure
      .input(z.object({
        kidId: z.number().int(),
        bonusMinutes: z.number().int().min(5).max(120).default(60),
        reason: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
        const { kidsTimeAllowances } = await import("../drizzle/schema");
        const today = new Date().toISOString().slice(0, 10);
        await db.insert(kidsTimeAllowances).values({
          kidId: input.kidId,
          grantedByUserId: ctx.user.id,
          allowanceDate: today,
          bonusSeconds: input.bonusMinutes * 60,
          reason: input.reason || `Bonus time granted by parent`,
        });
        return { success: true, bonusMinutes: input.bonusMinutes };
      }),

    /**
     * Parent adds bonus credits to a kid's account (auto-approved).
     */
    addBonusCredits: protectedProcedure
      .input(z.object({
        kidId: z.number().int(),
        amount: z.number().int().min(1).max(1000),
        reason: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
        const { kidsProfiles } = await import("../drizzle/schema");
        const [profile] = await db.select().from(kidsProfiles).where(eq(kidsProfiles.id, input.kidId)).limit(1);
        if (!profile) throw new TRPCError({ code: "NOT_FOUND" });
        await db.update(kidsProfiles).set({
          credits: (profile.credits || 0) + input.amount,
          totalCreditsEarned: (profile.totalCreditsEarned || 0) + input.amount,
        }).where(eq(kidsProfiles.id, input.kidId));
        return { success: true, newBalance: (profile.credits || 0) + input.amount };
      }),

    /**
     * Update kid credits after game win/loss.
     */
    updateCredits: publicProcedure
      .input(z.object({ kidId: z.number().int(), delta: z.number().int() }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
        const { kidsProfiles } = await import("../drizzle/schema");
        const [profile] = await db.select().from(kidsProfiles).where(eq(kidsProfiles.id, input.kidId)).limit(1);
        if (!profile) throw new TRPCError({ code: "NOT_FOUND" });
        const newCredits = Math.max(0, (profile.credits || 0) + input.delta);
        await db.update(kidsProfiles).set({ credits: newCredits }).where(eq(kidsProfiles.id, input.kidId));
        return { credits: newCredits };
      }),

    /**
     * Parent purchases play credits for their child's Kids Corner.
     * Rate: 100 play credits = $1.00
     * Options: 100 / 200 / 500 / 1000 / 2000 credits  ($1 / $2 / $5 / $10 / $20)
     */
    buyCredits: protectedProcedure
      .input(z.object({
        creditAmount: z.number().int().min(100).max(2000),
        kidName: z.string().min(1).max(60),
        origin: z.string().url(),
      }))
      .mutation(async ({ ctx, input }) => {
        const dollarAmount = input.creditAmount / 100;   // 100 credits = $1.00
        const unitAmountCents = Math.round(dollarAmount * 100); // Stripe uses cents
        const Stripe = (await import("stripe")).default;
        const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, { apiVersion: "2025-01-27.acacia" as any });
        const session = await stripe.checkout.sessions.create({
          payment_method_types: ["card"],
          mode: "payment",
          customer_email: ctx.user.email!,
          line_items: [{
            price_data: {
              currency: "usd",
              product_data: {
                name: `Kids Corner — ${input.creditAmount} Play Credits`,
                description: `For ${input.kidName} on SportCardsOnline.com Kids Corner. Rate: 100 credits = $1.00`,
              },
              unit_amount: unitAmountCents,
            },
            quantity: 1,
          }],
          client_reference_id: ctx.user.id.toString(),
          metadata: {
            user_id:       ctx.user.id.toString(),
            customer_email: ctx.user.email!,
            customer_name:  ctx.user.name || "",
            order_type:    "kids_credits",
            credit_amount: input.creditAmount.toString(),
            kid_name:      input.kidName,
          },
          success_url: `${input.origin}/kids-corner?credits_added=${input.creditAmount}&success=1`,
          cancel_url:  `${input.origin}/kids-corner`,
          allow_promotion_codes: true,
        });
        return { checkoutUrl: session.url! };
      }),

    /**
     * Get a shuffled pool of real house+eBay cards for Kids Corner games.
     * Returns up to 100 cards with id, playerName, sport, frontImageUrl, gradeScore.
     */
    getCardPool: publicProcedure
      .input(z.object({ limit: z.number().int().min(10).max(200).default(100) }))
      .query(async ({ input }) => {
        const db = await getDb();
        if (!db) return { cards: [] };
        const { cards: cT } = await import("../drizzle/schema");
        // Fetch active cards that have a front image (house H or eBay E)
        const rows = await db
          .select({
            id: cT.id,
            playerName: cT.playerName,
            sport: cT.sport,
            frontImageUrl: cT.frontImageUrl,
            gradeScore: cT.gradeScore,
            gradeCompany: cT.gradeCompany,
            setName: cT.setName,
            year: cT.year,
            source: cT.source,
          })
          .from(cT)
          .where(and(
            eq(cT.status, "active"),
            isNotNull(cT.frontImageUrl),
          ))
          .limit(500);
        // Fisher-Yates shuffle then slice
        const arr = [...rows];
        for (let i = arr.length - 1; i > 0; i--) {
          const j = Math.floor(Math.random() * (i + 1));
          [arr[i], arr[j]] = [arr[j], arr[i]];
        }
        return { cards: arr.slice(0, input.limit) };
      }),
  }),
  disputes: router({
    openDispute: protectedProcedure
      .input(z.object({
        orderId: z.number(),
        reason: z.enum(["item_not_received", "item_not_as_described", "damaged_item", "wrong_item", "other"]),
        description: z.string().min(10).max(2000),
      }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new Error("DB unavailable");
        // Verify the order belongs to this buyer
        const { orders } = await import("../drizzle/schema");
        const [order] = await db.select().from(orders).where(and(eq(orders.id, input.orderId), eq(orders.buyerEmail, ctx.user.email!))).limit(1);
        if (!order) throw new Error("Order not found or not yours");
        // Check no open dispute already exists
        const existing = await db.select().from(disputes).where(and(eq(disputes.orderId, input.orderId), eq(disputes.buyerId, ctx.user.id))).limit(1);
        if (existing.length > 0) throw new Error("A dispute already exists for this order");
        // Create dispute and update order status
        await db.insert(disputes).values({
          orderId: input.orderId,
          buyerId: ctx.user.id,
          reason: input.reason,
          description: input.description,
          status: "open",
        });
        await db.update(orders).set({ status: "disputed" }).where(eq(orders.id, input.orderId));
        // Notify owner via in-app
        await notifyOwner({ title: "New Dispute Opened", content: `Buyer ${ctx.user.email} opened a dispute on Order #${input.orderId}: ${input.reason}` });
        // Send email notifications to buyer, seller, and admin
        const { sendEmail, emailTemplates, ADMIN_EMAIL } = await import("./email");
        const reasonLabel = input.reason.replace(/_/g, " ").replace(/\b\w/g, (c: string) => c.toUpperCase());
        const disputeData = { orderId: String(input.orderId), cardTitle: order.cardTitle ?? `Order #${input.orderId}`, openedBy: ctx.user.name || ctx.user.email!, reason: reasonLabel };
        // Buyer confirmation
        sendEmail({ to: ctx.user.email!, ...emailTemplates().disputeOpened(ctx.user.name || "Buyer", disputeData) }).catch(() => {});
        // Seller notification
        if (order.sellerEmail) {
          sendEmail({ to: order.sellerEmail, ...emailTemplates().disputeOpened(order.sellerEmail, { ...disputeData, isAdmin: false }) }).catch(() => {});
        }
        // Admin notification
        sendEmail({ to: ADMIN_EMAIL, ...emailTemplates().disputeOpened("Admin", { ...disputeData, isAdmin: true }) }).catch(() => {});
        return { success: true };
      }),

    listDisputes: protectedProcedure
      .input(z.object({ status: z.string().optional() }))
      .query(async ({ ctx, input }) => {
        if (ctx.user.role !== "admin") throw new Error("Admin only");
        const db = await getDb();
        if (!db) return [];
        const conditions = input.status ? [eq(disputes.status, input.status)] : [];
        const rows = await db.select().from(disputes)
          .where(conditions.length ? and(...conditions as [any, ...any[]]) : undefined)
          .orderBy(desc(disputes.createdAt));
        return rows;
      }),

    updateDisputeStatus: protectedProcedure
      .input(z.object({
        disputeId: z.number(),
        status: z.enum(["investigating", "resolved", "closed"]),
        resolutionNote: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        if (ctx.user.role !== "admin") throw new Error("Admin only");
        const db = await getDb();
        if (!db) throw new Error("DB unavailable");
        await db.update(disputes).set({
          status: input.status,
          resolutionNote: input.resolutionNote ?? null,
          resolvedBy: ctx.user.id,
          resolvedAt: input.status === "resolved" ? new Date() : null,
        }).where(eq(disputes.id, input.disputeId));

        // Send resolution emails to buyer and seller when status is resolved or closed
        if (input.status === "resolved" || input.status === "closed") {
          const { sendEmail, emailTemplates } = await import("./email");
          const { orders } = await import("../drizzle/schema");
          // Fetch the dispute with order info
          const [dispute] = await db.select().from(disputes).where(eq(disputes.id, input.disputeId)).limit(1);
          if (dispute) {
            const [order] = await db.select().from(orders).where(eq(orders.id, dispute.orderId)).limit(1);
            if (order) {
              const outcome = input.status === "resolved" ? "Resolved in favour of buyer" : "Case closed";
              const resolution = input.resolutionNote || (input.status === "resolved" ? "The dispute has been reviewed and resolved by our team." : "This dispute has been closed.");
              const resolveData = {
                orderId: String(dispute.orderId),
                cardTitle: order.cardTitle ?? `Order #${dispute.orderId}`,
                resolution,
                outcome,
              };
              // Email buyer
              if (order.buyerEmail) {
                sendEmail({ to: order.buyerEmail, ...emailTemplates().disputeResolved(order.buyerEmail, resolveData) }).catch(() => {});
              }
              // Email seller
              if (order.sellerEmail) {
                sendEmail({ to: order.sellerEmail, ...emailTemplates().disputeResolved(order.sellerEmail, { ...resolveData, outcome: input.status === "resolved" ? "Resolved — please check your account" : "Case closed" }) }).catch(() => {});
              }
            }
          }
        }

        return { success: true };
      }),
  }),

  // ============================================================================
  // LIVE EBAY SEARCH & DROPSHIP — search any card, grade, company in real-time
  // Results marked up 10%, $12 minimum, shipping cost included.
  // Owner gets notified on purchase with eBay link + suggested Best Offer.
  // ============================================================================
  liveSearch: router({
    /**
     * Search eBay live for any player + grade + company.
     * Returns cards marked up 10% with shipping cost included.
     * Minimum our price: $12.00. Free shipping flagged.
     */
    search: publicProcedure
      .input(z.object({
        query: z.string().min(2).max(100),
        gradeCompany: z.enum(["any", "PSA", "BGS", "SGC", "CGC"]).default("any"),
        minGrade: z.string().optional(),
        limit: z.number().min(1).max(30).default(20),
      }))
      .query(async ({ input }) => {
        const clientId = process.env.EBAY_CLIENT_ID;
        const clientSecret = process.env.EBAY_CLIENT_SECRET;
        if (!clientId || !clientSecret) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "eBay not configured" });

        // Get OAuth token
        const isSandbox = clientId.includes("-SBX-");
        const ebayBase = isSandbox ? "https://api.sandbox.ebay.com" : "https://api.ebay.com";
        const creds = Buffer.from(`${clientId}:${clientSecret}`).toString("base64");
        const tokenRes = await fetch(`${ebayBase}/identity/v1/oauth2/token`, {
          method: "POST",
          headers: { "Authorization": `Basic ${creds}`, "Content-Type": "application/x-www-form-urlencoded" },
          body: "grant_type=client_credentials&scope=https%3A%2F%2Fapi.ebay.com%2Foauth%2Fapi_scope",
        });
        const tokenData = await tokenRes.json() as any;
        if (!tokenData.access_token) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "eBay auth failed" });
        const token = tokenData.access_token;

        // Build search query
        const gradeKeyword = input.gradeCompany !== "any" ? input.gradeCompany : "";
        const minGradeKeyword = input.minGrade ? input.minGrade : "";
        const q = [input.query, gradeKeyword, minGradeKeyword, "sports card graded"]
          .filter(Boolean).join(" ");

        const params = new URLSearchParams({
          q,
          category_ids: "212",
          limit: String(Math.min(input.limit * 3, 50)), // fetch extra to filter
          sort: "newlyListed",
          filter: "buyingOptions:{FIXED_PRICE|BEST_OFFER},conditions:{NEW|LIKE_NEW|VERY_GOOD|GOOD}",
          fieldgroups: "EXTENDED",
        });

        const res = await fetch(`${ebayBase}/buy/browse/v1/item_summary/search?${params}`, {
          headers: { "Authorization": `Bearer ${token}`, "X-EBAY-C-MARKETPLACE-ID": "EBAY_US" },
          signal: AbortSignal.timeout(10000),
        });
        if (!res.ok) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "eBay search failed" });
        const data = await res.json() as any;
        const items: any[] = data.itemSummaries || [];

        const MARKUP = 1.10; // 10% markup
        const MIN_OUR_PRICE = 12.00;

        const results = items
          .map((item: any) => {
            const ebayPrice = parseFloat(item.price?.value || "0");
            if (ebayPrice <= 0) return null;

            // Shipping cost
            const shippingOptions = item.shippingOptions || [];
            const freeShipping = shippingOptions.some((s: any) =>
              s.shippingCostType === "FREE" || parseFloat(s.shippingCost?.value || "1") === 0
            );
            const shippingCost = freeShipping ? 0 : parseFloat(
              shippingOptions[0]?.shippingCost?.value || "0"
            );

            // Our price = (eBay price + shipping) × 1.10, rounded to 2dp
            const totalEbayWithShipping = ebayPrice + shippingCost;
            const ourPrice = Math.round(totalEbayWithShipping * MARKUP * 100) / 100;

            // Enforce $12 minimum
            if (ourPrice < MIN_OUR_PRICE) return null;

            // Suggested Best Offer = eBay price × 0.90 (10% below, maximizes margin)
            const suggestedOffer = Math.round(ebayPrice * 0.90 * 100) / 100;

            // Detect grade company from title
            const title = item.title || "";
            let detectedCompany = "Unknown";
            if (/\bBGS\b|\bBeckett\b/i.test(title)) detectedCompany = "BGS";
            else if (/\bPSA\b/i.test(title)) detectedCompany = "PSA";
            else if (/\bSGC\b/i.test(title)) detectedCompany = "SGC";
            else if (/\bCGC\b/i.test(title)) detectedCompany = "CGC";

            // Extract grade from title
            const gradeMatch = title.match(/(?:PSA|BGS|SGC|CGC)\s*(\d+(?:\.\d+)?)/i);
            const grade = gradeMatch ? gradeMatch[1] : null;

            const acceptsOffers = (item.buyingOptions || []).includes("BEST_OFFER");

            return {
              ebayItemId: item.itemId,
              title,
              ebayPrice,
              shippingCost,
              freeShipping,
              ourPrice,
              suggestedOffer,
              imageUrl: item.image?.imageUrl || null,
              ebayUrl: item.itemWebUrl,
              gradeCompany: detectedCompany,
              grade,
              acceptsOffers,
              seller: item.seller?.username || "unknown",
            };
          })
          .filter(Boolean)
          .slice(0, input.limit);

        return { results, total: results.length, query: q };
      }),

    /**
     * Customer purchases a live-search card.
     * Creates a pending order, notifies owner with eBay link + suggested Best Offer.
     */
    purchase: protectedProcedure
      .input(z.object({
        ebayItemId: z.string(),
        title: z.string(),
        ebayPrice: z.number(),
        shippingCost: z.number(),
        freeShipping: z.boolean(),
        ourPrice: z.number(),
        suggestedOffer: z.number(),
        imageUrl: z.string().nullable(),
        ebayUrl: z.string(),
        gradeCompany: z.string(),
        grade: z.string().nullable(),
        acceptsOffers: z.boolean(),
        seller: z.string(),
        // Shipping address
        shippingName: z.string(),
        shippingAddress: z.string(),
        shippingCity: z.string(),
        shippingState: z.string(),
        shippingZip: z.string(),
      }))
      .mutation(async ({ input, ctx }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "DB unavailable" });

        // Create a pending dropship order in the DB
        const { orders: oT } = await import("../drizzle/schema");
        const orderId = `DS-${Date.now()}-${Math.random().toString(36).slice(2, 7).toUpperCase()}`;
        const fullAddress = `${input.shippingName}, ${input.shippingAddress}, ${input.shippingCity}, ${input.shippingState} ${input.shippingZip}`;
        await db.insert(oT).values({
          buyerEmail: ctx.user.email ?? ctx.user.openId,
          buyerName: input.shippingName,
          sellerEmail: "dropship@sportscardsonline.com",
          cardTitle: input.title,
          cardImageUrl: input.imageUrl ?? undefined,
          price: String(input.ourPrice),
          totalAmount: String(input.ourPrice),
          status: "pending",
          shippingAddress: fullAddress,
          isDropshipOrder: true,
          ebayFulfillmentLink: input.ebayUrl,
          ebayOfferStatus: input.acceptsOffers ? "pending" : "not_eligible",
          ebayOfferAmount: String(input.suggestedOffer),
          ticketNumber: orderId,
        });

        // Notify owner with full order details
        const shippingLine = input.freeShipping
          ? "✅ FREE SHIPPING on eBay"
          : `📦 eBay Shipping: $${input.shippingCost.toFixed(2)}`;

        const offerLine = input.acceptsOffers
          ? `💡 Accepts Best Offer — suggest offering **$${input.suggestedOffer.toFixed(2)}** (10% below eBay price)`
          : `⚠️ Fixed price only — no Best Offer available. Buy at $${input.ebayPrice.toFixed(2)}.`;

        await notifyOwner({
          title: `🛒 New Dropship Order — ${input.gradeCompany} ${input.grade || ""} ${input.title.slice(0, 50)}`,
          content: [
            `**Customer:** ${ctx.user.name || ctx.user.email}`,
            `**Card:** ${input.title}`,
            `**Grade:** ${input.gradeCompany} ${input.grade || "N/A"}`,
            ``,
            `**eBay Price:** $${input.ebayPrice.toFixed(2)}`,
            shippingLine,
            `**Our Price (charged to customer):** $${input.ourPrice.toFixed(2)}`,
            `**Our Margin:** ~$${(input.ourPrice - input.ebayPrice - input.shippingCost).toFixed(2)}`,
            ``,
            offerLine,
            ``,
            `**eBay Listing:** ${input.ebayUrl}`,
            `**eBay Seller:** ${input.seller}`,
            ``,
            `**Ship To:**`,
            `${input.shippingName}`,
            `${input.shippingAddress}`,
            `${input.shippingCity}, ${input.shippingState} ${input.shippingZip}`,
            ``,
            `**Order ID:** ${orderId}`,
          ].join("\n"),
        });

        return { success: true, orderId };
      }),
  }),
});
export type AppRouter = typeof appRouter;;

