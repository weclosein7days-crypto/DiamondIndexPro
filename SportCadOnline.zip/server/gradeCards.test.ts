/**
 * Tests for Grade Cards auto-pricing and news ticker procedures.
 */
import { describe, it, expect } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createAuthContext(): TrpcContext {
  const user: AuthenticatedUser = {
    id: 1,
    openId: "test-user",
    email: "test@example.com",
    name: "Test User",
    loginMethod: "manus",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  return {
    user,
    req: {
      headers: { origin: "http://localhost:3000" },
      cookies: {},
    } as any,
    res: {
      cookie: () => {},
      clearCookie: () => {},
    } as any,
  };
}

describe("news.getTicker", () => {
  it("returns an array of ticker items with id, text, and category", async () => {
    const caller = appRouter.createCaller(createAuthContext());
    const items = await caller.news.getTicker();
    expect(Array.isArray(items)).toBe(true);
    expect(items.length).toBeGreaterThan(0);
    const first = items[0];
    expect(first).toHaveProperty("id");
    expect(first).toHaveProperty("text");
    expect(first).toHaveProperty("category");
    expect(typeof first.text).toBe("string");
    expect(first.text.length).toBeGreaterThan(0);
  });

  it("returns items covering multiple sports categories", async () => {
    const caller = appRouter.createCaller(createAuthContext());
    const items = await caller.news.getTicker();
    const categories = new Set(items.map((i: { category: string }) => i.category));
    expect(categories.size).toBeGreaterThanOrEqual(3);
  });
});

describe("grading.getMarketPrice", () => {
  it("returns a market price result object with expected fields", async () => {
    const caller = appRouter.createCaller(createAuthContext());
    const result = await caller.grading.getMarketPrice({
      query: "Mike Trout 2011 Topps Update",
      grade: 9,
    });
    expect(result).toHaveProperty("suggestedPrice");
    expect(result).toHaveProperty("marketAvg");
    expect(result).toHaveProperty("sources");
    expect(result).toHaveProperty("multiplier");
    expect(result).toHaveProperty("gradeCategory");
    expect(result.sources).toHaveProperty("ebay");
    expect(result.sources).toHaveProperty("scp");
    expect(result.sources).toHaveProperty("beckett");
    // multiplier should be a positive number
    expect(typeof result.multiplier).toBe("number");
    expect(result.multiplier).toBeGreaterThan(0);
  }, 30000); // 30s timeout for external API calls

  it("handles null grade (ungraded card) gracefully", async () => {
    const caller = appRouter.createCaller(createAuthContext());
    const result = await caller.grading.getMarketPrice({
      query: "Caitlin Clark 2024 Panini Prizm",
      grade: null,
    });
    expect(result).toHaveProperty("gradeCategory");
    expect(result.gradeCategory).toBe("raw");
    expect(result.multiplier).toBeGreaterThan(0);
  }, 30000);
});
