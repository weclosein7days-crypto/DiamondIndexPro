/**
 * Tests for bulk card operations (bulkUpdateStatus, bulkDelete)
 * These test the DB helper functions directly via the tRPC router.
 */
import { describe, it, expect } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

function createAdminContext(email: string): TrpcContext {
  const user = {
    id: 1,
    openId: "admin-user",
    email,
    name: "Admin User",
    loginMethod: "manus",
    role: "admin",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };
  return {
    user,
    req: { headers: {}, cookies: {} } as any,
    res: { clearCookie: () => {}, cookie: () => {} } as any,
  };
}

describe("cards.bulkUpdateStatus procedure", () => {
  it("returns success:true and updated count for valid input", async () => {
    const caller = appRouter.createCaller(createAdminContext("test-admin@example.com"));
    // Use an empty array — no cards to update, but procedure should succeed
    const result = await caller.cards.bulkUpdateStatus({ ids: [], status: "bank" });
    expect(result.success).toBe(true);
    expect(result.updated).toBe(0);
  });

  it("accepts all valid status values", async () => {
    const caller = appRouter.createCaller(createAdminContext("test-admin@example.com"));
    const statuses = ["active", "sold", "draft", "auction", "traded", "casino", "bank"] as const;
    for (const status of statuses) {
      const result = await caller.cards.bulkUpdateStatus({ ids: [], status });
      expect(result.success).toBe(true);
    }
  });

  it("rejects unauthenticated callers", async () => {
    const unauthCtx: TrpcContext = {
      user: null,
      req: { headers: {}, cookies: {} } as any,
      res: { clearCookie: () => {}, cookie: () => {} } as any,
    };
    const caller = appRouter.createCaller(unauthCtx);
    await expect(
      caller.cards.bulkUpdateStatus({ ids: [1, 2], status: "casino" })
    ).rejects.toThrow();
  });
});

describe("cards.bulkDelete procedure", () => {
  it("returns success:true and deleted count for empty ids array", async () => {
    const caller = appRouter.createCaller(createAdminContext("test-admin@example.com"));
    const result = await caller.cards.bulkDelete({ ids: [] });
    expect(result.success).toBe(true);
    expect(result.deleted).toBe(0);
  });

  it("rejects unauthenticated callers", async () => {
    const unauthCtx: TrpcContext = {
      user: null,
      req: { headers: {}, cookies: {} } as any,
      res: { clearCookie: () => {}, cookie: () => {} } as any,
    };
    const caller = appRouter.createCaller(unauthCtx);
    await expect(
      caller.cards.bulkDelete({ ids: [1, 2] })
    ).rejects.toThrow();
  });
});
