/**
 * Escrow Auto-Release & Ship-Reminder Jobs
 *
 * Runs every 15 minutes:
 *  1. Auto-release: orders where autoReleaseAt has passed and status is still "shipped"
 *  2. Ship reminder: orders where shipByDeadline is within 24 hours and status is "paid" or "label_created"
 *  3. Auto-release warning: orders where autoReleaseAt is within 1 hour and status is "shipped"
 */

import { getDb } from "./db";
import { orders } from "../drizzle/schema";
import { and, eq, lte, gte } from "drizzle-orm";
import { sendEmail, emailTemplates, ADMIN_EMAIL } from "./email";

let jobRunning = false;

export function startEscrowJobs() {
  console.log("[EscrowJobs] Starting escrow auto-release job (every 15 min)");
  // Run immediately on startup, then every 15 minutes
  runEscrowJobs().catch(console.error);
  setInterval(() => {
    runEscrowJobs().catch(console.error);
  }, 15 * 60 * 1000);
}

async function runEscrowJobs() {
  if (jobRunning) return;
  jobRunning = true;
  try {
    const db = await getDb();
    if (!db) return;

    const now = new Date();

    // ── 1. AUTO-RELEASE: orders past autoReleaseAt still in "shipped" status ──
    const overdueOrders = await db
      .select()
      .from(orders)
      .where(
        and(
          eq(orders.status, "shipped"),
          lte(orders.autoReleaseAt, now)
        )
      )
      .limit(50);

    for (const order of overdueOrders) {
      try {
        // Mark as confirmed + funds released
        await db
          .update(orders)
          .set({ status: "confirmed", confirmedAt: now, fundsReleasedAt: now })
          .where(eq(orders.id, order.id));

        const payout = order.sellerPayout
          ? parseFloat(String(order.sellerPayout))
          : parseFloat(String(order.price || "0")) * 0.9;

        const tmpl = emailTemplates();

        // Email buyer: funds auto-released
        if (order.buyerEmail) {
          const buyerTmpl = tmpl.fundsReleasedBuyer(order.buyerEmail, {
            orderId: String(order.id),
            cardTitle: order.cardTitle || "Sports Card",
          });
          sendEmail({ to: order.buyerEmail, ...buyerTmpl }).catch(() => {});
        }

        // Email seller: funds released
        if (order.sellerEmail) {
          const sellerTmpl = tmpl.fundsReleasedSeller(order.sellerEmail, {
            orderId: String(order.id),
            cardTitle: order.cardTitle || "Sports Card",
            payout,
            releasedBy: "Auto-Release (24hr timer expired)",
          });
          sendEmail({ to: order.sellerEmail, ...sellerTmpl }).catch(() => {});
        }

        // Email admin: auto-release fired
        const adminTmpl = tmpl.adminAutoRelease({
          orderId: String(order.id),
          cardTitle: order.cardTitle || "Sports Card",
          buyerEmail: order.buyerEmail || "unknown",
          sellerEmail: order.sellerEmail || "unknown",
          payout,
        });
        sendEmail({ to: ADMIN_EMAIL, subject: adminTmpl.subject, html: adminTmpl.html }).catch(() => {});

        console.log(`[EscrowJobs] Auto-released order #${order.id} (${order.ticketNumber})`);
      } catch (err: any) {
        console.error(`[EscrowJobs] Failed to auto-release order #${order.id}:`, err.message);
      }
    }

    // ── 2. AUTO-RELEASE WARNING: 1 hour before auto-release ──────────────────
    const oneHourFromNow = new Date(now.getTime() + 60 * 60 * 1000);
    const warningOrders = await db
      .select()
      .from(orders)
      .where(
        and(
          eq(orders.status, "shipped"),
          lte(orders.autoReleaseAt, oneHourFromNow),
          gte(orders.autoReleaseAt, now),
          // Only warn once: heuristic — autoReleaseAt is within [now, now+1hr]
        )
      )
      .limit(50);

    for (const order of warningOrders) {
      try {
        if (!order.buyerEmail || !order.autoReleaseAt) continue;
        const releaseTime = new Date(order.autoReleaseAt).toLocaleString("en-US", {
          weekday: "short", month: "short", day: "numeric",
          hour: "2-digit", minute: "2-digit",
        });
        const warnTmpl = emailTemplates().buyerAutoReleaseWarning(order.buyerEmail, {
          orderId: String(order.id),
          cardTitle: order.cardTitle || "Sports Card",
          releaseTime,
        });
        sendEmail({ to: order.buyerEmail, ...warnTmpl }).catch(() => {});
        // Mark warning sent — use updatedAt as a proxy since autoReleaseWarningAt column doesn't exist yet
        await db
          .update(orders)
          .set({ updatedAt: now })
          .where(eq(orders.id, order.id));
        console.log(`[EscrowJobs] Sent 1-hr auto-release warning for order #${order.id}`);
      } catch (err: any) {
        console.error(`[EscrowJobs] Warning email failed for order #${order.id}:`, err.message);
      }
    }

    // ── 3. SHIP REMINDER: 24 hours before ship-by deadline ───────────────────
    const in24h = new Date(now.getTime() + 24 * 60 * 60 * 1000);
    const unshippedOrders = await db
      .select()
      .from(orders)
      .where(
        and(
          // Status is paid or label created but not yet shipped
          eq(orders.status, "paid"),
          lte(orders.shipByDeadline, in24h),
          gte(orders.shipByDeadline, now)
        )
      )
      .limit(50);

    for (const order of unshippedOrders) {
      try {
        if (!order.sellerEmail || !order.shipByDeadline) continue;
        const deadline = new Date(order.shipByDeadline).toLocaleString("en-US", {
          weekday: "long", month: "short", day: "numeric",
          hour: "2-digit", minute: "2-digit",
        });
        const reminderTmpl = emailTemplates().sellerShipReminder(order.sellerEmail, {
          orderId: String(order.id),
          cardTitle: order.cardTitle || "Sports Card",
          deadline,
        });
        sendEmail({ to: order.sellerEmail, ...reminderTmpl }).catch(() => {});
        console.log(`[EscrowJobs] Sent ship reminder for order #${order.id} to ${order.sellerEmail}`);
      } catch (err: any) {
        console.error(`[EscrowJobs] Ship reminder failed for order #${order.id}:`, err.message);
      }
    }

    if (overdueOrders.length + warningOrders.length + unshippedOrders.length > 0) {
      console.log(`[EscrowJobs] Processed: ${overdueOrders.length} auto-releases, ${warningOrders.length} warnings, ${unshippedOrders.length} ship reminders`);
    }
  } finally {
    jobRunning = false;
  }
}
