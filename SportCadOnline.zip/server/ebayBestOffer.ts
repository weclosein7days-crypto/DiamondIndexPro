/**
 * eBay Best Offer Service
 *
 * Automated system that attempts to purchase eBay dropship cards at 10% below
 * the asking price using eBay's Best Offer API. Falls back to full-price
 * purchase if the listing doesn't support Best Offer or if the offer is declined.
 *
 * Flow:
 *   1. Check if listing supports Best Offer (getItem API)
 *   2. If yes → submit offer at (askingPrice × 0.90)
 *   3. Poll for seller response (up to 30 min, every 2 min)
 *   4. If accepted → record savings, proceed with purchase
 *   5. If declined/countered/expired → fall back to full price
 *   6. If not eligible → fall back to full price immediately
 *   7. Update order record with offer status throughout
 */

import { getDb } from "./db";
import { orders } from "../drizzle/schema";
import { eq } from "drizzle-orm";

const OFFER_DISCOUNT = 0.10;          // 10% below asking
const POLL_INTERVAL_MS = 2 * 60 * 1000;  // poll every 2 minutes
const POLL_MAX_ATTEMPTS = 15;         // max 30 minutes of polling

// ─── eBay OAuth token helper ──────────────────────────────────────────────────

async function getEbayToken(): Promise<string> {
  const clientId = process.env.EBAY_CLIENT_ID;
  const clientSecret = process.env.EBAY_CLIENT_SECRET;
  if (!clientId || !clientSecret) throw new Error("eBay credentials not configured");

  const credentials = Buffer.from(`${clientId}:${clientSecret}`).toString("base64");
  const res = await fetch("https://api.ebay.com/identity/v1/oauth2/token", {
    method: "POST",
    headers: {
      Authorization: `Basic ${credentials}`,
      "Content-Type": "application/x-www-form-urlencoded",
    },
    body: "grant_type=client_credentials&scope=https%3A%2F%2Fapi.ebay.com%2Foauth%2Fapi_scope",
  });

  if (!res.ok) {
    const text = await res.text();
    throw new Error(`eBay token error: ${res.status} ${text}`);
  }

  const data = await res.json() as { access_token: string };
  return data.access_token;
}

// ─── Check if listing supports Best Offer ────────────────────────────────────

export interface BestOfferEligibility {
  eligible: boolean;
  askingPrice: number;
  currency: string;
  reason?: string;
}

export async function checkBestOfferEligibility(
  ebayItemId: string
): Promise<BestOfferEligibility> {
  try {
    const token = await getEbayToken();

    // Use Browse API to get listing details including Best Offer eligibility
    const res = await fetch(
      `https://api.ebay.com/buy/browse/v1/item/v1|${ebayItemId}|0`,
      {
        headers: {
          Authorization: `Bearer ${token}`,
          "X-EBAY-C-MARKETPLACE-ID": "EBAY_US",
          "Content-Type": "application/json",
        },
      }
    );

    if (!res.ok) {
      const text = await res.text();
      console.warn(`[BestOffer] Browse API error for ${ebayItemId}: ${res.status} ${text}`);
      return { eligible: false, askingPrice: 0, currency: "USD", reason: `API error: ${res.status}` };
    }

    const item = await res.json() as any;

    const askingPrice = parseFloat(item?.price?.value || "0");
    const currency = item?.price?.currency || "USD";

    // Check if Best Offer is enabled on this listing
    const buyingOptions: string[] = item?.buyingOptions || [];
    const eligible = buyingOptions.includes("BEST_OFFER");

    if (!eligible) {
      return {
        eligible: false,
        askingPrice,
        currency,
        reason: "Listing does not have Best Offer enabled",
      };
    }

    return { eligible: true, askingPrice, currency };
  } catch (err: any) {
    console.error("[BestOffer] Eligibility check failed:", err.message);
    return { eligible: false, askingPrice: 0, currency: "USD", reason: err.message };
  }
}

// ─── Submit a Best Offer ──────────────────────────────────────────────────────

export interface SubmitOfferResult {
  success: boolean;
  offerId?: string;
  offerAmount: number;
  error?: string;
}

export async function submitBestOffer(
  ebayItemId: string,
  offerAmount: number
): Promise<SubmitOfferResult> {
  try {
    const token = await getEbayToken();

    // Use Offer API to submit the offer
    const res = await fetch("https://api.ebay.com/buy/offer/v1_beta/offer", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${token}`,
        "X-EBAY-C-MARKETPLACE-ID": "EBAY_US",
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        itemId: `v1|${ebayItemId}|0`,
        price: {
          value: offerAmount.toFixed(2),
          currency: "USD",
        },
        quantity: 1,
      }),
    });

    if (!res.ok) {
      const text = await res.text();
      console.warn(`[BestOffer] Submit offer error: ${res.status} ${text}`);
      return { success: false, offerAmount, error: `Submit error: ${res.status}` };
    }

    const data = await res.json() as any;
    const offerId = data?.offerId || data?.id;

    console.log(`[BestOffer] Offer submitted: $${offerAmount.toFixed(2)} on item ${ebayItemId}, offerId: ${offerId}`);
    return { success: true, offerId, offerAmount };
  } catch (err: any) {
    console.error("[BestOffer] Submit failed:", err.message);
    return { success: false, offerAmount, error: err.message };
  }
}

// ─── Poll offer status ────────────────────────────────────────────────────────

export type OfferOutcome = "accepted" | "declined" | "countered" | "expired" | "pending";

export interface PollOfferResult {
  outcome: OfferOutcome;
  counterAmount?: number;
}

export async function pollOfferStatus(offerId: string): Promise<PollOfferResult> {
  try {
    const token = await getEbayToken();

    const res = await fetch(`https://api.ebay.com/buy/offer/v1_beta/offer/${offerId}`, {
      headers: {
        Authorization: `Bearer ${token}`,
        "X-EBAY-C-MARKETPLACE-ID": "EBAY_US",
      },
    });

    if (!res.ok) {
      console.warn(`[BestOffer] Poll error: ${res.status}`);
      return { outcome: "pending" };
    }

    const data = await res.json() as any;
    const status: string = (data?.offerStatus || "").toUpperCase();

    if (status === "ACCEPTED" || status === "BUYER_ACCEPTED") return { outcome: "accepted" };
    if (status === "DECLINED" || status === "SELLER_DECLINED") return { outcome: "declined" };
    if (status === "COUNTERED" || status === "SELLER_COUNTER") {
      const counterAmount = parseFloat(data?.counterOffer?.price?.value || "0");
      return { outcome: "countered", counterAmount };
    }
    if (status === "EXPIRED") return { outcome: "expired" };

    return { outcome: "pending" };
  } catch (err: any) {
    console.error("[BestOffer] Poll failed:", err.message);
    return { outcome: "pending" };
  }
}

// ─── Main orchestrator ────────────────────────────────────────────────────────

export interface BestOfferResult {
  /** Final purchase price (offer amount if accepted, full price if fallback) */
  purchasePrice: number;
  /** Whether the offer was accepted and savings were realized */
  offerAccepted: boolean;
  /** Amount saved vs. asking price (0 if no savings) */
  savings: number;
  /** Final status to store on the order */
  status: "accepted" | "declined" | "countered" | "expired" | "not_eligible" | "fallback_full_price";
  /** eBay offer ID (if one was submitted) */
  offerId?: string;
  /** Offer amount that was submitted */
  offerAmount?: number;
}

/**
 * Attempt to purchase an eBay item via Best Offer at 10% below asking.
 * Updates the order record throughout the process.
 * Returns the final purchase price and offer outcome.
 */
export async function attemptBestOffer(
  orderId: number,
  ebayItemId: string,
  askingPrice: number
): Promise<BestOfferResult> {
  const db = await getDb();

  const offerAmount = Math.floor(askingPrice * (1 - OFFER_DISCOUNT) * 100) / 100;

  // ── Step 1: Check eligibility ──────────────────────────────────────────────
  console.log(`[BestOffer] Checking eligibility for item ${ebayItemId} (order ${orderId})`);
  const eligibility = await checkBestOfferEligibility(ebayItemId);

  if (!eligibility.eligible) {
    console.log(`[BestOffer] Not eligible: ${eligibility.reason}`);
    if (db) {
      await db.update(orders)
        .set({ ebayOfferStatus: "not_eligible" })
        .where(eq(orders.id, orderId));
    }
    return {
      purchasePrice: askingPrice,
      offerAccepted: false,
      savings: 0,
      status: "not_eligible",
    };
  }

  // ── Step 2: Submit offer ───────────────────────────────────────────────────
  console.log(`[BestOffer] Submitting offer of $${offerAmount.toFixed(2)} (asking: $${askingPrice.toFixed(2)})`);
  const submitResult = await submitBestOffer(ebayItemId, offerAmount);

  if (!submitResult.success || !submitResult.offerId) {
    console.warn(`[BestOffer] Submit failed: ${submitResult.error}`);
    if (db) {
      await db.update(orders)
        .set({ ebayOfferStatus: "fallback_full_price" })
        .where(eq(orders.id, orderId));
    }
    return {
      purchasePrice: askingPrice,
      offerAccepted: false,
      savings: 0,
      status: "fallback_full_price",
    };
  }

  // Update order: offer pending
  if (db) {
    await db.update(orders)
      .set({
        ebayOfferStatus: "pending",
        ebayOfferAmount: offerAmount.toFixed(2) as any,
        ebayOfferId: submitResult.offerId,
        ebayOfferSentAt: new Date(),
      })
      .where(eq(orders.id, orderId));
  }

  // ── Step 3: Poll for response ──────────────────────────────────────────────
  let attempts = 0;
  while (attempts < POLL_MAX_ATTEMPTS) {
    await new Promise(resolve => setTimeout(resolve, POLL_INTERVAL_MS));
    attempts++;

    const poll = await pollOfferStatus(submitResult.offerId);
    console.log(`[BestOffer] Poll attempt ${attempts}/${POLL_MAX_ATTEMPTS}: ${poll.outcome}`);

    if (poll.outcome === "pending") continue;

    // Offer resolved — update order
    const savings = poll.outcome === "accepted" ? askingPrice - offerAmount : 0;
    const purchasePrice = poll.outcome === "accepted" ? offerAmount : askingPrice;

    if (db) {
      await db.update(orders)
        .set({
          ebayOfferStatus: poll.outcome,
          ebayOfferRespondedAt: new Date(),
          ebayOfferSavings: savings.toFixed(2) as any,
        })
        .where(eq(orders.id, orderId));
    }

    if (poll.outcome === "accepted") {
      console.log(`[BestOffer] ✅ Offer accepted! Saved $${savings.toFixed(2)} on order ${orderId}`);
      return {
        purchasePrice: offerAmount,
        offerAccepted: true,
        savings,
        status: "accepted",
        offerId: submitResult.offerId,
        offerAmount,
      };
    }

    // Declined, countered, or expired → fall back to full price
    console.log(`[BestOffer] Offer ${poll.outcome} — falling back to full price $${askingPrice.toFixed(2)}`);
    return {
      purchasePrice: askingPrice,
      offerAccepted: false,
      savings: 0,
      status: poll.outcome === "countered" ? "countered" : poll.outcome,
      offerId: submitResult.offerId,
      offerAmount,
    };
  }

  // Timed out polling — fall back to full price
  console.warn(`[BestOffer] Polling timed out after ${POLL_MAX_ATTEMPTS} attempts — falling back to full price`);
  if (db) {
    await db.update(orders)
      .set({ ebayOfferStatus: "expired" })
      .where(eq(orders.id, orderId));
  }
  return {
    purchasePrice: askingPrice,
    offerAccepted: false,
    savings: 0,
    status: "expired",
    offerId: submitResult.offerId,
    offerAmount,
  };
}
