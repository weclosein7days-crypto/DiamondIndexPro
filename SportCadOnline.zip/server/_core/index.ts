import "dotenv/config";
import express from "express";
import { createServer } from "http";
import net from "net";
import { createExpressMiddleware } from "@trpc/server/adapters/express";
import { registerOAuthRoutes } from "./oauth";
import { registerEbayDeletionRoute } from "../ebayDeletion";
import { appRouter } from "../routers";
import { createContext } from "./context";
import { serveStatic, setupVite } from "./vite";
import mysql from "mysql2/promise";

async function runPendingMigrations() {
  const statements = [
    "ALTER TABLE `collections` ADD COLUMN IF NOT EXISTS `listingStatus` enum('none','listed','auction','trading','sold') DEFAULT 'none' NOT NULL",
    "ALTER TABLE `collections` ADD COLUMN IF NOT EXISTS `linkedCardId` int",
    "ALTER TABLE `trades` ADD COLUMN IF NOT EXISTS `initiatorAgreed` boolean DEFAULT false",
    "ALTER TABLE `trades` ADD COLUMN IF NOT EXISTS `receiverAgreed` boolean DEFAULT false",
    "ALTER TABLE `trades` ADD COLUMN IF NOT EXISTS `initiatorTracking` varchar(200)",
    "ALTER TABLE `trades` ADD COLUMN IF NOT EXISTS `receiverTracking` varchar(200)",
    "ALTER TABLE `trades` ADD COLUMN IF NOT EXISTS `shippingStatus` enum('pending','initiator_shipped','receiver_shipped','both_shipped','completed') DEFAULT 'pending'",
    // Lifecycle state machine migration
    "ALTER TABLE `collections` MODIFY COLUMN `listingStatus` enum('none','listed','auction','in_trade','in_sale','shipped','traded','sold') NOT NULL DEFAULT 'none'",
    "ALTER TABLE `collections` ADD COLUMN IF NOT EXISTS `lifecycleNote` varchar(500)",
    // Trade fee payment statuses
    "ALTER TABLE `trades` MODIFY COLUMN `status` enum('pending','accepted','rejected','cancelled','countered','agreed','fee_pending','paid_ready_to_ship','shipped','completed') NOT NULL DEFAULT 'pending'",
    // Game plays: add roulette/blackjack to gameType enum
    "ALTER TABLE `game_plays` MODIFY COLUMN `gameType` enum('pack_rip','spin_wheel','scratch_card','tournament','poker','roulette','blackjack') NOT NULL",
    // Game plays: add win/loss/registered/bust to outcome enum
    "ALTER TABLE `game_plays` MODIFY COLUMN `outcome` enum('credits','card_prize','jackpot','mini_jackpot','bust','registered','win','loss') NOT NULL",
    // Collections: add gameSource, prizeClaimId, trackingNumber columns
    "ALTER TABLE `collections` ADD COLUMN IF NOT EXISTS `gameSource` varchar(100)",
    "ALTER TABLE `collections` ADD COLUMN IF NOT EXISTS `prizeClaimId` int",
    "ALTER TABLE `collections` ADD COLUMN IF NOT EXISTS `trackingNumber` varchar(100)",
    // Collections: expand listingStatus enum with pending_gm/gs/gm_complete
    "ALTER TABLE `collections` MODIFY COLUMN `listingStatus` enum('none','listed','auction','in_trade','in_sale','shipped','traded','sold','pending_gm','gs','gm_complete') NOT NULL DEFAULT 'none'",
    // Roulette saved bets table
    `CREATE TABLE IF NOT EXISTS \`roulette_saved_bets\` (
      \`id\` int AUTO_INCREMENT NOT NULL,
      \`userId\` int NOT NULL,
      \`name\` varchar(100) NOT NULL,
      \`bets\` json NOT NULL,
      \`createdAt\` timestamp NOT NULL DEFAULT (now()),
      CONSTRAINT \`roulette_saved_bets_id\` PRIMARY KEY(\`id\`)
    )`,
    // User collection (imported from Sports Cards Pro)
    `CREATE TABLE IF NOT EXISTS \`user_collection\` (
      \`id\` int AUTO_INCREMENT NOT NULL,
      \`userId\` int NOT NULL,
      \`scpId\` varchar(32) NOT NULL,
      \`productName\` varchar(512) NOT NULL,
      \`consoleName\` varchar(512) NOT NULL,
      \`priceInPennies\` int NOT NULL DEFAULT 0,
      \`costBasisInPennies\` int NOT NULL DEFAULT 0,
      \`condition\` varchar(128),
      \`quantity\` int NOT NULL DEFAULT 1,
      \`imageUrl\` text,
      \`imageBackUrl\` text,
      \`gradingCompany\` varchar(64),
      \`gradingCertId\` varchar(128),
      \`sport\` varchar(64),
      \`playerName\` varchar(255),
      \`dateEntered\` varchar(32),
      \`datePurchased\` varchar(32),
      \`notes\` text,
      \`folder\` varchar(255),
      \`createdAt\` timestamp NOT NULL DEFAULT (now()),
      \`updatedAt\` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
      CONSTRAINT \`user_collection_id\` PRIMARY KEY(\`id\`)
    )`,
    // Vault system: add isVaulted and cardShippingFee to cards table
    "ALTER TABLE `cards` ADD COLUMN IF NOT EXISTS `isVaulted` boolean DEFAULT false",
    "ALTER TABLE `cards` ADD COLUMN IF NOT EXISTS `cardShippingFee` decimal(10,2) DEFAULT NULL",
    // Collections: expand listingStatus enum with vault statuses
    "ALTER TABLE `collections` MODIFY COLUMN `listingStatus` enum('none','listed','auction','in_trade','in_sale','shipped','traded','sold','pending_gm','gs','gm_complete','vaulted','vault_listed','vault_auction','vault_sold','vault_shipped') NOT NULL DEFAULT 'none'",
    // Collections: add vault-specific columns
    "ALTER TABLE `collections` ADD COLUMN IF NOT EXISTS `shippingFee` decimal(10,2) DEFAULT NULL",
    "ALTER TABLE `collections` ADD COLUMN IF NOT EXISTS `vaultedAt` timestamp DEFAULT NULL",
    // eBay dropship fields for cards
    "ALTER TABLE `cards` ADD COLUMN IF NOT EXISTS `ebayListingUrl` text",
    "ALTER TABLE `cards` ADD COLUMN IF NOT EXISTS `sourcePrice` decimal(10,2) DEFAULT NULL",
    "ALTER TABLE `cards` ADD COLUMN IF NOT EXISTS `isDropship` boolean DEFAULT false",
    // eBay dropship fields for orders
    "ALTER TABLE `orders` ADD COLUMN IF NOT EXISTS `isDropshipOrder` boolean DEFAULT false",
    "ALTER TABLE `orders` ADD COLUMN IF NOT EXISTS `ebayFulfillmentLink` text",
    "ALTER TABLE `orders` ADD COLUMN IF NOT EXISTS `dropshipFulfilledAt` timestamp DEFAULT NULL",
    // eBay Best Offer tracking fields for orders
    "ALTER TABLE `orders` ADD COLUMN IF NOT EXISTS `ebayOfferStatus` enum('none','not_eligible','pending','accepted','declined','countered','expired','fallback_full_price') DEFAULT 'none'",
    "ALTER TABLE `orders` ADD COLUMN IF NOT EXISTS `ebayOfferAmount` decimal(10,2) DEFAULT NULL",
    "ALTER TABLE `orders` ADD COLUMN IF NOT EXISTS `ebayOfferSentAt` timestamp DEFAULT NULL",
    "ALTER TABLE `orders` ADD COLUMN IF NOT EXISTS `ebayOfferRespondedAt` timestamp DEFAULT NULL",
    "ALTER TABLE `orders` ADD COLUMN IF NOT EXISTS `ebayOfferSavings` decimal(10,2) DEFAULT NULL",
    "ALTER TABLE `orders` ADD COLUMN IF NOT EXISTS `ebayOfferId` varchar(100) DEFAULT NULL",
    // Card events lifecycle table
    `CREATE TABLE IF NOT EXISTS \`cardEvents\` (
      \`id\` int AUTO_INCREMENT NOT NULL,
      \`collectionItemId\` int NOT NULL DEFAULT 0,
      \`cardId\` int,
      \`userEmail\` varchar(320),
      \`eventType\` enum('added','graded','listed','delisted','auction_started','auction_ended','bid_received','trade_offered','trade_agreed','trade_fee_paid','shipped_to_scg','received_by_scg','shipped_to_recipient','delivered','sold','traded','price_updated','note_added','imported','vaulted','casino_assigned','status_changed','auction_bid','auction_won','bulk_action') NOT NULL,
      \`description\` text,
      \`metadata\` text,
      \`createdAt\` timestamp NOT NULL DEFAULT (now()),
      CONSTRAINT \`cardEvents_id\` PRIMARY KEY(\`id\`)
    )`,
    // cardEvents: add cardId column if missing (for house card event tracking)
    "ALTER TABLE `cardEvents` ADD COLUMN IF NOT EXISTS `cardId` int",
    // cardEvents: expand eventType enum with new lifecycle values
    "ALTER TABLE `cardEvents` MODIFY COLUMN `eventType` enum('added','graded','listed','delisted','auction_started','auction_ended','bid_received','trade_offered','trade_agreed','trade_fee_paid','shipped_to_scg','received_by_scg','shipped_to_recipient','delivered','sold','traded','price_updated','note_added','imported','vaulted','casino_assigned','status_changed','auction_bid','auction_won','bulk_action') NOT NULL",
    // cardEvents: fix collectionItemId to allow DEFAULT 0 (nullable-safe)
    "ALTER TABLE `cardEvents` MODIFY COLUMN `collectionItemId` int NOT NULL DEFAULT 0",
    // cards: add freeShipping, isUpAndComing, isShowcaseCard, marketPrice, psaPrice columns
    "ALTER TABLE `cards` ADD COLUMN IF NOT EXISTS `freeShipping` boolean DEFAULT false",
    "ALTER TABLE `cards` ADD COLUMN IF NOT EXISTS `isUpAndComing` boolean DEFAULT false",
    "ALTER TABLE `cards` ADD COLUMN IF NOT EXISTS `isShowcaseCard` boolean DEFAULT false",
    "ALTER TABLE `cards` ADD COLUMN IF NOT EXISTS `marketPrice` decimal(10,2) DEFAULT NULL",
    "ALTER TABLE `cards` ADD COLUMN IF NOT EXISTS `psaPrice` decimal(10,2) DEFAULT NULL",
    "ALTER TABLE `cards` ADD COLUMN IF NOT EXISTS `buyNowPrice` decimal(10,2) DEFAULT NULL",
    // blog_posts: add videoUrl, view_count, click_count
    "ALTER TABLE `blog_posts` ADD COLUMN IF NOT EXISTS `videoUrl` text",
    "ALTER TABLE `blog_posts` ADD COLUMN IF NOT EXISTS `view_count` int NOT NULL DEFAULT 0",
    "ALTER TABLE `blog_posts` ADD COLUMN IF NOT EXISTS `click_count` int NOT NULL DEFAULT 0",
    // content_metrics: daily performance tracking per post
    `CREATE TABLE IF NOT EXISTS \`content_metrics\` (\`id\` int AUTO_INCREMENT NOT NULL, \`post_id\` int NOT NULL, \`date\` varchar(10) NOT NULL, \`views\` int NOT NULL DEFAULT 0, \`clicks\` int NOT NULL DEFAULT 0, \`youtube_views\` int NOT NULL DEFAULT 0, \`youtube_likes\` int NOT NULL DEFAULT 0, \`youtube_comments\` int NOT NULL DEFAULT 0, \`referrer\` varchar(256), \`createdAt\` timestamp NOT NULL DEFAULT (now()), CONSTRAINT \`content_metrics_id\` PRIMARY KEY(\`id\`))`,
    // cards: add qty column for merged duplicate listings
    "ALTER TABLE `cards` ADD COLUMN IF NOT EXISTS `qty` int NOT NULL DEFAULT 1",
  ];
  try {
    const conn = await mysql.createConnection(process.env.DATABASE_URL!);
    for (const stmt of statements) {
      try { await conn.execute(stmt); } catch (_e) { /* already exists */ }
    }
    await conn.end();
    console.log("[migrations] Applied.");
  } catch (err) {
    console.warn("[migrations] Skipped:", (err as Error).message);
  }
}

function isPortAvailable(port: number): Promise<boolean> {
  return new Promise(resolve => {
    const server = net.createServer();
    server.listen(port, () => {
      server.close(() => resolve(true));
    });
    server.on("error", () => resolve(false));
  });
}

async function findAvailablePort(startPort: number = 3000): Promise<number> {
  for (let port = startPort; port < startPort + 20; port++) {
    if (await isPortAvailable(port)) {
      return port;
    }
  }
  throw new Error(`No available port found starting from ${startPort}`);
}

async function startServer() {
  const app = express();
  const server = createServer(app);
  // IMPORTANT: Stripe webhook MUST be registered before express.json() for signature verification
  const { handleStripeWebhook } = await import("../stripeWebhook");
  app.post("/api/stripe/webhook", express.raw({ type: "application/json" }), handleStripeWebhook);
  // Configure body parser with larger size limit for file uploads
  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ limit: "50mb", extended: true }));
  // OAuth callback under /api/oauth/callback
  registerOAuthRoutes(app);
  // eBay Marketplace Account Deletion compliance endpoint
  registerEbayDeletionRoute(app);
  // Image proxy for external images (e.g. eBay) that block hotlinking
  app.get("/api/img-proxy", async (req: any, res: any) => {
    const rawUrl = req.query.url as string;
    if (!rawUrl) return res.status(400).send("Missing url");
    let targetUrl: string;
    try { targetUrl = decodeURIComponent(rawUrl); } catch { return res.status(400).send("Bad url"); }
    // Only proxy known safe image domains
    const allowed = ["ebayimg.com", "thumbs.ebaystatic.com"];
    const isAllowed = allowed.some(d => targetUrl.includes(d));
    if (!isAllowed) return res.status(403).send("Domain not allowed");
    try {
      const https = await import("https");
      const http = await import("http");
      const urlMod = await import("url");
      const parsed = new urlMod.URL(targetUrl);
      const client = parsed.protocol === "https:" ? https.default : http.default;
      const options = {
        hostname: parsed.hostname,
        path: parsed.pathname + parsed.search,
        headers: {
          "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36",
          "Referer": "https://www.ebay.com/",
          "Accept": "image/webp,image/apng,image/*,*/*;q=0.8",
        },
      };
      const proxyReq = client.get(options, (proxyRes: any) => {
        if (proxyRes.statusCode === 301 || proxyRes.statusCode === 302) {
          // Follow redirect
          const location = proxyRes.headers["location"];
          if (location) {
            res.redirect("/api/img-proxy?url=" + encodeURIComponent(location));
          } else {
            res.status(502).send("Redirect with no location");
          }
          return;
        }
        res.setHeader("Content-Type", proxyRes.headers["content-type"] || "image/jpeg");
        res.setHeader("Cache-Control", "public, max-age=86400");
        res.setHeader("Access-Control-Allow-Origin", "*");
        proxyRes.pipe(res);
      });
      proxyReq.on("error", (e: any) => { if (!res.headersSent) res.status(502).send("Proxy error: " + e.message); });
      proxyReq.setTimeout(10000, () => { proxyReq.destroy(); if (!res.headersSent) res.status(504).send("Timeout"); });
    } catch (e: any) {
      res.status(502).send("Proxy error: " + e.message);
    }
  });

  // Internal bulk import endpoint (protected by secret token, for admin scripts only)
  app.post("/api/internal/bulk-import-cards", async (req: any, res: any) => {
    const token = req.headers["x-internal-token"];
    if (token !== "sco-internal-import-2026") return res.status(401).json({ error: "Unauthorized" });
    try {
      const { createCard } = await import("../db");
      const cardsToImport = req.body.cards as any[];
      if (!Array.isArray(cardsToImport)) return res.status(400).json({ error: "cards must be an array" });
      let imported = 0;
      const errors: string[] = [];
      for (const card of cardsToImport) {
        try {
          await createCard({
            title: card.title,
            playerName: card.playerName,
            year: card.year,
            setName: card.setName,
            cardNumber: card.cardNumber,
            sport: card.sport || "basketball",
            condition: "graded",
            gradeCompany: card.gradeCompany || "Beckett",
            gradeScore: card.gradeScore || "10",
            price: card.price,
            category: card.category || "modern",
            status: card.status || "active",
            description: card.description,
            frontImageUrl: card.frontImageUrl || undefined,
            sellerEmail: "admin@sportcardsonline.com",
            storeName: "SCO House",
            isMainStore: true,
            source: "search_import",
            aiGrade: "10.00",
            aiGradeLabel: "GEM MINT",
          });
          imported++;
        } catch (e: any) {
          errors.push(`${card.title}: ${e.message}`);
        }
      }
      res.json({ success: true, imported, errors });
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });
  // Internal: get all house cards
  app.get("/api/internal/get-all-cards", async (req: any, res: any) => {
    const token = req.headers["x-internal-token"];
    if (token !== "sco-internal-import-2026") return res.status(401).json({ error: "Unauthorized" });
    try {
      const { getDb } = await import("../db");
      const db = await getDb();
      if (!db) return res.status(500).json({ error: "DB unavailable" });
      const { cards: cT } = await import("../../drizzle/schema");
      const allCards = await db.select().from(cT);
      res.json({ cards: allCards });
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  // Internal: update a card by id
  app.post("/api/internal/update-card", async (req: any, res: any) => {
    const token = req.headers["x-internal-token"];
    if (token !== "sco-internal-import-2026") return res.status(401).json({ error: "Unauthorized" });
    try {
      const { getDb } = await import("../db");
      const db = await getDb();
      if (!db) return res.status(500).json({ error: "DB unavailable" });
      const { cards: cT } = await import("../../drizzle/schema");
      const { eq } = await import("drizzle-orm");
      const { id, updates } = req.body;
      if (!id) return res.status(400).json({ error: "id required" });
      await db.update(cT).set(updates).where(eq(cT.id, id));
      res.json({ success: true });
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  // Internal: delete a card by id
  app.post("/api/internal/delete-card", async (req: any, res: any) => {
    const token = req.headers["x-internal-token"];
    if (token !== "sco-internal-import-2026") return res.status(401).json({ error: "Unauthorized" });
    try {
      const { getDb } = await import("../db");
      const db = await getDb();
      if (!db) return res.status(500).json({ error: "DB unavailable" });
      const { cards: cT } = await import("../../drizzle/schema");
      const { eq } = await import("drizzle-orm");
      const { id } = req.body;
      if (!id) return res.status(400).json({ error: "id required" });
      await db.delete(cT).where(eq(cT.id, id));
      res.json({ success: true });
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  // ============================================================================
  // SEO: Dynamic Sitemap
  // ============================================================================
  app.get("/sitemap.xml", async (_req: any, res: any) => {
    try {
      const { getDb } = await import("../db");
      const db = await getDb();
      const { cards } = await import("../../drizzle/schema");
      const { eq } = await import("drizzle-orm");
      const domain = "https://www.sportcardsonline.com";
      const now = new Date().toISOString().split("T")[0];
      const staticPages = [
        { url: "/", priority: "1.0", changefreq: "daily" },
        { url: "/marketplace", priority: "0.9", changefreq: "daily" },
        { url: "/vault", priority: "0.7", changefreq: "weekly" },
        { url: "/auctions", priority: "0.8", changefreq: "daily" },
        { url: "/trade", priority: "0.7", changefreq: "weekly" },
        { url: "/grading", priority: "0.7", changefreq: "weekly" },
        { url: "/tournaments", priority: "0.7", changefreq: "daily" },
      ];
      let cardUrls = "";
      if (db) {
        const allCards = await db
          .select({ id: cards.id, updatedAt: cards.updatedAt })
          .from(cards)
          .where(eq(cards.status, "active"))
          .limit(5000);
        cardUrls = allCards
          .map((c: any) => {
            const lastmod = c.updatedAt ? new Date(c.updatedAt).toISOString().split("T")[0] : now;
            return `  <url>\n    <loc>${domain}/card/${c.id}</loc>\n    <lastmod>${lastmod}</lastmod>\n    <changefreq>weekly</changefreq>\n    <priority>0.6</priority>\n  </url>`;
          })
          .join("\n");
      }
      const staticUrls = staticPages
        .map(
          (p) =>
            `  <url>\n    <loc>${domain}${p.url}</loc>\n    <lastmod>${now}</lastmod>\n    <changefreq>${p.changefreq}</changefreq>\n    <priority>${p.priority}</priority>\n  </url>`
        )
        .join("\n");
      const xml = `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${staticUrls}\n${cardUrls}\n</urlset>`;
      res.set("Content-Type", "application/xml");
      res.send(xml);
    } catch (e: any) {
      res.status(500).send("<!-- sitemap error -->");
    }
  });

  // tRPC API
  app.use(
    "/api/trpc",
    createExpressMiddleware({
      router: appRouter,
      createContext,
    })
  );
  // development mode uses Vite, production mode uses static files
  if (process.env.NODE_ENV === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  const preferredPort = parseInt(process.env.PORT || "3000");
  const port = await findAvailablePort(preferredPort);

  if (port !== preferredPort) {
    console.log(`Port ${preferredPort} is busy, using port ${port} instead`);
  }

  server.listen(port, () => {
    console.log(`Server running on http://localhost:${port}/`);
  });
}

runPendingMigrations().then(async () => {
  await startServer();
  // Start auction lifecycle background jobs (auto-renew, expiry)
  const { startAuctionJobs } = await import("../auctionJobs");
  startAuctionJobs();
  // Start eBay availability checker (runs every 4 hours, deletes unavailable dropship cards)
  const { startAvailabilityJobs } = await import("../ebayAvailabilityJobs");
  startAvailabilityJobs();
  // Start daily blog generation pipeline (runs every day at 7:00 AM)
  const { startBlogJobs } = await import("../blogJobs");
  startBlogJobs();
  // Start escrow auto-release & ship-reminder jobs (runs every 15 min)
  const { startEscrowJobs } = await import("../escrowJobs");
  startEscrowJobs();
  // Start daily 3 AM operations report email to admin
  const { startDailyReportJobs } = await import("../dailyReportJobs");
  startDailyReportJobs();
}).catch(console.error);
