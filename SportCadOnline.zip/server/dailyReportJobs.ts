/**
 * Daily 3 AM Operations Report
 *
 * Runs every day at 3:00 AM (server local time).
 * Queries the DB for yesterday's stats and emails a full summary to the admin.
 *
 * Report sections:
 *  1. New Orders (count, total revenue, pending fulfilment)
 *  2. Active Auctions (count, highest bids, ending within 24 hrs)
 *  3. Revenue Summary (yesterday vs. 7-day avg)
 *  4. Escrow Status (funds pending release, overdue)
 *  5. Low Inventory Alert (cards with price < $50 and qty = 1)
 *  6. New User Registrations
 *  7. Blog Posts Published Yesterday
 */
import { getDb } from "./db";
import { orders, auctions, cards, users, blogPosts } from "../drizzle/schema";
import { and, gte, lt, lte, eq, count, sql } from "drizzle-orm";
import { sendEmail, ADMIN_EMAIL } from "./email";
import PDFDocument from "pdfkit";

// ─── Schedule: run at 3:00 AM every day ─────────────────────────────────────
export function startDailyReportJobs() {
  console.log("[DailyReport] Scheduling 3 AM operations report");

  // Calculate ms until next 3:00 AM
  function msUntilNext3AM(): number {
    const now = new Date();
    const next = new Date(now);
    next.setHours(3, 0, 0, 0);
    if (next <= now) next.setDate(next.getDate() + 1);
    return next.getTime() - now.getTime();
  }

  // Schedule first run
  setTimeout(() => {
    runDailyReport().catch(console.error);
    // Then repeat every 24 hours
    setInterval(() => {
      runDailyReport().catch(console.error);
    }, 24 * 60 * 60 * 1000);
  }, msUntilNext3AM());

  console.log(`[DailyReport] Next report in ${Math.round(msUntilNext3AM() / 60000)} minutes`);
}

// ─── Main report runner ───────────────────────────────────────────────────────
async function runDailyReport() {
  console.log("[DailyReport] Generating daily operations report...");
  try {
    const db = await getDb();
    if (!db) {
      console.error("[DailyReport] DB unavailable — skipping report");
      return;
    }

    const now = new Date();
    const todayStart = new Date(now);
    todayStart.setHours(0, 0, 0, 0);
    const yesterdayStart = new Date(todayStart);
    yesterdayStart.setDate(yesterdayStart.getDate() - 1);
    const sevenDaysAgo = new Date(todayStart);
    sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);
    const next24h = new Date(now.getTime() + 24 * 60 * 60 * 1000);

    // ── 1. New Orders (yesterday) ──────────────────────────────────────────
    const newOrders = await db
      .select()
      .from(orders)
      .where(and(gte(orders.createdAt, yesterdayStart), lt(orders.createdAt, todayStart)));

    const orderRevenue = newOrders.reduce((sum, o) => sum + parseFloat(String(o.totalAmount ?? o.price ?? 0)), 0);
    const pendingShipment = newOrders.filter(o => o.status === "paid" || o.status === "label_created").length;
    const completedOrders = newOrders.filter(o => o.fundsReleased).length;

    // ── 2. Active Auctions ─────────────────────────────────────────────────
    const activeAuctions = await db
      .select()
      .from(auctions)
      .where(eq(auctions.status, "active"));

    const endingSoon = activeAuctions.filter(a => new Date(a.endTime) <= next24h);
    const totalBidValue = activeAuctions.reduce((sum, a) => sum + parseFloat(String(a.currentBid ?? 0)), 0);

    // ── 3. Revenue: 7-day window ───────────────────────────────────────────
    const weekOrders = await db
      .select()
      .from(orders)
      .where(gte(orders.createdAt, sevenDaysAgo));

    const weekRevenue = weekOrders.reduce((sum, o) => sum + parseFloat(String(o.totalAmount ?? o.price ?? 0)), 0);
    const dailyAvg = weekRevenue / 7;

    // ── 4. Escrow Status ───────────────────────────────────────────────────
    const pendingEscrow = await db
      .select()
      .from(orders)
      .where(and(eq(orders.status, "shipped"), eq(orders.fundsReleased, false)));

    const overdueEscrow = pendingEscrow.filter(
      o => o.autoReleaseAt && new Date(o.autoReleaseAt) < now
    );

    // ── 5. Low Inventory Alert ─────────────────────────────────────────────
    const lowInventory = await db
      .select()
      .from(cards)
      .where(and(eq(cards.status, "active"), eq(cards.isMainStore, true)))
      .limit(200);

    // Cards priced under $50 (potential pricing issues) or only 1 left
    const lowPriceCards = lowInventory.filter(c => parseFloat(String(c.price ?? 0)) < 50 && parseFloat(String(c.price ?? 0)) > 0);

    // ── 6. New User Registrations ──────────────────────────────────────────
    const newUsers = await db
      .select()
      .from(users)
      .where(and(gte(users.createdAt, yesterdayStart), lt(users.createdAt, todayStart)));

    // ── 7. Blog Posts Published Yesterday ─────────────────────────────────
    const newBlogPosts = await db
      .select()
      .from(blogPosts)
      .where(and(gte(blogPosts.publishedAt, yesterdayStart), lt(blogPosts.publishedAt, todayStart)));

    // ── Build HTML report ──────────────────────────────────────────────────
    const reportDate = yesterdayStart.toLocaleDateString("en-US", { weekday: "long", year: "numeric", month: "long", day: "numeric" });
    const revenueVsAvg = orderRevenue > dailyAvg
      ? `<span style="color:#22c55e">▲ +$${(orderRevenue - dailyAvg).toFixed(2)} vs 7-day avg</span>`
      : `<span style="color:#ef4444">▼ -$${(dailyAvg - orderRevenue).toFixed(2)} vs 7-day avg</span>`;

    const html = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <style>
    body { font-family: Arial, sans-serif; background: #0f172a; color: #e2e8f0; margin: 0; padding: 0; }
    .container { max-width: 680px; margin: 0 auto; padding: 32px 24px; }
    .header { background: linear-gradient(135deg, #1e3a5f, #0f172a); border-radius: 12px 12px 0 0; padding: 28px 32px; border-bottom: 3px solid #c9a84c; }
    .header h1 { margin: 0; font-size: 24px; color: #c9a84c; }
    .header p { margin: 6px 0 0; color: #94a3b8; font-size: 14px; }
    .section { background: #1e293b; border-radius: 8px; padding: 20px 24px; margin: 16px 0; border-left: 4px solid #c9a84c; }
    .section h2 { margin: 0 0 14px; font-size: 16px; color: #c9a84c; text-transform: uppercase; letter-spacing: 0.05em; }
    .stat-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 12px; }
    .stat { background: #0f172a; border-radius: 6px; padding: 12px 16px; text-align: center; }
    .stat .value { font-size: 28px; font-weight: 700; color: #f8fafc; }
    .stat .label { font-size: 12px; color: #64748b; margin-top: 4px; }
    table { width: 100%; border-collapse: collapse; font-size: 13px; }
    th { background: #0f172a; color: #94a3b8; padding: 8px 12px; text-align: left; font-weight: 600; }
    td { padding: 8px 12px; border-bottom: 1px solid #1e293b; color: #e2e8f0; }
    .badge { display: inline-block; padding: 2px 8px; border-radius: 9999px; font-size: 11px; font-weight: 600; }
    .badge-red { background: #7f1d1d; color: #fca5a5; }
    .badge-green { background: #14532d; color: #86efac; }
    .badge-yellow { background: #713f12; color: #fde68a; }
    .footer { text-align: center; padding: 20px; color: #475569; font-size: 12px; }
    .portal-btn { display: inline-block; background: linear-gradient(135deg, #c9a84c, #e8c96a); color: #0f172a; font-weight: 700; font-size: 14px; padding: 12px 28px; border-radius: 8px; text-decoration: none; margin: 8px 4px; }
    .portal-btn-outline { display: inline-block; background: transparent; color: #c9a84c; font-weight: 600; font-size: 13px; padding: 8px 18px; border-radius: 6px; text-decoration: none; border: 1px solid #c9a84c; margin: 4px; }
    .alert { background: #7f1d1d; border: 1px solid #dc2626; border-radius: 6px; padding: 12px 16px; margin-bottom: 12px; color: #fca5a5; font-size: 13px; }
  </style>
</head>
<body>
<div class="container">
  <div class="header">
    <h1>📊 Daily Operations Report</h1>
    <p>SportsCardsOnline.com · ${reportDate}</p>
  </div>

  <!-- Revenue Summary -->
  <div class="section">
    <h2>💰 Revenue Summary</h2>
    <div class="stat-grid">
      <div class="stat">
        <div class="value">$${orderRevenue.toFixed(2)}</div>
        <div class="label">Yesterday Revenue</div>
      </div>
      <div class="stat">
        <div class="value">$${dailyAvg.toFixed(2)}</div>
        <div class="label">7-Day Daily Avg</div>
      </div>
      <div class="stat">
        <div class="value">$${weekRevenue.toFixed(2)}</div>
        <div class="label">7-Day Total</div>
      </div>
    </div>
    <p style="margin:12px 0 0; font-size:13px;">${revenueVsAvg}</p>
  </div>

  <!-- New Orders -->
  <div class="section">
    <h2>🛒 New Orders (${newOrders.length})</h2>
    ${newOrders.length === 0 ? '<p style="color:#64748b;font-size:13px;">No new orders yesterday.</p>' : `
    <div class="stat-grid" style="grid-template-columns: repeat(3,1fr); margin-bottom:16px;">
      <div class="stat"><div class="value">${newOrders.length}</div><div class="label">Total Orders</div></div>
      <div class="stat"><div class="value">${pendingShipment}</div><div class="label">Awaiting Shipment</div></div>
      <div class="stat"><div class="value">${completedOrders}</div><div class="label">Completed</div></div>
    </div>
    <table>
      <tr><th>Ticket</th><th>Card</th><th>Buyer</th><th>Amount</th><th>Status</th></tr>
      ${newOrders.slice(0, 10).map(o => `
      <tr>
        <td>#${o.ticketNumber ?? o.id}</td>
        <td>${(o.cardTitle ?? "—").slice(0, 35)}</td>
        <td>${o.buyerEmail ?? "—"}</td>
        <td>$${parseFloat(String(o.totalAmount ?? o.price ?? 0)).toFixed(2)}</td>
        <td><span class="badge ${o.fundsReleased ? "badge-green" : o.status === "shipped" ? "badge-yellow" : "badge-red"}">${o.status}</span></td>
      </tr>`).join("")}
    </table>
    ${newOrders.length > 10 ? `<p style="color:#64748b;font-size:12px;margin-top:8px;">+ ${newOrders.length - 10} more orders</p>` : ""}
    `}
  </div>

  <!-- Escrow Status -->
  <div class="section">
    <h2>🔒 Escrow Status</h2>
    ${overdueEscrow.length > 0 ? `<div class="alert">⚠️ ${overdueEscrow.length} order(s) are OVERDUE for auto-release — check immediately!</div>` : ""}
    <div class="stat-grid">
      <div class="stat"><div class="value">${pendingEscrow.length}</div><div class="label">Funds Held</div></div>
      <div class="stat"><div class="value">$${pendingEscrow.reduce((s, o) => s + parseFloat(String(o.totalAmount ?? o.price ?? 0)), 0).toFixed(2)}</div><div class="label">Total Held</div></div>
      <div class="stat"><div class="value">${overdueEscrow.length}</div><div class="label">Overdue</div></div>
    </div>
  </div>

  <!-- Active Auctions -->
  <div class="section">
    <h2>🔨 Active Auctions (${activeAuctions.length})</h2>
    <div class="stat-grid" style="margin-bottom:16px;">
      <div class="stat"><div class="value">${activeAuctions.length}</div><div class="label">Live Auctions</div></div>
      <div class="stat"><div class="value">${endingSoon.length}</div><div class="label">Ending in 24h</div></div>
      <div class="stat"><div class="value">$${totalBidValue.toFixed(2)}</div><div class="label">Total Bid Value</div></div>
    </div>
    ${endingSoon.length > 0 ? `
    <table>
      <tr><th>Card</th><th>Current Bid</th><th>Ends</th></tr>
      ${endingSoon.slice(0, 5).map(a => `
      <tr>
        <td>${(a.cardTitle ?? "—").slice(0, 40)}</td>
        <td>$${parseFloat(String(a.currentBid ?? 0)).toFixed(2)}</td>
        <td>${new Date(a.endTime).toLocaleString()}</td>
      </tr>`).join("")}
    </table>` : ""}
  </div>

  <!-- Low Inventory Alert -->
  ${lowPriceCards.length > 0 ? `
  <div class="section">
    <h2>⚠️ Low Price Alert (${lowPriceCards.length} cards under $50)</h2>
    <table>
      <tr><th>Card</th><th>Price</th><th>Sport</th></tr>
      ${lowPriceCards.slice(0, 8).map(c => `
      <tr>
        <td>${(c.title ?? "—").slice(0, 40)}</td>
        <td>$${parseFloat(String(c.price ?? 0)).toFixed(2)}</td>
        <td>${c.sport ?? "—"}</td>
      </tr>`).join("")}
    </table>
    ${lowPriceCards.length > 8 ? `<p style="color:#64748b;font-size:12px;margin-top:8px;">+ ${lowPriceCards.length - 8} more</p>` : ""}
  </div>` : ""}

  <!-- New Users & Blog -->
  <div class="section">
    <h2>👥 New Registrations & Content</h2>
    <div class="stat-grid">
      <div class="stat"><div class="value">${newUsers.length}</div><div class="label">New Users</div></div>
      <div class="stat"><div class="value">${newBlogPosts.length}</div><div class="label">Blog Posts</div></div>
      <div class="stat"><div class="value">${activeAuctions.filter(a => a.bidCount && a.bidCount > 0).length}</div><div class="label">Auctions w/ Bids</div></div>
    </div>
    ${newBlogPosts.length > 0 ? `
    <table style="margin-top:12px;">
      <tr><th>Blog Post</th><th>Sport</th></tr>
      ${newBlogPosts.map(p => `<tr><td>${(p.title ?? "—").slice(0, 55)}</td><td>${p.sport ?? "—"}</td></tr>`).join("")}
    </table>` : ""}
  </div>

  <!-- Portal CTA Buttons -->
  <div style="background:#1e293b; border-radius:8px; padding:24px; margin:16px 0; text-align:center;">
    <p style="color:#94a3b8; font-size:13px; margin:0 0 16px;">Jump directly to the section that needs attention:</p>
    <a href="https://cardvault-l9wjitqm.manus.space/admin?tab=orders" class="portal-btn">📦 View Orders</a>
    <a href="https://cardvault-l9wjitqm.manus.space/admin?tab=escrow" class="portal-btn">🔒 Manage Escrow</a>
    <a href="https://cardvault-l9wjitqm.manus.space/admin?tab=disputes" class="portal-btn" style="background:linear-gradient(135deg,#dc2626,#ef4444);color:#fff;">🚨 Open Disputes</a>
    <br/>
    <a href="https://cardvault-l9wjitqm.manus.space/admin?tab=auctions" class="portal-btn-outline">🔨 Auctions</a>
    <a href="https://cardvault-l9wjitqm.manus.space/admin?tab=cards" class="portal-btn-outline">🃏 Inventory</a>
    <a href="https://cardvault-l9wjitqm.manus.space/admin?tab=users" class="portal-btn-outline">👥 Users</a>
    <a href="https://cardvault-l9wjitqm.manus.space/admin?tab=blog" class="portal-btn-outline">📝 Blog</a>
  </div>

  <div class="footer">
    <p>SportsCardsOnline.com · Automated Operations Report · Generated at ${now.toLocaleString()}</p>
    <p>Click any button above to go directly to that section in the admin portal.</p>
  </div>
</div>
</body>
</html>`;

    // ── Generate PDF attachment ────────────────────────────────────────────
    const pdfBuffer = await generateOrdersPdf(newOrders, reportDate, orderRevenue, pendingShipment, completedOrders);

    // Send the report
    await sendEmail({
      to: ADMIN_EMAIL,
      subject: `📊 Daily Ops Report — ${reportDate} | Orders: ${newOrders.length} | Revenue: $${orderRevenue.toFixed(2)}`,
      html,
      attachments: pdfBuffer ? [{
        filename: `orders-${yesterdayStart.toISOString().slice(0, 10)}.pdf`,
        content: pdfBuffer,
        contentType: "application/pdf",
      }] : undefined,
    });

    console.log(`[DailyReport] Report sent to ${ADMIN_EMAIL} — ${newOrders.length} orders, $${orderRevenue.toFixed(2)} revenue`);
  } catch (err) {
    console.error("[DailyReport] Failed to generate/send report:", err);
  }
}

// ─── PDF Generator ────────────────────────────────────────────────────────────
async function generateOrdersPdf(
  orderList: any[],
  reportDate: string,
  totalRevenue: number,
  pendingShipment: number,
  completedOrders: number
): Promise<Buffer | null> {
  try {
    return await new Promise<Buffer>((resolve, reject) => {
      const doc = new PDFDocument({ margin: 40, size: "LETTER" });
      const chunks: Buffer[] = [];
      doc.on("data", (chunk: Buffer) => chunks.push(chunk));
      doc.on("end", () => resolve(Buffer.concat(chunks)));
      doc.on("error", reject);

      // ── Header ──────────────────────────────────────────────────────────────
      doc.rect(0, 0, doc.page.width, 70).fill("#0d1f3c");
      doc.fillColor("#ffffff").fontSize(18).font("Helvetica-Bold")
        .text("SportsCardsOnline.com", 40, 18);
      doc.fontSize(10).font("Helvetica").fillColor("#aaaacc")
        .text(`Daily Orders Report — ${reportDate}`, 40, 42);
      doc.fillColor("#C41E3A").fontSize(10)
        .text(`Generated: ${new Date().toLocaleString()}`, 40, 56);

      // ── Summary Row ─────────────────────────────────────────────────────────
      doc.moveDown(3);
      const summaryY = 90;
      const cols = [
        { label: "Total Orders", value: String(orderList.length) },
        { label: "Revenue", value: `$${totalRevenue.toFixed(2)}` },
        { label: "Pending Ship", value: String(pendingShipment) },
        { label: "Completed", value: String(completedOrders) },
      ];
      const boxW = (doc.page.width - 80) / cols.length;
      cols.forEach((col, i) => {
        const x = 40 + i * boxW;
        doc.rect(x, summaryY, boxW - 8, 50).fillAndStroke("#f8f9fa", "#dddddd");
        doc.fillColor("#333333").fontSize(9).font("Helvetica")
          .text(col.label, x + 6, summaryY + 8, { width: boxW - 20 });
        doc.fillColor("#0d1f3c").fontSize(16).font("Helvetica-Bold")
          .text(col.value, x + 6, summaryY + 22, { width: boxW - 20 });
      });

      // ── Orders Table ─────────────────────────────────────────────────────────
      doc.moveDown(1);
      const tableTop = summaryY + 70;
      doc.fillColor("#0d1f3c").fontSize(12).font("Helvetica-Bold")
        .text("Order Details", 40, tableTop);

      // Table header
      const headerY = tableTop + 18;
      doc.rect(40, headerY, doc.page.width - 80, 18).fill("#0d1f3c");
      const headers = ["Order ID", "Card", "Buyer", "Amount", "Status", "Date"];
      const colWidths = [60, 160, 100, 65, 70, 75];
      let xPos = 44;
      headers.forEach((h, i) => {
        doc.fillColor("#ffffff").fontSize(8).font("Helvetica-Bold")
          .text(h, xPos, headerY + 5, { width: colWidths[i] });
        xPos += colWidths[i];
      });

      // Table rows
      let rowY = headerY + 20;
      if (orderList.length === 0) {
        doc.fillColor("#888888").fontSize(10).font("Helvetica")
          .text("No orders placed yesterday.", 40, rowY);
      } else {
        orderList.forEach((order, idx) => {
          if (rowY > doc.page.height - 80) {
            doc.addPage();
            rowY = 40;
          }
          const bg = idx % 2 === 0 ? "#ffffff" : "#f5f5f8";
          doc.rect(40, rowY, doc.page.width - 80, 16).fill(bg);
          const rowData = [
            `#${order.id}`,
            (order.cardTitle || order.cardId || "—").toString().slice(0, 28),
            (order.buyerEmail || "—").toString().slice(0, 20),
            `$${parseFloat(String(order.totalAmount ?? order.price ?? 0)).toFixed(2)}`,
            (order.status || "—").toString(),
            order.createdAt ? new Date(order.createdAt).toLocaleDateString() : "—",
          ];
          xPos = 44;
          rowData.forEach((cell, i) => {
            doc.fillColor("#333333").fontSize(7.5).font("Helvetica")
              .text(cell, xPos, rowY + 4, { width: colWidths[i], ellipsis: true });
            xPos += colWidths[i];
          });
          rowY += 17;
        });
      }

      // ── Footer ───────────────────────────────────────────────────────────────
      const footerY = doc.page.height - 40;
      doc.rect(0, footerY - 5, doc.page.width, 45).fill("#0d1f3c");
      doc.fillColor("#aaaacc").fontSize(8).font("Helvetica")
        .text("SportsCardsOnline.com · Confidential Operations Report · Do not distribute", 40, footerY + 5);

      doc.end();
    });
  } catch (err) {
    console.error("[DailyReport] PDF generation failed:", err);
    return null;
  }
}
