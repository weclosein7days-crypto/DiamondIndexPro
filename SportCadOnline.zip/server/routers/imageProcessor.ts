/**
 * Image Processor tRPC Router
 * ────────────────────────────
 * Procedures for triggering and monitoring the card image processing pipeline.
 *
 * Procedures:
 *   imageProcessor.processCard         — Process a single card (admin only)
 *   imageProcessor.processBatch        — Process multiple cards (admin only)
 *   imageProcessor.processHouseCards   — Process all 100 house cards (admin only)
 *   imageProcessor.getStatus           — Get pipeline status and job queue
 *   imageProcessor.previewCrop         — Preview crop result without saving to S3
 *   imageProcessor.fetchEbayImages     — Fetch front/back URLs from eBay listing
 */

import { z } from "zod";
import { router, protectedProcedure } from "../_core/trpc";
import { TRPCError } from "@trpc/server";
import { getDb } from "../db";
import { cards, type Card } from "../../drizzle/schema";
import { eq } from "drizzle-orm";
import { processCardImages, processCardImage, fetchImageBuffer, detectCardFace, calculateFrameBorderPx } from "../imageProcessor";
import { fetchEbayItemImages, fetchEbayImagesBatch, upgradeEbayImageUrl } from "../ebayImageFetcher";
import { storagePut } from "../storage";
import sharp from "sharp";

// ─── In-memory job queue (simple, no Redis needed) ────────────────────────────

interface ProcessingJob {
  jobId: string;
  status: "pending" | "running" | "done" | "error";
  total: number;
  done: number;
  errors: number;
  startedAt: number;
  completedAt?: number;
  results: Array<{
    cardId: number;
    cardName: string;
    frontUrl: string | null;
    backUrl: string | null;
    notes: string[];
    error?: string;
  }>;
  currentCard?: string;
}

const jobQueue = new Map<string, ProcessingJob>();

function createJobId(): string {
  return `job_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
}

// ─── Admin guard ──────────────────────────────────────────────────────────────

const adminProcedure = protectedProcedure.use(({ ctx, next }) => {
  if (ctx.user.role !== "admin") {
    throw new TRPCError({ code: "FORBIDDEN", message: "Admin access required" });
  }
  return next({ ctx });
});

// ─── Router ───────────────────────────────────────────────────────────────────

export const imageProcessorRouter = router({

  /**
   * Process a single card by ID.
   * Fetches eBay images, crops, frames, and stores in S3.
   * Updates the card's frontImageUrl and backImageUrl in the database.
   */
  processCard: adminProcedure
    .input(z.object({
      cardId: z.number(),
      /** Override front image URL (optional — fetched from eBay if not provided) */
      frontImageUrl: z.string().url().optional(),
      /** Override back image URL (optional) */
      backImageUrl: z.string().url().optional(),
      /** Add 1/8-inch white border frame (default: true) */
      addFrame: z.boolean().default(true),
      /** Frame border color (default: white) */
      frameColor: z.object({ r: z.number(), g: z.number(), b: z.number() }).optional(),
      /** Skip PSA compliance check (default: false) */
      skipComplianceCheck: z.boolean().default(false),
    }))
    .mutation(async ({ input }) => {
      // Fetch card from DB
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "DB unavailable" });
      const [card] = await db.select().from(cards).where(eq(cards.id, input.cardId)).limit(1) as Card[];
      if (!card) throw new TRPCError({ code: "NOT_FOUND", message: `Card ${input.cardId} not found` });

      let frontUrl = input.frontImageUrl;
      let backUrl = input.backImageUrl ?? undefined;

      // If no override URLs, fetch from eBay
      if (!frontUrl && card.ebayItemId) {
        const ebayImages = await fetchEbayItemImages(card.ebayItemId);
        if (ebayImages.error) {
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message: `eBay image fetch failed: ${ebayImages.error}`,
          });
        }
        frontUrl = ebayImages.frontImageUrl ?? undefined;
        backUrl = backUrl ?? ebayImages.backImageUrl ?? undefined;
      }

      // Fall back to existing image URLs
      frontUrl = frontUrl ?? card.frontImageUrl ?? undefined;
      backUrl = backUrl ?? card.backImageUrl ?? undefined;

      if (!frontUrl) {
        throw new TRPCError({
          code: "BAD_REQUEST",
          message: "No front image URL available — provide frontImageUrl or ensure card has ebayItemId",
        });
      }

      // Process images
      const result = await processCardImages({
        cardId: String(input.cardId),
        frontImageUrl: frontUrl,
        backImageUrl: backUrl ?? null,
        addFrame: input.addFrame,
        frameColor: input.frameColor,
        skipComplianceCheck: input.skipComplianceCheck,
      });

      // Update card in DB with new processed image URLs
      if (result.frontUrl && db) {
        await db.update(cards)
          .set({
            frontImageUrl: result.frontUrl,
            ...(result.backUrl ? { backImageUrl: result.backUrl } : {}),
          })
          .where(eq(cards.id, input.cardId));
      }

      return {
        cardId: input.cardId,
        cardName: card.title,
        frontUrl: result.frontUrl,
        backUrl: result.backUrl,
        width: result.width,
        height: result.height,
        psaCompliant: result.psaCompliant,
        processingNotes: result.processingNotes,
        error: result.error,
      };
    }),

  /**
   * Process all house cards (or a subset) in the background.
   * Returns a job ID for polling status.
   */
  processHouseCards: adminProcedure
    .input(z.object({
      /** Maximum number of cards to process (default: all) */
      limit: z.number().min(1).max(100).default(100),
      /** Only process cards that don't have a processed front image yet */
      onlyMissing: z.boolean().default(true),
      /** Add 1/8-inch white border frame */
      addFrame: z.boolean().default(true),
      /** Delay between cards in ms (to respect eBay rate limits) */
      delayMs: z.number().min(0).max(5000).default(800),
    }))
    .mutation(async ({ input }) => {
      // Get house cards from DB
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "DB unavailable" });
      const houseCards = await db.select({
        id: cards.id,
        title: cards.title,
        ebayItemId: cards.ebayItemId,
        frontImageUrl: cards.frontImageUrl,
        backImageUrl: cards.backImageUrl,
        isDropship: cards.isDropship,
      }).from(cards)
        .where(eq(cards.isDropship, true))
        .limit(input.limit);

      type HouseCardRow = typeof houseCards[0];
      // Filter to only missing if requested
      const toProcess = input.onlyMissing
        ? houseCards.filter((c: HouseCardRow) => !c.frontImageUrl || c.frontImageUrl.includes("ebayimg.com") || c.frontImageUrl.includes("ebay.com"))
        : houseCards;

      if (toProcess.length === 0) {
        return { jobId: null, message: "No cards to process — all house cards already have processed images", total: 0 };
      }

      // Create job
      const jobId = createJobId();
      const job: ProcessingJob = {
        jobId,
        status: "pending",
        total: toProcess.length,
        done: 0,
        errors: 0,
        startedAt: Date.now(),
        results: [],
      };
      jobQueue.set(jobId, job);

      // Run in background (don't await)
      (async () => {
        job.status = "running";

        for (const card of toProcess) {
          job.currentCard = card.title;

          try {
            // Fetch eBay images
            let frontUrl: string | null = null;
            let backUrl: string | null = null;

            if (card.ebayItemId) {
              const ebayImages = await fetchEbayItemImages(card.ebayItemId);
              frontUrl = ebayImages.frontImageUrl;
              backUrl = ebayImages.backImageUrl;
            }

            // Fall back to existing URLs
            frontUrl = frontUrl ?? card.frontImageUrl ?? null;
            backUrl = backUrl ?? card.backImageUrl ?? null;

            if (!frontUrl) {
              job.results.push({
                cardId: card.id,
                cardName: card.title,
                frontUrl: null,
                backUrl: null,
                notes: [],
                error: "No image URL available",
              });
              job.errors++;
              job.done++;
              continue;
            }

            // Process images
            const result = await processCardImages({
              cardId: String(card.id),
              frontImageUrl: frontUrl,
              backImageUrl: backUrl,
              addFrame: input.addFrame,
            });

            // Update DB
            if (result.frontUrl) {
              const dbInner = await getDb();
              if (dbInner) await dbInner.update(cards)
                .set({
                  frontImageUrl: result.frontUrl,
                  ...(result.backUrl ? { backImageUrl: result.backUrl } : {}),
                })
                .where(eq(cards.id, card.id));
            }

            job.results.push({
              cardId: card.id,
              cardName: card.title,
              frontUrl: result.frontUrl,
              backUrl: result.backUrl,
              notes: result.processingNotes,
              error: result.error,
            });

            if (result.error || !result.frontUrl) job.errors++;
          } catch (e) {
            job.results.push({
              cardId: card.id,
              cardName: card.title,
              frontUrl: null,
              backUrl: null,
              notes: [],
              error: (e as Error).message,
            });
            job.errors++;
          }

          job.done++;

          // Rate limit delay
          if (input.delayMs > 0) {
            await new Promise(r => setTimeout(r, input.delayMs));
          }
        }

        job.status = "done";
        job.completedAt = Date.now();
        job.currentCard = undefined;
      })();

      return {
        jobId,
        message: `Processing ${toProcess.length} house cards in background`,
        total: toProcess.length,
      };
    }),

  /**
   * Get the status of a processing job.
   */
  getJobStatus: adminProcedure
    .input(z.object({ jobId: z.string() }))
    .query(({ input }) => {
      const job = jobQueue.get(input.jobId);
      if (!job) throw new TRPCError({ code: "NOT_FOUND", message: `Job ${input.jobId} not found` });

      return {
        jobId: job.jobId,
        status: job.status,
        total: job.total,
        done: job.done,
        errors: job.errors,
        progress: job.total > 0 ? Math.round((job.done / job.total) * 100) : 0,
        startedAt: job.startedAt,
        completedAt: job.completedAt,
        elapsedMs: (job.completedAt ?? Date.now()) - job.startedAt,
        currentCard: job.currentCard,
        recentResults: job.results.slice(-5), // Last 5 results for live preview
        allResults: job.status === "done" ? job.results : [],
      };
    }),

  /**
   * List all recent processing jobs.
   */
  listJobs: adminProcedure
    .query(() => {
      const jobs = Array.from(jobQueue.values())
        .sort((a, b) => b.startedAt - a.startedAt)
        .slice(0, 20)
        .map(j => ({
          jobId: j.jobId,
          status: j.status,
          total: j.total,
          done: j.done,
          errors: j.errors,
          progress: j.total > 0 ? Math.round((j.done / j.total) * 100) : 0,
          startedAt: j.startedAt,
          completedAt: j.completedAt,
        }));
      return jobs;
    }),

  /**
   * Preview the crop result for a card image without saving to S3.
   * Returns a base64-encoded JPEG of the cropped + framed result.
   */
  previewCrop: adminProcedure
    .input(z.object({
      imageUrl: z.string().url(),
      addFrame: z.boolean().default(true),
    }))
    .mutation(async ({ input }) => {
      const buffer = await fetchImageBuffer(input.imageUrl);
      if (!buffer) throw new TRPCError({ code: "BAD_REQUEST", message: "Could not fetch image" });

      const face = await detectCardFace(buffer);
      const meta = await sharp(buffer).metadata();
      const imgW = meta.width ?? 800;
      const imgH = meta.height ?? 1000;

      const SAFETY = face.confidence === "high" ? 2 : 8;
      const cropLeft = Math.max(0, face.left - SAFETY);
      const cropTop = Math.max(0, face.top - SAFETY);
      const cropW = Math.min(imgW - cropLeft, face.width + SAFETY * 2);
      const cropH = Math.min(imgH - cropTop, face.height + SAFETY * 2);

      let pipeline = sharp(buffer)
        .extract({ left: cropLeft, top: cropTop, width: cropW, height: cropH })
        .resize({ width: 400, fit: "inside" });

      let previewBuffer: Buffer;

      if (input.addFrame) {
        const resized = await pipeline.toBuffer();
        const rMeta = await sharp(resized).metadata();
        const rW = rMeta.width ?? 400;
        const rH = rMeta.height ?? 560;
        const border = calculateFrameBorderPx(rW);

        previewBuffer = await sharp({
          create: { width: rW + border * 2, height: rH + border * 2, channels: 3, background: { r: 255, g: 255, b: 255 } },
        })
          .composite([{ input: resized, left: border, top: border }])
          .jpeg({ quality: 85 })
          .toBuffer();
      } else {
        previewBuffer = await pipeline.jpeg({ quality: 85 }).toBuffer();
      }

      return {
        previewBase64: `data:image/jpeg;base64,${previewBuffer.toString("base64")}`,
        detection: {
          type: face.type,
          confidence: face.confidence,
          cropRegion: { left: cropLeft, top: cropTop, width: cropW, height: cropH },
          originalSize: { width: imgW, height: imgH },
        },
      };
    }),

  /**
   * Fetch front + back image URLs from an eBay listing.
   * Useful for previewing before processing.
   */
  fetchEbayImages: adminProcedure
    .input(z.object({ ebayItemId: z.string() }))
    .query(async ({ input }) => {
      const images = await fetchEbayItemImages(input.ebayItemId);
      return {
        itemId: images.itemId,
        title: images.title,
        frontImageUrl: images.frontImageUrl,
        backImageUrl: images.backImageUrl,
        allImageUrls: images.allImageUrls,
        imageCount: images.imageCount,
        error: images.error,
      };
    }),

  /**
   * Get processing statistics for house cards.
   */
  getStats: adminProcedure
    .query(async () => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "DB unavailable" });
      const allHouseCards = await db.select({
        id: cards.id,
        frontImageUrl: cards.frontImageUrl,
        backImageUrl: cards.backImageUrl,
      }).from(cards).where(eq(cards.isDropship, true));

      type HouseCardRow = typeof allHouseCards[0];
      const total = allHouseCards.length;
      const hasProcessedFront = allHouseCards.filter((c: HouseCardRow) =>
        c.frontImageUrl && !c.frontImageUrl.includes("ebayimg.com") && !c.frontImageUrl.includes("ebay.com")
      ).length;
      const hasBack = allHouseCards.filter((c: HouseCardRow) => c.backImageUrl).length;
      const hasProcessedBack = allHouseCards.filter((c: HouseCardRow) =>
        c.backImageUrl && !c.backImageUrl.includes("ebayimg.com") && !c.backImageUrl.includes("ebay.com")
      ).length;
      const missing = total - hasProcessedFront;

      return {
        total,
        hasProcessedFront,
        hasProcessedBack,
        hasBack,
        missing,
        percentComplete: total > 0 ? Math.round((hasProcessedFront / total) * 100) : 0,
        activeJobs: Array.from(jobQueue.values()).filter(j => j.status === "running").length,
        recentJobs: Array.from(jobQueue.values())
          .sort((a, b) => b.startedAt - a.startedAt)
          .slice(0, 5)
          .map(j => ({ jobId: j.jobId, status: j.status, total: j.total, done: j.done, errors: j.errors })),
      };
    }),
});
