import { router, protectedProcedure, publicProcedure } from "../_core/trpc";
import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { getDb, addCredits } from "../db";
import { affiliates, affiliateReferrals, referralVisits } from "../../drizzle/schema";
import { eq, desc, and, gt, isNull } from "drizzle-orm";
import { nanoid } from "nanoid";
import { sendEmail, emailTemplates } from "../email";

// Flat credit rewards for the 2-tier referral system
const TIER1_CREDITS = 20; // direct referral earns 20 credits
const TIER2_CREDITS = 10; // second-level referral earns 10 credits

export const affiliateRouter = router({
  myAffiliate: protectedProcedure.query(async ({ ctx }) => {
    const db = await getDb();
    if (!db) return null;
    const [aff] = await db.select().from(affiliates).where(eq(affiliates.userEmail, ctx.user.email!)).limit(1);
    return aff || null;
  }),

  joinAffiliate: protectedProcedure.mutation(async ({ ctx }) => {
    const db = await getDb();
    if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
    const [existing] = await db.select().from(affiliates).where(eq(affiliates.userEmail, ctx.user.email!)).limit(1);
    if (existing) return existing;
    const code = nanoid(8).toUpperCase();
    await db.insert(affiliates).values({
      userEmail: ctx.user.email!,
      userName: ctx.user.name || undefined,
      referralCode: code,
    });
    const [aff] = await db.select().from(affiliates).where(eq(affiliates.userEmail, ctx.user.email!)).limit(1);
    return aff!;
  }),

  myReferrals: protectedProcedure.query(async ({ ctx }) => {
    const db = await getDb();
    if (!db) return [];
    return db.select().from(affiliateReferrals)
      .where(eq(affiliateReferrals.affiliateEmail, ctx.user.email!))
      .orderBy(desc(affiliateReferrals.createdAt));
  }),

  // Track a referral visit (called when user lands on site with ?ref= param)
  trackVisit: publicProcedure
    .input(z.object({
      refCode: z.string(),
      visitorCookie: z.string().optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) return { success: false };
      const [aff] = await db.select().from(affiliates)
        .where(eq(affiliates.referralCode, input.refCode)).limit(1);
      if (!aff) return { success: false, error: "Invalid referral code" };
      const visitorIp = (ctx.req as any).ip
        || ((ctx.req as any).headers?.['x-forwarded-for'] as string)?.split(",")[0]?.trim()
        || "unknown";
      const expiresAt = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000);
      await db.insert(referralVisits).values({
        refCode: input.refCode,
        affiliateEmail: aff.userEmail,
        visitorIp,
        visitorCookie: input.visitorCookie || null,
        expiresAt,
      });
      return { success: true };
    }),

  /**
   * Process referral on new user signup — flat 20 credits (tier 1) / 10 credits (tier 2).
   * Called automatically when a new user first signs in (OAuth callback).
   * No plan required — any signup triggers the reward.
   */
  processSignup: protectedProcedure
    .input(z.object({
      visitorCookie: z.string().optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) return { success: false };
      const now = new Date();
      const visitorIp = (ctx.req as any).ip
        || ((ctx.req as any).headers?.['x-forwarded-for'] as string)?.split(",")[0]?.trim()
        || "unknown";
      let visit = null;
      if (input.visitorCookie) {
        const [v] = await db.select().from(referralVisits)
          .where(and(
            eq(referralVisits.visitorCookie, input.visitorCookie),
            isNull(referralVisits.convertedEmail),
            gt(referralVisits.expiresAt, now)
          )).limit(1);
        visit = v || null;
      }
      if (!visit && visitorIp !== "unknown") {
        const [v] = await db.select().from(referralVisits)
          .where(and(
            eq(referralVisits.visitorIp, visitorIp),
            isNull(referralVisits.convertedEmail),
            gt(referralVisits.expiresAt, now)
          )).limit(1);
        visit = v || null;
      }
      if (!visit) return { success: false, reason: "No referral visit found" };

      // Mark visit as converted
      await db.update(referralVisits)
        .set({ convertedEmail: ctx.user.email!, convertedAt: now, creditsTier: "signup" })
        .where(eq(referralVisits.id, visit.id));

      const [tier1Aff] = await db.select().from(affiliates)
        .where(eq(affiliates.userEmail, visit.affiliateEmail)).limit(1);

      if (tier1Aff) {
        // Tier 1: flat 20 credits for direct referral
        const commissionAmount = (TIER1_CREDITS * 0.01).toFixed(2);
        await db.insert(affiliateReferrals).values({
          affiliateEmail: tier1Aff.userEmail,
          referralCode: visit.refCode,
          referredEmail: ctx.user.email!,
          referredName: ctx.user.name || undefined,
          commissionAmount,
          status: "pending",
        });
        await db.update(affiliates)
          .set({
            totalReferrals: (tier1Aff.totalReferrals || 0) + 1,
            totalEarnings: (parseFloat(tier1Aff.totalEarnings || "0") + parseFloat(commissionAmount)).toFixed(2),
            pendingPayout: (parseFloat(tier1Aff.pendingPayout || "0") + parseFloat(commissionAmount)).toFixed(2),
          })
          .where(eq(affiliates.id, tier1Aff.id));

        // Award 20 credits to tier1 referrer
        await addCredits(
          tier1Aff.userEmail,
          TIER1_CREDITS,
          `Referral bonus: ${ctx.user.name || ctx.user.email!} joined SportCardsOnline`
        );

        // Tier 2: find who referred the tier1 affiliate
        const [tier1Visit] = await db.select().from(referralVisits)
          .where(and(
            eq(referralVisits.convertedEmail, tier1Aff.userEmail),
            gt(referralVisits.expiresAt, new Date(0))
          )).limit(1);

        if (tier1Visit && !tier1Visit.layer2BonusAwarded) {
          const [tier2Aff] = await db.select().from(affiliates)
            .where(eq(affiliates.userEmail, tier1Visit.affiliateEmail)).limit(1);
          if (tier2Aff) {
            const tier2Commission = (TIER2_CREDITS * 0.01).toFixed(2);
            await db.insert(affiliateReferrals).values({
              affiliateEmail: tier2Aff.userEmail,
              referralCode: tier1Visit.refCode,
              referredEmail: ctx.user.email!,
              referredName: ctx.user.name || undefined,
              commissionAmount: tier2Commission,
              status: "pending",
            });
            await db.update(affiliates)
              .set({
                totalEarnings: (parseFloat(tier2Aff.totalEarnings || "0") + parseFloat(tier2Commission)).toFixed(2),
                pendingPayout: (parseFloat(tier2Aff.pendingPayout || "0") + parseFloat(tier2Commission)).toFixed(2),
              })
              .where(eq(affiliates.id, tier2Aff.id));

            // Award 10 credits to tier2 referrer
            await addCredits(
              tier2Aff.userEmail,
              TIER2_CREDITS,
              `Tier 2 referral bonus: ${ctx.user.name || ctx.user.email!} joined SportCardsOnline`
            );
            await db.update(referralVisits)
              .set({ layer2BonusAwarded: true })
              .where(eq(referralVisits.id, tier1Visit.id));
          }
        }
      }
      return { success: true, creditsAwarded: TIER1_CREDITS };
    }),
});
