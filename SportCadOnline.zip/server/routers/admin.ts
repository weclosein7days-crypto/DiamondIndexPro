import { router, protectedProcedure } from "../_core/trpc";
import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { getDb } from "../db";
import {
  users, cards, orders, auctions, trades, creditAccounts, affiliates,
  affiliateReferrals, notificationTemplates, collections, bids, stores,
} from "../../drizzle/schema";
import { eq, desc, sql, and, like, or, inArray } from "drizzle-orm";
import { addCredits, deductCredits, updateCard, deleteCard, getCardById, createCardEvent } from "../db";
import { getMarketPrice } from "../marketPrice";
import { importEbayDropshipCards, checkEbayAvailability } from "../ebayDropship";
import { runAvailabilityCheck as runAvailCheckJob, lastAvailabilityRun } from "../ebayAvailabilityJobs";
import { sendEmail } from "../email";
import { createShippingLabel } from "../shippoService";
import { generateBlogPost, listAllBlogPosts, deleteBlogPost, updateBlogPost } from "../blogEngine";
import { generateBlogVideo } from "../videoEngine";
import { uploadToYouTube, isYouTubeConfigured } from "../youtubeService";
import { generateVideoAutoTags } from "../youtubeAutoTagger";
import { blogPosts } from "../../drizzle/schema";

const adminProcedure = protectedProcedure.use(({ ctx, next }) => {
  if (ctx.user.role !== "admin") throw new TRPCError({ code: "FORBIDDEN", message: "Admin access required" });
  return next({ ctx });
});

export const adminRouter = router({
  // -- STATS ------------------------------------------------------------------
  stats: adminProcedure.query(async () => {
    const db = await getDb();
    if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });

    const [userCount] = await db.select({ count: sql<number>`count(*)` }).from(users);
    const [cardCount] = await db.select({ count: sql<number>`count(*)` }).from(cards);
    const [orderCount] = await db.select({ count: sql<number>`count(*)` }).from(orders);
    const [auctionCount] = await db.select({ count: sql<number>`count(*)` }).from(auctions).where(eq(auctions.status, "active"));
    const [revenue] = await db.select({ total: sql<number>`sum(platformFee)` }).from(orders).where(eq(orders.status, "delivered"));
    const [collectionCount] = await db.select({ count: sql<number>`count(*)` }).from(collections);

    // House card breakdown by status
    const statusBreakdown = await db
      .select({ status: cards.status, count: sql<number>`count(*)` })
      .from(cards)
      .groupBy(cards.status);
    const byStatus: Record<string, number> = {};
    for (const row of statusBreakdown) {
      byStatus[row.status ?? "unknown"] = Number(row.count);
    }

    return {
      users: userCount?.count || 0,
      cards: cardCount?.count || 0,
      orders: orderCount?.count || 0,
      activeAuctions: auctionCount?.count || 0,
      totalRevenue: revenue?.total || 0,
      collectionItems: collectionCount?.count || 0,
      cardsByStatus: byStatus,
    };
  }),

  // -- HOUSE COLLECTION (all cards, all statuses, paginated) ------------------
  houseCards: adminProcedure
    .input(z.object({
      search: z.string().optional(),
      status: z.string().optional(),
      sport: z.string().optional(),
      source: z.enum(["all", "house", "ebay"]).optional(),
      limit: z.number().default(50),
      offset: z.number().default(0),
      sortBy: z.enum(["newest", "oldest", "price_high", "price_low", "player"]).default("newest"),
    }).optional())
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) return { cards: [], total: 0, byStatus: {} };

      const limit = input?.limit ?? 50;
      const offset = input?.offset ?? 0;
      const search = input?.search;
      const statusFilter = input?.status;
      const sportFilter = input?.sport;
      const sourceFilter = input?.source;

      const conditions = [];
      if (sourceFilter === "house") {
        // Manually added / graded in-house cards
        conditions.push(eq(cards.source, "manual"));
      } else if (sourceFilter === "ebay") {
        // eBay-imported cards (still house inventory, sourced from eBay)
        conditions.push(eq(cards.source, "ebay_import"));
      }
      if (statusFilter && statusFilter !== "all") {
        conditions.push(eq(cards.status, statusFilter as any));
      }
      if (sportFilter && sportFilter !== "all") {
        conditions.push(eq(cards.sport, sportFilter as any));
      }
      if (search) {
        conditions.push(
          or(
            like(cards.playerName, `%${search}%`),
            like(cards.title, `%${search}%`),
            like(cards.setName, `%${search}%`),
            like(cards.certNumber, `%${search}%`),
          )!
        );
      }

      const where = conditions.length > 0 ? and(...conditions) : undefined;

      const orderMap = {
        newest: desc(cards.createdAt),
        oldest: cards.createdAt,
        price_high: desc(cards.price),
        price_low: cards.price,
        player: cards.playerName,
      };
      const orderBy = orderMap[input?.sortBy ?? "newest"];

      const [allCards, countResult, statusBreakdown] = await Promise.all([
        where
          ? db.select().from(cards).where(where).orderBy(orderBy).limit(limit).offset(offset)
          : db.select().from(cards).orderBy(orderBy).limit(limit).offset(offset),
        where
          ? db.select({ count: sql<number>`count(*)` }).from(cards).where(where)
          : db.select({ count: sql<number>`count(*)` }).from(cards),
        db.select({ status: cards.status, count: sql<number>`count(*)` }).from(cards).groupBy(cards.status),
      ]);

      const byStatus: Record<string, number> = {};
      for (const row of statusBreakdown) {
        byStatus[row.status ?? "unknown"] = Number(row.count);
      }

      return {
        cards: allCards,
        total: Number(countResult[0]?.count ?? 0),
        byStatus,
      };
    }),

  // -- BULK ACTIONS ON HOUSE CARDS -------------------------------------------
  bulkUpdateCardStatus: adminProcedure
    .input(z.object({
      ids: z.array(z.number()),
      status: z.enum(["active", "sold", "draft", "auction", "traded", "casino", "bank"]),
    }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      if (input.ids.length === 0) return { success: true, updated: 0 };
      let updated = 0;
      const eventType = input.status === 'casino' ? 'casino_assigned'
        : input.status === 'bank' ? 'vaulted'
        : input.status === 'active' ? 'listed'
        : input.status === 'auction' ? 'auction_started'
        : input.status === 'sold' ? 'sold'
        : 'bulk_action';
      for (const id of input.ids) {
        await db.update(cards).set({ status: input.status }).where(eq(cards.id, id));
        await createCardEvent({
          cardId: id,
          userEmail: ctx.user.email ?? undefined,
          eventType,
          description: `Bulk action: status set to ${input.status}`,
          metadata: { newStatus: input.status, bulkCount: input.ids.length },
        });
        updated++;
      }
      return { success: true, updated };
    }),

  bulkDeleteCards: adminProcedure
    .input(z.object({ ids: z.array(z.number()) }))
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      if (input.ids.length === 0) return { success: true, deleted: 0 };
      let deleted = 0;
      for (const id of input.ids) {
        await db.delete(cards).where(eq(cards.id, id));
        deleted++;
      }
      return { success: true, deleted };
    }),

  // -- CARD HISTORY -----------------------------------------------------------
  getCardHistory: adminProcedure
    .input(z.object({ cardId: z.number() }))
    .query(async ({ input }) => {
      const { getCardHistoryByCardId } = await import("../db");
      return getCardHistoryByCardId(input.cardId);
    }),

  // -- USERS ------------------------------------------------------------------
  listUsers: adminProcedure
    .input(z.object({ search: z.string().optional(), limit: z.number().default(50) }).optional())
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) return [];
      if (input?.search) {
        return db.select().from(users)
          .where(like(users.email, `%${input.search}%`))
          .orderBy(desc(users.createdAt)).limit(input?.limit || 50);
      }
      return db.select().from(users).orderBy(desc(users.createdAt)).limit(input?.limit || 50);
    }),

  setUserRole: adminProcedure
    .input(z.object({ userId: z.number(), role: z.enum(["user", "admin"]) }))
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      await db.update(users).set({ role: input.role }).where(eq(users.id, input.userId));
      return { success: true };
    }),

  // -- COLLECTIONS MODERATION --------------------------------------------------
  listAllCollections: adminProcedure
    .input(z.object({ search: z.string().optional(), limit: z.number().default(100) }).optional())
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) return [];
      if (input?.search) {
        return db.select().from(collections)
          .where(like(collections.ownerEmail, `%${input.search}%`))
          .orderBy(desc(collections.createdAt)).limit(input?.limit || 100);
      }
      return db.select().from(collections).orderBy(desc(collections.createdAt)).limit(input?.limit || 100);
    }),

  // -- VAULT MODERATION -------------------------------------------------------
  listVaultedCards: adminProcedure
    .input(z.object({ search: z.string().optional() }).optional())
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) return [];
      const vaultWhere = sql`${collections.listingStatus} LIKE 'vault%'`;
      if (input?.search) {
        return db.select().from(collections)
          .where(and(
            sql`${collections.listingStatus} LIKE 'vault%'`,
            sql`(${collections.ownerEmail} LIKE ${`%${input.search}%`} OR ${collections.cardTitle} LIKE ${`%${input.search}%`} OR ${collections.playerName} LIKE ${`%${input.search}%`})`
          ))
          .orderBy(desc(collections.createdAt));
      }
      return db.select().from(collections)
        .where(vaultWhere)
        .orderBy(desc(collections.createdAt));
    }),

  updateVaultStatus: adminProcedure
    .input(z.object({
      collectionId: z.number(),
      listingStatus: z.enum(["vaulted", "vault_listed", "vault_auction", "vault_sold", "vault_shipped", "none"]),
    }))
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) return { success: false };
      await db.update(collections)
        .set({ listingStatus: input.listingStatus })
        .where(eq(collections.id, input.collectionId));
      return { success: true };
    }),

  // -- CARDS MODERATION -------------------------------------------------------
  listAllCards: adminProcedure
    .input(z.object({
      search: z.string().optional(),
      status: z.string().optional(),
      sport: z.string().optional(),
      source: z.enum(["all", "house", "ebay"]).optional(),
      limit: z.number().default(500),
    }).optional())
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) return [];
      const conditions: ReturnType<typeof eq>[] = [];
      if (input?.status && input.status !== "all") {
        conditions.push(eq(cards.status, input.status as any));
      }
      if (input?.sport && input.sport !== "all") {
        conditions.push(eq(cards.sport, input.sport.toLowerCase() as any));
      }
      if (input?.source === "house") {
        conditions.push(eq(cards.isMainStore, true));
      } else if (input?.source === "ebay") {
        conditions.push(eq(cards.isMainStore, false));
      }
      if (input?.search?.trim()) {
        const term = `%${input.search.trim()}%`;
        conditions.push(or(like(cards.playerName, term), like(cards.title, term), like(cards.setName, term)) as any);
      }
      const where = conditions.length > 0 ? and(...conditions) : undefined;
      return db.select().from(cards)
        .where(where)
        .orderBy(desc(cards.createdAt))
        .limit(input?.limit || 500);
    }),

  adjustGrade: adminProcedure
    .input(z.object({
      cardId: z.number(),
      aiGrade: z.string(),
      aiGradeLabel: z.string(),
      aiCentering: z.string().optional(),
      aiCorners: z.string().optional(),
      aiEdges: z.string().optional(),
      aiSurface: z.string().optional(),
      adminNote: z.string().optional(),
    }))
    .mutation(async ({ input }) => {
      const { cardId, adminNote, ...gradeData } = input;
      const cardUpdates: Record<string, unknown> = { ...gradeData };

      // ── Auto-price from eBay + SCP + Beckett (3-source market avg) ──────────
      // Raw=120% · Graded 1-9=90% · Grade 10=80% of market avg
      try {
        const card = await getCardById(cardId);
        if (card) {
          const query = `${card.playerName} ${card.year || ""} ${card.setName || ""}`.trim();
          const gradeNum = parseFloat(gradeData.aiGrade);
          const priceResult = await getMarketPrice(query, isNaN(gradeNum) ? null : gradeNum);
          if (priceResult.suggestedPrice) {
            cardUpdates.price = priceResult.suggestedPrice.toFixed(2);
          }
        }
      } catch (e) {
        console.warn("[adjustGrade] Market price lookup failed:", e);
      }

      await updateCard(cardId, cardUpdates as Parameters<typeof updateCard>[1]);
      // Also update collection if exists — match by linkedCardId (the cards.id FK)
      const db = await getDb();
      if (db) {
        const collectionSet: Record<string, unknown> = {
          overallGrade: gradeData.aiGrade,
          gradeLabel: gradeData.aiGradeLabel,
          centeringScore: gradeData.aiCentering,
          cornersScore: gradeData.aiCorners,
          edgesScore: gradeData.aiEdges,
          surfaceScore: gradeData.aiSurface,
        };
        // Sync the SCP-derived price to the collection's estimated value fields
        if (cardUpdates.price) {
          collectionSet.estimatedValueLow = cardUpdates.price;
          collectionSet.estimatedValueHigh = cardUpdates.price;
        }
        await db.update(collections)
          .set(collectionSet)
          .where(eq(collections.linkedCardId, cardId));
      }
      return { success: true, autoPrice: cardUpdates.price };
    }),

  // Inline price/grade editing from admin table
  adminUpdateCard: adminProcedure
    .input(z.object({
      cardId: z.number(),
      price: z.string().optional(),
      aiGrade: z.string().optional(),
      status: z.string().optional(),
      playerName: z.string().optional(),
      setName: z.string().optional(),
      year: z.string().optional(),
      description: z.string().optional(),
    }))
    .mutation(async ({ input }) => {
      const { cardId, price, aiGrade, status, playerName, setName, year, description } = input;
      const updates: Record<string, unknown> = {};
      if (price !== undefined) updates.price = price;
      if (status !== undefined) updates.status = status;
      if (playerName !== undefined) updates.playerName = playerName;
      if (setName !== undefined) updates.setName = setName;
      if (year !== undefined) updates.year = year;
      if (description !== undefined) updates.description = description;
      if (aiGrade !== undefined) {
        const LABEL_MAP: Record<string, string> = {
          "10": "GEM MINT", "9.5": "MINT+", "9": "MINT",
          "8.5": "NM-MT+", "8": "NM-MT", "7.5": "NM+", "7": "NM",
          "6.5": "EX-MT+", "6": "EX-MT", "5.5": "EX+", "5": "EX",
          "4.5": "VG-EX+", "4": "VG-EX", "3.5": "VG+", "3": "VG",
          "2": "GOOD", "1.5": "FAIR", "1": "POOR",
        };
        updates.aiGrade = aiGrade;
        updates.aiGradeLabel = LABEL_MAP[aiGrade] || `GRADE ${aiGrade}`;
        // Cascade all sub-grades to the same value
        updates.aiCentering = aiGrade;
        updates.aiCorners = aiGrade;
        updates.aiEdges = aiGrade;
        updates.aiSurface = aiGrade;
        updates.condition = "graded";

        // ── Auto-price from SportsCardsPro API ─────────────────────────────
        // Grade 10 = 70% of PSA-10 (manual-only-price)
        // Grade 9   = 80% of graded-price
        // Grade 8   = 80% of new-price
        // Grade 7   = 80% of cib-price
        // Use getMarketPrice (eBay + SCP + Beckett 3-source avg) for auto-pricing
        // Only auto-price if no explicit price was passed
        if (price === undefined) {
          try {
            const card = await getCardById(cardId);
            if (card) {
              const query = `${card.playerName} ${card.year || ""} ${card.setName || ""}`.trim();
              const gradeNum = parseFloat(aiGrade);
              const priceResult = await getMarketPrice(query, isNaN(gradeNum) ? null : gradeNum);
              if (priceResult.suggestedPrice && priceResult.suggestedPrice > 0) {
                updates.price = priceResult.suggestedPrice.toFixed(2);
              }
            }
          } catch (e) {
            // Market price lookup failed — don't block the grade update, just skip auto-price
            console.warn("[adminUpdateCard] Market price lookup failed:", e);
          }
        }
      }
      // Log the status/price change to card history
      const prevCard = await getCardById(cardId);
      const changedFields: string[] = [];
      if (updates.status && updates.status !== prevCard?.status) changedFields.push(`status: ${prevCard?.status} → ${updates.status}`);
      if (updates.price) changedFields.push(`price: $${updates.price}`);
      if (updates.aiGrade) changedFields.push(`grade: ${updates.aiGrade}`);
      if (changedFields.length > 0) {
        const eventType = updates.status === 'casino' ? 'casino_assigned'
          : updates.status === 'bank' ? 'vaulted'
          : updates.status === 'active' ? 'listed'
          : updates.status === 'auction' ? 'auction_started'
          : updates.status === 'sold' ? 'sold'
          : updates.price ? 'price_updated'
          : 'status_changed';
        await createCardEvent({
          cardId,
          eventType,
          description: changedFields.join(', '),
          metadata: { updates },
        });
      }
      await updateCard(cardId, updates as Parameters<typeof updateCard>[1]);
      // Sync grade and/or price to any linked collection rows
      const db2 = await getDb();
      if (db2) {
        const collectionSync: Record<string, unknown> = {};
        if (aiGrade !== undefined) {
          const LABEL_MAP2: Record<string, string> = {
            "10": "GEM MINT", "9.5": "MINT+", "9": "MINT",
            "8.5": "NM-MT+", "8": "NM-MT", "7.5": "NM+", "7": "NM",
            "6.5": "EX-MT+", "6": "EX-MT", "5.5": "EX+", "5": "EX",
            "4.5": "VG-EX+", "4": "VG-EX", "3.5": "VG+", "3": "VG",
            "2": "GOOD", "1.5": "FAIR", "1": "POOR",
          };
          collectionSync.overallGrade = aiGrade;
          collectionSync.gradeLabel = LABEL_MAP2[aiGrade] || `GRADE ${aiGrade}`;
          collectionSync.centeringScore = aiGrade;
          collectionSync.cornersScore = aiGrade;
          collectionSync.edgesScore = aiGrade;
          collectionSync.surfaceScore = aiGrade;
        }
        // Sync price (either explicit or SCP-derived) to estimatedValue fields
        const finalPrice = updates.price as string | undefined;
        if (finalPrice) {
          collectionSync.estimatedValueLow = finalPrice;
          collectionSync.estimatedValueHigh = finalPrice;
        }
        if (Object.keys(collectionSync).length > 0) {
          await db2.update(collections)
            .set(collectionSync)
            .where(eq(collections.linkedCardId, cardId));
        }
      }
      return { success: true, autoPrice: updates.price };
    }),

  // Direct grade + estimated-value edit for collection-only items (no linked card)
  adjustCollectionGrade: adminProcedure
    .input(z.object({
      collectionId: z.number(),
      overallGrade: z.string(),
      estimatedValueLow: z.string().optional(),
      estimatedValueHigh: z.string().optional(),
    }))
    .mutation(async ({ input }) => {
      const LABEL_MAP: Record<string, string> = {
        "10": "GEM MINT", "9.5": "MINT+", "9": "MINT",
        "8.5": "NM-MT+", "8": "NM-MT", "7.5": "NM+", "7": "NM",
        "6.5": "EX-MT+", "6": "EX-MT", "5.5": "EX+", "5": "EX",
        "4.5": "VG-EX+", "4": "VG-EX", "3.5": "VG+", "3": "VG",
        "2": "GOOD", "1.5": "FAIR", "1": "POOR",
      };
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      const gradeLabel = LABEL_MAP[input.overallGrade] || `GRADE ${input.overallGrade}`;

      // Fetch SCP price if no explicit value provided
      let autoPrice: string | undefined;
      if (!input.estimatedValueLow) {
        try {
          const [item] = await db.select().from(collections).where(eq(collections.id, input.collectionId)).limit(1);
          if (item) {
            const query = `${item.playerName} ${item.year || ""} ${item.setName || ""}`.trim();
            const gradeNum = parseFloat(input.overallGrade);
            const priceResult = await getMarketPrice(query, isNaN(gradeNum) ? null : gradeNum);
            if (priceResult.suggestedPrice) autoPrice = priceResult.suggestedPrice.toFixed(2);
          }
        } catch (e) {
          console.warn("[adjustCollectionGrade] Market price lookup failed:", e);
        }
      }

      const updateSet: Record<string, unknown> = {
        overallGrade: input.overallGrade,
        gradeLabel,
        centeringScore: input.overallGrade,
        cornersScore: input.overallGrade,
        edgesScore: input.overallGrade,
        surfaceScore: input.overallGrade,
      };
      const low = input.estimatedValueLow || autoPrice;
      const high = input.estimatedValueHigh || autoPrice;
      if (low) { updateSet.estimatedValueLow = low; updateSet.estimatedValueHigh = high || low; }

      await db.update(collections).set(updateSet).where(eq(collections.id, input.collectionId));
      return { success: true, autoPrice: low };
    }),

  deleteCardAdmin: adminProcedure
    .input(z.object({ cardId: z.number(), reason: z.string().optional() }))
    .mutation(async ({ input }) => {
      await deleteCard(input.cardId);
      return { success: true };
    }),

  // Replace front/back photos for a card (admin-only, used with camera capture)
  updateCardImages: adminProcedure
    .input(z.object({
      cardId: z.number(),
      frontImageUrl: z.string(),
      backImageUrl: z.string(),
    }))
    .mutation(async ({ input }) => {
      await updateCard(input.cardId, {
        frontImageUrl: input.frontImageUrl,
        backImageUrl: input.backImageUrl,
      });
      return { success: true };
    }),

  deleteCollectionAdmin: adminProcedure
    .input(z.object({ collectionId: z.number() }))
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      await db.delete(collections).where(eq(collections.id, input.collectionId));
      return { success: true };
    }),

  // -- ORDERS -----------------------------------------------------------------
  listAllOrders: adminProcedure
    .input(z.object({ status: z.string().optional(), limit: z.number().default(100) }).optional())
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) return [];
      return db.select().from(orders).orderBy(desc(orders.createdAt)).limit(input?.limit || 100);
    }),

  updateOrderStatus: adminProcedure
    .input(z.object({ orderId: z.number(), status: z.enum(["pending", "paid", "shipped", "delivered", "cancelled", "refunded"]) }))
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      await db.update(orders).set({ status: input.status }).where(eq(orders.id, input.orderId));
      // Notify seller when marked delivered (third-party orders only)
      if (input.status === "delivered") {
        const [order] = await db.select().from(orders).where(eq(orders.id, input.orderId)).limit(1);
        if (order && !order.isDropshipOrder && order.sellerEmail) {
          sendEmail({
            to: order.sellerEmail,
            subject: `📦 Your card has been delivered — funds pending release`,
            html: `<div style="font-family:sans-serif;max-width:600px;margin:0 auto;padding:24px">
              <h2 style="color:#1a3a6b">Your card has been delivered!</h2>
              <p>Great news — the buyer has received your card (Order #${order.id}).</p>
              <p><strong>Sale amount:</strong> $${parseFloat(order.totalAmount ?? "0").toFixed(2)}</p>
              <p>Our team will review the delivery and release your funds shortly. You will receive another email once funds have been released to you.</p>
              <p style="color:#888;font-size:12px">SportCardsOnline.com — Questions? Contact support.</p>
            </div>`,
          }).catch(() => {});
        }
      }
      return { success: true };
    }),

  // -- CREDITS ----------------------------------------------------------------
  listCreditAccounts: adminProcedure.query(async () => {
    const db = await getDb();
    if (!db) return [];
    return db.select().from(creditAccounts).orderBy(desc(creditAccounts.updatedAt)).limit(200);
  }),

  adminAddCredits: adminProcedure
    .input(z.object({ userEmail: z.string(), amount: z.number(), reason: z.string() }))
    .mutation(async ({ input }) => {
      await addCredits(input.userEmail, input.amount, `[Admin] ${input.reason}`);
      return { success: true };
    }),

  adminDeductCredits: adminProcedure
    .input(z.object({ userEmail: z.string(), amount: z.number(), reason: z.string() }))
    .mutation(async ({ input }) => {
      const ok = await deductCredits(input.userEmail, input.amount, `[Admin] ${input.reason}`);
      if (!ok) throw new TRPCError({ code: "BAD_REQUEST", message: "Insufficient credits or account not found" });
      return { success: true };
    }),

  // -- AUCTIONS ---------------------------------------------------------------
  listAllAuctions: adminProcedure
    .input(z.object({ status: z.string().optional() }).optional())
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) return [];
      return db.select().from(auctions).orderBy(desc(auctions.createdAt)).limit(100);
    }),

  cancelAuction: adminProcedure
    .input(z.object({ auctionId: z.number(), reason: z.string().optional() }))
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      await db.update(auctions).set({ status: "cancelled" }).where(eq(auctions.id, input.auctionId));
      return { success: true };
    }),

  // -- AFFILIATE --------------------------------------------------------------
  listAffiliates: adminProcedure.query(async () => {
    const db = await getDb();
    if (!db) return [];
    return db.select().from(affiliates).orderBy(desc(affiliates.totalEarnings)).limit(200);
  }),

  listReferrals: adminProcedure
    .input(z.object({ affiliateEmail: z.string().optional() }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) return [];
      if (input.affiliateEmail) {
        return db.select().from(affiliateReferrals)
          .where(eq(affiliateReferrals.affiliateEmail, input.affiliateEmail))
          .orderBy(desc(affiliateReferrals.createdAt));
      }
      return db.select().from(affiliateReferrals).orderBy(desc(affiliateReferrals.createdAt)).limit(200);
    }),

  updateAffiliateStatus: adminProcedure
    .input(z.object({ affiliateEmail: z.string(), status: z.enum(["active", "suspended", "pending"]) }))
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      await db.update(affiliates).set({ status: input.status }).where(eq(affiliates.userEmail, input.affiliateEmail));
      return { success: true };
    }),

  markAffiliatePaid: adminProcedure
    .input(z.object({ affiliateEmail: z.string(), amount: z.string() }))
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      const [aff] = await db.select().from(affiliates).where(eq(affiliates.userEmail, input.affiliateEmail)).limit(1);
      if (!aff) throw new TRPCError({ code: "NOT_FOUND" });
      const newPaid = (parseFloat(aff.paidOut || "0") + parseFloat(input.amount)).toFixed(2);
      const newPending = Math.max(0, parseFloat(aff.pendingPayout || "0") - parseFloat(input.amount)).toFixed(2);
      await db.update(affiliates).set({ paidOut: newPaid, pendingPayout: newPending }).where(eq(affiliates.userEmail, input.affiliateEmail));
      return { success: true };
    }),

  // -- NOTIFICATION TEMPLATES -------------------------------------------------
  listTemplates: adminProcedure.query(async () => {
    const db = await getDb();
    if (!db) return [];
    return db.select().from(notificationTemplates).orderBy(notificationTemplates.trigger);
  }),

  upsertTemplate: adminProcedure
    .input(z.object({
      id: z.number().optional(),
      name: z.string(),
      subject: z.string(),
      body: z.string(),
      trigger: z.enum([
        "order_placed", "order_shipped", "order_delivered",
        "trade_received", "trade_accepted", "trade_rejected",
        "auction_won", "auction_outbid", "auction_ended",
        "grade_complete", "credit_added", "welcome"
      ]),
      isActive: z.boolean().default(true),
    }))
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      if (input.id) {
        await db.update(notificationTemplates).set(input).where(eq(notificationTemplates.id, input.id));
      } else {
        await db.insert(notificationTemplates).values(input);
      }
      return { success: true };
    }),

  deleteTemplate: adminProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      await db.delete(notificationTemplates).where(eq(notificationTemplates.id, input.id));
      return { success: true };
    }),

  // -- TRADES ----------------------------------------------------------------
  listAllTrades: adminProcedure
    .input(z.object({ status: z.string().optional(), limit: z.number().default(100) }).optional())
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) return [];
      if (input?.status) {
        return db.select().from(trades).where(eq(trades.status, input.status as any)).orderBy(desc(trades.createdAt)).limit(input?.limit || 100);
      }
      return db.select().from(trades).orderBy(desc(trades.createdAt)).limit(input?.limit || 100);
    }),

  adminUpdateTradeTracking: adminProcedure
    .input(z.object({
      tradeId: z.number(),
      initiatorTracking: z.string().optional(),
      receiverTracking: z.string().optional(),
      status: z.enum(["pending", "accepted", "rejected", "cancelled", "countered", "agreed", "shipped", "completed"]).optional(),
    }))
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      const updates: Record<string, unknown> = {};
      if (input.initiatorTracking !== undefined) updates.initiatorTracking = input.initiatorTracking;
      if (input.receiverTracking !== undefined) updates.receiverTracking = input.receiverTracking;
      if (input.status !== undefined) updates.status = input.status;
      await db.update(trades).set(updates).where(eq(trades.id, input.tradeId));
      return { success: true };
    }),

  // -- SEED TEST CARDS -------------------------------------------------------
  seedTestCards: adminProcedure
    .input(z.object({ ownerEmail: z.string().email() }))
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });

      const sampleCards = [
        { cardTitle: "1952 Topps Mickey Mantle #311", playerName: "Mickey Mantle", year: "1952", setName: "Topps", cardNumber: "311", sport: "baseball" as const, overallGrade: "8.5", gradeLabel: "NM-MT", certNumber: "SCG-10001", estimatedValueLow: "4500", estimatedValueHigh: "6200", centeringScore: "8", cornersScore: "9", edgesScore: "8.5", surfaceScore: "8.5", description: "Iconic Mantle. Light wear on corners, clean surface." },
        { cardTitle: "1986-87 Fleer Michael Jordan #57 RC", playerName: "Michael Jordan", year: "1986", setName: "Fleer", cardNumber: "57", sport: "basketball" as const, overallGrade: "9.0", gradeLabel: "MINT", certNumber: "SCG-10002", estimatedValueLow: "8000", estimatedValueHigh: "12000", centeringScore: "9", cornersScore: "9", edgesScore: "9", surfaceScore: "9", description: "Classic Jordan rookie. Sharp corners, bright colors." },
        { cardTitle: "2000 Bowman Chrome Tom Brady #236 RC", playerName: "Tom Brady", year: "2000", setName: "Bowman Chrome", cardNumber: "236", sport: "football" as const, overallGrade: "9.5", gradeLabel: "GEM-MT", certNumber: "SCG-10003", estimatedValueLow: "3200", estimatedValueHigh: "4800", centeringScore: "9.5", cornersScore: "9.5", edgesScore: "9.5", surfaceScore: "9.5", description: "Gem mint Brady rookie. Perfect centering." },
        { cardTitle: "1979-80 O-Pee-Chee Wayne Gretzky #18 RC", playerName: "Wayne Gretzky", year: "1979", setName: "O-Pee-Chee", cardNumber: "18", sport: "hockey" as const, overallGrade: "7.5", gradeLabel: "NM", certNumber: "SCG-10004", estimatedValueLow: "1800", estimatedValueHigh: "2600", centeringScore: "7.5", cornersScore: "8", edgesScore: "7.5", surfaceScore: "7.5", description: "The Great One rookie. Some edge wear." },
        { cardTitle: "2003 Topps Chrome LeBron James #111 RC", playerName: "LeBron James", year: "2003", setName: "Topps Chrome", cardNumber: "111", sport: "basketball" as const, overallGrade: "8.0", gradeLabel: "NM-MT", certNumber: "SCG-10005", estimatedValueLow: "900", estimatedValueHigh: "1400", centeringScore: "8", cornersScore: "8", edgesScore: "8", surfaceScore: "8", description: "LBJ Chrome rookie. Great surface, slight centering off." },
        { cardTitle: "1989 Upper Deck Ken Griffey Jr. #1 RC", playerName: "Ken Griffey Jr.", year: "1989", setName: "Upper Deck", cardNumber: "1", sport: "baseball" as const, overallGrade: "9.0", gradeLabel: "MINT", certNumber: "SCG-10006", estimatedValueLow: "280", estimatedValueHigh: "420", centeringScore: "9", cornersScore: "9", edgesScore: "9", surfaceScore: "9", description: "The Kid rookie. Near perfect condition." },
        { cardTitle: "1996 Topps Chrome Kobe Bryant #138 RC", playerName: "Kobe Bryant", year: "1996", setName: "Topps Chrome", cardNumber: "138", sport: "basketball" as const, overallGrade: "8.5", gradeLabel: "NM-MT", certNumber: "SCG-10007", estimatedValueLow: "1200", estimatedValueHigh: "1800", centeringScore: "8.5", cornersScore: "8.5", edgesScore: "8.5", surfaceScore: "8.5", description: "Kobe Chrome rookie. Sharp and clean." },
        { cardTitle: "2018 Prizm Patrick Mahomes #195 RC", playerName: "Patrick Mahomes", year: "2018", setName: "Panini Prizm", cardNumber: "195", sport: "football" as const, overallGrade: "9.5", gradeLabel: "GEM-MT", certNumber: "SCG-10008", estimatedValueLow: "650", estimatedValueHigh: "950", centeringScore: "9.5", cornersScore: "9.5", edgesScore: "9.5", surfaceScore: "9.5", description: "Mahomes Prizm gem. Perfect all around." },
        { cardTitle: "2011 Topps Update Mike Trout #US175 RC", playerName: "Mike Trout", year: "2011", setName: "Topps Update", cardNumber: "US175", sport: "baseball" as const, overallGrade: "8.0", gradeLabel: "NM-MT", certNumber: "SCG-10009", estimatedValueLow: "380", estimatedValueHigh: "560", centeringScore: "8", cornersScore: "8", edgesScore: "8", surfaceScore: "8", description: "Trout Update rookie. Solid grade." },
        { cardTitle: "2005-06 Upper Deck Sidney Crosby #201 RC", playerName: "Sidney Crosby", year: "2005", setName: "Upper Deck", cardNumber: "201", sport: "hockey" as const, overallGrade: "9.0", gradeLabel: "MINT", certNumber: "SCG-10010", estimatedValueLow: "420", estimatedValueHigh: "680", centeringScore: "9", cornersScore: "9", edgesScore: "9", surfaceScore: "9", description: "Crosby rookie. Mint condition, bright surface." },
      ];

      let inserted = 0;
      for (const card of sampleCards) {
        await db.insert(collections).values({
          ownerEmail: input.ownerEmail,
          cardTitle: card.cardTitle,
          playerName: card.playerName,
          year: card.year,
          setName: card.setName,
          cardNumber: card.cardNumber,
          sport: card.sport,
          overallGrade: card.overallGrade,
          gradeLabel: card.gradeLabel,
          certNumber: card.certNumber,
          estimatedValueLow: card.estimatedValueLow,
          estimatedValueHigh: card.estimatedValueHigh,
          centeringScore: card.centeringScore,
          cornersScore: card.cornersScore,
          edgesScore: card.edgesScore,
          surfaceScore: card.surfaceScore,
          description: card.description,
        });
        inserted++;
      }
      return { success: true, inserted };
    }),

  // -- BULK IMPORT HOUSE CARDS (used by import scripts) -----------------------
  bulkImportHouseCards: adminProcedure
    .input(z.array(z.object({
      playerName: z.string(),
      title: z.string(),
      year: z.string().optional(),
      setName: z.string().optional(),
      cardNumber: z.string().optional(),
      sport: z.enum(["baseball", "basketball", "football", "hockey", "soccer", "other"]).default("basketball"),
      condition: z.enum(["raw", "graded"]).default("graded"),
      gradeCompany: z.enum(["PSA", "Beckett", "SGC", "TGA", "CGC", "other", "none"]).default("Beckett"),
      gradeScore: z.string().optional(),
      price: z.string().optional(),
      category: z.enum(["rookie", "vintage", "modern", "insert", "parallel", "autograph", "memorabilia", "other"]).default("modern"),
      status: z.enum(["active", "sold", "draft", "auction", "traded", "casino", "bank"]).default("active"),
      description: z.string().optional(),
      frontImageUrl: z.string().nullable().optional(),
    })))
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "DB unavailable" });
      const { createCard } = await import("../db");
      let imported = 0;
      const errors: string[] = [];
      for (const card of input) {
        try {
          await createCard({
            title: card.title,
            playerName: card.playerName,
            year: card.year,
            setName: card.setName,
            cardNumber: card.cardNumber,
            sport: card.sport,
            condition: card.condition,
            gradeCompany: card.gradeCompany,
            gradeScore: card.gradeScore,
            price: card.price,
            category: card.category,
            status: card.status,
            description: card.description,
            frontImageUrl: card.frontImageUrl ?? undefined,
            sellerEmail: "admin@sportcardsonline.com",
            storeName: "SCO House",
            isMainStore: true,
            source: "search_import",
            aiGrade: card.gradeScore === "10" ? "10.00" : card.gradeScore === "9.5" ? "9.50" : card.gradeScore === "9" ? "9.00" : undefined,
            aiGradeLabel: card.gradeScore === "10" ? "GEM MINT" : card.gradeScore === "9.5" ? "MINT+" : card.gradeScore === "9" ? "MINT" : undefined,
          });
          imported++;
        } catch (e: any) {
          errors.push(`${card.title}: ${e.message}`);
        }
      }
      return { success: true, imported, errors };
    }),

  // -- eBay DROPSHIP ENGINE --------------------------------------------------
  importEbayCards: adminProcedure
    .input(z.object({
      sport: z.string().optional(),
      playersPerSport: z.number().min(1).max(50).default(10),
      cardsPerPlayer: z.number().min(1).max(50).default(3),
      maxTotal: z.number().min(1).max(1000).default(300),
    }))
    .mutation(async ({ input }) => {
      const result = await importEbayDropshipCards({
        sport: input.sport,
        playersPerSport: input.playersPerSport,
        cardsPerPlayer: input.cardsPerPlayer,
        maxTotal: input.maxTotal,
      });
      return result;
    }),

  // Get pending dropship orders needing fulfillment
  getDropshipOrders: adminProcedure
    .input(z.object({
      status: z.enum(["pending", "fulfilled", "all"]).default("pending"),
    }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "DB unavailable" });

      const conditions = [sql`${orders.isDropshipOrder} = 1`];
      if (input.status === "pending") {
        conditions.push(sql`${orders.dropshipFulfilledAt} IS NULL`);
      } else if (input.status === "fulfilled") {
        conditions.push(sql`${orders.dropshipFulfilledAt} IS NOT NULL`);
      }

      const result = await db
        .select({
          orderId: orders.id,
          ticketNumber: orders.ticketNumber,
          cardId: orders.cardId,
          buyerEmail: orders.buyerEmail,
          buyerName: orders.buyerName,
          shippingAddress: orders.shippingAddress,
          totalAmount: orders.totalAmount,
          ebayFulfillmentLink: orders.ebayFulfillmentLink,
          dropshipFulfilledAt: orders.dropshipFulfilledAt,
          createdAt: orders.createdAt,
          cardTitle: cards.title,
          cardPlayerName: cards.playerName,
          cardEbayItemId: cards.ebayItemId,
          cardEbayListingUrl: cards.ebayListingUrl,
          cardSourcePrice: cards.sourcePrice,
          cardPrice: cards.price,
          cardShippingFee: cards.cardShippingFee,
          cardImage: cards.frontImageUrl,
          // Best Offer tracking fields
          ebayOfferStatus: orders.ebayOfferStatus,
          ebayOfferAmount: orders.ebayOfferAmount,
          ebayOfferSentAt: orders.ebayOfferSentAt,
          ebayOfferRespondedAt: orders.ebayOfferRespondedAt,
          ebayOfferSavings: orders.ebayOfferSavings,
          ebayOfferId: orders.ebayOfferId,
        })
        .from(orders)
        .leftJoin(cards, eq(orders.cardId, cards.id))
        .where(and(...conditions))
        .orderBy(desc(orders.createdAt))
        .limit(100);

      return result;
    }),

  // Mark a dropship order as fulfilled
  markDropshipFulfilled: adminProcedure
    .input(z.object({ orderId: z.number() }))
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "DB unavailable" });
      await db.update(orders)
        .set({ dropshipFulfilledAt: new Date() })
        .where(eq(orders.id, input.orderId));
      return { success: true };
    }),

  // Attempt eBay Best Offer (10% below asking) on a dropship order before fulfillment
  attemptBestOffer: adminProcedure
    .input(z.object({
      orderId: z.number(),
      ebayItemId: z.string(),
      askingPrice: z.number(),
    }))
    .mutation(async ({ input }) => {
      const { attemptBestOffer } = await import("../ebayBestOffer");
      const result = await attemptBestOffer(input.orderId, input.ebayItemId, input.askingPrice);
      return result;
    }),

  // Check Best Offer eligibility without submitting
  checkBestOfferEligibility: adminProcedure
    .input(z.object({ ebayItemId: z.string() }))
    .query(async ({ input }) => {
      const { checkBestOfferEligibility } = await import("../ebayBestOffer");
      return checkBestOfferEligibility(input.ebayItemId);
    }),

  // Get offer status for an order
  getOrderOfferStatus: adminProcedure
    .input(z.object({ orderId: z.number() }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "DB unavailable" });
      const result = await db
        .select({
          ebayOfferStatus: orders.ebayOfferStatus,
          ebayOfferAmount: orders.ebayOfferAmount,
          ebayOfferSentAt: orders.ebayOfferSentAt,
          ebayOfferRespondedAt: orders.ebayOfferRespondedAt,
          ebayOfferSavings: orders.ebayOfferSavings,
          ebayOfferId: orders.ebayOfferId,
        })
        .from(orders)
        .where(eq(orders.id, input.orderId))
        .limit(1);
      return result[0] || null;
    }),

  // Check eBay availability for a card (admin manual check)
  checkEbayCardAvailability: adminProcedure
    .input(z.object({ ebayItemId: z.string(), cardId: z.number() }))
    .mutation(async ({ input }) => {
      const result = await checkEbayAvailability(input.ebayItemId);
      if (!result.available) {
        const db = await getDb();
        if (db) {
          await db.update(cards)
            .set({ status: "sold" })
            .where(eq(cards.id, input.cardId));
        }
      }
      return result;
    }),

  // Clear all eBay dropship cards (for refresh)
  clearDropshipCards: adminProcedure
    .mutation(async () => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "DB unavailable" });
      const result = await db.delete(cards).where(sql`${cards.isDropship} = 1`);
      return { success: true, deleted: (result as any).rowsAffected || 0 };
    }),

  // -- CARD PROFILE (full edit + history) ------------------------------------
  adminGetCardProfile: adminProcedure
    .input(z.object({ cardId: z.number() }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      const [card] = await db.select().from(cards).where(eq(cards.id, input.cardId)).limit(1);
      if (!card) throw new TRPCError({ code: "NOT_FOUND", message: "Card not found" });
      const orderHistory = await db.select().from(orders).where(eq(orders.cardId, input.cardId)).orderBy(desc(orders.createdAt)).limit(20);
      const { getCardHistoryByCardId } = await import("../db");
      const history = await getCardHistoryByCardId(input.cardId);
      return { card, orderHistory, history };
    }),

  adminUpdateCardFull: adminProcedure
    .input(z.object({
      cardId: z.number(),
      title: z.string().optional(),
      playerName: z.string().optional(),
      year: z.string().optional(),
      manufacturer: z.string().optional(),
      cardNumber: z.string().optional(),
      setName: z.string().optional(),
      sport: z.enum(["baseball","basketball","football","hockey","soccer","other"]).optional(),
      price: z.string().optional(),
      aiGrade: z.string().optional(),
      status: z.enum(["active","sold","draft","auction","traded","casino","bank"]).optional(),
      description: z.string().optional(),
      isUpAndComing: z.boolean().optional(),
      isShowcaseCard: z.boolean().optional(),
      featuredOnMain: z.boolean().optional(),
      cardShippingFee: z.string().optional(),
    }))
    .mutation(async ({ input, ctx }) => {
      const { cardId, aiGrade, ...rest } = input;
      const updates: Record<string, unknown> = { ...rest };
      if (aiGrade !== undefined) {
        const LABEL_MAP: Record<string, string> = {
          "10": "GEM MINT", "9.5": "MINT+", "9": "MINT",
          "8.5": "NM-MT+", "8": "NM-MT", "7.5": "NM+", "7": "NM",
          "6.5": "EX-MT+", "6": "EX-MT", "5.5": "EX+", "5": "EX",
          "4.5": "VG-EX+", "4": "VG-EX", "3.5": "VG+", "3": "VG",
          "2": "GOOD", "1.5": "FAIR", "1": "POOR",
        };
        updates.aiGrade = aiGrade;
        updates.aiGradeLabel = LABEL_MAP[aiGrade] || `GRADE ${aiGrade}`;
        updates.condition = "graded";
      }
      await createCardEvent({ cardId, userEmail: ctx.user.email ?? undefined, eventType: "status_changed", description: `Admin full edit by ${ctx.user.email}`, metadata: { updates } });
      await updateCard(cardId, updates as Parameters<typeof updateCard>[1]);
      return { success: true };
    }),

  // -- ORDER TRACKING & FUND RELEASE -----------------------------------------
  adminUpdateOrderTracking: adminProcedure
    .input(z.object({
      orderId: z.number(),
      trackingNumber: z.string().optional(),
      carrier: z.string().optional(),
      carrierStatus: z.string().optional(),
      status: z.enum(["pending","paid","label_created","shipped","delivered","confirmed","completed","cancelled","refunded","disputed"]).optional(),
    }))
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      const updates: Record<string, unknown> = {};
      if (input.trackingNumber !== undefined) updates.trackingNumber = input.trackingNumber;
      if (input.carrier !== undefined) updates.carrier = input.carrier;
      if (input.carrierStatus !== undefined) updates.carrierStatus = input.carrierStatus;
      if (input.status !== undefined) {
        updates.status = input.status;
        if (input.status === "delivered") updates.deliveredAt = new Date();
      }
      await db.update(orders).set(updates).where(eq(orders.id, input.orderId));
      return { success: true };
    }),

  adminReleaseFunds: adminProcedure
    .input(z.object({ orderId: z.number() }))
    .mutation(async ({ input, ctx }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      const [order] = await db.select().from(orders).where(eq(orders.id, input.orderId)).limit(1);
      if (!order) throw new TRPCError({ code: "NOT_FOUND", message: "Order not found" });
      if (order.fundsReleased) throw new TRPCError({ code: "BAD_REQUEST", message: "Funds already released" });
      if (order.isDropshipOrder) throw new TRPCError({ code: "BAD_REQUEST", message: "eBay dropship order — no manual release needed" });
      await db.update(orders).set({
        fundsReleased: true,
        fundsReleasedAt: new Date(),
        fundsReleasedBy: ctx.user.email ?? "admin",
        status: "completed",
      }).where(eq(orders.id, input.orderId));
      // Notify seller that funds have been released
      if (order.sellerEmail) {
        const releasedAt = new Date().toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric" });
        sendEmail({
          to: order.sellerEmail,
          subject: `💰 Funds released for Order #${order.id}`,
          html: `<div style="font-family:sans-serif;max-width:600px;margin:0 auto;padding:24px">
            <h2 style="color:#1a3a6b">💰 Your funds have been released!</h2>
            <p>Your payment for Order #${order.id} has been released.</p>
            <p><strong>Amount:</strong> $${parseFloat(order.totalAmount ?? "0").toFixed(2)}</p>
            <p><strong>Released on:</strong> ${releasedAt}</p>
            <p>Funds will appear in your account within 1-3 business days depending on your payment method.</p>
            <p>Thank you for selling on SportCardsOnline.com!</p>
            <p style="color:#888;font-size:12px">SportCardsOnline.com — Questions? Contact support.</p>
          </div>`,
        }).catch(() => {});
      }
      return { success: true, releasedBy: ctx.user.email, releasedAt: new Date() };
    }),

  // -- SELLER PAYOUTS ---------------------------------------------------------
  listSellerPayouts: adminProcedure
    .input(z.object({
      search: z.string().optional(),
      limit: z.number().default(100),
      offset: z.number().default(0),
    }).optional())
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) return { payouts: [], total: 0, totalAmount: 0 };

      const conditions = [
        eq(orders.fundsReleased, true),
      ];
      if (input?.search) {
        conditions.push(
          or(
            like(orders.sellerEmail, `%${input.search}%`),
            like(orders.cardTitle, `%${input.search}%`),
            like(orders.fundsReleasedBy, `%${input.search}%`),
          )! as any
        );
      }

      const [payouts, countResult, sumResult] = await Promise.all([
        db.select({
          id: orders.id,
          cardTitle: orders.cardTitle,
          sellerEmail: orders.sellerEmail,
          buyerEmail: orders.buyerEmail,
          totalAmount: orders.totalAmount,
          platformFee: orders.platformFee,
          fundsReleasedAt: orders.fundsReleasedAt,
          fundsReleasedBy: orders.fundsReleasedBy,
          trackingNumber: orders.trackingNumber,
          carrier: orders.carrier,
          deliveredAt: orders.deliveredAt,
          isDropshipOrder: orders.isDropshipOrder,
          status: orders.status,
        })
          .from(orders)
          .where(and(...conditions))
          .orderBy(desc(orders.fundsReleasedAt))
          .limit(input?.limit ?? 100)
          .offset(input?.offset ?? 0),
        db.select({ count: sql<number>`count(*)` }).from(orders).where(and(...conditions)),
        db.select({ total: sql<number>`sum(totalAmount)` }).from(orders).where(and(...conditions)),
      ]);

      return {
        payouts,
        total: Number(countResult[0]?.count ?? 0),
        totalAmount: Number(sumResult[0]?.total ?? 0),
      };
    }),

  // -- SHIPPING LABEL CREATION (Shippo) ---------------------------------------
  adminCreateShippingLabel: adminProcedure
    .input(z.object({
      orderId: z.number(),
      // Buyer / recipient address
      toName: z.string(),
      toStreet1: z.string(),
      toStreet2: z.string().optional(),
      toCity: z.string(),
      toState: z.string(),
      toZip: z.string(),
      toCountry: z.string().default("US"),
      toPhone: z.string().optional(),
      toEmail: z.string().optional(),
      // Parcel (optional overrides — defaults to standard card bubble mailer)
      weightOz: z.number().optional(),
      lengthIn: z.number().optional(),
      widthIn: z.number().optional(),
      heightIn: z.number().optional(),
      // Insurance
      insuredValue: z.number().optional(),
    }))
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });

      const [order] = await db.select().from(orders).where(eq(orders.id, input.orderId)).limit(1);
      if (!order) throw new TRPCError({ code: "NOT_FOUND", message: "Order not found" });

      const result = await createShippingLabel({
        toAddress: {
          name: input.toName,
          street1: input.toStreet1,
          street2: input.toStreet2,
          city: input.toCity,
          state: input.toState,
          zip: input.toZip,
          country: input.toCountry,
          phone: input.toPhone,
          email: input.toEmail,
        },
        weightOz: input.weightOz,
        lengthIn: input.lengthIn,
        widthIn: input.widthIn,
        heightIn: input.heightIn,
        orderId: input.orderId,
        cardTitle: order.cardTitle ?? "Sports Card",
        insuredValue: input.insuredValue,
      });

      // Save tracking number, carrier, label URL, and update status
      await db.update(orders).set({
        trackingNumber: result.trackingNumber,
        carrier: result.carrier,
        labelUrl: result.labelUrl,
        labelPurchased: true,
        status: "label_created",
      }).where(eq(orders.id, input.orderId));

      return {
        trackingNumber: result.trackingNumber,
        carrier: result.carrier,
        labelUrl: result.labelUrl,
        rate: result.rate,
        shippoTransactionId: result.shippoTransactionId,
      };
    }),

  // -- BATCH LABEL CREATION ---------------------------------------------------
  adminBatchCreateLabels: adminProcedure
    .mutation(async () => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });

      // Find all paid/pending orders that have a shipping address but no label yet
      const pending = await db.select().from(orders)
        .where(
          and(
            eq(orders.labelPurchased, false),
            or(
              eq(orders.status, "paid"),
              eq(orders.status, "pending"),
            )
          )
        )
        .orderBy(orders.id)
        .limit(100);

      const results: Array<{
        orderId: number;
        cardTitle: string;
        success: boolean;
        trackingNumber?: string;
        labelUrl?: string;
        rate?: string;
        error?: string;
      }> = [];

      for (const order of pending) {
        // Skip orders without a shipping address
        if (!order.shippingAddress) {
          results.push({ orderId: order.id, cardTitle: order.cardTitle ?? "—", success: false, error: "No shipping address" });
          continue;
        }

        // Parse shipping address (stored as JSON string)
        let addr: Record<string, string>;
        try {
          addr = JSON.parse(order.shippingAddress);
        } catch {
          results.push({ orderId: order.id, cardTitle: order.cardTitle ?? "—", success: false, error: "Invalid address format" });
          continue;
        }

        const toName = addr.name || addr.fullName || addr.recipientName || "";
        const toStreet1 = addr.street1 || addr.address1 || addr.line1 || "";
        const toCity = addr.city || "";
        const toState = addr.state || addr.province || "";
        const toZip = addr.zip || addr.postal_code || addr.postalCode || "";

        if (!toName || !toStreet1 || !toCity || !toState || !toZip) {
          results.push({ orderId: order.id, cardTitle: order.cardTitle ?? "—", success: false, error: "Incomplete address" });
          continue;
        }

        try {
          const result = await createShippingLabel({
            toAddress: {
              name: toName,
              street1: toStreet1,
              street2: addr.street2 || addr.address2 || addr.line2 || undefined,
              city: toCity,
              state: toState,
              zip: toZip,
              country: addr.country || "US",
              phone: addr.phone || order.buyerEmail || undefined,
              email: order.buyerEmail || undefined,
            },
            orderId: order.id,
            cardTitle: order.cardTitle ?? "Sports Card",
            insuredValue: order.totalAmount ? parseFloat(order.totalAmount) : undefined,
          });

          await db.update(orders).set({
            trackingNumber: result.trackingNumber,
            carrier: result.carrier,
            labelUrl: result.labelUrl,
            labelPurchased: true,
            status: "label_created",
          }).where(eq(orders.id, order.id));

          results.push({
            orderId: order.id,
            cardTitle: order.cardTitle ?? "—",
            success: true,
            trackingNumber: result.trackingNumber,
            labelUrl: result.labelUrl,
            rate: result.rate,
          });
        } catch (err: any) {
          results.push({
            orderId: order.id,
            cardTitle: order.cardTitle ?? "—",
            success: false,
            error: err?.message ?? "Unknown error",
          });
        }
      }

      const succeeded = results.filter(r => r.success).length;
      const failed = results.filter(r => !r.success).length;
      const skipped = pending.length === 0 ? 0 : 0; // all pending are in results

      return { results, succeeded, failed, total: results.length };
    }),

  adminGetCollectionItem: adminProcedure
    .input(z.object({ collectionId: z.number() }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      const [item] = await db.select().from(collections).where(eq(collections.id, input.collectionId)).limit(1);
      if (!item) throw new TRPCError({ code: "NOT_FOUND", message: "Collection item not found" });
      return item;
    }),

  adminUpdateCollectionItem: adminProcedure
    .input(z.object({
      collectionId: z.number(),
      overallGrade: z.string().optional(),
      estimatedValueLow: z.string().optional(),
      estimatedValueHigh: z.string().optional(),
      cardTitle: z.string().optional(),
      playerName: z.string().optional(),
      year: z.string().optional(),
      setName: z.string().optional(),
      sport: z.enum(["baseball","basketball","football","hockey","soccer","other"]).optional(),
      certNumber: z.string().optional(),
      description: z.string().optional(),
      listingStatus: z.string().optional(),
      notes: z.string().optional(),
    }))
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      const { collectionId, ...rest } = input;
      const updates: Record<string, unknown> = {};
      for (const [k, v] of Object.entries(rest)) {
        if (v !== undefined) updates[k] = v;
      }
      if (Object.keys(updates).length === 0) return { success: true };
      await db.update(collections).set(updates).where(eq(collections.id, collectionId));
      return { success: true };
    }),

  // -- INVENTORY SUMMARY (house vs eBay breakdown) ---------------------------
  inventorySummary: adminProcedure.query(async () => {
    const db = await getDb();
    if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });

    const [houseRows, ebayRows] = await Promise.all([
      // House = manually added cards (graded in-house, physically owned)
      db
        .select({
          status: cards.status,
          count: sql<number>`count(*)`,
          totalValue: sql<number>`COALESCE(sum(CAST(${cards.price} AS DECIMAL(10,2))), 0)`,
        })
        .from(cards)
        .where(eq(cards.source, "manual"))
        .groupBy(cards.status),
      // eBay Imported = cards sourced via eBay import (still house inventory)
      db
        .select({
          status: cards.status,
          count: sql<number>`count(*)`,
          totalValue: sql<number>`COALESCE(sum(CAST(${cards.price} AS DECIMAL(10,2))), 0)`,
        })
        .from(cards)
        .where(eq(cards.source, "ebay_import"))
        .groupBy(cards.status),
    ]);

    const summarize = (rows: { status: string | null; count: number; totalValue: number }[]) => {
      let totalCount = 0;
      let totalValue = 0;
      const byStatus: Record<string, { count: number; value: number }> = {};
      for (const row of rows) {
        const cnt = Number(row.count);
        const val = Number(row.totalValue) || 0;
        totalCount += cnt;
        totalValue += val;
        byStatus[row.status ?? "unknown"] = { count: cnt, value: val };
      }
      return {
        totalCount,
        totalValue: Math.round(totalValue * 100) / 100,
        avgPrice: totalCount > 0 ? Math.round((totalValue / totalCount) * 100) / 100 : 0,
        byStatus,
      };
    };

    return {
      house: summarize(houseRows),
      ebay: summarize(ebayRows),
    };
  }),

  // -- INVENTORY TIER STATS (for health widget) ----------------------------
  inventoryTierStats: adminProcedure.query(async () => {
    const db = await getDb();
    if (!db) return { tiers: [], totalEligible: 0, avgPrice: 0, medianPrice: 0 };

    // Fetch all active cards under $2000 (exclude high-end outliers)
    const allCards = await db
      .select({ price: cards.price, isMainStore: cards.isMainStore })
      .from(cards)
      .where(and(
        eq(cards.status, "active"),
        sql`CAST(${cards.price} AS DECIMAL) < 2000`,
        sql`CAST(${cards.price} AS DECIMAL) > 0`,
      ));

    const total = allCards.length;
    if (total === 0) return { tiers: [], totalEligible: 0, avgPrice: 0, medianPrice: 0 };

    const tierDefs = [
      { label: "Entry",    min: 0,   max: 25,   target: 35,   color: "#22c55e", desc: "$10\u2013$25" },
      { label: "Mid",      min: 25,  max: 75,   target: 30,   color: "#3b82f6", desc: "$26\u2013$75" },
      { label: "Core",     min: 75,  max: 150,  target: 20,   color: "#a855f7", desc: "$76\u2013$150" },
      { label: "Premium",  min: 150, max: 500,  target: 12.5, color: "#f59e0b", desc: "$151\u2013$500" },
      { label: "High End", min: 500, max: 2000, target: 2.5,  color: "#ef4444", desc: "$501\u2013$1,999" },
    ];

    const prices = allCards
      .map(c => parseFloat(String(c.price ?? 0)))
      .filter(p => p > 0)
      .sort((a, b) => a - b);

    const avgPrice = prices.reduce((s, p) => s + p, 0) / prices.length;
    const medianPrice = prices[Math.floor(prices.length / 2)] ?? 0;

    const tiers = tierDefs.map(t => {
      const count = allCards.filter(c => {
        const p = parseFloat(String(c.price ?? 0));
        return p > t.min && p <= t.max;
      }).length;
      const currentPct = total > 0 ? (count / total) * 100 : 0;
      const diff = currentPct - t.target;
      const status = Math.abs(diff) <= 5 ? "ok" : diff > 0 ? "over" : "under";
      return {
        label: t.label,
        desc: t.desc,
        color: t.color,
        count,
        currentPct: Math.round(currentPct * 10) / 10,
        targetPct: t.target,
        diff: Math.round(diff * 10) / 10,
        status,
      };
    });

    return {
      tiers,
      totalEligible: total,
      avgPrice: Math.round(avgPrice * 100) / 100,
      medianPrice: Math.round(medianPrice * 100) / 100,
    };
  }),

  // -- BEST OFFER QUEUE (all orders with offer activity) --------------------
  getBestOfferQueue: adminProcedure
    .input(z.object({
      status: z.enum(["all", "pending", "accepted", "declined", "countered", "expired", "not_eligible", "fallback_full_price"]).default("all"),
      limit: z.number().default(100),
    }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) return [];
      const conditions: any[] = [sql`${orders.ebayOfferStatus} IS NOT NULL`];
      if (input.status !== "all") {
        conditions.push(eq(orders.ebayOfferStatus, input.status as any));
      }
      const result = await db
        .select({
          orderId: orders.id,
          ticketNumber: orders.ticketNumber,
          buyerEmail: orders.buyerEmail,
          totalAmount: orders.totalAmount,
          createdAt: orders.createdAt,
          ebayOfferStatus: orders.ebayOfferStatus,
          ebayOfferAmount: orders.ebayOfferAmount,
          ebayOfferSentAt: orders.ebayOfferSentAt,
          ebayOfferRespondedAt: orders.ebayOfferRespondedAt,
          ebayOfferSavings: orders.ebayOfferSavings,
          ebayOfferId: orders.ebayOfferId,
          ebayFulfillmentLink: orders.ebayFulfillmentLink,
          dropshipFulfilledAt: orders.dropshipFulfilledAt,
          cardTitle: cards.title,
          cardPlayerName: cards.playerName,
          cardEbayItemId: cards.ebayItemId,
          cardSourcePrice: cards.sourcePrice,
          cardImage: cards.frontImageUrl,
        })
        .from(orders)
        .leftJoin(cards, eq(orders.cardId, cards.id))
        .where(and(...conditions))
        .orderBy(desc(orders.ebayOfferSentAt))
        .limit(input.limit);
      return result;
    }),
  // -- INVENTORY CARDS BY SOURCE + STATUS (for widget drill-down) ------------
  inventoryCardsByStatus: adminProcedure
    .input(z.object({
      source: z.enum(["house", "ebay"]),
      status: z.string(),
      limit: z.number().default(100),
    }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) return [];
      const isHouse = input.source === "house";
      const results = await db
        .select()
        .from(cards)
        .where(and(
          eq(cards.isMainStore, isHouse),
          eq(cards.status, input.status as any),
        ))
        .orderBy(desc(cards.createdAt))
        .limit(input.limit);
      return results;
    }),

  // -- BEST OFFER SAVINGS TIME-SERIES (for dashboard chart) -----------------
  getBestOfferSavingsTimeSeries: adminProcedure
    .input(z.object({
      // Number of days to look back (default 90)
      days: z.number().min(7).max(365).default(90),
      // Granularity: daily or weekly
      granularity: z.enum(["daily", "weekly"]).default("daily"),
    }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) return { points: [], totalSavings: 0, acceptedCount: 0 };

      // Pull all accepted offers within the time window
      const cutoff = new Date();
      cutoff.setDate(cutoff.getDate() - input.days);

      const rows = await db
        .select({
          respondedAt: orders.ebayOfferRespondedAt,
          savings: orders.ebayOfferSavings,
        })
        .from(orders)
        .where(
          and(
            sql`${orders.ebayOfferStatus} = 'accepted'`,
            sql`${orders.ebayOfferSavings} IS NOT NULL`,
            sql`${orders.ebayOfferRespondedAt} >= ${cutoff.toISOString().slice(0, 19).replace('T', ' ')}`,
          )
        )
        .orderBy(orders.ebayOfferRespondedAt);

      // Build a map of date-bucket → daily savings
      const bucketMap = new Map<string, number>();

      // Pre-fill every bucket in the range with 0 so the chart has no gaps
      const now = new Date();
      const step = input.granularity === "weekly" ? 7 : 1;
      for (let d = new Date(cutoff); d <= now; d.setDate(d.getDate() + step)) {
        const key = input.granularity === "weekly"
          ? `${d.getFullYear()}-W${String(Math.ceil((d.getDate()) / 7)).padStart(2, '0')}-${d.toISOString().slice(0, 10)}`
          : d.toISOString().slice(0, 10);
        if (!bucketMap.has(key)) bucketMap.set(key, 0);
      }

      // Accumulate savings into buckets
      let totalSavings = 0;
      let acceptedCount = 0;
      for (const row of rows) {
        if (!row.respondedAt || !row.savings) continue;
        const d = new Date(row.respondedAt);
        const key = input.granularity === "weekly"
          ? `${d.getFullYear()}-W${String(Math.ceil((d.getDate()) / 7)).padStart(2, '0')}-${d.toISOString().slice(0, 10)}`
          : d.toISOString().slice(0, 10);
        const val = parseFloat(row.savings as string);
        bucketMap.set(key, (bucketMap.get(key) ?? 0) + val);
        totalSavings += val;
        acceptedCount++;
      }

      // Build sorted points array and compute running cumulative
      const sortedKeys = Array.from(bucketMap.keys()).sort();
      let cumulative = 0;
      const points = sortedKeys.map(key => {
        const daily = Math.round((bucketMap.get(key) ?? 0) * 100) / 100;
        cumulative = Math.round((cumulative + daily) * 100) / 100;
        // Use the date portion (last 10 chars) as the display label
        const label = key.slice(-10);
        return { date: label, daily, cumulative };
      });

      return {
        points,
        totalSavings: Math.round(totalSavings * 100) / 100,
        acceptedCount,
      };
    }),

  // -- eBay AVAILABILITY CHECK -----------------------------------------------
  // Scans all isDropship cards, verifies each eBay listing is still live,
  // and deletes cards that are no longer available. Sends owner notification on removal.
  runAvailabilityCheck: adminProcedure
    .mutation(async () => {
      // Delegate to the shared job function (same logic used by the cron job)
      return runAvailCheckJob();
    }),

  // Returns the result of the last availability check run (cron or manual)
  getLastAvailabilityRun: adminProcedure
    .query(async () => {
      return lastAvailabilityRun;
    }),

  // ─── Blog procedures ──────────────────────────────────────────────────────
  listBlogPosts: adminProcedure
    .input(z.object({ limit: z.number().min(1).max(100).default(50) }).optional())
    .query(async ({ input }) => {
      return listAllBlogPosts(input?.limit ?? 50);
    }),

  generateBlogPost: adminProcedure
    .input(z.object({
      topic: z.string().optional(),
      sport: z.string().optional(),
    }).optional())
    .mutation(async ({ input }) => {
      const post = await generateBlogPost({ topic: input?.topic, sport: input?.sport });
      return post;
    }),

  generateBlogVideo: adminProcedure
    .input(z.object({ postId: z.number() }))
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "DB unavailable" });
      const [post] = await db.select().from(blogPosts).where(eq(blogPosts.id, input.postId)).limit(1);
      if (!post) throw new TRPCError({ code: "NOT_FOUND", message: "Post not found" });
      await updateBlogPost(input.postId, { videoStatus: "generating" });
      try {
        const result = await generateBlogVideo({
          postId: post.id,
          title: post.title,
          excerpt: post.excerpt ?? "",
          content: post.content,
          coverImageUrl: post.coverImageUrl,
          slug: post.slug,
        });
        await updateBlogPost(input.postId, { videoStatus: "ready", videoUrl: result.s3Url });
        return { success: true, videoUrl: result.s3Url, durationSeconds: result.durationSeconds };
      } catch (e) {
        await updateBlogPost(input.postId, { videoStatus: "error", videoErrorMsg: (e as Error).message });
        throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: (e as Error).message });
      }
    }),

  publishBlogVideoToYouTube: adminProcedure
    .input(z.object({ postId: z.number() }))
    .mutation(async ({ input }) => {
      if (!isYouTubeConfigured()) {
        throw new TRPCError({ code: "PRECONDITION_FAILED", message: "YouTube credentials not configured. Add YOUTUBE_CLIENT_ID, YOUTUBE_CLIENT_SECRET, YOUTUBE_REFRESH_TOKEN in Settings → Secrets." });
      }
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "DB unavailable" });
      const [post] = await db.select().from(blogPosts).where(eq(blogPosts.id, input.postId)).limit(1);
      if (!post) throw new TRPCError({ code: "NOT_FOUND", message: "Post not found" });
      if (!post.videoUrl) throw new TRPCError({ code: "PRECONDITION_FAILED", message: "Generate the video first before publishing to YouTube." });
      const os = await import("os");
      const path = await import("path");
      const fs = await import("fs/promises");
      const tmpPath = path.join(os.tmpdir(), `yt-upload-${post.id}-${Date.now()}.mp4`);
      // Download video from S3 to temp file
      const https = await import("https");
      const http = await import("http");
      await new Promise<void>((resolve, reject) => {
        const fileStream = require("fs").createWriteStream(tmpPath);
        const protocol = post.videoUrl!.startsWith("https") ? https : http;
        protocol.get(post.videoUrl!, (res: any) => {
          res.pipe(fileStream);
          fileStream.on("finish", () => { fileStream.close(); resolve(); });
        }).on("error", reject);
      });
      try {
        // ── Auto-generate YouTube tags and authoritative links ──────────────
        const autoTagResult = await generateVideoAutoTags({
          title: post.title,
          excerpt: post.excerpt ?? "",
          sport: post.sport ?? "other",
          existingTags: post.tags ? JSON.parse(post.tags) : [],
        });

        // Build the enriched YouTube description
        const baseDescription = post.excerpt ?? post.title;
        const siteUrl = "https://www.sportcardsonline.com";
        const enrichedDescription =
          baseDescription +
          `\n\n🃏 Browse & Buy Sports Cards: ${siteUrl}` +
          `\n📊 Free Card Valuations: ${siteUrl}/marketplace` +
          `\n⭐ Professional Card Grading: ${siteUrl}/grading` +
          `\n📖 Read the full article: ${siteUrl}/blog/${post.slug}` +
          autoTagResult.authoritativeLinksBlock +
          `\n\n${autoTagResult.hashtagString}`;

        const ytResult = await uploadToYouTube({
          videoPath: tmpPath,
          title: post.title,
          description: enrichedDescription,
          excerpt: post.excerpt ?? "",
          slug: post.slug,
          tags: autoTagResult.finalTags,
          thumbnailUrl: post.coverImageUrl ?? undefined,
        });

        // Save auto-tags and links back to the blog post record
        await updateBlogPost(input.postId, {
          youtubeVideoId: ytResult.videoId,
          youtubeUrl: ytResult.videoUrl,
          videoStatus: "published",
          youtubeAutoTags: autoTagResult.youtubeAutoTags,
          youtubeAutoLinks: autoTagResult.youtubeAutoLinks,
        });
        return {
          success: true,
          youtubeUrl: ytResult.videoUrl,
          videoId: ytResult.videoId,
          tagsUsed: autoTagResult.finalTags,
          linksInjected: JSON.parse(autoTagResult.youtubeAutoLinks).length,
        };
      } finally {
        try { await fs.unlink(tmpPath); } catch { /* ignore */ }
      }
    }),

  deleteBlogPost: adminProcedure
    .input(z.object({ postId: z.number() }))
    .mutation(async ({ input }) => {
      await deleteBlogPost(input.postId);
      return { success: true };
    }),

  // -- CARD DEDUPLICATION -------------------------------------------------------
  // Finds duplicate eBay dropship cards (same playerName+year+setName+condition+gradeScore),
  // merges them into one listing using the highest price and summed qty, deletes the rest.
  // House cards (isDropship=0 / source='manual') are NEVER touched.
  deduplicateCards: adminProcedure
    .mutation(async () => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });

      // Fetch all active dropship cards
      const dropshipCards = await db
        .select({
          id: cards.id,
          playerName: cards.playerName,
          year: cards.year,
          setName: cards.setName,
          condition: cards.condition,
          gradeScore: cards.gradeScore,
          price: cards.price,
          qty: cards.qty,
          title: cards.title,
        })
        .from(cards)
        .where(and(sql`${cards.isDropship} = 1`, sql`${cards.status} = 'active'`));

      // Group by dedup key
      const groups = new Map<string, typeof dropshipCards>();
      for (const card of dropshipCards) {
        const key = [
          (card.playerName ?? "").toLowerCase().trim(),
          (card.year ?? "").trim(),
          (card.setName ?? "").toLowerCase().trim(),
          (card.condition ?? "").toLowerCase().trim(),
          (card.gradeScore ?? "").toLowerCase().trim(),
        ].join("|");
        if (!groups.has(key)) groups.set(key, []);
        groups.get(key)!.push(card);
      }

      let mergedGroups = 0;
      let deletedCards = 0;
      const mergedTitles: string[] = [];

      for (const group of Array.from(groups.values())) {
        if (group.length <= 1) continue; // no duplicates

        // Sort by price descending — keep the highest-priced card as the canonical listing
        group.sort((a: { price: string | null }, b: { price: string | null }) => parseFloat(b.price ?? "0") - parseFloat(a.price ?? "0"));
        const keeper = group[0];
        const duplicates = group.slice(1);

        // Sum up all quantities
        const totalQty = group.reduce((sum: number, c: { qty: number }) => sum + (c.qty ?? 1), 0);
        const highestPrice = keeper.price ?? "0";

        // Update the keeper with merged qty and highest price
        await db
          .update(cards)
          .set({ qty: totalQty, price: highestPrice })
          .where(eq(cards.id, keeper.id));

        // Delete all duplicates
        for (const dup of duplicates) {
          await db.delete(cards).where(eq(cards.id, dup.id));
          deletedCards++;
        }

        mergedGroups++;
        mergedTitles.push(`${keeper.playerName} (${group.length} → 1, qty ${totalQty}, $${highestPrice})`);
      }

      return { mergedGroups, deletedCards, mergedTitles };
    }),

  getPlatformSettings: adminProcedure.query(async () => {
    const db = await getDb();
    if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
    const [store] = await db.select().from(stores).where(eq(stores.isMainStore, true)).limit(1);
    return {
      labelBorderColor: store?.labelColor ?? "red",
    };
  }),

  updatePlatformSettings: adminProcedure
    .input(z.object({
      labelBorderColor: z.enum(["red", "blue", "black", "white", "orange"]),
    }))
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      // Map border color to labelColor enum value
      const colorMap: Record<string, "dark" | "ruby" | "light" | "silver" | "nightlife" | "red" | "black" | "none"> = {
        red: "ruby",
        blue: "nightlife",
        black: "black",
        white: "light",
        orange: "silver",
      };
      const labelColorVal = colorMap[input.labelBorderColor] ?? "ruby";
      await db.update(stores).set({ labelColor: labelColorVal }).where(eq(stores.isMainStore, true));
      return { success: true };
    }),
});
