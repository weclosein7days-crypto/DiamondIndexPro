/**
 * Kids Educational Trivia Router
 * - Age-matched questions from DOB
 * - Spaced repetition: wrong answers rephrase + re-queue after 10 questions
 * - AI auto-generator: creates new questions when bank runs low
 * - Per-kid history, mastery, and streak tracking
 */

import { z } from "zod";
import { router, publicProcedure } from "../_core/trpc";
import { TRPCError } from "@trpc/server";
import { eq, and, notInArray, between, sql, asc } from "drizzle-orm";
import { getDb } from "../db";
import { invokeLLM } from "../_core/llm";
import {
  kidsTriviaQuestions,
  kidsQuestionHistory,
  kidsRephraseQueue,
  kidsSubjectMastery,
  kidsProfiles,
  kidsActivityLog,
} from "../../drizzle/schema";

// ─── Helpers ─────────────────────────────────────────────────────────────────

/** Calculate age in years from a YYYY-MM-DD birthdate string */
function calcAge(birthdate: string): number {
  const today = new Date();
  const dob = new Date(birthdate);
  let age = today.getFullYear() - dob.getFullYear();
  const m = today.getMonth() - dob.getMonth();
  if (m < 0 || (m === 0 && today.getDate() < dob.getDate())) age--;
  return Math.max(6, Math.min(age, 18));
}

/** Shuffle an array (Fisher-Yates) */
function shuffle<T>(arr: T[]): T[] {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

/** Build a question payload with shuffled choices */
function buildQuestionPayload(q: {
  id: number;
  question: string;
  correctAnswer: string;
  choiceA: string;
  choiceB: string;
  choiceC: string;
  choiceD: string;
  sport: string | null;
  difficulty: string;
  subject: string;
  creditsReward: number;
  funFact: string | null;
  ageMin: number;
  ageMax: number;
}, isRephrase = false, rephraseId?: number) {
  const choices = shuffle([q.choiceA, q.choiceB, q.choiceC, q.choiceD]);
  return {
    questionId: q.id,
    rephraseId: rephraseId ?? null,
    isRephrase,
    question: q.question,
    choices,
    correctAnswer: q.correctAnswer,
    sport: q.sport ?? "basketball",
    difficulty: q.difficulty,
    subject: q.subject,
    creditsReward: q.creditsReward,
    funFact: q.funFact ?? "",
    ageMin: q.ageMin,
    ageMax: q.ageMax,
  };
}

// ─── AI Rephrase ──────────────────────────────────────────────────────────────

async function rephraseQuestion(original: {
  question: string;
  correctAnswer: string;
  choiceA: string;
  choiceB: string;
  choiceC: string;
  choiceD: string;
  sport: string | null;
  subject: string;
  ageMin: number;
}): Promise<{
  question: string;
  choiceA: string;
  choiceB: string;
  choiceC: string;
  choiceD: string;
  correctAnswer: string;
} | null> {
  try {
    const resp = await invokeLLM({
      messages: [
        {
          role: "system",
          content: `You are a fun kids educational trivia writer. Rephrase the given question using a DIFFERENT sports example or scenario while testing the SAME concept. Keep the same correct answer. Make it age-appropriate for a ${original.ageMin}-year-old. Use sports themes (${original.sport ?? "any sport"}). Return JSON only.`,
        },
        {
          role: "user",
          content: `Original question: "${original.question}"
Correct answer: "${original.correctAnswer}"
Wrong choices: "${original.choiceA}", "${original.choiceB}", "${original.choiceC}", "${original.choiceD}"
Subject: ${original.subject}

Rephrase this into a NEW question that tests the same concept with a different sports scenario. Return JSON:
{
  "question": "...",
  "choiceA": "...",
  "choiceB": "...",
  "choiceC": "...",
  "choiceD": "...",
  "correctAnswer": "..."
}`,
        },
      ],
      response_format: {
        type: "json_schema",
        json_schema: {
          name: "rephrased_question",
          strict: true,
          schema: {
            type: "object",
            properties: {
              question: { type: "string" },
              choiceA: { type: "string" },
              choiceB: { type: "string" },
              choiceC: { type: "string" },
              choiceD: { type: "string" },
              correctAnswer: { type: "string" },
            },
            required: ["question", "choiceA", "choiceB", "choiceC", "choiceD", "correctAnswer"],
            additionalProperties: false,
          },
        },
      },
    });
    const content = resp?.choices?.[0]?.message?.content;
    if (!content) return null;
    return JSON.parse(typeof content === 'string' ? content : JSON.stringify(content));
  } catch {
    return null;
  }
}

// ─── AI Question Generator ────────────────────────────────────────────────────

async function generateNewQuestions(
  age: number,
  subject: string,
  sport: string,
  count: number
): Promise<Array<{
  question: string;
  correctAnswer: string;
  choiceA: string;
  choiceB: string;
  choiceC: string;
  choiceD: string;
  funFact: string;
  difficulty: "easy" | "medium" | "hard";
}>> {
  try {
    const difficulty = age <= 7 ? "easy" : age <= 9 ? "easy to medium" : age <= 11 ? "medium" : "medium to hard";
    const resp = await invokeLLM({
      messages: [
        {
          role: "system",
          content: `You are a fun kids educational trivia writer. Create ${count} unique multiple-choice questions for a ${age}-year-old child. Each question MUST be about ${subject} (school curriculum) but use a ${sport} sports theme or example to make it engaging. Difficulty: ${difficulty}. Return JSON array only.`,
        },
        {
          role: "user",
          content: `Generate ${count} sports-themed ${subject} questions for age ${age}. Each must have exactly 4 choices (A/B/C/D), one correct answer, and a fun sports fact. Return JSON array:
[
  {
    "question": "...",
    "correctAnswer": "...",
    "choiceA": "...",
    "choiceB": "...",
    "choiceC": "...",
    "choiceD": "...",
    "funFact": "...",
    "difficulty": "easy|medium|hard"
  }
]`,
        },
      ],
    });
    const content = resp?.choices?.[0]?.message?.content;
    if (!content) return [];
    const contentStr = typeof content === 'string' ? content : JSON.stringify(content);
    // Extract JSON array from response
    const match = contentStr.match(/\[[\s\S]*\]/);
    if (!match) return [];
    const parsed = JSON.parse(match[0]);
    return Array.isArray(parsed) ? parsed.slice(0, count) : [];
  } catch {
    return [];
  }
}

// ─── Router ───────────────────────────────────────────────────────────────────

export const kidsTriviaRouter = router({
  /**
   * Get the next question for a kid.
   * Priority: 1) pending rephrase queue, 2) unseen age-matched questions, 3) oldest seen
   */
  getNextQuestion: publicProcedure
    .input(z.object({ kidId: z.number() }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "DB unavailable" });

      // Get kid profile for age calculation
      const [kid] = await db.select().from(kidsProfiles).where(eq(kidsProfiles.id, input.kidId)).limit(1);
      if (!kid) throw new TRPCError({ code: "NOT_FOUND", message: "Kid profile not found" });

      const kidAge = calcAge(kid.birthdate);

      // Count how many questions this kid has answered total (for rephrase timing)
      const [countRow] = await db
        .select({ count: sql<number>`COUNT(*)` })
        .from(kidsQuestionHistory)
        .where(eq(kidsQuestionHistory.kidId, input.kidId));
      const totalAnswered = Number(countRow?.count ?? 0);

      // 1) Check rephrase queue — show if showAfterCount <= totalAnswered
      const [pendingRephrase] = await db
        .select()
        .from(kidsRephraseQueue)
        .where(
          and(
            eq(kidsRephraseQueue.kidId, input.kidId),
            eq(kidsRephraseQueue.shown, false),
            sql`${kidsRephraseQueue.showAfterCount} <= ${totalAnswered}`
          )
        )
        .orderBy(asc(kidsRephraseQueue.showAfterCount))
        .limit(1);

      if (pendingRephrase) {
        // Get original question for metadata
        const [orig] = await db
          .select()
          .from(kidsTriviaQuestions)
          .where(eq(kidsTriviaQuestions.id, pendingRephrase.originalQuestionId))
          .limit(1);
        if (orig) {
          const rq = {
            id: orig.id,
            question: pendingRephrase.rephrasedQuestion,
            correctAnswer: pendingRephrase.correctAnswer,
            choiceA: pendingRephrase.rephrasedChoiceA,
            choiceB: pendingRephrase.rephrasedChoiceB,
            choiceC: pendingRephrase.rephrasedChoiceC,
            choiceD: pendingRephrase.rephrasedChoiceD,
            sport: orig.sport,
            difficulty: orig.difficulty,
            subject: (orig as any).subject ?? "sports_facts",
            creditsReward: orig.creditsReward,
            funFact: orig.funFact,
            ageMin: orig.ageMin,
            ageMax: (orig as any).ageMax ?? 13,
          };
          return buildQuestionPayload(rq, true, pendingRephrase.id);
        }
      }

      // 2) Get IDs of questions already answered correctly (mastered)
      const masteredRows = await db
        .select({ questionId: kidsQuestionHistory.questionId })
        .from(kidsQuestionHistory)
        .where(
          and(
            eq(kidsQuestionHistory.kidId, input.kidId),
            eq(kidsQuestionHistory.answeredCorrectly, true)
          )
        );
      const masteredIds = masteredRows.map((r) => r.questionId);

      // 3) Find unseen age-matched questions
      const baseQuery = db
        .select()
        .from(kidsTriviaQuestions)
        .where(
          and(
            between(kidsTriviaQuestions.ageMin, 6, kidAge),
            sql`${(kidsTriviaQuestions as any).ageMax} >= ${kidAge}`
          )
        );

      let candidates = await baseQuery;

      // Filter out mastered ones
      if (masteredIds.length > 0) {
        candidates = candidates.filter((q) => !masteredIds.includes(q.id));
      }

      if (candidates.length === 0) {
        // All age-appropriate questions mastered — trigger AI generation
        return {
          questionId: null,
          rephraseId: null,
          isRephrase: false,
          question: null,
          choices: [],
          correctAnswer: null,
          sport: "basketball",
          difficulty: "easy",
          subject: "sports_facts",
          creditsReward: 5,
          funFact: "",
          ageMin: kidAge,
          ageMax: kidAge,
          needsGeneration: true,
          kidAge,
        };
      }

      // Pick a random unseen question
      const q = candidates[Math.floor(Math.random() * candidates.length)];
      return {
        ...buildQuestionPayload({
          ...q,
          subject: (q as any).subject ?? "sports_facts",
          ageMax: (q as any).ageMax ?? 13,
        }),
        needsGeneration: false,
        kidAge,
      };
    }),

  /**
   * Submit an answer for a question.
   * - Records history
   * - If wrong: generates rephrase and queues it for 10 questions later
   * - Updates subject mastery
   * - Awards credits on correct answer
   */
  submitAnswer: publicProcedure
    .input(
      z.object({
        kidId: z.number(),
        questionId: z.number(),
        rephraseId: z.number().nullable().optional(),
        selectedAnswer: z.string(),
        correctAnswer: z.string(),
        subject: z.string(),
        creditsReward: z.number(),
      })
    )
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "DB unavailable" });

      const isCorrect = input.selectedAnswer.trim().toLowerCase() === input.correctAnswer.trim().toLowerCase();

      // Count total answered for spaced repetition timing
      const [countRow] = await db
        .select({ count: sql<number>`COUNT(*)` })
        .from(kidsQuestionHistory)
        .where(eq(kidsQuestionHistory.kidId, input.kidId));
      const totalAnswered = Number(countRow?.count ?? 0);

      // Record history
      await db.insert(kidsQuestionHistory).values({
        kidId: input.kidId,
        questionId: input.questionId,
        answeredCorrectly: isCorrect,
        selectedAnswer: input.selectedAnswer,
        attemptCount: 1,
        masteredAt: isCorrect ? new Date() : undefined,
        lastShownAt: new Date(),
      });

      // Mark rephrase as shown/answered
      if (input.rephraseId) {
        await db
          .update(kidsRephraseQueue)
          .set({ shown: true, answeredCorrectly: isCorrect })
          .where(eq(kidsRephraseQueue.id, input.rephraseId));
      }

      // Update subject mastery
      const [existing] = await db
        .select()
        .from(kidsSubjectMastery)
        .where(
          and(
            eq(kidsSubjectMastery.kidId, input.kidId),
            eq(kidsSubjectMastery.subject, input.subject)
          )
        )
        .limit(1);

      if (existing) {
        const newStreak = isCorrect ? existing.currentStreak + 1 : 0;
        await db
          .update(kidsSubjectMastery)
          .set({
            totalAnswered: existing.totalAnswered + 1,
            totalCorrect: isCorrect ? existing.totalCorrect + 1 : existing.totalCorrect,
            currentStreak: newStreak,
            bestStreak: Math.max(existing.bestStreak, newStreak),
            lastAnsweredAt: new Date(),
          })
          .where(eq(kidsSubjectMastery.id, existing.id));
      } else {
        await db.insert(kidsSubjectMastery).values({
          kidId: input.kidId,
          subject: input.subject,
          totalAnswered: 1,
          totalCorrect: isCorrect ? 1 : 0,
          currentStreak: isCorrect ? 1 : 0,
          bestStreak: isCorrect ? 1 : 0,
          lastAnsweredAt: new Date(),
        });
      }

      // Award credits on correct answer
      if (isCorrect) {
        await db
          .update(kidsProfiles)
          .set({
            credits: sql`${kidsProfiles.credits} + ${input.creditsReward}`,
            totalCreditsEarned: sql`${kidsProfiles.totalCreditsEarned} + ${input.creditsReward}`,
            xp: sql`${kidsProfiles.xp} + ${Math.ceil(input.creditsReward * 1.5)}`,
          })
          .where(eq(kidsProfiles.id, input.kidId));

        // Log activity
        await db.insert(kidsActivityLog).values({
          kidId: input.kidId,
          activityType: "trivia_correct",
          creditsEarned: input.creditsReward,
          creditsSpent: 0,
          metadata: { questionId: input.questionId, subject: input.subject },
        });
      } else {
        // Log wrong answer
        await db.insert(kidsActivityLog).values({
          kidId: input.kidId,
          activityType: "trivia_wrong",
          creditsEarned: 0,
          creditsSpent: 0,
          metadata: { questionId: input.questionId, subject: input.subject },
        });

        // Generate rephrase asynchronously and queue it
        if (!input.rephraseId) {
          // Don't await — fire and forget so response is fast
          (async () => {
            try {
              const [orig] = await db
                .select()
                .from(kidsTriviaQuestions)
                .where(eq(kidsTriviaQuestions.id, input.questionId))
                .limit(1);
              if (!orig) return;

              const rephrased = await rephraseQuestion({
                question: orig.question,
                correctAnswer: orig.correctAnswer,
                choiceA: orig.choiceA,
                choiceB: orig.choiceB,
                choiceC: orig.choiceC,
                choiceD: orig.choiceD,
                sport: orig.sport,
                subject: (orig as any).subject ?? "sports_facts",
                ageMin: orig.ageMin,
              });

              if (rephrased) {
                await db.insert(kidsRephraseQueue).values({
                  kidId: input.kidId,
                  originalQuestionId: input.questionId,
                  rephrasedQuestion: rephrased.question,
                  rephrasedChoiceA: rephrased.choiceA,
                  rephrasedChoiceB: rephrased.choiceB,
                  rephrasedChoiceC: rephrased.choiceC,
                  rephrasedChoiceD: rephrased.choiceD,
                  correctAnswer: rephrased.correctAnswer,
                  showAfterCount: totalAnswered + 10, // show after 10 more questions
                  shown: false,
                });
              }
            } catch (e) {
              console.error("[kidsTrivia] Rephrase generation failed:", e);
            }
          })();
        }
      }

      return {
        isCorrect,
        creditsAwarded: isCorrect ? input.creditsReward : 0,
        xpAwarded: isCorrect ? Math.ceil(input.creditsReward * 1.5) : 0,
        message: isCorrect
          ? `🎉 Correct! +${input.creditsReward} credits!`
          : "Not quite — we'll give you another chance later with a different example!",
      };
    }),

  /**
   * Generate new AI questions for a kid when their bank runs low.
   * Called when getNextQuestion returns needsGeneration: true.
   */
  generateMoreQuestions: publicProcedure
    .input(
      z.object({
        kidId: z.number(),
        count: z.number().min(5).max(25).default(10),
      })
    )
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "DB unavailable" });

      const [kid] = await db.select().from(kidsProfiles).where(eq(kidsProfiles.id, input.kidId)).limit(1);
      if (!kid) throw new TRPCError({ code: "NOT_FOUND", message: "Kid not found" });

      const kidAge = calcAge(kid.birthdate);
      const subjects = ["math", "reading", "science", "history", "sports_facts"];
      const sports = ["basketball", "baseball", "football", "soccer", "hockey"];
      let totalInserted = 0;

      for (const subject of subjects) {
        const sport = sports[Math.floor(Math.random() * sports.length)];
        const perSubject = Math.ceil(input.count / subjects.length);
        const newQs = await generateNewQuestions(kidAge, subject, sport, perSubject);

        for (const q of newQs) {
          try {
            await db.insert(kidsTriviaQuestions).values({
              question: q.question,
              correctAnswer: q.correctAnswer,
              choiceA: q.choiceA,
              choiceB: q.choiceB,
              choiceC: q.choiceC,
              choiceD: q.choiceD,
              sport,
              difficulty: q.difficulty as "easy" | "medium" | "hard",
              ageMin: Math.max(6, kidAge - 1),
              category: "player_fact",
              creditsReward: q.difficulty === "hard" ? 12 : q.difficulty === "medium" ? 8 : 5,
              funFact: q.funFact,
            });
            totalInserted++;
          } catch (e) {
            // Skip duplicates
          }
        }
      }

      return { generated: totalInserted, kidAge };
    }),

  /**
   * Get a kid's learning stats for the Parents Corner dashboard.
   */
  getLearningStats: publicProcedure
    .input(z.object({ kidId: z.number() }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "DB unavailable" });

      const mastery = await db
        .select()
        .from(kidsSubjectMastery)
        .where(eq(kidsSubjectMastery.kidId, input.kidId));

      const [totalRow] = await db
        .select({
          total: sql<number>`COUNT(*)`,
          correct: sql<number>`SUM(CASE WHEN answeredCorrectly = 1 THEN 1 ELSE 0 END)`,
        })
        .from(kidsQuestionHistory)
        .where(eq(kidsQuestionHistory.kidId, input.kidId));

      const [todayRow] = await db
        .select({ count: sql<number>`COUNT(*)` })
        .from(kidsQuestionHistory)
        .where(
          and(
            eq(kidsQuestionHistory.kidId, input.kidId),
            sql`DATE(lastShownAt) = CURDATE()`
          )
        );

      return {
        subjectMastery: mastery,
        totalAnswered: Number(totalRow?.total ?? 0),
        totalCorrect: Number(totalRow?.correct ?? 0),
        accuracy: totalRow?.total
          ? Math.round((Number(totalRow.correct) / Number(totalRow.total)) * 100)
          : 0,
        answeredToday: Number(todayRow?.count ?? 0),
      };
    }),
});
