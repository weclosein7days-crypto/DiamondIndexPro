import { protectedProcedure, router } from "../_core/trpc";
import { z } from "zod";
import { eq, and, like, desc, sql } from "drizzle-orm";
import { getDb } from "../db";
import { userCollection, collections } from "../../drizzle/schema";
import collectionSeedData from "../collection_seed_data.json";

// eBay OAuth token cache
let ebayTokenCache: { token: string; expiresAt: number } | null = null;

async function getEbayToken(): Promise<string | null> {
  if (ebayTokenCache && Date.now() < ebayTokenCache.expiresAt - 60000) {
    return ebayTokenCache.token;
  }
  const clientId = process.env.EBAY_CLIENT_ID;
  const clientSecret = process.env.EBAY_CLIENT_SECRET;
  if (!clientId || !clientSecret) return null;
  try {
    const creds = Buffer.from(`${clientId}:${clientSecret}`).toString("base64");
    const res = await fetch("https://api.ebay.com/identity/v1/oauth2/token", {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
        Authorization: `Basic ${creds}`,
      },
      body: "grant_type=client_credentials&scope=https%3A%2F%2Fapi.ebay.com%2Foauth%2Fapi_scope",
    });
    if (!res.ok) return null;
    const data = await res.json() as { access_token: string; expires_in: number };
    ebayTokenCache = { token: data.access_token, expiresAt: Date.now() + data.expires_in * 1000 };
    return data.access_token;
  } catch {
    return null;
  }
}

async function fetchEbayImage(query: string): Promise<string | null> {
  const token = await getEbayToken();
  if (!token) return null;
  try {
    const q = encodeURIComponent(query + " sports card");
    const res = await fetch(
      `https://api.ebay.com/buy/browse/v1/item_summary/search?q=${q}&limit=3&filter=categoryIds:{212`,
      {
        headers: { Authorization: `Bearer ${token}`, "X-EBAY-C-MARKETPLACE-ID": "EBAY_US" },
      }
    );
    if (!res.ok) return null;
    const data = await res.json() as { itemSummaries?: Array<{ image?: { imageUrl: string } }> };
    return data.itemSummaries?.[0]?.image?.imageUrl ?? null;
  } catch {
    return null;
  }
}

export const collectionRouter = router({
  /** Import all cards from the SCP CSV seed data for the current user */
  importFromScp: protectedProcedure.mutation(async ({ ctx }) => {
    const db = await getDb();
    if (!db) throw new Error("DB unavailable");

    // Check if already imported
    const existing = await db
      .select({ count: sql<number>`count(*)` })
      .from(userCollection)
      .where(eq(userCollection.userId, ctx.user.id));
    const count = Number(existing[0]?.count ?? 0);
    if (count > 0) {
      return { imported: 0, skipped: count, message: `Already imported ${count} cards.` };
    }

    // Insert all cards in batches of 50
    const userId = ctx.user.id;
    const userEmail = ctx.user.email!;
    const rows = (collectionSeedData as typeof collectionSeedData).map((c) => ({
      userId,
      scpId: c.scpId,
      productName: c.productName,
      consoleName: c.consoleName,
      priceInPennies: c.priceInPennies,
      costBasisInPennies: c.costBasisInPennies,
      condition: c.condition ?? "Ungraded",
      quantity: c.quantity,
      gradingCompany: c.gradingCompany ?? null,
      gradingCertId: c.gradingCertId ?? null,
      sport: c.sport,
      playerName: c.playerName,
      notes: c.notes ?? null,
    }));

    const batchSize = 50;
    for (let i = 0; i < rows.length; i += batchSize) {
      await db.insert(userCollection).values(rows.slice(i, i + batchSize));
    }

    // Mirror into master collections CRM so cards appear in the user's CRM
    const collectionRows = (collectionSeedData as typeof collectionSeedData).map((c) => ({
      ownerEmail: userEmail,
      cardTitle: c.productName || c.playerName || "Imported Card",
      playerName: c.playerName || "Unknown",
      sport: (c.sport as any) || "baseball",
      frontImageUrl: null as string | null,
      backImageUrl: null as string | null,
      overallGrade: c.condition && c.condition !== "Ungraded" ? c.condition : null,
      gradeLabel: c.gradingCompany ? `${c.gradingCompany}` : null,
      certNumber: c.gradingCertId || null,
      estimatedValueLow: c.priceInPennies ? String(Math.round(c.priceInPennies / 100)) : null,
      estimatedValueHigh: c.priceInPennies ? String(Math.round(c.priceInPennies / 100)) : null,
      listingStatus: "none" as const,
      lifecycleNote: `Imported from SCP — ${c.condition ?? "Ungraded"}`,
    }));

    for (let i = 0; i < collectionRows.length; i += batchSize) {
      await db.insert(collections).values(collectionRows.slice(i, i + batchSize));
    }

    return { imported: rows.length, skipped: 0, message: `Imported ${rows.length} cards successfully.` };
  }),

  /** List collection with search and filters */
  list: protectedProcedure
    .input(
      z.object({
        search: z.string().optional(),
        sport: z.string().optional(),
        condition: z.string().optional(),
        page: z.number().default(1),
        pageSize: z.number().default(24),
        sortBy: z.enum(["value_desc", "value_asc", "name_asc", "name_desc", "newest"]).default("value_desc"),
      })
    )
    .query(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) return { cards: [], total: 0 };

      const conditions = [eq(userCollection.userId, ctx.user.id)];
      if (input.search) {
        conditions.push(
          sql`(${userCollection.productName} LIKE ${`%${input.search}%`} OR ${userCollection.playerName} LIKE ${`%${input.search}%`} OR ${userCollection.consoleName} LIKE ${`%${input.search}%`})`
        );
      }
      if (input.sport && input.sport !== "All") {
        conditions.push(eq(userCollection.sport, input.sport));
      }
      if (input.condition && input.condition !== "All") {
        conditions.push(like(userCollection.condition, `%${input.condition}%`));
      }

      const whereClause = and(...conditions);

      const totalRes = await db
        .select({ count: sql<number>`count(*)` })
        .from(userCollection)
        .where(whereClause);
      const total = Number(totalRes[0]?.count ?? 0);

      let orderClause;
      switch (input.sortBy) {
        case "value_asc": orderClause = sql`${userCollection.priceInPennies} ASC`; break;
        case "name_asc": orderClause = sql`${userCollection.productName} ASC`; break;
        case "name_desc": orderClause = sql`${userCollection.productName} DESC`; break;
        case "newest": orderClause = desc(userCollection.createdAt); break;
        default: orderClause = sql`${userCollection.priceInPennies} DESC`;
      }

      const offset = (input.page - 1) * input.pageSize;
      const cards = await db
        .select()
        .from(userCollection)
        .where(whereClause)
        .orderBy(orderClause)
        .limit(input.pageSize)
        .offset(offset);

      return { cards, total };
    }),

  /** Get collection stats */
  stats: protectedProcedure.query(async ({ ctx }) => {
    const db = await getDb();
    if (!db) return null;

    const res = await db
      .select({
        totalCards: sql<number>`sum(${userCollection.quantity})`,
        uniqueCards: sql<number>`count(*)`,
        totalValuePennies: sql<number>`sum(${userCollection.priceInPennies} * ${userCollection.quantity})`,
        totalCostPennies: sql<number>`sum(${userCollection.costBasisInPennies} * ${userCollection.quantity})`,
      })
      .from(userCollection)
      .where(eq(userCollection.userId, ctx.user.id));

    const sportRes = await db
      .select({
        sport: userCollection.sport,
        count: sql<number>`count(*)`,
      })
      .from(userCollection)
      .where(eq(userCollection.userId, ctx.user.id))
      .groupBy(userCollection.sport);

    return {
      totalCards: Number(res[0]?.totalCards ?? 0),
      uniqueCards: Number(res[0]?.uniqueCards ?? 0),
      totalValuePennies: Number(res[0]?.totalValuePennies ?? 0),
      totalCostPennies: Number(res[0]?.totalCostPennies ?? 0),
      bySport: sportRes,
    };
  }),

  /** Fetch image for a card from eBay (called lazily when card has no image) */
  fetchImage: protectedProcedure
    .input(z.object({ cardId: z.number(), query: z.string() }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) return null;

      // Verify ownership
      const [card] = await db
        .select()
        .from(userCollection)
        .where(and(eq(userCollection.id, input.cardId), eq(userCollection.userId, ctx.user.id)));
      if (!card) return null;

      // If already has image, return it
      if (card.imageUrl) return card.imageUrl;

      // Fetch from eBay
      const imageUrl = await fetchEbayImage(input.query);
      if (imageUrl) {
        await db
          .update(userCollection)
          .set({ imageUrl })
          .where(eq(userCollection.id, input.cardId));
      }
      return imageUrl;
    }),

  /** Get a single card detail */
  getCard: protectedProcedure
    .input(z.object({ cardId: z.number() }))
    .query(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) return null;
      const [card] = await db
        .select()
        .from(userCollection)
        .where(and(eq(userCollection.id, input.cardId), eq(userCollection.userId, ctx.user.id)));
      return card ?? null;
    }),

  /** Update card notes */
  updateNotes: protectedProcedure
    .input(z.object({ cardId: z.number(), notes: z.string() }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) return;
      await db
        .update(userCollection)
        .set({ notes: input.notes })
        .where(and(eq(userCollection.id, input.cardId), eq(userCollection.userId, ctx.user.id)));
    }),
});
