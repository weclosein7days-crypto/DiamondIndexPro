/**
 * Kids Collection & Trading Router
 * - Per-kid card collection persisted in DB
 * - Starter pack seeded on profile creation (Appie and Giffy get named packs)
 * - Kids can browse each other's collections and send/accept/decline trade offers
 */

import { router, publicProcedure } from "../_core/trpc";
import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { getDb } from "../db";
import { eq, and, or, ne, desc } from "drizzle-orm";

// ── Starter pack definitions ──────────────────────────────────────────────────
// Each kid gets 10 starter cards across different sports
const STARTER_PACKS: Record<string, Array<{
  playerName: string; year: string; sport: string; setName: string;
  cardNumber: string; rarity: "common" | "uncommon" | "rare" | "epic" | "legendary";
  estimatedValue: string; imageUrl?: string;
}>> = {
  // Appie's starter pack — basketball & baseball heavy
  appie: [
    { playerName: "LeBron James", year: "2003", sport: "basketball", setName: "Topps Chrome", cardNumber: "111", rarity: "rare", estimatedValue: "12.50" },
    { playerName: "Caitlin Clark", year: "2024", sport: "basketball", setName: "Panini Prizm", cardNumber: "RC1", rarity: "epic", estimatedValue: "45.00" },
    { playerName: "Mike Trout", year: "2011", sport: "baseball", setName: "Topps Update", cardNumber: "US175", rarity: "rare", estimatedValue: "18.00" },
    { playerName: "Patrick Mahomes", year: "2017", sport: "football", setName: "Panini Prizm", cardNumber: "269", rarity: "uncommon", estimatedValue: "8.00" },
    { playerName: "Connor McDavid", year: "2015", sport: "hockey", setName: "Upper Deck", cardNumber: "RC201", rarity: "uncommon", estimatedValue: "6.50" },
    { playerName: "Lionel Messi", year: "2004", sport: "soccer", setName: "Panini", cardNumber: "1", rarity: "legendary", estimatedValue: "95.00" },
    { playerName: "Stephen Curry", year: "2009", sport: "basketball", setName: "Topps", cardNumber: "321", rarity: "uncommon", estimatedValue: "7.00" },
    { playerName: "Shohei Ohtani", year: "2018", sport: "baseball", setName: "Topps", cardNumber: "700", rarity: "rare", estimatedValue: "22.00" },
    { playerName: "Cooper Flagg", year: "2025", sport: "basketball", setName: "Panini Prizm", cardNumber: "RC1", rarity: "epic", estimatedValue: "38.00" },
    { playerName: "Wayne Gretzky", year: "1979", sport: "hockey", setName: "O-Pee-Chee", cardNumber: "18", rarity: "legendary", estimatedValue: "120.00" },
  ],
  // Giffy's starter pack — football & soccer heavy
  giffy: [
    { playerName: "Patrick Mahomes", year: "2017", sport: "football", setName: "Panini Prizm", cardNumber: "269", rarity: "rare", estimatedValue: "14.00" },
    { playerName: "Caitlin Clark", year: "2024", sport: "basketball", setName: "Topps Chrome", cardNumber: "RC5", rarity: "epic", estimatedValue: "42.00" },
    { playerName: "Cristiano Ronaldo", year: "2003", sport: "soccer", setName: "Panini", cardNumber: "CR7", rarity: "legendary", estimatedValue: "88.00" },
    { playerName: "LeBron James", year: "2003", sport: "basketball", setName: "Upper Deck", cardNumber: "301", rarity: "uncommon", estimatedValue: "9.00" },
    { playerName: "Aaron Judge", year: "2013", sport: "baseball", setName: "Topps", cardNumber: "RC99", rarity: "rare", estimatedValue: "16.00" },
    { playerName: "Sidney Crosby", year: "2005", sport: "hockey", setName: "Upper Deck", cardNumber: "RC251", rarity: "rare", estimatedValue: "19.00" },
    { playerName: "Ja Morant", year: "2019", sport: "basketball", setName: "Panini Prizm", cardNumber: "RC249", rarity: "uncommon", estimatedValue: "7.50" },
    { playerName: "Josh Allen", year: "2018", sport: "football", setName: "Panini Prizm", cardNumber: "RC101", rarity: "uncommon", estimatedValue: "8.50" },
    { playerName: "Fernando Tatis Jr.", year: "2019", sport: "baseball", setName: "Topps Chrome", cardNumber: "RC203", rarity: "uncommon", estimatedValue: "6.00" },
    { playerName: "Cooper Flagg", year: "2025", sport: "basketball", setName: "Topps Chrome", cardNumber: "RC2", rarity: "epic", estimatedValue: "35.00" },
  ],
  // Default starter pack for any other kid
  default: [
    { playerName: "LeBron James", year: "2003", sport: "basketball", setName: "Topps", cardNumber: "221", rarity: "uncommon", estimatedValue: "8.00" },
    { playerName: "Caitlin Clark", year: "2024", sport: "basketball", setName: "Panini", cardNumber: "RC1", rarity: "rare", estimatedValue: "35.00" },
    { playerName: "Patrick Mahomes", year: "2017", sport: "football", setName: "Topps", cardNumber: "150", rarity: "uncommon", estimatedValue: "7.00" },
    { playerName: "Mike Trout", year: "2011", sport: "baseball", setName: "Topps", cardNumber: "US175", rarity: "uncommon", estimatedValue: "9.00" },
    { playerName: "Connor McDavid", year: "2015", sport: "hockey", setName: "Upper Deck", cardNumber: "RC1", rarity: "uncommon", estimatedValue: "6.00" },
    { playerName: "Cooper Flagg", year: "2025", sport: "basketball", setName: "Panini Prizm", cardNumber: "RC1", rarity: "rare", estimatedValue: "30.00" },
    { playerName: "Shohei Ohtani", year: "2018", sport: "baseball", setName: "Topps Chrome", cardNumber: "700", rarity: "uncommon", estimatedValue: "7.50" },
    { playerName: "Lionel Messi", year: "2004", sport: "soccer", setName: "Panini", cardNumber: "1", rarity: "rare", estimatedValue: "25.00" },
    { playerName: "Stephen Curry", year: "2009", sport: "basketball", setName: "Topps", cardNumber: "321", rarity: "common", estimatedValue: "4.00" },
    { playerName: "Josh Allen", year: "2018", sport: "football", setName: "Panini", cardNumber: "RC101", rarity: "common", estimatedValue: "5.00" },
  ],
};

function getStarterPack(displayName: string) {
  const key = displayName.toLowerCase().trim();
  if (key === "appie") return STARTER_PACKS.appie;
  if (key === "giffy") return STARTER_PACKS.giffy;
  return STARTER_PACKS.default;
}

export const kidsCollectionRouter = router({
  /**
   * Get or create a kid profile AND seed their starter pack if new.
   * Returns the kid's full collection.
   */
  getOrCreateWithCollection: publicProcedure
    .input(z.object({
      username: z.string().min(1).max(64),
      displayName: z.string().min(1).max(128),
      birthdate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional().default("2012-01-01"),
      avatarEmoji: z.string().optional().default("🏆"),
    }))
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "DB unavailable" });
      const { kidsProfiles, kidsCollection } = await import("../../drizzle/schema");

      // Find or create profile
      const [existing] = await db.select().from(kidsProfiles)
        .where(eq(kidsProfiles.username, input.username)).limit(1);

      let kidId: number;
      let isNew = false;

      if (existing) {
        kidId = existing.id;
      } else {
        const result = await db.insert(kidsProfiles).values({
          parentUserId: 0,
          username: input.username,
          displayName: input.displayName,
          birthdate: input.birthdate,
          avatarEmoji: input.avatarEmoji,
          credits: 25,
          totalCreditsEarned: 25,
          level: 1,
          xp: 0,
          isActive: true,
          shareToken: Math.random().toString(36).slice(2, 10),
        });
        kidId = (result as any).insertId as number;
        isNew = true;
      }

      // Seed starter pack if new or collection is empty
      const existingCards = await db.select().from(kidsCollection)
        .where(eq(kidsCollection.kidId, kidId)).limit(1);

      if (existingCards.length === 0) {
        const pack = getStarterPack(input.displayName);
        await db.insert(kidsCollection).values(
          pack.map(card => ({
            kidId,
            playerName: card.playerName,
            year: card.year,
            sport: card.sport,
            setName: card.setName,
            cardNumber: card.cardNumber,
            rarity: card.rarity,
            estimatedValue: card.estimatedValue,
            source: "starter_pack" as const,
          }))
        );
        isNew = true;
      }

      // Return full collection
      const cards = await db.select().from(kidsCollection)
        .where(eq(kidsCollection.kidId, kidId))
        .orderBy(desc(kidsCollection.acquiredAt));

      return { kidId, isNew, cards };
    }),

  /**
   * Get a kid's full collection by kidId.
   */
  getMyCollection: publicProcedure
    .input(z.object({ kidId: z.number().int().positive() }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "DB unavailable" });
      const { kidsCollection } = await import("../../drizzle/schema");
      const cards = await db.select().from(kidsCollection)
        .where(eq(kidsCollection.kidId, input.kidId))
        .orderBy(desc(kidsCollection.acquiredAt));
      return cards;
    }),

  /**
   * Add a card to a kid's collection (from card pull, trivia reward, etc.)
   */
  addCard: publicProcedure
    .input(z.object({
      kidId: z.number().int().positive(),
      playerName: z.string(),
      year: z.string().optional(),
      sport: z.string().optional(),
      setName: z.string().optional(),
      cardNumber: z.string().optional(),
      imageUrl: z.string().optional(),
      rarity: z.enum(["common", "uncommon", "rare", "epic", "legendary"]).default("common"),
      estimatedValue: z.string().optional().default("0.00"),
      source: z.enum(["daily_pull", "trivia_reward", "activity_reward", "trade", "starter_pack"]).default("daily_pull"),
    }))
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "DB unavailable" });
      const { kidsCollection } = await import("../../drizzle/schema");
      const result = await db.insert(kidsCollection).values({
        kidId: input.kidId,
        playerName: input.playerName,
        year: input.year,
        sport: input.sport,
        setName: input.setName,
        cardNumber: input.cardNumber,
        imageUrl: input.imageUrl,
        rarity: input.rarity,
        estimatedValue: input.estimatedValue,
        source: input.source,
      });
      return { cardId: (result as any).insertId as number };
    }),

  /**
   * Get all other kids' profiles (for trading — so Appie can see Giffy's collection)
   */
  getOtherKids: publicProcedure
    .input(z.object({ myKidId: z.number().int().positive() }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "DB unavailable" });
      const { kidsProfiles, kidsCollection } = await import("../../drizzle/schema");
      const others = await db.select().from(kidsProfiles)
        .where(and(ne(kidsProfiles.id, input.myKidId), eq(kidsProfiles.isActive, true)))
        .limit(20);
      // For each other kid, get their collection count
      const result = await Promise.all(others.map(async kid => {
        const cards = await db.select().from(kidsCollection)
          .where(eq(kidsCollection.kidId, kid.id));
        return {
          id: kid.id,
          displayName: kid.displayName,
          avatarEmoji: kid.avatarEmoji,
          level: kid.level,
          cardCount: cards.length,
          cards,
        };
      }));
      return result;
    }),

  /**
   * Send a trade offer: I offer one of my cards for one of your cards.
   */
  sendTradeOffer: publicProcedure
    .input(z.object({
      offererId: z.number().int().positive(),
      receiverId: z.number().int().positive(),
      offeredCardId: z.number().int().positive(),
      requestedCardId: z.number().int().positive(),
      message: z.string().max(255).optional(),
    }))
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "DB unavailable" });
      const { kidsTradeRequests, kidsCollection } = await import("../../drizzle/schema");

      // Verify offerer owns the offered card
      const [offeredCard] = await db.select().from(kidsCollection)
        .where(and(eq(kidsCollection.id, input.offeredCardId), eq(kidsCollection.kidId, input.offererId))).limit(1);
      if (!offeredCard) throw new TRPCError({ code: "BAD_REQUEST", message: "You don't own that card!" });

      // Verify receiver owns the requested card
      const [requestedCard] = await db.select().from(kidsCollection)
        .where(and(eq(kidsCollection.id, input.requestedCardId), eq(kidsCollection.kidId, input.receiverId))).limit(1);
      if (!requestedCard) throw new TRPCError({ code: "BAD_REQUEST", message: "That card doesn't belong to them!" });

      // Create trade request (expires in 48 hours)
      const expiresAt = new Date(Date.now() + 48 * 60 * 60 * 1000);
      const result = await db.insert(kidsTradeRequests).values({
        offererId: input.offererId,
        receiverId: input.receiverId,
        offeredCardId: input.offeredCardId,
        requestedCardId: input.requestedCardId,
        message: input.message,
        status: "pending",
        expiresAt,
      });
      return { tradeId: (result as any).insertId as number };
    }),

  /**
   * Get all pending trade offers for a kid (incoming + outgoing)
   */
  getMyTrades: publicProcedure
    .input(z.object({ kidId: z.number().int().positive() }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "DB unavailable" });
      const { kidsTradeRequests, kidsCollection, kidsProfiles } = await import("../../drizzle/schema");

      const trades = await db.select().from(kidsTradeRequests)
        .where(
          or(
            eq(kidsTradeRequests.offererId, input.kidId),
            eq(kidsTradeRequests.receiverId, input.kidId)
          )
        )
        .orderBy(desc(kidsTradeRequests.createdAt))
        .limit(50);

      // Enrich with card and player details
      const enriched = await Promise.all(trades.map(async trade => {
        const [offeredCard] = await db.select().from(kidsCollection).where(eq(kidsCollection.id, trade.offeredCardId)).limit(1);
        const [requestedCard] = await db.select().from(kidsCollection).where(eq(kidsCollection.id, trade.requestedCardId)).limit(1);
        const [offerer] = await db.select({ displayName: kidsProfiles.displayName, avatarEmoji: kidsProfiles.avatarEmoji }).from(kidsProfiles).where(eq(kidsProfiles.id, trade.offererId)).limit(1);
        const [receiver] = await db.select({ displayName: kidsProfiles.displayName, avatarEmoji: kidsProfiles.avatarEmoji }).from(kidsProfiles).where(eq(kidsProfiles.id, trade.receiverId)).limit(1);
        return {
          ...trade,
          offeredCard,
          requestedCard,
          offerer,
          receiver,
          isIncoming: trade.receiverId === input.kidId,
        };
      }));

      return enriched;
    }),

  /**
   * Accept a trade offer — swap the cards between kids
   */
  acceptTrade: publicProcedure
    .input(z.object({
      tradeId: z.number().int().positive(),
      kidId: z.number().int().positive(), // must be the receiver
    }))
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "DB unavailable" });
      const { kidsTradeRequests, kidsCollection } = await import("../../drizzle/schema");

      const [trade] = await db.select().from(kidsTradeRequests).where(eq(kidsTradeRequests.id, input.tradeId)).limit(1);
      if (!trade) throw new TRPCError({ code: "NOT_FOUND", message: "Trade not found" });
      if (trade.receiverId !== input.kidId) throw new TRPCError({ code: "FORBIDDEN", message: "Not your trade to accept" });
      if (trade.status !== "pending") throw new TRPCError({ code: "BAD_REQUEST", message: "Trade is no longer pending" });

      // Swap card ownership
      await db.update(kidsCollection).set({ kidId: trade.receiverId, source: "trade" }).where(eq(kidsCollection.id, trade.offeredCardId));
      await db.update(kidsCollection).set({ kidId: trade.offererId, source: "trade" }).where(eq(kidsCollection.id, trade.requestedCardId));

      // Mark trade as accepted
      await db.update(kidsTradeRequests).set({ status: "accepted", respondedAt: new Date() }).where(eq(kidsTradeRequests.id, input.tradeId));

      return { success: true };
    }),

  /**
   * Decline or cancel a trade offer
   */
  declineTrade: publicProcedure
    .input(z.object({
      tradeId: z.number().int().positive(),
      kidId: z.number().int().positive(),
    }))
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "DB unavailable" });
      const { kidsTradeRequests } = await import("../../drizzle/schema");

      const [trade] = await db.select().from(kidsTradeRequests).where(eq(kidsTradeRequests.id, input.tradeId)).limit(1);
      if (!trade) throw new TRPCError({ code: "NOT_FOUND", message: "Trade not found" });
      if (trade.receiverId !== input.kidId && trade.offererId !== input.kidId) {
        throw new TRPCError({ code: "FORBIDDEN", message: "Not your trade" });
      }

      const newStatus = trade.offererId === input.kidId ? "cancelled" : "declined";
      await db.update(kidsTradeRequests).set({ status: newStatus, respondedAt: new Date() }).where(eq(kidsTradeRequests.id, input.tradeId));
      return { success: true };
    }),

  /**
   * Daily 25-credit bonus — claim once per day
   */
  claimDailyBonus: publicProcedure
    .input(z.object({ kidId: z.number().int().positive() }))
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "DB unavailable" });
      const { kidsProfiles } = await import("../../drizzle/schema");

      const [profile] = await db.select().from(kidsProfiles).where(eq(kidsProfiles.id, input.kidId)).limit(1);
      if (!profile) throw new TRPCError({ code: "NOT_FOUND", message: "Profile not found" });

      const today = new Date().toISOString().slice(0, 10);
      const lastClaim = profile.lastDailyClaimAt ? new Date(profile.lastDailyClaimAt).toISOString().slice(0, 10) : null;

      if (lastClaim === today) {
        return { success: false, message: "Already claimed today!", credits: profile.credits };
      }

      const newCredits = profile.credits + 25;
      await db.update(kidsProfiles).set({
        credits: newCredits,
        totalCreditsEarned: profile.totalCreditsEarned + 25,
        lastDailyClaimAt: new Date(),
      }).where(eq(kidsProfiles.id, input.kidId));

      return { success: true, message: "+25 daily bonus credits! 🎉", credits: newCredits };
    }),

  /**
   * Parent grants bonus credits to a kid — auto-approved always
   */
  parentGrantCredits: publicProcedure
    .input(z.object({
      kidId: z.number().int().positive(),
      amount: z.number().int().min(1).max(10000),
      reason: z.string().max(255).optional().default("Parent bonus"),
    }))
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "DB unavailable" });
      const { kidsProfiles, kidsActivityLog } = await import("../../drizzle/schema");

      const [profile] = await db.select().from(kidsProfiles).where(eq(kidsProfiles.id, input.kidId)).limit(1);
      if (!profile) throw new TRPCError({ code: "NOT_FOUND", message: "Profile not found" });

      const newCredits = profile.credits + input.amount;
      await db.update(kidsProfiles).set({
        credits: newCredits,
        totalCreditsEarned: profile.totalCreditsEarned + input.amount,
      }).where(eq(kidsProfiles.id, input.kidId));

      // Log the activity
      await db.insert(kidsActivityLog).values({
        kidId: input.kidId,
        activityType: "daily_claim",
        creditsEarned: input.amount,
        creditsSpent: 0,
        metadata: { reason: input.reason, grantedBy: "parent" },
      });

      return { success: true, newCredits, message: `✅ ${input.amount} credits added for ${profile.displayName}!` };
    }),
});
