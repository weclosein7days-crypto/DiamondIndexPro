/**
 * One-time script: sets a blog post's videoUrl to a test MP4 and videoStatus to "ready"
 * so the YouTube upload button appears in the Admin panel.
 * Run: npx tsx server/scripts/setup_yt_test.ts
 */
import { getDb } from "../db";
import { blogPosts } from "../../drizzle/schema";
import { eq, isNull } from "drizzle-orm";

async function main() {
  const db = await getDb();
  if (!db) { console.error("DB unavailable"); process.exit(1); }

  // List current posts
  const posts = await db.select({
    id: blogPosts.id,
    title: blogPosts.title,
    videoStatus: blogPosts.videoStatus,
    videoUrl: blogPosts.videoUrl,
    youtubeVideoId: blogPosts.youtubeVideoId,
  }).from(blogPosts).limit(10);

  console.log("Existing blog posts:");
  posts.forEach(p => console.log(`  ID:${p.id} | ${p.title?.slice(0, 50)} | status:${p.videoStatus} | yt:${p.youtubeVideoId ?? "none"}`));

  if (posts.length === 0) {
    console.log("\nNo blog posts found. Generate one first via Admin → Blog → Generate Post.");
    process.exit(0);
  }

  // Pick first post without a YouTube ID
  const target = posts.find(p => !p.youtubeVideoId) ?? posts[0];
  console.log(`\nTarget: ID:${target.id} "${target.title?.slice(0, 50)}"`);

  // A short real MP4 (Google sample, ~1.5MB, 15 seconds)
  const testVideoUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4";

  await db.update(blogPosts)
    .set({ videoStatus: "ready", videoUrl: testVideoUrl })
    .where(eq(blogPosts.id, target.id));

  console.log(`✅ Done! Post ID:${target.id} is now videoStatus=ready.`);
  console.log(`   Go to Admin → Blog tab and click the "YouTube" button on that post.`);
  process.exit(0);
}

main().catch(e => { console.error(e.message); process.exit(1); });
