/**
 * Fast BGS import - runs sport by sport to avoid timeout
 * Run: npx tsx server/scripts/run_bgs_import_fast.ts basketball
 */
import { importEbayDropshipCards } from "../ebayDropship";

const sport = process.argv[2] || undefined;

async function main() {
  console.log(`Starting BGS Beckett import for sport: ${sport || "ALL"}...`);
  const result = await importEbayDropshipCards({
    sport,
    playersPerSport: 15,
    cardsPerPlayer: 5,
    maxTotal: 100,
  });
  console.log(`\n✅ Done: imported=${result.imported} skipped=${result.skipped} errors=${result.errors.length}`);
  if (result.errors.length > 0) {
    result.errors.slice(0, 5).forEach(e => console.log(`  - ${e}`));
  }
}

main().catch(console.error);
