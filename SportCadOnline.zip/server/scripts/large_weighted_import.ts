/**
 * large_weighted_import.ts
 * Runs a large eBay BGS import weighted toward baseball and basketball.
 * Target: 300-500 total cards.
 * 
 * Sport weights (out of 100):
 *   Baseball:    30%  → ~120 cards
 *   Basketball:  30%  → ~120 cards
 *   Football:    20%  → ~80 cards
 *   Hockey:      10%  → ~40 cards
 *   Soccer:       5%  → ~20 cards
 *   Golf:         5%  → ~20 cards
 */

import { importEbayDropshipCards } from "../ebayDropship";
import mysql from "mysql2/promise";

async function getCurrentCount(): Promise<number> {
  const conn = await mysql.createConnection(process.env.DATABASE_URL!);
  const [rows]: any = await conn.execute("SELECT COUNT(*) as cnt FROM cards");
  await conn.end();
  return rows[0].cnt;
}

async function main() {
  console.log("=== Large Weighted eBay BGS Import ===");
  console.log("Target: 300-500 total cards, weighted toward baseball & basketball");
  console.log("Start time:", new Date().toLocaleString());

  const startCount = await getCurrentCount();
  console.log(`Current card count: ${startCount}`);

  const sportConfigs = [
    { sport: "baseball",   playersPerSport: 40, cardsPerPlayer: 8, maxTotal: 130, label: "⚾ Baseball" },
    { sport: "basketball", playersPerSport: 40, cardsPerPlayer: 8, maxTotal: 130, label: "🏀 Basketball" },
    { sport: "football",   playersPerSport: 30, cardsPerPlayer: 6, maxTotal: 90,  label: "🏈 Football" },
    { sport: "hockey",     playersPerSport: 20, cardsPerPlayer: 5, maxTotal: 50,  label: "🏒 Hockey" },
    { sport: "soccer",     playersPerSport: 15, cardsPerPlayer: 4, maxTotal: 30,  label: "⚽ Soccer" },
    { sport: "golf",       playersPerSport: 15, cardsPerPlayer: 4, maxTotal: 30,  label: "⛳ Golf" },
  ];

  let totalImported = 0;
  let totalSkipped = 0;
  let totalErrors = 0;

  for (const config of sportConfigs) {
    console.log(`\n--- ${config.label} (target: ${config.maxTotal} cards) ---`);
    try {
      const result = await importEbayDropshipCards({
        sport: config.sport as any,
        playersPerSport: config.playersPerSport,
        cardsPerPlayer: config.cardsPerPlayer,
        maxTotal: config.maxTotal,
      });
      totalImported += result.imported;
      totalSkipped += result.skipped;
      totalErrors += result.errors?.length ?? 0;
      console.log(`✅ ${config.label}: imported=${result.imported}, skipped=${result.skipped}, errors=${result.errors?.length ?? 0}`);
    } catch (err: any) {
      console.error(`❌ ${config.label} failed:`, err.message);
      totalErrors++;
    }
  }

  const endCount = await getCurrentCount();
  console.log("\n=== Import Complete ===");
  console.log(`Cards before: ${startCount}`);
  console.log(`Cards after:  ${endCount}`);
  console.log(`Net new:      ${endCount - startCount}`);
  console.log(`Total imported: ${totalImported}`);
  console.log(`Total skipped:  ${totalSkipped}`);
  console.log(`Total errors:   ${totalErrors}`);
  console.log("End time:", new Date().toLocaleString());
  process.exit(0);
}

main().catch(e => {
  console.error("Fatal error:", e);
  process.exit(1);
});
