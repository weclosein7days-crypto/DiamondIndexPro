import { createCard, getDb } from "../db";
import mysql from "mysql2/promise";

async function main() {
  // Check DB count
  const conn = await mysql.createConnection(process.env.DATABASE_URL!);
  const [rows] = await conn.execute("SELECT COUNT(*) as cnt FROM cards") as any;
  console.log("Cards in DB:", rows[0].cnt);
  await conn.end();

  // Try createCard
  console.log("Testing createCard...");
  try {
    const result = await createCard({
      title: "Test Card BGS 9 LeBron James 2020",
      playerName: "LeBron James",
      year: "2020",
      setName: "",
      cardNumber: "",
      sport: "basketball",
      condition: "graded",
      gradeCompany: "Beckett",
      gradeScore: "9",
      price: "50.00",
      cardShippingFee: null,
      category: "modern",
      status: "active",
      description: "Test card",
      frontImageUrl: undefined,
      sellerEmail: "admin@sportcardsonline.com",
      storeName: "SCO House",
      isMainStore: true,
      source: "ebay_import",
      ebayItemId: "test_" + Date.now(),
      ebayListingUrl: "https://www.ebay.com/itm/test",
      sourcePrice: "41.67",
      isDropship: true,
      aiGrade: "9",
      aiGradeLabel: "Beckett 9",
    } as any);
    console.log("createCard result:", JSON.stringify(result));
  } catch (e: any) {
    console.log("createCard ERROR:", e.message);
    console.log("Stack:", e.stack?.substring(0, 500));
  }

  // Check count again
  const conn2 = await mysql.createConnection(process.env.DATABASE_URL!);
  const [rows2] = await conn2.execute("SELECT COUNT(*) as cnt FROM cards") as any;
  console.log("Cards in DB after:", rows2[0].cnt);
  await conn2.end();

  process.exit(0);
}

main().catch(e => { console.error(e); process.exit(1); });
