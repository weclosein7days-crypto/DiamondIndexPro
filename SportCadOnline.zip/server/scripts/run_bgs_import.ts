/**
 * One-time script to import BGS 9/9.5/10 cards from eBay
 * Run: npx tsx server/scripts/run_bgs_import.ts
 */
import { importEbayDropshipCards } from "../ebayDropship";

async function main() {
  console.log("Starting BGS Beckett import (9, 9.5, 10 only)...");
  const result = await importEbayDropshipCards({
    playersPerSport: 8,
    cardsPerPlayer: 4,
    maxTotal: 300,
  });
  console.log(`\n✅ Import complete:`);
  console.log(`   Imported: ${result.imported}`);
  console.log(`   Skipped:  ${result.skipped}`);
  if (result.errors.length > 0) {
    console.log(`   Errors (${result.errors.length}):`);
    result.errors.slice(0, 10).forEach(e => console.log(`     - ${e}`));
  }
}

main().catch(console.error);
