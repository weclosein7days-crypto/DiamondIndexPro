#!/usr/bin/env python3
"""
generate_video.py — Sports Cards Online Blog Video Generator

Creates a professional MP4 video from a blog post using:
- Animated title card with SCO branding
- Scrolling content slides with key sections
- Background music-ready format (silent, 1080p)
- Branded outro with CTA

Usage:
  python3 generate_video.py --title "..." --excerpt "..." --content "..." --output /tmp/out.mp4 [--cover_url "..."]

Returns JSON to stdout: { success, output, duration_seconds, file_size_bytes, error? }
"""

import argparse
import json
import os
import sys
import textwrap
import re
import tempfile
import math
from pathlib import Path

try:
    from PIL import Image, ImageDraw, ImageFont, ImageFilter
    import numpy as np
    from moviepy.editor import (
        ImageClip, concatenate_videoclips, CompositeVideoClip,
        ColorClip, TextClip, VideoFileClip
    )
    import requests
except ImportError as e:
    print(json.dumps({"success": False, "error": f"Missing dependency: {e}"}))
    sys.exit(1)

# ── Constants ─────────────────────────────────────────────────────────────────
W, H = 1920, 1080
FPS = 24
FONT_BOLD = "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf"
FONT_REG  = "/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf"

# Brand colors
SCO_DARK   = (10, 15, 35)       # deep navy
SCO_NAVY   = (15, 25, 55)       # navy
SCO_RED    = (220, 38, 38)      # brand red
SCO_GOLD   = (251, 191, 36)     # gold accent
SCO_WHITE  = (255, 255, 255)
SCO_LGRAY  = (200, 210, 230)


def load_font(path, size):
    try:
        return ImageFont.truetype(path, size)
    except Exception:
        return ImageFont.load_default()


def wrap_text(text, font, max_width, draw):
    """Wrap text to fit within max_width pixels."""
    words = text.split()
    lines = []
    current = []
    for word in words:
        test = " ".join(current + [word])
        bbox = draw.textbbox((0, 0), test, font=font)
        if bbox[2] - bbox[0] <= max_width:
            current.append(word)
        else:
            if current:
                lines.append(" ".join(current))
            current = [word]
    if current:
        lines.append(" ".join(current))
    return lines


def draw_gradient_bg(img, color1=SCO_DARK, color2=SCO_NAVY):
    """Draw a vertical gradient background."""
    draw = ImageDraw.Draw(img)
    for y in range(H):
        t = y / H
        r = int(color1[0] * (1 - t) + color2[0] * t)
        g = int(color1[1] * (1 - t) + color2[1] * t)
        b = int(color1[2] * (1 - t) + color2[2] * t)
        draw.line([(0, y), (W, y)], fill=(r, g, b))
    return img


def draw_card_pattern(img, alpha=30):
    """Draw subtle card suit pattern in background."""
    draw = ImageDraw.Draw(img)
    suits = ["♠", "♥", "♦", "♣"]
    try:
        suit_font = load_font(FONT_REG, 80)
        for i in range(0, W, 200):
            for j in range(0, H, 200):
                suit = suits[(i // 200 + j // 200) % 4]
                draw.text((i, j), suit, fill=(255, 255, 255, alpha), font=suit_font)
    except Exception:
        pass
    return img


def make_intro_frame(title, excerpt):
    """Create the intro title card frame."""
    img = Image.new("RGB", (W, H), SCO_DARK)
    draw_gradient_bg(img, (8, 12, 30), (20, 35, 70))
    draw = ImageDraw.Draw(img)

    # Red accent bar on left
    draw.rectangle([(0, 0), (12, H)], fill=SCO_RED)

    # Gold accent bar at top
    draw.rectangle([(0, 0), (W, 8)], fill=SCO_GOLD)

    # SCO Logo text
    logo_font = load_font(FONT_BOLD, 52)
    draw.text((80, 60), "SportCardsOnline.com", fill=SCO_GOLD, font=logo_font)

    # Subtitle under logo
    sub_font = load_font(FONT_REG, 28)
    draw.text((80, 125), "Buy • Sell • Grade • Collect", fill=SCO_LGRAY, font=sub_font)

    # Divider line
    draw.line([(80, 170), (W - 80, 170)], fill=SCO_RED, width=3)

    # Main title — large, centered
    title_font = load_font(FONT_BOLD, 72)
    title_clean = title.replace("'", "'").replace(""", '"').replace(""", '"')
    title_lines = wrap_text(title_clean, title_font, W - 200, draw)
    # Limit to 3 lines
    title_lines = title_lines[:3]
    y_start = 220
    for line in title_lines:
        bbox = draw.textbbox((0, 0), line, font=title_font)
        tw = bbox[2] - bbox[0]
        draw.text(((W - tw) // 2, y_start), line, fill=SCO_WHITE, font=title_font)
        y_start += 90

    # Excerpt text
    exc_font = load_font(FONT_REG, 38)
    excerpt_clean = excerpt.replace("'", "'")[:200]
    exc_lines = wrap_text(excerpt_clean, exc_font, W - 240, draw)[:3]
    y_exc = max(y_start + 40, 560)
    for line in exc_lines:
        bbox = draw.textbbox((0, 0), line, font=exc_font)
        tw = bbox[2] - bbox[0]
        draw.text(((W - tw) // 2, y_exc), line, fill=SCO_LGRAY, font=exc_font)
        y_exc += 52

    # Bottom CTA bar
    draw.rectangle([(0, H - 120), (W, H)], fill=SCO_RED)
    cta_font = load_font(FONT_BOLD, 42)
    cta_text = "🃏  www.sportcardsonline.com  |  Buy • Sell • Grade"
    bbox = draw.textbbox((0, 0), cta_text, font=cta_font)
    tw = bbox[2] - bbox[0]
    draw.text(((W - tw) // 2, H - 85), cta_text, fill=SCO_WHITE, font=cta_font)

    return img


def extract_sections(content):
    """Extract H2 sections and their text from markdown content."""
    sections = []
    current_title = "Introduction"
    current_text = []

    for line in content.split("\n"):
        line = line.strip()
        if line.startswith("## "):
            if current_text:
                sections.append((current_title, " ".join(current_text)))
            current_title = line[3:].strip()
            current_text = []
        elif line.startswith("# "):
            pass  # skip H1
        elif line and not line.startswith("```") and not line.startswith("|"):
            # Clean markdown
            clean = re.sub(r'\[([^\]]+)\]\([^\)]+\)', r'\1', line)
            clean = re.sub(r'\*\*([^*]+)\*\*', r'\1', clean)
            clean = re.sub(r'\*([^*]+)\*', r'\1', clean)
            clean = re.sub(r'#+\s*', '', clean)
            clean = clean.strip()
            if clean and len(clean) > 20:
                current_text.append(clean)

    if current_text:
        sections.append((current_title, " ".join(current_text)))

    return sections[:8]  # max 8 sections


def make_section_frame(section_title, section_text, slide_num, total_slides):
    """Create a content slide frame."""
    img = Image.new("RGB", (W, H), SCO_DARK)
    draw_gradient_bg(img, (10, 18, 40), (18, 30, 65))
    draw = ImageDraw.Draw(img)

    # Left red bar
    draw.rectangle([(0, 0), (10, H)], fill=SCO_RED)

    # Top gold bar
    draw.rectangle([(0, 0), (W, 6)], fill=SCO_GOLD)

    # Section number badge
    badge_font = load_font(FONT_BOLD, 28)
    badge_text = f"  {slide_num} / {total_slides}  "
    draw.rectangle([(60, 40), (200, 85)], fill=SCO_RED)
    draw.text((70, 48), badge_text, fill=SCO_WHITE, font=badge_font)

    # SCO logo small
    logo_font = load_font(FONT_BOLD, 30)
    draw.text((W - 420, 50), "SportCardsOnline.com", fill=SCO_GOLD, font=logo_font)

    # Section title
    title_font = load_font(FONT_BOLD, 64)
    title_clean = section_title.replace("'", "'")[:80]
    title_lines = wrap_text(title_clean, title_font, W - 160, draw)[:2]
    y = 120
    for line in title_lines:
        draw.text((80, y), line, fill=SCO_GOLD, font=title_font)
        y += 80

    # Divider
    draw.line([(80, y + 10), (W - 80, y + 10)], fill=SCO_RED, width=3)
    y += 35

    # Section body text
    body_font = load_font(FONT_REG, 40)
    body_clean = section_text.replace("'", "'")
    body_lines = wrap_text(body_clean, body_font, W - 200, draw)
    # Show up to 10 lines
    for line in body_lines[:10]:
        if y > H - 180:
            break
        draw.text((80, y), line, fill=SCO_WHITE, font=body_font)
        y += 55

    # Bottom bar
    draw.rectangle([(0, H - 100), (W, H)], fill=(20, 30, 60))
    cta_font = load_font(FONT_BOLD, 34)
    draw.text((80, H - 70), "🃏 SportCardsOnline.com", fill=SCO_GOLD, font=cta_font)
    draw.text((W - 600, H - 70), "Subscribe for Daily Card News!", fill=SCO_LGRAY, font=cta_font)

    return img


def make_outro_frame(title):
    """Create the outro/CTA frame."""
    img = Image.new("RGB", (W, H), SCO_DARK)
    draw_gradient_bg(img, (15, 10, 5), (40, 15, 5))
    draw = ImageDraw.Draw(img)

    # Gold borders
    draw.rectangle([(0, 0), (W, 10)], fill=SCO_GOLD)
    draw.rectangle([(0, H - 10), (W, H)], fill=SCO_GOLD)
    draw.rectangle([(0, 0), (10, H)], fill=SCO_GOLD)
    draw.rectangle([(W - 10, 0), (W, H)], fill=SCO_GOLD)

    # Main CTA
    big_font = load_font(FONT_BOLD, 90)
    draw.text((W // 2 - 350, 150), "🃏 SUBSCRIBE", fill=SCO_GOLD, font=big_font)

    sub_font = load_font(FONT_BOLD, 52)
    draw.text((W // 2 - 420, 280), "for Daily Sports Card News & Deals!", fill=SCO_WHITE, font=sub_font)

    # Divider
    draw.line([(160, 380), (W - 160, 380)], fill=SCO_RED, width=4)

    # Site URL
    url_font = load_font(FONT_BOLD, 64)
    draw.text((W // 2 - 380, 420), "www.sportcardsonline.com", fill=SCO_GOLD, font=url_font)

    # Features
    feat_font = load_font(FONT_REG, 42)
    features = [
        "✅  Buy & Sell Graded Cards",
        "✅  Professional Card Grading (SCG)",
        "✅  Live Auctions Every Day",
        "✅  Free Card Value Search",
    ]
    y = 530
    for f in features:
        draw.text((W // 2 - 350, y), f, fill=SCO_LGRAY, font=feat_font)
        y += 60

    # Bottom
    draw.rectangle([(0, H - 110), (W, H)], fill=SCO_RED)
    bot_font = load_font(FONT_BOLD, 38)
    draw.text((W // 2 - 380, H - 80), "Like  •  Comment  •  Share  •  Subscribe  🔔", fill=SCO_WHITE, font=bot_font)

    return img


def frames_to_clip(frames_data, duration_each):
    """Convert list of (PIL.Image, duration) to moviepy clips."""
    clips = []
    for img, dur in frames_data:
        arr = np.array(img)
        clip = ImageClip(arr, duration=dur)
        clips.append(clip)
    return clips


def generate_video(title, excerpt, content, output_path, cover_url=None):
    """Main video generation function."""
    # Extract content sections
    sections = extract_sections(content)
    if not sections:
        sections = [("Key Highlights", excerpt[:500])]

    # Build frames list: (PIL.Image, duration_seconds)
    frames_data = []

    # 1. Intro card — 5 seconds
    intro = make_intro_frame(title, excerpt)
    frames_data.append((intro, 5))

    # 2. Content slides — 6 seconds each
    total = len(sections)
    for i, (sec_title, sec_text) in enumerate(sections):
        frame = make_section_frame(sec_title, sec_text, i + 1, total)
        frames_data.append((frame, 6))

    # 3. Outro — 4 seconds
    outro = make_outro_frame(title)
    frames_data.append((outro, 4))

    # Convert to moviepy clips
    clips = frames_to_clip(frames_data, 1)  # placeholder, we set duration above

    # Rebuild with correct durations
    clips = []
    for img, dur in frames_data:
        arr = np.array(img)
        clip = ImageClip(arr, duration=dur).set_fps(FPS)
        clips.append(clip)

    # Concatenate
    final = concatenate_videoclips(clips, method="compose")

    # Write video
    final.write_videofile(
        output_path,
        fps=FPS,
        codec="libx264",
        audio=False,
        preset="fast",
        ffmpeg_params=["-crf", "23"],
        logger=None,
    )

    duration = sum(d for _, d in frames_data)
    size = os.path.getsize(output_path)

    return {
        "success": True,
        "output": output_path,
        "duration_seconds": duration,
        "file_size_bytes": size,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--title", required=True)
    parser.add_argument("--excerpt", default="")
    parser.add_argument("--content", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--cover_url", default=None)
    args = parser.parse_args()

    try:
        result = generate_video(
            title=args.title,
            excerpt=args.excerpt,
            content=args.content,
            output_path=args.output,
            cover_url=args.cover_url,
        )
        print(json.dumps(result))
    except Exception as e:
        import traceback
        print(json.dumps({
            "success": False,
            "error": str(e),
            "traceback": traceback.format_exc()[-500:],
        }))
        sys.exit(1)


if __name__ == "__main__":
    main()
