import mysql from "mysql2/promise";
import { getDb } from "../db";

async function main() {
  // Test 1: Direct mysql2 connection
  console.log("1. Testing direct mysql2 connection...");
  try {
    const conn = await mysql.createConnection(process.env.DATABASE_URL!);
    const [rows] = await conn.execute("SELECT COUNT(*) as cnt FROM cards") as any;
    console.log(`   ✅ Direct mysql2: ${rows[0].cnt} cards in DB`);
    
    const [sourceRows] = await conn.execute(
      "SELECT source, gradeCompany, COUNT(*) as cnt FROM cards GROUP BY source, gradeCompany LIMIT 10"
    ) as any;
    sourceRows.forEach((r: any) => console.log(`   - ${r.source} / ${r.gradeCompany}: ${r.cnt}`));
    await conn.end();
  } catch (e: any) {
    console.log(`   ❌ Direct mysql2 failed: ${e.message}`);
  }

  // Test 2: Drizzle getDb()
  console.log("2. Testing Drizzle getDb()...");
  try {
    const db = await getDb();
    console.log(`   DB result: ${db ? "connected" : "null/undefined"}`);
    if (db) {
      const result = await (db as any).execute("SELECT COUNT(*) as cnt FROM cards");
      console.log(`   Drizzle result:`, JSON.stringify(result).substring(0, 200));
    }
  } catch (e: any) {
    console.log(`   ❌ Drizzle getDb() failed: ${e.message}`);
  }

  // Test 3: eBay token
  console.log("3. Testing eBay API token...");
  try {
    const clientId = process.env.EBAY_CLIENT_ID!;
    const clientSecret = process.env.EBAY_CLIENT_SECRET!;
    const credentials = Buffer.from(`${clientId}:${clientSecret}`).toString("base64");
    const res = await fetch("https://api.ebay.com/identity/v1/oauth2/token", {
      method: "POST",
      headers: {
        "Authorization": `Basic ${credentials}`,
        "Content-Type": "application/x-www-form-urlencoded",
      },
      body: "grant_type=client_credentials&scope=https://api.ebay.com/oauth/api_scope",
    });
    const data = await res.json() as any;
    if (data.access_token) {
      console.log(`   ✅ eBay token obtained (${data.token_type})`);
    } else {
      console.log(`   ❌ eBay token failed: ${JSON.stringify(data)}`);
    }
  } catch (e: any) {
    console.log(`   ❌ eBay API failed: ${e.message}`);
  }

  process.exit(0);
}

main().catch(e => { console.error(e); process.exit(1); });
