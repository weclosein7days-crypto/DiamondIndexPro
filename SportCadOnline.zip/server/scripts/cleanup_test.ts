import mysql from "mysql2/promise";

async function main() {
  const conn = await mysql.createConnection(process.env.DATABASE_URL!);
  const [r] = await conn.execute("DELETE FROM cards WHERE ebayItemId LIKE 'test_%'") as any;
  console.log("Deleted test cards:", r.affectedRows);
  const [total] = await conn.execute("SELECT COUNT(*) as cnt FROM cards") as any;
  console.log("Cards remaining:", total[0].cnt);
  await conn.end();
  process.exit(0);
}
main().catch(e => { console.error(e); process.exit(1); });
