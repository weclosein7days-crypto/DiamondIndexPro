/**
 * Maximum eBay BGS Import — targets 400+ cards
 * - 8 cards per player (up from 3)
 * - All players in roster (not just first 10)
 * - Grade floor: BGS 8.5+
 * - Weighted toward baseball & basketball
 */
import { importEbayDropshipCards } from "../ebayDropship";
import mysql from "mysql2/promise";

async function getCount() {
  const conn = await mysql.createConnection(process.env.DATABASE_URL!);
  const [rows] = await conn.execute("SELECT COUNT(*) as cnt FROM cards") as any;
  conn.end();
  return rows[0].cnt;
}

async function main() {
  const before = await getCount();
  console.log(`📦 Starting max import. Current cards: ${before}`);

  const runs = [
    // High priority — baseball & basketball (most demand)
    { sport: "baseball",    playersPerSport: 80, cardsPerPlayer: 8, maxTotal: 200 },
    { sport: "basketball",  playersPerSport: 80, cardsPerPlayer: 8, maxTotal: 200 },
    // Medium priority
    { sport: "football",    playersPerSport: 60, cardsPerPlayer: 6, maxTotal: 120 },
    { sport: "hockey",      playersPerSport: 40, cardsPerPlayer: 6, maxTotal: 80  },
    { sport: "soccer",      playersPerSport: 40, cardsPerPlayer: 5, maxTotal: 60  },
    { sport: "golf",        playersPerSport: 40, cardsPerPlayer: 5, maxTotal: 60  },
    // Lower priority (2 marketplace slots each)
    { sport: "tennis",      playersPerSport: 30, cardsPerPlayer: 4, maxTotal: 40  },
    // Search-only
    { sport: "mma",         playersPerSport: 40, cardsPerPlayer: 3, maxTotal: 50  },
    { sport: "boxing",      playersPerSport: 40, cardsPerPlayer: 3, maxTotal: 50  },
  ];

  let totalImported = 0;
  let totalSkipped = 0;

  for (const run of runs) {
    console.log(`\n🏃 Importing ${run.sport} — up to ${run.maxTotal} cards...`);
    try {
      const result = await importEbayDropshipCards(run);
      totalImported += result.imported;
      totalSkipped += result.skipped;
      console.log(`  ✅ ${run.sport}: +${result.imported} imported, ${result.skipped} skipped`);
      if (result.errors.length > 0) {
        console.log(`  ⚠️  ${result.errors.length} errors:`, result.errors.slice(0, 3));
      }
    } catch (e: any) {
      console.error(`  ❌ ${run.sport} failed:`, e.message);
    }
    // Pause between sports to avoid rate limiting
    await new Promise(r => setTimeout(r, 1000));
  }

  const after = await getCount();
  console.log(`\n📊 DONE — Total imported: ${totalImported}, Skipped: ${totalSkipped}`);
  console.log(`📈 Cards: ${before} → ${after} (+${after - before})`);
}

main().catch(console.error);
