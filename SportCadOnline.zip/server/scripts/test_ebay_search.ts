import { detectGrade } from "../ebayDropship";

async function getEbayToken(): Promise<string> {
  const clientId = process.env.EBAY_CLIENT_ID!;
  const clientSecret = process.env.EBAY_CLIENT_SECRET!;
  const credentials = Buffer.from(`${clientId}:${clientSecret}`).toString("base64");
  const res = await fetch("https://api.ebay.com/identity/v1/oauth2/token", {
    method: "POST",
    headers: {
      "Authorization": `Basic ${credentials}`,
      "Content-Type": "application/x-www-form-urlencoded",
    },
    body: "grant_type=client_credentials&scope=https://api.ebay.com/oauth/api_scope",
  });
  const data = await res.json() as any;
  if (!data.access_token) throw new Error(`eBay OAuth failed: ${JSON.stringify(data)}`);
  return data.access_token;
}

async function searchEbayCards(token: string, playerName: string, limit: number, gradeKeyword: string) {
  const params = new URLSearchParams({
    q: `${playerName} ${gradeKeyword} sports card`,
    category_ids: "212",
    limit: String(limit),
    sort: "newlyListed",
    filter: "buyingOptions:{FIXED_PRICE}",
  });
  const url = `https://api.ebay.com/buy/browse/v1/item_summary/search?${params}`;
  console.log("Searching:", url.substring(0, 120));
  const res = await fetch(url, {
    headers: {
      "Authorization": `Bearer ${token}`,
      "X-EBAY-C-MARKETPLACE-ID": "EBAY_US",
    },
  });
  console.log("Status:", res.status);
  if (!res.ok) {
    const text = await res.text();
    console.log("Error body:", text.substring(0, 300));
    return [];
  }
  const data = await res.json() as any;
  console.log("Total results:", data.total, "| Items returned:", data.itemSummaries?.length || 0);
  return data.itemSummaries || [];
}

async function main() {
  const token = await getEbayToken();
  console.log("✅ Token obtained\n");

  // Test 1: BGS search
  console.log("=== Test 1: LeBron James BGS ===");
  const items1 = await searchEbayCards(token, "LeBron James", 5, "BGS");
  items1.slice(0, 3).forEach((item: any) => {
    const grade = detectGrade(item.title);
    console.log(`  - $${item.price?.value} | ${grade ? `${grade.company} ${grade.score}` : "no grade"} | ${item.title.substring(0, 60)}`);
  });

  // Test 2: PSA search
  console.log("\n=== Test 2: Mike Trout PSA ===");
  const items2 = await searchEbayCards(token, "Mike Trout", 5, "PSA");
  items2.slice(0, 3).forEach((item: any) => {
    const grade = detectGrade(item.title);
    console.log(`  - $${item.price?.value} | ${grade ? `${grade.company} ${grade.score}` : "no grade"} | ${item.title.substring(0, 60)}`);
  });

  process.exit(0);
}

main().catch(e => { console.error(e); process.exit(1); });
