/**
 * Large-scale eBay BGS import script
 * Targets 200-500 BGS 9+ cards across all sports
 * Run: npx tsx server/scripts/large_ebay_import.ts
 */

import { importEbayDropshipCards } from "../ebayDropship";
import { getDb } from "../db";
import { cards } from "../../drizzle/schema";
import { count } from "drizzle-orm";

async function main() {
  console.log("🚀 Starting large-scale eBay BGS import...");
  console.log(`Started at: ${new Date().toISOString()}`);

  const db = await getDb();
  if (!db) { console.error("DB unavailable"); process.exit(1); }

  // Count current cards
  const [before] = await db.select({ count: count() }).from(cards);
  console.log(`📊 Cards before import: ${before.count}`);

  const result = await importEbayDropshipCards({
    playersPerSport: 25,   // 25 players per sport (vs 10 before)
    cardsPerPlayer: 4,     // 4 cards per player (vs 3 before)
    maxTotal: 500,         // cap at 500
  });

  const [after] = await db.select({ count: count() }).from(cards);

  console.log("\n✅ Import complete!");
  console.log(`📦 Imported: ${result.imported} new cards`);
  console.log(`⏭️  Skipped: ${result.skipped} (duplicates, wrong grade, price out of range)`);
  console.log(`❌ Errors: ${result.errors.length}`);
  console.log(`📊 Cards after import: ${after.count}`);
  console.log(`📈 Net new cards: ${Number(after.count) - Number(before.count)}`);

  if (result.errors.length > 0) {
    console.log("\nFirst 10 errors:");
    result.errors.slice(0, 10).forEach(e => console.log(`  - ${e}`));
  }

  process.exit(0);
}

main().catch(e => { console.error(e); process.exit(1); });
