/**
 * bulk_upload_youtube.ts
 * Run with: npx tsx server/scripts/bulk_upload_youtube.ts
 * 
 * Directly generates videos for all blog posts without videos,
 * then uploads them to YouTube with auto-generated tags.
 */

import { getDb } from "../db";
import { blogPosts } from "../../drizzle/schema";
import { eq, isNull, or } from "drizzle-orm";
import { generateBlogVideo } from "../videoEngine";
import { uploadToYouTube, isYouTubeConfigured } from "../youtubeService";
import { generateVideoAutoTags } from "../youtubeAutoTagger";
import { updateBlogPost } from "../blogEngine";
import https from "https";
import http from "http";
import fs from "fs";
import { unlink } from "fs/promises";
import os from "os";
import path from "path";

async function sleep(ms: number) {
  return new Promise((r) => setTimeout(r, ms));
}

async function downloadToTemp(url: string, tmpPath: string): Promise<void> {
  return new Promise((resolve, reject) => {
    const fileStream = fs.createWriteStream(tmpPath);
    const protocol = url.startsWith("https") ? https : http;
    (protocol as any).get(url, (res: any) => {
      res.pipe(fileStream);
      fileStream.on("finish", () => { fileStream.close(); resolve(); });
    }).on("error", reject);
  });
}

async function main() {
  console.log("=== Bulk Video Generation & YouTube Upload ===\n");

  if (!isYouTubeConfigured()) {
    console.error("❌ YouTube credentials not configured. Set YOUTUBE_CLIENT_ID, YOUTUBE_CLIENT_SECRET, YOUTUBE_REFRESH_TOKEN.");
    process.exit(1);
  }

  const db = await getDb();
  if (!db) {
    console.error("❌ Database unavailable");
    process.exit(1);
  }

  // Get all blog posts
  const allPosts = await db.select().from(blogPosts).orderBy(blogPosts.id);
  console.log(`Found ${allPosts.length} total blog posts`);

  const needsVideo = allPosts.filter(p => !p.videoUrl);
  const hasVideoNoYT = allPosts.filter(p => p.videoUrl && !p.youtubeVideoId);
  const alreadyUploaded = allPosts.filter(p => p.youtubeVideoId);

  console.log(`  - Needs video generation: ${needsVideo.length}`);
  console.log(`  - Has video, needs YouTube: ${hasVideoNoYT.length}`);
  console.log(`  - Already on YouTube: ${alreadyUploaded.length}`);

  if (alreadyUploaded.length > 0) {
    console.log("\nAlready uploaded:");
    for (const p of alreadyUploaded) {
      console.log(`  ✅ [${p.id}] ${p.title.slice(0, 60)} -> https://youtube.com/watch?v=${p.youtubeVideoId}`);
    }
  }

  const toUpload: typeof allPosts = [];

  // Step 1: Generate videos for posts that don't have them
  if (needsVideo.length > 0) {
    console.log(`\n=== Generating ${needsVideo.length} videos ===`);
    for (const post of needsVideo) {
      console.log(`\n[${post.id}] Generating video: "${post.title.slice(0, 60)}"`);
      try {
        await updateBlogPost(post.id, { videoStatus: "generating" });
        const result = await generateBlogVideo({
          postId: post.id,
          title: post.title,
          excerpt: post.excerpt ?? "",
          content: post.content,
          coverImageUrl: post.coverImageUrl,
          slug: post.slug,
        });
        await updateBlogPost(post.id, { videoStatus: "ready", videoUrl: result.s3Url });
        console.log(`  ✅ Video ready: ${result.s3Url.slice(0, 80)}`);
        console.log(`     Duration: ${result.durationSeconds}s, Size: ${(result.fileSizeBytes / 1024 / 1024).toFixed(1)}MB`);
        // Re-fetch post with updated videoUrl
        const [updated] = await db.select().from(blogPosts).where(eq(blogPosts.id, post.id)).limit(1);
        if (updated) toUpload.push(updated);
      } catch (e) {
        const msg = (e as Error).message;
        console.error(`  ❌ Video generation failed: ${msg.slice(0, 150)}`);
        await updateBlogPost(post.id, { videoStatus: "error", videoErrorMsg: msg });
      }
      await sleep(1000);
    }
  }

  // Add posts that already had videos but no YouTube ID
  toUpload.push(...hasVideoNoYT);

  // Step 2: Upload to YouTube
  // YouTube quota: 10,000 units/day, each upload = 1,600 units → max 6 per day
  const MAX_UPLOADS_PER_RUN = 6;
  const uploadBatch = toUpload.slice(0, MAX_UPLOADS_PER_RUN);
  if (uploadBatch.length < toUpload.length) {
    console.log(`\n⚠️  Quota limit: uploading ${uploadBatch.length} of ${toUpload.length} videos today. Remaining ${toUpload.length - uploadBatch.length} will upload tomorrow.`);
  }

  if (uploadBatch.length === 0) {
    console.log("\n✅ No videos to upload to YouTube.");
    return;
  }

  console.log(`\n=== Uploading ${uploadBatch.length} videos to YouTube ===`);
  const uploaded: string[] = [];
  const failed: string[] = [];

  for (const post of uploadBatch) {
    console.log(`\n[${post.id}] Uploading: "${post.title.slice(0, 60)}"`);
    if (!post.videoUrl) {
      console.log(`  ⏭ Skipping — no video URL`);
      continue;
    }

    const tmpPath = path.join(os.tmpdir(), `yt-bulk-${post.id}-${Date.now()}.mp4`);
    try {
      // Download video from S3
      console.log(`  Downloading video...`);
      await downloadToTemp(post.videoUrl, tmpPath);
      const sizeMB = (fs.statSync(tmpPath).size / 1024 / 1024).toFixed(1);
      console.log(`  Downloaded: ${sizeMB}MB`);

      // Generate auto-tags
      console.log(`  Generating YouTube tags...`);
      const autoTagResult = await generateVideoAutoTags({
        title: post.title,
        excerpt: post.excerpt ?? "",
        sport: post.sport ?? "other",
        existingTags: post.tags ? JSON.parse(post.tags) : [],
      });

      const siteUrl = "https://www.sportcardsonline.com";
      const enrichedDescription =
        (post.excerpt ?? post.title) +
        `\n\n🃏 Browse & Buy Sports Cards: ${siteUrl}` +
        `\n📊 Free Card Valuations: ${siteUrl}/marketplace` +
        `\n⭐ Professional Card Grading: ${siteUrl}/grading` +
        `\n📖 Read the full article: ${siteUrl}/blog/${post.slug}` +
        autoTagResult.authoritativeLinksBlock +
        `\n\n${autoTagResult.hashtagString}`;

      // Upload to YouTube
      console.log(`  Uploading to YouTube (${autoTagResult.finalTags.length} tags)...`);
      const ytResult = await uploadToYouTube({
        videoPath: tmpPath,
        title: post.title,
        description: enrichedDescription,
        excerpt: post.excerpt ?? "",
        slug: post.slug,
        tags: autoTagResult.finalTags,
        thumbnailUrl: post.coverImageUrl ?? undefined,
      });

      // Save to DB
      await updateBlogPost(post.id, {
        youtubeVideoId: ytResult.videoId,
        youtubeUrl: ytResult.videoUrl,
        videoStatus: "published",
        youtubeAutoTags: autoTagResult.youtubeAutoTags,
        youtubeAutoLinks: autoTagResult.youtubeAutoLinks,
      });

      console.log(`  ✅ Uploaded: ${ytResult.videoUrl}`);
      console.log(`     Tags: ${autoTagResult.finalTags.slice(0, 5).join(", ")}...`);
      uploaded.push(`[${post.id}] ${post.title.slice(0, 50)} -> ${ytResult.videoUrl}`);

    } catch (e) {
      const msg = (e as Error).message;
      console.error(`  ❌ Failed: ${msg.slice(0, 200)}`);
      failed.push(`[${post.id}] ${post.title.slice(0, 50)}: ${msg.slice(0, 100)}`);
    } finally {
      try { await unlink(tmpPath); } catch { /* ignore */ }
    }

    // Pause between uploads to respect YouTube quota
    if (uploadBatch.indexOf(post) < uploadBatch.length - 1) {
      console.log(`  Pausing 5s before next upload...`);
      await sleep(5000);
    }
  }

  // Final summary
  console.log("\n=== FINAL SUMMARY ===");
  console.log(`✅ Successfully uploaded to YouTube: ${uploaded.length}`);
  for (const u of uploaded) console.log(`   ${u}`);
  if (failed.length > 0) {
    console.log(`❌ Failed: ${failed.length}`);
    for (const f of failed) console.log(`   ${f}`);
  }
  console.log("\nDone!");
}

main().catch((e) => {
  console.error("Fatal error:", e);
  process.exit(1);
});
