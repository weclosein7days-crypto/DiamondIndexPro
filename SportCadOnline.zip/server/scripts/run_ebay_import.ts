/**
 * One-shot eBay BGS import script
 * Run with: npx tsx server/scripts/run_ebay_import.ts
 */
import { importEbayDropshipCards } from "../ebayDropship";

async function main() {
  console.log("=== eBay BGS Import (Beckett 9+ only) ===");
  console.log("Starting import...\n");

  const result = await importEbayDropshipCards({
    playersPerSport: 10,
    cardsPerPlayer: 3,
    maxTotal: 300,
  });

  console.log("\n=== Import Complete ===");
  console.log(`Imported: ${result.imported}`);
  console.log(`Skipped:  ${result.skipped}`);
  if (result.errors.length > 0) {
    console.log(`Errors:   ${result.errors.length}`);
    result.errors.slice(0, 5).forEach(e => console.log("  -", e));
  }
}

main().catch(e => {
  console.error("Import failed:", e.message);
  process.exit(1);
});
