/**
 * Balanced 50/50 PSA + BGS Import Script
 * 
 * - Checks current BGS vs PSA counts per sport
 * - If PSA is behind BGS: runs PSA-only catch-up import
 * - Once balanced: imports equal amounts of PSA and BGS
 * - Maintains same sport percentage mix for both grading companies
 * - BGS grade floor: 8.0+, PSA grade floor: 8+
 * - Markup: 20% on source price
 */

import { importEbayDropshipCards } from "../ebayDropship";
import mysql from "mysql2/promise";

async function getConn() {
  return mysql.createConnection(process.env.DATABASE_URL!);
}

async function getInventoryCounts() {
  const conn = await getConn();
  const [rows] = await conn.execute(
    `SELECT gradeCompany, sport, COUNT(*) as cnt 
     FROM cards 
     WHERE source = 'ebay_import' AND gradeCompany IN ('Beckett', 'PSA')
     GROUP BY gradeCompany, sport`
  ) as any;
  await conn.end();

  const bgsTotal: Record<string, number> = {};
  const psaTotal: Record<string, number> = {};
  let totalBGS = 0;
  let totalPSA = 0;

  for (const row of rows) {
    if (row.gradeCompany === "Beckett") {
      bgsTotal[row.sport] = Number(row.cnt);
      totalBGS += Number(row.cnt);
    } else if (row.gradeCompany === "PSA") {
      psaTotal[row.sport] = Number(row.cnt);
      totalPSA += Number(row.cnt);
    }
  }

  return { bgsTotal, psaTotal, totalBGS, totalPSA };
}

async function getTotalCards() {
  const conn = await getConn();
  const [rows] = await conn.execute("SELECT COUNT(*) as total FROM cards") as any;
  await conn.end();
  return rows[0].total;
}

async function main() {
  const { bgsTotal, psaTotal, totalBGS, totalPSA } = await getInventoryCounts();
  const totalBefore = await getTotalCards();

  console.log(`\n📊 Current inventory: BGS=${totalBGS}, PSA=${totalPSA}, Total=${totalBefore}`);
  console.log(`📋 BGS by sport:`, bgsTotal);
  console.log(`📋 PSA by sport:`, psaTotal);

  const psaDeficit = totalBGS - totalPSA;

  if (psaDeficit > 0) {
    // PSA catch-up: import PSA cards per sport proportional to the deficit
    console.log(`\n🔄 PSA needs ${psaDeficit} more cards to reach 50/50 balance`);
    console.log(`   Running PSA-only import across all sports...\n`);

    // Run PSA import for each sport based on deficit
    const sportDeficits: Record<string, number> = {};
    const allSports = ["basketball", "baseball", "football", "hockey", "soccer", "golf"];
    for (const sport of allSports) {
      const deficit = (bgsTotal[sport] || 0) - (psaTotal[sport] || 0);
      if (deficit > 0) sportDeficits[sport] = deficit;
    }

    for (const [sport, deficit] of Object.entries(sportDeficits)) {
      if (deficit <= 0) continue;
      const cardsPerPlayer = Math.min(8, Math.ceil(deficit / 10));
      const playersNeeded = Math.ceil(deficit / cardsPerPlayer);
      console.log(`  🏃 PSA ${sport}: targeting +${deficit} cards (${playersNeeded} players × ${cardsPerPlayer} cards)`);

      const result = await importEbayDropshipCards({
        sport,
        playersPerSport: Math.min(playersNeeded + 5, 80),
        cardsPerPlayer,
        maxTotal: deficit + 10,
        gradeCompanyFilter: "PSA",
        gradeFloor: 8,
      } as any);

      console.log(`  ✅ PSA ${sport}: +${result.imported} imported, ${result.skipped} skipped`);
    }

  } else {
    // Balanced: import equal BGS and PSA per sport
    console.log(`\n✅ BGS and PSA are balanced. Running equal import for both...\n`);

    const sportTargets = [
      { sport: "basketball", target: 30 },
      { sport: "baseball",   target: 26 },
      { sport: "football",   target: 19 },
      { sport: "hockey",     target: 6  },
      { sport: "soccer",     target: 5  },
      { sport: "golf",       target: 5  },
    ];

    for (const { sport, target } of sportTargets) {
      const half = Math.ceil(target / 2);

      // BGS
      const bgsResult = await importEbayDropshipCards({
        sport,
        playersPerSport: 40,
        cardsPerPlayer: 4,
        maxTotal: half,
        gradeCompanyFilter: "Beckett",
        gradeFloor: 8,
      } as any);
      console.log(`  BGS ${sport}: +${bgsResult.imported}`);

      // PSA
      const psaResult = await importEbayDropshipCards({
        sport,
        playersPerSport: 40,
        cardsPerPlayer: 4,
        maxTotal: half,
        gradeCompanyFilter: "PSA",
        gradeFloor: 8,
      } as any);
      console.log(`  PSA ${sport}: +${psaResult.imported}`);
    }
  }

  // Final counts
  const { totalBGS: finalBGS, totalPSA: finalPSA } = await getInventoryCounts();
  const totalAfter = await getTotalCards();

  console.log(`\n📈 Final inventory:`);
  console.log(`  BGS: ${finalBGS}`);
  console.log(`  PSA: ${finalPSA}`);
  console.log(`  TOTAL: ${totalAfter} (was ${totalBefore}, +${totalAfter - totalBefore})`);

  process.exit(0);
}

main().catch(e => { console.error(e); process.exit(1); });
