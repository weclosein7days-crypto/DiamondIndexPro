/**
 * Direct test of the YouTube upload pipeline.
 * Run: npx tsx server/scripts/test_yt_upload.ts
 */
import { getDb } from "../db";
import { blogPosts } from "../../drizzle/schema";
import { eq } from "drizzle-orm";
import { uploadToYouTube, isYouTubeConfigured } from "../youtubeService";
import { generateVideoAutoTags } from "../youtubeAutoTagger";
import { updateBlogPost } from "../blogEngine";
import https from "https";
import http from "http";
import fs from "fs/promises";
import { createWriteStream } from "fs";
import os from "os";
import path from "path";

async function main() {
  if (!isYouTubeConfigured()) {
    console.error("❌ YouTube credentials not configured");
    process.exit(1);
  }
  console.log("✅ YouTube credentials found");

  const db = await getDb();
  if (!db) { console.error("DB unavailable"); process.exit(1); }

  const [post] = await db.select().from(blogPosts).where(eq(blogPosts.id, 1)).limit(1);
  if (!post) { console.error("Post ID:1 not found"); process.exit(1); }
  if (!post.videoUrl) { console.error("No videoUrl on post ID:1"); process.exit(1); }

  console.log(`📝 Post: "${post.title}"`);
  console.log(`🎬 Video URL: ${post.videoUrl}`);

  // Download video to temp file
  const tmpPath = path.join(os.tmpdir(), `yt-test-${Date.now()}.mp4`);
  console.log(`⬇️  Downloading video to ${tmpPath}...`);
  
  await new Promise<void>((resolve, reject) => {
    const fileStream = createWriteStream(tmpPath);
    const protocol = post.videoUrl!.startsWith("https") ? https : http;
    (protocol as any).get(post.videoUrl!, (res: any) => {
      res.pipe(fileStream);
      fileStream.on("finish", () => { fileStream.close(); resolve(); });
    }).on("error", reject);
  });

  const stat = await fs.stat(tmpPath);
  console.log(`✅ Downloaded: ${(stat.size / 1024 / 1024).toFixed(2)} MB`);

  // Generate auto-tags
  console.log("🤖 Generating YouTube tags...");
  const autoTagResult = await generateVideoAutoTags({
    title: post.title,
    excerpt: post.excerpt ?? "",
    sport: post.sport ?? "other",
    existingTags: post.tags ? JSON.parse(post.tags) : [],
  });
  console.log(`🏷️  Tags (${autoTagResult.finalTags.length}):`, autoTagResult.finalTags.slice(0, 5).join(", "), "...");

  // Upload to YouTube
  console.log("🚀 Uploading to YouTube...");
  const ytResult = await uploadToYouTube({
    videoPath: tmpPath,
    title: post.title,
    description: (post.excerpt ?? post.title) + "\n\n🃏 Browse & Buy Sports Cards: https://www.sportcardsonline.com",
    excerpt: post.excerpt ?? "",
    slug: post.slug,
    tags: autoTagResult.finalTags,
    thumbnailUrl: post.coverImageUrl ?? undefined,
  });

  console.log(`\n✅ SUCCESS!`);
  console.log(`   Video ID: ${ytResult.videoId}`);
  console.log(`   YouTube URL: ${ytResult.videoUrl}`);

  // Save back to DB
  await updateBlogPost(1, {
    youtubeVideoId: ytResult.videoId,
    youtubeUrl: ytResult.videoUrl,
    videoStatus: "published",
    youtubeAutoTags: autoTagResult.youtubeAutoTags,
    youtubeAutoLinks: autoTagResult.youtubeAutoLinks,
  });
  console.log("💾 Saved to database");

  // Cleanup
  await fs.unlink(tmpPath).catch(() => {});
  process.exit(0);
}

main().catch(e => { console.error("❌ Error:", e.message); process.exit(1); });
