import { getDb } from "../db";
import { sql } from "drizzle-orm";

async function main() {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  const [rows] = await db.execute(sql`SELECT source, gradeCompany, COUNT(*) as cnt FROM cards GROUP BY source, gradeCompany ORDER BY cnt DESC LIMIT 20`) as any;
  rows.forEach((r: any) => console.log(JSON.stringify(r)));
  process.exit(0);
}
main().catch(e => { console.error(e); process.exit(1); });
