/**
 * shippingReminderJobs.ts
 *
 * Background job that runs every hour and sends a reminder email to sellers
 * who have NOT entered a tracking number and whose shipByDeadline is within
 * the next 24 hours.
 *
 * Logic:
 *  - Find orders where:
 *      status IN ('paid', 'label_created')  — sold but not yet shipped
 *      trackingNumber IS NULL               — no tracking entered
 *      shipReminderSentAt IS NULL           — reminder not already sent
 *      shipByDeadline IS NOT NULL           — deadline was set at purchase
 *      shipByDeadline BETWEEN NOW() AND NOW() + 24h
 *  - For each such order, send the shippingReminder email to the seller
 *  - Mark shipReminderSentAt = NOW() so we never send twice
 */

import mysql from "mysql2/promise";
import { sendEmail, emailTemplates } from "./email";
import { notifyOwner } from "./_core/notification";

const DB_URL = process.env.DATABASE_URL;

async function getConnection() {
  if (!DB_URL) return null;
  try {
    return await mysql.createConnection(DB_URL);
  } catch (e) {
    console.warn("[ShippingReminder] DB connect failed:", (e as Error).message);
    return null;
  }
}

export async function processShippingReminders(): Promise<void> {
  const conn = await getConnection();
  if (!conn) return;

  try {
    const now = new Date();
    const in24h = new Date(now.getTime() + 24 * 60 * 60 * 1000);

    // Find all orders needing a reminder
    const [rows] = await conn.execute<mysql.RowDataPacket[]>(
      `SELECT id, ticketNumber, cardTitle, buyerName, sellerEmail, sellerStoreName, shipByDeadline
       FROM orders
       WHERE status IN ('paid', 'label_created')
         AND trackingNumber IS NULL
         AND shipReminderSentAt IS NULL
         AND shipByDeadline IS NOT NULL
         AND shipByDeadline > ?
         AND shipByDeadline <= ?`,
      [now, in24h]
    );

    if (rows.length === 0) {
      console.log("[ShippingReminder] No orders need a reminder at this time.");
      return;
    }

    console.log(`[ShippingReminder] Found ${rows.length} order(s) needing a 24h reminder.`);

    const templates = emailTemplates();
    const appUrl = process.env.VITE_APP_URL || "https://sportcardsonline.com";

    for (const order of rows) {
      const sellerEmail = order.sellerEmail as string;
      const sellerName = (order.sellerStoreName as string) || "Seller";
      const orderId = (order.ticketNumber as string) || String(order.id);
      const cardTitle = (order.cardTitle as string) || "Your card";
      const buyerName = (order.buyerName as string) || "the buyer";
      const shipByDeadline = new Date(order.shipByDeadline as string);
      const myListingsUrl = `${appUrl}/my-listings`;

      // Send reminder email
      const tmpl = templates.shippingReminder(sellerName, {
        orderId,
        cardTitle,
        buyerName,
        shipByDeadline,
        myListingsUrl,
      });

      const sent = await sendEmail({ to: sellerEmail, ...tmpl });

      if (sent) {
        // Mark reminder as sent so we don't send again
        await conn.execute(
          `UPDATE orders SET shipReminderSentAt = ? WHERE id = ?`,
          [new Date(), order.id]
        );
        console.log(`[ShippingReminder] Reminder sent for order #${orderId} to ${sellerEmail}`);
      } else {
        console.warn(`[ShippingReminder] Failed to send reminder for order #${orderId} to ${sellerEmail}`);
      }
    }

    // Notify owner if any reminders were sent
    if (rows.length > 0) {
      await notifyOwner({
        title: `Shipping Reminders Sent (${rows.length})`,
        content: `${rows.length} seller(s) were reminded to ship their cards within 24 hours:\n${rows
          .map((o) => `• Order #${o.ticketNumber || o.id}: "${o.cardTitle}" → ${o.sellerEmail}`)
          .join("\n")}`,
      }).catch(() => {});
    }
  } catch (err) {
    console.error("[ShippingReminder] Error processing reminders:", (err as Error).message);
  } finally {
    await conn.end();
  }
}

/**
 * Start the hourly shipping reminder job.
 * Runs immediately on startup, then every hour.
 */
export function startShippingReminderJobs(): void {
  const INTERVAL_MS = 60 * 60 * 1000; // 1 hour

  // Run once immediately (catches any orders that were missed during downtime)
  processShippingReminders().catch(console.error);

  // Then run every hour
  setInterval(() => {
    processShippingReminders().catch(console.error);
  }, INTERVAL_MS);

  console.log("[ShippingReminder] Shipping reminder job started — runs every hour.");
}
