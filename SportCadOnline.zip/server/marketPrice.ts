/**
 * marketPrice.ts
 * Fetches average sold prices from eBay Browse API, SportsCardsPro, and Beckett,
 * then applies SCO's grade-based multiplier to produce a suggested price.
 *
 * Multipliers:
 *   Raw / Ungraded  -> 120% of market avg
 *   Graded 1-9      -> 90% of market avg
 *   Graded 10       -> 80% of market avg
 */

export interface MarketPriceResult {
  suggestedPrice: number | null;
  marketAvg: number | null;
  sources: {
    ebay: number | null;
    scp: number | null;
    beckett: number | null;
  };
  multiplier: number;
  gradeCategory: "raw" | "graded_10" | "graded_1_9";
  error?: string;
}

function gradeCategory(grade: number | null): "raw" | "graded_10" | "graded_1_9" {
  if (grade === null || grade === undefined) return "raw";
  if (grade >= 10) return "graded_10";
  return "graded_1_9";
}

function getMultiplier(cat: "raw" | "graded_10" | "graded_1_9"): number {
  if (cat === "raw") return 1.20;
  if (cat === "graded_10") return 0.80;
  return 0.90;
}

// eBay OAuth token cache (module-level, shared across calls)
let _ebayTokenCache: { token: string; expiresAt: number } | null = null;

async function getEbayOAuthToken(): Promise<string | null> {
  if (_ebayTokenCache && Date.now() < _ebayTokenCache.expiresAt - 60000) {
    return _ebayTokenCache.token;
  }
  const clientId = process.env.EBAY_CLIENT_ID;
  const clientSecret = process.env.EBAY_CLIENT_SECRET;
  if (!clientId || !clientSecret) return null;
  try {
    const creds = Buffer.from(`${clientId}:${clientSecret}`).toString("base64");
    const res = await fetch("https://api.ebay.com/identity/v1/oauth2/token", {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
        Authorization: `Basic ${creds}`,
      },
      body: "grant_type=client_credentials&scope=https%3A%2F%2Fapi.ebay.com%2Foauth%2Fapi_scope",
    });
    if (!res.ok) return null;
    const data = await res.json() as { access_token: string; expires_in: number };
    _ebayTokenCache = { token: data.access_token, expiresAt: Date.now() + data.expires_in * 1000 };
    return data.access_token;
  } catch {
    return null;
  }
}

async function fetchEbayAvg(query: string, grade?: number | null): Promise<number | null> {
  try {
    const token = await getEbayOAuthToken();
    if (!token) return null;
    // Append grade label to query for better matching
    let gradeLabel = "";
    if (grade !== null && grade !== undefined) {
      if (grade >= 10) gradeLabel = " BGS 10";
      else if (grade >= 9.5) gradeLabel = " BGS 9.5";
      else if (grade >= 9) gradeLabel = " BGS 9";
      else if (grade >= 8.5) gradeLabel = " BGS 8.5";
      else if (grade >= 8) gradeLabel = " BGS 8";
    }
    const q = encodeURIComponent(query + gradeLabel);
    // Browse API v1 — use buyingOptions:FIXED_PRICE (confirmed working)
    const url = `https://api.ebay.com/buy/browse/v1/item_summary/search?q=${q}&filter=buyingOptions%3A%7BFIXED_PRICE%7D&limit=10&sort=price`;
    const res = await fetch(url, {
      headers: {
        Authorization: `Bearer ${token}`,
        "X-EBAY-C-MARKETPLACE-ID": "EBAY_US",
      },
      signal: AbortSignal.timeout(8000),
    });
    if (!res.ok) return null;
    const data = await res.json() as { itemSummaries?: Array<{ price?: { value: string } }> };
    const items = data.itemSummaries || [];
    const prices = items
      .map((item) => parseFloat(item.price?.value || "0"))
      .filter((p) => p > 0 && p < 50000);
    if (prices.length === 0) return null;
    return prices.reduce((a, b) => a + b, 0) / prices.length;
  } catch {
    return null;
  }
}

async function fetchScpAvg(query: string, grade: number | null): Promise<number | null> {
  try {
    const token = process.env.SPORTSCARDSPRO_API_TOKEN || "c0b53bce27c1bdab90b1605249e600dc43dfd1d5";
    const searchRes = await fetch(
      `https://www.sportscardspro.com/api/products?t=${token}&q=${encodeURIComponent(query)}`
    );
    if (!searchRes.ok) return null;
    const searchData = await searchRes.json() as { status: string; products?: Array<{ id: string }> };
    if (searchData.status !== "success" || !searchData.products?.length) return null;
    const priceRes = await fetch(
      `https://www.sportscardspro.com/api/product?t=${token}&id=${encodeURIComponent(searchData.products[0].id)}`
    );
    if (!priceRes.ok) return null;
    const d = await priceRes.json() as Record<string, string | number>;
    if (d.status !== "success") return null;
    const cents = (v: unknown): number | null => typeof v === "number" && v > 0 ? v / 100 : null;
    let price: number | null = null;
    if (grade === null) {
      price = cents(d["loose-price"]) ?? cents(d["new-price"]);
    } else if (grade >= 10) {
      price = cents(d["manual-only-price"]) ?? cents(d["graded-price"]);
    } else if (grade >= 9) {
      price = cents(d["graded-price"]) ?? cents(d["new-price"]);
    } else if (grade >= 8) {
      price = cents(d["new-price"]) ?? cents(d["cib-price"]);
    } else if (grade >= 7) {
      price = cents(d["cib-price"]) ?? cents(d["loose-price"]);
    } else {
      price = cents(d["loose-price"]);
    }
    return price;
  } catch {
    return null;
  }
}

async function fetchBeckettAvg(query: string): Promise<number | null> {
  try {
    const encoded = encodeURIComponent(query);
    const res = await fetch(
      `https://www.beckett.com/price-guide/search?q=${encoded}&category=sports-cards`,
      {
        headers: {
          "User-Agent": "Mozilla/5.0 (compatible; SCO-PriceBot/1.0)",
          Accept: "text/html",
        },
        signal: AbortSignal.timeout(8000),
      }
    );
    if (!res.ok) return null;
    const html = await res.text();
    const priceMatches = html.match(/\$\s*(\d+(?:\.\d{1,2})?)/g);
    if (!priceMatches || priceMatches.length === 0) return null;
    const prices = priceMatches
      .map((p: string) => parseFloat(p.replace("$", "").trim()))
      .filter((p: number) => p > 0 && p < 50000);
    if (prices.length === 0) return null;
    const sorted = prices.slice(0, 6).sort((a: number, b: number) => a - b);
    const mid = Math.floor(sorted.length / 2);
    return sorted.length % 2 !== 0 ? sorted[mid] : (sorted[mid - 1] + sorted[mid]) / 2;
  } catch {
    return null;
  }
}

/**
 * Fetch market price for a card and return a suggested SCO price.
 * @param query  Search string: "Player Year Set" e.g. "Caitlin Clark 2024 Panini Prizm"
 * @param grade  Numeric grade (0-10), or null for raw/ungraded
 */
export async function getMarketPrice(query: string, grade: number | null): Promise<MarketPriceResult> {
  const [ebay, scp, beckett] = await Promise.allSettled([
    fetchEbayAvg(query, grade),
    fetchScpAvg(query, grade),
    fetchBeckettAvg(query),
  ]);

  const ebayPrice = ebay.status === "fulfilled" ? ebay.value : null;
  const scpPrice = scp.status === "fulfilled" ? scp.value : null;
  const beckettPrice = beckett.status === "fulfilled" ? beckett.value : null;

  const validPrices = [ebayPrice, scpPrice, beckettPrice].filter(
    (p): p is number => p !== null && p > 0
  );

  if (validPrices.length === 0) {
    return {
      suggestedPrice: null,
      marketAvg: null,
      sources: { ebay: ebayPrice, scp: scpPrice, beckett: beckettPrice },
      multiplier: getMultiplier(gradeCategory(grade)),
      gradeCategory: gradeCategory(grade),
      error: "No market data found for this card",
    };
  }

  const marketAvg = validPrices.reduce((a, b) => a + b, 0) / validPrices.length;
  const cat = gradeCategory(grade);
  const multiplier = getMultiplier(cat);
  const suggestedPrice = parseFloat((marketAvg * multiplier).toFixed(2));

  return {
    suggestedPrice,
    marketAvg: parseFloat(marketAvg.toFixed(2)),
    sources: { ebay: ebayPrice, scp: scpPrice, beckett: beckettPrice },
    multiplier,
    gradeCategory: cat,
  };
}
