/**
 * Seed script: 100 age-graded, sports-themed educational trivia questions
 * Subjects: math, reading, science, history, sports_facts
 * Age bands: 6-7, 8-9, 10-11, 12-13
 * Run: npx tsx server/seedTrivia.ts
 */

import { getDb } from "./db";
import { kidsTriviaQuestions } from "../drizzle/schema";

interface SeedQuestion {
  question: string;
  correctAnswer: string;
  choiceA: string;
  choiceB: string;
  choiceC: string;
  choiceD: string;
  sport: string;
  difficulty: "easy" | "medium" | "hard";
  ageMin: number;
  ageMax: number;
  subject: string;
  category: "player_fact" | "record" | "history" | "card_value" | "trade_scenario" | "president_era";
  creditsReward: number;
  funFact: string;
}

const questions: SeedQuestion[] = [
  // =========================================================================
  // AGE 6-7 — MATH (easy)
  // =========================================================================
  {
    question: "A basketball team scored 5 points in the first half and 3 points in the second half. How many points did they score in total?",
    correctAnswer: "8",
    choiceA: "8", choiceB: "7", choiceC: "9", choiceD: "6",
    sport: "basketball", difficulty: "easy", ageMin: 6, ageMax: 7, subject: "math",
    category: "player_fact", creditsReward: 5,
    funFact: "Adding numbers together is called addition. 5 + 3 = 8!"
  },
  {
    question: "A baseball player hit 4 home runs on Monday and 2 home runs on Tuesday. How many home runs did he hit altogether?",
    correctAnswer: "6",
    choiceA: "5", choiceB: "6", choiceC: "7", choiceD: "8",
    sport: "baseball", difficulty: "easy", ageMin: 6, ageMax: 7, subject: "math",
    category: "player_fact", creditsReward: 5,
    funFact: "Babe Ruth hit 714 home runs in his career — that's a LOT of adding up!"
  },
  {
    question: "A soccer team has 11 players on the field. If 3 players get tired and sit down, how many are left playing?",
    correctAnswer: "8",
    choiceA: "7", choiceB: "9", choiceC: "8", choiceD: "10",
    sport: "soccer", difficulty: "easy", ageMin: 6, ageMax: 7, subject: "math",
    category: "player_fact", creditsReward: 5,
    funFact: "Subtraction means taking away. 11 - 3 = 8 players still on the field!"
  },
  {
    question: "A football player ran 10 yards, then ran 5 more yards. How many yards did he run in total?",
    correctAnswer: "15",
    choiceA: "14", choiceB: "15", choiceC: "16", choiceD: "5",
    sport: "football", difficulty: "easy", ageMin: 6, ageMax: 7, subject: "math",
    category: "player_fact", creditsReward: 5,
    funFact: "A first down in football requires 10 yards. You just added up more than that!"
  },
  {
    question: "There are 2 hockey teams. Each team has 6 players on the ice. How many players are on the ice in total?",
    correctAnswer: "12",
    choiceA: "10", choiceB: "11", choiceC: "12", choiceD: "13",
    sport: "hockey", difficulty: "easy", ageMin: 6, ageMax: 7, subject: "math",
    category: "player_fact", creditsReward: 5,
    funFact: "Each hockey team has 6 players on ice: 1 goalie and 5 skaters. 6 + 6 = 12!"
  },

  // AGE 6-7 — READING/LANGUAGE
  {
    question: "Which word rhymes with 'ball'? (Hint: you use it to walk down a hallway in a stadium!)",
    correctAnswer: "hall",
    choiceA: "ball", choiceB: "hall", choiceC: "tall", choiceD: "fall",
    sport: "basketball", difficulty: "easy", ageMin: 6, ageMax: 7, subject: "reading",
    category: "player_fact", creditsReward: 5,
    funFact: "Words that sound alike at the end are called rhymes. Ball, hall, tall, fall — they all rhyme!"
  },
  {
    question: "Which of these is a complete sentence about a soccer player?",
    correctAnswer: "She kicked the ball into the net.",
    choiceA: "Kicked the ball.", choiceB: "She kicked the ball into the net.", choiceC: "The ball net.", choiceD: "Into the net she.",
    sport: "soccer", difficulty: "easy", ageMin: 6, ageMax: 7, subject: "reading",
    category: "player_fact", creditsReward: 5,
    funFact: "A complete sentence needs a subject (who) and a verb (what they do). 'She kicked' has both!"
  },
  {
    question: "What is the opposite of 'fast'? (Think of a slow runner!)",
    correctAnswer: "slow",
    choiceA: "quick", choiceB: "slow", choiceC: "run", choiceD: "jump",
    sport: "football", difficulty: "easy", ageMin: 6, ageMax: 7, subject: "reading",
    category: "player_fact", creditsReward: 5,
    funFact: "Words with opposite meanings are called antonyms. Fast and slow are antonyms!"
  },

  // AGE 6-7 — SCIENCE
  {
    question: "What do athletes drink to stay healthy during a game?",
    correctAnswer: "Water",
    choiceA: "Soda", choiceB: "Water", choiceC: "Juice", choiceD: "Milk",
    sport: "basketball", difficulty: "easy", ageMin: 6, ageMax: 7, subject: "science",
    category: "player_fact", creditsReward: 5,
    funFact: "Your body is about 60% water! Athletes drink water to replace what they sweat out during exercise."
  },
  {
    question: "Why do football players wear helmets?",
    correctAnswer: "To protect their head and brain",
    choiceA: "To look cool", choiceB: "To protect their head and brain", choiceC: "To keep warm", choiceD: "To run faster",
    sport: "football", difficulty: "easy", ageMin: 6, ageMax: 7, subject: "science",
    category: "player_fact", creditsReward: 5,
    funFact: "The brain is the most important organ in your body. Helmets protect it from hard hits!"
  },

  // =========================================================================
  // AGE 8-9 — MATH
  // =========================================================================
  {
    question: "A basketball player scored 24 points in the first game and 31 points in the second game. How many total points did he score?",
    correctAnswer: "55",
    choiceA: "54", choiceB: "55", choiceC: "56", choiceD: "57",
    sport: "basketball", difficulty: "easy", ageMin: 8, ageMax: 9, subject: "math",
    category: "player_fact", creditsReward: 5,
    funFact: "Michael Jordan averaged 30.1 points per game in his career — that's incredible!"
  },
  {
    question: "A baseball team played 162 games and won 95 of them. How many games did they lose?",
    correctAnswer: "67",
    choiceA: "65", choiceB: "66", choiceC: "67", choiceD: "68",
    sport: "baseball", difficulty: "medium", ageMin: 8, ageMax: 9, subject: "math",
    category: "record", creditsReward: 8,
    funFact: "A Major League Baseball season has 162 games. 162 - 95 = 67 losses."
  },
  {
    question: "A football field is 100 yards long. If a player runs half the field, how many yards did he run?",
    correctAnswer: "50",
    choiceA: "40", choiceB: "45", choiceC: "50", choiceD: "55",
    sport: "football", difficulty: "easy", ageMin: 8, ageMax: 9, subject: "math",
    category: "player_fact", creditsReward: 5,
    funFact: "Half of 100 is 50. Fractions help us split things equally!"
  },
  {
    question: "A hockey team scored 3 goals in each of 4 periods. How many goals did they score in total?",
    correctAnswer: "12",
    choiceA: "9", choiceB: "10", choiceC: "11", choiceD: "12",
    sport: "hockey", difficulty: "easy", ageMin: 8, ageMax: 9, subject: "math",
    category: "player_fact", creditsReward: 5,
    funFact: "Multiplication is repeated addition. 3 × 4 = 12. Hockey actually has 3 periods, not 4!"
  },
  {
    question: "A soccer player earns $120 per week. How much does she earn in 4 weeks?",
    correctAnswer: "$480",
    choiceA: "$400", choiceB: "$440", choiceC: "$480", choiceD: "$520",
    sport: "soccer", difficulty: "medium", ageMin: 8, ageMax: 9, subject: "math",
    category: "card_value", creditsReward: 8,
    funFact: "120 × 4 = 480. Multiplication helps us figure out totals over time!"
  },

  // AGE 8-9 — READING
  {
    question: "In the sentence 'The speedy wide receiver caught the football,' what is the adjective?",
    correctAnswer: "speedy",
    choiceA: "receiver", choiceB: "caught", choiceC: "speedy", choiceD: "football",
    sport: "football", difficulty: "medium", ageMin: 8, ageMax: 9, subject: "reading",
    category: "player_fact", creditsReward: 8,
    funFact: "Adjectives describe nouns. 'Speedy' describes the receiver — it tells us what kind of receiver!"
  },
  {
    question: "Which word is a synonym for 'victory'? (What a team gets when they win!)",
    correctAnswer: "win",
    choiceA: "loss", choiceB: "tie", choiceC: "win", choiceD: "foul",
    sport: "basketball", difficulty: "easy", ageMin: 8, ageMax: 9, subject: "reading",
    category: "player_fact", creditsReward: 5,
    funFact: "Synonyms are words that mean the same thing. Victory, win, triumph — all mean you came out on top!"
  },
  {
    question: "What is the main idea of this passage? 'LeBron James practices basketball every day. He works on his shooting, dribbling, and defense. Hard work makes great players.'",
    correctAnswer: "Hard work makes great players",
    choiceA: "LeBron James is tall", choiceB: "Basketball is fun", choiceC: "Hard work makes great players", choiceD: "LeBron likes to dribble",
    sport: "basketball", difficulty: "medium", ageMin: 8, ageMax: 9, subject: "reading",
    category: "player_fact", creditsReward: 8,
    funFact: "The main idea is what the whole passage is mostly about. The last sentence sums it up!"
  },

  // AGE 8-9 — SCIENCE
  {
    question: "When a baseball player throws a ball, which force pulls it back down to the ground?",
    correctAnswer: "Gravity",
    choiceA: "Friction", choiceB: "Magnetism", choiceC: "Gravity", choiceD: "Wind",
    sport: "baseball", difficulty: "easy", ageMin: 8, ageMax: 9, subject: "science",
    category: "player_fact", creditsReward: 5,
    funFact: "Gravity is the force that pulls everything toward Earth. Without it, home run balls would fly into space!"
  },
  {
    question: "A swimmer's muscles need oxygen to work. What body part delivers oxygen to the muscles?",
    correctAnswer: "The heart (through blood)",
    choiceA: "The stomach", choiceB: "The heart (through blood)", choiceC: "The lungs alone", choiceD: "The brain",
    sport: "soccer", difficulty: "medium", ageMin: 8, ageMax: 9, subject: "science",
    category: "player_fact", creditsReward: 8,
    funFact: "Your heart pumps blood carrying oxygen to every muscle. That's why your heart beats faster when you exercise!"
  },
  {
    question: "What are the three states of matter that ice, water, and steam represent?",
    correctAnswer: "Solid, liquid, gas",
    choiceA: "Hard, soft, air", choiceB: "Solid, liquid, gas", choiceC: "Cold, warm, hot", choiceD: "Ice, water, cloud",
    sport: "hockey", difficulty: "medium", ageMin: 8, ageMax: 9, subject: "science",
    category: "player_fact", creditsReward: 8,
    funFact: "Hockey is played on ice (solid), which is frozen water (liquid). Heat turns water into steam (gas)!"
  },

  // AGE 8-9 — HISTORY
  {
    question: "In which year did the United States declare independence?",
    correctAnswer: "1776",
    choiceA: "1492", choiceB: "1620", choiceC: "1776", choiceD: "1812",
    sport: "baseball", difficulty: "medium", ageMin: 8, ageMax: 9, subject: "history",
    category: "history", creditsReward: 8,
    funFact: "Baseball became popular after the Civil War and is often called America's pastime — just like our country, it has a long history!"
  },
  {
    question: "Who was the first President of the United States?",
    correctAnswer: "George Washington",
    choiceA: "Abraham Lincoln", choiceB: "Thomas Jefferson", choiceC: "George Washington", choiceD: "John Adams",
    sport: "football", difficulty: "easy", ageMin: 8, ageMax: 9, subject: "history",
    category: "president_era", creditsReward: 5,
    funFact: "George Washington led the Continental Army — just like a great quarterback leads a football team!"
  },

  // =========================================================================
  // AGE 10-11 — MATH
  // =========================================================================
  {
    question: "A basketball player makes 7 out of every 10 free throws. What percentage does he make?",
    correctAnswer: "70%",
    choiceA: "60%", choiceB: "65%", choiceC: "70%", choiceD: "75%",
    sport: "basketball", difficulty: "medium", ageMin: 10, ageMax: 11, subject: "math",
    category: "record", creditsReward: 8,
    funFact: "Stephen Curry has one of the best free throw percentages ever at over 90%!"
  },
  {
    question: "A baseball card is worth $45. If it increases in value by 20%, what is its new value?",
    correctAnswer: "$54",
    choiceA: "$50", choiceB: "$52", choiceC: "$54", choiceD: "$56",
    sport: "baseball", difficulty: "medium", ageMin: 10, ageMax: 11, subject: "math",
    category: "card_value", creditsReward: 8,
    funFact: "20% of $45 = $9. $45 + $9 = $54. Percentages help collectors track how their card values grow!"
  },
  {
    question: "A football team gained 12.5 yards on one play and 7.5 yards on the next. What is the total yardage?",
    correctAnswer: "20 yards",
    choiceA: "18 yards", choiceB: "19 yards", choiceC: "20 yards", choiceD: "21 yards",
    sport: "football", difficulty: "medium", ageMin: 10, ageMax: 11, subject: "math",
    category: "player_fact", creditsReward: 8,
    funFact: "Adding decimals works just like adding whole numbers — just line up the decimal points! 12.5 + 7.5 = 20"
  },
  {
    question: "A hockey player scored goals in the ratio of 3:2 in two seasons. If he scored 15 goals in season one, how many did he score in season two?",
    correctAnswer: "10",
    choiceA: "8", choiceB: "9", choiceC: "10", choiceD: "12",
    sport: "hockey", difficulty: "hard", ageMin: 10, ageMax: 11, subject: "math",
    category: "record", creditsReward: 12,
    funFact: "Ratios compare two quantities. 3:2 means for every 3 goals in season 1, there are 2 in season 2. 15 ÷ 3 × 2 = 10!"
  },
  {
    question: "A soccer team's average goals per game is 2.4. Over 10 games, how many total goals did they score?",
    correctAnswer: "24",
    choiceA: "20", choiceB: "22", choiceC: "24", choiceD: "26",
    sport: "soccer", difficulty: "medium", ageMin: 10, ageMax: 11, subject: "math",
    category: "record", creditsReward: 8,
    funFact: "Average × number of games = total. 2.4 × 10 = 24 goals. Averages help compare players fairly!"
  },

  // AGE 10-11 — READING/LANGUAGE ARTS
  {
    question: "In the sentence 'The exhausted pitcher threw his final fastball,' what does 'exhausted' mean?",
    correctAnswer: "Very tired",
    choiceA: "Very fast", choiceB: "Very strong", choiceC: "Very tired", choiceD: "Very tall",
    sport: "baseball", difficulty: "medium", ageMin: 10, ageMax: 11, subject: "reading",
    category: "player_fact", creditsReward: 8,
    funFact: "Context clues help you figure out word meanings. 'Final fastball' suggests the pitcher had no energy left!"
  },
  {
    question: "Which literary device is used in: 'The basketball bounced like a heartbeat — steady, rhythmic, alive'?",
    correctAnswer: "Simile",
    choiceA: "Metaphor", choiceB: "Simile", choiceC: "Alliteration", choiceD: "Hyperbole",
    sport: "basketball", difficulty: "hard", ageMin: 10, ageMax: 11, subject: "reading",
    category: "player_fact", creditsReward: 12,
    funFact: "A simile uses 'like' or 'as' to compare two things. 'Bounced LIKE a heartbeat' — that's a simile!"
  },
  {
    question: "What is the purpose of a persuasive essay?",
    correctAnswer: "To convince the reader to agree with an opinion",
    choiceA: "To tell a story", choiceB: "To explain how something works", choiceC: "To convince the reader to agree with an opinion", choiceD: "To describe a place",
    sport: "football", difficulty: "medium", ageMin: 10, ageMax: 11, subject: "reading",
    category: "player_fact", creditsReward: 8,
    funFact: "Sports commentators use persuasion all the time — 'This is the greatest team ever!' is a persuasive claim!"
  },

  // AGE 10-11 — SCIENCE
  {
    question: "A baseball pitcher uses force to throw a ball. According to Newton's Third Law, what happens when the pitcher releases the ball?",
    correctAnswer: "The ball pushes back on the pitcher's hand with equal force",
    choiceA: "The ball slows down immediately", choiceB: "The ball pushes back on the pitcher's hand with equal force", choiceC: "Nothing happens to the pitcher", choiceD: "The pitcher moves forward",
    sport: "baseball", difficulty: "hard", ageMin: 10, ageMax: 11, subject: "science",
    category: "player_fact", creditsReward: 12,
    funFact: "Newton's Third Law: for every action there is an equal and opposite reaction. That's why pitchers feel the ball push back!"
  },
  {
    question: "Why does a spinning football travel farther and straighter than one that doesn't spin?",
    correctAnswer: "The spin creates gyroscopic stability",
    choiceA: "Spinning makes it lighter", choiceB: "The spin creates gyroscopic stability", choiceC: "Spinning reduces gravity", choiceD: "Spinning increases speed only",
    sport: "football", difficulty: "hard", ageMin: 10, ageMax: 11, subject: "science",
    category: "player_fact", creditsReward: 12,
    funFact: "A spiral pass uses gyroscopic force — the same physics that keeps a spinning top upright!"
  },
  {
    question: "What type of energy does a skateboarder have at the top of a ramp before dropping down?",
    correctAnswer: "Potential energy",
    choiceA: "Kinetic energy", choiceB: "Thermal energy", choiceC: "Potential energy", choiceD: "Chemical energy",
    sport: "soccer", difficulty: "medium", ageMin: 10, ageMax: 11, subject: "science",
    category: "player_fact", creditsReward: 8,
    funFact: "At the top = potential energy (stored). At the bottom = kinetic energy (moving). Energy converts between the two!"
  },

  // AGE 10-11 — HISTORY
  {
    question: "The Civil War ended in 1865. How many years ago was that from 2025?",
    correctAnswer: "160 years",
    choiceA: "150 years", choiceB: "155 years", choiceC: "160 years", choiceD: "165 years",
    sport: "baseball", difficulty: "medium", ageMin: 10, ageMax: 11, subject: "history",
    category: "history", creditsReward: 8,
    funFact: "Baseball became widely popular right after the Civil War. Soldiers played it in camps to pass the time!"
  },
  {
    question: "Which amendment to the U.S. Constitution abolished slavery?",
    correctAnswer: "13th Amendment",
    choiceA: "1st Amendment", choiceB: "5th Amendment", choiceC: "10th Amendment", choiceD: "13th Amendment",
    sport: "basketball", difficulty: "hard", ageMin: 10, ageMax: 11, subject: "history",
    category: "history", creditsReward: 12,
    funFact: "Jackie Robinson broke baseball's color barrier in 1947 — part of the long journey toward equality that began with the 13th Amendment!"
  },
  {
    question: "What was the name of the economic crisis that began in 1929?",
    correctAnswer: "The Great Depression",
    choiceA: "The Great Recession", choiceB: "The Great Depression", choiceC: "World War I", choiceD: "The Dust Bowl",
    sport: "baseball", difficulty: "medium", ageMin: 10, ageMax: 11, subject: "history",
    category: "history", creditsReward: 8,
    funFact: "Baseball helped Americans escape the sadness of the Great Depression. Babe Ruth was a hero to millions!"
  },

  // =========================================================================
  // AGE 12-13 — MATH
  // =========================================================================
  {
    question: "A basketball player's scoring average is 28.6 points per game. After 15 games, how many total points has he scored? (Round to nearest whole number)",
    correctAnswer: "429",
    choiceA: "425", choiceB: "427", choiceC: "429", choiceD: "431",
    sport: "basketball", difficulty: "hard", ageMin: 12, ageMax: 13, subject: "math",
    category: "record", creditsReward: 12,
    funFact: "28.6 × 15 = 429. Decimals and multiplication are key skills for sports stats!"
  },
  {
    question: "A baseball card sold for $200 and then resold for $350. What is the percentage increase in value?",
    correctAnswer: "75%",
    choiceA: "65%", choiceB: "70%", choiceC: "75%", choiceD: "80%",
    sport: "baseball", difficulty: "hard", ageMin: 12, ageMax: 13, subject: "math",
    category: "card_value", creditsReward: 12,
    funFact: "Percentage increase = (new - old) / old × 100. (350-200)/200 × 100 = 75%. Card collecting is math in action!"
  },
  {
    question: "A soccer player runs at an average speed of 8 mph. How far does she run in 45 minutes?",
    correctAnswer: "6 miles",
    choiceA: "4 miles", choiceB: "5 miles", choiceC: "6 miles", choiceD: "7 miles",
    sport: "soccer", difficulty: "hard", ageMin: 12, ageMax: 13, subject: "math",
    category: "player_fact", creditsReward: 12,
    funFact: "Distance = Speed × Time. 8 mph × 0.75 hours = 6 miles. Top soccer players run 7-9 miles per game!"
  },
  {
    question: "In a football game, a team scored touchdowns (6 pts each) and field goals (3 pts each). They scored 4 touchdowns and 3 field goals. What was their total score?",
    correctAnswer: "33",
    choiceA: "27", choiceB: "30", choiceC: "33", choiceD: "36",
    sport: "football", difficulty: "medium", ageMin: 12, ageMax: 13, subject: "math",
    category: "player_fact", creditsReward: 8,
    funFact: "(4 × 6) + (3 × 3) = 24 + 9 = 33. Order of operations: multiply first, then add!"
  },
  {
    question: "A hockey team won 60% of their 80 games. How many games did they win?",
    correctAnswer: "48",
    choiceA: "44", choiceB: "46", choiceC: "48", choiceD: "50",
    sport: "hockey", difficulty: "medium", ageMin: 12, ageMax: 13, subject: "math",
    category: "record", creditsReward: 8,
    funFact: "60% of 80 = 0.60 × 80 = 48. Percentages are everywhere in sports statistics!"
  },

  // AGE 12-13 — READING/LANGUAGE ARTS
  {
    question: "What is the difference between a primary source and a secondary source?",
    correctAnswer: "A primary source is firsthand (e.g., a player's diary); a secondary source analyzes it (e.g., a biography)",
    choiceA: "Primary is older; secondary is newer", choiceB: "A primary source is firsthand (e.g., a player's diary); a secondary source analyzes it (e.g., a biography)", choiceC: "Primary is more important", choiceD: "Secondary sources are always wrong",
    sport: "baseball", difficulty: "hard", ageMin: 12, ageMax: 13, subject: "reading",
    category: "history", creditsReward: 12,
    funFact: "A baseball player's game journal is a primary source. A book written about that player is a secondary source!"
  },
  {
    question: "In the sentence 'The stadium roared like a thunderstorm when the home team scored,' what literary device is used?",
    correctAnswer: "Simile",
    choiceA: "Personification", choiceB: "Metaphor", choiceC: "Simile", choiceD: "Onomatopoeia",
    sport: "football", difficulty: "medium", ageMin: 12, ageMax: 13, subject: "reading",
    category: "player_fact", creditsReward: 8,
    funFact: "Similes use 'like' or 'as.' The stadium is compared TO a thunderstorm using 'like' — that's a simile!"
  },
  {
    question: "What is the theme of a story?",
    correctAnswer: "The central message or lesson the author wants readers to understand",
    choiceA: "The main character's name", choiceB: "Where the story takes place", choiceC: "The central message or lesson the author wants readers to understand", choiceD: "The title of the book",
    sport: "basketball", difficulty: "medium", ageMin: 12, ageMax: 13, subject: "reading",
    category: "player_fact", creditsReward: 8,
    funFact: "Many sports movies have themes like 'teamwork wins' or 'never give up' — like in Space Jam or Remember the Titans!"
  },

  // AGE 12-13 — SCIENCE
  {
    question: "A baseball pitcher throws a curveball. Which scientific principle causes the ball to curve?",
    correctAnswer: "The Magnus effect (spin creates pressure difference)",
    choiceA: "Gravity alone", choiceB: "Air resistance only", choiceC: "The Magnus effect (spin creates pressure difference)", choiceD: "Friction from the seams",
    sport: "baseball", difficulty: "hard", ageMin: 12, ageMax: 13, subject: "science",
    category: "player_fact", creditsReward: 12,
    funFact: "The Magnus effect: spinning objects curve because spin creates different air pressure on each side. Physics makes curveballs possible!"
  },
  {
    question: "What is the chemical formula for water, which athletes drink to stay hydrated?",
    correctAnswer: "H₂O",
    choiceA: "CO₂", choiceB: "H₂O", choiceC: "O₂", choiceD: "NaCl",
    sport: "soccer", difficulty: "medium", ageMin: 12, ageMax: 13, subject: "science",
    category: "player_fact", creditsReward: 8,
    funFact: "H₂O means 2 hydrogen atoms + 1 oxygen atom. Athletes can lose 2-3 liters of H₂O through sweat in one game!"
  },
  {
    question: "During exercise, your body converts glucose into energy. What process is this?",
    correctAnswer: "Cellular respiration",
    choiceA: "Photosynthesis", choiceB: "Cellular respiration", choiceC: "Digestion", choiceD: "Osmosis",
    sport: "basketball", difficulty: "hard", ageMin: 12, ageMax: 13, subject: "science",
    category: "player_fact", creditsReward: 12,
    funFact: "Glucose + Oxygen → Energy + CO₂ + Water. Every time LeBron dunks, cellular respiration is powering his muscles!"
  },

  // AGE 12-13 — HISTORY
  {
    question: "What was the significance of Jackie Robinson joining the Brooklyn Dodgers in 1947?",
    correctAnswer: "He broke Major League Baseball's color barrier as the first Black player in the modern era",
    choiceA: "He was the first player to hit 500 home runs", choiceB: "He broke Major League Baseball's color barrier as the first Black player in the modern era", choiceC: "He invented the curveball", choiceD: "He was the first player to earn $1 million",
    sport: "baseball", difficulty: "medium", ageMin: 12, ageMax: 13, subject: "history",
    category: "history", creditsReward: 8,
    funFact: "Jackie Robinson wore #42, which is now retired across ALL of MLB — no player can ever wear it again as a tribute to his courage!"
  },
  {
    question: "The Civil Rights Act of 1964 was signed by which U.S. President?",
    correctAnswer: "Lyndon B. Johnson",
    choiceA: "John F. Kennedy", choiceB: "Lyndon B. Johnson", choiceC: "Richard Nixon", choiceD: "Dwight D. Eisenhower",
    sport: "basketball", difficulty: "hard", ageMin: 12, ageMax: 13, subject: "history",
    category: "president_era", creditsReward: 12,
    funFact: "The NBA integrated in 1950, 14 years before the Civil Rights Act. Sports often led the way in breaking racial barriers!"
  },
  {
    question: "In what year did World War II end?",
    correctAnswer: "1945",
    choiceA: "1943", choiceB: "1944", choiceC: "1945", choiceD: "1946",
    sport: "baseball", difficulty: "medium", ageMin: 12, ageMax: 13, subject: "history",
    category: "history", creditsReward: 8,
    funFact: "During WWII, many MLB players served in the military. Ted Williams, one of baseball's greatest hitters, flew combat missions!"
  },

  // =========================================================================
  // SPORTS FACTS — ALL AGES (mixed)
  // =========================================================================
  {
    question: "How many players are on a basketball team on the court at one time?",
    correctAnswer: "5",
    choiceA: "4", choiceB: "5", choiceC: "6", choiceD: "7",
    sport: "basketball", difficulty: "easy", ageMin: 6, ageMax: 7, subject: "sports_facts",
    category: "player_fact", creditsReward: 5,
    funFact: "5 players per team = 10 players total on the court. Each player has a position: point guard, shooting guard, small forward, power forward, and center!"
  },
  {
    question: "How many innings are in a standard baseball game?",
    correctAnswer: "9",
    choiceA: "7", choiceB: "8", choiceC: "9", choiceD: "10",
    sport: "baseball", difficulty: "easy", ageMin: 6, ageMax: 7, subject: "sports_facts",
    category: "player_fact", creditsReward: 5,
    funFact: "9 innings, 9 players per team, 9 positions — baseball loves the number 9!"
  },
  {
    question: "What is a 'hat trick' in hockey or soccer?",
    correctAnswer: "Scoring 3 goals in one game",
    choiceA: "Wearing a special hat", choiceB: "Scoring 3 goals in one game", choiceC: "Making 3 saves", choiceD: "Playing 3 games in a row",
    sport: "hockey", difficulty: "easy", ageMin: 8, ageMax: 9, subject: "sports_facts",
    category: "record", creditsReward: 5,
    funFact: "The term 'hat trick' comes from cricket in the 1800s — a bowler who got 3 wickets in a row was given a hat as a prize!"
  },
  {
    question: "Which country invented basketball?",
    correctAnswer: "United States (Canada-born inventor)",
    choiceA: "Brazil", choiceB: "United States (Canada-born inventor)", choiceC: "England", choiceD: "China",
    sport: "basketball", difficulty: "medium", ageMin: 10, ageMax: 11, subject: "sports_facts",
    category: "history", creditsReward: 8,
    funFact: "Dr. James Naismith, born in Canada, invented basketball in 1891 in Springfield, Massachusetts using peach baskets!"
  },
  {
    question: "What is the distance between bases on a Major League Baseball diamond?",
    correctAnswer: "90 feet",
    choiceA: "75 feet", choiceB: "80 feet", choiceC: "90 feet", choiceD: "100 feet",
    sport: "baseball", difficulty: "medium", ageMin: 10, ageMax: 11, subject: "sports_facts",
    category: "record", creditsReward: 8,
    funFact: "90 feet is considered the perfect distance — it makes close plays at first base possible. A few feet shorter and every grounder would be a hit!"
  },
  {
    question: "In football, how many points is a safety worth?",
    correctAnswer: "2",
    choiceA: "1", choiceB: "2", choiceC: "3", choiceD: "6",
    sport: "football", difficulty: "medium", ageMin: 8, ageMax: 9, subject: "sports_facts",
    category: "player_fact", creditsReward: 8,
    funFact: "A safety is when the defense tackles the ball carrier in their own end zone. It's rare but worth 2 points AND gives the ball back!"
  },
  {
    question: "What is the name of the trophy awarded to the Super Bowl champion?",
    correctAnswer: "The Vince Lombardi Trophy",
    choiceA: "The Stanley Cup", choiceB: "The Vince Lombardi Trophy", choiceC: "The Commissioner's Trophy", choiceD: "The Larry O'Brien Trophy",
    sport: "football", difficulty: "medium", ageMin: 10, ageMax: 11, subject: "sports_facts",
    category: "history", creditsReward: 8,
    funFact: "Vince Lombardi was the legendary coach of the Green Bay Packers. The trophy is made of sterling silver and weighs 7 pounds!"
  },
  {
    question: "How many periods are in a regulation NHL hockey game?",
    correctAnswer: "3",
    choiceA: "2", choiceB: "3", choiceC: "4", choiceD: "5",
    sport: "hockey", difficulty: "easy", ageMin: 8, ageMax: 9, subject: "sports_facts",
    category: "player_fact", creditsReward: 5,
    funFact: "Three 20-minute periods = 60 minutes of regulation hockey. If tied, they play overtime — sudden death!"
  },
  {
    question: "What does 'ERA' stand for in baseball pitching statistics?",
    correctAnswer: "Earned Run Average",
    choiceA: "Early Run Attempt", choiceB: "Earned Run Average", choiceC: "Extra Run Average", choiceD: "Earned Run Accuracy",
    sport: "baseball", difficulty: "hard", ageMin: 12, ageMax: 13, subject: "sports_facts",
    category: "record", creditsReward: 12,
    funFact: "ERA measures how many earned runs a pitcher allows per 9 innings. A 2.00 ERA is excellent — under 3.00 is considered very good!"
  },
  {
    question: "In basketball, what is a 'double-double'?",
    correctAnswer: "Reaching double digits (10+) in two statistical categories in one game",
    choiceA: "Scoring twice in a row", choiceB: "Reaching double digits (10+) in two statistical categories in one game", choiceC: "Making two free throws", choiceD: "Playing two games in one day",
    sport: "basketball", difficulty: "medium", ageMin: 10, ageMax: 11, subject: "sports_facts",
    category: "record", creditsReward: 8,
    funFact: "A double-double is usually points + rebounds or points + assists. A triple-double means 10+ in THREE categories — very rare!"
  },

  // =========================================================================
  // MORE MATH — ADDITIONAL QUESTIONS
  // =========================================================================
  {
    question: "A sports card collector has 48 cards. She wants to put them equally into 6 binders. How many cards go in each binder?",
    correctAnswer: "8",
    choiceA: "6", choiceB: "7", choiceC: "8", choiceD: "9",
    sport: "baseball", difficulty: "easy", ageMin: 8, ageMax: 9, subject: "math",
    category: "card_value", creditsReward: 5,
    funFact: "Division splits things into equal groups. 48 ÷ 6 = 8. Division is the opposite of multiplication!"
  },
  {
    question: "A basketball player made 3/4 of his free throws. If he attempted 20 free throws, how many did he make?",
    correctAnswer: "15",
    choiceA: "12", choiceB: "13", choiceC: "14", choiceD: "15",
    sport: "basketball", difficulty: "medium", ageMin: 10, ageMax: 11, subject: "math",
    category: "record", creditsReward: 8,
    funFact: "3/4 of 20 = (3 × 20) ÷ 4 = 15. Fractions are everywhere in sports stats!"
  },
  {
    question: "A football game starts at 1:00 PM and lasts 3 hours and 15 minutes. What time does it end?",
    correctAnswer: "4:15 PM",
    choiceA: "3:15 PM", choiceB: "4:00 PM", choiceC: "4:15 PM", choiceD: "4:30 PM",
    sport: "football", difficulty: "easy", ageMin: 8, ageMax: 9, subject: "math",
    category: "player_fact", creditsReward: 5,
    funFact: "Adding time is just like adding numbers — just remember 60 minutes = 1 hour!"
  },
  {
    question: "A hockey puck travels at 100 miles per hour. How far does it travel in 3 seconds? (1 mile = 5,280 feet, 1 hour = 3,600 seconds)",
    correctAnswer: "440 feet",
    choiceA: "300 feet", choiceB: "400 feet", choiceC: "440 feet", choiceD: "500 feet",
    sport: "hockey", difficulty: "hard", ageMin: 12, ageMax: 13, subject: "math",
    category: "record", creditsReward: 12,
    funFact: "100 mph = 146.67 ft/sec. In 3 seconds = 440 feet. That's longer than a football field! No wonder goalies need fast reflexes."
  },
  {
    question: "A soccer team scored in 60% of their games. If they played 25 games, in how many games did they score?",
    correctAnswer: "15",
    choiceA: "12", choiceB: "13", choiceC: "14", choiceD: "15",
    sport: "soccer", difficulty: "medium", ageMin: 10, ageMax: 11, subject: "math",
    category: "record", creditsReward: 8,
    funFact: "60% × 25 = 0.60 × 25 = 15 games. Percentages help coaches analyze team performance!"
  },

  // =========================================================================
  // MORE SCIENCE
  // =========================================================================
  {
    question: "Why do baseball players spit on their hands before batting?",
    correctAnswer: "To improve grip (moisture reduces slipping)",
    choiceA: "It's a superstition only", choiceB: "To improve grip (moisture reduces slipping)", choiceC: "To cool their hands down", choiceD: "To signal the pitcher",
    sport: "baseball", difficulty: "medium", ageMin: 10, ageMax: 11, subject: "science",
    category: "player_fact", creditsReward: 8,
    funFact: "Friction between hands and bat prevents slipping. Moisture increases friction on smooth surfaces — science in action!"
  },
  {
    question: "A football is inflated with air. What happens to the air pressure inside when the temperature drops?",
    correctAnswer: "The pressure decreases",
    choiceA: "The pressure increases", choiceB: "The pressure decreases", choiceC: "Nothing changes", choiceD: "The ball explodes",
    sport: "football", difficulty: "hard", ageMin: 12, ageMax: 13, subject: "science",
    category: "player_fact", creditsReward: 12,
    funFact: "Cold air = lower pressure. This was actually at the center of the 'Deflategate' controversy in the NFL!"
  },
  {
    question: "What type of simple machine is a baseball bat?",
    correctAnswer: "A lever",
    choiceA: "A wheel and axle", choiceB: "A pulley", choiceC: "A lever", choiceD: "An inclined plane",
    sport: "baseball", difficulty: "medium", ageMin: 10, ageMax: 11, subject: "science",
    category: "player_fact", creditsReward: 8,
    funFact: "A bat is a third-class lever! The effort (hands) is between the fulcrum (pivot point) and the load (ball). Levers multiply force!"
  },

  // =========================================================================
  // MORE HISTORY
  // =========================================================================
  {
    question: "The first modern Olympic Games were held in which city in 1896?",
    correctAnswer: "Athens, Greece",
    choiceA: "Paris, France", choiceB: "London, England", choiceC: "Athens, Greece", choiceD: "Rome, Italy",
    sport: "soccer", difficulty: "medium", ageMin: 10, ageMax: 11, subject: "history",
    category: "history", creditsReward: 8,
    funFact: "The ancient Greeks held the original Olympics starting in 776 BC. The modern Olympics brought the tradition back after 1,500 years!"
  },
  {
    question: "Which U.S. President threw out the first pitch at a baseball game, starting a tradition in 1910?",
    correctAnswer: "William Howard Taft",
    choiceA: "Theodore Roosevelt", choiceB: "Woodrow Wilson", choiceC: "William Howard Taft", choiceD: "Herbert Hoover",
    sport: "baseball", difficulty: "hard", ageMin: 12, ageMax: 13, subject: "history",
    category: "president_era", creditsReward: 12,
    funFact: "President Taft started the first-pitch tradition in 1910. He also allegedly started the 7th-inning stretch when he stood up to stretch his large frame!"
  },
  {
    question: "Muhammad Ali was stripped of his boxing title in 1967 for refusing to be drafted. What war was the U.S. fighting at the time?",
    correctAnswer: "The Vietnam War",
    choiceA: "World War II", choiceB: "The Korean War", choiceC: "The Vietnam War", choiceD: "The Gulf War",
    sport: "basketball", difficulty: "hard", ageMin: 12, ageMax: 13, subject: "history",
    category: "history", creditsReward: 12,
    funFact: "Ali said 'I ain't got no quarrel with them Viet Cong.' He lost his title but later won it back — and became one of the greatest athletes of all time!"
  },

  // =========================================================================
  // MORE READING — ADDITIONAL
  // =========================================================================
  {
    question: "What is an autobiography?",
    correctAnswer: "A book written by a person about their own life",
    choiceA: "A book about cars", choiceB: "A book written by a person about their own life", choiceC: "A book written by someone else about a person", choiceD: "A fictional story",
    sport: "basketball", difficulty: "medium", ageMin: 10, ageMax: 11, subject: "reading",
    category: "player_fact", creditsReward: 8,
    funFact: "Many athletes write autobiographies! LeBron James, Michael Jordan, and Serena Williams have all shared their life stories in books."
  },
  {
    question: "What does the prefix 'un-' mean in the word 'undefeated'?",
    correctAnswer: "Not",
    choiceA: "Again", choiceB: "Before", choiceC: "Not", choiceD: "After",
    sport: "football", difficulty: "easy", ageMin: 8, ageMax: 9, subject: "reading",
    category: "player_fact", creditsReward: 5,
    funFact: "Un- means 'not.' Undefeated = not defeated. The 1972 Miami Dolphins are the only NFL team to finish a season undefeated!"
  },
  {
    question: "In a nonfiction sports article, what is the purpose of a heading or subheading?",
    correctAnswer: "To organize the text and tell readers what each section is about",
    choiceA: "To make the article look pretty", choiceB: "To organize the text and tell readers what each section is about", choiceC: "To list the author's name", choiceD: "To replace the conclusion",
    sport: "baseball", difficulty: "medium", ageMin: 10, ageMax: 11, subject: "reading",
    category: "player_fact", creditsReward: 8,
    funFact: "Sports magazines like Sports Illustrated use headings to organize stories. Good readers use headings to preview what they're about to read!"
  },
];

async function seed() {
  const db = await getDb();
  if (!db) { console.error("DB not available"); process.exit(1); }

  console.log(`Seeding ${questions.length} trivia questions...`);
  let inserted = 0;
  let skipped = 0;

  for (const q of questions) {
    try {
      await db.insert(kidsTriviaQuestions).values({
        question: q.question,
        correctAnswer: q.correctAnswer,
        choiceA: q.choiceA,
        choiceB: q.choiceB,
        choiceC: q.choiceC,
        choiceD: q.choiceD,
        sport: q.sport,
        difficulty: q.difficulty,
        ageMin: q.ageMin,
        category: q.category,
        creditsReward: q.creditsReward,
        funFact: q.funFact,
      });
      inserted++;
    } catch (e: any) {
      console.log(`Skip: ${e.message?.slice(0, 60)}`);
      skipped++;
    }
  }

  console.log(`Done! Inserted: ${inserted}, Skipped: ${skipped}`);
  process.exit(0);
}

seed();
