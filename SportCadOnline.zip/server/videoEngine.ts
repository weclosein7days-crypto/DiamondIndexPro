/**
 * Video Engine
 * Calls the Python generate_video.py script to produce an MP4,
 * uploads it to S3, and returns the CDN URL.
 */
import { execFile } from "child_process";
import { promisify } from "util";
import { readFile, unlink } from "fs/promises";
import { join, dirname } from "path";
import { fileURLToPath } from "url";
import os from "os";
import { storagePut } from "./storage";

const execFileAsync = promisify(execFile);

// ESM-compatible __dirname
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const SCRIPT_PATH = join(__dirname, "scripts", "generate_video.py");

export interface VideoGenerationInput {
  postId: number;
  title: string;
  excerpt: string;
  content: string;
  coverImageUrl?: string | null;
  slug: string;
}

export interface VideoGenerationResult {
  s3Url: string;
  durationSeconds: number;
  fileSizeBytes: number;
}

export async function generateBlogVideo(input: VideoGenerationInput): Promise<VideoGenerationResult> {
  const outputPath = join(os.tmpdir(), `blog-video-${input.postId}-${Date.now()}.mp4`);

  console.log(`[videoEngine] Generating video for post #${input.postId}: "${input.title}"`);

  try {
    const args = [
      SCRIPT_PATH,
      "--title", input.title,
      "--excerpt", input.excerpt || "",
      "--content", input.content,
      "--output", outputPath,
    ];

    if (input.coverImageUrl) {
      args.push("--cover_url", input.coverImageUrl);
    }

    const { stdout, stderr } = await execFileAsync("python3", args, {
      timeout: 300_000, // 5 minute timeout
      maxBuffer: 10 * 1024 * 1024,
    });

    if (stderr) {
      console.warn(`[videoEngine] Python stderr:`, stderr.slice(0, 500));
    }

    let result: { success: boolean; output: string; duration_seconds: number; file_size_bytes: number; error?: string };
    try {
      result = JSON.parse(stdout.trim());
    } catch {
      throw new Error(`Python script returned non-JSON: ${stdout.slice(0, 200)}`);
    }

    if (!result.success || result.error) {
      throw new Error(`Video generation failed: ${result.error}`);
    }

    console.log(`[videoEngine] Video generated: ${result.duration_seconds}s, ${(result.file_size_bytes / 1024 / 1024).toFixed(1)}MB`);

    // Upload to S3
    const videoBuffer = await readFile(outputPath);
    const s3Key = `blog-videos/${input.slug}.mp4`;
    const { url: s3Url } = await storagePut(s3Key, videoBuffer, "video/mp4");

    console.log(`[videoEngine] Uploaded to S3: ${s3Url}`);

    return {
      s3Url,
      durationSeconds: result.duration_seconds,
      fileSizeBytes: result.file_size_bytes,
    };
  } finally {
    // Clean up temp file
    try { await unlink(outputPath); } catch { /* ignore */ }
  }
}
