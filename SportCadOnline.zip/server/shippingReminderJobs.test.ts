/**
 * Tests for shippingReminderJobs.ts
 *
 * Verifies that:
 * 1. processShippingReminders sends emails to sellers whose shipByDeadline is within 24h
 * 2. It skips orders that already have a tracking number (SQL filter)
 * 3. It skips orders that already had a reminder sent (SQL filter)
 * 4. It marks shipReminderSentAt after sending
 * 5. It handles DB failure gracefully
 * 6. It continues processing other orders if one email fails
 */

import { describe, it, expect, vi, beforeEach } from "vitest";

// ─── Hoist mocks so they are available when vi.mock factories run ─────────────
const { mockExecute, mockEnd, mockSendEmail, mockShippingReminderTemplate, mockNotifyOwner } =
  vi.hoisted(() => {
    const mockExecute = vi.fn();
    const mockEnd = vi.fn();
    const mockSendEmail = vi.fn().mockResolvedValue(true);
    const mockShippingReminderTemplate = vi.fn().mockReturnValue({
      subject: "Test reminder subject",
      html: "<p>Test reminder html</p>",
    });
    const mockNotifyOwner = vi.fn().mockResolvedValue(true);
    return { mockExecute, mockEnd, mockSendEmail, mockShippingReminderTemplate, mockNotifyOwner };
  });

// ─── Mock mysql2/promise ──────────────────────────────────────────────────────
vi.mock("mysql2/promise", () => ({
  default: {
    createConnection: vi.fn().mockResolvedValue({
      execute: mockExecute,
      end: mockEnd,
    }),
  },
}));

// ─── Mock email ───────────────────────────────────────────────────────────────
vi.mock("./email", () => ({
  sendEmail: (...args: any[]) => mockSendEmail(...args),
  emailTemplates: () => ({
    shippingReminder: mockShippingReminderTemplate,
  }),
}));

// ─── Mock notification ────────────────────────────────────────────────────────
vi.mock("./_core/notification", () => ({
  notifyOwner: (...args: any[]) => mockNotifyOwner(...args),
}));

// ─── Import after mocks ───────────────────────────────────────────────────────
import { processShippingReminders } from "./shippingReminderJobs";

// ─── Helpers ──────────────────────────────────────────────────────────────────
const now = new Date();
const in12h = new Date(now.getTime() + 12 * 60 * 60 * 1000);

function makeOrder(overrides: Record<string, any> = {}) {
  return {
    id: 1,
    ticketNumber: "SCO-001",
    cardTitle: "2023 Topps Chrome Mike Trout",
    buyerName: "John Buyer",
    sellerEmail: "seller@example.com",
    sellerStoreName: "Test Store",
    shipByDeadline: in12h.toISOString(),
    ...overrides,
  };
}

describe("processShippingReminders", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    process.env.DATABASE_URL = "mysql://test";
    // Re-apply default mock return values after clearAllMocks
    mockSendEmail.mockResolvedValue(true);
    mockShippingReminderTemplate.mockReturnValue({
      subject: "Test reminder subject",
      html: "<p>Test reminder html</p>",
    });
    mockNotifyOwner.mockResolvedValue(true);
  });

  it("sends a reminder email when an order is within 24h of deadline", async () => {
    const order = makeOrder();
    mockExecute
      .mockResolvedValueOnce([[order], []]) // SELECT
      .mockResolvedValueOnce([{ affectedRows: 1 }, []]); // UPDATE

    await processShippingReminders();

    expect(mockSendEmail).toHaveBeenCalledOnce();
    expect(mockSendEmail).toHaveBeenCalledWith(
      expect.objectContaining({
        to: "seller@example.com",
        subject: "Test reminder subject",
      })
    );
  });

  it("marks shipReminderSentAt after sending the email", async () => {
    const order = makeOrder();
    mockExecute
      .mockResolvedValueOnce([[order], []])
      .mockResolvedValueOnce([{ affectedRows: 1 }, []]);

    await processShippingReminders();

    const updateCall = mockExecute.mock.calls.find((c) =>
      (c[0] as string).includes("UPDATE")
    );
    expect(updateCall).toBeDefined();
    expect(updateCall![0]).toContain("UPDATE orders SET shipReminderSentAt");
    expect(updateCall![1][1]).toBe(order.id);
  });

  it("does not send any email when there are no qualifying orders", async () => {
    mockExecute.mockResolvedValueOnce([[], []]);

    await processShippingReminders();

    expect(mockSendEmail).not.toHaveBeenCalled();
  });

  it("SQL query filters on shipReminderSentAt IS NULL to prevent duplicates", async () => {
    mockExecute.mockResolvedValueOnce([[], []]);

    await processShippingReminders();

    const selectCall = mockExecute.mock.calls[0];
    expect(selectCall[0]).toContain("shipReminderSentAt IS NULL");
  });

  it("SQL query filters on trackingNumber IS NULL to skip already-shipped orders", async () => {
    mockExecute.mockResolvedValueOnce([[], []]);

    await processShippingReminders();

    const selectCall = mockExecute.mock.calls[0];
    expect(selectCall[0]).toContain("trackingNumber IS NULL");
  });

  it("handles DB connection failure gracefully without throwing", async () => {
    const mysql = await import("mysql2/promise");
    vi.mocked(mysql.default.createConnection).mockRejectedValueOnce(new Error("DB down"));

    await expect(processShippingReminders()).resolves.not.toThrow();
    expect(mockSendEmail).not.toHaveBeenCalled();
  });

  it("continues processing other orders if one email fails to send", async () => {
    const order1 = makeOrder({ id: 1, ticketNumber: "SCO-001", sellerEmail: "seller1@example.com" });
    const order2 = makeOrder({ id: 2, ticketNumber: "SCO-002", sellerEmail: "seller2@example.com" });

    mockExecute
      .mockResolvedValueOnce([[order1, order2], []]) // SELECT
      .mockResolvedValueOnce([{ affectedRows: 1 }, []]) // UPDATE order2 (only successful one)
      .mockResolvedValueOnce([{ affectedRows: 1 }, []]);

    // First email fails, second succeeds
    mockSendEmail
      .mockResolvedValueOnce(false)
      .mockResolvedValueOnce(true);

    await processShippingReminders();

    // Both emails were attempted
    expect(mockSendEmail).toHaveBeenCalledTimes(2);
    // Only the successful one triggers an UPDATE
    const updateCalls = mockExecute.mock.calls.filter((c) =>
      (c[0] as string).includes("UPDATE")
    );
    expect(updateCalls).toHaveLength(1);
    expect(updateCalls[0][1][1]).toBe(order2.id);
  });
});
