/**
 * eBay Dropship Import Engine
 * 
 * Fetches top trending sports cards from eBay across 7 sports,
 * applies 20% markup + shipping cost, detects BGS grades only,
 * and imports them as dropship listings.
 * 
 * LOCKED RULE: Only Beckett BGS graded cards with grade 9.0 or higher are imported.
 * PSA, SGC, CSG, and ungraded cards are always skipped.
 */

import { createCard, getDb } from "./db";
import { cards } from "../drizzle/schema";
import { eq, and } from "drizzle-orm";

const MARKUP = 1.20; // 20% markup

// Top 100 trending players per sport — expanded roster for larger import pool
const SPORT_PLAYERS: Record<string, { sport: string; players: string[] }> = {
  basketball: {
    sport: "basketball",
    players: [
      // Current stars & rookies
      "Caitlin Clark", "Victor Wembanyama", "Cooper Flagg", "Paige Bueckers",
      "LeBron James", "Stephen Curry", "Luka Doncic", "Giannis Antetokounmpo",
      "Jayson Tatum", "Anthony Edwards", "Nikola Jokic", "Shai Gilgeous-Alexander",
      "Zion Williamson", "Paolo Banchero", "Scottie Barnes", "Evan Mobley",
      "Cade Cunningham", "Jalen Green", "Tyrese Haliburton", "Donovan Mitchell",
      "Ja Morant", "Devin Booker", "Trae Young", "Karl-Anthony Towns",
      "Bam Adebayo", "Kawhi Leonard", "Kevin Durant", "Joel Embiid",
      "Damian Lillard", "Kyrie Irving",
      // Rising stars & depth
      "Franz Wagner", "Alperen Sengun", "Jalen Brunson", "Darius Garland",
      "Desmond Bane", "Jaren Jackson Jr", "Zach LaVine", "DeMar DeRozan",
      "Lauri Markkanen", "Keldon Johnson", "Josh Giddey", "Luguentz Dort",
      "Keegan Murray", "Bennedict Mathurin", "Jabari Smith Jr", "Jaden Ivey",
      "Dyson Daniels", "Scoot Henderson", "Brandon Miller", "Ausar Thompson",
      "Amen Thompson", "Gradey Dick", "Jordan Hawkins", "Cason Wallace",
      "Keyonte George", "Dereck Lively II", "Nick Smith Jr", "Anthony Black",
      // Legends & veterans
      "Michael Jordan", "Kobe Bryant", "Shaquille O'Neal", "Magic Johnson",
      "Larry Bird", "Charles Barkley", "Patrick Ewing", "Hakeem Olajuwon",
      "Allen Iverson", "Dirk Nowitzki", "Dwyane Wade", "Chris Paul",
      "Russell Westbrook", "James Harden", "Paul George", "Carmelo Anthony",
      // WNBA
      "Angel Reese", "A'ja Wilson", "Breanna Stewart", "Sabrina Ionescu",
      "Kelsey Plum", "Arike Ogunbowale", "Napheesa Collier", "Aliyah Boston",
      "Cameron Brink", "Kate Martin", "Rickea Jackson", "Sophie Cunningham"
    ]
  },
  football: {
    sport: "football",
    players: [
      // Current stars
      "Patrick Mahomes", "Josh Allen", "Lamar Jackson", "Joe Burrow",
      "Justin Jefferson", "CeeDee Lamb", "Ja'Marr Chase", "Tyreek Hill",
      "Travis Kelce", "Brock Purdy", "Caleb Williams", "Marvin Harrison Jr",
      "Drake Maye", "Bo Nix", "Jayden Daniels", "Malik Nabers",
      "Sam LaPorta", "Puka Nacua", "Rashee Rice", "Nico Collins",
      "Christian McCaffrey", "Saquon Barkley", "Derrick Henry", "Jonathan Taylor",
      "Justin Herbert", "Jalen Hurts", "Dak Prescott", "Trevor Lawrence",
      "Anthony Richardson", "Bryce Young",
      // Rising stars & depth
      "Bijan Robinson", "Jahmyr Gibbs", "De'Von Achane", "Puka Nacua",
      "Jordan Addison", "Zay Flowers", "Quentin Johnston", "Jaxon Smith-Njigba",
      "Tank Dell", "Michael Pittman Jr", "Stefon Diggs", "Davante Adams",
      "Amari Cooper", "DeAndre Hopkins", "Cooper Kupp", "Keenan Allen",
      "George Kittle", "Mark Andrews", "Dallas Goedert", "Pat Freiermuth",
      "Micah Parsons", "Nick Bosa", "Myles Garrett", "Maxx Crosby",
      "Sauce Gardner", "Jalen Ramsey", "Trevon Diggs", "Patrick Surtain II",
      // Legends
      "Tom Brady", "Peyton Manning", "Jerry Rice", "Barry Sanders",
      "Emmitt Smith", "Walter Payton", "Joe Montana", "Dan Marino",
      "Brett Favre", "John Elway", "Lawrence Taylor", "Deion Sanders",
      "Randy Moss", "Terrell Owens", "Adrian Peterson", "LaDainian Tomlinson"
    ]
  },
  baseball: {
    sport: "baseball",
    players: [
      // Current stars
      "Shohei Ohtani", "Juan Soto", "Ronald Acuna Jr", "Mookie Betts",
      "Freddie Freeman", "Julio Rodriguez", "Gunnar Henderson", "Bobby Witt Jr",
      "Jackson Holliday", "Paul Skenes", "Elly De La Cruz", "Jackson Chourio",
      "Francisco Lindor", "Yordan Alvarez", "Adley Rutschman", "Corbin Carroll",
      "Trea Turner", "Pete Alonso", "Vladimir Guerrero Jr", "Mike Trout",
      "Fernando Tatis Jr", "Bryce Harper", "Aaron Judge", "Corey Seager",
      "Nolan Arenado", "Jose Ramirez", "Wander Franco", "Spencer Torkelson",
      "Colt Keith", "Wyatt Langford",
      // Rising stars & depth
      "Evan Carter", "Masyn Winn", "Jackson Merrill", "Colton Cowser",
      "Kyle Harrison", "Cade Cavalli", "Gavin Williams", "Andrew Abbott",
      "Taj Bradley", "Kodai Senga", "Yoshinobu Yamamoto", "Roki Sasaki",
      "Gerrit Cole", "Shane Bieber", "Spencer Strider", "Zack Wheeler",
      "Max Scherzer", "Justin Verlander", "Clayton Kershaw", "Jacob deGrom",
      "Xander Bogaerts", "Marcus Semien", "Jose Altuve", "Freddie Freeman",
      "Matt Olson", "Paul Goldschmidt", "Manny Machado", "Rafael Devers",
      "Austin Riley", "Ke'Bryan Hayes", "Gleyber Torres", "DJ LeMahieu",
      // Legends
      "Derek Jeter", "Ken Griffey Jr", "Barry Bonds", "Hank Aaron",
      "Willie Mays", "Mickey Mantle", "Babe Ruth", "Ted Williams",
      "Cal Ripken Jr", "Tony Gwynn", "Nolan Ryan", "Roger Clemens",
      "Randy Johnson", "Pedro Martinez", "Greg Maddux", "Tom Seaver"
    ]
  },
  hockey: {
    sport: "hockey",
    players: [
      // Current stars
      "Connor McDavid", "Nathan MacKinnon", "Auston Matthews", "Leon Draisaitl",
      "David Pastrnak", "Cale Makar", "Sidney Crosby", "Alex Ovechkin",
      "Jack Hughes", "Quinn Hughes", "Kirill Kaprizov", "Elias Pettersson",
      "Matthew Tkachuk", "Brady Tkachuk", "Aleksander Barkov",
      "Nikita Kucherov", "Brayden Point", "Sebastian Aho", "Mitch Marner",
      "William Nylander", "Tage Thompson", "Jason Robertson", "Nico Hischier",
      "Trevor Zegras", "Cole Caufield", "Shane Wright", "Matty Beniers",
      "Owen Power", "Simon Edvinsson", "Juraj Slafkovsky",
      // Rising stars & depth
      "Marco Rossi", "Logan Cooley", "Connor Bedard", "Adam Fantilli",
      "Leo Carlsson", "Matvei Michkov", "Zach Benson", "Ryan Leonard",
      "Macklin Celebrini", "Cayden Lindstrom", "Artyom Levshunov", "Ivan Demidov",
      "Rickard Rakell", "Nazem Kadri", "Ryan O'Reilly", "Bo Horvat",
      "Elias Lindholm", "Mikael Backlund", "Anze Kopitar", "Ryan Nugent-Hopkins",
      "Mark Scheifele", "Kyle Connor", "Gabriel Vilardi", "Pierre-Luc Dubois",
      // Legends
      "Wayne Gretzky", "Mario Lemieux", "Gordie Howe", "Bobby Orr",
      "Mark Messier", "Steve Yzerman", "Jaromir Jagr", "Brett Hull",
      "Mike Modano", "Joe Sakic", "Patrick Roy", "Martin Brodeur"
    ]
  },
  soccer: {
    sport: "soccer",
    players: [
      // Current stars
      "Lionel Messi", "Cristiano Ronaldo", "Kylian Mbappe", "Erling Haaland",
      "Vinicius Jr", "Jude Bellingham", "Pedri", "Gavi",
      "Bukayo Saka", "Phil Foden", "Rodri", "Lamine Yamal",
      "Florian Wirtz", "Jamal Musiala", "Declan Rice", "Martin Odegaard",
      "Raphinha", "Federico Valverde", "Toni Kroos", "Neymar",
      "Karim Benzema", "Harry Kane", "Romelu Lukaku", "Lautaro Martinez",
      "Alexia Putellas", "Sam Kerr", "Trinity Rodman", "Alex Morgan",
      // Rising stars & depth
      "Endrick", "Warren Zaire-Emery", "Evan Ferguson", "Mathys Tel",
      "Alejandro Garnacho", "Kobbie Mainoo", "Rasmus Hojlund", "Victor Osimhen",
      "Khvicha Kvaratskhelia", "Leandro Trossard", "Gabriel Martinelli", "Ben White",
      "William Saliba", "Virgil van Dijk", "Trent Alexander-Arnold", "Andrew Robertson",
      "Alisson Becker", "Ederson", "Manuel Neuer", "Marc-Andre ter Stegen",
      "Robert Lewandowski", "Antoine Griezmann", "Ousmane Dembele", "Bernardo Silva",
      "Bruno Fernandes", "Marcus Rashford", "Raheem Sterling", "Sadio Mane",
      "Mohamed Salah", "Heung-min Son", "Son Heung-min", "Christian Pulisic"
    ]
  },
  golf: {
    sport: "golf",
    players: [
      // Current stars
      "Tiger Woods", "Scottie Scheffler", "Rory McIlroy", "Jon Rahm",
      "Brooks Koepka", "Dustin Johnson", "Justin Thomas", "Jordan Spieth",
      "Xander Schauffele", "Patrick Cantlay", "Collin Morikawa", "Viktor Hovland",
      "Max Homa", "Tony Finau", "Shane Lowry", "Tommy Fleetwood",
      "Hideki Matsuyama", "Cameron Smith", "Will Zalatoris", "Sahith Theegala",
      // Rising stars & depth
      "Ludvig Aberg", "Tom Kim", "Akshay Bhatia", "Nick Dunlap",
      "Jackson Suber", "Michael Thorbjornsen", "Neal Shipley", "Christo Lamprecht",
      "Nicolai Hojgaard", "Rasmus Hojgaard", "Matteo Manassero", "Adrien Dumont de Chassart",
      "Keegan Bradley", "Billy Horschel", "Jason Day", "Adam Scott",
      "Matt Fitzpatrick", "Tyrrell Hatton", "Patrick Reed",
      "Rickie Fowler", "Bubba Watson", "Phil Mickelson", "Lee Westwood",
      // Legends
      "Jack Nicklaus", "Arnold Palmer", "Gary Player", "Tom Watson",
      "Nick Faldo", "Greg Norman", "Seve Ballesteros", "Ben Hogan"
    ]
  },
  // Tennis — 2 marketplace slots (hottest players), rest for search
  tennis: {
    sport: "tennis",
    players: [
      // Current stars (hottest first — first 2 go to marketplace)
      "Jannik Sinner", "Carlos Alcaraz", "Novak Djokovic", "Daniil Medvedev",
      "Alexander Zverev", "Casper Ruud", "Holger Rune", "Andrey Rublev",
      "Taylor Fritz", "Tommy Paul", "Ben Shelton", "Frances Tiafoe",
      "Stefanos Tsitsipas", "Grigor Dimitrov", "Hubert Hurkacz", "Alex de Minaur",
      "Ugo Humbert", "Sebastian Korda", "Lorenzo Musetti", "Matteo Berrettini",
      // Women's stars
      "Aryna Sabalenka", "Iga Swiatek", "Coco Gauff", "Elena Rybakina",
      "Jessica Pegula", "Barbora Krejcikova", "Madison Keys", "Emma Navarro",
      "Mirra Andreeva", "Paula Badosa", "Jasmine Paolini", "Danielle Collins",
      // Legends
      "Roger Federer", "Rafael Nadal", "Serena Williams", "Venus Williams",
      "Andre Agassi", "Pete Sampras", "Steffi Graf", "Martina Navratilova",
      "John McEnroe", "Jimmy Connors", "Billie Jean King", "Chris Evert"
    ]
  },
  // MMA — search-only (isSearchOnly: true), 50 cards max
  mma: {
    sport: "mma",
    players: [
      // Current champions & stars
      "Jon Jones", "Islam Makhachev", "Leon Edwards", "Alex Pereira",
      "Sean O'Malley", "Ilia Topuria", "Dricus du Plessis", "Tom Aspinall",
      "Merab Dvalishvili", "Belal Muhammad", "Dustin Poirier", "Max Holloway",
      "Charles Oliveira", "Justin Gaethje", "Paddy Pimblett", "Conor McGregor",
      "Khabib Nurmagomedov", "Stipe Miocic", "Francis Ngannou", "Ciryl Gane",
      "Valentina Shevchenko", "Zhang Weili", "Alexa Grasso", "Amanda Nunes",
      "Rose Namajunas", "Julianna Pena", "Miesha Tate", "Holly Holm",
      "Ronda Rousey", "Nate Diaz", "Nick Diaz", "Jorge Masvidal",
      "Colby Covington", "Kamaru Usman", "Robert Whittaker", "Paulo Costa",
      "Israel Adesanya", "Sean Strickland", "Jiri Prochazka", "Jamahal Hill",
      "Magomed Ankalaev", "Khalil Rountree", "Bo Nickal", "Sean Brady",
      "Shavkat Rakhmonov", "Geoff Neal", "Michael Chandler", "Tony Ferguson"
    ]
  },
  // Boxing — search-only (isSearchOnly: true), 50 cards max
  boxing: {
    sport: "boxing",
    players: [
      // Current champions & stars
      "Canelo Alvarez", "Terence Crawford", "Errol Spence Jr", "Gervonta Davis",
      "Ryan Garcia", "Devin Haney", "Shakur Stevenson", "Naoya Inoue",
      "Oleksandr Usyk", "Tyson Fury", "Anthony Joshua", "Deontay Wilder",
      "David Benavidez", "Jermall Charlo", "Jermell Charlo", "Vergil Ortiz Jr",
      "Jose Ramirez", "Jose Zepeda", "Regis Prograis", "Josh Taylor",
      "Katie Taylor", "Amanda Serrano", "Claressa Shields", "Seniesa Estrada",
      "Jake Paul", "KSI", "Logan Paul", "Tommy Fury",
      // Legends
      "Muhammad Ali", "Mike Tyson", "Floyd Mayweather Jr", "Oscar De La Hoya",
      "Manny Pacquiao", "Sugar Ray Leonard", "Marvin Hagler", "Thomas Hearns",
      "Roberto Duran", "Joe Frazier", "George Foreman", "Lennox Lewis",
      "Evander Holyfield", "Larry Holmes", "Joe Louis", "Rocky Marciano",
      "Sugar Ray Robinson", "Willie Pep", "Archie Moore", "Jersey Joe Walcott"
    ]
  }
};

// Grade detection patterns — company values MUST match DB enum: PSA, Beckett, SGC, TGA, CGC, other, none
const GRADE_PATTERNS = [
  { regex: /PSA\s*(\d+(?:\.\d+)?)/i, company: "PSA" },
  { regex: /BGS\s*(\d+(?:\.\d+)?)/i, company: "Beckett" },
  { regex: /SGC\s*(\d+(?:\.\d+)?)/i, company: "SGC" },
  { regex: /BVG\s*(\d+(?:\.\d+)?)/i, company: "Beckett" },
  { regex: /Beckett\s*(\d+(?:\.\d+)?)/i, company: "Beckett" },
  { regex: /CSG\s*(\d+(?:\.\d+)?)/i, company: "other" },
];

export function detectGrade(title: string): { company: string; score: string } | null {
  for (const { regex, company } of GRADE_PATTERNS) {
    const match = title.match(regex);
    if (match) {
      return { company, score: match[1] };
    }
  }
  return null;
}

export function detectSport(playerName: string): string {
  for (const [key, { sport, players }] of Object.entries(SPORT_PLAYERS)) {
    if (players.some(p => p.toLowerCase() === playerName.toLowerCase())) {
      return sport;
    }
  }
  return "other";
}

interface EbayItem {
  itemId: string;
  title: string;
  price: { value: string; currency: string };
  shippingOptions?: Array<{ shippingCost: { value: string; currency: string }; shippingCostType: string }>;
  image?: { imageUrl: string };
  itemWebUrl: string;
  condition?: string;
}

async function getEbayToken(): Promise<string> {
  const clientId = process.env.EBAY_CLIENT_ID!;
  const clientSecret = process.env.EBAY_CLIENT_SECRET!;
  const credentials = Buffer.from(`${clientId}:${clientSecret}`).toString("base64");

  const res = await fetch("https://api.ebay.com/identity/v1/oauth2/token", {
    method: "POST",
    headers: {
      "Authorization": `Basic ${credentials}`,
      "Content-Type": "application/x-www-form-urlencoded",
    },
    body: "grant_type=client_credentials&scope=https://api.ebay.com/oauth/api_scope",
  });

  const data = await res.json() as any;
  if (!data.access_token) throw new Error(`eBay OAuth failed: ${JSON.stringify(data)}`);
  return data.access_token;
}

async function searchEbayCards(token: string, query: string, limit = 5, gradeKeyword = ""): Promise<EbayItem[]> {
  const params = new URLSearchParams({
    q: gradeKeyword ? `${query} ${gradeKeyword} sports card` : `${query} sports card`,
    category_ids: "212",  // Sports Trading Cards
    limit: String(limit),
    sort: "newlyListed",
    filter: "buyingOptions:{FIXED_PRICE},conditions:{NEW|LIKE_NEW|VERY_GOOD|GOOD}",  // shipping handled in code
  });

  const res = await fetch(`https://api.ebay.com/buy/browse/v1/item_summary/search?${params}`, {
    headers: {
      "Authorization": `Bearer ${token}`,
      "X-EBAY-C-MARKETPLACE-ID": "EBAY_US",
      "Content-Type": "application/json",
    },
  });

  if (!res.ok) return [];
  const data = await res.json() as any;
  return data.itemSummaries || [];
}

export async function importEbayDropshipCards(options: {
  sport?: string;
  playersPerSport?: number;
  cardsPerPlayer?: number;
  maxTotal?: number;
  gradeCompanyFilter?: "PSA" | "Beckett" | null;  // null = BGS only (default)
  gradeFloor?: number;  // override grade floor (default: 8.0 for BGS, 8 for PSA)
} = {}): Promise<{ imported: number; skipped: number; errors: string[] }> {
  const {
    sport: filterSport,
    playersPerSport = 10,
    cardsPerPlayer = 3,
    maxTotal = 500,
    gradeCompanyFilter = null,  // null = BGS only (legacy default)
    gradeFloor,
  } = options;
  // Determine which company to import and what grade keyword to search
  const targetCompany = gradeCompanyFilter || "Beckett";
  const searchKeyword = targetCompany === "PSA" ? "PSA" : "BGS";
  const effectiveGradeFloor = gradeFloor ?? (targetCompany === "PSA" ? 8 : 8.0);

  const db = await getDb();
  if (!db) throw new Error("DB unavailable");

  const token = await getEbayToken();
  let imported = 0;
  let skipped = 0;
  const errors: string[] = [];

  const sportsToProcess = filterSport
    ? { [filterSport]: SPORT_PLAYERS[filterSport] }
    : SPORT_PLAYERS;

  for (const [sportKey, { sport, players }] of Object.entries(sportsToProcess)) {
    const playersToProcess = players.slice(0, playersPerSport);

    for (const player of playersToProcess) {
      if (imported >= maxTotal) break;

      try {
        // Search for cards matching the target grading company
        const items = await searchEbayCards(token, player, cardsPerPlayer * 3, searchKeyword);

        for (const item of items.slice(0, cardsPerPlayer)) {
          if (imported >= maxTotal) break;

          // Skip if we already have this eBay item
          const existing = await db.select({ id: cards.id })
            .from(cards)
            .where(eq(cards.ebayItemId, item.itemId))
            .limit(1);

          if (existing.length > 0) {
            skipped++;
            continue;
          }

          const sourcePrice = parseFloat(item.price.value);
          if (isNaN(sourcePrice) || sourcePrice <= 0) { skipped++; continue; }

          // LOCKED RULE: minimum $10 source price before 20% markup
          if (sourcePrice < 10) { skipped++; continue; }

          // RULE: max $5000 source price cap for BGS graded cards (premium graded market)
          if (sourcePrice > 5000) { skipped++; continue; }

          // RULE: For BGS graded cards, allow shipping up to $10 (graded slabs need insurance)
          const shippingOption = item.shippingOptions?.[0];
          const shippingCostValue = parseFloat(shippingOption?.shippingCost?.value || "0");
          const isFreeShipping = !shippingOption
            || shippingOption.shippingCostType === "FREE"
            || shippingCostValue === 0;
          const isAffordableShipping = shippingCostValue <= 10;
          if (!isFreeShipping && !isAffordableShipping) { skipped++; continue; }
          const shippingCost = isFreeShipping ? 0 : shippingCostValue;

          // Apply 20% markup to card price (shipping stays at cost)
          const markedUpPrice = Math.ceil(sourcePrice * MARKUP * 100) / 100;

          // Detect grade from title
          const grade = detectGrade(item.title);

          // Filter by target grading company
          if (!grade || grade.company !== targetCompany) { skipped++; continue; }
          // Grade floor filter
          const gradeNum = parseFloat(grade.score);
           if (gradeNum < effectiveGradeFloor) { skipped++; continue; }
          // Extract year from title (look for 4-digit year)
          const yearMatch = item.title.match(/\b(19|20)\d{2}\b/);
          const year = yearMatch ? yearMatch[0] : new Date().getFullYear().toString();

          // Build a clean card title
          const title = item.title.length > 200 ? item.title.substring(0, 200) : item.title;

          try {
            await createCard({
              title,
              playerName: player,
              year,
              setName: "",
              cardNumber: "",
              sport,
              condition: grade ? "graded" : "raw",
              gradeCompany: grade?.company || null,
              gradeScore: grade?.score || null,
              price: markedUpPrice.toFixed(2),
              cardShippingFee: null, // LOCKED: free shipping only — always null
              category: "modern",
              status: "active",
              description: `Source: eBay listing. Original price: $${sourcePrice.toFixed(2)}. Shipping: Free.`,
              frontImageUrl: (item.image?.imageUrl || '').replace('s-l225', 's-l1600').replace('s-l500', 's-l1600') || undefined, // LOCKED: always full-size image
              sellerEmail: "admin@sportcardsonline.com",
              storeName: "SCO House",
              isMainStore: true,
              source: "ebay_import",
              ebayItemId: item.itemId,
              ebayListingUrl: item.itemWebUrl,
              sourcePrice: sourcePrice.toFixed(2),
              isDropship: true,
              aiGrade: grade ? grade.score : null,
              aiGradeLabel: grade ? `${grade.company} ${grade.score}` : null,
            } as any);
            imported++;
          } catch (e: any) {
            errors.push(`${player} - ${item.itemId}: ${e.message}`);
          }
        }

        // Small delay to avoid rate limiting
        await new Promise(r => setTimeout(r, 200));
      } catch (e: any) {
        errors.push(`${player}: ${e.message}`);
      }
    }
  }

  return { imported, skipped, errors };
}

export async function checkEbayAvailability(ebayItemId: string): Promise<{
  available: boolean;
  currentPrice?: number;
  title?: string;
}> {
  try {
    const token = await getEbayToken();
    // ebayItemId may already be in v1|XXXXX|0 format from the Browse API
    const itemPath = ebayItemId.startsWith('v1|') ? ebayItemId : `v1|${ebayItemId}|0`;
    const res = await fetch(`https://api.ebay.com/buy/browse/v1/item/${itemPath}`, {
      headers: {
        "Authorization": `Bearer ${token}`,
        "X-EBAY-C-MARKETPLACE-ID": "EBAY_US",
      },
    });

    if (res.status === 404 || res.status === 410) {
      return { available: false };
    }

    if (!res.ok) return { available: false };

    const data = await res.json() as any;

    // Check if item is still available
    if (data.buyingOptions?.includes("FIXED_PRICE") === false) {
      return { available: false };
    }

    const price = parseFloat(data.price?.value || "0");
    return {
      available: true,
      currentPrice: price,
      title: data.title,
    };
  } catch {
    return { available: false };
  }
}
