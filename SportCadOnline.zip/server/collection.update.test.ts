import { describe, expect, it, vi, beforeEach } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

// Mock the db module so tests don't need a real database
vi.mock("./db", async (importOriginal) => {
  const actual = await importOriginal<typeof import("./db")>();
  return {
    ...actual,
    getCollectionItemById: vi.fn(),
    updateCollectionItem: vi.fn(),
    deleteCollectionItem: vi.fn(),
    createCollectionItem: vi.fn(),
    getCollectionByOwnerEmail: vi.fn(),
    createCard: vi.fn(),
    getStoreByOwnerEmail: vi.fn(),
    getDb: vi.fn().mockResolvedValue(null),
  };
});

import {
  getCollectionItemById,
  updateCollectionItem,
  deleteCollectionItem,
  createCard,
  getStoreByOwnerEmail,
} from "./db";

const mockGetCollectionItemById = vi.mocked(getCollectionItemById);
const mockUpdateCollectionItem = vi.mocked(updateCollectionItem);
const mockDeleteCollectionItem = vi.mocked(deleteCollectionItem);
const mockCreateCard = vi.mocked(createCard);
const mockGetStoreByOwnerEmail = vi.mocked(getStoreByOwnerEmail);

function createAuthContext(email = "owner@test.com"): TrpcContext {
  return {
    user: {
      id: 1,
      openId: "test-user",
      email,
      name: "Test User",
      loginMethod: "manus",
      role: "user",
      createdAt: new Date(),
      updatedAt: new Date(),
      lastSignedIn: new Date(),
    },
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: { clearCookie: vi.fn() } as unknown as TrpcContext["res"],
  };
}

const mockCollectionItem = {
  id: 42,
  ownerEmail: "owner@test.com",
  cardTitle: "2003 Topps Chrome LeBron James RC",
  playerName: "LeBron James",
  year: "2003",
  setName: "Topps Chrome",
  cardNumber: "111",
  sport: "basketball" as const,
  frontImageUrl: "https://cdn.example.com/front.jpg",
  backImageUrl: "https://cdn.example.com/back.jpg",
  extraImageUrls: null,
  overallGrade: "9.50",
  gradeLabel: "Mint",
  centeringScore: "9",
  cornersScore: "9.5",
  edgesScore: "9.5",
  surfaceScore: "10",
  estimatedValueLow: "500.00",
  estimatedValueHigh: "700.00",
  certNumber: "SCG-12345",
  description: "Test card",
  listingStatus: "none" as const,
  linkedCardId: null,
  createdAt: new Date(),
  updatedAt: new Date(),
};

describe("collection.update", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("updates extraImageUrls for an owned collection item", async () => {
    mockGetCollectionItemById.mockResolvedValue(mockCollectionItem);
    mockUpdateCollectionItem.mockResolvedValue({
      ...mockCollectionItem,
      extraImageUrls: ["https://cdn.example.com/extra1.jpg"],
    });

    const ctx = createAuthContext("owner@test.com");
    const caller = appRouter.createCaller(ctx);

    const result = await caller.collection.update({
      id: 42,
      extraImageUrls: ["https://cdn.example.com/extra1.jpg"],
    });

    expect(mockGetCollectionItemById).toHaveBeenCalledWith(42);
    expect(mockUpdateCollectionItem).toHaveBeenCalledWith(42, {
      extraImageUrls: ["https://cdn.example.com/extra1.jpg"],
    });
    expect(result?.extraImageUrls).toEqual(["https://cdn.example.com/extra1.jpg"]);
  });

  it("throws FORBIDDEN when user does not own the collection item", async () => {
    mockGetCollectionItemById.mockResolvedValue(mockCollectionItem);

    const ctx = createAuthContext("other@test.com");
    const caller = appRouter.createCaller(ctx);

    await expect(
      caller.collection.update({ id: 42, extraImageUrls: [] })
    ).rejects.toThrow();
  });

  it("updates labelColor for an owned collection item", async () => {
    mockGetCollectionItemById.mockResolvedValue(mockCollectionItem);
    mockUpdateCollectionItem.mockResolvedValue({
      ...mockCollectionItem,
    });

    const ctx = createAuthContext("owner@test.com");
    const caller = appRouter.createCaller(ctx);

    await caller.collection.update({ id: 42, labelColor: "ruby" });

    expect(mockUpdateCollectionItem).toHaveBeenCalledWith(42, {
      labelColor: "ruby",
    });
  });
});

describe("collection.bulkDelete", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("deletes multiple owned collection items", async () => {
    mockGetCollectionItemById
      .mockResolvedValueOnce({ ...mockCollectionItem, id: 1 })
      .mockResolvedValueOnce({ ...mockCollectionItem, id: 2 });
    mockDeleteCollectionItem.mockResolvedValue(undefined);

    const ctx = createAuthContext("owner@test.com");
    const caller = appRouter.createCaller(ctx);

    const result = await caller.collection.bulkDelete({ ids: [1, 2] });

    expect(result).toEqual({ success: true, count: 2 });
    expect(mockDeleteCollectionItem).toHaveBeenCalledTimes(2);
  });

  it("skips items not owned by the user", async () => {
    mockGetCollectionItemById
      .mockResolvedValueOnce({ ...mockCollectionItem, id: 1, ownerEmail: "other@test.com" })
      .mockResolvedValueOnce({ ...mockCollectionItem, id: 2 });
    mockDeleteCollectionItem.mockResolvedValue(undefined);

    const ctx = createAuthContext("owner@test.com");
    const caller = appRouter.createCaller(ctx);

    const result = await caller.collection.bulkDelete({ ids: [1, 2] });

    // Returns count of IDs passed, but only deletes owned ones
    expect(result).toEqual({ success: true, count: 2 });
    expect(mockDeleteCollectionItem).toHaveBeenCalledTimes(1);
    expect(mockDeleteCollectionItem).toHaveBeenCalledWith(2);
  });
});

describe("collection.bulkListToArena", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("lists multiple owned cards to the arena", async () => {
    mockGetCollectionItemById
      .mockResolvedValueOnce({ ...mockCollectionItem, id: 10 })
      .mockResolvedValueOnce({ ...mockCollectionItem, id: 11 });
    mockGetStoreByOwnerEmail.mockResolvedValue(null);
    mockCreateCard.mockResolvedValue({
      id: 100,
      title: mockCollectionItem.cardTitle,
      playerName: mockCollectionItem.playerName,
      price: "49.99",
      status: "active",
      sellerEmail: "owner@test.com",
    } as any);

    const ctx = createAuthContext("owner@test.com");
    const caller = appRouter.createCaller(ctx);

    const result = await caller.collection.bulkListToArena({ ids: [10, 11], price: "49.99" });

    expect(result).toEqual({ success: true, count: 2 });
    expect(mockCreateCard).toHaveBeenCalledTimes(2);
  });
});
