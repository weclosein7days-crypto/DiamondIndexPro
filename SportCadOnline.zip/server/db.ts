import { eq, desc, and, or, like, sql, inArray, notInArray } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  InsertUser,
  users,
  stores,
  cards,
  collections,
  auctions,
  bids,
  orders,
  trades,
  messages,
  creditAccounts,
  creditTransactions,
  cardFingerprints,
  gradeRequests,
  showcases,
  wishlists,
  type Store,
  type Card,
  type Collection,
  type Auction,
  type Order,
  type Trade,
  type CreditAccount,
  type InsertCard,
  type InsertCollection,
  type InsertAuction,
  type InsertBid,
  type InsertOrder,
  type InsertTrade,
  type InsertMessage,
  type InsertCreditAccount,
  type InsertCreditTransaction,
  type InsertCardFingerprint,
  type InsertGradeRequest,
  orderMessages,
  type OrderMessage,
  type InsertOrderMessage,
  favorites,
  userInterests,
  type Favorite,
  type UserInterest,
} from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

// ============================================================================
// USER MANAGEMENT
// ============================================================================

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = { openId: user.openId };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = "admin";
      updateSet.role = "admin";
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getUserByEmail(email: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.email, email)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

// ============================================================================
// STORES
// ============================================================================

export async function getStoreByOwnerEmail(ownerEmail: string): Promise<Store | undefined> {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(stores).where(eq(stores.ownerEmail, ownerEmail)).limit(1);
  return result[0];
}

export async function createStore(data: typeof stores.$inferInsert): Promise<Store> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(stores).values(data);
  const insertedId = Number(result[0].insertId);
  const store = await db.select().from(stores).where(eq(stores.id, insertedId)).limit(1);
  return store[0]!;
}

// ============================================================================
// CARDS (MARKETPLACE)
// ============================================================================

/**
 * Returns active marketplace cards with sport-weighted distribution and $500 cap.
 *
 * Sport quotas (default / no-filter mode):
 *   Basketball: 25% | Football: 15% | Baseball: 15% | Hockey: 5% | Soccer: 5% | Other: 10%
 *   Remaining 25% fills from any sport (house priority)
 *
 * LOCKED RULES:
 *   - Minimum price: $10
 *   - Maximum price: $500 (higher-value cards are searchable but not shown in default list)
 *   - House cards (isMainStore=true) always prioritised within each sport bucket (70/30 split)
 */
export async function getActiveCards(limit = 200, sport?: string, search?: string): Promise<Card[]> {
  const db = await getDb();
  if (!db) return [];

  const PRICE_FILTER = sql`CAST(${cards.price} AS DECIMAL(10,2)) BETWEEN 10.00 AND 500.00`;

  // ── Filtered mode (sport or search active) ────────────────────────────────
  if ((sport && sport.toLowerCase() !== "all") || search) {
    const conditions: any[] = [
      eq(cards.status, "active"),
      PRICE_FILTER,
    ];
    if (sport && sport.toLowerCase() !== "all") {
      conditions.push(eq(cards.sport, sport.toLowerCase() as any));
    }
    if (search && search.trim()) {
      const term = `%${search.trim()}%`;
      conditions.push(or(like(cards.playerName, term), like(cards.title, term), like(cards.setName, term)));
    }
    const [houseCards, sourcedCards] = await Promise.all([
      db.select().from(cards).where(and(...conditions, eq(cards.isMainStore, true))).orderBy(sql`RAND()`).limit(limit),
      db.select().from(cards).where(and(...conditions, eq(cards.isMainStore, false))).orderBy(sql`RAND()`).limit(limit),
    ]);
    return [...houseCards, ...sourcedCards].slice(0, limit);
  }

  // ── Default mode: sport-weighted distribution ─────────────────────────────
  // Basketball 25%, Football 15%, Baseball 15%, Hockey 5%, Soccer 5%, Other 10%
  // Remaining 25% = overflow fill from any sport (house priority)
  const sportQuotas: Array<{ sport: string; pct: number }> = [
    { sport: "basketball", pct: 0.25 },
    { sport: "football",   pct: 0.15 },
    { sport: "baseball",   pct: 0.15 },
    { sport: "hockey",     pct: 0.05 },
    { sport: "soccer",     pct: 0.05 },
    { sport: "other",      pct: 0.10 },
  ];

  const bucketResults = await Promise.all(
    sportQuotas.map(async ({ sport: s, pct }) => {
      const quota = Math.max(2, Math.round(limit * pct));
      const houseQuota = Math.ceil(quota * 0.7);
      const sourcedQuota = quota - houseQuota;
      const [h, src] = await Promise.all([
        db.select().from(cards)
          .where(and(eq(cards.status, "active"), PRICE_FILTER, eq(cards.sport, s as any), eq(cards.isMainStore, true)))
          .orderBy(sql`RAND()`).limit(houseQuota),
        db.select().from(cards)
          .where(and(eq(cards.status, "active"), PRICE_FILTER, eq(cards.sport, s as any), eq(cards.isMainStore, false)))
          .orderBy(sql`RAND()`).limit(sourcedQuota),
      ]);
      return [...h, ...src].slice(0, quota);
    })
  );

  const sportCards = bucketResults.flat();
  const usedIds = new Set(sportCards.map(c => c.id));

  // Fill remaining slots with any-sport house cards not already included
  const remaining = limit - sportCards.length;
  let fillCards: Card[] = [];
  if (remaining > 0) {
    const fillRaw = await db
      .select().from(cards)
      .where(and(eq(cards.status, "active"), PRICE_FILTER, eq(cards.isMainStore, true)))
      .orderBy(sql`RAND()`)
      .limit(remaining * 3);
    fillCards = fillRaw.filter(c => !usedIds.has(c.id)).slice(0, remaining);
  }

  return [...sportCards, ...fillCards];
}

// ── Top 50 curated marketplace cards ─────────────────────────────────────────
// 60% house cards (top-priced, max 2 per player), 40% sourced (sport-split)
export async function getTop50Cards(): Promise<Card[]> {
  const db = await getDb();
  if (!db) return [];

  // House: top 30 by price, max 2 per player
  const houseRaw = await db
    .select().from(cards)
    .where(and(eq(cards.status, "active"), eq(cards.isMainStore, true)))
    .orderBy(sql`CAST(${cards.price} AS DECIMAL(10,2)) DESC`)
    .limit(300);
  const houseSeen: Record<string, number> = {};
  const houseResult: Card[] = [];
  for (const c of houseRaw) {
    const key = (c.playerName ?? "x").toLowerCase();
    houseSeen[key] = (houseSeen[key] || 0) + 1;
    if (houseSeen[key] <= 2) houseResult.push(c);
    if (houseResult.length >= 30) break;
  }

  // Sourced: sport-split quotas
  const sportQuotas: Array<{ sport: string; limit: number }> = [
    { sport: "basketball", limit: 10 },
    { sport: "baseball", limit: 5 },
    { sport: "football", limit: 5 },
    { sport: "hockey", limit: 3 },
    { sport: "soccer", limit: 2 },
    { sport: "other", limit: 2 },
  ];
  const sourcedResult: Card[] = [];
  await Promise.all(sportQuotas.map(async ({ sport: s, limit: lim }) => {
    const rows = await db.select().from(cards)
      .where(and(eq(cards.status, "active"), eq(cards.isMainStore, false), eq(cards.sport, s as any)))
      .orderBy(sql`CAST(${cards.price} AS DECIMAL(10,2)) DESC`)
      .limit(lim * 4);
    const seen: Record<string, number> = {};
    let added = 0;
    for (const c of rows) {
      const key = (c.playerName ?? "x").toLowerCase();
      seen[key] = (seen[key] || 0) + 1;
      if (seen[key] <= 1 && added < lim) { sourcedResult.push(c); added++; }
    }
  }));

  return [...houseResult, ...sourcedResult].slice(0, 50);
}

// ── Seasonal Picks ────────────────────────────────────────────────────────────
export async function getSeasonalPicks(): Promise<{ theme: string; label: string; emoji: string; cards: Card[] }[]> {
  const db = await getDb();
  if (!db) return [];
  const month = new Date().getMonth() + 1;

  const sections: Array<{ theme: string; label: string; emoji: string; players: string[] }> = [];

  // April–May: Final Four / March Madness + MLB Opening Day
  if (month >= 3 && month <= 5) {
    sections.push({ theme: "final_four", label: "🏀 Final Four Buzz", emoji: "🏀",
      players: ["Cooper Flagg", "Paige Bueckers", "Kon Knueppel", "Dylan Harper", "Ace Bailey", "Tre Johnson", "VJ Edgecombe", "Johni Broome", "Caitlin Clark", "Angel Reese"] });
    sections.push({ theme: "mlb_opening", label: "⚾ MLB Opening Day", emoji: "⚾",
      players: ["Paul Skenes", "Elly De La Cruz", "Shohei Ohtani", "Aaron Judge", "Gunnar Henderson", "Bobby Witt Jr.", "Jackson Holliday", "James Wood", "Wyatt Langford", "Colt Keith"] });
  }
  // June–August: WNBA + NFL preseason
  if (month >= 6 && month <= 8) {
    sections.push({ theme: "wnba_season", label: "🏀 WNBA Season", emoji: "🏀",
      players: ["Caitlin Clark", "Paige Bueckers", "Angel Reese", "A'ja Wilson", "Sabrina Ionescu", "Kate Martin", "Aziaha James", "Rickea Jackson", "Breanna Stewart", "Diana Taurasi"] });
    sections.push({ theme: "nfl_preseason", label: "🏈 NFL Draft Buzz", emoji: "🏈",
      players: ["Cam Ward", "Travis Hunter", "Ashton Jeanty", "Shedeur Sanders", "Abdul Carter", "Tetairoa McMillan", "Patrick Mahomes", "Josh Allen", "Lamar Jackson", "Caleb Williams"] });
  }
  // September–January: NFL season + NBA tip-off
  if (month >= 9 || month <= 1) {
    sections.push({ theme: "nfl_season", label: "🏈 NFL Season Hot Picks", emoji: "🏈",
      players: ["Patrick Mahomes", "Josh Allen", "Lamar Jackson", "Jalen Hurts", "Brock Purdy", "CJ Stroud", "Jayden Daniels", "Caleb Williams", "Drake Maye", "Bo Nix"] });
    sections.push({ theme: "nba_tipoff", label: "🏀 NBA Tip-Off", emoji: "🏀",
      players: ["Victor Wembanyama", "LeBron James", "Luka Doncic", "Jayson Tatum", "Giannis Antetokounmpo", "Nikola Jokic", "Anthony Edwards", "Shai Gilgeous-Alexander", "Donovan Mitchell", "Tyrese Haliburton"] });
  }
  // February–April: NBA All-Star + NHL playoff push
  if (month >= 2 && month <= 4) {
    sections.push({ theme: "nba_allstar", label: "⭐ NBA All-Star Picks", emoji: "⭐",
      players: ["LeBron James", "Luka Doncic", "Jayson Tatum", "Giannis Antetokounmpo", "Nikola Jokic", "Anthony Edwards", "Shai Gilgeous-Alexander", "Donovan Mitchell", "Tyrese Haliburton", "Jaylen Brown"] });
    sections.push({ theme: "nhl_playoffs", label: "🏒 NHL Playoff Push", emoji: "🏒",
      players: ["Connor McDavid", "Sidney Crosby", "Auston Matthews", "Connor Bedard", "Macklin Celebrini", "Matthew Knies", "Nathan MacKinnon", "David Pastrnak", "Cale Makar", "Matvei Michkov"] });
  }
  // Always: Soccer
  sections.push({ theme: "soccer_stars", label: "⚽ World Soccer Stars", emoji: "⚽",
    players: ["Lionel Messi", "Kylian Mbappe", "Lamine Yamal", "Jude Bellingham", "Erling Haaland", "Vinicius Jr", "Florian Wirtz", "Cavan Sullivan", "Gio Reyna", "Pedri"] });

  const results: { theme: string; label: string; emoji: string; cards: Card[] }[] = [];
  for (const section of sections.slice(0, 5)) {
    const sectionCards: Card[] = [];
    for (const playerName of section.players) {
      const rows = await db.select().from(cards)
        .where(and(eq(cards.status, "active"), sql`LOWER(${cards.playerName}) LIKE ${`%${playerName.toLowerCase()}%`}`))        
        .orderBy(sql`isMainStore DESC, CAST(${cards.price} AS DECIMAL(10,2)) DESC`)
        .limit(2);
      if (rows.length > 0) sectionCards.push(rows[0]);
      if (sectionCards.length >= 12) break;
    }
    if (sectionCards.length >= 2) results.push({ theme: section.theme, label: section.label, emoji: section.emoji, cards: sectionCards });
  }
  return results;
}

// ── Pro Rookies ───────────────────────────────────────────────────────────────
export async function getProRookies(): Promise<{ sport: string; label: string; emoji: string; cards: Card[] }[]> {
  const db = await getDb();
  if (!db) return [];
  const month = new Date().getMonth() + 1;

  const groups: Array<{ sport: string; label: string; emoji: string; players: string[]; priority: number }> = [
    { sport: "basketball", label: "WNBA Rookies", emoji: "🏀",
      players: ["Paige Bueckers", "Kiki Iriafen", "Aziaha James", "Aneesah Morrow", "Aliyah Boston", "Rickea Jackson", "DiJonai Carrington", "Angel Reese", "Kate Martin", "Stephanie Soares"],
      priority: month >= 3 && month <= 7 ? 1 : 3 },
    { sport: "basketball", label: "NBA Rookies", emoji: "🏀",
      players: ["Kon Knueppel", "Cooper Flagg", "Zaccharie Risacher", "Alex Sarr", "Stephon Castle", "Matas Buzelis", "Donovan Clingan", "Cody Williams", "Jaylen Wells", "Nikola Topic"],
      priority: month >= 10 || month <= 4 ? 1 : 2 },
    { sport: "football", label: "NFL Draft Class '25", emoji: "🏈",
      players: ["Cam Ward", "Travis Hunter", "Ashton Jeanty", "Shedeur Sanders", "Abdul Carter", "Will Johnson", "Mason Graham", "Tetairoa McMillan", "Kelvin Banks Jr", "Malaki Starks"],
      priority: month >= 4 && month <= 9 ? 1 : 2 },
    { sport: "baseball", label: "MLB Rookies", emoji: "⚾",
      players: ["Paul Skenes", "Jackson Holliday", "James Wood", "Wyatt Langford", "Colton Cowser", "Colt Keith", "Yoshinobu Yamamoto", "Kyle Manzardo", "Hurston Waldrep", "Jurrangelo Cijntje"],
      priority: month >= 3 && month <= 10 ? 1 : 3 },
    { sport: "hockey", label: "NHL Rookies", emoji: "🏒",
      players: ["Macklin Celebrini", "Connor Bedard", "Matthew Knies", "Matvei Michkov", "Leo Carlsson", "Will Smith", "Brayden Yager", "Dalibor Dvorsky", "Zach Benson", "Axel Sandin Pellikka"],
      priority: month >= 10 || month <= 4 ? 1 : 3 },
    { sport: "soccer", label: "Soccer Rising Stars", emoji: "⚽",
      players: ["Lamine Yamal", "Cavan Sullivan", "Florian Wirtz", "Gio Reyna", "Jude Bellingham", "Endrick", "Warren Zaire-Emery", "Kobbie Mainoo", "Pedri", "Gavi"],
      priority: 2 },
  ];

  groups.sort((a, b) => a.priority - b.priority);

  const results: { sport: string; label: string; emoji: string; cards: Card[] }[] = [];
  for (const group of groups) {
    const groupCards: Card[] = [];
    for (const playerName of group.players) {
      const rows = await db.select().from(cards)
        .where(and(eq(cards.status, "active"), sql`LOWER(${cards.playerName}) LIKE ${`%${playerName.toLowerCase()}%`}`))        
        .orderBy(sql`isMainStore DESC, CAST(${cards.price} AS DECIMAL(10,2)) DESC`)
        .limit(2);
      if (rows.length > 0) groupCards.push(rows[0]);
      if (groupCards.length >= 10) break;
    }
    if (groupCards.length >= 2) results.push({ sport: group.sport, label: group.label, emoji: group.emoji, cards: groupCards });
  }
  return results;
}

export async function getCardById(id: number): Promise<Card | undefined> {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(cards).where(eq(cards.id, id)).limit(1);
  return result[0];
}

export async function getCardsBySellerEmail(sellerEmail: string): Promise<Card[]> {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(cards).where(eq(cards.sellerEmail, sellerEmail)).orderBy(desc(cards.createdAt));
}

export async function createCard(data: InsertCard): Promise<Card> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(cards).values(data);
  const insertedId = Number(result[0].insertId);
  const card = await db.select().from(cards).where(eq(cards.id, insertedId)).limit(1);
  return card[0]!;
}

export async function updateCard(id: number, data: Partial<InsertCard>): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(cards).set(data).where(eq(cards.id, id));
}

export async function deleteCard(id: number): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(cards).where(eq(cards.id, id));
}

// ============================================================================
// COLLECTIONS
// ============================================================================

export async function getCollectionByOwnerEmail(ownerEmail: string): Promise<Collection[]> {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(collections).where(eq(collections.ownerEmail, ownerEmail)).orderBy(desc(collections.createdAt));
}

export async function getCollectionItemById(id: number): Promise<Collection | undefined> {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(collections).where(eq(collections.id, id)).limit(1);
  return result[0];
}

export async function createCollectionItem(data: InsertCollection): Promise<Collection> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(collections).values(data);
  const insertedId = Number(result[0].insertId);
  const item = await db.select().from(collections).where(eq(collections.id, insertedId)).limit(1);
  return item[0]!;
}

export async function updateCollectionItem(id: number, data: Partial<InsertCollection>): Promise<Collection | undefined> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(collections).set(data).where(eq(collections.id, id));
  const result = await db.select().from(collections).where(eq(collections.id, id)).limit(1);
  return result[0];
}

export async function deleteCollectionItem(id: number): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(collections).where(eq(collections.id, id));
}

// ============================================================================
// AUCTIONS
// ============================================================================

export type AuctionWithCardDetails = Auction & {
  frontImageUrl?: string | null;
  backImageUrl?: string | null;
  extraImageUrls?: string[] | null;
  labelColor?: string | null;
  year?: string | null;
  setName?: string | null;
  cardNumber?: string | null;
  sport?: string | null;
  description?: string | null;
  aiGrade?: string | null;
  aiGradeLabel?: string | null;
  aiCentering?: string | null;
  aiCorners?: string | null;
  aiEdges?: string | null;
  aiSurface?: string | null;
  aiCertNumber?: string | null;
  certNumber?: string | null;
};

export async function getActiveAuctions(limit = 200): Promise<AuctionWithCardDetails[]> {
  const db = await getDb();
  if (!db) return [];
  const rows = await db
    .select({
      // All auction fields
      id: auctions.id,
      cardId: auctions.cardId,
      cardTitle: auctions.cardTitle,
      cardImageUrl: auctions.cardImageUrl,
      sellerEmail: auctions.sellerEmail,
      storeName: auctions.storeName,
      startingPrice: auctions.startingPrice,
      currentBid: auctions.currentBid,
      highestBidderEmail: auctions.highestBidderEmail,
      highestBidderName: auctions.highestBidderName,
      bidCount: auctions.bidCount,
      endTime: auctions.endTime,
      status: auctions.status,
      playerName: auctions.playerName,
      gradeInfo: auctions.gradeInfo,
      durationDays: auctions.durationDays,
      listingCreditsPaid: auctions.listingCreditsPaid,
      buyNowPrice: auctions.buyNowPrice,
      minBidPrice: auctions.minBidPrice,
      autoRenew: auctions.autoRenew,
      renewCount: auctions.renewCount,
      isVaulted: auctions.isVaulted,
      createdAt: auctions.createdAt,
      updatedAt: auctions.updatedAt,
      // Card detail fields from JOIN
      frontImageUrl: cards.frontImageUrl,
      backImageUrl: cards.backImageUrl,
      extraImageUrls: cards.extraImageUrls,
      labelColor: cards.labelColor,
      year: cards.year,
      setName: cards.setName,
      cardNumber: cards.cardNumber,
      sport: cards.sport,
      description: cards.description,
      aiGrade: cards.aiGrade,
      aiGradeLabel: cards.aiGradeLabel,
      aiCentering: cards.aiCentering,
      aiCorners: cards.aiCorners,
      aiEdges: cards.aiEdges,
      aiSurface: cards.aiSurface,
      aiCertNumber: cards.aiCertNumber,
      certNumber: cards.certNumber,
    })
    .from(auctions)
    .leftJoin(cards, eq(auctions.cardId, cards.id))
    .where(eq(auctions.status, "active"))
    .orderBy(auctions.endTime)
    .limit(limit);
  return rows as AuctionWithCardDetails[];
}

export async function getAuctionById(id: number): Promise<AuctionWithCardDetails | undefined> {
  const db = await getDb();
  if (!db) return undefined;
  const rows = await db
    .select({
      id: auctions.id,
      cardId: auctions.cardId,
      cardTitle: auctions.cardTitle,
      cardImageUrl: auctions.cardImageUrl,
      sellerEmail: auctions.sellerEmail,
      storeName: auctions.storeName,
      startingPrice: auctions.startingPrice,
      currentBid: auctions.currentBid,
      highestBidderEmail: auctions.highestBidderEmail,
      highestBidderName: auctions.highestBidderName,
      bidCount: auctions.bidCount,
      endTime: auctions.endTime,
      status: auctions.status,
      playerName: auctions.playerName,
      gradeInfo: auctions.gradeInfo,
      durationDays: auctions.durationDays,
      listingCreditsPaid: auctions.listingCreditsPaid,
      buyNowPrice: auctions.buyNowPrice,
      minBidPrice: auctions.minBidPrice,
      autoRenew: auctions.autoRenew,
      renewCount: auctions.renewCount,
      isVaulted: auctions.isVaulted,
      createdAt: auctions.createdAt,
      updatedAt: auctions.updatedAt,
      frontImageUrl: cards.frontImageUrl,
      backImageUrl: cards.backImageUrl,
      extraImageUrls: cards.extraImageUrls,
      labelColor: cards.labelColor,
      year: cards.year,
      setName: cards.setName,
      cardNumber: cards.cardNumber,
      sport: cards.sport,
      description: cards.description,
      aiGrade: cards.aiGrade,
      aiGradeLabel: cards.aiGradeLabel,
      aiCentering: cards.aiCentering,
      aiCorners: cards.aiCorners,
      aiEdges: cards.aiEdges,
      aiSurface: cards.aiSurface,
      aiCertNumber: cards.aiCertNumber,
      certNumber: cards.certNumber,
    })
    .from(auctions)
    .leftJoin(cards, eq(auctions.cardId, cards.id))
    .where(eq(auctions.id, id))
    .limit(1);
  return rows[0] as AuctionWithCardDetails | undefined;
}

export async function getAuctionsBySellerEmail(sellerEmail: string): Promise<Auction[]> {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(auctions).where(eq(auctions.sellerEmail, sellerEmail)).orderBy(desc(auctions.createdAt));
}

export async function getActiveAuctionCountBySellerEmail(sellerEmail: string): Promise<number> {
  const db = await getDb();
  if (!db) return 0;
  const result = await db.select({ count: sql<number>`count(*)` }).from(auctions).where(and(eq(auctions.sellerEmail, sellerEmail), eq(auctions.status, "active")));
  return result[0]?.count || 0;
}

export async function createAuction(data: InsertAuction): Promise<Auction> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(auctions).values(data);
  const insertedId = Number(result[0].insertId);
  const auction = await db.select().from(auctions).where(eq(auctions.id, insertedId)).limit(1);
  return auction[0]!;
}

export async function updateAuction(id: number, data: Partial<InsertAuction>): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(auctions).set(data).where(eq(auctions.id, id));
}

// ============================================================================
// BIDS
// ============================================================================

export async function getBidsByAuctionId(auctionId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(bids).where(eq(bids.auctionId, auctionId)).orderBy(desc(bids.bidTime));
}

export async function createBid(data: InsertBid) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.insert(bids).values(data);
}

// ============================================================================
// ORDERS
// ============================================================================

export async function getOrdersByBuyerEmail(buyerEmail: string): Promise<Order[]> {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(orders).where(eq(orders.buyerEmail, buyerEmail)).orderBy(desc(orders.createdAt));
}

export async function getOrdersBySellerEmail(sellerEmail: string): Promise<Order[]> {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(orders).where(eq(orders.sellerEmail, sellerEmail)).orderBy(desc(orders.createdAt));
}

export async function getOrderById(id: number): Promise<Order | undefined> {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(orders).where(eq(orders.id, id)).limit(1);
  return result[0];
}

export async function createOrder(data: InsertOrder): Promise<Order> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(orders).values(data);
  const insertedId = Number(result[0].insertId);
  const order = await db.select().from(orders).where(eq(orders.id, insertedId)).limit(1);
  return order[0]!;
}

export async function updateOrder(id: number, data: Partial<InsertOrder>): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(orders).set(data).where(eq(orders.id, id));
}

// ============================================================================
// TRADES
// ============================================================================

export async function getTradesByInitiatorEmail(initiatorEmail: string): Promise<Trade[]> {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(trades).where(eq(trades.initiatorEmail, initiatorEmail)).orderBy(desc(trades.createdAt));
}

export async function getTradesByReceiverEmail(receiverEmail: string): Promise<Trade[]> {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(trades).where(eq(trades.receiverEmail, receiverEmail)).orderBy(desc(trades.createdAt));
}

export async function getTradeById(id: number): Promise<Trade | undefined> {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(trades).where(eq(trades.id, id)).limit(1);
  return result[0];
}

export async function createTrade(data: InsertTrade): Promise<Trade> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(trades).values(data);
  const insertedId = Number(result[0].insertId);
  const trade = await db.select().from(trades).where(eq(trades.id, insertedId)).limit(1);
  return trade[0]!;
}

export async function updateTrade(id: number, data: Partial<InsertTrade>): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(trades).set(data).where(eq(trades.id, id));
}

// ============================================================================
// MESSAGES
// ============================================================================

export async function getMessagesByConversationId(conversationId: string) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(messages).where(eq(messages.conversationId, conversationId)).orderBy(messages.createdAt);
}

export async function createMessage(data: InsertMessage) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.insert(messages).values(data);
}

// ============================================================================
// CREDIT SYSTEM
// ============================================================================

export async function getCreditAccountByEmail(userEmail: string): Promise<CreditAccount | undefined> {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(creditAccounts).where(eq(creditAccounts.userEmail, userEmail)).limit(1);
  return result[0];
}

export async function createCreditAccount(data: InsertCreditAccount): Promise<CreditAccount> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(creditAccounts).values(data);
  const insertedId = Number(result[0].insertId);
  const account = await db.select().from(creditAccounts).where(eq(creditAccounts.id, insertedId)).limit(1);
  return account[0]!;
}

export async function updateCreditAccount(userEmail: string, data: Partial<InsertCreditAccount>): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(creditAccounts).set(data).where(eq(creditAccounts.userEmail, userEmail));
}

export async function deductCredits(userEmail: string, amount: number, reason: string, allowFreeCredits = true): Promise<boolean> {
  const db = await getDb();
  if (!db) return false;

  const account = await getCreditAccountByEmail(userEmail);
  if (!account || account.credits < amount) return false;

  // Deduct from purchased credits first, then free credits (if allowed)
  const purchased = account.purchasedCredits ?? 0;
  const free = account.freeCredits ?? 0;
  let newPurchased = purchased;
  let newFree = free;

  if (purchased >= amount) {
    newPurchased = purchased - amount;
  } else if (allowFreeCredits) {
    const fromPurchased = purchased;
    const fromFree = amount - fromPurchased;
    if (fromFree > free) return false;
    newPurchased = 0;
    newFree = free - fromFree;
  } else {
    // Casino mode: only purchased credits allowed
    if (purchased < amount) return false;
    newPurchased = purchased - amount;
  }

  await updateCreditAccount(userEmail, {
    credits: account.credits - amount,
    purchasedCredits: newPurchased,
    freeCredits: newFree,
    totalSpent: (account.totalSpent || 0) + amount,
  });

  await createCreditTransaction({
    userEmail,
    amount: -amount,
    type: "deduction",
    reason,
  });

  return true;
}

export async function addCredits(userEmail: string, amount: number, reason: string, isPurchased = true): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const account = await getCreditAccountByEmail(userEmail);
  if (!account) {
    await createCreditAccount({
      userEmail,
      credits: amount,
      freeCredits: isPurchased ? 25 : 25 + amount,
      purchasedCredits: isPurchased ? amount : 0,
      totalPurchased: isPurchased ? amount : 0,
    });
  } else {
    await updateCreditAccount(userEmail, {
      credits: account.credits + amount,
      purchasedCredits: isPurchased ? (account.purchasedCredits ?? 0) + amount : (account.purchasedCredits ?? 0),
      freeCredits: isPurchased ? (account.freeCredits ?? 0) : (account.freeCredits ?? 0) + amount,
      totalPurchased: isPurchased ? (account.totalPurchased || 0) + amount : (account.totalPurchased || 0),
    });
  }

  await createCreditTransaction({
    userEmail,
    amount,
    type: "purchase",
    reason,
  });
}

export async function createCreditTransaction(data: InsertCreditTransaction) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.insert(creditTransactions).values(data);
}

// ============================================================================
// CARD FINGERPRINTING
// ============================================================================

export async function checkCardFingerprint(userEmail: string, frontHash: string, backHash: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db
    .select()
    .from(cardFingerprints)
    .where(and(eq(cardFingerprints.userEmail, userEmail), eq(cardFingerprints.frontImageHash, frontHash), eq(cardFingerprints.backImageHash, backHash)))
    .limit(1);
  return result[0];
}

export async function createCardFingerprint(data: InsertCardFingerprint) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.insert(cardFingerprints).values(data);
}

// ============================================================================
// GRADE REQUESTS
// ============================================================================

export async function createGradeRequest(data: InsertGradeRequest) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(gradeRequests).values(data);
  return Number(result[0].insertId);
}

export async function searchCards(query: string, limit = 20): Promise<Card[]> {
  const db = await getDb();
  if (!db) return [];
  const q = `%${query}%`;
  // Check if any HOUSE (isMainStore) cards match — if yes, show ONLY house cards
  // This ensures we clear house inventory first before showing sourced cards
  const houseCheck = await db
    .select({ id: cards.id })
    .from(cards)
    .where(
      and(
        eq(cards.status, "active"),
        eq(cards.isMainStore, true),
        or(
          like(cards.playerName, q),
          like(cards.title, q),
          like(cards.setName, q)
        )
      )
    )
    .limit(1);
  const houseHasMatch = houseCheck.length > 0;
  return db
    .select()
    .from(cards)
    .where(
      and(
        eq(cards.status, "active"),
        // If house has this player, restrict to house only; else show all (sourced fills gap)
        houseHasMatch ? eq(cards.isMainStore, true) : undefined,
        or(
          like(cards.playerName, q),
          like(cards.title, q),
          like(cards.setName, q),
          like(cards.sellerEmail, q),
          like(cards.storeName, q)
        )
      )
    )
    .orderBy(desc(cards.isMainStore), desc(cards.createdAt))
    .limit(limit);
}

// ============================================================================
// ORDER MESSAGES (TICKET THREAD)
// ============================================================================

export async function getOrderMessages(orderId: number): Promise<OrderMessage[]> {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(orderMessages).where(eq(orderMessages.orderId, orderId)).orderBy(orderMessages.createdAt);
}

export async function createOrderMessage(data: InsertOrderMessage): Promise<OrderMessage> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(orderMessages).values(data);
  const insertedId = Number(result[0].insertId);
  const msg = await db.select().from(orderMessages).where(eq(orderMessages.id, insertedId)).limit(1);
  return msg[0]!;
}

export async function markOrderMessagesRead(orderId: number, readerEmail: string): Promise<void> {
  const db = await getDb();
  if (!db) return;
  const { ne } = await import("drizzle-orm");
  await db.update(orderMessages)
    .set({ isRead: true })
    .where(and(eq(orderMessages.orderId, orderId), ne(orderMessages.senderEmail, readerEmail)));
}

// ============================================================================
// SELLER LOOKUP (FOR TRADE PAGE)
// ============================================================================

export async function getCardsBySellerForTrade(sellerEmail: string): Promise<Card[]> {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(cards)
    .where(and(eq(cards.sellerEmail, sellerEmail), eq(cards.status, "active")))
    .orderBy(desc(cards.createdAt))
    .limit(200);
}

// Search sellers by name or store name, returns unique sellers with card count
export async function searchSellers(query: string): Promise<{ sellerEmail: string; storeName: string | null; cardCount: number }[]> {
  const db = await getDb();
  if (!db) return [];
  const q = `%${query}%`;
  const results = await db
    .select({
      sellerEmail: cards.sellerEmail,
      storeName: cards.storeName,
      cardCount: sql<number>`count(*)`,
    })
    .from(cards)
    .where(
      and(
        eq(cards.status, "active"),
        or(
          like(cards.storeName, q),
          like(cards.sellerEmail, q),
          like(cards.playerName, q),
          like(cards.title, q)
        )
      )
    )
    .groupBy(cards.sellerEmail, cards.storeName)
    .limit(10);
  return results;
}

// ============================================================================
// CARD EVENTS (Lifecycle timeline)
// ============================================================================
export async function createCardEvent(data: {
  collectionItemId?: number;
  cardId?: number;  // house card ID
  userEmail?: string;
  eventType: string;
  description?: string;
  metadata?: Record<string, unknown>;
}) {
  const db = await getDb();
  if (!db) return;
  try {
    const { cardEvents } = await import("../drizzle/schema");
    await db.insert(cardEvents).values({
      collectionItemId: data.collectionItemId ?? 0,
      cardId: data.cardId,
      userEmail: data.userEmail,
      eventType: data.eventType as any,
      description: data.description,
      metadata: data.metadata ? JSON.stringify(data.metadata) : undefined,
    });
  } catch (e) {
    console.error("[createCardEvent] Failed:", e);
  }
}

export async function getCardEvents(collectionItemId: number) {
  const db = await getDb();
  if (!db) return [];
  const { cardEvents } = await import("../drizzle/schema");
  const { desc } = await import("drizzle-orm");
  return db
    .select()
    .from(cardEvents)
    .where(eq(cardEvents.collectionItemId, collectionItemId))
    .orderBy(desc(cardEvents.createdAt))
    .limit(50);
}

export async function getCardHistoryByCardId(cardId: number) {
  const db = await getDb();
  if (!db) return [];
  const { cardEvents } = await import("../drizzle/schema");
  const { desc } = await import("drizzle-orm");
  return db
    .select()
    .from(cardEvents)
    .where(eq(cardEvents.cardId, cardId))
    .orderBy(desc(cardEvents.createdAt))
    .limit(100);
}

// ============================================================================
// USER COLLECTION (imported from Sports Cards Pro)
// ============================================================================

export async function getUserCollectionByUserId(userId: number, limit = 200, offset = 0) {
  const db = await getDb();
  if (!db) return [];
  const { userCollection } = await import("../drizzle/schema");
  return db
    .select()
    .from(userCollection)
    .where(eq(userCollection.userId, userId))
    .orderBy(desc(userCollection.priceInPennies))
    .limit(limit)
    .offset(offset);
}

export async function getUserCollectionCount(userId: number): Promise<number> {
  const db = await getDb();
  if (!db) return 0;
  const { userCollection } = await import("../drizzle/schema");
  const result = await db
    .select({ count: sql<number>`count(*)` })
    .from(userCollection)
    .where(eq(userCollection.userId, userId));
  return result[0]?.count || 0;
}

export async function getUserCollectionStats(userId: number) {
  const db = await getDb();
  if (!db) return { totalCards: 0, totalValue: 0, totalCost: 0, sports: [] };
  const { userCollection } = await import("../drizzle/schema");
  const [stats] = await db
    .select({
      totalCards: sql<number>`count(*)`,
      totalValue: sql<number>`sum(priceInPennies)`,
      totalCost: sql<number>`sum(costBasisInPennies)`,
    })
    .from(userCollection)
    .where(eq(userCollection.userId, userId));
  return {
    totalCards: stats?.totalCards || 0,
    totalValue: stats?.totalValue || 0,
    totalCost: stats?.totalCost || 0,
  };
}

export async function searchUserCollection(userId: number, query: string, limit = 50) {
  const db = await getDb();
  if (!db) return [];
  const { userCollection } = await import("../drizzle/schema");
  const searchPattern = `%${query}%`;
  return db
    .select()
    .from(userCollection)
    .where(
      and(
        eq(userCollection.userId, userId),
        or(
          like(userCollection.productName, searchPattern),
          like(userCollection.playerName, searchPattern),
          like(userCollection.consoleName, searchPattern),
        )
      )
    )
    .orderBy(desc(userCollection.priceInPennies))
    .limit(limit);
}

// ============================================================================
// FAVORITES
// ============================================================================

export async function toggleFavorite(userId: number, cardId: number): Promise<{ favorited: boolean }> {
  const db = await getDb();
  if (!db) return { favorited: false };
  const existing = await db.select().from(favorites).where(and(eq(favorites.userId, userId), eq(favorites.cardId, cardId))).limit(1);
  if (existing.length > 0) {
    await db.delete(favorites).where(and(eq(favorites.userId, userId), eq(favorites.cardId, cardId)));
    return { favorited: false };
  } else {
    await db.insert(favorites).values({ userId, cardId });
    return { favorited: true };
  }
}

export async function getFavoriteCardIds(userId: number): Promise<number[]> {
  const db = await getDb();
  if (!db) return [];
  const rows = await db.select({ cardId: favorites.cardId }).from(favorites).where(eq(favorites.userId, userId));
  return rows.map(r => r.cardId);
}

export async function getFavoriteCards(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select({ card: cards })
    .from(favorites)
    .innerJoin(cards, eq(favorites.cardId, cards.id))
    .where(eq(favorites.userId, userId))
    .orderBy(desc(favorites.createdAt));
}

// ============================================================================
// USER INTERESTS (PERSONALIZATION)
// ============================================================================

export async function trackUserInterest(userId: number, playerName: string, sport: string | null, avgPrice: number | null): Promise<void> {
  const db = await getDb();
  if (!db) return;
  const existing = await db.select().from(userInterests)
    .where(and(eq(userInterests.userId, userId), eq(userInterests.playerName, playerName)))
    .limit(1);
  if (existing.length > 0) {
    await db.update(userInterests)
      .set({
        searchCount: existing[0].searchCount + 1,
        viewCount: existing[0].viewCount + 1,
        avgPrice: avgPrice ? avgPrice.toFixed(2) : existing[0].avgPrice,
        lastInteractedAt: new Date(),
      })
      .where(and(eq(userInterests.userId, userId), eq(userInterests.playerName, playerName)));
  } else {
    await db.insert(userInterests).values({
      userId,
      playerName,
      sport,
      searchCount: 1,
      viewCount: 1,
      avgPrice: avgPrice ? avgPrice.toFixed(2) : null,
      lastInteractedAt: new Date(),
    });
  }
}

export async function getTopInterests(userId: number, limit = 10): Promise<UserInterest[]> {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(userInterests)
    .where(eq(userInterests.userId, userId))
    .orderBy(desc(userInterests.searchCount), desc(userInterests.lastInteractedAt))
    .limit(limit);
}

export async function getPersonalizedCards(userId: number, limit = 24): Promise<typeof cards.$inferSelect[]> {
  const db = await getDb();
  if (!db) return [];
  // Get top interests
  const interests = await getTopInterests(userId, 5);
  if (interests.length === 0) {
    // No interests yet — return top cards by price
    return db.select().from(cards).where(eq(cards.status, "active")).orderBy(desc(cards.price)).limit(limit);
  }
  // Build a list of player names to prioritize
  const playerNames = interests.map(i => i.playerName);
  // Get cards matching interests first, then fill with top cards
  const interestCards = await db.select().from(cards)
    .where(and(eq(cards.status, "active"), inArray(cards.playerName, playerNames)))
    .orderBy(desc(cards.price))
    .limit(limit);
  if (interestCards.length >= limit) return interestCards.slice(0, limit);
  // Fill remaining slots with other top cards
  const interestCardIds = interestCards.map(c => c.id);
  const fillCards = await db.select().from(cards)
    .where(and(eq(cards.status, "active"), interestCardIds.length > 0 ? notInArray(cards.id, interestCardIds) : undefined))
    .orderBy(desc(cards.price))
    .limit(limit - interestCards.length);
  return [...interestCards, ...fillCards];
}

// ── House Picks For You ───────────────────────────────────────────────────────
// Returns 10 house cards personalized by user interests (past searches/purchases).
// For guests (no userId), returns top-priced house cards across sports.
export async function getHousePicksForUser(userId?: number): Promise<Card[]> {
  const db = await getDb();
  if (!db) return [];

  if (userId) {
    const interests = await getTopInterests(userId, 5);
    if (interests.length > 0) {
      const playerNames = interests.map(i => i.playerName);
      // Try to get house cards matching interests
      const interestCards = await db.select().from(cards)
        .where(and(
          eq(cards.status, "active"),
          eq(cards.isMainStore, true),
          inArray(cards.playerName, playerNames)
        ))
        .orderBy(sql`CAST(${cards.price} AS DECIMAL(10,2)) DESC`)
        .limit(20);
      // Deduplicate by player (max 1 per player)
      const seen = new Set<string>();
      const deduped: Card[] = [];
      for (const c of interestCards) {
        const key = (c.playerName ?? "x").toLowerCase();
        if (!seen.has(key)) { seen.add(key); deduped.push(c); }
        if (deduped.length >= 10) break;
      }
      if (deduped.length >= 5) return deduped.slice(0, 10);
    }
  }

  // Fallback: top-priced house cards, max 1 per player, spread across sports
  const sportOrder = ["basketball", "football", "baseball", "hockey", "soccer", "other"];
  const result: Card[] = [];
  for (const sport of sportOrder) {
    const rows = await db.select().from(cards)
      .where(and(eq(cards.status, "active"), eq(cards.isMainStore, true), eq(cards.sport, sport as any)))
      .orderBy(sql`CAST(${cards.price} AS DECIMAL(10,2)) DESC`)
      .limit(5);
    const seen = new Set<string>();
    for (const c of rows) {
      const key = (c.playerName ?? "x").toLowerCase();
      if (!seen.has(key)) { seen.add(key); result.push(c); }
      if (result.length >= 10) break;
    }
    if (result.length >= 10) break;
  }
  return result.slice(0, 10);
}

// ── Up & Coming Section ───────────────────────────────────────────────────────
// LOCKED RULE: house cards only, admin-flagged with isUpAndComing=true
export async function getUpAndComingCards(limit = 20): Promise<Card[]> {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(cards)
    .where(
      and(
        eq(cards.status, "active"),
        eq(cards.isMainStore, true),
        sql`${cards.isUpAndComing} = 1` as any,
      )
    )
    .orderBy(desc(cards.createdAt))
    .limit(limit);
}

// ── Showcase Section ──────────────────────────────────────────────────────────
// LOCKED RULE: house cards only, admin-flagged with isShowcaseCard=true, $5k-$10k range
// 5 cards rotate daily (seeded by day-of-year so they change each day)
export async function getShowcaseCards(): Promise<Card[]> {
  const db = await getDb();
  if (!db) return [];
  const rows = await db
    .select()
    .from(cards)
    .where(
      and(
        eq(cards.status, "active"),
        eq(cards.isMainStore, true),
        sql`${cards.isShowcaseCard} = 1` as any,
      )
    )
    .orderBy(cards.id)
    .limit(50);
  if (rows.length === 0) return [];
  // Rotate 5 cards daily using day-of-year as seed
  const now = new Date();
  const start = new Date(now.getFullYear(), 0, 0);
  const dayOfYear = Math.floor((now.getTime() - start.getTime()) / 86400000);
  const offset = dayOfYear % Math.max(1, rows.length);
  const rotated = [...rows.slice(offset), ...rows.slice(0, offset)];
  return rotated.slice(0, 5);
}


// ============================================================================
// SMART MARKETPLACE ROTATION
// ============================================================================
/**
 * WNBA player names — used to identify WNBA cards within the basketball sport bucket.
 * WNBA cards MUST come from house inventory only (source = 'manual', isMainStore = true).
 */
const WNBA_PLAYERS = [
  "Caitlin Clark", "Angel Reese", "Paige Bueckers", "A'ja Wilson", "Sabrina Ionescu",
  "Kate Martin", "Aziaha James", "Rickea Jackson", "Breanna Stewart", "Diana Taurasi",
  "Kelsey Plum", "Jewell Loyd", "Napheesa Collier", "Aliyah Boston", "Aneesah Morrow",
  "Kiki Iriafen", "DiJonai Carrington", "Stephanie Soares", "Dearica Hamby", "Skylar Diggins",
  "Chelsea Gray", "Courtney Williams", "Jonquel Jones", "Alyssa Thomas", "DeWanna Bonner",
];

/**
 * Sport-weighted slot targets for the featured row (24 cards total).
 * WNBA: 25% = 6 slots (house only)
 * NBA:  25% = 6 slots
 * Football: 15% = 4 slots
 * Baseball: 15% = 4 slots
 * Hockey:    5% = 1 slot
 * Soccer:    5% = 1 slot
 * Other:    10% = 2 slots
 */
const FEATURED_SLOTS = [
  { key: "wnba",     sport: "basketball", limit: 6, houseOnly: true,  isWnba: true  },
  { key: "nba",      sport: "basketball", limit: 6, houseOnly: false, isWnba: false },
  { key: "football", sport: "football",   limit: 4, houseOnly: false, isWnba: false },
  { key: "baseball", sport: "baseball",   limit: 4, houseOnly: false, isWnba: false },
  { key: "hockey",   sport: "hockey",     limit: 1, houseOnly: false, isWnba: false },
  { key: "soccer",   sport: "soccer",     limit: 1, houseOnly: false, isWnba: false },
  { key: "other",    sport: "other",      limit: 2, houseOnly: false, isWnba: false },
];

/** Seeded deterministic shuffle — same seed produces same order */
function seededShuffle<T>(arr: T[], seed: number): T[] {
  const a = [...arr];
  let s = seed;
  for (let i = a.length - 1; i > 0; i--) {
    s = (s * 1664525 + 1013904223) & 0xffffffff;
    const j = Math.abs(s) % (i + 1);
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

/**
 * Returns up to 24 featured cards for the Marketplace rotation strip.
 *
 * Rules enforced:
 * - $500 price cap — no card above $500 shown in this strip
 * - WNBA cards come from house inventory only (isMainStore = true)
 * - Daily rotation — cards change each day (date-seeded shuffle)
 * - Personalization — if visitorKey supplied, cards matching visitor's
 *   recent search player names are boosted to the front of each bucket
 */
export async function getFeaturedCards(visitorKey?: string): Promise<Card[]> {
  const db = await getDb();
  if (!db) return [];

  // Day-of-year seed so rotation changes daily
  const now = new Date();
  const dayOfYear = Math.floor(
    (now.getTime() - new Date(now.getFullYear(), 0, 0).getTime()) / 86400000
  );

  // Fetch visitor's recent search history for personalization
  let boostedPlayers: string[] = [];
  if (visitorKey) {
    try {
      const { visitorSearchHistory } = await import("../drizzle/schema");
      const recentSearches = await db
        .select()
        .from(visitorSearchHistory)
        .where(eq(visitorSearchHistory.visitorKey, visitorKey))
        .orderBy(desc(visitorSearchHistory.searchedAt))
        .limit(20);
      const seen = new Set<string>();
      for (const row of recentSearches) {
        if (row.playerName && !seen.has(row.playerName)) {
          seen.add(row.playerName);
          boostedPlayers.push(row.playerName);
        }
      }
    } catch {
      // personalization is best-effort — ignore errors
    }
  }

  // Track all card IDs already placed so we never duplicate across slots
  const usedIds = new Set<number>();
  const result: Card[] = [];

  for (const slot of FEATURED_SLOTS) {
    // Fetch a generous pool — for WNBA we need extra because we filter by player name post-query
    const poolSize = slot.isWnba ? 200 : slot.limit * 12;

    const baseConditions: any[] = [
      eq(cards.status, "active"),
      eq(cards.sport, slot.sport as any),
      sql`CAST(${cards.price} AS DECIMAL(10,2)) BETWEEN 10.00 AND 500.00`,
    ];

    if (slot.houseOnly) {
      baseConditions.push(eq(cards.isMainStore, true));
    }

    const pool = await db
      .select()
      .from(cards)
      .where(and(...baseConditions))
      .orderBy(sql`CAST(${cards.price} AS DECIMAL(10,2)) DESC`)
      .limit(poolSize);

    // Split WNBA vs NBA within the basketball bucket
    let filtered: Card[];
    if (slot.isWnba) {
      filtered = pool.filter(c =>
        WNBA_PLAYERS.some(p => (c.playerName ?? "").toLowerCase().includes(p.toLowerCase()))
      );
      // Fallback: if no WNBA-named house cards exist, use any basketball house cards
      if (filtered.length === 0) {
        filtered = pool; // pool already restricted to isMainStore=true basketball
      }
    } else if (slot.sport === "basketball" && !slot.isWnba) {
      filtered = pool.filter(c =>
        !WNBA_PLAYERS.some(p => (c.playerName ?? "").toLowerCase().includes(p.toLowerCase()))
      );
    } else {
      filtered = pool;
    }

    // Skip only if truly no cards exist for this sport (e.g. no hockey cards at all)
    if (filtered.length === 0) continue;

    // Remove cards already placed in a previous slot
    filtered = filtered.filter(c => !usedIds.has(c.id));

    // Personalization: separate boosted vs rest
    const boosted: Card[] = [];
    const rest: Card[] = [];
    for (const c of filtered) {
      const isBoost = boostedPlayers.some(
        p => (c.playerName ?? "").toLowerCase().includes(p.toLowerCase())
      );
      if (isBoost) boosted.push(c);
      else rest.push(c);
    }

    // Daily rotation within each bucket
    const shuffledBoosted = seededShuffle(boosted, dayOfYear + slot.key.charCodeAt(0));
    const shuffledRest    = seededShuffle(rest,    dayOfYear + slot.key.charCodeAt(0) + 1000);

    // Deduplicate by player name (max 1 card per player per slot), respect slot.limit
    const seenPlayers = new Set<string>();
    const slotCards: Card[] = [];
    for (const c of [...shuffledBoosted, ...shuffledRest]) {
      const playerKey = (c.playerName ?? `id-${c.id}`).toLowerCase();
      if (!seenPlayers.has(playerKey)) {
        seenPlayers.add(playerKey);
        slotCards.push(c);
        usedIds.add(c.id);
      }
      if (slotCards.length >= slot.limit) break;
    }
    result.push(...slotCards);
  }

  // ── Guarantee fill: if total < 24, top up with any remaining active cards ──
  const TARGET = 24;
  if (result.length < TARGET) {
    // Build a set of player names already in the result to avoid player-level duplication
    const usedPlayers = new Set(result.map(c => (c.playerName ?? `id-${c.id}`).toLowerCase()));
    const fillPool = await db
      .select()
      .from(cards)
      .where(and(
        eq(cards.status, "active"),
        sql`CAST(${cards.price} AS DECIMAL(10,2)) BETWEEN 10.00 AND 500.00`,
        eq(cards.isMainStore, true),
      ))
      .orderBy(sql`RAND()`)
      .limit((TARGET - result.length) * 4);
    for (const c of fillPool) {
      const playerKey = (c.playerName ?? `id-${c.id}`).toLowerCase();
      if (!usedIds.has(c.id) && !usedPlayers.has(playerKey)) {
        result.push(c);
        usedIds.add(c.id);
        usedPlayers.add(playerKey);
      }
      if (result.length >= TARGET) break;
    }
  }

  return result;
}

/**
 * Record a visitor search for Marketplace personalization.
 * visitorKey = userId (string) for logged-in users, or localStorage sessionId for guests.
 */
export async function recordVisitorSearch(
  visitorKey: string,
  query: string,
  sport?: string,
  playerName?: string,
  isLoggedIn = false
): Promise<void> {
  const db = await getDb();
  if (!db || !query.trim()) return;
  try {
    const { visitorSearchHistory } = await import("../drizzle/schema");
    await db.insert(visitorSearchHistory).values({
      visitorKey,
      isLoggedIn,
      query: query.trim().slice(0, 255),
      sport: sport?.slice(0, 50),
      playerName: playerName?.slice(0, 255),
    });
  } catch {
    // best-effort
  }
}
