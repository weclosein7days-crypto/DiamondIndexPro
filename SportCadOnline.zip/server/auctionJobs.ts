/**
 * auctionJobs.ts
 * 
 * Background jobs for auction lifecycle management:
 * - Checks for expired auctions every 30 minutes
 * - If an auction ends with no bids meeting the minimum (startingPrice), 
 *   and autoRenew is true, it re-lists for another 3 days
 * - If minimum bid was met, marks as "ended" and sends notification
 */

import mysql from "mysql2/promise";
import { sendEmail } from "./email";
import { notifyOwner } from "./_core/notification";

const DB_URL = process.env.DATABASE_URL;

async function getConnection() {
  if (!DB_URL) return null;
  try {
    return await mysql.createConnection(DB_URL);
  } catch (e) {
    console.warn("[AuctionJobs] DB connect failed:", (e as Error).message);
    return null;
  }
}

async function processExpiredAuctions() {
  const conn = await getConnection();
  if (!conn) return;

  try {
    // Find auctions that have passed their endTime but are still "active"
    const [expiredAuctions] = await conn.execute<mysql.RowDataPacket[]>(
      `SELECT a.*, c.price as cardPrice
       FROM auctions a
       LEFT JOIN cards c ON a.cardId = c.id
       WHERE a.status = 'active' AND a.endTime < NOW()`
    );

    if (expiredAuctions.length === 0) {
      await conn.end();
      return;
    }

    console.log(`[AuctionJobs] Processing ${expiredAuctions.length} expired auctions...`);

    for (const auction of expiredAuctions) {
      const currentBid = parseFloat(auction.currentBid || "0");
      const minBidPrice = parseFloat(auction.minBidPrice || auction.startingPrice || "0");
      const bidCount = auction.bidCount || 0;

      // Check if minimum bid was met
      const minBidMet = bidCount > 0 && currentBid >= minBidPrice;

      if (minBidMet) {
        // Auction succeeded — mark as ended
        await conn.execute(
          `UPDATE auctions SET status = 'ended' WHERE id = ?`,
          [auction.id]
        );

        // Mark the underlying card as sold
        if (auction.cardId) {
          await conn.execute(`UPDATE cards SET status = 'sold' WHERE id = ?`, [auction.cardId]);
        }

        // Auto-add card to winner's Collection CRM
        const winnerEmail = auction.highestBidderEmail;
        if (winnerEmail && auction.cardId) {
          const [cardRows] = await conn.execute<mysql.RowDataPacket[]>(
            `SELECT * FROM cards WHERE id = ?`, [auction.cardId]
          );
          const card = cardRows[0];
          if (card) {
            await conn.execute(
              `INSERT INTO collections (ownerEmail, cardTitle, playerName, year, setName, cardNumber, sport, frontImageUrl, backImageUrl, overallGrade, gradeLabel, centeringScore, cornersScore, edgesScore, surfaceScore, certNumber, estimatedValueLow, estimatedValueHigh, listingStatus, lifecycleNote, linkedCardId, createdAt, updatedAt)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'none', ?, ?, NOW(), NOW())`,
              [
                winnerEmail,
                card.title,
                card.playerName,
                card.year || null,
                card.setName || null,
                card.cardNumber || null,
                card.sport || 'baseball',
                card.frontImageUrl || null,
                card.backImageUrl || null,
                card.aiGrade ? String(card.aiGrade) : null,
                card.aiGradeLabel || null,
                card.aiCentering || null,
                card.aiCorners || null,
                card.aiEdges || null,
                card.aiSurface || null,
                card.aiCertNumber || card.certNumber || null,
                String(currentBid),
                String(currentBid),
                `Won at auction #${auction.id} for $${currentBid}`,
                auction.cardId,
              ]
            );
          }

          // Notify winner
          sendEmail({
            to: winnerEmail,
            subject: `You won the auction! — ${auction.cardTitle || card?.title || 'Sports Card'}`,
            html: `<p>Congratulations! You won the auction for <strong>${auction.cardTitle || card?.title || 'Sports Card'}</strong> with a bid of <strong>$${currentBid}</strong>.</p><p>The card has been added to your Collection. You will receive shipping details shortly.</p>`,
          }).catch(() => {});

          // Notify seller
          sendEmail({
            to: auction.sellerEmail,
            subject: `Your auction ended — ${auction.cardTitle || card?.title || 'Sports Card'} sold for $${currentBid}`,
            html: `<p>Your auction for <strong>${auction.cardTitle || card?.title || 'Sports Card'}</strong> ended. Winning bid: <strong>$${currentBid}</strong> by ${auction.highestBidderName || winnerEmail}.</p><p>Please ship the card within 48 hours.</p>`,
          }).catch(() => {});

          notifyOwner({
            title: `Auction Won: ${auction.cardTitle || 'Card'}`,
            content: `Winner: ${winnerEmail}\nSeller: ${auction.sellerEmail}\nBid: $${currentBid}\nAuction #${auction.id}`,
          }).catch(() => {});
        }

         console.log(`[AuctionJobs] Auction #${auction.id} ended successfully (bid: $${currentBid})`);
      } else if (auction.autoRenew) {
        // Minimum not met — auto-renew for another 3 days
        const newEndTime = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);
        const renewCount = (auction.renewCount || 0) + 1;

        await conn.execute(
          `UPDATE auctions 
           SET endTime = ?, 
               renewCount = ?,
               currentBid = '0.00',
               highestBidderEmail = NULL,
               highestBidderName = NULL,
               bidCount = 0
           WHERE id = ?`,
          [newEndTime, renewCount, auction.id]
        );

        // Clear old bids for this auction
        await conn.execute(
          `DELETE FROM bids WHERE auctionId = ?`,
          [auction.id]
        );

        console.log(
          `[AuctionJobs] Auction #${auction.id} auto-renewed (attempt #${renewCount}, min bid $${minBidPrice} not met)`
        );
      } else {
        // No auto-renew — just end it
        await conn.execute(
          `UPDATE auctions SET status = 'ended' WHERE id = ?`,
          [auction.id]
        );
        console.log(`[AuctionJobs] Auction #${auction.id} ended (no auto-renew, min bid not met)`);
      }
    }
  } catch (err) {
    console.error("[AuctionJobs] Error processing expired auctions:", err);
  } finally {
    await conn.end();
  }
}

/**
 * Start the auction background job.
 * Runs every 30 minutes to check for expired auctions.
 */
export function startAuctionJobs() {
  console.log("[AuctionJobs] Starting auction lifecycle manager (30-min interval)");
  
  // Run immediately on startup
  processExpiredAuctions().catch(console.error);
  
  // Then run every 30 minutes
  setInterval(() => {
    processExpiredAuctions().catch(console.error);
  }, 30 * 60 * 1000);
}
