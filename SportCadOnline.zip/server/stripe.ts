/**
 * Stripe helper for CardVault
 * Handles trade fee payments ($10/person) and sale platform fees (10%)
 */
import Stripe from "stripe";

const stripeSecretKey = process.env.STRIPE_SECRET_KEY;

export function getStripe(): Stripe {
  if (!stripeSecretKey) throw new Error("STRIPE_SECRET_KEY not configured");
  return new Stripe(stripeSecretKey, { apiVersion: "2025-02-24.acacia" });
}

/**
 * Create a $10 trade fee checkout session for one party
 */
export async function createTradeFeeSession({
  tradeId,
  partyEmail,
  partyName,
  role, // "initiator" | "receiver"
  origin,
}: {
  tradeId: number;
  partyEmail: string;
  partyName: string;
  role: "initiator" | "receiver";
  origin: string;
}): Promise<Stripe.Checkout.Session> {
  const stripe = getStripe();
  const session = await stripe.checkout.sessions.create({
    mode: "payment",
    customer_email: partyEmail,
    line_items: [
      {
        price_data: {
          currency: "usd",
          product_data: {
            name: "SCG Trade Escrow Fee",
            description: `Trade #${tradeId} — SCG verifies, seals, and forwards your cards. $10 per party.`,
          },
          unit_amount: 1000, // $10.00 in cents
        },
        quantity: 1,
      },
    ],
    client_reference_id: String(tradeId),
    metadata: {
      trade_id: String(tradeId),
      party_email: partyEmail,
      party_name: partyName,
      role,
      type: "trade_fee",
    },
    success_url: `${origin}/trades?trade_fee_paid=1&trade_id=${tradeId}`,
    cancel_url: `${origin}/trades?trade_fee_cancelled=1&trade_id=${tradeId}`,
  });
  return session;
}
