/**
 * Blog Jobs — Daily 7 AM cron to auto-generate blog post, create video, and upload to YouTube
 */
import { generateBlogPost } from "./blogEngine";
import { generateBlogVideo } from "./videoEngine";
import { updateBlogPost } from "./blogEngine";
import { isYouTubeConfigured, uploadToYouTube } from "./youtubeService";
import { getDb } from "./db";
import { blogPosts } from "../drizzle/schema";
import { eq } from "drizzle-orm";
import https from "https";
import http from "http";
import fs from "fs";
import os from "os";
import path from "path";

// Simple cron-style scheduler using setTimeout
function scheduleDaily(hour: number, minute: number, fn: () => Promise<void>) {
  function getNextRunMs() {
    const now = new Date();
    const next = new Date();
    next.setHours(hour, minute, 0, 0);
    if (next <= now) {
      next.setDate(next.getDate() + 1);
    }
    return next.getTime() - now.getTime();
  }

  function schedule() {
    const delay = getNextRunMs();
    const nextRun = new Date(Date.now() + delay);
    console.log(`[blogJobs] Next blog generation scheduled for: ${nextRun.toLocaleString()}`);
    setTimeout(async () => {
      try {
        await fn();
      } catch (e) {
        console.error("[blogJobs] Error in daily blog job:", e);
      }
      schedule(); // reschedule for next day
    }, delay);
  }

  schedule();
}

async function runDailyBlogPipeline() {
  console.log("[blogJobs] Starting daily blog pipeline...");

  // Step 1: Generate blog post
  let postId: number;
  let slug: string;
  try {
    const result = await generateBlogPost({});
    postId = result.id;
    slug = result.slug;
    console.log(`[blogJobs] Blog post generated: #${postId} "${result.title}"`);
  } catch (e) {
    console.error("[blogJobs] Blog generation failed:", e);
    return;
  }

  // Step 2: Generate video
  try {
    await updateBlogPost(postId, { videoStatus: "generating" });
    const db = await getDb();
    if (!db) throw new Error("DB unavailable");
    const [post] = await db.select().from(blogPosts).where(eq(blogPosts.id, postId)).limit(1);
    if (!post) throw new Error("Post not found after insert");

    const videoResult = await generateBlogVideo({
      postId: post.id,
      title: post.title,
      excerpt: post.excerpt ?? "",
      content: post.content,
      coverImageUrl: post.coverImageUrl,
      slug: post.slug,
    });
    await updateBlogPost(postId, { videoStatus: "ready", videoUrl: videoResult.s3Url });
    console.log(`[blogJobs] Video generated and uploaded: ${videoResult.s3Url}`);

    // Step 3: Upload to YouTube (if configured)
    if (isYouTubeConfigured()) {
      const tmpPath = path.join(os.tmpdir(), `yt-daily-${postId}-${Date.now()}.mp4`);
      // Download video from S3 to temp file
      await new Promise<void>((resolve, reject) => {
        const fileStream = fs.createWriteStream(tmpPath);
        const protocol = videoResult.s3Url.startsWith("https") ? https : http;
        (protocol as any).get(videoResult.s3Url, (res: any) => {
          res.pipe(fileStream);
          fileStream.on("finish", () => { fileStream.close(); resolve(); });
        }).on("error", reject);
      });
      try {
        const tags = post.tags ? JSON.parse(post.tags) : [];
        const ytResult = await uploadToYouTube({
          videoPath: tmpPath,
          title: post.title,
          description: post.excerpt ?? post.title,
          excerpt: post.excerpt ?? "",
          slug: post.slug,
          tags,
          thumbnailUrl: post.coverImageUrl ?? undefined,
        });
        await updateBlogPost(postId, {
          youtubeVideoId: ytResult.videoId,
          youtubeUrl: ytResult.videoUrl,
          videoStatus: "published",
        });
        console.log(`[blogJobs] Uploaded to YouTube: ${ytResult.videoUrl}`);
      } finally {
        try { fs.unlinkSync(tmpPath); } catch { /* ignore */ }
      }
    } else {
      console.log("[blogJobs] YouTube not configured — skipping upload. Add YOUTUBE_CLIENT_ID, YOUTUBE_CLIENT_SECRET, YOUTUBE_REFRESH_TOKEN to enable.");
    }
  } catch (e) {
    console.error("[blogJobs] Video/YouTube step failed:", e);
    await updateBlogPost(postId, { videoStatus: "error", videoErrorMsg: (e as Error).message });
  }

  console.log("[blogJobs] Daily blog pipeline complete.");
}

export function startBlogJobs() {
  console.log("[blogJobs] Blog job scheduler started — posts will be generated daily at 7:00 AM");
  scheduleDaily(7, 0, runDailyBlogPipeline);
}
