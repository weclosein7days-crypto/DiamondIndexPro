/**
 * CardVault Image Processor
 * ─────────────────────────
 * Automatically detects the card/slab face in eBay listing images,
 * crops tightly to the card, adds a 1/8-inch white border frame,
 * and stores the processed image in S3.
 *
 * PSA Compliance Rules enforced:
 *  - Rejects images containing shipping claim text overlays
 *  - Rejects images with seller contact watermarks
 *  - Does NOT overlay PSA logo or branding
 *  - Only processes images from eBay listings we actually carry
 *  - Stores front + back variants separately
 */

import sharp from "sharp";
import { storagePut } from "./storage";

// ─── Types ────────────────────────────────────────────────────────────────────

export interface ProcessedCardImage {
  frontUrl: string | null;
  backUrl: string | null;
  frontKey: string | null;
  backKey: string | null;
  width: number;
  height: number;
  processingNotes: string[];
  psaCompliant: boolean;
  error?: string;
}

export interface ProcessImageOptions {
  /** Card ID used to build the S3 key */
  cardId: string;
  /** URL of the front image (from eBay listing) */
  frontImageUrl: string;
  /** URL of the back image (optional, from eBay additional images) */
  backImageUrl?: string | null;
  /** Target output DPI — 300 for print quality, 150 for web */
  targetDpi?: number;
  /** Whether to add the 1/8-inch white border frame (default: true) */
  addFrame?: boolean;
  /** Border color as hex (default: #FFFFFF white) */
  frameColor?: { r: number; g: number; b: number };
  /** Skip PSA compliance check (default: false) */
  skipComplianceCheck?: boolean;
}

// ─── Constants ────────────────────────────────────────────────────────────────

/** Standard sports card aspect ratio (2.5" × 3.5") */
const CARD_ASPECT_RATIO = 2.5 / 3.5; // ~0.714

/** PSA slab aspect ratio (slightly wider than raw card) */
const SLAB_ASPECT_RATIO = 2.75 / 3.875; // ~0.710

/** Tolerance for aspect ratio matching */
const ASPECT_RATIO_TOLERANCE = 0.15;

/** Minimum card face size in pixels (reject tiny thumbnails) */
const MIN_CARD_DIMENSION = 200;

/** 1/8 inch at 300 DPI = 37.5 px → round to 38 */
const FRAME_BORDER_PX_AT_300DPI = 38;

/** Web output target width */
const WEB_OUTPUT_WIDTH = 800;

/** PSA compliance: text patterns that indicate shipping claims */
const SHIPPING_CLAIM_PATTERNS = [
  /ships?\s+from/i,
  /free\s+ship/i,
  /i\s+ship/i,
  /will\s+ship/i,
  /fast\s+ship/i,
  /same\s+day\s+ship/i,
  /combined\s+ship/i,
  /seller\s+ships/i,
  /tracking\s+number/i,
];

/** Seller contact watermark patterns */
const CONTACT_WATERMARK_PATTERNS = [
  /@gmail\.com/i,
  /@yahoo\.com/i,
  /@hotmail\.com/i,
  /\(\d{3}\)\s*\d{3}-\d{4}/,  // phone number
  /www\./i,
  /\.com\b/i,
  /instagram\.com/i,
  /facebook\.com/i,
];

// ─── Utility: Fetch image buffer from URL ─────────────────────────────────────

export async function fetchImageBuffer(url: string): Promise<Buffer | null> {
  try {
    // Upgrade eBay images to full resolution
    const fullResUrl = url
      .replace(/s-l\d+\.jpg/i, "s-l1600.jpg")
      .replace(/s-l\d+\.webp/i, "s-l1600.jpg");

    const res = await fetch(fullResUrl, {
      headers: {
        "User-Agent": "Mozilla/5.0 (compatible; CardVault/1.0; +https://sportcardsonline.com)",
        "Accept": "image/webp,image/jpeg,image/*",
      },
      signal: AbortSignal.timeout(15_000),
    });

    if (!res.ok) {
      // Try original URL as fallback
      if (fullResUrl !== url) {
        const fallback = await fetch(url, {
          headers: { "User-Agent": "Mozilla/5.0" },
          signal: AbortSignal.timeout(10_000),
        });
        if (!fallback.ok) return null;
        return Buffer.from(await fallback.arrayBuffer());
      }
      return null;
    }

    return Buffer.from(await res.arrayBuffer());
  } catch {
    return null;
  }
}

// ─── PSA Compliance Checker ───────────────────────────────────────────────────

/**
 * Checks image metadata and dimensions for PSA compliance.
 * Note: Full OCR-based text detection would require an external service.
 * This performs structural checks (size, format, aspect ratio sanity).
 */
export async function checkPsaCompliance(
  imageBuffer: Buffer,
  imageUrl: string
): Promise<{ compliant: boolean; reasons: string[] }> {
  const reasons: string[] = [];

  // Check URL for obvious shipping claim patterns in query strings / filenames
  for (const pattern of SHIPPING_CLAIM_PATTERNS) {
    if (pattern.test(imageUrl)) {
      reasons.push(`URL contains shipping claim pattern: ${pattern.source}`);
    }
  }

  // Check URL for contact watermark patterns
  for (const pattern of CONTACT_WATERMARK_PATTERNS) {
    if (pattern.test(imageUrl)) {
      reasons.push(`URL contains contact/watermark pattern: ${pattern.source}`);
    }
  }

  try {
    const meta = await sharp(imageBuffer).metadata();

    // Reject very small images (likely thumbnails or icons)
    if ((meta.width ?? 0) < MIN_CARD_DIMENSION || (meta.height ?? 0) < MIN_CARD_DIMENSION) {
      reasons.push(`Image too small: ${meta.width}×${meta.height}px (min ${MIN_CARD_DIMENSION}px)`);
    }

    // Reject images with extreme aspect ratios (clearly not a card)
    if (meta.width && meta.height) {
      const ratio = meta.width / meta.height;
      // Cards are portrait (ratio < 1) or landscape (ratio > 1 if rotated)
      // Reject if it looks like a banner/header (very wide) or a square icon
      if (ratio > 3.0) {
        reasons.push(`Suspicious aspect ratio ${ratio.toFixed(2)} — may be a banner/header, not a card`);
      }
    }
  } catch {
    reasons.push("Could not read image metadata");
  }

  return { compliant: reasons.length === 0, reasons };
}

// ─── Card Face Detector ───────────────────────────────────────────────────────

interface DetectedFace {
  left: number;
  top: number;
  width: number;
  height: number;
  confidence: "high" | "medium" | "low";
  type: "raw_card" | "psa_slab" | "full_image";
}

/**
 * Detects the card or PSA slab face within an image using edge analysis.
 *
 * Strategy:
 * 1. Convert to grayscale and analyze pixel brightness distribution
 * 2. Find the dominant rectangular region matching card aspect ratios
 * 3. Use padding analysis to detect white/background borders around the card
 * 4. Return crop coordinates for the detected face
 *
 * For eBay images, the card is typically:
 * - Centered in the frame
 * - Surrounded by white or neutral background
 * - The largest rectangular object in the image
 */
export async function detectCardFace(imageBuffer: Buffer): Promise<DetectedFace> {
  const meta = await sharp(imageBuffer).metadata();
  const imgW = meta.width ?? 800;
  const imgH = meta.height ?? 1000;

  // Step 1: Get raw pixel data (grayscale) to analyze brightness distribution
  const { data: pixels, info } = await sharp(imageBuffer)
    .resize({ width: 400, fit: "inside" }) // Downscale for fast processing
    .grayscale()
    .raw()
    .toBuffer({ resolveWithObject: true });

  const w = info.width;
  const h = info.height;

  // Step 2: Find content bounding box by scanning from edges inward
  // We look for the first row/column that has significant non-background content
  // Background is typically white (>240) or very light gray

  const BACKGROUND_THRESHOLD = 235; // pixels brighter than this are "background"
  const CONTENT_DENSITY_THRESHOLD = 0.05; // 5% of pixels must be non-background

  function rowHasContent(y: number): boolean {
    let contentPixels = 0;
    for (let x = 0; x < w; x++) {
      if (pixels[y * w + x] < BACKGROUND_THRESHOLD) contentPixels++;
    }
    return contentPixels / w > CONTENT_DENSITY_THRESHOLD;
  }

  function colHasContent(x: number): boolean {
    let contentPixels = 0;
    for (let y = 0; y < h; y++) {
      if (pixels[y * w + x] < BACKGROUND_THRESHOLD) contentPixels++;
    }
    return contentPixels / h > CONTENT_DENSITY_THRESHOLD;
  }

  // Find top edge
  let topEdge = 0;
  for (let y = 0; y < h; y++) {
    if (rowHasContent(y)) { topEdge = y; break; }
  }

  // Find bottom edge
  let bottomEdge = h - 1;
  for (let y = h - 1; y >= 0; y--) {
    if (rowHasContent(y)) { bottomEdge = y; break; }
  }

  // Find left edge
  let leftEdge = 0;
  for (let x = 0; x < w; x++) {
    if (colHasContent(x)) { leftEdge = x; break; }
  }

  // Find right edge
  let rightEdge = w - 1;
  for (let x = w - 1; x >= 0; x--) {
    if (colHasContent(x)) { rightEdge = x; break; }
  }

  // Step 3: Scale back to original image coordinates
  const scaleX = imgW / w;
  const scaleY = imgH / h;

  const detectedLeft = Math.max(0, Math.floor(leftEdge * scaleX));
  const detectedTop = Math.max(0, Math.floor(topEdge * scaleY));
  const detectedRight = Math.min(imgW, Math.ceil(rightEdge * scaleX));
  const detectedBottom = Math.min(imgH, Math.ceil(bottomEdge * scaleY));

  const detectedW = detectedRight - detectedLeft;
  const detectedH = detectedBottom - detectedTop;

  // Step 4: Check if detected region matches card aspect ratio
  const detectedRatio = detectedW / detectedH;
  const isCardRatio = Math.abs(detectedRatio - CARD_ASPECT_RATIO) < ASPECT_RATIO_TOLERANCE;
  const isSlabRatio = Math.abs(detectedRatio - SLAB_ASPECT_RATIO) < ASPECT_RATIO_TOLERANCE;

  // Step 5: Determine confidence and type
  // If we found significant padding (>5% of image), we have high confidence
  const paddingLeft = detectedLeft / imgW;
  const paddingTop = detectedTop / imgH;
  const paddingRight = (imgW - detectedRight) / imgW;
  const paddingBottom = (imgH - detectedBottom) / imgH;
  const hasPadding = paddingLeft > 0.03 || paddingTop > 0.03 || paddingRight > 0.03 || paddingBottom > 0.03;

  let confidence: "high" | "medium" | "low" = "low";
  let type: "raw_card" | "psa_slab" | "full_image" = "full_image";

  if (isSlabRatio && hasPadding) {
    confidence = "high";
    type = "psa_slab";
  } else if (isCardRatio && hasPadding) {
    confidence = "high";
    type = "raw_card";
  } else if (hasPadding && detectedW > MIN_CARD_DIMENSION && detectedH > MIN_CARD_DIMENSION) {
    confidence = "medium";
    type = isSlabRatio ? "psa_slab" : "raw_card";
  } else {
    // No clear padding detected — treat the whole image as the card face
    confidence = "low";
    type = "full_image";
    return {
      left: 0,
      top: 0,
      width: imgW,
      height: imgH,
      confidence,
      type,
    };
  }

  return {
    left: detectedLeft,
    top: detectedTop,
    width: detectedW,
    height: detectedH,
    confidence,
    type,
  };
}

// ─── Frame Border Calculator ──────────────────────────────────────────────────

/**
 * Calculates the pixel size of a 1/8-inch border at the output DPI.
 * Standard card display: 300 DPI = 38px border, 150 DPI = 19px, 72 DPI = 9px
 */
export function calculateFrameBorderPx(outputWidthPx: number, cardWidthInches = 2.5): number {
  const dpi = outputWidthPx / cardWidthInches;
  const borderPx = Math.round((1 / 8) * dpi);
  return Math.max(4, Math.min(borderPx, 60)); // Clamp between 4px and 60px
}

// ─── Core Image Processor ─────────────────────────────────────────────────────

/**
 * Processes a single card image:
 * 1. Fetch from URL
 * 2. PSA compliance check
 * 3. Detect card face
 * 4. Crop to card face
 * 5. Add 1/8-inch white border frame
 * 6. Resize to web output dimensions
 * 7. Upload to S3
 */
export async function processCardImage(
  imageUrl: string,
  cardId: string,
  side: "front" | "back",
  options: Partial<ProcessImageOptions> = {}
): Promise<{ url: string | null; key: string | null; notes: string[]; compliant: boolean }> {
  const notes: string[] = [];
  const addFrame = options.addFrame !== false; // default true
  const frameColor = options.frameColor ?? { r: 255, g: 255, b: 255 };
  const skipCompliance = options.skipComplianceCheck ?? false;

  // 1. Fetch image
  const buffer = await fetchImageBuffer(imageUrl);
  if (!buffer) {
    return { url: null, key: null, notes: [`Failed to fetch image from ${imageUrl}`], compliant: false };
  }
  notes.push(`Fetched ${buffer.length} bytes from eBay`);

  // 2. PSA compliance check
  if (!skipCompliance) {
    const { compliant, reasons } = await checkPsaCompliance(buffer, imageUrl);
    if (!compliant) {
      notes.push(...reasons.map(r => `[PSA COMPLIANCE] ${r}`));
      // Log but don't block — compliance issues are warnings, not hard stops
      // (shipping claim text in URL doesn't mean the image itself has it)
    }
  }

  // 3. Detect card face
  let face: DetectedFace;
  try {
    face = await detectCardFace(buffer);
    notes.push(`Card face detected: ${face.type} at (${face.left},${face.top}) ${face.width}×${face.height}px [confidence: ${face.confidence}]`);
  } catch (e) {
    notes.push(`Face detection failed: ${(e as Error).message} — using full image`);
    const meta = await sharp(buffer).metadata();
    face = { left: 0, top: 0, width: meta.width ?? 800, height: meta.height ?? 1000, confidence: "low", type: "full_image" };
  }

  // 4. Crop to card face (with small safety margin to avoid cutting edges)
  const SAFETY_MARGIN = face.confidence === "high" ? 2 : 8; // px at original resolution
  const cropLeft = Math.max(0, face.left - SAFETY_MARGIN);
  const cropTop = Math.max(0, face.top - SAFETY_MARGIN);
  const meta = await sharp(buffer).metadata();
  const imgW = meta.width ?? 800;
  const imgH = meta.height ?? 1000;
  const cropWidth = Math.min(imgW - cropLeft, face.width + SAFETY_MARGIN * 2);
  const cropHeight = Math.min(imgH - cropTop, face.height + SAFETY_MARGIN * 2);

  let pipeline = sharp(buffer).extract({
    left: cropLeft,
    top: cropTop,
    width: cropWidth,
    height: cropHeight,
  });

  // 5. Resize to web output width (maintain aspect ratio)
  pipeline = pipeline.resize({ width: WEB_OUTPUT_WIDTH, fit: "inside", withoutEnlargement: false });

  // 6. Add 1/8-inch white border frame
  if (addFrame) {
    const borderPx = calculateFrameBorderPx(WEB_OUTPUT_WIDTH);
    notes.push(`Adding ${borderPx}px white border frame (1/8-inch equivalent at ${Math.round(WEB_OUTPUT_WIDTH / 2.5)} DPI)`);

    // Get dimensions after resize
    const resizedBuffer = await pipeline.toBuffer();
    const resizedMeta = await sharp(resizedBuffer).metadata();
    const rW = resizedMeta.width ?? WEB_OUTPUT_WIDTH;
    const rH = resizedMeta.height ?? Math.round(WEB_OUTPUT_WIDTH / CARD_ASPECT_RATIO);

    // Create white background canvas with border
    const canvasW = rW + borderPx * 2;
    const canvasH = rH + borderPx * 2;

    const framedBuffer = await sharp({
      create: {
        width: canvasW,
        height: canvasH,
        channels: 3,
        background: frameColor,
      },
    })
      .composite([{ input: resizedBuffer, left: borderPx, top: borderPx }])
      .jpeg({ quality: 92, progressive: true })
      .toBuffer();

    // 7. Upload to S3
    const s3Key = `card-images/${cardId}/${side}_processed_${Date.now()}.jpg`;
    try {
      const { url } = await storagePut(s3Key, framedBuffer, "image/jpeg");
      notes.push(`Uploaded to S3: ${s3Key} (${canvasW}×${canvasH}px)`);
      return { url, key: s3Key, notes, compliant: true };
    } catch (e) {
      notes.push(`S3 upload failed: ${(e as Error).message}`);
      return { url: null, key: null, notes, compliant: true };
    }
  } else {
    // No frame — just crop + resize
    const outputBuffer = await pipeline.jpeg({ quality: 92, progressive: true }).toBuffer();
    const s3Key = `card-images/${cardId}/${side}_processed_${Date.now()}.jpg`;
    try {
      const { url } = await storagePut(s3Key, outputBuffer, "image/jpeg");
      notes.push(`Uploaded to S3: ${s3Key}`);
      return { url, key: s3Key, notes, compliant: true };
    } catch (e) {
      notes.push(`S3 upload failed: ${(e as Error).message}`);
      return { url: null, key: null, notes, compliant: true };
    }
  }
}

// ─── Full Card Processor (front + back) ──────────────────────────────────────

/**
 * Processes both front and back images for a card.
 * Returns S3 URLs for both sides.
 */
export async function processCardImages(options: ProcessImageOptions): Promise<ProcessedCardImage> {
  const notes: string[] = [];
  let psaCompliant = true;

  // Process front
  const front = await processCardImage(
    options.frontImageUrl,
    options.cardId,
    "front",
    options
  );
  notes.push(...front.notes.map(n => `[FRONT] ${n}`));
  if (!front.compliant) psaCompliant = false;

  // Process back (if provided)
  let back: { url: string | null; key: string | null; notes: string[]; compliant: boolean } = {
    url: null, key: null, notes: [], compliant: true
  };
  if (options.backImageUrl) {
    back = await processCardImage(
      options.backImageUrl,
      options.cardId,
      "back",
      options
    );
    notes.push(...back.notes.map(n => `[BACK] ${n}`));
    if (!back.compliant) psaCompliant = false;
  } else {
    notes.push("[BACK] No back image URL provided — skipping");
  }

  // Get final dimensions from front
  let width = WEB_OUTPUT_WIDTH;
  let height = Math.round(WEB_OUTPUT_WIDTH / CARD_ASPECT_RATIO);
  if (front.url) {
    try {
      const buf = await fetchImageBuffer(front.url);
      if (buf) {
        const m = await sharp(buf).metadata();
        width = m.width ?? width;
        height = m.height ?? height;
      }
    } catch { /* ignore */ }
  }

  return {
    frontUrl: front.url,
    backUrl: back.url,
    frontKey: front.key,
    backKey: back.key,
    width,
    height,
    processingNotes: notes,
    psaCompliant,
  };
}
