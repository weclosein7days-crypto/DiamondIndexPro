/**
 * eBay Image Fetcher
 * ──────────────────
 * Fetches front and back card images from eBay listing galleries.
 *
 * eBay Browse API returns:
 *   - item.image.imageUrl       → primary (front) image
 *   - item.additionalImages[]   → gallery images (may include back, angles, etc.)
 *
 * Heuristics to identify the "back" image:
 *   1. If there are exactly 2 images → first = front, second = back
 *   2. If there are 3+ images → analyze position (back is usually 2nd or 3rd)
 *   3. If only 1 image → front only, no back
 *
 * PSA Compliance:
 *   - Only fetches images from eBay listings we actually carry
 *   - Does not scrape or cache images from PSA's cert database
 *   - Upgrades all image URLs to full resolution (s-l1600)
 */

import { fetchImageBuffer } from "./imageProcessor";

// ─── eBay OAuth Token ─────────────────────────────────────────────────────────

/** Simple eBay client credentials token (no caching needed for batch jobs) */
async function getEbayToken(): Promise<string> {
  const clientId = process.env.EBAY_CLIENT_ID!;
  const clientSecret = process.env.EBAY_CLIENT_SECRET!;
  if (!clientId || !clientSecret) {
    throw new Error("EBAY_CLIENT_ID and EBAY_CLIENT_SECRET must be set in environment variables");
  }
  const credentials = Buffer.from(`${clientId}:${clientSecret}`).toString("base64");
  const res = await fetch("https://api.ebay.com/identity/v1/oauth2/token", {
    method: "POST",
    headers: {
      "Authorization": `Basic ${credentials}`,
      "Content-Type": "application/x-www-form-urlencoded",
    },
    body: "grant_type=client_credentials&scope=https://api.ebay.com/oauth/api_scope",
  });
  const data = await res.json() as any;
  if (!data.access_token) throw new Error(`eBay OAuth failed: ${JSON.stringify(data)}`);
  return data.access_token;
}

// ─── Types ────────────────────────────────────────────────────────────────────

export interface EbayItemImages {
  itemId: string;
  title: string | null;
  frontImageUrl: string | null;
  backImageUrl: string | null;
  allImageUrls: string[];
  imageCount: number;
  fetchedAt: number;
  error?: string;
}

// ─── URL Utilities ────────────────────────────────────────────────────────────

/**
 * Upgrades an eBay image URL to full resolution (s-l1600).
 * eBay serves images at multiple sizes; s-l1600 is the largest available.
 */
export function upgradeEbayImageUrl(url: string): string {
  if (!url) return url;
  return url
    .replace(/s-l\d+\.(jpg|jpeg|webp|png)/i, "s-l1600.$1")
    .replace(/s-l\d+$/i, "s-l1600");
}

/**
 * Extracts the numeric eBay item ID from various formats:
 *   "v1|358404573406|0"  → "358404573406"
 *   "358404573406"       → "358404573406"
 */
export function extractEbayItemId(rawId: string): string {
  if (!rawId) return rawId;
  const parts = rawId.replace("v1|", "").split("|");
  return parts[0];
}

// ─── eBay Browse API Fetcher ──────────────────────────────────────────────────

/**
 * Fetches all images for an eBay listing using the Browse API.
 * Returns front + back URLs plus the full gallery.
 */
export async function fetchEbayItemImages(rawItemId: string): Promise<EbayItemImages> {
  const itemId = extractEbayItemId(rawItemId);
  const result: EbayItemImages = {
    itemId,
    title: null,
    frontImageUrl: null,
    backImageUrl: null,
    allImageUrls: [],
    imageCount: 0,
    fetchedAt: Date.now(),
  };

  try {
    const token = await getEbayToken();

    // Use Browse API item endpoint to get full item details including all images
    const res = await fetch(`https://api.ebay.com/buy/browse/v1/item/v1|${itemId}|0`, {
      headers: {
        "Authorization": `Bearer ${token}`,
        "X-EBAY-C-MARKETPLACE-ID": "EBAY_US",
        "X-EBAY-C-ENDUSERCTX": "contextualLocation=country=US",
      },
      signal: AbortSignal.timeout(15_000),
    });

    if (!res.ok) {
      result.error = `eBay API returned ${res.status}: ${res.statusText}`;
      return result;
    }

    const data = await res.json() as {
      itemId?: string;
      title?: string;
      image?: { imageUrl: string };
      additionalImages?: Array<{ imageUrl: string }>;
    };

    result.title = data.title ?? null;

    // Collect all image URLs
    const allUrls: string[] = [];

    if (data.image?.imageUrl) {
      allUrls.push(upgradeEbayImageUrl(data.image.imageUrl));
    }

    if (data.additionalImages?.length) {
      for (const img of data.additionalImages) {
        if (img.imageUrl) {
          allUrls.push(upgradeEbayImageUrl(img.imageUrl));
        }
      }
    }

    result.allImageUrls = allUrls;
    result.imageCount = allUrls.length;

    if (allUrls.length === 0) {
      result.error = "No images found in eBay listing";
      return result;
    }

    // Assign front and back
    result.frontImageUrl = allUrls[0];

    if (allUrls.length >= 2) {
      // Heuristic: back is typically the 2nd image in sports card listings
      // For PSA slabs, the back shows the label/cert number
      result.backImageUrl = await identifyBackImage(allUrls);
    }

    return result;
  } catch (e) {
    result.error = `Fetch failed: ${(e as Error).message}`;
    return result;
  }
}

// ─── Back Image Identifier ────────────────────────────────────────────────────

/**
 * Identifies which image in the gallery is the card back.
 *
 * Strategy:
 * - For 2-image listings: second image is always the back
 * - For 3+ image listings: analyze each image's brightness distribution
 *   - Card backs tend to be lighter (more white/stats text area)
 *   - PSA slab backs show the certification label (distinctive bright yellow/white)
 * - Falls back to the second image if analysis is inconclusive
 */
async function identifyBackImage(imageUrls: string[]): Promise<string | null> {
  if (imageUrls.length < 2) return null;

  // For exactly 2 images, second is always the back
  if (imageUrls.length === 2) return imageUrls[1];

  // For 3+ images, try to find the back by analyzing brightness
  // The front (player photo) tends to be darker/more colorful
  // The back (stats/cert) tends to be lighter/more uniform
  try {
    const brightnessScores: { url: string; brightness: number }[] = [];

    // Only analyze first 4 images to keep it fast
    const toAnalyze = imageUrls.slice(0, Math.min(4, imageUrls.length));

    for (const url of toAnalyze) {
      const buf = await fetchImageBuffer(url);
      if (!buf) { brightnessScores.push({ url, brightness: 0 }); continue; }

      const { data } = await import("sharp").then(s =>
        s.default(buf)
          .resize({ width: 100, height: 100, fit: "fill" })
          .grayscale()
          .raw()
          .toBuffer({ resolveWithObject: true })
      );

      const avgBrightness = Array.from(data).reduce((sum, px) => sum + px, 0) / data.length;
      brightnessScores.push({ url, brightness: avgBrightness });
    }

    // Front is typically the darkest (player photo with colorful design)
    // Back is typically brighter (white stats area or cert label)
    brightnessScores.sort((a, b) => a.brightness - b.brightness);

    // The darkest is the front, the second darkest (or brightest) is the back
    const frontUrl = brightnessScores[0].url;
    const backCandidates = brightnessScores.filter(s => s.url !== frontUrl);

    if (backCandidates.length > 0) {
      // Prefer the image right after the front in the original order
      const frontIdx = imageUrls.indexOf(frontUrl);
      const nextIdx = frontIdx + 1 < imageUrls.length ? frontIdx + 1 : 0;
      return imageUrls[nextIdx];
    }

    return imageUrls[1]; // Fallback
  } catch {
    return imageUrls[1]; // Safe fallback
  }
}

// ─── Batch Fetcher ────────────────────────────────────────────────────────────

export interface BatchFetchResult {
  itemId: string;
  success: boolean;
  frontImageUrl: string | null;
  backImageUrl: string | null;
  imageCount: number;
  error?: string;
}

/**
 * Fetches images for multiple eBay items in batches.
 * Respects rate limits with configurable delay between requests.
 */
export async function fetchEbayImagesBatch(
  itemIds: string[],
  options: {
    delayMs?: number;
    onProgress?: (done: number, total: number, current: string) => void;
  } = {}
): Promise<BatchFetchResult[]> {
  const { delayMs = 500, onProgress } = options;
  const results: BatchFetchResult[] = [];

  for (let i = 0; i < itemIds.length; i++) {
    const rawId = itemIds[i];
    const itemId = extractEbayItemId(rawId);

    onProgress?.(i, itemIds.length, itemId);

    const images = await fetchEbayItemImages(rawId);
    results.push({
      itemId: rawId,
      success: !images.error,
      frontImageUrl: images.frontImageUrl,
      backImageUrl: images.backImageUrl,
      imageCount: images.imageCount,
      error: images.error,
    });

    // Rate limit: wait between requests
    if (i < itemIds.length - 1 && delayMs > 0) {
      await new Promise(resolve => setTimeout(resolve, delayMs));
    }
  }

  onProgress?.(itemIds.length, itemIds.length, "done");
  return results;
}
