import { describe, it, expect } from "vitest";

// Unit tests for trade agreement address logic
describe("Trade Agreement Address Fields", () => {
  it("should collect initiator address fields on agree", () => {
    const updates: Record<string, unknown> = {};
    const isInitiator = true;
    const input = {
      id: 1,
      address: "123 Main St",
      city: "Columbus",
      state: "OH",
      zip: "43215",
      phone: "555-1234",
    };
    if (isInitiator) {
      updates.initiatorAgreed = true;
      updates.initiatorSignedAt = new Date();
      if (input.address) updates.initiatorAddress = input.address;
      if (input.city) updates.initiatorCity = input.city;
      if (input.state) updates.initiatorState = input.state;
      if (input.zip) updates.initiatorZip = input.zip;
      if (input.phone) updates.initiatorPhone = input.phone;
    }
    expect(updates.initiatorAgreed).toBe(true);
    expect(updates.initiatorAddress).toBe("123 Main St");
    expect(updates.initiatorCity).toBe("Columbus");
    expect(updates.initiatorState).toBe("OH");
    expect(updates.initiatorZip).toBe("43215");
    expect(updates.initiatorPhone).toBe("555-1234");
    expect(updates.initiatorSignedAt).toBeInstanceOf(Date);
  });

  it("should collect receiver address fields on agree", () => {
    const updates: Record<string, unknown> = {};
    const isReceiver = true;
    const input = {
      id: 2,
      address: "456 Oak Ave",
      city: "Granville",
      state: "OH",
      zip: "43023",
      phone: "555-5678",
    };
    if (isReceiver) {
      updates.receiverAgreed = true;
      updates.receiverSignedAt = new Date();
      if (input.address) updates.receiverAddress = input.address;
      if (input.city) updates.receiverCity = input.city;
      if (input.state) updates.receiverState = input.state;
      if (input.zip) updates.receiverZip = input.zip;
      if (input.phone) updates.receiverPhone = input.phone;
    }
    expect(updates.receiverAgreed).toBe(true);
    expect(updates.receiverAddress).toBe("456 Oak Ave");
    expect(updates.receiverCity).toBe("Granville");
    expect(updates.receiverState).toBe("OH");
    expect(updates.receiverZip).toBe("43023");
    expect(updates.receiverPhone).toBe("555-5678");
  });

  it("should detect both-agreed state and generate ticket number", () => {
    const newInitiatorAgreed = true;
    const newReceiverAgreed = true;
    const bothAgreed = newInitiatorAgreed && newReceiverAgreed;
    expect(bothAgreed).toBe(true);

    const tradeId = 42;
    const ticketNum = `SCO-${tradeId}-${Date.now().toString().slice(-6)}`;
    expect(ticketNum).toMatch(/^SCO-42-\d{6}$/);
  });

  it("should build next-steps message with trade summary", () => {
    const tradeId = 42;
    const ticketNum = "SCO-42-123456";
    const offeredList = ["  • Mike Trout 2026 Topps", "  • Caitlin Clark Holo"].join("\n");
    const requestedList = ["  • Shohei Ohtani RC"].join("\n");
    const msg =
      `✅ TRADE AGREEMENT CONFIRMED — #${ticketNum}\n\n` +
      `Both parties have digitally agreed to this trade. Here is what happens next:\n\n` +
      `📋 TRADE SUMMARY\n` +
      `Initiator is sending:\n${offeredList}\n\n` +
      `Receiver is sending:\n${requestedList}`;
    expect(msg).toContain("SCO-42-123456");
    expect(msg).toContain("Mike Trout");
    expect(msg).toContain("Shohei Ohtani");
    expect(msg).toContain("TRADE AGREEMENT CONFIRMED");
  });

  it("should not set bothAgreed if only one party agreed", () => {
    const newInitiatorAgreed = true;
    const newReceiverAgreed = false;
    const bothAgreed = newInitiatorAgreed && newReceiverAgreed;
    expect(bothAgreed).toBe(false);
  });
});
