/**
 * Direct SMTP email test — bypasses webhook, calls email functions directly.
 * Run with: node server/test-email-send.mjs
 */
import nodemailer from "nodemailer";

const SMTP_USER = process.env.SMTP_USER;
const SMTP_PASS = process.env.SMTP_PASS;
const SMTP_HOST = process.env.SMTP_HOST || "smtp.ionos.com";
const SMTP_PORT = parseInt(process.env.SMTP_PORT || "587", 10);
const SMTP_FROM = process.env.SMTP_FROM || `SportCardsOnline <${SMTP_USER}>`;

if (!SMTP_USER || !SMTP_PASS) {
  console.error("❌ SMTP_USER or SMTP_PASS not set");
  process.exit(1);
}

const transporter = nodemailer.createTransport({
  host: SMTP_HOST,
  port: SMTP_PORT,
  secure: SMTP_PORT === 465,
  auth: { user: SMTP_USER, pass: SMTP_PASS },
  tls: { rejectUnauthorized: false },
});

// ── Verify connection ─────────────────────────────────────────────────────────
console.log(`🔌 Connecting to ${SMTP_HOST}:${SMTP_PORT} as ${SMTP_USER}...`);
try {
  await transporter.verify();
  console.log("✅ SMTP connection verified");
} catch (err) {
  console.error("❌ SMTP verify failed:", err.message);
  process.exit(1);
}

// ── Test card data ────────────────────────────────────────────────────────────
const testCard = {
  title: "2003 LeBron James Topps Rookie Card PSA 10",
  price: "$21.59",
  id: 14,
};
const buyerEmail = SMTP_USER; // Send to staff inbox so you can see it
const sellerEmail = SMTP_USER;
const orderId = "TEST-" + Date.now();

// ── Buyer: Order Confirmation ─────────────────────────────────────────────────
const buyerHtml = `
<!DOCTYPE html><html><body style="font-family:Arial,sans-serif;background:#0a0f1e;color:#fff;padding:32px;">
<div style="max-width:600px;margin:0 auto;background:#111827;border-radius:12px;padding:32px;">
  <h1 style="color:#ef4444;">🏆 SportCardsOnline</h1>
  <h2 style="color:#fff;">Order Confirmed!</h2>
  <p>Hi <strong>Test Buyer</strong>,</p>
  <p>Your order has been confirmed and payment received. Here are your order details:</p>
  <table style="width:100%;border-collapse:collapse;margin:16px 0;">
    <tr style="background:#1f2937;">
      <td style="padding:12px;border:1px solid #374151;"><strong>Card</strong></td>
      <td style="padding:12px;border:1px solid #374151;">${testCard.title}</td>
    </tr>
    <tr>
      <td style="padding:12px;border:1px solid #374151;"><strong>Order ID</strong></td>
      <td style="padding:12px;border:1px solid #374151;">${orderId}</td>
    </tr>
    <tr style="background:#1f2937;">
      <td style="padding:12px;border:1px solid #374151;"><strong>Amount Paid</strong></td>
      <td style="padding:12px;border:1px solid #374151;">${testCard.price}</td>
    </tr>
    <tr>
      <td style="padding:12px;border:1px solid #374151;"><strong>Status</strong></td>
      <td style="padding:12px;border:1px solid #374151;color:#22c55e;">✅ Payment Received — Awaiting Shipment</td>
    </tr>
  </table>
  <p>Your payment is held securely in escrow. Once the seller ships and you confirm receipt, funds will be released.</p>
  <p>You have <strong>24 hours after delivery</strong> to confirm receipt. If we don't hear from you, funds are automatically released to the seller.</p>
  <p style="color:#9ca3af;font-size:12px;">This is a test email sent from the CardVault platform. Order ID: ${orderId}</p>
</div>
</body></html>`;

// ── Seller: New Order Received ────────────────────────────────────────────────
const sellerHtml = `
<!DOCTYPE html><html><body style="font-family:Arial,sans-serif;background:#0a0f1e;color:#fff;padding:32px;">
<div style="max-width:600px;margin:0 auto;background:#111827;border-radius:12px;padding:32px;">
  <h1 style="color:#ef4444;">🏆 SportCardsOnline</h1>
  <h2 style="color:#fff;">New Order Received!</h2>
  <p>Hi <strong>SCO House</strong>,</p>
  <p>You have a new order! Please prepare the card for shipment.</p>
  <table style="width:100%;border-collapse:collapse;margin:16px 0;">
    <tr style="background:#1f2937;">
      <td style="padding:12px;border:1px solid #374151;"><strong>Card Sold</strong></td>
      <td style="padding:12px;border:1px solid #374151;">${testCard.title}</td>
    </tr>
    <tr>
      <td style="padding:12px;border:1px solid #374151;"><strong>Order ID</strong></td>
      <td style="padding:12px;border:1px solid #374151;">${orderId}</td>
    </tr>
    <tr style="background:#1f2937;">
      <td style="padding:12px;border:1px solid #374151;"><strong>Sale Price</strong></td>
      <td style="padding:12px;border:1px solid #374151;">${testCard.price}</td>
    </tr>
    <tr>
      <td style="padding:12px;border:1px solid #374151;"><strong>Buyer</strong></td>
      <td style="padding:12px;border:1px solid #374151;">Test Buyer (testbuyer@example.com)</td>
    </tr>
  </table>
  <p><strong>Next steps:</strong></p>
  <ol>
    <li>Purchase a shipping label and get your tracking number</li>
    <li>Log into the platform and enter the tracking number in the order</li>
    <li>Ship the card within 3 business days</li>
    <li>Mark the order as shipped in the messaging thread</li>
  </ol>
  <p style="color:#9ca3af;font-size:12px;">This is a test email sent from the CardVault platform. Order ID: ${orderId}</p>
</div>
</body></html>`;

// ── Send both emails ──────────────────────────────────────────────────────────
console.log("\n📧 Sending BUYER order confirmation email...");
try {
  const info = await transporter.sendMail({
    from: SMTP_FROM,
    to: buyerEmail,
    subject: `[TEST] ✅ Order Confirmed — ${testCard.title}`,
    html: buyerHtml,
  });
  console.log("✅ Buyer email sent! Message ID:", info.messageId);
} catch (err) {
  console.error("❌ Buyer email failed:", err.message);
}

console.log("\n📧 Sending SELLER new order notification email...");
try {
  const info = await transporter.sendMail({
    from: SMTP_FROM,
    to: sellerEmail,
    subject: `[TEST] 🛒 New Order Received — ${testCard.title}`,
    html: sellerHtml,
  });
  console.log("✅ Seller email sent! Message ID:", info.messageId);
} catch (err) {
  console.error("❌ Seller email failed:", err.message);
}

console.log("\n🏁 Test complete. Check your inbox at:", SMTP_USER);
