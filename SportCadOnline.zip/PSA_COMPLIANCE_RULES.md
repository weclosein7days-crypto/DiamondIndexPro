# PSA Compliance Rules for CardVault Image Processor

## Summary of Key Rules (from PSA Terms & Conditions, Feb 10 2026)

### Image Ownership
- PSA **owns** all images of cards submitted to them (Submission Content).
- PSA grants customers a **limited, revocable license** to display Grader Notes (including an image) alongside the grade or PSA certification label for that specific item.
- Customer **may NOT** publish, display, recreate, sublicense, or create derivative works from Grader Notes without PSA's written consent.

### What We CAN Do (CardVault's Situation)
CardVault sources cards from **eBay listings** (not directly from PSA submissions). The images come from:
1. **eBay seller-uploaded photos** — owned by the seller, licensed to eBay for display.
2. **PSA's own cert lookup images** — PSA-owned, limited license for display alongside cert info.

Since CardVault buys cards through eBay (dropship model) and **does not submit to PSA directly**, the compliance rules are:

#### ALLOWED:
- Display eBay seller photos of cards we have purchased/listed for sale.
- Show the card image alongside the PSA cert number, grade, and label image.
- Crop and frame card images for display purposes (transformative presentation).
- Show front and back of a card from eBay listing gallery images.
- Reference PSA grade (e.g., "PSA 9") as a factual descriptor.

#### NOT ALLOWED:
- Claim we ship cards ourselves (we use PSA Vault / eBay dropship — PSA ships).
- Use the PSA logo as if we are PSA or affiliated with PSA.
- Imply PSA endorses our platform.
- Show shipping labels, tracking numbers, or "ships from PSA" messaging.
- Use PSA's cert database images without displaying them alongside the cert number.
- Misrepresent the grade or condition of a card.
- Show images of cards we don't actually have for sale.

### Key Compliance Rules for Image Processor

1. **No shipping claims in images** — Strip/reject images that contain text like "ships from", "free shipping", "seller ships", watermarks with shipping info.
2. **No PSA logo misuse** — Do not overlay PSA logo on processed images. Only display PSA grade as text.
3. **No false representation** — Only process and display images of cards actually in our inventory.
4. **Attribution** — When displaying eBay images, they remain attributed to the eBay listing.
5. **Cert display** — If showing PSA cert image, always pair it with the cert number and grade.
6. **No derivative works from PSA scans** — Do not crop/modify images sourced directly from PSA's cert lookup; only use eBay seller photos.

### Image Sources Priority Order
1. **eBay listing gallery** — Primary source (seller-uploaded, multiple angles, front + back).
2. **PSA cert lookup** — Secondary, display only with cert number, no modification.
3. **Fallback** — Placeholder card image if no valid image found.

### Watermark / Overlay Rules
- May add CardVault branding watermark to processed images (subtle, corner placement).
- Must NOT add text claiming shipping, pricing guarantees, or PSA affiliation.
- The 1/8" white border frame is purely aesthetic — compliant.

### Auto-Reject Triggers (Image Compliance Filter)
The processor should flag/reject images containing:
- Text: "ships from", "free shipping", "seller ships", "I ship", "will ship"
- Watermarks with seller contact info (email, phone, social handles)
- PSA logo used as a badge/overlay (not the actual slab label)
- Images that are clearly not the card (packaging, envelopes, etc.)
- Blurry or low-resolution images (< 300px on shortest side)
