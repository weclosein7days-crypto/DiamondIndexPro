#!/usr/bin/env python3
"""
Bulk generate videos for all blog posts without videos, then upload to YouTube.
Runs directly against the API server.
"""

import json
import sys
import time
import urllib.request
import urllib.parse
import subprocess
import os
import tempfile
import http.client

BASE = "http://localhost:3000"

def api_get(path):
    url = BASE + path
    with urllib.request.urlopen(url, timeout=30) as r:
        return json.load(r)

def api_post(path, data):
    body = json.dumps({"json": data}).encode()
    req = urllib.request.Request(
        BASE + path,
        data=body,
        headers={"Content-Type": "application/json"},
        method="POST"
    )
    with urllib.request.urlopen(req, timeout=600) as r:
        return json.load(r)

def get_all_posts():
    data = api_get("/api/trpc/blog.listPosts?input=%7B%22json%22%3A%7B%22limit%22%3A100%7D%7D")
    return data['result']['data']['json']

def get_post_content(post_id):
    encoded = urllib.parse.quote(json.dumps({"json": {"id": post_id}}))
    data = api_get(f"/api/trpc/blog.getPost?input={encoded}")
    return data['result']['data']['json']

def trigger_generate_video(post_id):
    """Call the admin generateBlogVideo procedure."""
    data = api_post(
        "/api/trpc/admin.generateBlogVideo",
        {"postId": post_id}
    )
    return data

def trigger_youtube_upload(post_id):
    """Call the admin publishBlogVideoToYouTube procedure."""
    data = api_post(
        "/api/trpc/admin.publishBlogVideoToYouTube",
        {"postId": post_id}
    )
    return data

def main():
    print("=== Fetching all blog posts ===")
    posts = get_all_posts()
    print(f"Found {len(posts)} total posts")

    # Find posts without videos
    needs_video = [(p['id'], p['title'][:60]) for p in posts if not p.get('videoUrl')]
    has_video_no_yt = [(p['id'], p['title'][:60], p.get('videoUrl')) for p in posts if p.get('videoUrl') and not p.get('youtubeVideoId')]
    already_done = [(p['id'], p['title'][:60], p.get('youtubeVideoId')) for p in posts if p.get('youtubeVideoId')]

    print(f"\nNeeds video generation: {len(needs_video)}")
    print(f"Has video, needs YouTube upload: {len(has_video_no_yt)}")
    print(f"Already on YouTube: {len(already_done)}")

    results = []

    # Step 1: Generate videos for posts that don't have them
    for post_id, title in needs_video:
        print(f"\n[{post_id}] Generating video: {title}")
        try:
            result = trigger_generate_video(post_id)
            if result.get('result', {}).get('data', {}).get('json', {}).get('success'):
                video_url = result['result']['data']['json'].get('videoUrl', '')
                print(f"  ✅ Video generated: {video_url[:60]}")
                has_video_no_yt.append((post_id, title, video_url))
            else:
                err = result.get('error', {}).get('message', str(result))
                print(f"  ❌ Video generation failed: {err[:100]}")
                results.append({"id": post_id, "title": title, "status": "video_failed", "error": err[:100]})
        except Exception as e:
            print(f"  ❌ Exception: {e}")
            results.append({"id": post_id, "title": title, "status": "video_exception", "error": str(e)[:100]})
        time.sleep(2)  # brief pause between generations

    # Step 2: Upload all videos to YouTube
    print(f"\n=== Uploading {len(has_video_no_yt)} videos to YouTube ===")
    for post_id, title, video_url in has_video_no_yt:
        print(f"\n[{post_id}] Uploading to YouTube: {title}")
        try:
            result = trigger_youtube_upload(post_id)
            yt_data = result.get('result', {}).get('data', {}).get('json', {})
            if yt_data.get('youtubeUrl'):
                yt_url = yt_data['youtubeUrl']
                yt_id = yt_data.get('videoId', '')
                print(f"  ✅ YouTube: {yt_url}")
                results.append({"id": post_id, "title": title, "status": "uploaded", "youtubeUrl": yt_url, "videoId": yt_id})
            else:
                err = result.get('error', {}).get('message', str(result)[:200])
                print(f"  ❌ YouTube upload failed: {err[:150]}")
                results.append({"id": post_id, "title": title, "status": "yt_failed", "error": err[:150]})
        except Exception as e:
            print(f"  ❌ Exception: {e}")
            results.append({"id": post_id, "title": title, "status": "yt_exception", "error": str(e)[:150]})
        time.sleep(3)  # pause between uploads to avoid quota issues

    # Summary
    print("\n=== FINAL SUMMARY ===")
    uploaded = [r for r in results if r['status'] == 'uploaded']
    failed = [r for r in results if r['status'] != 'uploaded']
    print(f"✅ Successfully uploaded to YouTube: {len(uploaded)}")
    for r in uploaded:
        print(f"   [{r['id']}] {r['title'][:50]} -> {r.get('youtubeUrl','')}")
    if failed:
        print(f"❌ Failed: {len(failed)}")
        for r in failed:
            print(f"   [{r['id']}] {r['title'][:50]} | {r['status']}: {r.get('error','')[:80]}")

    print("\nDone!")
    return results

if __name__ == "__main__":
    main()
