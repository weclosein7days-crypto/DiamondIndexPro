ALTER TABLE `orders` ADD `fulfillmentPreference` enum('pending','vault','ship') DEFAULT 'pending';--> statement-breakpoint
ALTER TABLE `orders` ADD `vaultRequestedAt` timestamp;--> statement-breakpoint
ALTER TABLE `orders` ADD `shipLabelEmailSentAt` timestamp;