CREATE TABLE `favorites` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`cardId` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `favorites_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `user_interests` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`playerName` varchar(255) NOT NULL,
	`sport` varchar(50),
	`searchCount` int NOT NULL DEFAULT 1,
	`viewCount` int NOT NULL DEFAULT 0,
	`avgPrice` decimal(10,2),
	`lastInteractedAt` timestamp NOT NULL DEFAULT (now()),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `user_interests_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `game_plays` MODIFY COLUMN `gameType` enum('pack_rip','spin_wheel','scratch_card','tournament','poker','roulette','blackjack','free_spin') NOT NULL;--> statement-breakpoint
ALTER TABLE `auctions` ADD `buyNowPrice` decimal(10,2);--> statement-breakpoint
ALTER TABLE `auctions` ADD `minBidPrice` decimal(10,2);--> statement-breakpoint
ALTER TABLE `auctions` ADD `autoRenew` boolean DEFAULT true NOT NULL;--> statement-breakpoint
ALTER TABLE `auctions` ADD `renewCount` int DEFAULT 0 NOT NULL;