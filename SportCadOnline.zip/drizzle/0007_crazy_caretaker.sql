CREATE TABLE `orderMessages` (
	`id` int AUTO_INCREMENT NOT NULL,
	`orderId` int NOT NULL,
	`senderEmail` varchar(320) NOT NULL,
	`senderName` varchar(255),
	`senderRole` enum('buyer','seller','system','admin') NOT NULL,
	`messageText` text NOT NULL,
	`isRead` boolean DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `orderMessages_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `orders` MODIFY COLUMN `status` enum('pending','paid','label_created','shipped','delivered','confirmed','completed','cancelled','refunded','disputed') NOT NULL DEFAULT 'pending';--> statement-breakpoint
ALTER TABLE `orders` ADD `carrier` varchar(100);--> statement-breakpoint
ALTER TABLE `orders` ADD `labelPurchased` boolean DEFAULT false;--> statement-breakpoint
ALTER TABLE `orders` ADD `deliveredAt` timestamp;--> statement-breakpoint
ALTER TABLE `orders` ADD `confirmedAt` timestamp;--> statement-breakpoint
ALTER TABLE `orders` ADD `autoReleaseAt` timestamp;--> statement-breakpoint
ALTER TABLE `orders` ADD `fundsReleasedAt` timestamp;--> statement-breakpoint
ALTER TABLE `orders` ADD `shipByDeadline` timestamp;--> statement-breakpoint
ALTER TABLE `orders` ADD `stripePaymentIntentId` varchar(255);