CREATE TABLE `compReferences` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`collectionItemId` int NOT NULL,
	`salePrice` decimal(10,2) NOT NULL,
	`saleDate` varchar(30),
	`condition` varchar(100),
	`platform` varchar(50) NOT NULL DEFAULT 'eBay',
	`sourceUrl` text,
	`title` varchar(255),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `compReferences_id` PRIMARY KEY(`id`)
);
