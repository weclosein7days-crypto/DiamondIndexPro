CREATE TABLE `kids_activity_log` (
	`id` int AUTO_INCREMENT NOT NULL,
	`kidId` int NOT NULL,
	`activityType` enum('daily_claim','card_pull','trivia_correct','trivia_wrong','view_card','add_wishlist','share_collection','complete_checklist','trade_scenario','value_game') NOT NULL,
	`creditsEarned` int NOT NULL DEFAULT 0,
	`creditsSpent` int NOT NULL DEFAULT 0,
	`metadata` json,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `kids_activity_log_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `kids_collection` (
	`id` int AUTO_INCREMENT NOT NULL,
	`kidId` int NOT NULL,
	`playerName` varchar(255) NOT NULL,
	`year` varchar(8),
	`sport` varchar(32),
	`setName` varchar(255),
	`cardNumber` varchar(32),
	`imageUrl` text,
	`rarity` enum('common','uncommon','rare','epic','legendary') NOT NULL DEFAULT 'common',
	`estimatedValue` decimal(10,2) DEFAULT '0.00',
	`isFavorite` boolean NOT NULL DEFAULT false,
	`source` enum('daily_pull','trivia_reward','activity_reward','trade','starter_pack') NOT NULL DEFAULT 'daily_pull',
	`acquiredAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `kids_collection_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `kids_daily_checklist` (
	`id` int AUTO_INCREMENT NOT NULL,
	`title` varchar(255) NOT NULL,
	`description` text,
	`activityType` varchar(64) NOT NULL,
	`creditsReward` int NOT NULL DEFAULT 5,
	`icon` varchar(8) DEFAULT '⭐',
	`sortOrder` int NOT NULL DEFAULT 0,
	`isActive` boolean NOT NULL DEFAULT true,
	CONSTRAINT `kids_daily_checklist_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `kids_profiles` (
	`id` int AUTO_INCREMENT NOT NULL,
	`parentUserId` int NOT NULL,
	`username` varchar(64) NOT NULL,
	`displayName` varchar(128) NOT NULL,
	`birthdate` varchar(10) NOT NULL,
	`avatarEmoji` varchar(8) DEFAULT '⭐',
	`credits` int NOT NULL DEFAULT 50,
	`totalCreditsEarned` int NOT NULL DEFAULT 50,
	`level` int NOT NULL DEFAULT 1,
	`xp` int NOT NULL DEFAULT 0,
	`isActive` boolean NOT NULL DEFAULT true,
	`lastDailyClaimAt` timestamp,
	`shareToken` varchar(64),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `kids_profiles_id` PRIMARY KEY(`id`),
	CONSTRAINT `kids_profiles_username_unique` UNIQUE(`username`),
	CONSTRAINT `kids_profiles_shareToken_unique` UNIQUE(`shareToken`)
);
--> statement-breakpoint
CREATE TABLE `kids_trivia_questions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`question` text NOT NULL,
	`correctAnswer` varchar(255) NOT NULL,
	`choiceA` varchar(255) NOT NULL,
	`choiceB` varchar(255) NOT NULL,
	`choiceC` varchar(255) NOT NULL,
	`choiceD` varchar(255) NOT NULL,
	`sport` varchar(32),
	`difficulty` enum('easy','medium','hard') NOT NULL DEFAULT 'easy',
	`ageMin` int NOT NULL DEFAULT 6,
	`category` enum('player_fact','record','history','card_value','trade_scenario','president_era') NOT NULL DEFAULT 'player_fact',
	`creditsReward` int NOT NULL DEFAULT 5,
	`funFact` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `kids_trivia_questions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `kids_wishlist` (
	`id` int AUTO_INCREMENT NOT NULL,
	`kidId` int NOT NULL,
	`playerName` varchar(255) NOT NULL,
	`year` varchar(8),
	`sport` varchar(32),
	`setName` varchar(255),
	`notes` text,
	`addedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `kids_wishlist_id` PRIMARY KEY(`id`)
);
