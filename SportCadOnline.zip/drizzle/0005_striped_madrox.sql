ALTER TABLE `collections` ADD `listingStatus` enum('none','listed','auction','trading','sold') DEFAULT 'none' NOT NULL;--> statement-breakpoint
ALTER TABLE `collections` ADD `linkedCardId` int;