CREATE TABLE `kids_play_sessions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`kidId` int NOT NULL,
	`sessionDate` varchar(10) NOT NULL,
	`startedAt` timestamp NOT NULL DEFAULT (now()),
	`endedAt` timestamp,
	`durationSeconds` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `kids_play_sessions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `kids_time_allowances` (
	`id` int AUTO_INCREMENT NOT NULL,
	`kidId` int NOT NULL,
	`grantedByUserId` int NOT NULL,
	`allowanceDate` varchar(10) NOT NULL,
	`bonusSeconds` int NOT NULL DEFAULT 3600,
	`reason` varchar(255),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `kids_time_allowances_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `kids_trade_requests` (
	`id` int AUTO_INCREMENT NOT NULL,
	`offererId` int NOT NULL,
	`receiverId` int NOT NULL,
	`offeredCardId` int NOT NULL,
	`requestedCardId` int NOT NULL,
	`status` enum('pending','accepted','declined','cancelled','expired') NOT NULL DEFAULT 'pending',
	`message` varchar(255),
	`expiresAt` timestamp NOT NULL,
	`respondedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `kids_trade_requests_id` PRIMARY KEY(`id`)
);
