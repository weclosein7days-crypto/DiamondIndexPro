CREATE TABLE `affiliateReferrals` (
	`id` int AUTO_INCREMENT NOT NULL,
	`affiliateEmail` varchar(320) NOT NULL,
	`referralCode` varchar(20) NOT NULL,
	`referredEmail` varchar(320) NOT NULL,
	`referredName` varchar(255),
	`commissionAmount` decimal(10,2) DEFAULT '0.00',
	`status` enum('pending','paid','cancelled') NOT NULL DEFAULT 'pending',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `affiliateReferrals_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `affiliates` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userEmail` varchar(320) NOT NULL,
	`userName` varchar(255),
	`referralCode` varchar(20) NOT NULL,
	`totalReferrals` int DEFAULT 0,
	`totalEarnings` decimal(10,2) DEFAULT '0.00',
	`pendingPayout` decimal(10,2) DEFAULT '0.00',
	`paidOut` decimal(10,2) DEFAULT '0.00',
	`status` enum('active','suspended','pending') NOT NULL DEFAULT 'active',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `affiliates_id` PRIMARY KEY(`id`),
	CONSTRAINT `affiliates_userEmail_unique` UNIQUE(`userEmail`),
	CONSTRAINT `affiliates_referralCode_unique` UNIQUE(`referralCode`)
);
--> statement-breakpoint
CREATE TABLE `auctions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`cardId` int NOT NULL,
	`cardTitle` varchar(255) NOT NULL,
	`cardImageUrl` text,
	`sellerEmail` varchar(320) NOT NULL,
	`storeName` varchar(255),
	`startingPrice` decimal(10,2) NOT NULL,
	`currentBid` decimal(10,2) DEFAULT '0.00',
	`highestBidderEmail` varchar(320),
	`highestBidderName` varchar(255),
	`bidCount` int DEFAULT 0,
	`endTime` timestamp NOT NULL,
	`status` enum('active','ended','cancelled','sold') NOT NULL DEFAULT 'active',
	`playerName` varchar(255),
	`gradeInfo` varchar(100),
	`durationDays` int NOT NULL,
	`listingCreditsPaid` int NOT NULL,
	`buyNowPrice` decimal(10,2),
	`minBidPrice` decimal(10,2),
	`autoRenew` boolean NOT NULL DEFAULT true,
	`renewCount` int NOT NULL DEFAULT 0,
	`isVaulted` boolean DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `auctions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `bids` (
	`id` int AUTO_INCREMENT NOT NULL,
	`auctionId` int NOT NULL,
	`bidderEmail` varchar(320) NOT NULL,
	`bidderName` varchar(255),
	`bidAmount` decimal(10,2) NOT NULL,
	`bidTime` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `bids_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `cardEvents` (
	`id` int AUTO_INCREMENT NOT NULL,
	`collectionItemId` int NOT NULL DEFAULT 0,
	`cardId` int,
	`userEmail` varchar(320),
	`eventType` enum('added','graded','listed','delisted','auction_started','auction_ended','bid_received','trade_offered','trade_agreed','trade_fee_paid','shipped_to_scg','received_by_scg','shipped_to_recipient','delivered','sold','traded','price_updated','note_added','imported','vaulted','casino_assigned','status_changed','auction_bid','auction_won','bulk_action') NOT NULL,
	`description` text,
	`metadata` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `cardEvents_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `cardFingerprints` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userEmail` varchar(320) NOT NULL,
	`frontImageHash` varchar(255) NOT NULL,
	`backImageHash` varchar(255) NOT NULL,
	`overallGrade` decimal(4,2),
	`gradeLabel` varchar(50),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `cardFingerprints_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `card_images` (
	`id` int AUTO_INCREMENT NOT NULL,
	`scpId` varchar(32) NOT NULL,
	`productName` varchar(512) NOT NULL,
	`setName` varchar(512),
	`frontImageUrl` text,
	`backImageUrl` text,
	`extraImageUrls` json DEFAULT ('[]'),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `card_images_id` PRIMARY KEY(`id`),
	CONSTRAINT `card_images_scpId_unique` UNIQUE(`scpId`)
);
--> statement-breakpoint
CREATE TABLE `cards` (
	`id` int AUTO_INCREMENT NOT NULL,
	`title` varchar(255) NOT NULL,
	`playerName` varchar(255) NOT NULL,
	`year` varchar(10),
	`manufacturer` varchar(100),
	`cardNumber` varchar(50),
	`setName` varchar(255),
	`sport` enum('baseball','basketball','football','hockey','soccer','other') NOT NULL DEFAULT 'baseball',
	`condition` enum('raw','graded') NOT NULL DEFAULT 'raw',
	`gradeCompany` enum('PSA','Beckett','SGC','TGA','CGC','other','none') DEFAULT 'none',
	`gradeScore` varchar(10),
	`certNumber` varchar(100),
	`frontImageUrl` text,
	`backImageUrl` text,
	`extraImageUrls` json,
	`price` decimal(10,2),
	`buyNowPrice` decimal(10,2),
	`status` enum('active','sold','draft','auction','traded','casino','bank') NOT NULL DEFAULT 'draft',
	`storeId` int,
	`storeName` varchar(255),
	`sellerEmail` varchar(320) NOT NULL,
	`featuredOnMain` boolean DEFAULT false,
	`isMainStore` boolean DEFAULT false,
	`description` text,
	`category` enum('rookie','vintage','modern','insert','parallel','autograph','memorabilia','other') DEFAULT 'modern',
	`source` enum('manual','ebay_import','search_import') DEFAULT 'manual',
	`ebayItemId` varchar(100),
	`showSlabView` boolean DEFAULT false,
	`labelColor` enum('dark','ruby','light','silver','nightlife','red','black','none') DEFAULT 'dark',
	`aiGrade` decimal(4,2),
	`aiGradeLabel` varchar(50),
	`aiCentering` varchar(10),
	`aiCorners` varchar(10),
	`aiEdges` varchar(10),
	`aiSurface` varchar(10),
	`aiCertNumber` varchar(100),
	`isVaulted` boolean DEFAULT false,
	`cardShippingFee` decimal(10,2),
	`ebayListingUrl` text,
	`sourcePrice` decimal(10,2),
	`isDropship` boolean DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `cards_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `collections` (
	`id` int AUTO_INCREMENT NOT NULL,
	`ownerEmail` varchar(320) NOT NULL,
	`cardTitle` varchar(255) NOT NULL,
	`playerName` varchar(255) NOT NULL,
	`year` varchar(10),
	`setName` varchar(255),
	`cardNumber` varchar(50),
	`sport` enum('baseball','basketball','football','hockey','soccer','other') NOT NULL DEFAULT 'baseball',
	`frontImageUrl` text,
	`backImageUrl` text,
	`extraImageUrls` json,
	`overallGrade` decimal(4,2),
	`gradeLabel` varchar(50),
	`centeringScore` varchar(10),
	`cornersScore` varchar(10),
	`edgesScore` varchar(10),
	`surfaceScore` varchar(10),
	`estimatedValueLow` decimal(10,2),
	`estimatedValueHigh` decimal(10,2),
	`certNumber` varchar(100),
	`description` text,
	`listingStatus` enum('none','listed','auction','in_trade','in_sale','shipped','traded','sold','pending_gm','gs','gm_complete','vaulted','vault_listed','vault_auction','vault_sold','vault_shipped') NOT NULL DEFAULT 'none',
	`lifecycleNote` varchar(500),
	`labelBg` varchar(50) DEFAULT 'black-silk',
	`labelBorder` varchar(50) DEFAULT 'red',
	`labelMode` enum('with_label','no_label') DEFAULT 'with_label',
	`linkedCardId` int,
	`gameSource` varchar(100),
	`prizeClaimId` int,
	`trackingNumber` varchar(100),
	`shippingFee` decimal(10,2),
	`vaultSource` enum('game_room_win','user_deposited'),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `collections_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `compReferences` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`collectionItemId` int NOT NULL,
	`salePrice` decimal(10,2) NOT NULL,
	`saleDate` varchar(30),
	`condition` varchar(100),
	`platform` varchar(50) NOT NULL DEFAULT 'eBay',
	`sourceUrl` text,
	`title` varchar(255),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `compReferences_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `creditAccounts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userEmail` varchar(320) NOT NULL,
	`userName` varchar(255),
	`credits` int NOT NULL DEFAULT 25,
	`freeCredits` int NOT NULL DEFAULT 25,
	`purchasedCredits` int NOT NULL DEFAULT 0,
	`plan` enum('free','starter','pro','elite') NOT NULL DEFAULT 'free',
	`planResetAt` timestamp,
	`totalPurchased` int DEFAULT 0,
	`totalSpent` int DEFAULT 0,
	`loyaltyTier` enum('bronze','silver','gold','platinum','diamond') NOT NULL DEFAULT 'bronze',
	`weeklyDeposits` int NOT NULL DEFAULT 0,
	`monthlyDeposits` int NOT NULL DEFAULT 0,
	`weeklyDepositResetAt` timestamp,
	`monthlyDepositResetAt` timestamp,
	`totalLoyaltyBonusEarned` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `creditAccounts_id` PRIMARY KEY(`id`),
	CONSTRAINT `creditAccounts_userEmail_unique` UNIQUE(`userEmail`)
);
--> statement-breakpoint
CREATE TABLE `creditTransactions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userEmail` varchar(320) NOT NULL,
	`amount` int NOT NULL,
	`type` enum('purchase','deduction','refund') NOT NULL,
	`reason` varchar(255),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `creditTransactions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `discountCodeUsages` (
	`id` int AUTO_INCREMENT NOT NULL,
	`codeId` int NOT NULL,
	`userEmail` varchar(320) NOT NULL,
	`appliedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `discountCodeUsages_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `discountCodes` (
	`id` int AUTO_INCREMENT NOT NULL,
	`code` varchar(50) NOT NULL,
	`description` varchar(255),
	`type` enum('plan_override','percent_off','credit_bonus') NOT NULL DEFAULT 'plan_override',
	`planTier` enum('free','starter','pro','elite'),
	`monthlyCredits` int,
	`monthlyFeeCents` int DEFAULT 0,
	`percentOff` int,
	`creditBonus` int,
	`isActive` boolean NOT NULL DEFAULT true,
	`usageLimit` int,
	`usageCount` int NOT NULL DEFAULT 0,
	`expiresAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `discountCodes_id` PRIMARY KEY(`id`),
	CONSTRAINT `discountCodes_code_unique` UNIQUE(`code`)
);
--> statement-breakpoint
CREATE TABLE `favorites` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`cardId` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `favorites_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `game_plays` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`gameType` enum('pack_rip','spin_wheel','scratch_card','tournament','poker','roulette','blackjack','free_spin') NOT NULL,
	`creditsSpent` int NOT NULL,
	`creditsWon` int NOT NULL DEFAULT 0,
	`prizeVaultId` int,
	`outcome` enum('credits','card_prize','jackpot','mini_jackpot','bust','registered','win','loss') NOT NULL,
	`outcomeData` json,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `game_plays_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `gradeRequests` (
	`id` int AUTO_INCREMENT NOT NULL,
	`frontImageUrl` text NOT NULL,
	`backImageUrl` text NOT NULL,
	`requesterEmail` varchar(320) NOT NULL,
	`aiGradeEstimate` varchar(10),
	`aiGradeDetails` text,
	`centeringScore` varchar(10),
	`cornersScore` varchar(10),
	`edgesScore` varchar(10),
	`surfaceScore` varchar(10),
	`estimatedValueLow` decimal(10,2),
	`estimatedValueHigh` decimal(10,2),
	`status` enum('pending_expert_review','completed','failed') NOT NULL DEFAULT 'completed',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `gradeRequests_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `messages` (
	`id` int AUTO_INCREMENT NOT NULL,
	`conversationId` varchar(100) NOT NULL,
	`senderEmail` varchar(320) NOT NULL,
	`senderName` varchar(255),
	`receiverEmail` varchar(320) NOT NULL,
	`receiverName` varchar(255),
	`messageText` text NOT NULL,
	`isRead` boolean DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `messages_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `notificationTemplates` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(100) NOT NULL,
	`subject` varchar(255) NOT NULL,
	`body` text NOT NULL,
	`trigger` enum('order_placed','order_shipped','order_delivered','trade_received','trade_accepted','trade_rejected','auction_won','auction_outbid','auction_ended','grade_complete','credit_added','welcome') NOT NULL,
	`isActive` boolean DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `notificationTemplates_id` PRIMARY KEY(`id`),
	CONSTRAINT `notificationTemplates_name_unique` UNIQUE(`name`)
);
--> statement-breakpoint
CREATE TABLE `orderMessages` (
	`id` int AUTO_INCREMENT NOT NULL,
	`orderId` int NOT NULL,
	`senderEmail` varchar(320) NOT NULL,
	`senderName` varchar(255),
	`senderRole` enum('buyer','seller','system','admin') NOT NULL,
	`messageText` text NOT NULL,
	`isRead` boolean DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `orderMessages_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `orders` (
	`id` int AUTO_INCREMENT NOT NULL,
	`cardId` int,
	`cardIds` json,
	`cardTitle` varchar(255),
	`cardImageUrl` text,
	`buyerEmail` varchar(320) NOT NULL,
	`buyerName` varchar(255),
	`sellerEmail` varchar(320),
	`sellerEmails` json,
	`sellerStoreName` varchar(255),
	`price` decimal(10,2),
	`totalAmount` decimal(10,2),
	`platformFee` decimal(10,2),
	`sellerPayout` decimal(10,2),
	`status` enum('pending','paid','label_created','shipped','delivered','confirmed','completed','cancelled','refunded','disputed') NOT NULL DEFAULT 'pending',
	`shippingMethod` enum('usps_first_class','usps_priority','ups_ground','ups_2day','ups_next_day') DEFAULT 'usps_first_class',
	`trackingNumber` varchar(100),
	`carrier` varchar(100),
	`shippingAddress` text,
	`fromAuction` boolean DEFAULT false,
	`labelPurchased` boolean DEFAULT false,
	`deliveredAt` timestamp,
	`confirmedAt` timestamp,
	`autoReleaseAt` timestamp,
	`fundsReleasedAt` timestamp,
	`shipByDeadline` timestamp,
	`stripePaymentIntentId` varchar(255),
	`ticketNumber` varchar(30),
	`fulfillmentPreference` enum('pending','vault','ship') DEFAULT 'pending',
	`vaultRequestedAt` timestamp,
	`shipLabelEmailSentAt` timestamp,
	`isDropshipOrder` boolean DEFAULT false,
	`ebayFulfillmentLink` text,
	`dropshipFulfilledAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `orders_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `prize_vault` (
	`id` int AUTO_INCREMENT NOT NULL,
	`cardTitle` varchar(255) NOT NULL,
	`playerName` varchar(255) NOT NULL,
	`year` varchar(10),
	`setName` varchar(255),
	`sport` enum('baseball','basketball','football','hockey','soccer','other') NOT NULL DEFAULT 'basketball',
	`frontImageUrl` text,
	`backImageUrl` text,
	`gradeScore` varchar(10),
	`estimatedValue` decimal(10,2) NOT NULL,
	`creditCost` int NOT NULL,
	`tier` enum('mega_jackpot','mini_jackpot','featured','standard') NOT NULL DEFAULT 'standard',
	`isActive` boolean NOT NULL DEFAULT true,
	`isClaimed` boolean NOT NULL DEFAULT false,
	`claimedByUserId` int,
	`claimedAt` timestamp,
	`addedByAdmin` boolean NOT NULL DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `prize_vault_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `referralVisits` (
	`id` int AUTO_INCREMENT NOT NULL,
	`refCode` varchar(20) NOT NULL,
	`affiliateEmail` varchar(320) NOT NULL,
	`visitorIp` varchar(64),
	`visitorCookie` varchar(64),
	`convertedEmail` varchar(320),
	`convertedAt` timestamp,
	`creditsTier` varchar(20),
	`layer2BonusAwarded` boolean DEFAULT false,
	`expiresAt` timestamp NOT NULL,
	`visitedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `referralVisits_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `roulette_saved_bets` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`name` varchar(100) NOT NULL,
	`bets` json NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `roulette_saved_bets_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `showcases` (
	`id` int AUTO_INCREMENT NOT NULL,
	`ownerEmail` varchar(320) NOT NULL,
	`title` varchar(255) NOT NULL,
	`description` text,
	`slug` varchar(255),
	`theme` varchar(50) DEFAULT 'dark',
	`cardIds` json,
	`isPublic` boolean DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `showcases_id` PRIMARY KEY(`id`),
	CONSTRAINT `showcases_slug_unique` UNIQUE(`slug`)
);
--> statement-breakpoint
CREATE TABLE `stores` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(255) NOT NULL,
	`ownerEmail` varchar(320) NOT NULL,
	`ownerName` varchar(255),
	`description` text,
	`logoUrl` text,
	`bannerUrl` text,
	`plan` enum('free','starter','pro','elite','franchise') NOT NULL DEFAULT 'free',
	`planStatus` enum('active','expired','cancelled') NOT NULL DEFAULT 'active',
	`labelColor` enum('dark','ruby','light','silver','nightlife','red','black','none') NOT NULL DEFAULT 'dark',
	`socialFacebook` varchar(255),
	`socialInstagram` varchar(255),
	`socialLinkedin` varchar(255),
	`socialEbay` varchar(255),
	`totalSales` int DEFAULT 0,
	`rating` decimal(3,2) DEFAULT '5.00',
	`isMainStore` boolean DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `stores_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `tournament_players` (
	`id` int AUTO_INCREMENT NOT NULL,
	`tournamentId` int NOT NULL,
	`userId` int,
	`aiName` varchar(64),
	`aiAvatar` varchar(8),
	`chips` int NOT NULL DEFAULT 1000,
	`status` enum('active','eliminated','winner') NOT NULL DEFAULT 'active',
	`finishPosition` int,
	`creditsWon` int DEFAULT 0,
	`joinedAt` timestamp NOT NULL DEFAULT (now()),
	`eliminatedAt` timestamp,
	CONSTRAINT `tournament_players_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `tournaments` (
	`id` int AUTO_INCREMENT NOT NULL,
	`type` enum('regular','winner_take_all') NOT NULL DEFAULT 'regular',
	`game` enum('poker','blackjack') NOT NULL DEFAULT 'poker',
	`buyIn` int NOT NULL,
	`maxPlayers` int NOT NULL DEFAULT 9,
	`currentPlayers` int NOT NULL DEFAULT 0,
	`status` enum('registering','active','final_table','completed','cancelled') NOT NULL DEFAULT 'registering',
	`prizePool` int NOT NULL DEFAULT 0,
	`prizeTier1` int DEFAULT 0,
	`prizeTier2` int DEFAULT 0,
	`prizeTier3` int DEFAULT 0,
	`prizeCardId` int,
	`startedAt` timestamp,
	`finalTableAt` timestamp,
	`completedAt` timestamp,
	`scheduledAt` timestamp NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `tournaments_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `tradeRevisions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`tradeId` int NOT NULL,
	`revisedByEmail` varchar(320) NOT NULL,
	`revisedByName` varchar(255),
	`offeredCardIds` json,
	`offeredCardTitles` json,
	`offeredCardImages` json,
	`offeredCardValues` json,
	`requestedCardIds` json,
	`requestedCardTitles` json,
	`requestedCardImages` json,
	`requestedCardValues` json,
	`message` text,
	`revisionNumber` int NOT NULL DEFAULT 1,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `tradeRevisions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `trades` (
	`id` int AUTO_INCREMENT NOT NULL,
	`initiatorEmail` varchar(320) NOT NULL,
	`initiatorName` varchar(255),
	`receiverEmail` varchar(320) NOT NULL,
	`receiverName` varchar(255),
	`offeredCardIds` json,
	`offeredCardTitles` json,
	`offeredCardImages` json,
	`requestedCardIds` json,
	`requestedCardTitles` json,
	`requestedCardImages` json,
	`status` enum('pending','accepted','rejected','cancelled','countered','agreed','fee_pending','paid_ready_to_ship','shipped','completed') NOT NULL DEFAULT 'pending',
	`message` text,
	`counterMessage` text,
	`conversationId` int,
	`initiatorAgreed` boolean DEFAULT false,
	`receiverAgreed` boolean DEFAULT false,
	`initiatorTracking` varchar(255),
	`initiatorReturnTracking` varchar(255),
	`receiverTracking` varchar(255),
	`receiverReturnTracking` varchar(255),
	`outgoingTracking` varchar(255),
	`shippingStatus` enum('pending','awaiting_packages','both_received','shipped') DEFAULT 'pending',
	`ticketNumber` varchar(30),
	`initiatorFeePaid` boolean DEFAULT false,
	`receiverFeePaid` boolean DEFAULT false,
	`initiatorFeeSessionId` varchar(255),
	`receiverFeeSessionId` varchar(255),
	`initiatorFeePaidAt` timestamp,
	`receiverFeePaidAt` timestamp,
	`feeReminderSentAt` timestamp,
	`feeReminderCount` int DEFAULT 0,
	`offeredCardValues` json,
	`requestedCardValues` json,
	`agreementSentAt` timestamp,
	`initiatorSignedAt` timestamp,
	`receiverSignedAt` timestamp,
	`initiatorAddress` text,
	`initiatorCity` varchar(100),
	`initiatorState` varchar(50),
	`initiatorZip` varchar(20),
	`initiatorPhone` varchar(30),
	`receiverAddress` text,
	`receiverCity` varchar(100),
	`receiverState` varchar(50),
	`receiverZip` varchar(20),
	`receiverPhone` varchar(30),
	`revisionCount` int DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `trades_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `user_collection` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`scpId` varchar(32) NOT NULL,
	`productName` varchar(512) NOT NULL,
	`consoleName` varchar(512) NOT NULL,
	`priceInPennies` int NOT NULL DEFAULT 0,
	`costBasisInPennies` int NOT NULL DEFAULT 0,
	`condition` varchar(128),
	`quantity` int NOT NULL DEFAULT 1,
	`imageUrl` text,
	`imageBackUrl` text,
	`gradingCompany` varchar(64),
	`gradingCertId` varchar(128),
	`sport` varchar(64),
	`playerName` varchar(255),
	`dateEntered` varchar(32),
	`datePurchased` varchar(32),
	`notes` text,
	`folder` varchar(255),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `user_collection_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `user_interests` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`playerName` varchar(255) NOT NULL,
	`sport` varchar(50),
	`searchCount` int NOT NULL DEFAULT 1,
	`viewCount` int NOT NULL DEFAULT 0,
	`avgPrice` decimal(10,2),
	`lastInteractedAt` timestamp NOT NULL DEFAULT (now()),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `user_interests_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `wishlists` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userEmail` varchar(320) NOT NULL,
	`playerName` varchar(255) NOT NULL,
	`year` varchar(10),
	`setName` varchar(255),
	`cardNumber` varchar(50),
	`sport` enum('baseball','basketball','football','hockey','soccer','other'),
	`maxPrice` decimal(10,2),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `wishlists_id` PRIMARY KEY(`id`)
);
