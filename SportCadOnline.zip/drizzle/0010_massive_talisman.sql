CREATE TABLE `tradeRevisions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`tradeId` int NOT NULL,
	`revisedByEmail` varchar(320) NOT NULL,
	`revisedByName` varchar(255),
	`offeredCardIds` json,
	`offeredCardTitles` json,
	`offeredCardImages` json,
	`offeredCardValues` json,
	`requestedCardIds` json,
	`requestedCardTitles` json,
	`requestedCardImages` json,
	`requestedCardValues` json,
	`message` text,
	`revisionNumber` int NOT NULL DEFAULT 1,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `tradeRevisions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `trades` ADD `offeredCardValues` json;--> statement-breakpoint
ALTER TABLE `trades` ADD `requestedCardValues` json;--> statement-breakpoint
ALTER TABLE `trades` ADD `agreementSentAt` timestamp;--> statement-breakpoint
ALTER TABLE `trades` ADD `initiatorSignedAt` timestamp;--> statement-breakpoint
ALTER TABLE `trades` ADD `receiverSignedAt` timestamp;--> statement-breakpoint
ALTER TABLE `trades` ADD `revisionCount` int DEFAULT 0;