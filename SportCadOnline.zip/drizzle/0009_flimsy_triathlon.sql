CREATE TABLE `discountCodeUsages` (
	`id` int AUTO_INCREMENT NOT NULL,
	`codeId` int NOT NULL,
	`userEmail` varchar(320) NOT NULL,
	`appliedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `discountCodeUsages_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `discountCodes` (
	`id` int AUTO_INCREMENT NOT NULL,
	`code` varchar(50) NOT NULL,
	`description` varchar(255),
	`type` enum('plan_override','percent_off','credit_bonus') NOT NULL DEFAULT 'plan_override',
	`planTier` enum('free','starter','pro','elite'),
	`monthlyCredits` int,
	`monthlyFeeCents` int DEFAULT 0,
	`percentOff` int,
	`creditBonus` int,
	`isActive` boolean NOT NULL DEFAULT true,
	`usageLimit` int,
	`usageCount` int NOT NULL DEFAULT 0,
	`expiresAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `discountCodes_id` PRIMARY KEY(`id`),
	CONSTRAINT `discountCodes_code_unique` UNIQUE(`code`)
);
