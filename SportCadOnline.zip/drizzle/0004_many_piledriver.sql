ALTER TABLE `trades` MODIFY COLUMN `status` enum('pending','accepted','rejected','cancelled','countered','agreed','shipped','completed') NOT NULL DEFAULT 'pending';--> statement-breakpoint
ALTER TABLE `trades` ADD `initiatorAgreed` boolean DEFAULT false;--> statement-breakpoint
ALTER TABLE `trades` ADD `receiverAgreed` boolean DEFAULT false;--> statement-breakpoint
ALTER TABLE `trades` ADD `initiatorTracking` varchar(255);--> statement-breakpoint
ALTER TABLE `trades` ADD `receiverTracking` varchar(255);--> statement-breakpoint
ALTER TABLE `trades` ADD `outgoingTracking` varchar(255);--> statement-breakpoint
ALTER TABLE `trades` ADD `shippingStatus` enum('pending','awaiting_packages','both_received','shipped') DEFAULT 'pending';