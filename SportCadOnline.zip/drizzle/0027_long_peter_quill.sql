CREATE TABLE `card_images` (
	`id` int AUTO_INCREMENT NOT NULL,
	`scpId` varchar(32) NOT NULL,
	`productName` varchar(512) NOT NULL,
	`setName` varchar(512),
	`frontImageUrl` text,
	`backImageUrl` text,
	`extraImageUrls` json DEFAULT ('[]'),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `card_images_id` PRIMARY KEY(`id`),
	CONSTRAINT `card_images_scpId_unique` UNIQUE(`scpId`)
);
