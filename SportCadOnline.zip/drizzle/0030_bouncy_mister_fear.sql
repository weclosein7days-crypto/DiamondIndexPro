CREATE TABLE `tournament_players` (
	`id` int AUTO_INCREMENT NOT NULL,
	`tournamentId` int NOT NULL,
	`userId` int,
	`aiName` varchar(64),
	`aiAvatar` varchar(8),
	`chips` int NOT NULL DEFAULT 1000,
	`status` enum('active','eliminated','winner') NOT NULL DEFAULT 'active',
	`finishPosition` int,
	`creditsWon` int DEFAULT 0,
	`joinedAt` timestamp NOT NULL DEFAULT (now()),
	`eliminatedAt` timestamp,
	CONSTRAINT `tournament_players_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `tournaments` (
	`id` int AUTO_INCREMENT NOT NULL,
	`type` enum('regular','winner_take_all') NOT NULL DEFAULT 'regular',
	`game` enum('poker','blackjack') NOT NULL DEFAULT 'poker',
	`buyIn` int NOT NULL,
	`maxPlayers` int NOT NULL DEFAULT 9,
	`currentPlayers` int NOT NULL DEFAULT 0,
	`status` enum('registering','active','final_table','completed','cancelled') NOT NULL DEFAULT 'registering',
	`prizePool` int NOT NULL DEFAULT 0,
	`prizeTier1` int DEFAULT 0,
	`prizeTier2` int DEFAULT 0,
	`prizeTier3` int DEFAULT 0,
	`prizeCardId` int,
	`startedAt` timestamp,
	`finalTableAt` timestamp,
	`completedAt` timestamp,
	`scheduledAt` timestamp NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `tournaments_id` PRIMARY KEY(`id`)
);
