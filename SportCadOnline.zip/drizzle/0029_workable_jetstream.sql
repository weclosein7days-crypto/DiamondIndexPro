ALTER TABLE `creditAccounts` ADD `freeCredits` int DEFAULT 25 NOT NULL;--> statement-breakpoint
ALTER TABLE `creditAccounts` ADD `purchasedCredits` int DEFAULT 0 NOT NULL;