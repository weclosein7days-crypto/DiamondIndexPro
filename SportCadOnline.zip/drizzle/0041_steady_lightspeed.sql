ALTER TABLE `orders` ADD `ebayOfferStatus` enum('none','not_eligible','pending','accepted','declined','countered','expired','fallback_full_price') DEFAULT 'none';--> statement-breakpoint
ALTER TABLE `orders` ADD `ebayOfferAmount` decimal(10,2);--> statement-breakpoint
ALTER TABLE `orders` ADD `ebayOfferSentAt` timestamp;--> statement-breakpoint
ALTER TABLE `orders` ADD `ebayOfferRespondedAt` timestamp;--> statement-breakpoint
ALTER TABLE `orders` ADD `ebayOfferSavings` decimal(10,2);--> statement-breakpoint
ALTER TABLE `orders` ADD `ebayOfferId` varchar(100);