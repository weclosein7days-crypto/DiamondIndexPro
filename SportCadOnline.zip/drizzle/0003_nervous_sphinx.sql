CREATE TABLE `referralVisits` (
	`id` int AUTO_INCREMENT NOT NULL,
	`refCode` varchar(20) NOT NULL,
	`affiliateEmail` varchar(320) NOT NULL,
	`visitorIp` varchar(64),
	`visitorCookie` varchar(64),
	`convertedEmail` varchar(320),
	`convertedAt` timestamp,
	`creditsTier` varchar(20),
	`layer2BonusAwarded` boolean DEFAULT false,
	`expiresAt` timestamp NOT NULL,
	`visitedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `referralVisits_id` PRIMARY KEY(`id`)
);
