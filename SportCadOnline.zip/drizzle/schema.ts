import { int, mysqlEnum, mysqlTable, text, mediumtext, timestamp, varchar, decimal, boolean, json } from "drizzle-orm/mysql-core";

/**
 * CardVault Database Schema
 * Sports card marketplace with grading, auctions, trades, and payment escrow
 */

// ============================================================================
// CORE USER & AUTH
// ============================================================================

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// ============================================================================
// STORES & SELLER PROFILES
// ============================================================================

export const stores = mysqlTable("stores", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  ownerEmail: varchar("ownerEmail", { length: 320 }).notNull(),
  ownerName: varchar("ownerName", { length: 255 }),
  description: text("description"),
  logoUrl: text("logoUrl"),
  bannerUrl: text("bannerUrl"),
  plan: mysqlEnum("plan", ["free", "starter", "pro", "elite", "franchise"]).default("free").notNull(),
  planStatus: mysqlEnum("planStatus", ["active", "expired", "cancelled"]).default("active").notNull(),
  labelColor: mysqlEnum("labelColor", ["dark", "ruby", "light", "silver", "nightlife", "red", "black", "none"]).default("dark").notNull(),
  socialFacebook: varchar("socialFacebook", { length: 255 }),
  socialInstagram: varchar("socialInstagram", { length: 255 }),
  socialLinkedin: varchar("socialLinkedin", { length: 255 }),
  socialEbay: varchar("socialEbay", { length: 255 }),
  totalSales: int("totalSales").default(0),
  rating: decimal("rating", { precision: 3, scale: 2 }).default("5.00"),
  isMainStore: boolean("isMainStore").default(false),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Store = typeof stores.$inferSelect;
export type InsertStore = typeof stores.$inferInsert;

// ============================================================================
// CARDS (MARKETPLACE LISTINGS)
// ============================================================================

export const cards = mysqlTable("cards", {
  id: int("id").autoincrement().primaryKey(),
  title: varchar("title", { length: 255 }).notNull(),
  playerName: varchar("playerName", { length: 255 }).notNull(),
  year: varchar("year", { length: 10 }),
  manufacturer: varchar("manufacturer", { length: 100 }),
  cardNumber: varchar("cardNumber", { length: 50 }),
  setName: varchar("setName", { length: 255 }),
  sport: mysqlEnum("sport", ["baseball", "basketball", "football", "hockey", "soccer", "golf", "tennis", "mma", "boxing", "other"]).default("baseball").notNull(),
  isSearchOnly: boolean("isSearchOnly").default(false), // true = search-only (MMA/boxing), not shown in main marketplace
  condition: mysqlEnum("condition", ["raw", "graded"]).default("raw").notNull(),
  gradeCompany: mysqlEnum("gradeCompany", ["PSA", "Beckett", "SGC", "TGA", "CGC", "other", "none"]).default("none"),
  gradeScore: varchar("gradeScore", { length: 10 }),
  certNumber: varchar("certNumber", { length: 100 }),
  frontImageUrl: text("frontImageUrl"),
  backImageUrl: text("backImageUrl"),
  extraImageUrls: json("extraImageUrls").$type<string[]>(),
  price: decimal("price", { precision: 10, scale: 2 }),
  buyNowPrice: decimal("buyNowPrice", { precision: 10, scale: 2 }),
  status: mysqlEnum("status", ["active", "sold", "draft", "auction", "traded", "casino", "bank"]).default("draft").notNull(),
  storeId: int("storeId"),
  storeName: varchar("storeName", { length: 255 }),
  sellerEmail: varchar("sellerEmail", { length: 320 }).notNull(),
  featuredOnMain: boolean("featuredOnMain").default(false),
  isMainStore: boolean("isMainStore").default(false),
  description: text("description"),
  category: mysqlEnum("category", ["rookie", "vintage", "modern", "insert", "parallel", "autograph", "memorabilia", "other"]).default("modern"),
  source: mysqlEnum("source", ["manual", "ebay_import", "search_import"]).default("manual"),
  ebayItemId: varchar("ebayItemId", { length: 100 }),
  showSlabView: boolean("showSlabView").default(false),
  labelColor: mysqlEnum("labelColor", ["dark", "ruby", "light", "silver", "nightlife", "red", "black", "none"]).default("dark"),
  aiGrade: decimal("aiGrade", { precision: 4, scale: 2 }),
  aiGradeLabel: varchar("aiGradeLabel", { length: 50 }),
  aiCentering: varchar("aiCentering", { length: 10 }),
  aiCorners: varchar("aiCorners", { length: 10 }),
  aiEdges: varchar("aiEdges", { length: 10 }),
  aiSurface: varchar("aiSurface", { length: 10 }),
  aiCertNumber: varchar("aiCertNumber", { length: 100 }),
  isVaulted: boolean("isVaulted").default(false),  // card is physically held at SCO vault
  cardShippingFee: decimal("cardShippingFee", { precision: 10, scale: 2 }),  // shipping fee added to buyer's cost
  // eBay dropship fields
  ebayListingUrl: text("ebayListingUrl"),          // full eBay listing URL for fulfillment
  sourcePrice: decimal("sourcePrice", { precision: 10, scale: 2 }),  // original eBay price before 20% markup
  isDropship: boolean("isDropship").default(false), // true = fulfilled via eBay dropship
  freeShipping: boolean("freeShipping").default(false), // true = eBay listing has free shipping
  isUpAndComing: boolean("isUpAndComing").default(false), // true = admin-flagged for Up & Coming section (house cards only)
  isShowcaseCard: boolean("isShowcaseCard").default(false), // true = admin-flagged for Showcase section ($5k-$10k house cards)
  marketPrice: decimal("marketPrice", { precision: 10, scale: 2 }),  // estimated market avg (eBay/SCP)
  psaPrice: decimal("psaPrice", { precision: 10, scale: 2 }),        // PSA population avg price
  qty: int("qty").default(1).notNull(), // quantity available (merged duplicates)
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Card = typeof cards.$inferSelect;
export type InsertCard = typeof cards.$inferInsert;

// ============================================================================
// COLLECTION (PERSONAL GRADED CARDS)
// ============================================================================

export const collections = mysqlTable("collections", {
  id: int("id").autoincrement().primaryKey(),
  ownerEmail: varchar("ownerEmail", { length: 320 }).notNull(),
  cardTitle: varchar("cardTitle", { length: 255 }).notNull(),
  playerName: varchar("playerName", { length: 255 }).notNull(),
  year: varchar("year", { length: 10 }),
  setName: varchar("setName", { length: 255 }),
  cardNumber: varchar("cardNumber", { length: 50 }),
  sport: mysqlEnum("sport", ["baseball", "basketball", "football", "hockey", "soccer", "golf", "tennis", "mma", "boxing", "other"]).default("baseball").notNull(),
  frontImageUrl: text("frontImageUrl"),
  backImageUrl: text("backImageUrl"),
  extraImageUrls: json("extraImageUrls").$type<string[]>(),
  overallGrade: decimal("overallGrade", { precision: 4, scale: 2 }),
  gradeLabel: varchar("gradeLabel", { length: 50 }),
  centeringScore: varchar("centeringScore", { length: 10 }),
  cornersScore: varchar("cornersScore", { length: 10 }),
  edgesScore: varchar("edgesScore", { length: 10 }),
  surfaceScore: varchar("surfaceScore", { length: 10 }),
  estimatedValueLow: decimal("estimatedValueLow", { precision: 10, scale: 2 }),
  estimatedValueHigh: decimal("estimatedValueHigh", { precision: 10, scale: 2 }),
  certNumber: varchar("certNumber", { length: 100 }),
  description: text("description"),
  listingStatus: mysqlEnum("listingStatus", ["none", "listed", "auction", "in_trade", "in_sale", "shipped", "traded", "sold", "pending_gm", "gs", "gm_complete", "vaulted", "vault_listed", "vault_auction", "vault_sold", "vault_shipped"]).default("none").notNull(),
  lifecycleNote: varchar("lifecycleNote", { length: 500 }),
  labelBg: varchar("labelBg", { length: 50 }).default("black-silk"),
  labelBorder: varchar("labelBorder", { length: 50 }).default("red"),
  labelMode: mysqlEnum("labelMode", ["with_label", "no_label"]).default("with_label"),
  linkedCardId: int("linkedCardId"),
  gameSource: varchar("gameSource", { length: 100 }),   // e.g. "pack_rip", "spin_wheel", "tournament"
  prizeClaimId: int("prizeClaimId"),                    // FK to prize_claims
  trackingNumber: varchar("trackingNumber", { length: 100 }), // for $20+ game prizes
  shippingFee: decimal("shippingFee", { precision: 10, scale: 2 }),  // vault shipping fee added to sale
  vaultSource: mysqlEnum("vaultSource", ["game_room_win", "user_deposited"]), // how card entered vault
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Collection = typeof collections.$inferSelect;
export type InsertCollection = typeof collections.$inferInsert;

// ============================================================================
// AUCTIONS
// ============================================================================

export const auctions = mysqlTable("auctions", {
  id: int("id").autoincrement().primaryKey(),
  cardId: int("cardId").notNull(),
  cardTitle: varchar("cardTitle", { length: 255 }).notNull(),
  cardImageUrl: text("cardImageUrl"),
  sellerEmail: varchar("sellerEmail", { length: 320 }).notNull(),
  storeName: varchar("storeName", { length: 255 }),
  startingPrice: decimal("startingPrice", { precision: 10, scale: 2 }).notNull(),
  currentBid: decimal("currentBid", { precision: 10, scale: 2 }).default("0.00"),
  highestBidderEmail: varchar("highestBidderEmail", { length: 320 }),
  highestBidderName: varchar("highestBidderName", { length: 255 }),
  bidCount: int("bidCount").default(0),
  endTime: timestamp("endTime").notNull(),
  status: mysqlEnum("status", ["active", "ended", "cancelled", "sold"]).default("active").notNull(),
  playerName: varchar("playerName", { length: 255 }),
  gradeInfo: varchar("gradeInfo", { length: 100 }),
  durationDays: int("durationDays").notNull(), // 3, 5, or 7
  listingCreditsPaid: int("listingCreditsPaid").notNull(),
  buyNowPrice: decimal("buyNowPrice", { precision: 10, scale: 2 }),  // 125% of market value
  minBidPrice: decimal("minBidPrice", { precision: 10, scale: 2 }),  // 75% of market value (= startingPrice)
  autoRenew: boolean("autoRenew").default(true).notNull(),           // re-list if min bid not met
  renewCount: int("renewCount").default(0).notNull(),                // how many times renewed
  isVaulted: boolean("isVaulted").default(false),                    // card physically held at SCO vault
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});
export type Auction = typeof auctions.$inferSelect;
export type InsertAuction = typeof auctions.$inferInsert;

// ============================================================================
// BIDS
// ============================================================================

export const bids = mysqlTable("bids", {
  id: int("id").autoincrement().primaryKey(),
  auctionId: int("auctionId").notNull(),
  bidderEmail: varchar("bidderEmail", { length: 320 }).notNull(),
  bidderName: varchar("bidderName", { length: 255 }),
  bidAmount: decimal("bidAmount", { precision: 10, scale: 2 }).notNull(),
  bidTime: timestamp("bidTime").defaultNow().notNull(),
});

export type Bid = typeof bids.$inferSelect;
export type InsertBid = typeof bids.$inferInsert;

// ============================================================================
// ORDERS
// ============================================================================

export const orders = mysqlTable("orders", {
  id: int("id").autoincrement().primaryKey(),
  cardId: int("cardId"),
  cardIds: json("cardIds").$type<number[]>(),
  cardTitle: varchar("cardTitle", { length: 255 }),
  cardImageUrl: text("cardImageUrl"),
  buyerEmail: varchar("buyerEmail", { length: 320 }).notNull(),
  buyerName: varchar("buyerName", { length: 255 }),
  sellerEmail: varchar("sellerEmail", { length: 320 }),
  sellerEmails: json("sellerEmails").$type<string[]>(),
  sellerStoreName: varchar("sellerStoreName", { length: 255 }),
  price: decimal("price", { precision: 10, scale: 2 }),
  totalAmount: decimal("totalAmount", { precision: 10, scale: 2 }),
  platformFee: decimal("platformFee", { precision: 10, scale: 2 }),
  sellerPayout: decimal("sellerPayout", { precision: 10, scale: 2 }),
  status: mysqlEnum("status", ["pending", "paid", "label_created", "shipped", "delivered", "confirmed", "completed", "cancelled", "refunded", "disputed"]).default("pending").notNull(),
  shippingMethod: mysqlEnum("shippingMethod", ["usps_first_class", "usps_priority", "ups_ground", "ups_2day", "ups_next_day"]).default("usps_first_class"),
  trackingNumber: varchar("trackingNumber", { length: 100 }),
  carrier: varchar("carrier", { length: 100 }),
  shippingAddress: text("shippingAddress"),
  fromAuction: boolean("fromAuction").default(false),
  labelPurchased: boolean("labelPurchased").default(false),
  labelUrl: text("labelUrl"),
  deliveredAt: timestamp("deliveredAt"),
  confirmedAt: timestamp("confirmedAt"),
  autoReleaseAt: timestamp("autoReleaseAt"),
  fundsReleasedAt: timestamp("fundsReleasedAt"),
  fundsReleased: boolean("fundsReleased").default(false),
  fundsReleasedBy: varchar("fundsReleasedBy", { length: 320 }),
  carrierStatus: varchar("carrierStatus", { length: 100 }),
  shipByDeadline: timestamp("shipByDeadline"),
  stripePaymentIntentId: varchar("stripePaymentIntentId", { length: 255 }),
  ticketNumber: varchar("ticketNumber", { length: 30 }),
  fulfillmentPreference: mysqlEnum("fulfillmentPreference", ["pending", "vault", "ship"]).default("pending"),
  vaultRequestedAt: timestamp("vaultRequestedAt"),
  shipLabelEmailSentAt: timestamp("shipLabelEmailSentAt"),
  // eBay dropship fulfillment
  isDropshipOrder: boolean("isDropshipOrder").default(false),
  ebayFulfillmentLink: text("ebayFulfillmentLink"),  // pre-built eBay cart/buy link for owner
  dropshipFulfilledAt: timestamp("dropshipFulfilledAt"),
  // eBay Best Offer tracking
  ebayOfferStatus: mysqlEnum("ebayOfferStatus", ["none", "not_eligible", "pending", "accepted", "declined", "countered", "expired", "fallback_full_price"]).default("none"),
  ebayOfferAmount: decimal("ebayOfferAmount", { precision: 10, scale: 2 }),
  ebayOfferSentAt: timestamp("ebayOfferSentAt"),
  ebayOfferRespondedAt: timestamp("ebayOfferRespondedAt"),
  ebayOfferSavings: decimal("ebayOfferSavings", { precision: 10, scale: 2 }),
  ebayOfferId: varchar("ebayOfferId", { length: 100 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Order = typeof orders.$inferSelect;
export type InsertOrder = typeof orders.$inferInsert;

// ============================================================================
// ORDER MESSAGES (TICKET THREAD)
// ============================================================================

export const orderMessages = mysqlTable("orderMessages", {
  id: int("id").autoincrement().primaryKey(),
  orderId: int("orderId").notNull(),
  senderEmail: varchar("senderEmail", { length: 320 }).notNull(),
  senderName: varchar("senderName", { length: 255 }),
  senderRole: mysqlEnum("senderRole", ["buyer", "seller", "system", "admin"]).notNull(),
  messageText: text("messageText").notNull(),
  isRead: boolean("isRead").default(false),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type OrderMessage = typeof orderMessages.$inferSelect;
export type InsertOrderMessage = typeof orderMessages.$inferInsert;

// ============================================================================
// TRADES
// ============================================================================

export const trades = mysqlTable("trades", {
  id: int("id").autoincrement().primaryKey(),
  initiatorEmail: varchar("initiatorEmail", { length: 320 }).notNull(),
  initiatorName: varchar("initiatorName", { length: 255 }),
  receiverEmail: varchar("receiverEmail", { length: 320 }).notNull(),
  receiverName: varchar("receiverName", { length: 255 }),
  offeredCardIds: json("offeredCardIds").$type<number[]>(),
  offeredCardTitles: json("offeredCardTitles").$type<string[]>(),
  offeredCardImages: json("offeredCardImages").$type<string[]>(),
  requestedCardIds: json("requestedCardIds").$type<number[]>(),
  requestedCardTitles: json("requestedCardTitles").$type<string[]>(),
  requestedCardImages: json("requestedCardImages").$type<string[]>(),
  status: mysqlEnum("status", ["pending", "accepted", "rejected", "cancelled", "countered", "agreed", "fee_pending", "paid_ready_to_ship", "shipped", "completed"]).default("pending").notNull(),
  message: text("message"),
  counterMessage: text("counterMessage"),
  conversationId: int("conversationId"),
  initiatorAgreed: boolean("initiatorAgreed").default(false),
  receiverAgreed: boolean("receiverAgreed").default(false),
   initiatorTracking: varchar("initiatorTracking", { length: 255 }),
  initiatorReturnTracking: varchar("initiatorReturnTracking", { length: 255 }),
  receiverTracking: varchar("receiverTracking", { length: 255 }),
  receiverReturnTracking: varchar("receiverReturnTracking", { length: 255 }),
  outgoingTracking: varchar("outgoingTracking", { length: 255 }),
  shippingStatus: mysqlEnum("shippingStatus", ["pending", "awaiting_packages", "both_received", "shipped"]).default("pending"),
  ticketNumber: varchar("ticketNumber", { length: 30 }),
  initiatorFeePaid: boolean("initiatorFeePaid").default(false),
  receiverFeePaid: boolean("receiverFeePaid").default(false),
  initiatorFeeSessionId: varchar("initiatorFeeSessionId", { length: 255 }),
  receiverFeeSessionId: varchar("receiverFeeSessionId", { length: 255 }),
  initiatorFeePaidAt: timestamp("initiatorFeePaidAt"),
  receiverFeePaidAt: timestamp("receiverFeePaidAt"),
  feeReminderSentAt: timestamp("feeReminderSentAt"),
  feeReminderCount: int("feeReminderCount").default(0),
  offeredCardValues: json("offeredCardValues").$type<number[]>(),
  requestedCardValues: json("requestedCardValues").$type<number[]>(),
  agreementSentAt: timestamp("agreementSentAt"),
  initiatorSignedAt: timestamp("initiatorSignedAt"),
  receiverSignedAt: timestamp("receiverSignedAt"),
  initiatorAddress: text("initiatorAddress"),
  initiatorCity: varchar("initiatorCity", { length: 100 }),
  initiatorState: varchar("initiatorState", { length: 50 }),
  initiatorZip: varchar("initiatorZip", { length: 20 }),
  initiatorPhone: varchar("initiatorPhone", { length: 30 }),
  receiverAddress: text("receiverAddress"),
  receiverCity: varchar("receiverCity", { length: 100 }),
  receiverState: varchar("receiverState", { length: 50 }),
  receiverZip: varchar("receiverZip", { length: 20 }),
  receiverPhone: varchar("receiverPhone", { length: 30 }),
  revisionCount: int("revisionCount").default(0),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});
export type Trade = typeof trades.$inferSelect;
export type InsertTrade = typeof trades.$inferInsert;

export const tradeRevisions = mysqlTable("tradeRevisions", {
  id: int("id").autoincrement().primaryKey(),
  tradeId: int("tradeId").notNull(),
  revisedByEmail: varchar("revisedByEmail", { length: 320 }).notNull(),
  revisedByName: varchar("revisedByName", { length: 255 }),
  offeredCardIds: json("offeredCardIds").$type<number[]>(),
  offeredCardTitles: json("offeredCardTitles").$type<string[]>(),
  offeredCardImages: json("offeredCardImages").$type<string[]>(),
  offeredCardValues: json("offeredCardValues").$type<number[]>(),
  requestedCardIds: json("requestedCardIds").$type<number[]>(),
  requestedCardTitles: json("requestedCardTitles").$type<string[]>(),
  requestedCardImages: json("requestedCardImages").$type<string[]>(),
  requestedCardValues: json("requestedCardValues").$type<number[]>(),
  message: text("message"),
  revisionNumber: int("revisionNumber").default(1).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});
export type TradeRevision = typeof tradeRevisions.$inferSelect;
export type InsertTradeRevision = typeof tradeRevisions.$inferInsert;

// ============================================================================
// MESSAGES
// ============================================================================

export const messages = mysqlTable("messages", {
  id: int("id").autoincrement().primaryKey(),
  conversationId: varchar("conversationId", { length: 100 }).notNull(),
  senderEmail: varchar("senderEmail", { length: 320 }).notNull(),
  senderName: varchar("senderName", { length: 255 }),
  receiverEmail: varchar("receiverEmail", { length: 320 }).notNull(),
  receiverName: varchar("receiverName", { length: 255 }),
  messageText: text("messageText").notNull(),
  isRead: boolean("isRead").default(false),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Message = typeof messages.$inferSelect;
export type InsertMessage = typeof messages.$inferInsert;

// ============================================================================
// CREDIT SYSTEM
// ============================================================================

export const creditAccounts = mysqlTable("creditAccounts", {
  id: int("id").autoincrement().primaryKey(),
  userEmail: varchar("userEmail", { length: 320 }).notNull().unique(),
  userName: varchar("userName", { length: 255 }),
  credits: int("credits").default(25).notNull(),
  freeCredits: int("freeCredits").default(25).notNull(),
  purchasedCredits: int("purchasedCredits").default(0).notNull(),
  plan: mysqlEnum("plan", ["free", "starter", "pro", "elite"]).default("free").notNull(),
  planResetAt: timestamp("planResetAt"),
  totalPurchased: int("totalPurchased").default(0),
  totalSpent: int("totalSpent").default(0),
  // Loyalty program
  loyaltyTier: mysqlEnum("loyaltyTier", ["bronze", "silver", "gold", "platinum", "diamond"]).default("bronze").notNull(),
  weeklyDeposits: int("weeklyDeposits").default(0).notNull(),
  monthlyDeposits: int("monthlyDeposits").default(0).notNull(),
  weeklyDepositResetAt: timestamp("weeklyDepositResetAt"),
  monthlyDepositResetAt: timestamp("monthlyDepositResetAt"),
  totalLoyaltyBonusEarned: int("totalLoyaltyBonusEarned").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type CreditAccount = typeof creditAccounts.$inferSelect;
export type InsertCreditAccount = typeof creditAccounts.$inferInsert;

export const creditTransactions = mysqlTable("creditTransactions", {
  id: int("id").autoincrement().primaryKey(),
  userEmail: varchar("userEmail", { length: 320 }).notNull(),
  amount: int("amount").notNull(),
  type: mysqlEnum("type", ["purchase", "deduction", "refund"]).notNull(),
  reason: varchar("reason", { length: 255 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type CreditTransaction = typeof creditTransactions.$inferSelect;
export type InsertCreditTransaction = typeof creditTransactions.$inferInsert;

// ============================================================================
// CARD FINGERPRINTING (DUPLICATE DETECTION)
// ============================================================================

export const cardFingerprints = mysqlTable("cardFingerprints", {
  id: int("id").autoincrement().primaryKey(),
  userEmail: varchar("userEmail", { length: 320 }).notNull(),
  frontImageHash: varchar("frontImageHash", { length: 255 }).notNull(),
  backImageHash: varchar("backImageHash", { length: 255 }).notNull(),
  overallGrade: decimal("overallGrade", { precision: 4, scale: 2 }),
  gradeLabel: varchar("gradeLabel", { length: 50 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type CardFingerprint = typeof cardFingerprints.$inferSelect;
export type InsertCardFingerprint = typeof cardFingerprints.$inferInsert;

// ============================================================================
// GRADE REQUESTS (AI + EXPERT REVIEW)
// ============================================================================

export const gradeRequests = mysqlTable("gradeRequests", {
  id: int("id").autoincrement().primaryKey(),
  frontImageUrl: text("frontImageUrl").notNull(),
  backImageUrl: text("backImageUrl").notNull(),
  requesterEmail: varchar("requesterEmail", { length: 320 }).notNull(),
  aiGradeEstimate: varchar("aiGradeEstimate", { length: 10 }),
  aiGradeDetails: text("aiGradeDetails"),
  centeringScore: varchar("centeringScore", { length: 10 }),
  cornersScore: varchar("cornersScore", { length: 10 }),
  edgesScore: varchar("edgesScore", { length: 10 }),
  surfaceScore: varchar("surfaceScore", { length: 10 }),
  estimatedValueLow: decimal("estimatedValueLow", { precision: 10, scale: 2 }),
  estimatedValueHigh: decimal("estimatedValueHigh", { precision: 10, scale: 2 }),
  status: mysqlEnum("status", ["pending_expert_review", "completed", "failed"]).default("completed").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type GradeRequest = typeof gradeRequests.$inferSelect;
export type InsertGradeRequest = typeof gradeRequests.$inferInsert;

// ============================================================================
// SHOWCASES (PUBLIC CARD DISPLAYS)
// ============================================================================

export const showcases = mysqlTable("showcases", {
  id: int("id").autoincrement().primaryKey(),
  ownerEmail: varchar("ownerEmail", { length: 320 }).notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  slug: varchar("slug", { length: 255 }).unique(),
  theme: varchar("theme", { length: 50 }).default("dark"),
  cardIds: json("cardIds").$type<number[]>(),
  isPublic: boolean("isPublic").default(true),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Showcase = typeof showcases.$inferSelect;
export type InsertShowcase = typeof showcases.$inferInsert;

// ============================================================================
// WISHLISTS
// ============================================================================

export const wishlists = mysqlTable("wishlists", {
  id: int("id").autoincrement().primaryKey(),
  userEmail: varchar("userEmail", { length: 320 }).notNull(),
  playerName: varchar("playerName", { length: 255 }).notNull(),
  year: varchar("year", { length: 10 }),
  setName: varchar("setName", { length: 255 }),
  cardNumber: varchar("cardNumber", { length: 50 }),
  sport: mysqlEnum("sport", ["baseball", "basketball", "football", "hockey", "soccer", "golf", "tennis", "mma", "boxing", "other"]),
  maxPrice: decimal("maxPrice", { precision: 10, scale: 2 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Wishlist = typeof wishlists.$inferSelect;
export type InsertWishlist = typeof wishlists.$inferInsert;

// ============================================================================
// AFFILIATE PROGRAM
// ============================================================================

export const affiliates = mysqlTable("affiliates", {
  id: int("id").autoincrement().primaryKey(),
  userEmail: varchar("userEmail", { length: 320 }).notNull().unique(),
  userName: varchar("userName", { length: 255 }),
  referralCode: varchar("referralCode", { length: 20 }).notNull().unique(),
  totalReferrals: int("totalReferrals").default(0),
  totalEarnings: decimal("totalEarnings", { precision: 10, scale: 2 }).default("0.00"),
  pendingPayout: decimal("pendingPayout", { precision: 10, scale: 2 }).default("0.00"),
  paidOut: decimal("paidOut", { precision: 10, scale: 2 }).default("0.00"),
  status: mysqlEnum("status", ["active", "suspended", "pending"]).default("active").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Affiliate = typeof affiliates.$inferSelect;
export type InsertAffiliate = typeof affiliates.$inferInsert;

export const affiliateReferrals = mysqlTable("affiliateReferrals", {
  id: int("id").autoincrement().primaryKey(),
  affiliateEmail: varchar("affiliateEmail", { length: 320 }).notNull(),
  referralCode: varchar("referralCode", { length: 20 }).notNull(),
  referredEmail: varchar("referredEmail", { length: 320 }).notNull(),
  referredName: varchar("referredName", { length: 255 }),
  commissionAmount: decimal("commissionAmount", { precision: 10, scale: 2 }).default("0.00"),
  status: mysqlEnum("status", ["pending", "paid", "cancelled"]).default("pending").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type AffiliateReferral = typeof affiliateReferrals.$inferSelect;
export type InsertAffiliateReferral = typeof affiliateReferrals.$inferInsert;

// ============================================================================
// NOTIFICATION / MESSAGE TEMPLATES
// ============================================================================

export const notificationTemplates = mysqlTable("notificationTemplates", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 100 }).notNull().unique(),
  subject: varchar("subject", { length: 255 }).notNull(),
  body: text("body").notNull(),
  trigger: mysqlEnum("trigger", [
    "order_placed",
    "order_shipped",
    "order_delivered",
    "trade_received",
    "trade_accepted",
    "trade_rejected",
    "auction_won",
    "auction_outbid",
    "auction_ended",
    "grade_complete",
    "credit_added",
    "welcome"
  ]).notNull(),
  isActive: boolean("isActive").default(true),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type NotificationTemplate = typeof notificationTemplates.$inferSelect;
export type InsertNotificationTemplate = typeof notificationTemplates.$inferInsert;

// ============================================================================
// REFERRAL VISITS (IP + cookie tracking for 30-day attribution)
// ============================================================================

export const referralVisits = mysqlTable("referralVisits", {
  id: int("id").autoincrement().primaryKey(),
  refCode: varchar("refCode", { length: 20 }).notNull(),
  affiliateEmail: varchar("affiliateEmail", { length: 320 }).notNull(),
  visitorIp: varchar("visitorIp", { length: 64 }),
  visitorCookie: varchar("visitorCookie", { length: 64 }),
  convertedEmail: varchar("convertedEmail", { length: 320 }),
  convertedAt: timestamp("convertedAt"),
  creditsTier: varchar("creditsTier", { length: 20 }),
  layer2BonusAwarded: boolean("layer2BonusAwarded").default(false),
  expiresAt: timestamp("expiresAt").notNull(),
  visitedAt: timestamp("visitedAt").defaultNow().notNull(),
});

export type ReferralVisit = typeof referralVisits.$inferSelect;
export type InsertReferralVisit = typeof referralVisits.$inferInsert;

// ============================================================================
// DISCOUNT CODES
// ============================================================================
export const discountCodes = mysqlTable("discountCodes", {
  id: int("id").autoincrement().primaryKey(),
  code: varchar("code", { length: 50 }).notNull().unique(),
  description: varchar("description", { length: 255 }),
  // What this code does:
  // plan_override: sets the user's plan tier, monthly credits, and monthly fee to specific values
  // percent_off: gives X% off the next plan purchase (Stripe coupon)
  // credit_bonus: adds a one-time credit bonus
  type: mysqlEnum("type", ["plan_override", "percent_off", "credit_bonus"]).notNull().default("plan_override"),
  // For plan_override: the plan tier to grant
  planTier: mysqlEnum("planTier", ["free", "starter", "pro", "elite"]),
  // For plan_override: monthly credits to grant (overrides plan default)
  monthlyCredits: int("monthlyCredits"),
  // For plan_override: monthly fee in cents (0 = free)
  monthlyFeeCents: int("monthlyFeeCents").default(0),
  // For percent_off: 0-100
  percentOff: int("percentOff"),
  // For credit_bonus: one-time credits to add
  creditBonus: int("creditBonus"),
  isActive: boolean("isActive").default(true).notNull(),
  // null = unlimited
  usageLimit: int("usageLimit"),
  usageCount: int("usageCount").default(0).notNull(),
  expiresAt: timestamp("expiresAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});
export type DiscountCode = typeof discountCodes.$inferSelect;
export type InsertDiscountCode = typeof discountCodes.$inferInsert;

// Track which users have used which discount codes
export const discountCodeUsages = mysqlTable("discountCodeUsages", {
  id: int("id").autoincrement().primaryKey(),
  codeId: int("codeId").notNull(),
  userEmail: varchar("userEmail", { length: 320 }).notNull(),
  appliedAt: timestamp("appliedAt").defaultNow().notNull(),
});
export type DiscountCodeUsage = typeof discountCodeUsages.$inferSelect;

// ============================================================================
// COMP REFERENCES (eBay sold sales saved as price references for collection items)
// ============================================================================
export const compReferences = mysqlTable("compReferences", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  collectionItemId: int("collectionItemId").notNull(),
  salePrice: decimal("salePrice", { precision: 10, scale: 2 }).notNull(),
  saleDate: varchar("saleDate", { length: 30 }),
  condition: varchar("condition", { length: 100 }),
  platform: varchar("platform", { length: 50 }).default("eBay").notNull(),
  sourceUrl: text("sourceUrl"),
  title: varchar("title", { length: 255 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});
export type CompReference = typeof compReferences.$inferSelect;
export type InsertCompReference = typeof compReferences.$inferInsert;

// ============================================================================
// CARD EVENTS (Lifecycle timeline for each collection item)
// ============================================================================
export const cardEvents = mysqlTable("cardEvents", {
  id: int("id").autoincrement().primaryKey(),
  collectionItemId: int("collectionItemId").default(0).notNull(),
  cardId: int("cardId"),  // house card ID (nullable — only set for house card events)
  userEmail: varchar("userEmail", { length: 320 }),
  eventType: mysqlEnum("eventType", [
    "added",
    "graded",
    "listed",
    "delisted",
    "auction_started",
    "auction_ended",
    "bid_received",
    "trade_offered",
    "trade_agreed",
    "trade_fee_paid",
    "shipped_to_scg",
    "received_by_scg",
    "shipped_to_recipient",
    "delivered",
    "sold",
    "traded",
    "price_updated",
    "note_added",
    "imported",
    "vaulted",
    "casino_assigned",
    "status_changed",
    "auction_bid",
    "auction_won",
    "bulk_action",
  ]).notNull(),
  description: text("description"),
  metadata: text("metadata"), // JSON string for extra data (price, tracking #, etc.)
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});
export type CardEvent = typeof cardEvents.$inferSelect;
export type InsertCardEvent = typeof cardEvents.$inferInsert;

// ============================================================================
// GAME ROOM
// ============================================================================

/** Cards the house puts up as prizes - jackpots and vault rewards */
export const prizeVault = mysqlTable("prize_vault", {
  id: int("id").autoincrement().primaryKey(),
  cardTitle: varchar("cardTitle", { length: 255 }).notNull(),
  playerName: varchar("playerName", { length: 255 }).notNull(),
  year: varchar("year", { length: 10 }),
  setName: varchar("setName", { length: 255 }),
  sport: mysqlEnum("sport", ["baseball", "basketball", "football", "hockey", "soccer", "golf", "tennis", "mma", "boxing", "other"]).default("basketball").notNull(),
  frontImageUrl: text("frontImageUrl"),
  backImageUrl: text("backImageUrl"),
  gradeScore: varchar("gradeScore", { length: 10 }),
  estimatedValue: decimal("estimatedValue", { precision: 10, scale: 2 }).notNull(),
  creditCost: int("creditCost").notNull(),           // credits needed to claim
  tier: mysqlEnum("tier", ["mega_jackpot", "mini_jackpot", "featured", "standard"]).default("standard").notNull(),
  isActive: boolean("isActive").default(true).notNull(),
  isClaimed: boolean("isClaimed").default(false).notNull(),
  claimedByUserId: int("claimedByUserId"),
  claimedAt: timestamp("claimedAt"),
  addedByAdmin: boolean("addedByAdmin").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});
export type PrizeVault = typeof prizeVault.$inferSelect;
export type InsertPrizeVault = typeof prizeVault.$inferInsert;

/** Log every game play - pack rip, spin, scratch */
export const gamePlays = mysqlTable("game_plays", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  gameType: mysqlEnum("gameType", ["pack_rip", "spin_wheel", "scratch_card", "tournament", "poker", "roulette", "blackjack", "free_spin"]).notNull(),
  creditsSpent: int("creditsSpent").notNull(),
  creditsWon: int("creditsWon").default(0).notNull(),
  prizeVaultId: int("prizeVaultId"),
  outcome: mysqlEnum("outcome", ["credits", "card_prize", "jackpot", "mini_jackpot", "bust", "registered", "win", "loss"]).notNull(),
  outcomeData: json("outcomeData"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});
export type GamePlay = typeof gamePlays.$inferSelect;
export type InsertGamePlay = typeof gamePlays.$inferInsert;

/** Saved roulette bet combinations per user */
export const rouletteSavedBets = mysqlTable("roulette_saved_bets", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  name: varchar("name", { length: 100 }).notNull(),
  bets: json("bets").notNull(), // Array<{ bet: BetType; amount: number }>
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});
export type RouletteSavedBet = typeof rouletteSavedBets.$inferSelect;
export type InsertRouletteSavedBet = typeof rouletteSavedBets.$inferInsert;

/** Imported card collection from Sports Cards Pro */
export const userCollection = mysqlTable("user_collection", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  scpId: varchar("scpId", { length: 32 }).notNull(),          // SCP product ID
  productName: varchar("productName", { length: 512 }).notNull(),
  consoleName: varchar("consoleName", { length: 512 }).notNull(), // set name
  priceInPennies: int("priceInPennies").default(0).notNull(),
  costBasisInPennies: int("costBasisInPennies").default(0).notNull(),
  condition: varchar("condition", { length: 128 }),
  quantity: int("quantity").default(1).notNull(),
  imageUrl: text("imageUrl"),                                 // front image
  imageBackUrl: text("imageBackUrl"),                         // back image (if available)
  gradingCompany: varchar("gradingCompany", { length: 64 }),
  gradingCertId: varchar("gradingCertId", { length: 128 }),
  sport: varchar("sport", { length: 64 }),                    // Basketball, Football, etc.
  playerName: varchar("playerName", { length: 255 }),         // extracted from productName
  dateEntered: varchar("dateEntered", { length: 32 }),
  datePurchased: varchar("datePurchased", { length: 32 }),
  notes: text("notes"),
  folder: varchar("folder", { length: 255 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});
export type UserCollection = typeof userCollection.$inferSelect;
export type InsertUserCollection = typeof userCollection.$inferInsert;

// ============================================================================
// FAVORITES & PERSONALIZATION
// ============================================================================

export const favorites = mysqlTable("favorites", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  cardId: int("cardId").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Favorite = typeof favorites.$inferSelect;
export type InsertFavorite = typeof favorites.$inferInsert;

export const userInterests = mysqlTable("user_interests", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  playerName: varchar("playerName", { length: 255 }).notNull(),
  sport: varchar("sport", { length: 50 }),
  searchCount: int("searchCount").default(1).notNull(),
  viewCount: int("viewCount").default(0).notNull(),
  avgPrice: decimal("avgPrice", { precision: 10, scale: 2 }),
  lastInteractedAt: timestamp("lastInteractedAt").defaultNow().notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type UserInterest = typeof userInterests.$inferSelect;
export type InsertUserInterest = typeof userInterests.$inferInsert;

// ============================================================================
// CARD IMAGE LIBRARY
// Permanent S3-backed image store keyed by SCP product ID.
// Once uploaded, images are reused across future imports of the same card.
// ============================================================================
export const cardImages = mysqlTable("card_images", {
  id: int("id").autoincrement().primaryKey(),
  scpId: varchar("scpId", { length: 32 }).notNull().unique(),
  productName: varchar("productName", { length: 512 }).notNull(),
  setName: varchar("setName", { length: 512 }),
  frontImageUrl: text("frontImageUrl"),
  backImageUrl: text("backImageUrl"),
  extraImageUrls: json("extraImageUrls").$type<string[]>().default([]),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});
export type CardImage = typeof cardImages.$inferSelect;
export type InsertCardImage = typeof cardImages.$inferInsert;

// ============================================================================
// TOURNAMENTS
// ============================================================================

export const tournaments = mysqlTable("tournaments", {
  id: int("id").autoincrement().primaryKey(),
  type: mysqlEnum("type", ["regular", "winner_take_all"]).default("regular").notNull(),
  game: mysqlEnum("game", ["poker", "blackjack"]).default("poker").notNull(),
  buyIn: int("buyIn").notNull(), // credits (1, 2, 5, 10, 20)
  maxPlayers: int("maxPlayers").default(9).notNull(),
  currentPlayers: int("currentPlayers").default(0).notNull(),
  status: mysqlEnum("status", ["registering", "active", "final_table", "completed", "cancelled"]).default("registering").notNull(),
  prizePool: int("prizePool").default(0).notNull(), // total credits in pot
  prizeTier1: int("prizeTier1").default(0), // 1st place credits
  prizeTier2: int("prizeTier2").default(0), // 2nd place credits
  prizeTier3: int("prizeTier3").default(0), // 3rd place credits
  prizeCardId: int("prizeCardId"),           // card prize for winner-take-all
  startedAt: timestamp("startedAt"),
  finalTableAt: timestamp("finalTableAt"),
  completedAt: timestamp("completedAt"),
  scheduledAt: timestamp("scheduledAt").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});
export type Tournament = typeof tournaments.$inferSelect;
export type InsertTournament = typeof tournaments.$inferInsert;

export const tournamentPlayers = mysqlTable("tournament_players", {
  id: int("id").autoincrement().primaryKey(),
  tournamentId: int("tournamentId").notNull(),
  userId: int("userId"),        // null = AI player
  aiName: varchar("aiName", { length: 64 }),
  aiAvatar: varchar("aiAvatar", { length: 8 }),
  chips: int("chips").default(1000).notNull(),
  status: mysqlEnum("status", ["active", "eliminated", "winner"]).default("active").notNull(),
  finishPosition: int("finishPosition"),
  creditsWon: int("creditsWon").default(0),
  joinedAt: timestamp("joinedAt").defaultNow().notNull(),
  eliminatedAt: timestamp("eliminatedAt"),
});
export type TournamentPlayer = typeof tournamentPlayers.$inferSelect;
export type InsertTournamentPlayer = typeof tournamentPlayers.$inferInsert;

/** Free card play tracking — 2 free cards per day, 30-min cooldown between plays */
export const freeCardPlays = mysqlTable("free_card_plays", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  cardId: int("cardId").notNull(),
  cardTitle: varchar("cardTitle", { length: 256 }).notNull(),
  cardValue: decimal("cardValue", { precision: 10, scale: 2 }).notNull(),
  claimed: boolean("claimed").default(false).notNull(),
  claimedAt: timestamp("claimedAt"),
  playedAt: timestamp("playedAt").defaultNow().notNull(),
});
export type FreeCardPlay = typeof freeCardPlays.$inferSelect;
export type InsertFreeCardPlay = typeof freeCardPlays.$inferInsert;

/** AI-generated blog posts with optional YouTube video */
export const blogPosts = mysqlTable("blog_posts", {
  id: int("id").autoincrement().primaryKey(),
  title: varchar("title", { length: 512 }).notNull(),
  slug: varchar("slug", { length: 512 }).notNull().unique(),
  excerpt: text("excerpt"),
  content: mediumtext("content").notNull(),
  sport: varchar("sport", { length: 64 }),
  tags: text("tags"),
  coverImageUrl: text("coverImageUrl"),
  youtubeVideoId: varchar("youtubeVideoId", { length: 64 }),
  youtubeUrl: text("youtubeUrl"),
  videoUrl: text("videoUrl"),
  videoStatus: varchar("videoStatus", { length: 32 }).default("none"),
  videoErrorMsg: text("videoErrorMsg"),
  youtubeAutoTags: text("youtubeAutoTags"),   // JSON array of AI-generated YouTube tags
  youtubeAutoLinks: text("youtubeAutoLinks"), // JSON array of authoritative links for video description
  status: varchar("status", { length: 32 }).default("draft"),
  publishedAt: timestamp("publishedAt"),
  viewCount: int("view_count").default(0).notNull(),
  clickCount: int("click_count").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().notNull(),
});
export type BlogPost = typeof blogPosts.$inferSelect;
export type InsertBlogPost = typeof blogPosts.$inferInsert;

/** Daily content performance metrics per blog post */
export const contentMetrics = mysqlTable("content_metrics", {
  id: int("id").autoincrement().primaryKey(),
  postId: int("post_id").notNull(),
  date: varchar("date", { length: 10 }).notNull(), // YYYY-MM-DD
  views: int("views").default(0).notNull(),
  clicks: int("clicks").default(0).notNull(),
  youtubeViews: int("youtube_views").default(0).notNull(),
  youtubeLikes: int("youtube_likes").default(0).notNull(),
  youtubeComments: int("youtube_comments").default(0).notNull(),
  referrer: varchar("referrer", { length: 256 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});
export type ContentMetric = typeof contentMetrics.$inferSelect;


// ============================================================================
// KIDS CORNER
// ============================================================================

/** Kid profile — linked to a parent user account */
export const kidsProfiles = mysqlTable("kids_profiles", {
  id: int("id").autoincrement().primaryKey(),
  parentUserId: int("parentUserId").notNull(),          // FK → users.id
  username: varchar("username", { length: 64 }).notNull().unique(),
  displayName: varchar("displayName", { length: 128 }).notNull(),
  birthdate: varchar("birthdate", { length: 10 }).notNull(), // YYYY-MM-DD
  avatarEmoji: varchar("avatarEmoji", { length: 8 }).default("⭐"),
  credits: int("credits").default(50).notNull(),         // starting credits
  totalCreditsEarned: int("totalCreditsEarned").default(50).notNull(),
  level: int("level").default(1).notNull(),
  xp: int("xp").default(0).notNull(),
  isActive: boolean("isActive").default(true).notNull(),
  lastDailyClaimAt: timestamp("lastDailyClaimAt"),
  shareToken: varchar("shareToken", { length: 64 }).unique(), // public share link token
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});
export type KidsProfile = typeof kidsProfiles.$inferSelect;
export type InsertKidsProfile = typeof kidsProfiles.$inferInsert;

/** Cards a kid has pulled/earned into their collection */
export const kidsCollection = mysqlTable("kids_collection", {
  id: int("id").autoincrement().primaryKey(),
  kidId: int("kidId").notNull(),                         // FK → kids_profiles.id
  playerName: varchar("playerName", { length: 255 }).notNull(),
  year: varchar("year", { length: 8 }),
  sport: varchar("sport", { length: 32 }),
  setName: varchar("setName", { length: 255 }),
  cardNumber: varchar("cardNumber", { length: 32 }),
  imageUrl: text("imageUrl"),
  rarity: mysqlEnum("rarity", ["common", "uncommon", "rare", "epic", "legendary"]).default("common").notNull(),
  estimatedValue: decimal("estimatedValue", { precision: 10, scale: 2 }).default("0.00"),
  isFavorite: boolean("isFavorite").default(false).notNull(),
  source: mysqlEnum("source", ["daily_pull", "trivia_reward", "activity_reward", "trade", "starter_pack"]).default("daily_pull").notNull(),
  acquiredAt: timestamp("acquiredAt").defaultNow().notNull(),
});
export type KidsCard = typeof kidsCollection.$inferSelect;
export type InsertKidsCard = typeof kidsCollection.$inferInsert;

/** Wishlist — cards a kid wants (parents can see for gift ideas) */
export const kidsWishlist = mysqlTable("kids_wishlist", {
  id: int("id").autoincrement().primaryKey(),
  kidId: int("kidId").notNull(),                         // FK → kids_profiles.id
  playerName: varchar("playerName", { length: 255 }).notNull(),
  year: varchar("year", { length: 8 }),
  sport: varchar("sport", { length: 32 }),
  setName: varchar("setName", { length: 255 }),
  notes: text("notes"),
  addedAt: timestamp("addedAt").defaultNow().notNull(),
});
export type KidsWishlistItem = typeof kidsWishlist.$inferSelect;

/** Trivia & learning questions */
export const kidsTriviaQuestions = mysqlTable("kids_trivia_questions", {
  id: int("id").autoincrement().primaryKey(),
  question: text("question").notNull(),
  correctAnswer: varchar("correctAnswer", { length: 255 }).notNull(),
  choiceA: varchar("choiceA", { length: 255 }).notNull(),
  choiceB: varchar("choiceB", { length: 255 }).notNull(),
  choiceC: varchar("choiceC", { length: 255 }).notNull(),
  choiceD: varchar("choiceD", { length: 255 }).notNull(),
  sport: varchar("sport", { length: 32 }),
  difficulty: mysqlEnum("difficulty", ["easy", "medium", "hard"]).default("easy").notNull(),
  ageMin: int("ageMin").default(6).notNull(),            // min age to receive this question
  ageMax: int("ageMax").default(13).notNull(),            // max age to receive this question
  subject: varchar("subject", { length: 32 }).default("sports_facts").notNull(), // math, reading, science, history, sports_facts
  category: mysqlEnum("category", ["player_fact", "record", "history", "card_value", "trade_scenario", "president_era"]).default("player_fact").notNull(),
  creditsReward: int("creditsReward").default(5).notNull(),
  funFact: text("funFact"),                              // shown after answering
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});
export type KidsTriviaQuestion = typeof kidsTriviaQuestions.$inferSelect;

/** Activity log — tracks what a kid did to earn credits */
export const kidsActivityLog = mysqlTable("kids_activity_log", {
  id: int("id").autoincrement().primaryKey(),
  kidId: int("kidId").notNull(),                         // FK → kids_profiles.id
  activityType: mysqlEnum("activityType", [
    "daily_claim",
    "card_pull",
    "trivia_correct",
    "trivia_wrong",
    "view_card",
    "add_wishlist",
    "share_collection",
    "complete_checklist",
    "trade_scenario",
    "value_game",
  ]).notNull(),
  creditsEarned: int("creditsEarned").default(0).notNull(),
  creditsSpent: int("creditsSpent").default(0).notNull(),
  metadata: json("metadata"),                            // e.g. { cardId, questionId, score }
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});
export type KidsActivityLog = typeof kidsActivityLog.$inferSelect;

/** Daily checklist items (static config, seeded) */
export const kidsDailyChecklist = mysqlTable("kids_daily_checklist", {
  id: int("id").autoincrement().primaryKey(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  activityType: varchar("activityType", { length: 64 }).notNull(),
  creditsReward: int("creditsReward").default(5).notNull(),
  icon: varchar("icon", { length: 8 }).default("⭐"),
  sortOrder: int("sortOrder").default(0).notNull(),
  isActive: boolean("isActive").default(true).notNull(),
});
export type KidsDailyChecklist = typeof kidsDailyChecklist.$inferSelect;

// ============================================================================
// KIDS TRADING
// ============================================================================
/** Trade requests between kids — swap showcase cards */
export const kidsTradeRequests = mysqlTable("kids_trade_requests", {
  id: int("id").autoincrement().primaryKey(),
  offererId: int("offererId").notNull(),
  receiverId: int("receiverId").notNull(),
  offeredCardId: int("offeredCardId").notNull(),
  requestedCardId: int("requestedCardId").notNull(),
  status: mysqlEnum("status", ["pending", "accepted", "declined", "cancelled", "expired"]).default("pending").notNull(),
  message: varchar("message", { length: 255 }),
  expiresAt: timestamp("expiresAt").notNull(),
  respondedAt: timestamp("respondedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});
export type KidsTradeRequest = typeof kidsTradeRequests.$inferSelect;
export type InsertKidsTradeRequest = typeof kidsTradeRequests.$inferInsert;

// ============================================================================
// KIDS PLAY SESSIONS (Daily Time Tracker)
// ============================================================================
/** Records each play session for a kid — used to enforce 1-hour daily limit */
export const kidsPlaySessions = mysqlTable("kids_play_sessions", {
  id: int("id").autoincrement().primaryKey(),
  kidId: int("kidId").notNull(),
  sessionDate: varchar("sessionDate", { length: 10 }).notNull(),
  startedAt: timestamp("startedAt").defaultNow().notNull(),
  endedAt: timestamp("endedAt"),
  durationSeconds: int("durationSeconds").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});
export type KidsPlaySession = typeof kidsPlaySessions.$inferSelect;

/** Parent-granted bonus time allowances */
export const kidsTimeAllowances = mysqlTable("kids_time_allowances", {
  id: int("id").autoincrement().primaryKey(),
  kidId: int("kidId").notNull(),
  grantedByUserId: int("grantedByUserId").notNull(),
  allowanceDate: varchar("allowanceDate", { length: 10 }).notNull(),
  bonusSeconds: int("bonusSeconds").default(3600).notNull(),
  reason: varchar("reason", { length: 255 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});
export type KidsTimeAllowance = typeof kidsTimeAllowances.$inferSelect;

// ============================================================================
// KIDS EDUCATIONAL TRIVIA — HISTORY & SPACED REPETITION
// ============================================================================

/** Per-kid question attempt history — drives spaced repetition */
export const kidsQuestionHistory = mysqlTable("kids_question_history", {
  id: int("id").autoincrement().primaryKey(),
  kidId: int("kidId").notNull(),                         // FK → kids_profiles.id
  questionId: int("questionId").notNull(),               // FK → kids_trivia_questions.id
  answeredCorrectly: boolean("answeredCorrectly").notNull(),
  selectedAnswer: varchar("selectedAnswer", { length: 255 }),
  attemptCount: int("attemptCount").default(1).notNull(), // how many times this question was shown
  masteredAt: timestamp("masteredAt"),                   // set when answered correctly
  lastShownAt: timestamp("lastShownAt").defaultNow().notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});
export type KidsQuestionHistory = typeof kidsQuestionHistory.$inferSelect;

/** Rephrase queue — wrong answers get a rephrased version queued for later */
export const kidsRephraseQueue = mysqlTable("kids_rephrase_queue", {
  id: int("id").autoincrement().primaryKey(),
  kidId: int("kidId").notNull(),                         // FK → kids_profiles.id
  originalQuestionId: int("originalQuestionId").notNull(), // FK → kids_trivia_questions.id
  rephrasedQuestion: text("rephrasedQuestion").notNull(), // AI-rephrased version
  rephrasedChoiceA: varchar("rephrasedChoiceA", { length: 255 }).notNull(),
  rephrasedChoiceB: varchar("rephrasedChoiceB", { length: 255 }).notNull(),
  rephrasedChoiceC: varchar("rephrasedChoiceC", { length: 255 }).notNull(),
  rephrasedChoiceD: varchar("rephrasedChoiceD", { length: 255 }).notNull(),
  correctAnswer: varchar("correctAnswer", { length: 255 }).notNull(),
  showAfterCount: int("showAfterCount").notNull(),        // show after this many questions answered
  shown: boolean("shown").default(false).notNull(),
  answeredCorrectly: boolean("answeredCorrectly"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});
export type KidsRephraseQueueItem = typeof kidsRephraseQueue.$inferSelect;

/** Per-kid subject mastery summary (updated on each answer) */
export const kidsSubjectMastery = mysqlTable("kids_subject_mastery", {
  id: int("id").autoincrement().primaryKey(),
  kidId: int("kidId").notNull(),
  subject: varchar("subject", { length: 32 }).notNull(), // math, reading, science, history, sports
  totalAnswered: int("totalAnswered").default(0).notNull(),
  totalCorrect: int("totalCorrect").default(0).notNull(),
  currentStreak: int("currentStreak").default(0).notNull(),
  bestStreak: int("bestStreak").default(0).notNull(),
  lastAnsweredAt: timestamp("lastAnsweredAt"),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});
export type KidsSubjectMastery = typeof kidsSubjectMastery.$inferSelect;

// ============================================================================
// DISPUTES — buyer-initiated order disputes
// ============================================================================
export const disputes = mysqlTable("disputes", {
  id:             int("id").autoincrement().primaryKey(),
  orderId:        int("orderId").notNull(),
  buyerId:        int("buyerId").notNull(),
  reason:         varchar("reason", { length: 64 }).notNull(),
  description:    text("description").notNull(),
  status:         varchar("status", { length: 32 }).default("open").notNull(),
  resolutionNote: text("resolutionNote"),
  resolvedBy:     int("resolvedBy"),
  resolvedAt:     timestamp("resolvedAt"),
  createdAt:      timestamp("createdAt").defaultNow().notNull(),
  updatedAt:      timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});
export type Dispute = typeof disputes.$inferSelect;

// ============================================================================
// VISITOR SEARCH HISTORY (Per-visitor personalization)
// ============================================================================
/** Tracks anonymous + logged-in visitor searches for Marketplace personalization */
export const visitorSearchHistory = mysqlTable("visitor_search_history", {
  id:          int("id").autoincrement().primaryKey(),
  visitorKey:  varchar("visitorKey", { length: 128 }).notNull(), // userId or sessionId
  isLoggedIn:  boolean("isLoggedIn").default(false).notNull(),
  query:       varchar("query", { length: 255 }).notNull(),
  sport:       varchar("sport", { length: 50 }),
  playerName:  varchar("playerName", { length: 255 }),
  searchedAt:  timestamp("searchedAt").defaultNow().notNull(),
});
export type VisitorSearchHistory = typeof visitorSearchHistory.$inferSelect;
export type InsertVisitorSearchHistory = typeof visitorSearchHistory.$inferInsert;

// ============================================================================
// HOT PLAYERS (Daily trending player scores for Marketplace rotation)
// ============================================================================
/** Daily hot-player scores — updated by 3am cron, used to weight Marketplace display */
export const hotPlayers = mysqlTable("hot_players", {
  id:          int("id").autoincrement().primaryKey(),
  playerName:  varchar("playerName", { length: 255 }).notNull(),
  sport:       varchar("sport", { length: 50 }).notNull(),
  hotScore:    int("hotScore").default(0).notNull(),  // higher = more prominent
  reason:      varchar("reason", { length: 500 }),    // e.g. "trending on eBay, recent news"
  scoreDate:   varchar("scoreDate", { length: 10 }).notNull(), // YYYY-MM-DD
  createdAt:   timestamp("createdAt").defaultNow().notNull(),
});
export type HotPlayer = typeof hotPlayers.$inferSelect;
export type InsertHotPlayer = typeof hotPlayers.$inferInsert;
