CREATE TABLE `affiliateReferrals` (
	`id` int AUTO_INCREMENT NOT NULL,
	`affiliateEmail` varchar(320) NOT NULL,
	`referralCode` varchar(20) NOT NULL,
	`referredEmail` varchar(320) NOT NULL,
	`referredName` varchar(255),
	`commissionAmount` decimal(10,2) DEFAULT '0.00',
	`status` enum('pending','paid','cancelled') NOT NULL DEFAULT 'pending',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `affiliateReferrals_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `affiliates` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userEmail` varchar(320) NOT NULL,
	`userName` varchar(255),
	`referralCode` varchar(20) NOT NULL,
	`totalReferrals` int DEFAULT 0,
	`totalEarnings` decimal(10,2) DEFAULT '0.00',
	`pendingPayout` decimal(10,2) DEFAULT '0.00',
	`paidOut` decimal(10,2) DEFAULT '0.00',
	`status` enum('active','suspended','pending') NOT NULL DEFAULT 'active',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `affiliates_id` PRIMARY KEY(`id`),
	CONSTRAINT `affiliates_userEmail_unique` UNIQUE(`userEmail`),
	CONSTRAINT `affiliates_referralCode_unique` UNIQUE(`referralCode`)
);
--> statement-breakpoint
CREATE TABLE `notificationTemplates` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(100) NOT NULL,
	`subject` varchar(255) NOT NULL,
	`body` text NOT NULL,
	`trigger` enum('order_placed','order_shipped','order_delivered','trade_received','trade_accepted','trade_rejected','auction_won','auction_outbid','auction_ended','grade_complete','credit_added','welcome') NOT NULL,
	`isActive` boolean DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `notificationTemplates_id` PRIMARY KEY(`id`),
	CONSTRAINT `notificationTemplates_name_unique` UNIQUE(`name`)
);
