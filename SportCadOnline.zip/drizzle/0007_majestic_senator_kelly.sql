ALTER TABLE `blog_posts` ADD `youtubeAutoTags` text;--> statement-breakpoint
ALTER TABLE `blog_posts` ADD `youtubeAutoLinks` text;