CREATE TABLE `hot_players` (
	`id` int AUTO_INCREMENT NOT NULL,
	`playerName` varchar(255) NOT NULL,
	`sport` varchar(50) NOT NULL,
	`hotScore` int NOT NULL DEFAULT 0,
	`reason` varchar(500),
	`scoreDate` varchar(10) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `hot_players_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `visitor_search_history` (
	`id` int AUTO_INCREMENT NOT NULL,
	`visitorKey` varchar(128) NOT NULL,
	`isLoggedIn` boolean NOT NULL DEFAULT false,
	`query` varchar(255) NOT NULL,
	`sport` varchar(50),
	`playerName` varchar(255),
	`searchedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `visitor_search_history_id` PRIMARY KEY(`id`)
);
