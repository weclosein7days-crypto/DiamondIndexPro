ALTER TABLE `collections` MODIFY COLUMN `listingStatus` enum('none','listed','auction','in_trade','in_sale','shipped','traded','sold','pending_gm','gs','gm_complete') NOT NULL DEFAULT 'none';--> statement-breakpoint
ALTER TABLE `game_plays` MODIFY COLUMN `gameType` enum('pack_rip','spin_wheel','scratch_card','tournament','poker','roulette','blackjack') NOT NULL;--> statement-breakpoint
ALTER TABLE `game_plays` MODIFY COLUMN `outcome` enum('credits','card_prize','jackpot','mini_jackpot','bust','registered','win','loss') NOT NULL;--> statement-breakpoint
ALTER TABLE `collections` ADD `gameSource` varchar(100);--> statement-breakpoint
ALTER TABLE `collections` ADD `prizeClaimId` int;--> statement-breakpoint
ALTER TABLE `collections` ADD `trackingNumber` varchar(100);