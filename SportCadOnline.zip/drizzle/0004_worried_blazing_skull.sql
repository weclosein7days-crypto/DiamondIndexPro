ALTER TABLE `kids_trivia_questions` ADD `ageMax` int DEFAULT 13 NOT NULL;--> statement-breakpoint
ALTER TABLE `kids_trivia_questions` ADD `subject` varchar(32) DEFAULT 'sports_facts' NOT NULL;