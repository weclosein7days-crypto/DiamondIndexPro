CREATE TABLE `kids_question_history` (
	`id` int AUTO_INCREMENT NOT NULL,
	`kidId` int NOT NULL,
	`questionId` int NOT NULL,
	`answeredCorrectly` boolean NOT NULL,
	`selectedAnswer` varchar(255),
	`attemptCount` int NOT NULL DEFAULT 1,
	`masteredAt` timestamp,
	`lastShownAt` timestamp NOT NULL DEFAULT (now()),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `kids_question_history_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `kids_rephrase_queue` (
	`id` int AUTO_INCREMENT NOT NULL,
	`kidId` int NOT NULL,
	`originalQuestionId` int NOT NULL,
	`rephrasedQuestion` text NOT NULL,
	`rephrasedChoiceA` varchar(255) NOT NULL,
	`rephrasedChoiceB` varchar(255) NOT NULL,
	`rephrasedChoiceC` varchar(255) NOT NULL,
	`rephrasedChoiceD` varchar(255) NOT NULL,
	`correctAnswer` varchar(255) NOT NULL,
	`showAfterCount` int NOT NULL,
	`shown` boolean NOT NULL DEFAULT false,
	`answeredCorrectly` boolean,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `kids_rephrase_queue_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `kids_subject_mastery` (
	`id` int AUTO_INCREMENT NOT NULL,
	`kidId` int NOT NULL,
	`subject` varchar(32) NOT NULL,
	`totalAnswered` int NOT NULL DEFAULT 0,
	`totalCorrect` int NOT NULL DEFAULT 0,
	`currentStreak` int NOT NULL DEFAULT 0,
	`bestStreak` int NOT NULL DEFAULT 0,
	`lastAnsweredAt` timestamp,
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `kids_subject_mastery_id` PRIMARY KEY(`id`)
);
