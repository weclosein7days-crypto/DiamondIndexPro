ALTER TABLE `creditAccounts` MODIFY COLUMN `credits` int NOT NULL DEFAULT 25;--> statement-breakpoint
ALTER TABLE `creditAccounts` MODIFY COLUMN `plan` enum('free','starter','pro','elite') NOT NULL DEFAULT 'free';--> statement-breakpoint
ALTER TABLE `creditAccounts` ADD `planResetAt` timestamp;