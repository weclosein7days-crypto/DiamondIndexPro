CREATE TABLE `auctions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`cardId` int NOT NULL,
	`cardTitle` varchar(255) NOT NULL,
	`cardImageUrl` text,
	`sellerEmail` varchar(320) NOT NULL,
	`storeName` varchar(255),
	`startingPrice` decimal(10,2) NOT NULL,
	`currentBid` decimal(10,2) DEFAULT '0.00',
	`highestBidderEmail` varchar(320),
	`highestBidderName` varchar(255),
	`bidCount` int DEFAULT 0,
	`endTime` timestamp NOT NULL,
	`status` enum('active','ended','cancelled','sold') NOT NULL DEFAULT 'active',
	`playerName` varchar(255),
	`gradeInfo` varchar(100),
	`durationDays` int NOT NULL,
	`listingCreditsPaid` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `auctions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `bids` (
	`id` int AUTO_INCREMENT NOT NULL,
	`auctionId` int NOT NULL,
	`bidderEmail` varchar(320) NOT NULL,
	`bidderName` varchar(255),
	`bidAmount` decimal(10,2) NOT NULL,
	`bidTime` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `bids_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `cardFingerprints` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userEmail` varchar(320) NOT NULL,
	`frontImageHash` varchar(255) NOT NULL,
	`backImageHash` varchar(255) NOT NULL,
	`overallGrade` decimal(4,2),
	`gradeLabel` varchar(50),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `cardFingerprints_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `cards` (
	`id` int AUTO_INCREMENT NOT NULL,
	`title` varchar(255) NOT NULL,
	`playerName` varchar(255) NOT NULL,
	`year` varchar(10),
	`manufacturer` varchar(100),
	`cardNumber` varchar(50),
	`setName` varchar(255),
	`sport` enum('baseball','basketball','football','hockey','soccer','other') NOT NULL DEFAULT 'baseball',
	`condition` enum('raw','graded') NOT NULL DEFAULT 'raw',
	`gradeCompany` enum('PSA','Beckett','SGC','TGA','CGC','other','none') DEFAULT 'none',
	`gradeScore` varchar(10),
	`certNumber` varchar(100),
	`frontImageUrl` text,
	`backImageUrl` text,
	`extraImageUrls` json,
	`price` decimal(10,2),
	`buyNowPrice` decimal(10,2),
	`status` enum('active','sold','draft','auction','traded') NOT NULL DEFAULT 'draft',
	`storeId` int,
	`storeName` varchar(255),
	`sellerEmail` varchar(320) NOT NULL,
	`featuredOnMain` boolean DEFAULT false,
	`isMainStore` boolean DEFAULT false,
	`description` text,
	`category` enum('rookie','vintage','modern','insert','parallel','autograph','memorabilia','other') DEFAULT 'modern',
	`source` enum('manual','ebay_import','search_import') DEFAULT 'manual',
	`ebayItemId` varchar(100),
	`showSlabView` boolean DEFAULT false,
	`labelColor` enum('dark','ruby','light','silver','nightlife','red','black','none') DEFAULT 'dark',
	`aiGrade` decimal(4,2),
	`aiGradeLabel` varchar(50),
	`aiCentering` varchar(10),
	`aiCorners` varchar(10),
	`aiEdges` varchar(10),
	`aiSurface` varchar(10),
	`aiCertNumber` varchar(100),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `cards_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `collections` (
	`id` int AUTO_INCREMENT NOT NULL,
	`ownerEmail` varchar(320) NOT NULL,
	`cardTitle` varchar(255) NOT NULL,
	`playerName` varchar(255) NOT NULL,
	`year` varchar(10),
	`setName` varchar(255),
	`cardNumber` varchar(50),
	`sport` enum('baseball','basketball','football','hockey','soccer','other') NOT NULL DEFAULT 'baseball',
	`frontImageUrl` text,
	`backImageUrl` text,
	`extraImageUrls` json,
	`overallGrade` decimal(4,2),
	`gradeLabel` varchar(50),
	`centeringScore` varchar(10),
	`cornersScore` varchar(10),
	`edgesScore` varchar(10),
	`surfaceScore` varchar(10),
	`estimatedValueLow` decimal(10,2),
	`estimatedValueHigh` decimal(10,2),
	`certNumber` varchar(100),
	`description` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `collections_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `creditAccounts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userEmail` varchar(320) NOT NULL,
	`userName` varchar(255),
	`credits` int NOT NULL DEFAULT 10,
	`plan` enum('free','silver','gold','platinum') NOT NULL DEFAULT 'free',
	`totalPurchased` int DEFAULT 0,
	`totalSpent` int DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `creditAccounts_id` PRIMARY KEY(`id`),
	CONSTRAINT `creditAccounts_userEmail_unique` UNIQUE(`userEmail`)
);
--> statement-breakpoint
CREATE TABLE `creditTransactions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userEmail` varchar(320) NOT NULL,
	`amount` int NOT NULL,
	`type` enum('purchase','deduction','refund') NOT NULL,
	`reason` varchar(255),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `creditTransactions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `gradeRequests` (
	`id` int AUTO_INCREMENT NOT NULL,
	`frontImageUrl` text NOT NULL,
	`backImageUrl` text NOT NULL,
	`requesterEmail` varchar(320) NOT NULL,
	`aiGradeEstimate` varchar(10),
	`aiGradeDetails` text,
	`centeringScore` varchar(10),
	`cornersScore` varchar(10),
	`edgesScore` varchar(10),
	`surfaceScore` varchar(10),
	`estimatedValueLow` decimal(10,2),
	`estimatedValueHigh` decimal(10,2),
	`status` enum('pending_expert_review','completed','failed') NOT NULL DEFAULT 'completed',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `gradeRequests_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `messages` (
	`id` int AUTO_INCREMENT NOT NULL,
	`conversationId` varchar(100) NOT NULL,
	`senderEmail` varchar(320) NOT NULL,
	`senderName` varchar(255),
	`receiverEmail` varchar(320) NOT NULL,
	`receiverName` varchar(255),
	`messageText` text NOT NULL,
	`isRead` boolean DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `messages_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `orders` (
	`id` int AUTO_INCREMENT NOT NULL,
	`cardId` int,
	`cardIds` json,
	`cardTitle` varchar(255),
	`cardImageUrl` text,
	`buyerEmail` varchar(320) NOT NULL,
	`buyerName` varchar(255),
	`sellerEmail` varchar(320),
	`sellerEmails` json,
	`sellerStoreName` varchar(255),
	`price` decimal(10,2),
	`totalAmount` decimal(10,2),
	`platformFee` decimal(10,2),
	`sellerPayout` decimal(10,2),
	`status` enum('pending','paid','shipped','delivered','cancelled','refunded') NOT NULL DEFAULT 'pending',
	`shippingMethod` enum('usps_first_class','usps_priority','ups_ground','ups_2day','ups_next_day') DEFAULT 'usps_first_class',
	`trackingNumber` varchar(100),
	`shippingAddress` text,
	`fromAuction` boolean DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `orders_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `showcases` (
	`id` int AUTO_INCREMENT NOT NULL,
	`ownerEmail` varchar(320) NOT NULL,
	`title` varchar(255) NOT NULL,
	`description` text,
	`slug` varchar(255),
	`theme` varchar(50) DEFAULT 'dark',
	`cardIds` json,
	`isPublic` boolean DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `showcases_id` PRIMARY KEY(`id`),
	CONSTRAINT `showcases_slug_unique` UNIQUE(`slug`)
);
--> statement-breakpoint
CREATE TABLE `stores` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(255) NOT NULL,
	`ownerEmail` varchar(320) NOT NULL,
	`ownerName` varchar(255),
	`description` text,
	`logoUrl` text,
	`bannerUrl` text,
	`plan` enum('free','starter','pro','elite','franchise') NOT NULL DEFAULT 'free',
	`planStatus` enum('active','expired','cancelled') NOT NULL DEFAULT 'active',
	`labelColor` enum('dark','ruby','light','silver','nightlife','red','black','none') NOT NULL DEFAULT 'dark',
	`socialFacebook` varchar(255),
	`socialInstagram` varchar(255),
	`socialLinkedin` varchar(255),
	`socialEbay` varchar(255),
	`totalSales` int DEFAULT 0,
	`rating` decimal(3,2) DEFAULT '5.00',
	`isMainStore` boolean DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `stores_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `trades` (
	`id` int AUTO_INCREMENT NOT NULL,
	`initiatorEmail` varchar(320) NOT NULL,
	`initiatorName` varchar(255),
	`receiverEmail` varchar(320) NOT NULL,
	`receiverName` varchar(255),
	`offeredCardIds` json,
	`offeredCardTitles` json,
	`offeredCardImages` json,
	`requestedCardIds` json,
	`requestedCardTitles` json,
	`requestedCardImages` json,
	`status` enum('pending','accepted','rejected','cancelled','countered') NOT NULL DEFAULT 'pending',
	`message` text,
	`counterMessage` text,
	`conversationId` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `trades_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `wishlists` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userEmail` varchar(320) NOT NULL,
	`playerName` varchar(255) NOT NULL,
	`year` varchar(10),
	`setName` varchar(255),
	`cardNumber` varchar(50),
	`sport` enum('baseball','basketball','football','hockey','soccer','other'),
	`maxPrice` decimal(10,2),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `wishlists_id` PRIMARY KEY(`id`)
);
