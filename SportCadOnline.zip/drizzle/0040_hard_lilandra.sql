ALTER TABLE `cards` ADD `marketPrice` decimal(10,2);--> statement-breakpoint
ALTER TABLE `cards` ADD `psaPrice` decimal(10,2);