ALTER TABLE `trades` ADD `initiatorAddress` text;--> statement-breakpoint
ALTER TABLE `trades` ADD `initiatorCity` varchar(100);--> statement-breakpoint
ALTER TABLE `trades` ADD `initiatorState` varchar(50);--> statement-breakpoint
ALTER TABLE `trades` ADD `initiatorZip` varchar(20);--> statement-breakpoint
ALTER TABLE `trades` ADD `initiatorPhone` varchar(30);--> statement-breakpoint
ALTER TABLE `trades` ADD `receiverAddress` text;--> statement-breakpoint
ALTER TABLE `trades` ADD `receiverCity` varchar(100);--> statement-breakpoint
ALTER TABLE `trades` ADD `receiverState` varchar(50);--> statement-breakpoint
ALTER TABLE `trades` ADD `receiverZip` varchar(20);--> statement-breakpoint
ALTER TABLE `trades` ADD `receiverPhone` varchar(30);