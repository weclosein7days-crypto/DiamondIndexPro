CREATE TABLE `content_metrics` (
	`id` int AUTO_INCREMENT NOT NULL,
	`post_id` int NOT NULL,
	`date` varchar(10) NOT NULL,
	`views` int NOT NULL DEFAULT 0,
	`clicks` int NOT NULL DEFAULT 0,
	`youtube_views` int NOT NULL DEFAULT 0,
	`youtube_likes` int NOT NULL DEFAULT 0,
	`youtube_comments` int NOT NULL DEFAULT 0,
	`referrer` varchar(256),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `content_metrics_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `blog_posts` ADD `videoUrl` text;--> statement-breakpoint
ALTER TABLE `blog_posts` ADD `view_count` int DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `blog_posts` ADD `click_count` int DEFAULT 0 NOT NULL;