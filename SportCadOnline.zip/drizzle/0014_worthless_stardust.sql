CREATE TABLE `cardEvents` (
	`id` int AUTO_INCREMENT NOT NULL,
	`collectionItemId` int NOT NULL,
	`userEmail` varchar(320),
	`eventType` enum('added','graded','listed','delisted','auction_started','auction_ended','bid_received','trade_offered','trade_agreed','trade_fee_paid','shipped_to_scg','received_by_scg','shipped_to_recipient','delivered','sold','traded','price_updated','note_added','imported') NOT NULL,
	`description` text,
	`metadata` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `cardEvents_id` PRIMARY KEY(`id`)
);
