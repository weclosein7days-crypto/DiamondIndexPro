ALTER TABLE `cards` ADD `isUpAndComing` boolean DEFAULT false;--> statement-breakpoint
ALTER TABLE `cards` ADD `isShowcaseCard` boolean DEFAULT false;