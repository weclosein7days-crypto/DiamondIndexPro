ALTER TABLE `creditAccounts` ADD `loyaltyTier` enum('bronze','silver','gold','platinum','diamond') DEFAULT 'bronze' NOT NULL;--> statement-breakpoint
ALTER TABLE `creditAccounts` ADD `weeklyDeposits` int DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `creditAccounts` ADD `monthlyDeposits` int DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `creditAccounts` ADD `weeklyDepositResetAt` timestamp;--> statement-breakpoint
ALTER TABLE `creditAccounts` ADD `monthlyDepositResetAt` timestamp;--> statement-breakpoint
ALTER TABLE `creditAccounts` ADD `totalLoyaltyBonusEarned` int DEFAULT 0 NOT NULL;