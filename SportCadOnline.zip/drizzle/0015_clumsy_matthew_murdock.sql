ALTER TABLE `collections` ADD `labelBg` varchar(50) DEFAULT 'black-silk';--> statement-breakpoint
ALTER TABLE `collections` ADD `labelBorder` varchar(50) DEFAULT 'red';--> statement-breakpoint
ALTER TABLE `collections` ADD `labelMode` enum('with_label','no_label') DEFAULT 'with_label';