CREATE TABLE `game_plays` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`gameType` enum('pack_rip','spin_wheel','scratch_card') NOT NULL,
	`creditsSpent` int NOT NULL,
	`creditsWon` int NOT NULL DEFAULT 0,
	`prizeVaultId` int,
	`outcome` enum('credits','card_prize','jackpot','mini_jackpot','bust') NOT NULL,
	`outcomeData` json,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `game_plays_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `prize_vault` (
	`id` int AUTO_INCREMENT NOT NULL,
	`cardTitle` varchar(255) NOT NULL,
	`playerName` varchar(255) NOT NULL,
	`year` varchar(10),
	`setName` varchar(255),
	`sport` enum('baseball','basketball','football','hockey','soccer','other') NOT NULL DEFAULT 'basketball',
	`frontImageUrl` text,
	`backImageUrl` text,
	`gradeScore` varchar(10),
	`estimatedValue` decimal(10,2) NOT NULL,
	`creditCost` int NOT NULL,
	`tier` enum('mega_jackpot','mini_jackpot','featured','standard') NOT NULL DEFAULT 'standard',
	`isActive` boolean NOT NULL DEFAULT true,
	`isClaimed` boolean NOT NULL DEFAULT false,
	`claimedByUserId` int,
	`claimedAt` timestamp,
	`addedByAdmin` boolean NOT NULL DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `prize_vault_id` PRIMARY KEY(`id`)
);
