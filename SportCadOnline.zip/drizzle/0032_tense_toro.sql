ALTER TABLE `cards` ADD `ebayListingUrl` text;--> statement-breakpoint
ALTER TABLE `cards` ADD `sourcePrice` decimal(10,2);--> statement-breakpoint
ALTER TABLE `cards` ADD `isDropship` boolean DEFAULT false;--> statement-breakpoint
ALTER TABLE `orders` ADD `isDropshipOrder` boolean DEFAULT false;--> statement-breakpoint
ALTER TABLE `orders` ADD `ebayFulfillmentLink` text;--> statement-breakpoint
ALTER TABLE `orders` ADD `dropshipFulfilledAt` timestamp;