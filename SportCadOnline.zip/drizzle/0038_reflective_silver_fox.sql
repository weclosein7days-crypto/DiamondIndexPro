ALTER TABLE `orders` ADD `fundsReleased` boolean DEFAULT false;--> statement-breakpoint
ALTER TABLE `orders` ADD `fundsReleasedBy` varchar(320);--> statement-breakpoint
ALTER TABLE `orders` ADD `carrierStatus` varchar(100);