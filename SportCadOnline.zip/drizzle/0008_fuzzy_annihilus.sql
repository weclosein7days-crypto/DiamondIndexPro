ALTER TABLE `orders` ADD `ticketNumber` varchar(30);--> statement-breakpoint
ALTER TABLE `trades` ADD `initiatorReturnTracking` varchar(255);--> statement-breakpoint
ALTER TABLE `trades` ADD `receiverReturnTracking` varchar(255);--> statement-breakpoint
ALTER TABLE `trades` ADD `ticketNumber` varchar(30);--> statement-breakpoint
ALTER TABLE `trades` ADD `initiatorFeePaid` boolean DEFAULT false;--> statement-breakpoint
ALTER TABLE `trades` ADD `receiverFeePaid` boolean DEFAULT false;--> statement-breakpoint
ALTER TABLE `trades` ADD `initiatorFeeSessionId` varchar(255);--> statement-breakpoint
ALTER TABLE `trades` ADD `receiverFeeSessionId` varchar(255);--> statement-breakpoint
ALTER TABLE `trades` ADD `initiatorFeePaidAt` timestamp;--> statement-breakpoint
ALTER TABLE `trades` ADD `receiverFeePaidAt` timestamp;--> statement-breakpoint
ALTER TABLE `trades` ADD `feeReminderSentAt` timestamp;--> statement-breakpoint
ALTER TABLE `trades` ADD `feeReminderCount` int DEFAULT 0;