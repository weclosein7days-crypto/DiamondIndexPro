ALTER TABLE `collections` MODIFY COLUMN `listingStatus` enum('none','listed','auction','in_trade','in_sale','shipped','traded','sold','pending_gm','gs','gm_complete','vaulted','vault_listed','vault_auction','vault_sold','vault_shipped') NOT NULL DEFAULT 'none';--> statement-breakpoint
ALTER TABLE `cards` ADD `isVaulted` boolean DEFAULT false;--> statement-breakpoint
ALTER TABLE `cards` ADD `cardShippingFee` decimal(10,2);--> statement-breakpoint
ALTER TABLE `collections` ADD `shippingFee` decimal(10,2);--> statement-breakpoint
ALTER TABLE `collections` ADD `vaultSource` enum('game_room_win','user_deposited');