CREATE TABLE `free_card_plays` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`cardId` int NOT NULL,
	`cardTitle` varchar(256) NOT NULL,
	`cardValue` decimal(10,2) NOT NULL,
	`claimed` boolean NOT NULL DEFAULT false,
	`claimedAt` timestamp,
	`playedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `free_card_plays_id` PRIMARY KEY(`id`)
);
