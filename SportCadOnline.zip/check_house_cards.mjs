import mysql from 'mysql2/promise';
import * as dotenv from 'dotenv';
dotenv.config();

const conn = await mysql.createConnection(process.env.DATABASE_URL);

// Check column names first
const [cols] = await conn.execute('DESCRIBE cards');
console.log('Cards columns:', cols.map(c => c.Field).join(', '));

// Check total cards
const [total] = await conn.execute('SELECT COUNT(*) as cnt FROM cards');
console.log('Total cards:', total[0].cnt);

// Check by sport breakdown
const [bySport] = await conn.execute(`
  SELECT sport, COUNT(*) as cnt 
  FROM cards 
  GROUP BY sport 
  ORDER BY cnt DESC
`);
console.log('\nBy sport:', JSON.stringify(bySport, null, 2));

// Sample cards with images
const [sample] = await conn.execute(`
  SELECT id, playerName, sport, team, imageUrl, price, rarity, source
  FROM cards 
  WHERE imageUrl IS NOT NULL AND imageUrl != ''
  LIMIT 20
`);
console.log('\nSample cards with images:', JSON.stringify(sample, null, 2));

await conn.end();
