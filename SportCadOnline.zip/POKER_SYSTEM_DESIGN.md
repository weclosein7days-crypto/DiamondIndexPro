# SportCardsOnline.com — Poker System Design

**Version:** 1.0 | **Date:** April 2026 | **Status:** Planning

---

## Overview

The SCO Poker Room is a credit-based Texas Hold'em poker system where players wager virtual credits (no cash value) and win **physical sports cards** as prizes. This model mirrors the sweepstakes/prize-redemption structure used by Dave & Buster's and skill-game platforms — no gambling license required because no real money is wagered and no cash prizes are awarded.

---

## Legal Framework

| Element | Detail |
|---|---|
| Currency | SCO Credits (virtual, no cash value, non-transferable) |
| Prizes | Physical sports cards from the House Prize Vault |
| Model | Skill-based prize tournament (sweepstakes model) |
| License Required | None (no cash wagering, no cash prizes) |
| Jurisdiction | Applicable in all 50 US states under this model |

---

## Game Types

### 1. Quick Play — vs. AI Dealer
- Single-player Texas Hold'em against an AI dealer
- Available 24/7, no waiting for other players
- Entry: 5–50 credits per hand
- AI difficulty: Casual (bluffs rarely, folds weak hands)
- Outcome: Win 1.5–3× your bet on winning hands; lose bet on loss
- House edge: ~15% (AI wins slightly more often long-term)

### 2. Cash Game Tables — Player vs. Player
- 2–6 players per table, real-time multiplayer via WebSocket
- Buy-in: 50 / 100 / 250 / 500 credits (4 stake levels)
- Blinds scale with buy-in level
- No time limit — play as many hands as you want
- Leave anytime and keep your chip stack (converted back to credits)
- House rake: 5% of each pot (capped at 10 credits)

### 3. Sit & Go Tournaments
- 6 or 9 players, starts when full
- Entry fee: 25–500 credits
- Prize: Top 1–3 players win credits or vault cards
- Duration: ~30–60 minutes

### 4. Scheduled Tournaments
- Fixed start times (daily, weekly, special events)
- Registration opens 24 hours before start
- Prize pool: entry fees + house contribution (vault cards)
- Bracket: single elimination or multi-table depending on size

### 5. Freeroll Tournaments
- Zero entry fee — anyone can join
- House provides prize (standard vault card, ~$50–75 value)
- Daily freeroll: 50-player max, first come first served
- Weekly freeroll: unlimited entries, bigger prize (featured card)
- Purpose: drive daily engagement and new user acquisition

---

## Tournament Structure

### Entry Tiers

| Tier | Entry Fee | Prize Pool | Card Prize |
|---|---|---|---|
| Freeroll | 0 credits | House-funded | Standard vault card (~$50) |
| Bronze | 25 credits | 80% of pool + house top-up | Standard card (~$75) |
| Silver | 100 credits | 80% of pool + house top-up | Featured card (~$200) |
| Gold | 250 credits | 80% of pool + house top-up | Mini Jackpot card (~$500) |
| Platinum | 500 credits | 80% of pool + house top-up | Featured card + credits |
| Championship | 1,000 credits | 80% of pool + house top-up | Mega Jackpot card (~$1,200) |

### Payout Structure (example: 50 players, Gold tier, 250cr entry = 12,500cr pool)

| Place | Prize |
|---|---|
| 1st | Mini Jackpot card (Cooper Flagg RC) + 2,000 credits |
| 2nd | 1,500 credits |
| 3rd | 1,000 credits |
| 4th–6th | 500 credits each |
| 7th–9th | 250 credits each (entry refund) |

House keeps 20% of the credit pool to fund operations.

---

## Game Engine Design

### Deck & Shuffle (Provably Fair)
```
1. Server generates a random seed at table creation (stored in DB)
2. Deck of 52 cards shuffled using seeded Fisher-Yates algorithm
3. Seed is revealed to players after the hand ends (verifiable)
4. All hands logged with seed + outcome for dispute resolution
```

### Texas Hold'em Hand Flow
```
Pre-flop  → Deal 2 hole cards to each player → Betting round 1
Flop      → Deal 3 community cards → Betting round 2
Turn      → Deal 1 community card  → Betting round 3
River     → Deal 1 community card  → Betting round 4
Showdown  → Best 5-card hand from 7 cards wins
```

### Hand Evaluator
Uses a 7-card best-hand evaluator (standard poker hand rankings):
Royal Flush > Straight Flush > Four of a Kind > Full House > Flush > Straight > Three of a Kind > Two Pair > Pair > High Card

### AI Dealer Logic (Quick Play)
- **Strong hand (top 20%):** Raise 2–3× big blind
- **Medium hand (20–50%):** Call or check
- **Weak hand (50–75%):** Call small bets, fold large raises
- **Very weak (75–100%):** Fold (unless pot odds favor calling)
- **Bluff frequency:** 8% of weak hands (raises with nothing)
- **Tells:** None — AI plays consistently to avoid exploitation

### Betting Actions
- **Fold** — surrender hand, lose current bet
- **Check** — pass action (only if no bet to call)
- **Call** — match current bet
- **Raise** — increase the bet (min 2× current bet)
- **All-In** — bet all remaining chips

---

## Database Schema

### `poker_tables`
| Column | Type | Description |
|---|---|---|
| id | INT PK | Table ID |
| tableType | ENUM | quick_play, cash_game, sit_and_go, tournament |
| tournamentId | INT | FK to tournaments (if applicable) |
| status | ENUM | waiting, active, finished |
| maxPlayers | INT | 2–9 |
| buyIn | INT | Credits required to sit |
| smallBlind | INT | Small blind amount |
| bigBlind | INT | Big blind amount |
| currentHandId | INT | FK to active hand |
| createdAt | TIMESTAMP | |

### `poker_players` (seats at a table)
| Column | Type | Description |
|---|---|---|
| id | INT PK | |
| tableId | INT FK | |
| userId | INT FK | |
| seatNumber | INT | 1–9 |
| chipStack | INT | Current chips at table |
| status | ENUM | active, folded, sitting_out, busted |
| isAI | BOOLEAN | True for AI dealer in quick play |
| joinedAt | TIMESTAMP | |

### `poker_hands`
| Column | Type | Description |
|---|---|---|
| id | INT PK | |
| tableId | INT FK | |
| seed | VARCHAR | Random seed for this hand (revealed post-hand) |
| deck | JSON | Full shuffled deck (revealed post-hand) |
| communityCards | JSON | [flop1, flop2, flop3, turn, river] |
| pot | INT | Total credits in pot |
| status | ENUM | pre_flop, flop, turn, river, showdown, finished |
| winnerId | INT FK | User who won |
| winnerHand | VARCHAR | e.g. "Full House, Aces over Kings" |
| rake | INT | House rake taken |
| createdAt | TIMESTAMP | |

### `poker_hand_players`
| Column | Type | Description |
|---|---|---|
| id | INT PK | |
| handId | INT FK | |
| userId | INT FK | |
| holeCards | JSON | [card1, card2] — hidden until showdown |
| actions | JSON | Array of {action, amount, street} |
| finalBet | INT | Total wagered this hand |
| won | INT | Credits won (0 if lost) |
| handRank | VARCHAR | Best hand description |

### `tournaments`
| Column | Type | Description |
|---|---|---|
| id | INT PK | |
| name | VARCHAR | e.g. "Daily Freeroll", "Championship Sunday" |
| tier | ENUM | freeroll, bronze, silver, gold, platinum, championship |
| entryFee | INT | Credits to enter |
| maxPlayers | INT | Cap on registrations |
| startTime | TIMESTAMP | Scheduled start |
| status | ENUM | upcoming, registering, active, finished, cancelled |
| prizeVaultId | INT FK | Card prize from vault |
| creditPrize | INT | Additional credit prize for winner |
| isFreeroll | BOOLEAN | |
| createdAt | TIMESTAMP | |

### `tournament_registrations`
| Column | Type | Description |
|---|---|---|
| id | INT PK | |
| tournamentId | INT FK | |
| userId | INT FK | |
| creditsPaid | INT | Entry fee paid |
| finalPlace | INT | Finishing position |
| creditsWon | INT | Credits awarded |
| cardPrizeClaimed | BOOLEAN | |
| registeredAt | TIMESTAMP | |

---

## Real-Time Architecture

### Technology: WebSockets via Socket.io
- Each poker table gets a dedicated Socket.io room: `table:{tableId}`
- Server emits events to all players in the room
- Players emit actions (fold/call/raise) to server
- Server validates action, updates state, broadcasts new state

### Key Events
```
Server → Client:
  table:state      — full table state (cards, bets, whose turn)
  hand:dealt       — new hand started, hole cards sent privately
  player:action    — another player acted
  hand:result      — showdown result, winner, pot distribution
  tournament:update — bracket update, player eliminated

Client → Server:
  player:action    — { action: 'fold'|'call'|'raise', amount?: number }
  player:ready     — player ready to start next hand
```

### Turn Timer
- 30 seconds per action
- Visual countdown shown to all players
- Auto-fold on timeout (protects game flow)
- 3 consecutive timeouts = sit-out (chips preserved)

---

## UI Design

### Poker Table
- **Felt:** Deep green (#0d4a1f) with subtle texture, gold rail border
- **Card backs:** SCO branded (red/gold with card logo)
- **Chip colors:** White=$1, Red=$5, Blue=$10, Green=$25, Black=$100, Purple=$500
- **Animations:** Cards slide in from dealer position, chips arc into pot
- **Player seats:** Circular avatars around oval table, name + stack shown
- **Community cards:** Center of table, flip animation on reveal
- **Betting controls:** Bottom bar — Fold / Check / Call / Raise slider / All-In

### Tournament Lobby
- Grid of tournament cards showing: name, tier badge, entry fee, prize, players registered, time until start
- Filter by: Freeroll / Paid / Active / Upcoming
- "Register" button with credit cost confirmation
- Live player count updating in real-time

### Prize Showcase
- Glowing display cases for each prize card
- Jackpot cards pulse with gold neon glow
- "LIVE" badge on active tournaments
- Countdown timer to next freeroll

---

## House Economics

### Revenue Sources
1. **Cash game rake:** 5% of each pot (capped at 10 credits)
2. **Tournament rake:** 20% of entry fee pool
3. **Quick play edge:** ~15% house edge on AI games
4. **Credit purchases:** Players buy credits when they run low

### Prize Costs
- House donates cards from the prize vault to tournaments
- Cards are sourced from: seller donations (in exchange for credits/promotion), SCO purchases at wholesale, or community card donations
- Estimated prize cost per tournament: $50–$1,200 depending on tier

### Sustainability Model
At 100 players per day across all game types:
- Cash game rake: ~500 credits/day
- Tournament rake: ~1,000 credits/day
- Quick play edge: ~300 credits/day
- Total: ~1,800 credits/day recirculated to house
- Prize cost: 1 standard card/day (~50 credits equivalent)
- **Net positive for house at any meaningful volume**

---

## Responsible Gaming Features

- **Daily credit limit:** Players can set a daily spend limit
- **Session timer:** Optional reminder after 1 hour of play
- **Cool-down:** 24-hour lock-out option (self-exclusion)
- **Transparency:** All odds displayed clearly in Game Room
- **No real money:** Credits cannot be converted back to cash

---

## Build Phases

| Phase | Feature | Estimated Complexity |
|---|---|---|
| 1 | Game Room landing + Pack Rip + Spin Wheel | Medium |
| 2 | Quick Play poker vs. AI | Medium |
| 3 | Cash game tables (multiplayer WebSocket) | High |
| 4 | Sit & Go tournaments | High |
| 5 | Scheduled tournaments + bracket system | High |
| 6 | Freeroll daily automation | Medium |
| 7 | Admin tournament management | Medium |

---

## Open Questions for Owner

1. **Card sourcing for prizes:** Will you purchase cards for the vault, or rely on seller donations initially?
2. **Freeroll frequency:** Daily? Twice daily? Only weekends to start?
3. **Multiplayer launch:** Do you want to soft-launch with AI-only first, then add multiplayer?
4. **Tournament schedule:** Fixed times (e.g. 8pm EST daily) or rolling start when full?
5. **Credit pricing:** Should credits have a suggested dollar equivalent displayed (e.g. "100 credits ≈ $9.99") or stay purely virtual?

---

*Document prepared by SCO Development Team — April 2026*
