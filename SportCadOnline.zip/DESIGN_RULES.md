# CardVault / SportCardsOnline.com — Design Rules (LOCKED IN)

> **READ THIS FIRST** before making any UI or backend changes.
> Do not invent colors, options, or fields. Use only what is defined here.

---

## 1. Card Display — Slab Frame (THE RULE)

Every graded card is displayed as a **PSA-style slab**:
- One single border/frame — everything inside it
- **SCG label strip at the TOP** (replaces PSA label) — inside the frame
- **Card photo fills the bottom** — inside the same frame
- **Nothing outside the frame** — no player name text, no price, no badge overlapping the border

Component: `client/src/components/SlabFrame.tsx` (named export `{ SlabFrame }`)

### Label Background Options (labelBg)
| Value | Description |
|-------|-------------|
| `black-silk` | Black background, white text (DEFAULT) |
| `white-silk` | White background, black text |
| `red-silk` | Red background, white text |

### Border Color Options (labelBorder)
| Value | Hex |
|-------|-----|
| `red` | #c41e3a (DEFAULT) |
| `blue` | #1d4ed8 |
| `white` | #ffffff |
| `orange` | #f97316 |
| `black` | #333333 |

### Label Mode (labelMode)
| Value | Description |
|-------|-------------|
| `with_label` | Show SCG label strip at top (DEFAULT for graded cards) |
| `no_label` | Raw card — just the photo in the case, no label |

---

## 2. Card Schema — Key Fields (cards table)

```
id, title, playerName, year, manufacturer, cardNumber, setName
sport: baseball | basketball | football | hockey | soccer | other
condition: raw | graded
gradeCompany: PSA | Beckett | SGC | TGA | CGC | other | none
gradeScore, certNumber
frontImageUrl, backImageUrl
price, buyNowPrice
status: active | sold | draft | auction | traded | casino | bank
isMainStore: boolean  ← TRUE = our house card
labelColor: dark | ruby | light | silver | nightlife | red | black | none (legacy)
labelBg: black-silk | white-silk | red-silk  (NEW — use this)
labelBorder: red | blue | white | orange | black  (NEW — use this)
labelMode: with_label | no_label
aiGrade, aiGradeLabel, aiCentering, aiCorners, aiEdges, aiSurface, aiCertNumber
showSlabView: boolean
isVaulted: boolean
isDropship: boolean
category: rookie | vintage | modern | insert | parallel | autograph | memorabilia | other
source: manual | ebay_import | search_import
```

---

## 3. Collections Schema — Key Fields (collections table)

```
id, ownerEmail, cardTitle, playerName, year, setName, cardNumber
sport: baseball | basketball | football | hockey | soccer | other
frontImageUrl, backImageUrl
overallGrade, gradeLabel
centeringScore, cornersScore, edgesScore, surfaceScore
certNumber
labelBg: black-silk | white-silk | red-silk  (DEFAULT: black-silk)
labelBorder: red | blue | white | orange | black  (DEFAULT: red)
labelMode: with_label | no_label  (DEFAULT: with_label)
listingStatus: none | listed | auction | in_trade | in_sale | shipped | traded | sold | pending_gm | gs | gm_complete | vaulted | vault_listed | vault_auction | vault_sold | vault_shipped
```

---

## 4. Router Structure

Main router file: `server/routers.ts`
Sub-routers in: `server/routers/admin.ts`, `server/routers/affiliate.ts`, `server/routers/collection.ts`

Key procedures:
- `cards.list` — input: `{ limit?, sport?, category?, search? }` — public
- `cards.top50` — no input — public — returns 50 curated cards (60% house, 40% sourced)
- `cards.seasonalPicks` — no input — public — returns seasonal card picks by theme
- `cards.proRookies` — no input — public — returns rookie cards by sport
- `cards.housePicks` — input: `{ userId? }` — public — returns personalized house picks
- `sportsData.gamesToday` — no input — public — live ESPN game scores
- `sportsData.tickerNews` — no input — public — card releases + sports news

---

## 5. Color Palette (Site Theme)

From `client/src/index.css`:
- Background: `oklch(0.13 0.025 264)` — deep navy almost black
- Primary accent: red/crimson
- Secondary accent: gold

Do NOT use arbitrary hex colors in UI. Use Tailwind tokens or the defined CSS variables.

---

## 6. House Cards vs Sourced Cards

- **House cards**: `isMainStore = true` — our own inventory, shown with gold ★ HOUSE badge in grid view
- **Sourced cards**: `isMainStore = false` — eBay imports / dropship

---

## 7. Carousel Layout Rules

- **Top 50 section**: 2 scrollable rows, left/right arrow buttons
- **Each sub-category** (Seasonal Picks, Pro Rookies, House Picks): 1 scrollable row, left/right arrows
- Cards in carousel use `SlabFrame` at smaller size — same slab display, just scaled down
- No text, badges, or labels OUTSIDE the slab frame in carousel view

---

## 8. NOW OPEN Badge

- Positioned ABOVE the hero ad, outside the Link/ad border
- Significant spacing (mt-6 or more) between it and the ad border
- Uses the existing pulsing red badge style already in the codebase

---

## 9. General Rules

- **Never invent colors** — use only the defined labelBg / labelBorder / site palette
- **Never split the slab** — label and photo are always inside ONE border
- **Never put text outside the slab frame** in carousel/grid display
- **Always use named exports** from SlabFrame: `import { SlabFrame } from "@/components/SlabFrame"`
- **Ask before making style decisions** if not defined here
- **One change at a time** — show user result before proceeding
