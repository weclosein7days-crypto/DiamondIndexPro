# SportCardsOnline.com — Locked Decisions Log

> **RULE: Nothing in this file changes unless the user explicitly says so.**
> Every session must reference this file before touching any code.

---

## Site Purpose
Simple sports card marketplace. Cards are displayed, imported, sold, and deleted — but always saved in records for barcode/cert tracking. That's it.

---

## Layout — LOCKED

### Marketplace Grid
- **5 columns** (`grid-cols-5`)
- **Gap:** `gap-4` (16px between cards)
- Cards use `aspect-[2/3]` ratio — do NOT change the ratio
- Card info below slab: player name (xs), set/year (10px), price (sm bold red)
- Sidebar (Live Auctions) stays on the right — do NOT remove it

### Marketplace Sections
- **NO** curated sections (no TOP 50, no SEASONAL PICKS, no PRO ROOKIES, no HOUSE PICKS)
- One flat marketplace grid — all cards together
- Filters: All / Baseball / Basketball / Football / Hockey / Soccer / Other
- Sort: Price High→Low, Price Low→High, Newest First
- Grid view and List view toggle

---

## Colors — LOCKED

| Element | Value |
|---|---|
| Background | Dark navy `#0a1628` |
| Card background | `#0d1f3c` |
| Accent / CTA red | `#c41e3a` |
| Text primary | white |
| Text secondary | `white/50` |
| Border default | `white/10` |
| Border hover | `#c41e3a/60` |

---

## Card Slab (SlabFrame) — LOCKED

- Front: card image fills the slab frame with SCO GRADING label at top, grade badge, player name + set at bottom label
- Back label layout: SCO GRADING top-left, player name, barcode centered right, Date Printed, Est. Value toggle
- Label colors configurable per card (dark, light, custom)
- Do NOT add outer borders or extra wrappers around the slab in the grid

---

## Navigation — LOCKED

Top nav items (in order):
1. Marketplace
2. Grading
3. Game Room
4. My Account
5. Info
6. Card Values
7. Comps

---

## Pricing Rules — LOCKED

- **Minimum marketplace price: $10.00** — any card under $10 is NEVER shown in the marketplace
- **eBay import minimum: $10.00 source price** — cards listed under $10 on eBay are never imported, skipped immediately
- **Free shipping only** — only eBay cards with free shipping are imported. Any card with paid shipping is skipped, period.
- **20% markup** applied to all eBay-sourced cards at import time: `sourcePrice × 1.20 = listed price`
- Cards with $0.00 or NULL price are never shown
- DB query enforces minimum via `CAST(price AS DECIMAL(10,2)) >= 10.00` inside `getActiveCards()` in `server/db.ts`
- These rules apply to ALL cards (house and imported)

---

## Card Image Rules — LOCKED

- All cards must have a real front image (not the default placeholder)
- **Always use full-size eBay images: `s-l1600` only** — never store `s-l225` or `s-l500` thumbnails
- Import code in `server/ebayDropship.ts` replaces any thumbnail URL with `s-l1600` at import time
- If an eBay image URL breaks, fetch a fresh one from eBay by player name + set name
- If no image can be found, remove the card from the marketplace
- Scheduled job runs every 6 hours to check image URLs and eBay availability
- If an eBay listing is sold, remove the card from the marketplace
- At checkout, check eBay availability on every card before Stripe payment

---

## Label — LOCKED

- **Default label background: White Silk**
- **Default label border: Red**
- Users can choose label colors when listing a card
- Same color options available when printing

---

## What Changes (and ONLY these things)
- Which cards are displayed in the marketplace
- Card data: images, prices, grades, player info
- Importing new cards
- Selling / deleting cards (records kept for barcode history)
- Back label fix (next task)

---

## Change Log

| Date | Change | Status |
|---|---|---|
| 2026-04-05 | Marketplace grid set to 5 columns, gap-4 | LOCKED |
| 2026-04-05 | Removed all curated carousel sections | LOCKED |
| 2026-04-05 | Back label design agreed on (SCO GRADING, barcode, player name, cert, est. value) | IN PROGRESS |
| 2026-04-05 | eBay import: free shipping only — paid shipping cards skipped | LOCKED |
| 2026-04-05 | eBay import: $10 minimum source price — under $10 never imported | LOCKED |
| 2026-04-05 | eBay import: 20% markup at import time (sourcePrice × 1.20) | LOCKED |
| 2026-04-05 | DB query: getActiveCards enforces CAST(price) >= 10.00 | LOCKED |
| 2026-04-05 | All 746 eBay cards upgraded from s-l225 to s-l1600 (full size) | LOCKED |
| 2026-04-05 | Import code always stores s-l1600 full-size images going forward | LOCKED |
| 2026-04-05 | Deleted 6 eBay cards that were under $10 | DONE |


---

## Card Flow — THE RULE (LOCKED)

Every card — whether imported from eBay, uploaded manually, or submitted for grading — follows this exact flow:

1. Import / Upload / Grade Submission
2. **COLLECTION** — all cards land here first (single source of truth)
3. **Auto-listed to MARKETPLACE** (status = active) immediately on import
4. Admin can reassign status at any time: listed | auction | traded | shipping | bank | casino | draft | sold

- No card ever skips Collection
- Auto-list on import — cards go straight to status=active unless admin overrides

---

## Card Source Badges — LOCKED

Every card displays a source badge in the **bottom-right corner** of the slab:

| Badge | Color | Meaning |
|-------|-------|---------|
| H | Gold #f59e0b | House card — our own inventory (isMainStore=true) |
| E | Blue #3b82f6 | eBay-sourced / dropship card (isMainStore=false) |
| G | Purple #8b5cf6 | Graded through our grading service |
| U | Green #10b981 | User-uploaded / manually entered |

Badge: 18-20px pill/circle, bold white letter, bottom-right of slab. Never overlaps grade score.

---

## Card Status Banners — LOCKED

Non-active cards show a status banner overlay across the card image:

| Status | Banner Text | Color |
|--------|-------------|-------|
| auction | AUCTION | Orange #f97316 |
| traded | TRADE | Teal #14b8a6 |
| shipping | SHIPPING | Blue #3b82f6 |
| sold | SOLD | Red #ef4444 |
| bank | IN VAULT | Gold #f59e0b |
| casino | GAME ROOM | Purple #8b5cf6 |
| draft | DRAFT | Gray #6b7280 |
| active | (no banner) | — |

Banner: diagonal ribbon or horizontal strip, semi-transparent background, bold white all-caps text.

---

## PSA Compliance Rules — LOCKED

- NEVER claim we ship PSA-graded cards — PSA ships directly to buyer
- NEVER display PSA logo as if we are PSA — we are a reseller/marketplace
- NEVER imply PSA endorsement of our grading or marketplace
- Card images from eBay used under eBay marketplace license (link back via ebayListingUrl)
- Our grading label is SCO GRADING — never PSA — on slab frames
- Cert numbers are for buyer reference only — buyers verify at psacard.com
- No shipping claims in descriptions — eBay handles fulfillment for dropship cards
