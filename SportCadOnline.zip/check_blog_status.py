import json, sys, subprocess, urllib.request

url = "http://localhost:3000/api/trpc/blog.listPosts?input=%7B%22json%22%3A%7B%22limit%22%3A100%7D%7D"
with urllib.request.urlopen(url) as r:
    d = json.load(r)

posts = d['result']['data']['json']
print(f"Total blog posts: {len(posts)}")
no_video = []
no_youtube = []
uploaded = []

for p in posts:
    vid = p.get('videoUrl')
    ytid = p.get('youtubeVideoId')
    tags = p.get('youtubeAutoTags')
    title = str(p.get('title',''))[:60]
    pid = p.get('id')
    status = p.get('status')
    
    if not vid:
        no_video.append((pid, title, status))
    elif not ytid:
        no_youtube.append((pid, title, status, vid[:60], 'YES' if tags else 'NO'))
    else:
        uploaded.append((pid, title, ytid))

print(f"\n=== UPLOADED TO YOUTUBE ({len(uploaded)}) ===")
for x in uploaded:
    print(f"  [{x[0]}] {x[1]} -> https://youtube.com/watch?v={x[2]}")

print(f"\n=== HAS VIDEO BUT NOT ON YOUTUBE ({len(no_youtube)}) ===")
for x in no_youtube:
    print(f"  [{x[0]}] {x[1]} | status={x[2]} | tags={x[4]}")
    print(f"       video: {x[3]}")

print(f"\n=== NO VIDEO GENERATED ({len(no_video)}) ===")
for x in no_video:
    print(f"  [{x[0]}] {x[1]} | status={x[2]}")
