import { useState, useEffect } from "react";

/**
 * Returns a live countdown string (HH:MM:SS) to the next daily Freeroll
 * tournament, which fires every day at 8:00 PM Eastern Time.
 */
export function useFreerollCountdown(): { countdown: string; isLive: boolean } {
  const getNext8pmEST = () => {
    const now = new Date();
    // Build today's 8pm in EST (UTC-5) / EDT (UTC-4)
    // We use the Intl API to figure out the current offset for America/New_York
    const nyNow = new Date(now.toLocaleString("en-US", { timeZone: "America/New_York" }));
    const target = new Date(nyNow);
    target.setHours(20, 0, 0, 0); // 8:00:00 PM
    // If 8pm has already passed today, aim for tomorrow
    if (nyNow >= target) {
      target.setDate(target.getDate() + 1);
    }
    // Convert back to UTC ms by computing the offset
    const offsetMs = now.getTime() - nyNow.getTime();
    return target.getTime() + offsetMs;
  };

  const [targetMs, setTargetMs] = useState(() => getNext8pmEST());
  const [remaining, setRemaining] = useState(0);

  useEffect(() => {
    const tick = () => {
      const diff = targetMs - Date.now();
      if (diff <= 0) {
        // Tournament just started — reset to next day
        const next = getNext8pmEST();
        setTargetMs(next);
        setRemaining(next - Date.now());
      } else {
        setRemaining(diff);
      }
    };
    tick();
    const id = setInterval(tick, 1000);
    return () => clearInterval(id);
  }, [targetMs]);

  const isLive = remaining <= 0;

  const h = Math.floor(remaining / 3_600_000);
  const m = Math.floor((remaining % 3_600_000) / 60_000);
  const s = Math.floor((remaining % 60_000) / 1_000);
  const pad = (n: number) => String(n).padStart(2, "0");
  const countdown = isLive ? "LIVE NOW" : `${pad(h)}:${pad(m)}:${pad(s)}`;

  return { countdown, isLive };
}
