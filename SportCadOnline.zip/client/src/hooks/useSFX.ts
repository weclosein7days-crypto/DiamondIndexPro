/**
 * useSFX — Shared Web Audio API sound engine for Kids Corner games.
 *
 * All sounds are synthesized in-browser (no audio files needed).
 * The AudioContext is lazily created on first user interaction to comply
 * with browser autoplay policies.
 *
 * Usage:
 *   const sfx = useSFX();
 *   sfx.deal();        // card dealt
 *   sfx.coinFlip();    // coin spinning
 *   sfx.coinLand();    // coin landing
 *   sfx.cheer();       // win fanfare
 *   sfx.groan();       // lose sound
 *   sfx.beep(freq)     // countdown beep
 *   sfx.whoosh()       // throw/reveal whoosh
 *   sfx.tick()         // spin wheel tick
 *   sfx.spinStart()    // wheel starts spinning
 *   sfx.spinStop()     // wheel stops
 *   sfx.book()         // Go Fish book collected
 *   sfx.goFish()       // Go Fish! call
 *   sfx.cardFlip()     // card flip (War)
 *   sfx.war()          // WAR! dramatic sting
 *   sfx.warWin()       // win a war pile
 *   sfx.levelUp()      // level up fanfare
 *   sfx.creditEarned() // credit coin clink
 */
import { useRef, useCallback } from "react";

type OscType = OscillatorType;

export function useSFX() {
  const ctxRef = useRef<AudioContext | null>(null);

  const ac = useCallback((): AudioContext => {
    if (!ctxRef.current) {
      ctxRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
    }
    if (ctxRef.current.state === "suspended") {
      ctxRef.current.resume();
    }
    return ctxRef.current;
  }, []);

  /** Low-level: play a single oscillator tone */
  const tone = useCallback((
    freq: number,
    dur: number,
    type: OscType = "sine",
    vol = 0.18,
    startOffset = 0,
    freqEnd?: number,
  ) => {
    try {
      const ctx = ac();
      const o = ctx.createOscillator();
      const g = ctx.createGain();
      o.connect(g);
      g.connect(ctx.destination);
      o.type = type;
      const t = ctx.currentTime + startOffset;
      o.frequency.setValueAtTime(freq, t);
      if (freqEnd !== undefined) {
        o.frequency.exponentialRampToValueAtTime(freqEnd, t + dur);
      }
      g.gain.setValueAtTime(vol, t);
      g.gain.exponentialRampToValueAtTime(0.001, t + dur);
      o.start(t);
      o.stop(t + dur + 0.01);
    } catch { /* ignore AudioContext errors */ }
  }, [ac]);

  /** Low-level: play white/pink noise burst */
  const noise = useCallback((dur: number, vol = 0.3, lowpass = 800, startOffset = 0) => {
    try {
      const ctx = ac();
      const buf = ctx.createBuffer(1, Math.ceil(ctx.sampleRate * dur), ctx.sampleRate);
      const d = buf.getChannelData(0);
      for (let i = 0; i < d.length; i++) {
        d[i] = (Math.random() * 2 - 1) * Math.exp(-i / (ctx.sampleRate * dur * 0.6));
      }
      const src = ctx.createBufferSource();
      src.buffer = buf;
      const f = ctx.createBiquadFilter();
      f.type = "lowpass";
      f.frequency.value = lowpass;
      const g = ctx.createGain();
      const t = ctx.currentTime + startOffset;
      g.gain.setValueAtTime(vol, t);
      g.gain.exponentialRampToValueAtTime(0.001, t + dur);
      src.connect(f);
      f.connect(g);
      g.connect(ctx.destination);
      src.start(t);
      src.stop(t + dur + 0.01);
    } catch { /* ignore */ }
  }, [ac]);

  // ── Card sounds ─────────────────────────────────────────────────────────────

  /** Single card dealt — quick triangle tap */
  const deal = useCallback(() => {
    tone(600, 0.06, "triangle", 0.12);
    noise(0.04, 0.08, 1200);
  }, [tone, noise]);

  /** Card flip (War game) — swoosh + tap */
  const cardFlip = useCallback(() => {
    tone(400, 0.12, "triangle", 0.15, 0, 800);
    noise(0.06, 0.1, 600);
  }, [tone, noise]);

  // ── Coin sounds ─────────────────────────────────────────────────────────────

  /** Coin spinning in air — rising shimmer */
  const coinFlip = useCallback(() => {
    [880, 1100, 1320, 1100, 880].forEach((f, i) => {
      tone(f, 0.1, "sine", 0.15, i * 0.07);
    });
  }, [tone]);

  /** Coin landing on table — metallic clink */
  const coinLand = useCallback(() => {
    tone(1200, 0.04, "sine", 0.3);
    tone(900, 0.08, "sine", 0.2, 0.03);
    tone(600, 0.15, "sine", 0.1, 0.06);
    noise(0.05, 0.12, 2000);
  }, [tone, noise]);

  /** Credit earned — cheerful coin clink */
  const creditEarned = useCallback(() => {
    tone(880, 0.08, "sine", 0.25);
    tone(1320, 0.12, "sine", 0.2, 0.06);
    tone(1760, 0.15, "sine", 0.15, 0.12);
  }, [tone]);

  // ── Win / Lose ──────────────────────────────────────────────────────────────

  /** Victory cheer — ascending fanfare */
  const cheer = useCallback(() => {
    const notes = [523, 659, 784, 1047, 1319, 1568];
    notes.forEach((f, i) => tone(f, 0.22, "triangle", 0.22, i * 0.1));
    // Add a harmony layer
    const harmony = [659, 784, 988, 1319, 1568, 1976];
    harmony.forEach((f, i) => tone(f, 0.18, "sine", 0.1, i * 0.1 + 0.05));
  }, [tone]);

  /** Lose groan — descending wah */
  const groan = useCallback(() => {
    tone(400, 0.5, "sawtooth", 0.15, 0, 180);
    tone(300, 0.4, "sine", 0.1, 0.1, 150);
  }, [tone]);

  // ── Go Fish ─────────────────────────────────────────────────────────────────

  /** Book collected — ascending arpeggio */
  const book = useCallback(() => {
    [523, 659, 784, 1047, 1319].forEach((f, i) =>
      tone(f, 0.18, "triangle", 0.22, i * 0.09)
    );
  }, [tone]);

  /** Go Fish! call — descending plop */
  const goFish = useCallback(() => {
    tone(350, 0.18, "sine", 0.2);
    tone(250, 0.28, "sine", 0.15, 0.15);
    noise(0.08, 0.06, 400, 0.3);
  }, [tone, noise]);

  // ── Spin Wheel ──────────────────────────────────────────────────────────────

  /** Single tick as wheel passes a segment */
  const tick = useCallback(() => {
    tone(1200, 0.03, "square", 0.08);
  }, [tone]);

  /** Wheel starts spinning — rising whoosh */
  const spinStart = useCallback(() => {
    tone(200, 0.4, "sawtooth", 0.12, 0, 800);
    noise(0.3, 0.08, 1500);
  }, [tone, noise]);

  /** Wheel slows to stop — descending rattle */
  const spinStop = useCallback(() => {
    tone(600, 0.3, "triangle", 0.15, 0, 200);
    noise(0.2, 0.1, 600);
  }, [tone, noise]);

  // ── Rock Paper Scissors ──────────────────────────────────────────────────────

  /** Countdown beep — crisp sine */
  const beep = useCallback((freq = 440) => {
    tone(freq, 0.12, "sine", 0.2);
  }, [tone]);

  /** Throw whoosh — quick air burst */
  const whoosh = useCallback(() => {
    tone(800, 0.15, "sawtooth", 0.12, 0, 200);
    noise(0.12, 0.15, 1000);
  }, [tone, noise]);

  // ── War / GameTime ──────────────────────────────────────────────────────────

  /** WAR! dramatic sting — low brass hit */
  const war = useCallback(() => {
    tone(110, 0.5, "sawtooth", 0.3);
    tone(138, 0.4, "sawtooth", 0.2, 0.05);
    tone(165, 0.3, "sawtooth", 0.15, 0.1);
    noise(0.15, 0.2, 300);
  }, [tone, noise]);

  /** Win a war pile — triumphant sting */
  const warWin = useCallback(() => {
    [392, 523, 659, 784].forEach((f, i) => tone(f, 0.2, "square", 0.18, i * 0.08));
  }, [tone]);

  // ── Level Up ────────────────────────────────────────────────────────────────

  /** Level up — full 8-bit style fanfare */
  const levelUp = useCallback(() => {
    const melody = [523, 659, 784, 1047, 784, 1047, 1319, 1568];
    melody.forEach((f, i) => tone(f, 0.18, "square", 0.2, i * 0.1));
    // Bass line
    [131, 165, 196, 262].forEach((f, i) => tone(f, 0.18, "sawtooth", 0.1, i * 0.2));
  }, [tone]);

  return {
    deal,
    cardFlip,
    coinFlip,
    coinLand,
    creditEarned,
    cheer,
    groan,
    book,
    goFish,
    tick,
    spinStart,
    spinStop,
    beep,
    whoosh,
    war,
    warWin,
    levelUp,
  };
}
