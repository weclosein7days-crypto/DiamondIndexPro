import { useCallback, useRef } from "react";

/**
 * Shared casino game audio hook using Web Audio API.
 * All sounds are synthesized — no external files needed.
 */
export function useGameAudio() {
  const ctxRef = useRef<AudioContext | null>(null);

  function getCtx(): AudioContext {
    if (!ctxRef.current || ctxRef.current.state === "closed") {
      ctxRef.current = new AudioContext();
    }
    if (ctxRef.current.state === "suspended") {
      ctxRef.current.resume();
    }
    return ctxRef.current;
  }

  /** Card deal swoosh — short filtered noise burst */
  const playDeal = useCallback(() => {
    try {
      const ctx = getCtx();
      const t = ctx.currentTime;
      const buf = ctx.createBuffer(1, ctx.sampleRate * 0.12, ctx.sampleRate);
      const data = buf.getChannelData(0);
      for (let i = 0; i < data.length; i++) data[i] = (Math.random() * 2 - 1) * (1 - i / data.length);
      const src = ctx.createBufferSource();
      src.buffer = buf;
      const filter = ctx.createBiquadFilter();
      filter.type = "bandpass";
      filter.frequency.setValueAtTime(3000, t);
      filter.frequency.exponentialRampToValueAtTime(800, t + 0.12);
      filter.Q.value = 1.5;
      const gain = ctx.createGain();
      gain.gain.setValueAtTime(0.35, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.12);
      src.connect(filter);
      filter.connect(gain);
      gain.connect(ctx.destination);
      src.start(t);
    } catch (_) {}
  }, []);

  /** Chip click — short percussive tick */
  const playChip = useCallback(() => {
    try {
      const ctx = getCtx();
      const t = ctx.currentTime;
      // Noise burst
      const buf = ctx.createBuffer(1, ctx.sampleRate * 0.04, ctx.sampleRate);
      const data = buf.getChannelData(0);
      for (let i = 0; i < data.length; i++) data[i] = (Math.random() * 2 - 1) * (1 - i / data.length);
      const src = ctx.createBufferSource();
      src.buffer = buf;
      const filter = ctx.createBiquadFilter();
      filter.type = "highpass";
      filter.frequency.value = 2000;
      const gain = ctx.createGain();
      gain.gain.setValueAtTime(0.4, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.04);
      // Tone click
      const osc = ctx.createOscillator();
      osc.type = "sine";
      osc.frequency.setValueAtTime(900, t);
      osc.frequency.exponentialRampToValueAtTime(400, t + 0.04);
      const oscGain = ctx.createGain();
      oscGain.gain.setValueAtTime(0.25, t);
      oscGain.gain.exponentialRampToValueAtTime(0.001, t + 0.04);
      src.connect(filter);
      filter.connect(gain);
      gain.connect(ctx.destination);
      osc.connect(oscGain);
      oscGain.connect(ctx.destination);
      src.start(t);
      osc.start(t);
      osc.stop(t + 0.04);
    } catch (_) {}
  }, []);

  /** Bet raise — two ascending chip clicks */
  const playRaise = useCallback(() => {
    try {
      const ctx = getCtx();
      const t = ctx.currentTime;
      [0, 0.08].forEach((delay, i) => {
        const osc = ctx.createOscillator();
        osc.type = "sine";
        osc.frequency.setValueAtTime(700 + i * 200, t + delay);
        osc.frequency.exponentialRampToValueAtTime(300 + i * 100, t + delay + 0.05);
        const gain = ctx.createGain();
        gain.gain.setValueAtTime(0.3, t + delay);
        gain.gain.exponentialRampToValueAtTime(0.001, t + delay + 0.05);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(t + delay);
        osc.stop(t + delay + 0.05);
      });
    } catch (_) {}
  }, []);

  /** Fold — descending card flutter */
  const playFold = useCallback(() => {
    try {
      const ctx = getCtx();
      const t = ctx.currentTime;
      const buf = ctx.createBuffer(1, ctx.sampleRate * 0.18, ctx.sampleRate);
      const data = buf.getChannelData(0);
      for (let i = 0; i < data.length; i++) {
        const env = Math.pow(1 - i / data.length, 2);
        data[i] = (Math.random() * 2 - 1) * env * 0.6;
      }
      const src = ctx.createBufferSource();
      src.buffer = buf;
      const filter = ctx.createBiquadFilter();
      filter.type = "bandpass";
      filter.frequency.setValueAtTime(1800, t);
      filter.frequency.exponentialRampToValueAtTime(400, t + 0.18);
      filter.Q.value = 2;
      const gain = ctx.createGain();
      gain.gain.setValueAtTime(0.3, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.18);
      src.connect(filter);
      filter.connect(gain);
      gain.connect(ctx.destination);
      src.start(t);
    } catch (_) {}
  }, []);

  /** Win fanfare — ascending chord + bell */
  const playWin = useCallback(() => {
    try {
      const ctx = getCtx();
      const t = ctx.currentTime;
      // Ascending arpeggio: C4 E4 G4 C5
      const notes = [261.63, 329.63, 392.0, 523.25];
      notes.forEach((freq, i) => {
        const osc = ctx.createOscillator();
        osc.type = "sine";
        osc.frequency.value = freq;
        const gain = ctx.createGain();
        gain.gain.setValueAtTime(0, t + i * 0.1);
        gain.gain.linearRampToValueAtTime(0.22, t + i * 0.1 + 0.05);
        gain.gain.exponentialRampToValueAtTime(0.001, t + i * 0.1 + 0.5);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(t + i * 0.1);
        osc.stop(t + i * 0.1 + 0.5);
      });
      // Bell sustain at C5
      setTimeout(() => {
        try {
          const ctx2 = getCtx();
          const t2 = ctx2.currentTime;
          const bell = ctx2.createOscillator();
          bell.type = "sine";
          bell.frequency.value = 1046.5;
          const bellGain = ctx2.createGain();
          bellGain.gain.setValueAtTime(0.18, t2);
          bellGain.gain.exponentialRampToValueAtTime(0.001, t2 + 1.2);
          bell.connect(bellGain);
          bellGain.connect(ctx2.destination);
          bell.start(t2);
          bell.stop(t2 + 1.2);
        } catch (_) {}
      }, 400);
    } catch (_) {}
  }, []);

  /** Blackjack natural — special 3:2 win sound */
  const playBlackjack = useCallback(() => {
    try {
      const ctx = getCtx();
      const t = ctx.currentTime;
      // Quick ascending scale C4 E4 G4 B4 D5 + shimmer
      const notes = [261.63, 329.63, 392.0, 493.88, 587.33];
      notes.forEach((freq, i) => {
        const osc = ctx.createOscillator();
        osc.type = i % 2 === 0 ? "sine" : "triangle";
        osc.frequency.value = freq;
        const gain = ctx.createGain();
        gain.gain.setValueAtTime(0, t + i * 0.07);
        gain.gain.linearRampToValueAtTime(0.2, t + i * 0.07 + 0.04);
        gain.gain.exponentialRampToValueAtTime(0.001, t + i * 0.07 + 0.6);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(t + i * 0.07);
        osc.stop(t + i * 0.07 + 0.6);
      });
    } catch (_) {}
  }, []);

  /** Bust / loss — descending trombone slide */
  const playLose = useCallback(() => {
    try {
      const ctx = getCtx();
      const t = ctx.currentTime;
      const osc = ctx.createOscillator();
      osc.type = "sawtooth";
      osc.frequency.setValueAtTime(350, t);
      osc.frequency.exponentialRampToValueAtTime(120, t + 0.5);
      const gain = ctx.createGain();
      gain.gain.setValueAtTime(0.18, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.5);
      const filter = ctx.createBiquadFilter();
      filter.type = "lowpass";
      filter.frequency.setValueAtTime(800, t);
      filter.frequency.exponentialRampToValueAtTime(200, t + 0.5);
      osc.connect(filter);
      filter.connect(gain);
      gain.connect(ctx.destination);
      osc.start(t);
      osc.stop(t + 0.5);
    } catch (_) {}
  }, []);

  /** Push / tie — neutral two-tone chime */
  const playPush = useCallback(() => {
    try {
      const ctx = getCtx();
      const t = ctx.currentTime;
      [440, 550].forEach((freq, i) => {
        const osc = ctx.createOscillator();
        osc.type = "sine";
        osc.frequency.value = freq;
        const gain = ctx.createGain();
        gain.gain.setValueAtTime(0.15, t + i * 0.12);
        gain.gain.exponentialRampToValueAtTime(0.001, t + i * 0.12 + 0.4);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(t + i * 0.12);
        osc.stop(t + i * 0.12 + 0.4);
      });
    } catch (_) {}
  }, []);

  /** Check — soft single tap */
  const playCheck = useCallback(() => {
    try {
      const ctx = getCtx();
      const t = ctx.currentTime;
      const osc = ctx.createOscillator();
      osc.type = "sine";
      osc.frequency.setValueAtTime(600, t);
      osc.frequency.exponentialRampToValueAtTime(350, t + 0.06);
      const gain = ctx.createGain();
      gain.gain.setValueAtTime(0.12, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.06);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(t);
      osc.stop(t + 0.06);
    } catch (_) {}
  }, []);

  /** Pot win — coins cascading */
  const playPotWin = useCallback(() => {
    try {
      const ctx = getCtx();
      const t = ctx.currentTime;
      // 8 coin clinks at random pitches
      for (let i = 0; i < 8; i++) {
        const delay = i * 0.06 + Math.random() * 0.03;
        const freq = 800 + Math.random() * 600;
        const osc = ctx.createOscillator();
        osc.type = "sine";
        osc.frequency.setValueAtTime(freq, t + delay);
        osc.frequency.exponentialRampToValueAtTime(freq * 0.5, t + delay + 0.15);
        const gain = ctx.createGain();
        gain.gain.setValueAtTime(0.15, t + delay);
        gain.gain.exponentialRampToValueAtTime(0.001, t + delay + 0.2);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(t + delay);
        osc.stop(t + delay + 0.2);
      }
    } catch (_) {}
  }, []);

  return {
    playDeal,
    playChip,
    playRaise,
    playFold,
    playWin,
    playBlackjack,
    playLose,
    playPush,
    playCheck,
    playPotWin,
  };
}
