import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

/**
 * Proxy external image URLs that may block hotlinking (e.g., eBay images).
 * Returns the original URL for CDN-hosted images.
 *
 * eBay upscaling: replaces the size suffix (e.g. s-l140, s-l300, s-l500)
 * with s-l1600 so the browser always receives the highest-resolution version
 * available on eBay's CDN, then downscales it cleanly instead of upscaling
 * a tiny thumbnail.
 */
export function proxyImageUrl(url: string | null | undefined): string | null {
  if (!url) return null;
  // Avoid double-proxying if already proxied
  if (url.includes("/api/img-proxy")) return url;
  if (url.includes("ebayimg.com") || url.includes("thumbs.ebaystatic.com")) {
    // Upscale to full resolution before proxying
    const upscaled = url.replace(/s-l\d+(\.(jpg|jpeg|png|webp))/i, "s-l1600$1");
    return "/api/img-proxy?url=" + encodeURIComponent(upscaled);
  }
  return url;
}
