/**
 * SCO Game Room — Economy Constants & Helpers
 *
 * Credit ↔ Token conversion:
 *   1 credit  = 100 tokens  (tokens are the in-game chip unit)
 *   1 token   = $0.01 face value
 *
 * House games (poker vs AI, spin, pack rip):
 *   - Wager range: 0.5 tokens – 500 tokens per hand/spin  (= $0.005 – $5.00)
 *   - Max payout = wager × HOUSE_MAX_MULTIPLIER  (no runaway wins on small bets)
 *   - House edge: ~5% rake on every resolved hand
 */

// ─── Conversion ───────────────────────────────────────────────────────────────
export const TOKENS_PER_CREDIT = 100;

export function creditsToTokens(credits: number): number {
  return Math.floor(credits * TOKENS_PER_CREDIT);
}

export function tokensToCredits(tokens: number): number {
  return tokens / TOKENS_PER_CREDIT;
}

/** Format tokens as a dollar-like display string (e.g. 50 → "$0.50") */
export function formatTokens(tokens: number): string {
  const dollars = tokens / TOKENS_PER_CREDIT;
  if (dollars < 0.01) return `${tokens}t`;
  return `$${dollars.toFixed(dollars < 1 ? 2 : dollars < 10 ? 2 : 0)}`;
}

// ─── Cash Game Wager Tiers ────────────────────────────────────────────────────
/** Selectable bet sizes in tokens (shown as dollar amounts to the player) */
export const WAGER_TIERS = [
  { tokens: 0.5,  label: "½¢",  blinds: { small: 0.25, big: 0.5  } },
  { tokens: 1,    label: "1¢",  blinds: { small: 0.5,  big: 1    } },
  { tokens: 5,    label: "5¢",  blinds: { small: 2.5,  big: 5    } },
  { tokens: 10,   label: "10¢", blinds: { small: 5,    big: 10   } },
  { tokens: 25,   label: "25¢", blinds: { small: 12.5, big: 25   } },
  { tokens: 50,   label: "50¢", blinds: { small: 25,   big: 50   } },
  { tokens: 100,  label: "$1",  blinds: { small: 50,   big: 100  } },
  { tokens: 500,  label: "$5",  blinds: { small: 250,  big: 500  } },
] as const;

/** House edge: 5% rake taken from every resolved pot */
export const HOUSE_EDGE_PCT = 0.05;

/**
 * Maximum payout multiplier for house games (spin, pack rip).
 * A player betting X tokens can win at most X × HOUSE_MAX_MULTIPLIER tokens back.
 * This prevents a 0.5-token bet from winning 10,000 tokens.
 */
export const HOUSE_MAX_MULTIPLIER = 2.0;

/**
 * Apply house rake to a pot and return the player-facing net pot.
 * Returns { netPot, rake }
 */
export function applyRake(grossPot: number): { netPot: number; rake: number } {
  const rake = Math.ceil(grossPot * HOUSE_EDGE_PCT);
  return { netPot: grossPot - rake, rake };
}

/**
 * Cap a spin/pack-rip payout so it never exceeds wager × HOUSE_MAX_MULTIPLIER.
 */
export function capPayout(wager: number, rawPayout: number): number {
  return Math.min(rawPayout, Math.floor(wager * HOUSE_MAX_MULTIPLIER));
}

// ─── Tournament Configurations ────────────────────────────────────────────────
export type PayoutStructure = "winner-take-all" | "top2" | "top3";

export interface TournamentConfig {
  id: string;
  name: string;
  buyInCredits: number;       // credits charged to enter
  startingChips: number;      // tokens each player starts with
  maxSeats: number;
  minSeats: number;           // starts when this many register
  payoutStructure: PayoutStructure;
  /** Percentage of prize pool to each place (must sum to 1) */
  payouts: number[];
  /** Prize type: card from vault or credits */
  prizeType: "card" | "credits" | "mixed";
  /** A/B variant label for analytics */
  variant?: string;
}

export interface TournamentConfig {
  id: string;
  name: string;
  buyInCredits: number;
  startingChips: number;
  maxSeats: number;
  minSeats: number;
  payoutStructure: PayoutStructure;
  payouts: number[];
  prizeType: "card" | "credits" | "mixed";
  /** Prize pool = buyIn × seats × PRIZE_MULTIPLIER */
  prizeMultiplier: number;
  /** Minutes until final table is forced */
  finalTableMinutes: number;
  variant?: string;
}

/** Prize pool = buy-in × seats × 5 (house contributes to make it 5x) */
export const PRIZE_MULTIPLIER = 5;

export const TOURNAMENT_CONFIGS: TournamentConfig[] = [
  // ── $1 Buy-In (runs all day, every 30 min) ─────────────────────────────────
  {
    id: "t1-wta",
    name: "$1 Shootout — Winner Take All",
    buyInCredits: 1,
    startingChips: 500,
    maxSeats: 6,
    minSeats: 2,
    payoutStructure: "winner-take-all",
    payouts: [1.0],
    prizeType: "credits",
    prizeMultiplier: PRIZE_MULTIPLIER,
    finalTableMinutes: 20,
    variant: "A",
  },
  // ── $2 Buy-In ──────────────────────────────────────────────────────────────
  {
    id: "t2-top2",
    name: "$2 Turbo — Top 2 Pay",
    buyInCredits: 2,
    startingChips: 750,
    maxSeats: 6,
    minSeats: 2,
    payoutStructure: "top2",
    payouts: [0.65, 0.35],
    prizeType: "credits",
    prizeMultiplier: PRIZE_MULTIPLIER,
    finalTableMinutes: 20,
    variant: "A",
  },
  // ── $5 Buy-In ──────────────────────────────────────────────────────────────
  {
    id: "t5-top3",
    name: "$5 Classic — Top 3 Pay",
    buyInCredits: 5,
    startingChips: 1000,
    maxSeats: 6,
    minSeats: 3,
    payoutStructure: "top3",
    payouts: [0.50, 0.30, 0.20],
    prizeType: "credits",
    prizeMultiplier: PRIZE_MULTIPLIER,
    finalTableMinutes: 20,
    variant: "A",
  },
  // ── $10 Buy-In ─────────────────────────────────────────────────────────────
  {
    id: "t10-top3",
    name: "$10 Championship — Top 3 Pay",
    buyInCredits: 10,
    startingChips: 1500,
    maxSeats: 8,
    minSeats: 3,
    payoutStructure: "top3",
    payouts: [0.50, 0.30, 0.20],
    prizeType: "mixed",
    prizeMultiplier: PRIZE_MULTIPLIER,
    finalTableMinutes: 20,
    variant: "A",
  },
  // ── $20 Buy-In — Card Prize ────────────────────────────────────────────────
  {
    id: "t20-card",
    name: "$20 High Roller — Card Prize",
    buyInCredits: 20,
    startingChips: 2000,
    maxSeats: 8,
    minSeats: 4,
    payoutStructure: "top3",
    payouts: [0.60, 0.25, 0.15],
    prizeType: "card",
    prizeMultiplier: PRIZE_MULTIPLIER,
    finalTableMinutes: 20,
    variant: "A",
  },
];

/**
 * Calculate prize pool and per-place payouts for a tournament.
 * @param config  Tournament configuration
 * @param seats   Number of players who registered
 * @returns       { prizePool, places: [{ place, credits }] }
 */
export function calcTournamentPrizes(
  config: TournamentConfig,
  seats: number,
): { prizePool: number; houseCut: number; places: { place: number; credits: number }[] } {
  // Prize pool = buy-in × seats × 5x multiplier (house subsidizes the prize)
  const multiplier = (config as { prizeMultiplier?: number }).prizeMultiplier ?? 5;
  const gross = config.buyInCredits * seats * multiplier;
  const houseCut = Math.ceil(config.buyInCredits * seats * HOUSE_EDGE_PCT); // house takes 5% of actual buy-ins only
  const prizePool = gross - houseCut;
  const places = config.payouts.map((pct, i) => ({
    place: i + 1,
    credits: Math.floor(prizePool * pct),
  }));
  return { prizePool, houseCut, places };
}

// ─── Game Popularity Score ────────────────────────────────────────────────────
/**
 * Compute a popularity score for a game given its play stats.
 * Score = totalPlays × recencyWeight × avgSessionMinutes
 * recencyWeight decays by half every 7 days.
 */
export function gamePopularityScore(
  totalPlays: number,
  lastPlayedAt: Date,
  avgSessionMinutes: number,
): number {
  const ageMs = Date.now() - lastPlayedAt.getTime();
  const ageDays = ageMs / (1000 * 60 * 60 * 24);
  const recencyWeight = Math.pow(0.5, ageDays / 7); // half-life 7 days
  return totalPlays * recencyWeight * Math.max(avgSessionMinutes, 1);
}

// ─── Pack Rip Jackpot Prizes ────────────────────────────────────────────────
/**
 * Physical card jackpots — shipped to winner after $2.50 shipping fee.
 * Odds scale with pack tier (Option B: sliding odds).
 */
export const JACKPOT_PRIZES = {
  mega: {
    id: "mega",
    name: "Caitlin Clark Elements Card",
    description: "2024 Panini Elements Caitlin Clark RC — Physical Card Shipped",
    estimatedValue: 250,
    emoji: "👑",
    color: "#FFD700",
    /** Odds by pack tier: standard / premium / elite */
    odds: { standard: 0.0005, premium: 0.002, elite: 0.005 }, // 0.05% / 0.2% / 0.5%
  },
  mini: {
    id: "mini",
    name: "Cooper Flagg Rookie PSA 10",
    description: "2024-25 Hoops Cooper Flagg RC PSA 10 — Physical Card Shipped",
    estimatedValue: 120,
    emoji: "🏆",
    color: "#C0C0C0",
    /** Odds by pack tier: standard / premium / elite */
    odds: { standard: 0.001, premium: 0.005, elite: 0.01 }, // 0.1% / 0.5% / 1%
  },
} as const;

export type JackpotTier = "standard" | "premium" | "elite";

/**
 * Pack rip outcome tiers with house-edge odds.
 * Expected return per credit spent ≈ 0.64  (36% house edge).
 *
 * Tier thresholds (cumulative, roll 0–1):
 *   mega jackpot  → 0 – megaOdds
 *   mini jackpot  → megaOdds – megaOdds+miniOdds
 *   rare          → next 2.5%
 *   uncommon      → next 12%
 *   common        → remainder
 */
export interface PackOutcome {
  tier: "mega_jackpot" | "mini_jackpot" | "rare" | "uncommon" | "common";
  /** Credits awarded (0 for physical card jackpots — prize is the card) */
  creditsWon: number;
  /** Multiplier of the bet that was returned */
  multiplier: number;
  label: string;
  jackpotPrize?: typeof JACKPOT_PRIZES["mega"] | typeof JACKPOT_PRIZES["mini"];
}

/**
 * Resolve a pack rip outcome.
 * @param betCredits  Credits wagered (5 = standard, 15 = premium, 35 = elite)
 * @returns PackOutcome
 */
export function resolvePackRip(betCredits: number): PackOutcome {
  const tier: JackpotTier =
    betCredits >= 35 ? "elite" :
    betCredits >= 15 ? "premium" : "standard";

  const megaOdds = JACKPOT_PRIZES.mega.odds[tier];
  const miniOdds = JACKPOT_PRIZES.mini.odds[tier];

  const roll = Math.random();

  // Mega jackpot
  if (roll < megaOdds) {
    return {
      tier: "mega_jackpot",
      creditsWon: 0,
      multiplier: 0,
      label: `🎉 MEGA JACKPOT! ${JACKPOT_PRIZES.mega.name}`,
      jackpotPrize: JACKPOT_PRIZES.mega,
    };
  }

  // Mini jackpot
  if (roll < megaOdds + miniOdds) {
    return {
      tier: "mini_jackpot",
      creditsWon: 0,
      multiplier: 0,
      label: `🏆 MINI JACKPOT! ${JACKPOT_PRIZES.mini.name}`,
      jackpotPrize: JACKPOT_PRIZES.mini,
    };
  }

  // Rare (2.5%) — 1.6× to 1.9× return
  if (roll < megaOdds + miniOdds + 0.025) {
    const mult = 1.6 + Math.random() * 0.3;
    const won = Math.floor(betCredits * mult);
    return { tier: "rare", creditsWon: won, multiplier: mult, label: `⭐ Rare Pull! +${won} credits` };
  }

  // Uncommon (12%) — 0.8× to 1.2× return (near break-even)
  if (roll < megaOdds + miniOdds + 0.025 + 0.12) {
    const mult = 0.8 + Math.random() * 0.4;
    const won = Math.floor(betCredits * mult);
    return { tier: "uncommon", creditsWon: won, multiplier: mult, label: `✨ Nice Pull! +${won} credits` };
  }

  // Common (remainder ~85%) — 0.1× to 0.5× return (house wins)
  const mult = 0.1 + Math.random() * 0.4;
  const won = Math.max(0, Math.floor(betCredits * mult));
  return { tier: "common", creditsWon: won, multiplier: mult, label: won > 0 ? `+${won} credits` : "No pull this time" };
}

// ─── Prize Showcase Credit Ranges ────────────────────────────────────────────
export const SHOWCASE_RANGES = [
  { label: "Best Pick",    pct: 1.00, description: "Best card you can afford" },
  { label: "Mid Range",   pct: 0.50, description: "50% of your credits" },
  { label: "Budget Pick", pct: 0.25, description: "25% of your credits" },
  { label: "Quick Win",   pct: 0.10, description: "10% of your credits" },
] as const;
