// ─── Types ────────────────────────────────────────────────────────────────────
export type Suit = "♠" | "♥" | "♦" | "♣";
export type Rank = "2" | "3" | "4" | "5" | "6" | "7" | "8" | "9" | "10" | "J" | "Q" | "K" | "A";

export interface Card {
  rank: Rank;
  suit: Suit;
  faceUp: boolean;
}

export type HandRank =
  | "Royal Flush" | "Straight Flush" | "Four of a Kind" | "Full House"
  | "Flush" | "Straight" | "Three of a Kind" | "Two Pair" | "One Pair" | "High Card";

export interface HandResult {
  rank: HandRank;
  score: number;
  description: string;
}

export type PlayerAction = "fold" | "check" | "call" | "raise" | "all-in";
export type BettingRound = "preflop" | "flop" | "turn" | "river" | "showdown";

export interface Player {
  id: string;
  name: string;
  avatar: string;
  chips: number;
  holeCards: Card[];
  bet: number;
  totalBet: number;
  folded: boolean;
  isAllIn: boolean;
  isDealer: boolean;
  isTurn: boolean;
  isHuman: boolean;
  lastAction?: PlayerAction;
  handResult?: HandResult;
  isWinner?: boolean;
}

export interface GameState {
  players: Player[];
  communityCards: Card[];
  pot: number;
  sidePots: number[];
  round: BettingRound;
  currentPlayerIndex: number;
  dealerIndex: number;
  smallBlind: number;
  bigBlind: number;
  deck: Card[];
  lastRaiseAmount: number;
  minRaise: number;
  actionLog: string[];
  phase: "waiting" | "playing" | "showdown" | "ended";
  winners: string[];
}

// ─── Deck ─────────────────────────────────────────────────────────────────────
const SUITS: Suit[] = ["♠", "♥", "♦", "♣"];
const RANKS: Rank[] = ["2","3","4","5","6","7","8","9","10","J","Q","K","A"];
const RANK_VALUES: Record<Rank, number> = {
  "2":2,"3":3,"4":4,"5":5,"6":6,"7":7,"8":8,"9":9,"10":10,"J":11,"Q":12,"K":13,"A":14,
};

export function createDeck(): Card[] {
  const deck: Card[] = [];
  for (const suit of SUITS) for (const rank of RANKS) deck.push({ rank, suit, faceUp: false });
  return shuffleDeck(deck);
}

export function shuffleDeck(deck: Card[]): Card[] {
  const d = [...deck];
  for (let i = d.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [d[i], d[j]] = [d[j], d[i]];
  }
  return d;
}

// ─── Hand Evaluation ──────────────────────────────────────────────────────────
function rankVal(r: Rank) { return RANK_VALUES[r]; }

function combinations<T>(arr: T[], k: number): T[][] {
  if (k === 0) return [[]];
  if (arr.length < k) return [];
  const [first, ...rest] = arr;
  return [...combinations(rest, k - 1).map(c => [first, ...c]), ...combinations(rest, k)];
}

function evaluate5(cards: Card[]): HandResult {
  const ranks = cards.map(c => rankVal(c.rank)).sort((a, b) => b - a);
  const suits = cards.map(c => c.suit);
  const rankCounts: Record<number, number> = {};
  for (const r of ranks) rankCounts[r] = (rankCounts[r] || 0) + 1;
  const counts = Object.values(rankCounts).sort((a, b) => b - a);
  const uniqueRanks = Object.keys(rankCounts).map(Number).sort((a, b) => b - a);
  const isFlush = new Set(suits).size === 1;
  const isStraight = (() => {
    if (uniqueRanks.length !== 5) return false;
    if (uniqueRanks[0] - uniqueRanks[4] === 4) return true;
    if (uniqueRanks[0] === 14 && uniqueRanks[1] === 5 && uniqueRanks[4] === 2) return true;
    return false;
  })();
  const highCard = ranks[0];
  const base = ranks.reduce((acc, r, i) => acc + r * Math.pow(15, 4 - i), 0);

  if (isFlush && isStraight && highCard === 14 && ranks[1] === 13)
    return { rank: "Royal Flush", score: 9_000_000 + base, description: "Royal Flush! 🎉" };
  if (isFlush && isStraight)
    return { rank: "Straight Flush", score: 8_000_000 + base, description: `Straight Flush, ${cards[0].rank} high` };
  if (counts[0] === 4)
    return { rank: "Four of a Kind", score: 7_000_000 + base, description: `Four of a Kind` };
  if (counts[0] === 3 && counts[1] === 2)
    return { rank: "Full House", score: 6_000_000 + base, description: "Full House" };
  if (isFlush)
    return { rank: "Flush", score: 5_000_000 + base, description: `Flush, ${cards[0].rank} high` };
  if (isStraight)
    return { rank: "Straight", score: 4_000_000 + base, description: `Straight, ${cards[0].rank} high` };
  if (counts[0] === 3)
    return { rank: "Three of a Kind", score: 3_000_000 + base, description: "Three of a Kind" };
  if (counts[0] === 2 && counts[1] === 2)
    return { rank: "Two Pair", score: 2_000_000 + base, description: "Two Pair" };
  if (counts[0] === 2)
    return { rank: "One Pair", score: 1_000_000 + base, description: `Pair of ${uniqueRanks[0]}s` };
  return { rank: "High Card", score: base, description: `${cards[0].rank} high` };
}

export function evaluateHand(holeCards: Card[], communityCards: Card[]): HandResult {
  const all = [...holeCards, ...communityCards].filter(c => c.rank);
  if (all.length < 2) return { rank: "High Card", score: 0, description: "—" };
  const combos = combinations(all, Math.min(5, all.length));
  let best: HandResult = { rank: "High Card", score: 0, description: "" };
  for (const combo of combos) {
    const r = evaluate5(combo);
    if (r.score > best.score) best = r;
  }
  return best;
}

// ─── AI Decision ──────────────────────────────────────────────────────────────
export function aiDecide(
  player: Player,
  gameState: GameState,
  callAmount: number,
): { action: PlayerAction; amount: number } {
  const allCards = [...player.holeCards, ...gameState.communityCards];
  const handResult = allCards.length >= 2 ? evaluateHand(player.holeCards, gameState.communityCards) : null;
  const strength = Math.min((handResult?.score ?? 0) / 9_000_000, 1);
  const rand = Math.random();
  const potOdds = callAmount / (gameState.pot + callAmount || 1);
  const bluffing = rand < 0.12;

  if (player.chips === 0) return { action: "check", amount: 0 };

  if (callAmount === 0) {
    if (strength > 0.6 || bluffing) {
      const raiseAmt = Math.min(Math.floor(gameState.pot * (0.5 + rand * 0.5)), player.chips);
      return { action: "raise", amount: Math.max(raiseAmt, gameState.bigBlind) };
    }
    return { action: "check", amount: 0 };
  }

  if (strength > 0.7 || bluffing) {
    if (strength > 0.85 && rand > 0.4) {
      const raiseAmt = Math.min(Math.floor(callAmount * (1.5 + rand * 2)), player.chips);
      return { action: "raise", amount: raiseAmt };
    }
    return { action: "call", amount: callAmount };
  }
  if (strength > potOdds * 1.5 || (strength > 0.3 && callAmount < gameState.bigBlind * 2))
    return { action: "call", amount: callAmount };
  return { action: "fold", amount: 0 };
}

// ─── Game Initialization ──────────────────────────────────────────────────────
export const AI_NAMES = [
  { name: "Ace McGee", avatar: "🎩" },
  { name: "Lucky Lou", avatar: "🍀" },
  { name: "Shark Sal", avatar: "🦈" },
  { name: "Bluff King", avatar: "👑" },
  { name: "River Roxy", avatar: "🌊" },
];

export function initGame(humanName: string, buyIn: number, smallBlind: number, numAI = 4): GameState {
  const deck = createDeck();
  const dealerIdx = Math.floor(Math.random() * (numAI + 1));
  const players: Player[] = [
    { id: "human", name: humanName, avatar: "😎", chips: buyIn, holeCards: [], bet: 0, totalBet: 0,
      folded: false, isAllIn: false, isDealer: dealerIdx === 0, isTurn: false, isHuman: true },
    ...AI_NAMES.slice(0, numAI).map((ai, i) => ({
      id: `ai_${i}`, name: ai.name, avatar: ai.avatar, chips: buyIn, holeCards: [], bet: 0, totalBet: 0,
      folded: false, isAllIn: false, isDealer: dealerIdx === i + 1, isTurn: false, isHuman: false,
    })),
  ];
  return {
    players, communityCards: [], pot: 0, sidePots: [], round: "preflop",
    currentPlayerIndex: 0, dealerIndex: dealerIdx, smallBlind, bigBlind: smallBlind * 2,
    deck, lastRaiseAmount: smallBlind * 2, minRaise: smallBlind * 2,
    actionLog: [], phase: "waiting", winners: [],
  };
}

export function dealHands(state: GameState): GameState {
  const deck = [...state.deck];
  const players: Player[] = state.players.map(p => ({
    ...p, holeCards: [] as Card[], bet: 0, totalBet: 0, folded: false, isAllIn: false,
    lastAction: undefined as PlayerAction | undefined,
    handResult: undefined as HandResult | undefined, isWinner: false,
  }));

  for (let i = 0; i < 2; i++) {
    for (const player of players) {
      const card = deck.pop()!;
      player.holeCards.push({ rank: card.rank, suit: card.suit, faceUp: player.isHuman });
    }
  }

  const sbIdx = (state.dealerIndex + 1) % players.length;
  const bbIdx = (state.dealerIndex + 2) % players.length;
  const firstToAct = (state.dealerIndex + 3) % players.length;
  const sb = Math.min(state.smallBlind, players[sbIdx].chips);
  const bb = Math.min(state.bigBlind, players[bbIdx].chips);

  players[sbIdx].chips -= sb; players[sbIdx].bet = sb; players[sbIdx].totalBet = sb;
  players[bbIdx].chips -= bb; players[bbIdx].bet = bb; players[bbIdx].totalBet = bb;

  return {
    ...state, players, deck, pot: sb + bb, communityCards: [], round: "preflop",
    currentPlayerIndex: firstToAct, lastRaiseAmount: bb, minRaise: bb, phase: "playing",
    actionLog: [`${players[sbIdx].name} posts SB (${sb})`, `${players[bbIdx].name} posts BB (${bb})`],
    winners: [],
  };
}

export function determineWinners(state: GameState): GameState {
  const activePlayers = state.players.filter(p => !p.folded);
  const evaluated = activePlayers.map(p => ({
    ...p,
    holeCards: p.holeCards.map(c => ({ rank: c.rank, suit: c.suit, faceUp: true } as Card)),
    handResult: evaluateHand(p.holeCards, state.communityCards),
  }));
  evaluated.sort((a, b) => (b.handResult?.score ?? 0) - (a.handResult?.score ?? 0));
  const winnerScore = evaluated[0].handResult?.score ?? 0;
  const winners = evaluated.filter(p => (p.handResult?.score ?? 0) === winnerScore);
  const share = Math.floor(state.pot / winners.length);

  const updatedPlayers = state.players.map(p => {
    const isWinner = winners.some(w => w.id === p.id);
    const evalP = evaluated.find(e => e.id === p.id);
    return {
      ...p,
      holeCards: p.holeCards.map(c => ({ rank: c.rank, suit: c.suit, faceUp: true } as Card)),
      handResult: evalP?.handResult,
      chips: isWinner ? p.chips + share : p.chips,
      isWinner,
    };
  });

  return {
    ...state, players: updatedPlayers, phase: "showdown", winners: winners.map(w => w.id),
    actionLog: [...state.actionLog, ...winners.map(w => `${w.name} wins ${share} with ${w.handResult?.rank}!`)],
  };
}
