import { useState, useEffect } from "react";
import { trpc } from "@/lib/trpc";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { Save, X } from "lucide-react";

interface CollectionItemDrawerProps {
  collectionId: number | null;
  onClose: () => void;
  onUpdated?: () => void;
}

export function CollectionItemDrawer({ collectionId, onClose, onUpdated }: CollectionItemDrawerProps) {
  const { data: item, isLoading, refetch } = trpc.admin.adminGetCollectionItem.useQuery(
    { collectionId: collectionId! },
    { enabled: collectionId !== null }
  );

  const updateMutation = trpc.admin.adminUpdateCollectionItem.useMutation({
    onSuccess: () => {
      toast.success("Collection item updated");
      refetch();
      onUpdated?.();
    },
    onError: (e) => toast.error(e.message),
  });

  const [form, setForm] = useState({
    cardTitle: "",
    playerName: "",
    year: "",
    setName: "",
    overallGrade: "",
    estimatedValueLow: "",
    estimatedValueHigh: "",
    certNumber: "",
    sport: "" as "baseball" | "basketball" | "football" | "hockey" | "soccer" | "other" | "",
    description: "",
    listingStatus: "",
  });

  useEffect(() => {
    if (item) {
      setForm({
        cardTitle: item.cardTitle ?? "",
        playerName: item.playerName ?? "",
        year: item.year ?? "",
        setName: item.setName ?? "",
        overallGrade: item.overallGrade ?? "",
        estimatedValueLow: item.estimatedValueLow ?? "",
        estimatedValueHigh: item.estimatedValueHigh ?? "",
        certNumber: item.certNumber ?? "",
        sport: (item.sport as any) ?? "",
        description: item.description ?? "",
    listingStatus: item.listingStatus ?? "",
      });
    }
  }, [item]);

  const handleSave = () => {
    if (!collectionId) return;
    updateMutation.mutate({
      collectionId,
      cardTitle: form.cardTitle || undefined,
      playerName: form.playerName || undefined,
      year: form.year || undefined,
      setName: form.setName || undefined,
      overallGrade: form.overallGrade || undefined,
      estimatedValueLow: form.estimatedValueLow || undefined,
      estimatedValueHigh: form.estimatedValueHigh || undefined,
      certNumber: form.certNumber || undefined,
      sport: (form.sport as any) || undefined,
      description: form.description || undefined,
              listingStatus: form.listingStatus || undefined,
    });
  };

  const GRADE_LABELS: Record<string, string> = {
    "10": "GEM MINT", "9.5": "MINT+", "9": "MINT",
    "8.5": "NM-MT+", "8": "NM-MT", "7.5": "NM+", "7": "NM",
    "6": "EX-MT", "5": "EX", "4": "VG-EX", "3": "VG",
    "2": "GOOD", "1": "POOR",
  };

  const gradeNum = parseFloat(form.overallGrade);

  return (
    <Sheet open={collectionId !== null} onOpenChange={open => { if (!open) onClose(); }}>
      <SheetContent side="right" className="w-full sm:max-w-xl bg-[#0a1628] border-white/10 text-white overflow-y-auto">
        <SheetHeader className="mb-4">
          <div className="flex items-center justify-between">
            <SheetTitle className="text-white text-lg">
              {isLoading ? "Loading..." : item?.cardTitle ?? "Collection Item"}
            </SheetTitle>
            <Button variant="ghost" size="icon" onClick={onClose} className="text-white/40 hover:text-white">
              <X className="w-4 h-4" />
            </Button>
          </div>
          {item && (
            <div className="flex items-center gap-2 mt-1">
              <span className="text-white/40 text-xs">ID #{item.id}</span>
              <span className="text-white/20 text-xs">·</span>
              <span className="text-white/40 text-xs">{item.ownerEmail}</span>
              {item.overallGrade && (
                <Badge className="bg-yellow-500/20 text-yellow-400 border-yellow-500/30 text-xs ml-auto">
                  SCG {parseFloat(item.overallGrade).toFixed(1)}
                  {GRADE_LABELS[parseFloat(item.overallGrade).toFixed(1)] && (
                    <span className="ml-1 opacity-60">{GRADE_LABELS[parseFloat(item.overallGrade).toFixed(1)]}</span>
                  )}
                </Badge>
              )}
            </div>
          )}
        </SheetHeader>

        {isLoading && (
          <div className="flex items-center justify-center h-32 text-white/40">Loading...</div>
        )}

        {item && !isLoading && (
          <div className="space-y-4">
            {/* Card images */}
            {(item.frontImageUrl || item.backImageUrl) && (
              <div className="flex gap-3">
                {item.frontImageUrl && (
                  <img src={item.frontImageUrl} alt="Front" className="h-32 w-auto rounded-lg border border-white/10 object-contain bg-black/40" />
                )}
                {item.backImageUrl && (
                  <img src={item.backImageUrl} alt="Back" className="h-32 w-auto rounded-lg border border-white/10 object-contain bg-black/40" />
                )}
              </div>
            )}

            {/* Core fields */}
            <div className="grid grid-cols-2 gap-3">
              <div className="col-span-2">
                <Label className="text-white/60 text-xs mb-1 block">Card Title</Label>
                <Input
                  value={form.cardTitle}
                  onChange={e => setForm(f => ({ ...f, cardTitle: e.target.value }))}
                  className="bg-white/5 border-white/10 text-white text-sm h-8"
                />
              </div>
              <div>
                <Label className="text-white/60 text-xs mb-1 block">Player Name</Label>
                <Input
                  value={form.playerName}
                  onChange={e => setForm(f => ({ ...f, playerName: e.target.value }))}
                  className="bg-white/5 border-white/10 text-white text-sm h-8"
                />
              </div>
              <div>
                <Label className="text-white/60 text-xs mb-1 block">Year</Label>
                <Input
                  value={form.year}
                  onChange={e => setForm(f => ({ ...f, year: e.target.value }))}
                  className="bg-white/5 border-white/10 text-white text-sm h-8"
                />
              </div>
              <div>
                <Label className="text-white/60 text-xs mb-1 block">Set Name</Label>
                <Input
                  value={form.setName}
                  onChange={e => setForm(f => ({ ...f, setName: e.target.value }))}
                  className="bg-white/5 border-white/10 text-white text-sm h-8"
                />
              </div>
              <div>
                <Label className="text-white/60 text-xs mb-1 block">Sport</Label>
                <Select value={form.sport} onValueChange={v => setForm(f => ({ ...f, sport: v as any }))}>
                  <SelectTrigger className="h-8 text-sm bg-white/5 border-white/10 text-white">
                    <SelectValue placeholder="Select sport" />
                  </SelectTrigger>
                  <SelectContent>
                    {["baseball","basketball","football","hockey","soccer","other"].map(s => (
                      <SelectItem key={s} value={s} className="capitalize">{s}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Grade & Value */}
            <div className="bg-white/5 rounded-lg p-3 space-y-3">
              <p className="text-white/60 text-xs font-semibold uppercase tracking-wide">Grade & Value</p>
              <div className="grid grid-cols-3 gap-3">
                <div>
                  <Label className="text-white/60 text-xs mb-1 block">Grade</Label>
                  <Input
                    value={form.overallGrade}
                    onChange={e => setForm(f => ({ ...f, overallGrade: e.target.value }))}
                    placeholder="e.g. 9.5"
                    className="bg-white/5 border-white/10 text-white text-sm h-8"
                  />
                  {!isNaN(gradeNum) && GRADE_LABELS[gradeNum.toFixed(1)] && (
                    <p className="text-yellow-400/60 text-xs mt-1">{GRADE_LABELS[gradeNum.toFixed(1)]}</p>
                  )}
                </div>
                <div>
                  <Label className="text-white/60 text-xs mb-1 block">Est. Value Low ($)</Label>
                  <Input
                    value={form.estimatedValueLow}
                    onChange={e => setForm(f => ({ ...f, estimatedValueLow: e.target.value }))}
                    placeholder="0.00"
                    className="bg-white/5 border-white/10 text-white text-sm h-8"
                  />
                </div>
                <div>
                  <Label className="text-white/60 text-xs mb-1 block">Est. Value High ($)</Label>
                  <Input
                    value={form.estimatedValueHigh}
                    onChange={e => setForm(f => ({ ...f, estimatedValueHigh: e.target.value }))}
                    placeholder="0.00"
                    className="bg-white/5 border-white/10 text-white text-sm h-8"
                  />
                </div>
              </div>
              <div>
                <Label className="text-white/60 text-xs mb-1 block">Cert Number</Label>
                <Input
                  value={form.certNumber}
                  onChange={e => setForm(f => ({ ...f, certNumber: e.target.value }))}
                  placeholder="PSA/BGS cert #"
                  className="bg-white/5 border-white/10 text-white text-sm h-8"
                />
              </div>
            </div>

            {/* Status */}
            <div>
              <Label className="text-white/60 text-xs mb-1 block">Listing Status</Label>
              <Select value={form.listingStatus} onValueChange={v => setForm(f => ({ ...f, listingStatus: v }))}>
                <SelectTrigger className="h-8 text-sm bg-white/5 border-white/10 text-white">
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent>
                  {["none","listed","auction","in_trade","in_sale","shipped","traded","sold","pending_gm","gs","gm_complete","vaulted","vault_listed","vault_auction","vault_sold","vault_shipped"].map(s => (
                    <SelectItem key={s} value={s} className="text-xs capitalize">{s.replace(/_/g," ")}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Description */}
            <div>
              <Label className="text-white/60 text-xs mb-1 block">Description</Label>
              <Textarea
                value={form.description}
                onChange={e => setForm(f => ({ ...f, description: e.target.value }))}
                rows={3}
                className="bg-white/5 border-white/10 text-white text-sm resize-none"
              />
            </div>

            {/* Save */}
            <Button
              onClick={handleSave}
              disabled={updateMutation.isPending}
              className="w-full bg-[#C41E3A] hover:bg-[#a01830] text-white"
            >
              <Save className="w-4 h-4 mr-2" />
              {updateMutation.isPending ? "Saving..." : "Save Changes"}
            </Button>
          </div>
        )}
      </SheetContent>
    </Sheet>
  );
}
