/**
 * SlabFrame — Auto-matched grading company slab label.
 *
 * Label styles by gradeCompany:
 *   BGS / Beckett  → Olive/tan label, dark text, "BECKETT" brand, sub-grades, large grade right
 *   PSA            → White label, red bottom strip, "PSA" brand, cert# barcode style
 *   SCG (our own)  → White label, silver border (no red)
 *   No grade / eBay → Full card frame, no label
 */

import { Award } from "lucide-react";
import { proxyImageUrl } from "@/lib/utils";

const GRADE_NAMES: Record<string, string> = {
  "10": "GEM MINT", "9.5": "GEM MINT", "9": "MINT", "8.5": "NM-MT+",
  "8": "NM-MT", "7.5": "NM+", "7": "NM", "6.5": "EX-MT+",
  "6": "EX-MT", "5": "EX", "4": "VG-EX", "3": "VG", "2": "GOOD", "1": "POOR",
};

// BGS Black Label is 10 Pristine
const BGS_GRADE_NAMES: Record<string, string> = {
  "10": "PRISTINE", "9.5": "GEM MINT", "9": "MINT", "8.5": "NM-MT+",
  "8": "NM-MT", "7.5": "NM+", "7": "NM", "6.5": "EX-MT+",
  "6": "EX-MT", "5": "EX", "4": "VG-EX", "3": "VG", "2": "GOOD", "1": "POOR",
};

export interface SlabFrameProps {
  imageUrl?: string | null;
  altText?: string;
  labelColor?: string | null;
  labelBg?: string | null;
  labelBorder?: string | null;
  labelMode?: "with_label" | "no_label" | null;
  grade?: string | number | null;
  gradeLabel?: string | null;
  playerName?: string | null;
  setName?: string | null;
  year?: string | null;
  cardNumber?: string | null;
  certNumber?: string | null;
  aiCertNumber?: string | null;
  aiCentering?: string | null;
  aiCorners?: string | null;
  aiEdges?: string | null;
  aiSurface?: string | null;
  cardId?: number | null;
  isBack?: boolean;
  className?: string;
  showScoLabel?: boolean;
  onError?: () => void;
  /** gradeCompany drives the label style: 'Beckett' | 'PSA' | 'SGC' | 'SCG' | 'other' | 'none' */
  gradeCompany?: string | null;
  // Source badge: 'H' = house, 'E' = eBay, 'G' = graded, 'U' = user upload
  sourceBadge?: 'H' | 'E' | 'G' | 'U' | null;
  // Status banner overlay
  cardStatus?: 'active' | 'auction' | 'traded' | 'shipping' | 'sold' | 'bank' | 'casino' | 'draft' | null;
  /** Show a glowing NEW badge — true when card was added in the last 24 hours */
  isNew?: boolean;
}

export function SlabFrame({
  imageUrl: rawImageUrl,
  altText = "Card",
  labelColor,
  labelBg,
  labelBorder,
  labelMode,
  grade,
  gradeLabel,
  playerName,
  setName,
  year,
  cardNumber,
  certNumber,
  aiCertNumber,
  aiCentering,
  aiCorners,
  aiEdges,
  aiSurface,
  cardId,
  isBack = false,
  className = "",
  showScoLabel = false,
  gradeCompany,
  sourceBadge,
  cardStatus,
  isNew = false,
}: SlabFrameProps) {

  // Source badge config
  const BADGE_CONFIG: Record<string, { color: string; label: string }> = {
    H: { color: '#f59e0b', label: 'H' },
    E: { color: '#3b82f6', label: 'E' },
    G: { color: '#8b5cf6', label: 'G' },
    U: { color: '#10b981', label: 'U' },
  };

  // Status banner config
  const STATUS_BANNER: Record<string, { text: string; color: string }> = {
    auction:  { text: 'AUCTION',   color: 'rgba(249,115,22,0.88)' },
    traded:   { text: 'TRADE',     color: 'rgba(20,184,166,0.88)' },
    shipping: { text: 'SHIPPING',  color: 'rgba(59,130,246,0.88)' },
    sold:     { text: 'SOLD',      color: 'rgba(239,68,68,0.88)'  },
    bank:     { text: 'IN VAULT',  color: 'rgba(245,158,11,0.88)' },
    casino:   { text: 'GAME ROOM', color: 'rgba(139,92,246,0.88)' },
    draft:    { text: 'DRAFT',     color: 'rgba(107,114,128,0.88)'},
  };

  const badge = sourceBadge ? BADGE_CONFIG[sourceBadge] : null;
  const banner = cardStatus && cardStatus !== 'active' ? STATUS_BANNER[cardStatus] : null;
  const imageUrl = proxyImageUrl(rawImageUrl);

  const gradeNum = grade ? parseFloat(String(grade)) : null;
  const gradeStr = gradeNum !== null && !isNaN(gradeNum) ? String(gradeNum) : null;
  const certNum = certNumber || aiCertNumber || null;

  // Determine which label style to use based on gradeCompany
  const company = (gradeCompany ?? "").toLowerCase();
  const isBGS = company === "beckett" || company === "bgs";
  const isPSA = company === "psa";
  const isSGC = company === "sgc";
  const isSCG = company === "scg" || showScoLabel || labelMode === "with_label";

  // Show label if: has a grade company with a grade, or forced via showScoLabel/labelMode
  const hasGrade = !!gradeStr;
  const showLabel = (hasGrade && (isBGS || isPSA || isSGC || isSCG || company === "other")) ||
                    showScoLabel ||
                    labelMode === "with_label" ||
                    (hasGrade && !gradeCompany && labelMode !== "no_label" && !!labelColor);

  // For eBay imported cards with no SCG grade — no label, full frame
  const forceNoLabel = labelMode === "no_label" || (!showLabel && !showScoLabel);

  // ── SHARED OVERLAYS (badges, banners, new) ─────────────────────────────────
  const Overlays = () => (
    <>
      {banner && (
        <div style={{
          position: 'absolute', top: '50%', left: '-10%', width: '120%',
          transform: 'translateY(-50%) rotate(-35deg)',
          background: banner.color, color: '#fff',
          fontFamily: "'Oswald', sans-serif", fontWeight: 900, fontSize: 18,
          letterSpacing: 3, textAlign: 'center', padding: '6px 0',
          pointerEvents: 'none', zIndex: 10, textShadow: '0 1px 3px rgba(0,0,0,0.5)',
        }}>{banner.text}</div>
      )}
      {isNew && (
        <div style={{ position: 'absolute', top: 5, left: 5, zIndex: 20, pointerEvents: 'none' }}>
          <div style={{
            background: 'linear-gradient(135deg, #15803d 0%, #22c55e 60%, #4ade80 100%)',
            color: '#fff', fontFamily: "'Oswald', sans-serif", fontWeight: 900,
            fontSize: 9, letterSpacing: 1.8, padding: '2px 6px', borderRadius: 4,
            boxShadow: '0 0 10px rgba(34,197,94,0.9), 0 0 20px rgba(34,197,94,0.4), 0 2px 4px rgba(0,0,0,0.6)',
            border: '1px solid rgba(255,255,255,0.5)', lineHeight: 1.3,
            textTransform: 'uppercase', textShadow: '0 1px 2px rgba(0,0,0,0.4)',
          }}>NEW</div>
        </div>
      )}
      {badge && (
        <div style={{
          position: 'absolute', bottom: 6, right: 6, width: 22, height: 22,
          borderRadius: '50%', background: badge.color, color: '#fff',
          fontFamily: "'Oswald', sans-serif", fontWeight: 900, fontSize: 12,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          boxShadow: '0 2px 6px rgba(0,0,0,0.6)', zIndex: 11,
          border: '2px solid rgba(255,255,255,0.3)', pointerEvents: 'none',
        }}>{badge.label}</div>
      )}
    </>
  );

  // ── NO LABEL — full card frame ─────────────────────────────────────────────
  if (forceNoLabel) {
    return (
      <div className={`relative w-full h-full ${className}`} style={{
        border: '2px solid rgba(255,255,255,0.08)',
        borderRadius: 6, overflow: 'hidden', background: '#0a0a12',
      }}>
        {imageUrl
          ? <img src={imageUrl} alt={altText} style={{ width: '100%', height: '100%', objectFit: 'contain', display: 'block' }} />
          : <div style={{ width: '100%', height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <Award style={{ width: 32, height: 32, color: 'rgba(255,255,255,0.12)' }} />
            </div>
        }
        <div style={{ position: 'absolute', inset: 0 }}><Overlays /></div>
      </div>
    );
  }

  // ── BGS / BECKETT LABEL ────────────────────────────────────────────────────
  if (isBGS) {
    // Beckett: olive/tan background, dark charcoal text, "BECKETT" brand top-left
    // Large grade number top-right, sub-grades in small text below card info
    // Black Label (10 Pristine) gets black bg with gold accents
    const isBlackLabel = gradeStr === "10";
    const bgsLabelBg = isBlackLabel ? "#111111" : "#c8b98a"; // black label or olive/tan
    const bgsBorderColor = isBlackLabel ? "#c9a227" : "#2c2c2c"; // gold or dark
    const bgsTextColor = isBlackLabel ? "#c9a227" : "#1a1a1a";
    const bgsSubColor = isBlackLabel ? "#a08020" : "#3a3a3a";
    const bgsGradeColor = isBlackLabel ? "#c9a227" : "#1a1a1a";
    const gradeName = gradeLabel || (gradeStr ? BGS_GRADE_NAMES[gradeStr] ?? "" : "");

    return (
      <div className={`relative w-full h-full flex flex-col ${className}`} style={{
        border: `2px solid ${bgsBorderColor}`,
        borderRadius: 4, overflow: 'hidden', background: '#0a0a12',
        boxShadow: `0 4px 20px rgba(0,0,0,0.7), 0 0 0 1px ${bgsBorderColor}55`,
        containerType: 'inline-size',
      }}>
        {/* BGS LABEL */}
        <div style={{
          flexShrink: 0, height: '18%',
          background: bgsLabelBg,
          borderBottom: `2px solid ${bgsBorderColor}`,
          padding: '2px 4px 2px 4px',
          display: 'flex', gap: 0, boxSizing: 'border-box',
        }}>
          {/* LEFT: brand + card info */}
          <div style={{ flex: 1, minWidth: 0, display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
            {/* Row 1: BECKETT brand */}
            <div style={{ display: 'flex', alignItems: 'center', gap: 3 }}>
              {/* Beckett "B" circle logo approximation */}
              <div style={{
                width: 14, height: 14, borderRadius: '50%',
                border: `1.5px solid ${bgsTextColor}`,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                flexShrink: 0,
              }}>
                <span style={{ fontSize: 8, fontWeight: 900, color: bgsTextColor, fontFamily: 'Georgia, serif', lineHeight: 1 }}>B</span>
              </div>
              <span style={{
                fontSize: 6, fontWeight: 900, color: bgsTextColor,
                letterSpacing: 1.2, fontFamily: "'Oswald', sans-serif", textTransform: 'uppercase',
              }}>BECKETT{isBlackLabel ? ' BLACK LABEL' : ''}</span>
            </div>
            {/* Row 2: set + year */}
            <div style={{
              fontSize: 'clamp(6px, 1.8cqw, 10px)', fontWeight: 700, color: bgsTextColor,
              fontFamily: "'Oswald', sans-serif", lineHeight: 1,
              whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis',
              textTransform: 'uppercase', letterSpacing: 0.3,
            }}>{playerName || '—'}</div>
            {/* Row 3: sub-grades */}
            <div style={{ display: 'flex', gap: 4, flexWrap: 'nowrap' }}>
              {[
                aiCentering ? `CTR ${aiCentering}` : null,
                aiCorners   ? `COR ${aiCorners}`   : null,
                aiEdges     ? `EDG ${aiEdges}`     : null,
                aiSurface   ? `SRF ${aiSurface}`   : null,
              ].filter(Boolean).map((s, i) => (
                <span key={i} style={{ fontSize: 4.5, fontWeight: 700, color: bgsSubColor, fontFamily: "'Oswald', sans-serif", whiteSpace: 'nowrap' }}>{s}</span>
              ))}
              {certNum && (
                <span style={{ fontSize: 4.5, fontWeight: 600, color: bgsSubColor, fontFamily: "'Courier New', monospace", marginLeft: 'auto', whiteSpace: 'nowrap' }}>{certNum}</span>
              )}
            </div>
          </div>

          {/* RIGHT: grade number */}
          {gradeStr && (
            <div style={{
              flexShrink: 0, borderLeft: `1.5px solid ${bgsBorderColor}`,
              paddingLeft: 4, paddingRight: 3, marginLeft: 4,
              display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
              minWidth: 40,
            }}>
              <div style={{
                fontSize: 4.5, fontWeight: 800, color: bgsSubColor,
                fontFamily: "'Oswald', sans-serif", letterSpacing: 0.8,
                textTransform: 'uppercase', lineHeight: 1, marginBottom: 1, whiteSpace: 'nowrap',
              }}>{gradeName}</div>
              <div style={{
                fontSize: 20, fontWeight: 900, color: bgsGradeColor,
                fontFamily: "'Georgia', serif", lineHeight: 1,
              }}>{gradeStr}</div>
            </div>
          )}
        </div>

        {/* ACCENT BAR — dark charcoal for BGS */}
        <div style={{ flexShrink: 0, height: 5, background: bgsBorderColor }} />

        {/* CARD IMAGE */}
        <div style={{ flex: 1, position: 'relative', overflow: 'hidden', background: '#0a0a12' }}>
          {imageUrl
            ? <img src={imageUrl} alt={altText} style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', objectFit: 'contain', objectPosition: 'center', display: 'block' }} />
            : <div style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <Award style={{ width: 40, height: 40, color: 'rgba(255,255,255,0.12)' }} />
              </div>
          }
          <Overlays />
        </div>
      </div>
    );
  }

  // ── PSA LABEL ──────────────────────────────────────────────────────────────
  if (isPSA) {
    // PSA: white label, red bottom strip, "PSA" in blue on left, grade large on right
    const gradeName = gradeLabel || (gradeStr ? GRADE_NAMES[gradeStr] ?? "" : "");
    return (
      <div className={`relative w-full h-full flex flex-col ${className}`} style={{
        border: '2px solid #cc0000',
        borderRadius: 4, overflow: 'hidden', background: '#0a0a12',
        boxShadow: '0 4px 20px rgba(0,0,0,0.7), 0 0 0 1px #cc000055',
        containerType: 'inline-size',
      }}>
        {/* PSA LABEL — white with red bottom strip */}
        <div style={{
          flexShrink: 0, height: '18%',
          background: '#ffffff',
          display: 'flex', flexDirection: 'column', boxSizing: 'border-box',
          overflow: 'hidden',
        }}>
          {/* Main label area */}
          <div style={{ flex: 1, display: 'flex', padding: '2px 4px 1px 4px', gap: 0 }}>
            {/* LEFT: PSA brand + card info */}
            <div style={{ flex: 1, minWidth: 0, display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
              {/* Row 1: PSA brand */}
              <div style={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                <span style={{
                  fontSize: 7, fontWeight: 900, color: '#003087',
                  letterSpacing: 1, fontFamily: 'Arial Black, sans-serif',
                }}>PSA</span>
                <span style={{
                  fontSize: 4.5, fontWeight: 600, color: '#555',
                  fontFamily: 'Arial, sans-serif', letterSpacing: 0.3,
                }}>GRADING SERVICES</span>
              </div>
              {/* Row 2: player name */}
              <div style={{
                fontSize: 'clamp(6px, 1.8cqw, 10px)', fontWeight: 700, color: '#111',
                fontFamily: 'Arial, sans-serif', lineHeight: 1,
                whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis',
                textTransform: 'uppercase',
              }}>{playerName || '—'}</div>
              {/* Row 3: set + cert */}
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 4 }}>
                <span style={{
                  fontSize: 4.5, fontWeight: 600, color: '#555',
                  fontFamily: 'Arial, sans-serif',
                  whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', flex: 1,
                }}>{setName || year || ''}</span>
                {certNum && (
                  <span style={{ fontSize: 4, fontWeight: 600, color: '#888', fontFamily: "'Courier New', monospace", whiteSpace: 'nowrap' }}>{certNum}</span>
                )}
              </div>
            </div>

            {/* RIGHT: grade */}
            {gradeStr && (
              <div style={{
                flexShrink: 0, borderLeft: '1.5px solid #cc0000',
                paddingLeft: 4, paddingRight: 3, marginLeft: 4,
                display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
                minWidth: 40,
              }}>
                <div style={{
                  fontSize: 4.5, fontWeight: 700, color: '#555',
                  fontFamily: 'Arial, sans-serif', letterSpacing: 0.5,
                  textTransform: 'uppercase', lineHeight: 1, marginBottom: 1, whiteSpace: 'nowrap',
                }}>{gradeName}</div>
                <div style={{
                  fontSize: 20, fontWeight: 900, color: '#cc0000',
                  fontFamily: 'Arial Black, sans-serif', lineHeight: 1,
                }}>{gradeStr}</div>
              </div>
            )}
          </div>
          {/* Red bottom strip */}
          <div style={{ flexShrink: 0, height: 5, background: '#cc0000' }} />
        </div>

        {/* CARD IMAGE */}
        <div style={{ flex: 1, position: 'relative', overflow: 'hidden', background: '#0a0a12' }}>
          {imageUrl
            ? <img src={imageUrl} alt={altText} style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', objectFit: 'contain', objectPosition: 'center', display: 'block' }} />
            : <div style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <Award style={{ width: 40, height: 40, color: 'rgba(255,255,255,0.12)' }} />
              </div>
          }
          <Overlays />
        </div>
      </div>
    );
  }

  // ── SGC LABEL ──────────────────────────────────────────────────────────────
  if (isSGC) {
    const gradeName = gradeLabel || (gradeStr ? GRADE_NAMES[gradeStr] ?? "" : "");
    return (
      <div className={`relative w-full h-full flex flex-col ${className}`} style={{
        border: '2px solid #1a1a1a',
        borderRadius: 4, overflow: 'hidden', background: '#0a0a12',
        boxShadow: '0 4px 20px rgba(0,0,0,0.7)',
        containerType: 'inline-size',
      }}>
        <div style={{
          flexShrink: 0, height: '15%',
          background: '#1a1a1a',
          padding: '2px 4px', display: 'flex', gap: 0, boxSizing: 'border-box',
        }}>
          <div style={{ flex: 1, minWidth: 0, display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
            <span style={{ fontSize: 6, fontWeight: 900, color: '#e8c547', letterSpacing: 1.5, fontFamily: "'Oswald', sans-serif" }}>SGC</span>
            <div style={{ fontSize: 'clamp(6px, 1.8cqw, 10px)', fontWeight: 700, color: '#fff', fontFamily: "'Oswald', sans-serif", whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', textTransform: 'uppercase' }}>{playerName || '—'}</div>
            <span style={{ fontSize: 4.5, fontWeight: 600, color: '#aaa', fontFamily: "'Oswald', sans-serif" }}>{setName || year || ''}</span>
          </div>
          {gradeStr && (
            <div style={{ flexShrink: 0, borderLeft: '1.5px solid #e8c547', paddingLeft: 4, marginLeft: 4, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', minWidth: 40 }}>
              <div style={{ fontSize: 4.5, fontWeight: 700, color: '#aaa', fontFamily: "'Oswald', sans-serif", textTransform: 'uppercase', lineHeight: 1, marginBottom: 1 }}>{gradeName}</div>
              <div style={{ fontSize: 20, fontWeight: 900, color: '#e8c547', fontFamily: "'Georgia', serif", lineHeight: 1 }}>{gradeStr}</div>
            </div>
          )}
        </div>
        <div style={{ flexShrink: 0, height: 4, background: '#e8c547' }} />
        <div style={{ flex: 1, position: 'relative', overflow: 'hidden', background: '#0a0a12' }}>
          {imageUrl
            ? <img src={imageUrl} alt={altText} style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', objectFit: 'contain', objectPosition: 'center', display: 'block' }} />
            : <div style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center' }}><Award style={{ width: 40, height: 40, color: 'rgba(255,255,255,0.12)' }} /></div>
          }
          <Overlays />
        </div>
      </div>
    );
  }

  // ── SCG / DEFAULT LABEL — white with silver border ─────────────────────────
  const gradeName = gradeLabel || (gradeStr ? GRADE_NAMES[gradeStr] ?? "" : "");
  // Override border: use silver/white instead of red
  const borderHex = labelBorder === "red" || !labelBorder ? "#9ca3af" : (
    { white: "#ffffff", orange: "#f97316", blue: "#1d4ed8", black: "#333333", silver: "#9ca3af" }[labelBorder] ?? "#9ca3af"
  );

  const verifyUrl = cardId
    ? `https://www.sportcardsonline.com/verify/${cardId}`
    : certNum ? `https://www.sportcardsonline.com/verify/${certNum}` : null;
  const qrUrl = verifyUrl
    ? `https://api.qrserver.com/v1/create-qr-code/?size=80x80&data=${encodeURIComponent(verifyUrl)}&bgcolor=ffffff&color=000000&margin=2`
    : null;

  return (
    <div className={`relative w-full h-full flex flex-col ${className}`} style={{
      border: `2px solid ${borderHex}`,
      borderRadius: 4, overflow: 'hidden', background: '#0a0a12',
      boxShadow: `0 4px 20px rgba(0,0,0,0.7), 0 0 0 1px ${borderHex}33`,
      containerType: 'inline-size',
    }}>
      {/* SCG LABEL — white with silver border */}
      <div style={{
        flexShrink: 0, height: '13%',
        background: '#f5f5f5',
        borderBottom: `1.5px solid ${borderHex}`,
        padding: '1px 4px', display: 'flex', flexDirection: 'column',
        justifyContent: 'center', gap: 1, boxSizing: 'border-box',
      }}>
        {!isBack ? (
          <div style={{ display: 'flex', height: '100%', gap: 0 }}>
            <div style={{ flex: 1, minWidth: 0, display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 2, minWidth: 0 }}>
                <span style={{ fontSize: 6, fontWeight: 900, color: '#111', letterSpacing: 1.5, fontFamily: "'Oswald', sans-serif", textTransform: 'uppercase', whiteSpace: 'nowrap', flexShrink: 0 }}>SCO GRADING</span>
                <span style={{ fontSize: 5.5, fontWeight: 600, color: '#666', fontFamily: "'Oswald', sans-serif", whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', maxWidth: '50%', textAlign: 'right' }}>{year || ''}</span>
              </div>
              <div style={{ fontSize: 'clamp(7px, 2.2cqw, 13px)', fontWeight: 900, color: '#111', fontFamily: "'Oswald', sans-serif", lineHeight: 1, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', textTransform: 'uppercase', letterSpacing: 0.3 }}>{playerName || '—'}</div>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 4, minWidth: 0 }}>
                <span style={{ fontSize: 5.5, fontWeight: 600, color: '#666', fontFamily: "'Oswald', sans-serif", whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', flex: 1 }}>{setName || ''}</span>
                {(certNum || cardNumber) && (
                  <span style={{ fontSize: 5, fontWeight: 700, color: '#888', fontFamily: "'Courier New', monospace", whiteSpace: 'nowrap', flexShrink: 0 }}>{certNum ? `#${certNum}` : cardNumber ? `No.${cardNumber}` : ''}</span>
                )}
              </div>
            </div>
            {gradeStr && (
              <div style={{ flexShrink: 0, borderLeft: `1.5px solid ${borderHex}`, paddingLeft: 4, paddingRight: 3, marginLeft: 4, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', minWidth: 44 }}>
                <div style={{ fontSize: 5, fontWeight: 800, color: '#333', fontFamily: "'Oswald', sans-serif", letterSpacing: 0.8, textTransform: 'uppercase', lineHeight: 1, marginBottom: 1, whiteSpace: 'nowrap' }}>{gradeName}</div>
                <div style={{ fontSize: 18, fontWeight: 900, color: borderHex === '#9ca3af' ? '#555' : borderHex, fontFamily: "'Georgia', serif", lineHeight: 1 }}>{gradeStr}</div>
              </div>
            )}
          </div>
        ) : (
          <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 8, height: '100%' }}>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 4 }}>
                <span style={{ fontSize: 11, fontWeight: 900, color: '#111', letterSpacing: 2, fontFamily: "'Oswald', sans-serif" }}>SCO GRADING</span>
              </div>
              {(aiCentering || aiCorners || aiEdges || aiSurface) && (
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6, marginBottom: 4 }}>
                  {[aiCentering && `CTR: ${aiCentering}`, aiCorners && `COR: ${aiCorners}`, aiEdges && `EDG: ${aiEdges}`, aiSurface && `SRF: ${aiSurface}`]
                    .filter(Boolean).map((s, i) => (
                      <span key={i} style={{ fontSize: 10, fontWeight: 700, color: '#555', fontFamily: "'Oswald', sans-serif" }}>{s}</span>
                    ))}
                </div>
              )}
              {certNum && <div style={{ fontSize: 10, color: '#666', fontFamily: "'Courier New', monospace" }}>CERT# {certNum}</div>}
            </div>
            {qrUrl && (
              <div style={{ flexShrink: 0, textAlign: 'center' }}>
                <img src={qrUrl} style={{ width: 48, height: 48, borderRadius: 4, border: `2px solid ${borderHex}` }} alt="QR" />
                <div style={{ fontSize: 7, color: '#666', marginTop: 2, fontFamily: "'Oswald', sans-serif" }}>SCAN TO VERIFY</div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* ACCENT BAR — silver for SCG */}
      <div style={{ flexShrink: 0, height: 7, background: borderHex }} />

      {/* CARD IMAGE */}
      <div style={{ flex: 1, position: 'relative', overflow: 'hidden', background: '#0a0a12' }}>
        {imageUrl
          ? <img src={imageUrl} alt={altText} style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', objectFit: 'contain', objectPosition: 'center', display: 'block' }} />
          : <div style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <Award style={{ width: 40, height: 40, color: 'rgba(255,255,255,0.12)' }} />
            </div>
        }
        <Overlays />
      </div>
    </div>
  );
}
