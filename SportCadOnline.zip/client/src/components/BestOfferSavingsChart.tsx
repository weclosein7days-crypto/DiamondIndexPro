import { useState } from "react";
import { trpc } from "@/lib/trpc";
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, ReferenceLine,
} from "recharts";
import { TrendingUp, DollarSign, CheckCircle2, Calendar } from "lucide-react";

type Granularity = "daily" | "weekly";
type Range = 7 | 30 | 90 | 365;

const RANGE_LABELS: Record<Range, string> = {
  7: "7d",
  30: "30d",
  90: "90d",
  365: "1y",
};

function formatDate(dateStr: string) {
  // dateStr is either "YYYY-MM-DD" or "YYYY-Www-YYYY-MM-DD"
  const iso = dateStr.includes("-W") ? dateStr.split("-").slice(2).join("-") : dateStr;
  const d = new Date(iso + "T00:00:00");
  if (isNaN(d.getTime())) return dateStr;
  return d.toLocaleDateString("en-US", { month: "short", day: "numeric" });
}

// Custom tooltip
function CustomTooltip({ active, payload, label }: any) {
  if (!active || !payload?.length) return null;
  const daily = payload.find((p: any) => p.dataKey === "savings");
  const cumul = payload.find((p: any) => p.dataKey === "cumulative");
  return (
    <div className="bg-[#0d1f3c] border border-white/10 rounded-lg p-3 text-xs shadow-xl">
      <div className="text-white/50 mb-1.5">{formatDate(label)}</div>
      {daily && (
        <div className="flex items-center gap-1.5 text-green-400">
          <span className="w-2 h-2 rounded-full bg-green-400 inline-block" />
          Daily savings: <span className="font-bold">${Number(daily.value).toFixed(2)}</span>
        </div>
      )}
      {cumul && (
        <div className="flex items-center gap-1.5 text-blue-400 mt-0.5">
          <span className="w-2 h-2 rounded-full bg-blue-400 inline-block" />
          Cumulative: <span className="font-bold">${Number(cumul.value).toFixed(2)}</span>
        </div>
      )}
    </div>
  );
}

export function BestOfferSavingsChart() {
  const [range, setRange] = useState<Range>(90);
  const [granularity, setGranularity] = useState<Granularity>("daily");
  const [mode, setMode] = useState<"daily" | "cumulative">("daily");

  const { data, isLoading } = trpc.admin.getBestOfferSavingsTimeSeries.useQuery(
    { days: range, granularity },
    { staleTime: 60_000 }
  );

  const chartData = (data?.points ?? []).map((p: any, i: number, arr: any[]) => {
    const cumulative = arr.slice(0, i + 1).reduce((sum: number, x: any) => sum + (x.savings ?? 0), 0);
    return { ...p, cumulative };
  });

  const hasData = chartData.some((p: any) => p.savings > 0);

  return (
    <div className="bg-[#0d1f3c] border border-white/10 rounded-xl p-5">
      {/* Header */}
      <div className="flex items-start justify-between mb-4 flex-wrap gap-3">
        <div>
          <div className="flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-green-400" />
            <h3 className="text-sm font-bold text-white">Best Offer Savings</h3>
          </div>
          <p className="text-xs text-white/40 mt-0.5">Accepted eBay offers — money saved vs. asking price</p>
        </div>
        {/* Summary pills */}
        <div className="flex items-center gap-3 flex-wrap">
          <div className="flex items-center gap-1.5 bg-green-500/10 border border-green-500/20 rounded-lg px-3 py-1.5">
            <DollarSign className="w-3 h-3 text-green-400" />
            <span className="text-xs font-bold text-green-400">${(data?.totalSavings ?? 0).toFixed(2)}</span>
            <span className="text-[10px] text-white/40">total saved</span>
          </div>
          <div className="flex items-center gap-1.5 bg-blue-500/10 border border-blue-500/20 rounded-lg px-3 py-1.5">
            <CheckCircle2 className="w-3 h-3 text-blue-400" />
            <span className="text-xs font-bold text-blue-400">{data?.acceptedCount ?? 0}</span>
            <span className="text-[10px] text-white/40">accepted</span>
          </div>
        </div>
      </div>

      {/* Controls */}
      <div className="flex items-center gap-2 mb-4 flex-wrap">
        {/* Range */}
        <div className="flex items-center gap-1 bg-white/5 rounded-lg p-1">
          {(Object.keys(RANGE_LABELS) as unknown as Range[]).map(r => (
            <button
              key={r}
              onClick={() => setRange(Number(r) as Range)}
              className={`text-[10px] px-2 py-0.5 rounded-md font-semibold transition-colors ${
                range === Number(r) ? "bg-[#C41E3A] text-white" : "text-white/40 hover:text-white"
              }`}
            >
              {RANGE_LABELS[Number(r) as Range]}
            </button>
          ))}
        </div>
        {/* Granularity */}
        <div className="flex items-center gap-1 bg-white/5 rounded-lg p-1">
          {(["daily", "weekly"] as Granularity[]).map(g => (
            <button
              key={g}
              onClick={() => setGranularity(g)}
              className={`text-[10px] px-2 py-0.5 rounded-md font-semibold transition-colors capitalize ${
                granularity === g ? "bg-white/20 text-white" : "text-white/40 hover:text-white"
              }`}
            >
              {g}
            </button>
          ))}
        </div>
        {/* Mode */}
        <div className="flex items-center gap-1 bg-white/5 rounded-lg p-1 ml-auto">
          {(["daily", "cumulative"] as const).map(m => (
            <button
              key={m}
              onClick={() => setMode(m)}
              className={`text-[10px] px-2 py-0.5 rounded-md font-semibold transition-colors capitalize ${
                mode === m ? "bg-white/20 text-white" : "text-white/40 hover:text-white"
              }`}
            >
              {m}
            </button>
          ))}
        </div>
      </div>

      {/* Chart */}
      {isLoading ? (
        <div className="h-48 flex items-center justify-center">
          <div className="w-5 h-5 border-2 border-[#C41E3A] border-t-transparent rounded-full animate-spin" />
        </div>
      ) : !hasData ? (
        <div className="h-48 flex flex-col items-center justify-center gap-2 text-white/30">
          <Calendar className="w-8 h-8 opacity-40" />
          <p className="text-xs">No accepted offers in this period yet</p>
          <p className="text-[10px] text-white/20">Savings will appear here once Best Offers are accepted</p>
        </div>
      ) : (
        <ResponsiveContainer width="100%" height={200}>
          <AreaChart data={chartData} margin={{ top: 4, right: 4, left: 0, bottom: 0 }}>
            <defs>
              <linearGradient id="savingsGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#22c55e" stopOpacity={0.3} />
                <stop offset="95%" stopColor="#22c55e" stopOpacity={0} />
              </linearGradient>
              <linearGradient id="cumulGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3} />
                <stop offset="95%" stopColor="#3b82f6" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
            <XAxis
              dataKey="date"
              tickFormatter={formatDate}
              tick={{ fill: "rgba(255,255,255,0.3)", fontSize: 9 }}
              axisLine={false}
              tickLine={false}
              interval="preserveStartEnd"
            />
            <YAxis
              tickFormatter={v => `$${v}`}
              tick={{ fill: "rgba(255,255,255,0.3)", fontSize: 9 }}
              axisLine={false}
              tickLine={false}
              width={48}
            />
            <Tooltip content={<CustomTooltip />} />
            <ReferenceLine y={0} stroke="rgba(255,255,255,0.1)" />
            {mode === "daily" ? (
              <Area
                type="monotone"
                dataKey="savings"
                stroke="#22c55e"
                strokeWidth={2}
                fill="url(#savingsGrad)"
                dot={false}
                activeDot={{ r: 4, fill: "#22c55e" }}
              />
            ) : (
              <Area
                type="monotone"
                dataKey="cumulative"
                stroke="#3b82f6"
                strokeWidth={2}
                fill="url(#cumulGrad)"
                dot={false}
                activeDot={{ r: 4, fill: "#3b82f6" }}
              />
            )}
          </AreaChart>
        </ResponsiveContainer>
      )}
    </div>
  );
}
