/**
 * GameTimesTicker — replaces the BettingTicker in the Game Room.
 * Shows today's real game times/scores from ESPN across all major leagues.
 * Priority: NCAA Men's/Women's Basketball (Final Four season) → MLB → NHL → NBA → NFL/CFB → MLS
 */
import { useEffect, useRef, useState } from "react";
import { trpc } from "@/lib/trpc";

const LEAGUE_COLORS: Record<string, string> = {
  "NCAA Men's":   "text-orange-400",
  "NCAA Women's": "text-pink-400",
  MLB:            "text-blue-400",
  NHL:            "text-cyan-400",
  NBA:            "text-orange-300",
  NFL:            "text-green-400",
  CFB:            "text-yellow-400",
  MLS:            "text-emerald-400",
};

const LEAGUE_ICONS: Record<string, string> = {
  "NCAA Men's":   "🏀",
  "NCAA Women's": "🏀",
  MLB:            "⚾",
  NHL:            "🏒",
  NBA:            "🏀",
  NFL:            "🏈",
  CFB:            "🏈",
  MLS:            "⚽",
};

interface GameEntry {
  league: string;
  leagueLabel: string;
  home: string;
  away: string;
  homeScore?: string;
  awayScore?: string;
  status: string;
  time: string;
  isLive: boolean;
  homeRank?: number;
  awayRank?: number;
}

function GameChip({ game }: { game: GameEntry }) {
  const color = LEAGUE_COLORS[game.league] ?? "text-yellow-400";
  const icon = LEAGUE_ICONS[game.league] ?? "🏆";
  const hasScore = game.homeScore !== undefined && game.awayScore !== undefined;

  return (
    <span className="inline-flex items-center gap-2 px-5 shrink-0">
      {/* League badge */}
      <span className={`text-[9px] font-black tracking-[0.15em] uppercase ${color}`}
        style={{ fontFamily: "Oswald, sans-serif" }}>
        {icon} {game.league}
      </span>
      <span className="text-white/20 text-xs">▸</span>
      {/* Teams + score */}
      <span className="text-[11px] text-white/85 font-semibold tracking-wide whitespace-nowrap">
        {game.awayRank && game.awayRank <= 25 ? <span className="text-yellow-400 text-[9px] mr-0.5">#{game.awayRank}</span> : null}
        {game.away}
        {hasScore ? (
          <span className="mx-1 text-white/50">
            {game.awayScore}
            <span className="mx-1 text-white/30">–</span>
            {game.homeScore}
          </span>
        ) : (
          <span className="mx-1 text-white/40">@</span>
        )}
        {game.homeRank && game.homeRank <= 25 ? <span className="text-yellow-400 text-[9px] mr-0.5">#{game.homeRank}</span> : null}
        {game.home}
      </span>
      {/* Status/time */}
      {game.isLive ? (
        <span className="bg-[#c41e3a] text-white text-[8px] font-black px-1.5 py-0.5 rounded animate-pulse tracking-widest">
          LIVE
        </span>
      ) : (
        <span className="text-[10px] text-white/40 font-medium">{game.time}</span>
      )}
      <span className="text-white/15 text-xs mx-1">◆</span>
    </span>
  );
}

const FALLBACK_GAMES: GameEntry[] = [
  { league: "NCAA Men's", leagueLabel: "NCAA Men's", away: "Duke", home: "UNC", status: "Scheduled", time: "7:00 PM ET", isLive: false },
  { league: "MLB", leagueLabel: "MLB", away: "NYY", home: "BOS", status: "Scheduled", time: "7:05 PM ET", isLive: false },
  { league: "NHL", leagueLabel: "NHL", away: "TOR", home: "MTL", status: "Scheduled", time: "7:30 PM ET", isLive: false },
  { league: "NBA", leagueLabel: "NBA", away: "LAL", home: "GSW", status: "Scheduled", time: "9:00 PM ET", isLive: false },
  { league: "NCAA Women's", leagueLabel: "NCAA Women's", away: "UConn", home: "Iowa", status: "Scheduled", time: "8:00 PM ET", isLive: false },
];

export function GameTimesTicker() {
  const { data: games, isLoading } = trpc.sportsData.gamesToday.useQuery(undefined, {
    refetchInterval: 3 * 60 * 1000, // refresh every 3 minutes
    staleTime: 2 * 60 * 1000,
  });

  const items: GameEntry[] = (!isLoading && games && games.length > 0) ? games : FALLBACK_GAMES;

  const trackRef = useRef<HTMLDivElement>(null);
  const pausedRef = useRef(false);
  const posRef = useRef(0);
  const rafRef = useRef<number>(0);

  useEffect(() => {
    const track = trackRef.current;
    if (!track || items.length === 0) return;
    const speed = 0.55;
    const animate = () => {
      if (!pausedRef.current) {
        posRef.current += speed;
        const halfWidth = track.scrollWidth / 2;
        if (posRef.current >= halfWidth) posRef.current = 0;
        track.style.transform = `translateX(-${posRef.current}px)`;
      }
      rafRef.current = requestAnimationFrame(animate);
    };
    rafRef.current = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(rafRef.current);
  }, [items]);

  return (
    <div
      className="w-full h-11 overflow-hidden select-none relative"
      style={{
        background: "linear-gradient(90deg, #050d1a 0%, #0a1628 50%, #050d1a 100%)",
        borderTop: "1px solid rgba(196,30,58,0.35)",
        boxShadow: "0 -2px 16px rgba(0,0,0,0.5)",
      }}
      onMouseEnter={() => { pausedRef.current = true; }}
      onMouseLeave={() => { pausedRef.current = false; }}
    >
      {/* Left label */}
      <div className="absolute left-0 top-0 bottom-0 z-10 flex items-center pointer-events-none">
        <div
          className="flex items-center gap-1.5 px-3 h-full shrink-0"
          style={{ background: "linear-gradient(90deg, #050d1a 65%, transparent)" }}
        >
          <span className="text-[9px] font-black tracking-[0.2em] text-[#c41e3a] uppercase"
            style={{ fontFamily: "Oswald, sans-serif" }}>
            GAME TIMES
          </span>
          <span className="w-px h-3 bg-[#c41e3a]/40" />
          <span className="text-[9px] font-bold text-white/30 tracking-wider uppercase">TODAY</span>
          <span className="w-px h-3 bg-white/10 ml-1" />
        </div>
      </div>
      {/* Right fade */}
      <div className="absolute right-0 top-0 bottom-0 w-12 z-10 pointer-events-none"
        style={{ background: "linear-gradient(270deg, #050d1a 60%, transparent)" }} />

      {/* Scrolling track */}
      <div className="flex items-center h-full pl-28">
        <div ref={trackRef} className="flex items-center h-full whitespace-nowrap will-change-transform">
          {[0, 1].map((pass) => (
            <div key={pass} className="flex items-center h-full shrink-0">
              {items.map((game, i) => (
                <GameChip key={`${pass}-${i}`} game={game} />
              ))}
            </div>
          ))}
        </div>
      </div>

      {isLoading && (
        <div className="absolute inset-0 flex items-center pl-28">
          <span className="text-white/30 text-xs animate-pulse">Loading today's games...</span>
        </div>
      )}
    </div>
  );
}
