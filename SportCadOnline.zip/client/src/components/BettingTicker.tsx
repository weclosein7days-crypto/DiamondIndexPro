import { useEffect, useRef, useState } from "react";
import { trpc } from "@/lib/trpc";
import { ExternalLink } from "lucide-react";

// Affiliate links — replace with your real tracking URLs after approval
const AFFILIATE_LINKS = {
  draftkings: "https://www.draftkings.com/gateway?s=1234567890", // Replace with your DK affiliate URL
  fanduel:    "https://www.fanduel.com/join",                    // Replace with your FD affiliate URL
};

function formatML(ml: number | null): string {
  if (ml === null) return "N/A";
  return ml > 0 ? `+${ml}` : `${ml}`;
}

function formatSpread(spread: string): string {
  return spread || "PK";
}

type OddsItem = {
  id: string;
  sport: string;
  emoji: string;
  awayTeam: string;
  homeTeam: string;
  awayAbbr: string;
  homeAbbr: string;
  spread: string;
  overUnder: number | null;
  awayML: number | null;
  homeML: number | null;
  gameTime: string;
  status: string;
};

function GameCard({ item }: { item: OddsItem }) {
  const isLive = item.status === "In Progress";
  const isFinal = item.status === "Final";
  const gameDate = new Date(item.gameTime);
  const timeStr = gameDate.toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });

  return (
    <div className="flex-shrink-0 flex items-center gap-3 bg-black/40 border border-yellow-500/20 rounded-lg px-4 py-2 mx-2 min-w-[320px]">
      {/* Sport badge */}
      <span className="text-xs font-bold text-yellow-400 bg-yellow-400/10 border border-yellow-400/30 rounded px-1.5 py-0.5 flex-shrink-0">
        {item.emoji} {item.sport}
      </span>

      {/* Matchup */}
      <div className="flex flex-col min-w-0">
        <div className="flex items-center gap-1.5 text-sm font-semibold text-white">
          <span>{item.awayAbbr}</span>
          <span className="text-white/40 text-xs">@</span>
          <span>{item.homeAbbr}</span>
          {isLive && (
            <span className="text-[10px] font-bold text-red-400 bg-red-400/10 border border-red-400/30 rounded px-1 animate-pulse">LIVE</span>
          )}
          {isFinal && (
            <span className="text-[10px] text-white/40">Final</span>
          )}
          {!isLive && !isFinal && (
            <span className="text-[10px] text-white/40">{timeStr}</span>
          )}
        </div>
        <div className="text-[10px] text-white/50 truncate">
          {item.awayTeam} vs {item.homeTeam}
        </div>
      </div>

      {/* Odds */}
      <div className="flex items-center gap-2 ml-auto flex-shrink-0">
        {/* Spread */}
        <div className="text-center">
          <div className="text-[9px] text-white/40 uppercase tracking-wide">Spread</div>
          <div className="text-xs font-bold text-green-400">{formatSpread(item.spread)}</div>
        </div>
        {/* O/U */}
        {item.overUnder && (
          <div className="text-center">
            <div className="text-[9px] text-white/40 uppercase tracking-wide">O/U</div>
            <div className="text-xs font-bold text-blue-400">{item.overUnder}</div>
          </div>
        )}
        {/* Moneyline */}
        <div className="text-center">
          <div className="text-[9px] text-white/40 uppercase tracking-wide">ML</div>
          <div className="text-xs font-mono text-white/80">
            <span className={item.awayML && item.awayML < 0 ? "text-green-400" : "text-red-400"}>{formatML(item.awayML)}</span>
            <span className="text-white/30 mx-0.5">/</span>
            <span className={item.homeML && item.homeML < 0 ? "text-green-400" : "text-red-400"}>{formatML(item.homeML)}</span>
          </div>
        </div>
      </div>

      {/* Bet Now button */}
      <a
        href={AFFILIATE_LINKS.draftkings}
        target="_blank"
        rel="noopener noreferrer"
        className="flex-shrink-0 flex items-center gap-1 bg-yellow-500 hover:bg-yellow-400 text-black text-[10px] font-bold px-2 py-1 rounded transition-colors"
        onClick={(e) => e.stopPropagation()}
      >
        BET <ExternalLink className="w-2.5 h-2.5" />
      </a>
    </div>
  );
}

export function BettingTicker() {
  const { data: odds, isLoading } = trpc.news.getBettingOdds.useQuery(undefined, {
    refetchInterval: 5 * 60 * 1000, // refresh every 5 minutes
    staleTime: 4 * 60 * 1000,
  });

  const trackRef = useRef<HTMLDivElement>(null);
  const [isPaused, setIsPaused] = useState(false);
  const posRef = useRef(0);
  const animRef = useRef<number>(0);
  const speedRef = useRef(0.5); // px per frame

  useEffect(() => {
    const track = trackRef.current;
    if (!track || !odds || odds.length === 0) return;

    const animate = () => {
      if (!isPaused) {
        posRef.current -= speedRef.current;
        const halfWidth = track.scrollWidth / 2;
        if (Math.abs(posRef.current) >= halfWidth) {
          posRef.current = 0;
        }
        track.style.transform = `translateX(${posRef.current}px)`;
      }
      animRef.current = requestAnimationFrame(animate);
    };

    animRef.current = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(animRef.current);
  }, [odds, isPaused]);

  if (isLoading) {
    return (
      <div className="w-full h-12 bg-black/60 border-t border-yellow-500/20 flex items-center px-4">
        <span className="text-yellow-400/60 text-xs animate-pulse">Loading live odds...</span>
      </div>
    );
  }

  if (!odds || odds.length === 0) {
    return (
      <div className="w-full h-12 bg-black/60 border-t border-yellow-500/20 flex items-center px-4 gap-3">
        <span className="text-yellow-400 text-xs font-bold">📊 LIVE ODDS</span>
        <span className="text-white/40 text-xs">No games scheduled today — check back later</span>
        <a
          href={AFFILIATE_LINKS.draftkings}
          target="_blank"
          rel="noopener noreferrer"
          className="ml-auto flex items-center gap-1 bg-yellow-500 hover:bg-yellow-400 text-black text-xs font-bold px-3 py-1 rounded transition-colors"
        >
          DraftKings <ExternalLink className="w-3 h-3" />
        </a>
      </div>
    );
  }

  // Duplicate items for seamless loop
  const items = [...odds, ...odds];

  return (
    <div
      className="w-full bg-black/70 border-t-2 border-yellow-500/40 overflow-hidden"
      style={{ height: "52px" }}
      onMouseEnter={() => setIsPaused(true)}
      onMouseLeave={() => setIsPaused(false)}
    >
      {/* Header label */}
      <div className="absolute left-0 z-10 h-[52px] flex items-center px-3 bg-gradient-to-r from-black via-black/90 to-transparent pointer-events-none">
        <div className="flex items-center gap-1.5">
          <div className="w-1.5 h-1.5 bg-red-500 rounded-full animate-pulse" />
          <span className="text-yellow-400 text-[10px] font-bold tracking-widest uppercase">Live Odds</span>
        </div>
      </div>

      {/* Scrolling track */}
      <div className="flex items-center h-full pl-24">
        <div ref={trackRef} className="flex items-center gap-0 will-change-transform">
          {items.map((item, idx) => (
            <GameCard key={`${item.id}-${idx}`} item={item} />
          ))}
        </div>
      </div>

      {/* Right fade + disclaimer */}
      <div className="absolute right-0 top-0 h-[52px] flex items-center pr-3 bg-gradient-to-l from-black via-black/80 to-transparent pointer-events-none">
        <span className="text-white/25 text-[9px]">21+ | Gambling Problem? 1-800-GAMBLER</span>
      </div>
    </div>
  );
}
