/**
 * CardPopup — compact card detail modal
 * - Fits on screen without overflow
 * - Add to Cart: shows confirmation, auto-closes after 2s
 * - Buy Now: opens Stripe checkout in new tab
 * - Click slab image to zoom (lightbox)
 */
import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ShoppingCart, ZoomIn, Award, Check, Camera, Share2, Link2, Twitter, Facebook, X as XIcon, Loader2, ExternalLink } from "lucide-react";
import { useCart } from "@/contexts/CartContext";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";
import CardCameraCapture from "@/components/CardCameraCapture";
import { SlabFrame } from "@/components/SlabFrame";

interface CardPopupProps {
  card: {
    id: number;
    title: string;
    playerName: string;
    price?: string | null;
    frontImageUrl?: string | null;
    backImageUrl?: string | null;
    labelColor?: string | null;
    extraImageUrls?: string[] | null;
    sellerEmail: string;
    storeName?: string | null;
    year?: string | null;
    setName?: string | null;
    cardNumber?: string | null;
    sport?: string | null;
    description?: string | null;
    aiGrade?: string | null;
    aiGradeLabel?: string | null;
    aiCentering?: string | null;
    aiCorners?: string | null;
    aiEdges?: string | null;
    aiSurface?: string | null;
    aiCertNumber?: string | null;
    certNumber?: string | null;
    isVaulted?: boolean | null;
    gradeCompany?: string | null;
    gradeScore?: string | null;
    isDropship?: boolean | null;
    source?: string | null;
  } | null;
  open: boolean;
  onClose: () => void;
}

// ── Simple fullscreen lightbox ───────────────────────────────────────────────
function Lightbox({ images, startIndex, onClose }: { images: string[]; startIndex: number; onClose: () => void }) {
  const [idx, setIdx] = useState(startIndex);
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
      if (e.key === "ArrowRight") setIdx(i => (i + 1) % images.length);
      if (e.key === "ArrowLeft") setIdx(i => (i - 1 + images.length) % images.length);
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [images.length, onClose]);

  return (
    <div className="fixed inset-0 z-[200] bg-black/95 flex items-center justify-center" onClick={onClose}>
      <button className="absolute top-4 right-4 text-white/70 hover:text-white" onClick={onClose}>
        <XIcon className="w-7 h-7" />
      </button>
      <img
        src={images[idx]}
        alt=""
        className="max-w-[90vw] max-h-[90vh] object-contain"
        onClick={e => e.stopPropagation()}
      />
      {images.length > 1 && (
        <div className="absolute bottom-6 flex gap-2">
          {images.map((_, i) => (
            <button
              key={i}
              onClick={e => { e.stopPropagation(); setIdx(i); }}
              className={`w-2 h-2 rounded-full transition-colors ${i === idx ? "bg-white" : "bg-white/30"}`}
            />
          ))}
        </div>
      )}
    </div>
  );
}

// ── Main popup ───────────────────────────────────────────────────────────────
export default function CardPopup({ card, open, onClose }: CardPopupProps) {
  const { addItem, removeItem, isInCart } = useCart();
  const { isAuthenticated, user } = useAuth();
  const createCheckout = trpc.orders.createCheckoutSession.useMutation();
  const [lightboxOpen, setLightboxOpen] = useState(false);
  const [lightboxStart, setLightboxStart] = useState(0);
  const [activeImg, setActiveImg] = useState(0);
  const [cameraOpen, setCameraOpen] = useState(false);
  const [shareOpen, setShareOpen] = useState(false);
  const [addedToCart, setAddedToCart] = useState(false);
  const isAdmin = (user as any)?.role === "admin";

  const images = card ? [
    card.frontImageUrl,
    card.backImageUrl,
    ...((card.extraImageUrls as string[] | null) || []),
  ].filter(Boolean) as string[] : [];

  // Reset ALL local state when card changes or popup closes
  useEffect(() => {
    setActiveImg(0);
    setAddedToCart(false);
    setLightboxOpen(false);
    setShareOpen(false);
  }, [card?.id]);

  // Also reset lightbox when popup closes
  useEffect(() => {
    if (!open) {
      setLightboxOpen(false);
      setShareOpen(false);
      setAddedToCart(false);
    }
  }, [open]);

  const inCart = card ? isInCart(card.id) : false;

  // Add to Cart — show confirmation, auto-close popup after 2s
  const handleAddToCart = () => {
    if (!card) return;
    if (inCart) {
      removeItem(card.id);
      toast.success("Removed from cart");
      return;
    }
    addItem({
      id: card.id,
      title: card.title,
      playerName: card.playerName,
      price: card.price || "0",
      frontImageUrl: card.frontImageUrl,
      sellerEmail: card.sellerEmail,
      storeName: card.storeName,
      aiGrade: card.aiGrade,
      aiGradeLabel: card.aiGradeLabel,
    });
    setAddedToCart(true);
    toast.success("Added to cart!");
    // Auto-close after 2 seconds
    setTimeout(() => {
      onClose();
      setAddedToCart(false);
    }, 2000);
  };

  // Buy Now — open Stripe checkout in new tab
  const handleBuyNow = async () => {
    if (!card) return;
    try {
      const { checkoutUrl } = await createCheckout.mutateAsync({
        cardId: card.id,
        cardTitle: card.title,
        cardImageUrl: card.frontImageUrl || undefined,
        sellerEmail: card.sellerEmail,
        sellerStoreName: card.storeName || undefined,
        price: card.price || "0",
        origin: window.location.origin,
      });
      toast.info("Opening checkout...");
      window.open(checkoutUrl, "_blank");
      onClose();
    } catch (e: any) {
      toast.error(e.message || "Failed to start checkout");
    }
  };

  if (!card) return null;

  const price = parseFloat(card.price || "0");

  return (
    <>
      {lightboxOpen && (
        <Lightbox images={images} startIndex={lightboxStart} onClose={() => setLightboxOpen(false)} />
      )}

      <Dialog open={open} onOpenChange={v => !v && onClose()}>
        {/* max-w-lg keeps it narrow enough to never overflow on 1024px+ screens */}
        <DialogContent className="w-[min(440px,calc(100vw-2rem))] max-h-[85vh] overflow-y-auto p-0 gap-0 bg-[#0d1f3c] border border-white/10" style={{maxWidth:'min(440px,calc(100vw - 2rem))'}}>

          {/* Header */}
          <DialogHeader className="px-4 pt-4 pb-2 border-b border-white/10">
            <DialogTitle className="text-sm font-bold text-white leading-tight pr-6 line-clamp-2">
              {card.title}
            </DialogTitle>
            <p className="text-xs text-white/50 mt-0.5">{card.playerName}</p>
          </DialogHeader>

          <div className="p-4 flex gap-4">

            {/* ── LEFT: Slab image ── */}
            <div className="flex flex-col gap-2 shrink-0" style={{ width: 140 }}>
              {/* Slab — click to zoom */}
              <div
                className="cursor-zoom-in relative group rounded overflow-hidden"
                style={{ height: 220 }}
                onClick={() => { setLightboxStart(activeImg); setLightboxOpen(true); }}
              >
                {images[activeImg] ? (
                  <SlabFrame
                    imageUrl={images[activeImg]}
                    altText={card.title}
                    labelColor={card.labelColor ?? "dark"}
                    grade={card.gradeScore || card.aiGrade}
                    gradeLabel={card.aiGradeLabel}
                    gradeCompany={card.gradeCompany}
                    playerName={card.playerName}
                    setName={card.setName}
                    year={card.year}
                    certNumber={card.certNumber ?? card.aiCertNumber}
                    cardId={card.id}
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center bg-[#0a1628] border border-white/10 rounded">
                    <Award className="w-8 h-8 text-white/20" />
                  </div>
                )}
                <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
                  <div className="bg-black/60 rounded-full px-2 py-1 flex items-center gap-1">
                    <ZoomIn className="w-3 h-3 text-white" />
                    <span className="text-white text-[10px]">Zoom</span>
                  </div>
                </div>
              </div>

              {/* Thumbnails */}
              {images.length > 1 && (
                <div className="flex gap-1 flex-wrap">
                  {images.map((img, i) => (
                    <button
                      key={i}
                      onClick={() => setActiveImg(i)}
                      className={`w-10 h-14 rounded overflow-hidden border-2 transition-colors bg-black ${
                        i === activeImg ? "border-[#c41e3a]" : "border-white/10 hover:border-white/30"
                      }`}
                    >
                      <img src={img} alt="" className="w-full h-full object-contain p-0.5" />
                    </button>
                  ))}
                </div>
              )}
              <p className="text-[9px] text-white/25 text-center">Click to zoom</p>
            </div>

            {/* ── RIGHT: Details + actions ── */}
            <div className="flex-1 min-w-0 flex flex-col gap-2">

              {/* Price */}
              <div className="flex items-baseline gap-2">
                <span className="text-2xl font-black text-[#c41e3a]">${price.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                {card.aiGradeLabel && (
                  <Badge className="bg-[#c41e3a]/20 text-[#ff6b6b] border-[#c41e3a]/30 text-[10px] px-1.5 py-0">{card.aiGradeLabel}</Badge>
                )}
              </div>

              {/* Grade box — SCO AI grade */}
              {card.aiGrade && (
                <div className="bg-[#0a1628] border border-white/10 rounded p-2">
                  <p className="text-[9px] font-bold text-white/40 uppercase tracking-wider mb-1">SCO AI Grade</p>
                  <div className="flex items-center gap-2">
                    <div className="text-2xl font-black text-[#c41e3a] leading-none">{card.aiGrade}</div>
                    <div className="grid grid-cols-2 gap-x-3 gap-y-0 text-[10px]">
                      {card.aiCentering && <div><span className="text-white/40">Ctr </span><span className="text-white">{card.aiCentering}</span></div>}
                      {card.aiCorners && <div><span className="text-white/40">Cor </span><span className="text-white">{card.aiCorners}</span></div>}
                      {card.aiEdges && <div><span className="text-white/40">Edg </span><span className="text-white">{card.aiEdges}</span></div>}
                      {card.aiSurface && <div><span className="text-white/40">Sur </span><span className="text-white">{card.aiSurface}</span></div>}
                    </div>
                  </div>
                </div>
              )}
              {/* Grade box — Third-party grade (PSA, Beckett, SGC, etc.) */}
              {card.gradeCompany && card.gradeCompany !== "none" && card.gradeScore && (
                <div className="bg-[#0a1628] border border-white/10 rounded p-2">
                  <p className="text-[9px] font-bold text-white/40 uppercase tracking-wider mb-1">{card.gradeCompany} Grade</p>
                  <div className="flex items-center gap-2">
                    <div className="text-2xl font-black text-[#E8C547] leading-none">{card.gradeScore}</div>
                    {card.certNumber && <div className="text-[10px] text-white/40">Cert #{card.certNumber}</div>}
                  </div>
                </div>
              )}

              {/* Card details */}
              <div className="space-y-0.5 text-xs">
                {card.year && <div className="flex justify-between gap-2"><span className="text-white/40 shrink-0">Year</span><span className="text-white">{card.year}</span></div>}
                {card.setName && <div className="flex justify-between gap-2"><span className="text-white/40 shrink-0">Set</span><span className="text-white text-right truncate max-w-[65%]">{card.setName}</span></div>}
                {card.cardNumber && <div className="flex justify-between gap-2"><span className="text-white/40 shrink-0">Card #</span><span className="text-white">{card.cardNumber}</span></div>}
                {card.sport && <div className="flex justify-between gap-2"><span className="text-white/40 shrink-0">Sport</span><span className="text-white capitalize">{card.sport}</span></div>}
                <div className="flex justify-between gap-2"><span className="text-white/40 shrink-0">Seller</span><span className="text-white truncate max-w-[65%]">{card.storeName || card.sellerEmail}</span></div>
              </div>

              {card.description && (
                <p className="text-[10px] text-white/40 leading-relaxed border-t border-white/10 pt-1.5 line-clamp-3">{card.description}</p>
              )}

              {/* Share */}
              <div className="relative">
                <Button
                  variant="outline"
                  size="sm"
                  className="w-full gap-1.5 border-white/15 text-white/50 hover:text-white hover:bg-white/10 text-xs h-7"
                  onClick={() => setShareOpen(v => !v)}
                >
                  <Share2 className="w-3 h-3" /> Share
                </Button>
                {shareOpen && (
                  <div className="absolute bottom-full left-0 right-0 mb-1 bg-[#0a1628] border border-white/15 rounded-lg p-1.5 flex flex-col gap-0.5 z-50 shadow-xl">
                    <button className="flex items-center gap-2 text-xs text-white/80 hover:text-white hover:bg-white/10 rounded px-2 py-1 transition-colors"
                      onClick={() => { const url = `${window.location.origin}/marketplace?card=${card.id}`; window.open(`https://twitter.com/intent/tweet?text=${encodeURIComponent(`${card.playerName} — ${card.title} $${price.toFixed(2)}`)}&url=${encodeURIComponent(url)}`, "_blank"); setShareOpen(false); }}>
                      <Twitter className="w-3 h-3 text-[#1DA1F2]" /> Share on X
                    </button>
                    <button className="flex items-center gap-2 text-xs text-white/80 hover:text-white hover:bg-white/10 rounded px-2 py-1 transition-colors"
                      onClick={() => { const url = `${window.location.origin}/marketplace?card=${card.id}`; window.open(`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}`, "_blank"); setShareOpen(false); }}>
                      <Facebook className="w-3 h-3 text-[#1877F2]" /> Share on Facebook
                    </button>
                    <button className="flex items-center gap-2 text-xs text-white/80 hover:text-white hover:bg-white/10 rounded px-2 py-1 transition-colors"
                      onClick={() => { navigator.clipboard.writeText(`${window.location.origin}/marketplace?card=${card.id}`).then(() => toast.success("Link copied!")); setShareOpen(false); }}>
                      <Link2 className="w-3 h-3 text-white/50" /> Copy link
                    </button>
                  </div>
                )}
              </div>

              {/* Action buttons */}
              <div className="flex flex-col gap-1.5 mt-auto">
                {isAuthenticated ? (
                  <>
                    {/* Add to Cart — shows checkmark + "Go to Cart" after adding */}
                    {addedToCart ? (
                      <div className="flex gap-1.5">
                        <div className="flex-1 flex items-center justify-center gap-1.5 bg-green-700 rounded text-white text-xs font-bold h-9">
                          <Check className="w-4 h-4" /> Added to Cart!
                        </div>
                        <Button
                          size="sm"
                          className="bg-white text-[#0a1628] hover:bg-white/90 font-bold text-xs h-9 px-3"
                          onClick={onClose}
                        >
                          Go to Cart
                        </Button>
                      </div>
                    ) : (
                      <Button
                        className={`w-full gap-2 font-bold h-9 text-sm ${inCart ? "bg-green-700 hover:bg-green-800 text-white" : "bg-[#c41e3a] hover:bg-[#a01830] text-white"}`}
                        onClick={handleAddToCart}
                      >
                        {inCart ? <><Check className="w-4 h-4" />In Cart — Remove</> : <><ShoppingCart className="w-4 h-4" />Add to Cart</>}
                      </Button>
                    )}

                    {/* Buy Now — Stripe checkout */}
                    <Button
                      variant="outline"
                      className="w-full gap-2 border-white/20 text-white hover:bg-white/10 font-bold h-9 text-sm"
                      onClick={handleBuyNow}
                      disabled={createCheckout.isPending}
                    >
                      {createCheckout.isPending
                        ? <><Loader2 className="w-4 h-4 animate-spin" /> Opening Stripe...</>
                        : <>⚡ Buy Now</>}
                    </Button>

                    {/* Admin: Replace Photos */}
                    {isAdmin && (
                      <Button
                        variant="outline"
                        className="w-full gap-1.5 border-yellow-500/40 text-yellow-400 hover:bg-yellow-500/10 text-xs h-7"
                        onClick={() => setCameraOpen(true)}
                      >
                        <Camera className="w-3 h-3" /> Replace Photos
                      </Button>
                    )}
                  </>
                ) : (
                  <Button asChild className="w-full bg-[#c41e3a] hover:bg-[#a01830] text-white font-bold h-9">
                    <a href={getLoginUrl()}>Sign In to Purchase</a>
                  </Button>
                )}
                {/* View Full Profile */}
                <a href={`/card/${card.id}`}
                  className="flex items-center justify-center gap-1.5 text-xs text-white/30 hover:text-white/60 transition-colors py-1"
                  onClick={onClose}>
                  <ExternalLink className="w-3 h-3" /> View Full Card Profile
                </a>
              </div>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {card && isAdmin && (
        <CardCameraCapture
          open={cameraOpen}
          onClose={() => setCameraOpen(false)}
          cardId={card.id}
          cardTitle={card.title}
          onSaved={() => { toast.success("Photos updated! Refresh to see changes."); setCameraOpen(false); }}
        />
      )}
    </>
  );
}
