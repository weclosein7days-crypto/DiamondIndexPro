import { useState } from "react";
import { Link } from "wouter";
import { ChevronDown, AlertCircle, Video, FileText, Shield, Mail, Twitter, Facebook, Instagram, Youtube } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";

// --- FAQ Data (Schema.org structured for SEO) ---------------------------------
const FAQS = [
  {
    question: "What is card grading and why does it matter?",
    answer: "Card grading is a professional evaluation of a trading card's condition on a scale of 1-10. It assesses centering, corners, edges, and surface quality. Graded cards command higher prices and buyer confidence because the grade is verified by an independent third party — making them far easier to buy and sell.",
  },
  {
    question: "How does SportCardsOnline AI grading (SCG) work?",
    answer: "Our AI grading analyzes high-resolution photos of your card's front and back to evaluate centering, corners, edges, and surface. You receive an SCG grade within minutes. Cards are then slabbed with professional labels. SCG grading is faster and more affordable than traditional services while maintaining professional accuracy.",
  },
  {
    question: "What is the difference between PSA, Beckett, SGC, and SCG?",
    answer: "PSA, Beckett, and SGC are established grading companies with strong market recognition. SCG (SportCardsOnline Grading) is our AI-powered grading service — faster, more affordable, and ideal for newer collectors and value-conscious investors who want professional documentation without long wait times.",
  },
  {
    question: "How do I sell my cards on SportCardsOnline?",
    answer: "Grade your cards with SCG, then list them on the marketplace with your asking price. When a buyer purchases, you ship the card directly to them. You keep 95% — we charge a flat 5% platform fee. No hidden costs, no monthly fees on the free plan.",
  },
  {
    question: "How does trading work on SportCardsOnline?",
    answer: "Use the Trade Center to browse cards you want, select cards from your collection to offer, and send a trade proposal. Both parties negotiate in the messaging thread. Once agreed, both parties ship their cards to SCO — we verify both cards, then forward each card to the correct recipient. This protects both parties from fraud.",
  },
  {
    question: "What sports and card types do you support?",
    answer: "We support baseball, basketball, football, hockey, and soccer cards — including rookies, vintage, modern, inserts, parallels, autographs, and memorabilia cards from all major manufacturers (Topps, Panini, Upper Deck, Bowman, Fleer, and more).",
  },
  {
    question: "Is my collection private or public?",
    answer: "Your personal collection is private by default. You can choose to list individual cards on the marketplace or set up a public store. Other collectors can only see cards you explicitly list for sale or trade.",
  },
  {
    question: "What is the affiliate/referral program?",
    answer: "Share your personal referral link and earn credits every time someone signs up through it. You earn credits equal to their plan value. When your referrals refer others, you earn a 25% bonus on those credits too — two layers of earning. Referral attribution lasts 30 days from first visit.",
  },
  {
    question: "How do auctions work?",
    answer: "Sellers can list cards as timed auctions with a starting bid and optional reserve price. Bidders compete in real time. When the auction ends, the highest bidder wins and pays. The seller ships the card and receives 95% of the final sale price.",
  },
  {
    question: "What payment methods are accepted?",
    answer: "We accept all major credit cards, debit cards, and PayPal through our secure Stripe-powered checkout. All transactions are encrypted and PCI-compliant.",
  },
];

// --- Sales Final Disclosure ---------------------------------------------------
function SalesFinalDisclosure() {
  const [open, setOpen] = useState(false);
  return (
    <div className="border border-orange-500/40 rounded-lg overflow-hidden bg-orange-950/30">
      <button
        onClick={() => setOpen(!open)}
        className="w-full flex items-center justify-between p-4 hover:bg-orange-950/50 transition text-left"
      >
        <div className="flex items-center gap-3">
          <AlertCircle className="w-5 h-5 text-orange-400 flex-shrink-0" />
          <div>
            <p className="font-bold text-orange-200 text-sm">PLEASE READ: All Sales Are Final</p>
            <p className="text-xs text-orange-300/70">Refund policy, dispute process, and video evidence requirements</p>
          </div>
        </div>
        <ChevronDown className={`w-5 h-5 text-orange-400 flex-shrink-0 transition-transform ${open ? "rotate-180" : ""}`} />
      </button>
      {open && (
        <div className="border-t border-orange-500/30 p-4 bg-[#0a1628] space-y-3 text-sm text-gray-300 leading-relaxed">
          <p className="font-semibold text-orange-300">SALES ARE FINAL — NO REFUNDS</p>
          <p>Purchases of trading cards are final. We cannot issue refunds because of the grading and inherent value of cards. We cannot determine if a card was altered, switched, damaged, or otherwise compromised once it has been mailed out. Responsibility for the card's condition, authenticity, and integrity lies with the buyer, seller, and shipping carrier.</p>

          <div className="flex items-start gap-2 mt-3">
            <Video className="w-4 h-4 text-orange-400 flex-shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold text-orange-200">VIDEO EVIDENCE REQUIREMENTS</p>
              <p className="text-gray-400 mt-1">If a card is missing or the wrong card was shipped, you MUST provide video evidence of opening the package. The video must show: the sealed envelope, breaking the seal, opening it, the card inside, pulling it out, placing it on a table, turning it over, and clearly explaining the issue. This must be done immediately upon receipt.</p>
            </div>
          </div>

          <div className="flex items-start gap-2 mt-3">
            <FileText className="w-4 h-4 text-orange-400 flex-shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold text-orange-200">DISPUTE PROCESS</p>
              <p className="text-gray-400 mt-1">Any dispute without conclusive video evidence will result in funds being released to the seller. You may then pursue civil court action. We strongly encourage videotaping every package opening, especially for high-value items.</p>
            </div>
          </div>

          <div className="flex items-start gap-2 mt-3">
            <Shield className="w-4 h-4 text-orange-400 flex-shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold text-orange-200">SHIPPER RESPONSIBILITIES</p>
              <p className="text-gray-400 mt-1">If the package is damaged, refuse it. If you're the shipper, require a signature. If you accept the package, you own it. For high-value transactions, consider mailing the card to SCO and we can handle the transaction — call for details.</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// --- Terms of Service Modal ---------------------------------------------------
function TermsModal({ open, onClose }: { open: boolean; onClose: () => void }) {
  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto bg-[#0d1f3c] border-[#1e3a5f] text-gray-200">
        <DialogHeader>
          <DialogTitle className="text-white text-xl">Terms of Service</DialogTitle>
        </DialogHeader>
        <div className="space-y-4 text-sm text-gray-300 leading-relaxed">
          <p className="text-gray-400 text-xs">Last updated: January 2026</p>

          <section>
            <h3 className="font-semibold text-white mb-1">1. Acceptance of Terms</h3>
            <p>By accessing or using SportCardsOnline.com, you agree to be bound by these Terms of Service. If you do not agree, please do not use our platform.</p>
          </section>

          <section>
            <h3 className="font-semibold text-white mb-1">2. Platform Services</h3>
            <p>SportCardsOnline provides a marketplace for buying, selling, trading, and grading sports trading cards. We offer AI-powered grading (SCG), live auctions, peer-to-peer trading with escrow protection, and a collector community.</p>
          </section>

          <section>
            <h3 className="font-semibold text-white mb-1">3. User Accounts</h3>
            <p>You must be 18 or older to create an account. You are responsible for maintaining the security of your account credentials. You may not use another person's account or share your login information.</p>
          </section>

          <section>
            <h3 className="font-semibold text-white mb-1">4. Arena Rules</h3>
            <p>All cards listed must be authentic. Counterfeit, altered, or misrepresented cards are strictly prohibited and will result in immediate account termination. Sellers receive 95% of the sale price; SportCardsOnline retains a 5% platform fee.</p>
          </section>

          <section>
            <h3 className="font-semibold text-white mb-1">5. Sales Are Final</h3>
            <p>All sales are final. No refunds will be issued except in cases of verified fraud with video evidence as described in our Sales Policy. By completing a purchase, you acknowledge this policy.</p>
          </section>

          <section>
            <h3 className="font-semibold text-white mb-1">6. Grading Services</h3>
            <p>SCG AI grading is an independent assessment. Grades are based on submitted images and are final once issued. SportCardsOnline is not responsible for discrepancies between AI grades and grades issued by other grading companies.</p>
          </section>

          <section>
            <h3 className="font-semibold text-white mb-1">7. Trade Escrow</h3>
            <p>For protected trades, both parties ship cards to SportCardsOnline. We verify both cards before forwarding to the respective recipients. This service is provided as a convenience; SportCardsOnline is not liable for carrier damage or loss during shipping.</p>
          </section>

          <section>
            <h3 className="font-semibold text-white mb-1">8. Prohibited Conduct</h3>
            <p>You may not: list counterfeit cards, manipulate bids, create fake accounts, harass other users, or use the platform for money laundering. Violations result in permanent account termination and potential legal action.</p>
          </section>

          <section>
            <h3 className="font-semibold text-white mb-1">9. Limitation of Liability</h3>
            <p>SportCardsOnline is not liable for losses arising from transactions between users, shipping issues, or grading disputes. Our maximum liability is limited to the platform fee collected on any single transaction.</p>
          </section>

          <section>
            <h3 className="font-semibold text-white mb-1">10. Contact</h3>
            <p>For legal inquiries: <a href="mailto:legal@sportcardsonline.com" className="text-[#C41E3A] hover:underline">legal@sportcardsonline.com</a></p>
          </section>
        </div>
      </DialogContent>
    </Dialog>
  );
}

// --- Privacy Policy Modal -----------------------------------------------------
function PrivacyModal({ open, onClose }: { open: boolean; onClose: () => void }) {
  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto bg-[#0d1f3c] border-[#1e3a5f] text-gray-200">
        <DialogHeader>
          <DialogTitle className="text-white text-xl">Privacy Policy</DialogTitle>
        </DialogHeader>
        <div className="space-y-4 text-sm text-gray-300 leading-relaxed">
          <p className="text-gray-400 text-xs">Last updated: January 2026</p>

          <section>
            <h3 className="font-semibold text-white mb-1">1. Information We Collect</h3>
            <p>We collect information you provide (name, email, shipping address, payment info), usage data (pages visited, cards viewed), and device information (IP address, browser type) to operate and improve our platform.</p>
          </section>

          <section>
            <h3 className="font-semibold text-white mb-1">2. How We Use Your Information</h3>
            <p>We use your information to: process transactions, provide grading services, facilitate trades, send order updates, personalize your experience, prevent fraud, and comply with legal obligations.</p>
          </section>

          <section>
            <h3 className="font-semibold text-white mb-1">3. Referral Tracking</h3>
            <p>We use cookies and IP address logging to track referrals for our affiliate program. Referral attribution lasts 30 days from first visit. This data is used solely to calculate referral credits and is not shared with third parties.</p>
          </section>

          <section>
            <h3 className="font-semibold text-white mb-1">4. Information Sharing</h3>
            <p>We share information with: payment processors (Stripe) for transactions, shipping carriers for order fulfillment, and law enforcement when legally required. We do not sell your personal data to third parties.</p>
          </section>

          <section>
            <h3 className="font-semibold text-white mb-1">5. Data Security</h3>
            <p>We use industry-standard encryption (TLS/SSL) for all data transmission. Payment information is processed by Stripe and never stored on our servers. We conduct regular security audits.</p>
          </section>

          <section>
            <h3 className="font-semibold text-white mb-1">6. Your Rights</h3>
            <p>You may request access to, correction of, or deletion of your personal data at any time. To exercise these rights, contact us at privacy@sportcardsonline.com. Account deletion removes all personal data within 30 days.</p>
          </section>

          <section>
            <h3 className="font-semibold text-white mb-1">7. Cookies</h3>
            <p>We use essential cookies for authentication, preference cookies for your settings, and analytics cookies to understand platform usage. You can disable non-essential cookies in your browser settings.</p>
          </section>

          <section>
            <h3 className="font-semibold text-white mb-1">8. Contact</h3>
            <p>For privacy questions: <a href="mailto:privacy@sportcardsonline.com" className="text-[#C41E3A] hover:underline">privacy@sportcardsonline.com</a></p>
          </section>
        </div>
      </DialogContent>
    </Dialog>
  );
}

// --- FAQ Accordion ------------------------------------------------------------
function FAQSection() {
  const [expanded, setExpanded] = useState<number | null>(null);
  return (
    <div
      className="space-y-2"
      itemScope
      itemType="https://schema.org/FAQPage"
    >
      {FAQS.map((faq, idx) => (
        <div
          key={idx}
          className="border border-[#1e3a5f] rounded-lg overflow-hidden hover:border-[#C41E3A]/40 transition-colors"
          itemScope
          itemType="https://schema.org/Question"
        >
          <button
            onClick={() => setExpanded(expanded === idx ? null : idx)}
            className="w-full px-5 py-3 flex items-center justify-between hover:bg-[#0d1f3c]/80 transition-colors text-left"
          >
            <h3 className="font-medium text-gray-200 text-sm pr-4" itemProp="name">{faq.question}</h3>
            <ChevronDown className={`w-4 h-4 text-gray-400 flex-shrink-0 transition-transform ${expanded === idx ? "rotate-180" : ""}`} />
          </button>
          {/* Answer always in DOM for Googlebot — visually hidden when collapsed */}
          <div
            className={`px-5 bg-[#0a1628] border-t border-[#1e3a5f] overflow-hidden transition-all duration-200 ${expanded === idx ? "py-3 max-h-96" : "max-h-0 border-t-0"}`}
            itemScope
            itemType="https://schema.org/Answer"
          >
            <p className="text-gray-400 text-sm leading-relaxed" itemProp="text">{faq.answer}</p>
          </div>
        </div>
      ))}
    </div>
  );
}

// --- Main Footer --------------------------------------------------------------
export default function Footer() {
  const [showTerms, setShowTerms] = useState(false);
  const [showPrivacy, setShowPrivacy] = useState(false);
  const [showFAQ, setShowFAQ] = useState(false);
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-[#060e1a] border-t border-[#1e3a5f] mt-16">
      {/* FAQ Section — collapsed by default */}
      <div className="max-w-5xl mx-auto px-4 py-6">
        <button
          onClick={() => setShowFAQ(!showFAQ)}
          className="w-full flex items-center justify-between px-6 py-4 bg-[#0d1f3c] border border-[#1e3a5f] rounded-xl hover:border-[#C41E3A]/50 transition-colors group"
        >
          <div className="text-left">
            <h2 className="text-xl font-bold text-white group-hover:text-[#C41E3A] transition-colors" style={{ fontFamily: "Oswald, sans-serif" }}>
              Frequently Asked Questions
            </h2>
            <p className="text-gray-400 text-xs mt-0.5">Everything you need to know about SportCardsOnline</p>
          </div>
          <ChevronDown className={`w-6 h-6 text-gray-400 flex-shrink-0 transition-transform duration-300 ${showFAQ ? "rotate-180 text-[#C41E3A]" : ""}`} />
        </button>
        {showFAQ && (
          <div className="mt-4 pb-4">
            <FAQSection />
          </div>
        )}
      </div>

      {/* Sales Final Disclosure */}
      <div className="max-w-5xl mx-auto px-4 pb-8">
        <SalesFinalDisclosure />
      </div>

      {/* Main Footer Links */}
      <div className="border-t border-[#1e3a5f]">
        <div className="max-w-6xl mx-auto px-4 py-10 grid grid-cols-2 md:grid-cols-4 gap-8">

          {/* Brand */}
          <div className="col-span-2 md:col-span-1">
            <p className="font-bold text-white text-lg mb-1" style={{ fontFamily: "Oswald, sans-serif" }}>
              Sport<span className="text-[#C41E3A]">CardsOnline</span>.com
            </p>
            <p className="text-gray-400 text-xs leading-relaxed mb-4">
              The premier AI-powered sports card grading, marketplace, and trading platform for collectors everywhere.
            </p>
            <div className="flex gap-3">
              <a href="https://twitter.com/sportcardsonline" target="_blank" rel="noopener noreferrer" className="text-gray-500 hover:text-[#C41E3A] transition-colors">
                <Twitter className="w-4 h-4" />
              </a>
              <a href="https://facebook.com/sportcardsonline" target="_blank" rel="noopener noreferrer" className="text-gray-500 hover:text-[#C41E3A] transition-colors">
                <Facebook className="w-4 h-4" />
              </a>
              <a href="https://instagram.com/sportcardsonline" target="_blank" rel="noopener noreferrer" className="text-gray-500 hover:text-[#C41E3A] transition-colors">
                <Instagram className="w-4 h-4" />
              </a>
              <a href="https://youtube.com/@sportcardsonline" target="_blank" rel="noopener noreferrer" className="text-gray-500 hover:text-[#C41E3A] transition-colors">
                <Youtube className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Arena */}
          <div>
            <h4 className="text-white font-semibold text-sm mb-3 uppercase tracking-wide">Arena</h4>
            <ul className="space-y-2 text-xs text-gray-400">
              <li><Link href="/arena" className="hover:text-[#C41E3A] transition-colors">Browse Cards</Link></li>
              <li><Link href="/arena?sport=baseball" className="hover:text-[#C41E3A] transition-colors">Baseball Cards</Link></li>
              <li><Link href="/arena?sport=basketball" className="hover:text-[#C41E3A] transition-colors">Basketball Cards</Link></li>
              <li><Link href="/arena?sport=football" className="hover:text-[#C41E3A] transition-colors">Football Cards</Link></li>
              <li><Link href="/arena?sport=hockey" className="hover:text-[#C41E3A] transition-colors">Hockey Cards</Link></li>
              <li><Link href="/auctions" className="hover:text-[#C41E3A] transition-colors">Live Auctions</Link></li>
              <li><Link href="/trades" className="hover:text-[#C41E3A] transition-colors">Trade Center</Link></li>
            </ul>
          </div>

          {/* Services */}
          <div>
            <h4 className="text-white font-semibold text-sm mb-3 uppercase tracking-wide">Services</h4>
            <ul className="space-y-2 text-xs text-gray-400">
              <li><Link href="/grade" className="hover:text-[#C41E3A] transition-colors">AI Card Grading (SCG)</Link></li>
              <li><Link href="/collection" className="hover:text-[#C41E3A] transition-colors">My Collection</Link></li>
              <li><Link href="/credits" className="hover:text-[#C41E3A] transition-colors">Subscription Plans</Link></li>
              <li><Link href="/credits" className="hover:text-[#C41E3A] transition-colors">Buy Credits</Link></li>
              <li><Link href="/dashboard" className="hover:text-[#C41E3A] transition-colors">Seller Dashboard</Link></li>
              <li><Link href="/referral" className="hover:text-[#C41E3A] transition-colors">Referral Program</Link></li>
            </ul>
          </div>

          {/* Company */}
          <div>
            <h4 className="text-white font-semibold text-sm mb-3 uppercase tracking-wide">Company</h4>
            <ul className="space-y-2 text-xs text-gray-400">
              <li><Link href="/contact" className="hover:text-[#C41E3A] transition-colors flex items-center gap-1"><Mail className="w-3 h-3" /> Contact Us</Link></li>
              <li>
                <button onClick={() => setShowTerms(true)} className="hover:text-[#C41E3A] transition-colors text-left">
                  Terms of Service
                </button>
              </li>
              <li>
                <button onClick={() => setShowPrivacy(true)} className="hover:text-[#C41E3A] transition-colors text-left">
                  Privacy Policy
                </button>
              </li>
              <li><span className="text-gray-600">Shipping Policy</span></li>
              <li><span className="text-gray-600">Grading Standards</span></li>
              <li><span className="text-gray-600">About SCG</span></li>
            </ul>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t border-[#1e3a5f] bg-[#040a12]">
        <div className="max-w-6xl mx-auto px-4 py-4 flex flex-col md:flex-row items-center justify-between gap-2">
          <p className="text-gray-600 text-xs">
            &copy; {currentYear} SportCardsOnline.com. All rights reserved.
          </p>
          <div className="flex items-center gap-4 text-xs text-gray-600">
            <button onClick={() => setShowTerms(true)} className="hover:text-gray-400 transition-colors">Terms</button>
            <span>|</span>
            <button onClick={() => setShowPrivacy(true)} className="hover:text-gray-400 transition-colors">Privacy</button>
            <span>|</span>
            <span>All sales are final</span>
            <span>|</span>
            <span>5% platform fee</span>
          </div>
        </div>
      </div>

      {/* Modals */}
      <TermsModal open={showTerms} onClose={() => setShowTerms(false)} />
      <PrivacyModal open={showPrivacy} onClose={() => setShowPrivacy(false)} />
    </footer>
  );
}
