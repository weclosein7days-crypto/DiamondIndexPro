/**
 * CardCarousel — horizontal scrollable row of cards.
 * Each card renders with an auto-matched grading company label (BGS, PSA, SCG, or no label).
 */
import { useRef } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { SlabFrame } from "@/components/SlabFrame";

interface CarouselCard {
  id: number;
  title: string;
  playerName?: string | null;
  frontImageUrl?: string | null;
  price?: string | null;
  aiGrade?: string | null;
  aiGradeLabel?: string | null;
  sport?: string | null;
  year?: string | null;
  setName?: string | null;
  cardNumber?: string | null;
  certNumber?: string | null;
  labelColor?: string | null;
  labelBg?: string | null;
  labelBorder?: string | null;
  labelMode?: string | null;
  isVaulted?: boolean | null;
  isMainStore?: boolean | null;
  gradeCompany?: string | null;
  gradeScore?: string | null;
}

interface CardCarouselProps {
  cards: CarouselCard[];
  onCardClick: (card: CarouselCard) => void;
  /** If true, show 2 rows stacked; otherwise single row */
  twoRows?: boolean;
  cardWidth?: number; // px, default 130
  isLoading?: boolean;
}

export function CardCarousel({ cards, onCardClick, twoRows = false, cardWidth = 130, isLoading = false }: CardCarouselProps) {
  const scrollRef = useRef<HTMLDivElement>(null);

  const scroll = (dir: "left" | "right") => {
    const el = scrollRef.current;
    if (!el) return;
    const amount = el.clientWidth * 0.75;
    el.scrollBy({ left: dir === "right" ? amount : -amount, behavior: "smooth" });
  };

  if (isLoading) {
    return (
      <div className="flex gap-3 overflow-hidden">
        {Array.from({ length: 8 }).map((_, i) => (
          <div key={i} className="shrink-0 animate-pulse" style={{ width: cardWidth }}>
            <div className="rounded-lg bg-white/5" style={{ aspectRatio: "2/3" }} />
            <div className="h-2.5 bg-white/5 rounded mt-1.5 mx-0.5" />
            <div className="h-2.5 bg-white/5 rounded mt-1 mx-0.5 w-2/3" />
          </div>
        ))}
      </div>
    );
  }

  if (!cards || cards.length === 0) return null;

  const rows = twoRows
    ? [cards.slice(0, Math.ceil(cards.length / 2)), cards.slice(Math.ceil(cards.length / 2))]
    : [cards];

  return (
    <div className="relative group/carousel">
      {/* Left arrow */}
      <button
        onClick={() => scroll("left")}
        className="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-3 z-10 w-8 h-8 rounded-full bg-black/80 border border-white/20 text-white flex items-center justify-center opacity-0 group-hover/carousel:opacity-100 transition-opacity hover:bg-[#c41e3a] hover:border-[#c41e3a] shadow-lg"
        aria-label="Scroll left"
      >
        <ChevronLeft className="w-4 h-4" />
      </button>

      {/* Scrollable container */}
      <div
        ref={scrollRef}
        className="overflow-x-auto pb-1"
        style={{ scrollbarWidth: "none", msOverflowStyle: "none" }}
      >
        <div className="flex flex-col gap-3" style={{ minWidth: "max-content" }}>
          {rows.map((rowCards, rowIdx) => (
            <div key={rowIdx} className="flex gap-3">
              {rowCards.map((card) => (
                <CardChip
                  key={card.id}
                  card={card}
                  width={cardWidth}
                  onClick={() => onCardClick(card)}
                />
              ))}
            </div>
          ))}
        </div>
      </div>

      {/* Right arrow */}
      <button
        onClick={() => scroll("right")}
        className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-3 z-10 w-8 h-8 rounded-full bg-black/80 border border-white/20 text-white flex items-center justify-center opacity-0 group-hover/carousel:opacity-100 transition-opacity hover:bg-[#c41e3a] hover:border-[#c41e3a] shadow-lg"
        aria-label="Scroll right"
      >
        <ChevronRight className="w-4 h-4" />
      </button>
    </div>
  );
}

function CardChip({ card, width, onClick }: { card: CarouselCard; width: number; onClick: () => void }) {
  const price = parseFloat(card.price ?? "0");
  const slabHeight = Math.round(width * 1.5); // 2:3 aspect ratio

  return (
    <div
      onClick={onClick}
      className="shrink-0 cursor-pointer group/chip"
      style={{ width }}
    >
      {/* Auto-matched grading company slab label */}
      <div
        className="group-hover/chip:scale-[1.02] transition-transform duration-200"
        style={{ height: slabHeight }}
      >
        <SlabFrame
          imageUrl={card.frontImageUrl}
          altText={card.playerName || card.title}
          labelColor={(card.labelColor as any) ?? "dark"}
          labelBg={(card.labelBg as any) ?? "black-silk"}
          labelBorder={(card.labelBorder as any) ?? "black"}
          grade={card.gradeScore || card.aiGrade}
          gradeLabel={card.aiGradeLabel}
          gradeCompany={card.gradeCompany}
          playerName={card.playerName}
          setName={card.setName}
          year={card.year}
          cardNumber={card.cardNumber}
          certNumber={card.certNumber}
          cardId={card.id}
        />
      </div>

      {/* Price below the slab */}
      <div className="mt-1.5 px-0.5">
        <p className="text-[10px] text-white/75 font-semibold line-clamp-1 leading-tight group-hover/chip:text-white transition-colors">
          {card.playerName || card.title}
        </p>
        <p className="text-[11px] font-bold text-[#c41e3a] mt-0.5">
          ${price.toLocaleString("en-US", { minimumFractionDigits: 0, maximumFractionDigits: 0 })}
        </p>
      </div>
    </div>
  );
}
