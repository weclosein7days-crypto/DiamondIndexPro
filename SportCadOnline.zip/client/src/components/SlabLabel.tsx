/**
 * SlabLabel — SCG slab label component (front + back)
 *
 * Backgrounds: white-silk | black-silk | red-silk
 * Border colors: white | orange | red | blue | black
 * Border thickness: ~6px (≈ 1/4 inch at 96 dpi scale)
 *
 * Used in:
 *  - MyCollection bulk print
 *  - MyStore single-card print
 *  - GradeCards slab preview
 */

export const LABEL_BACKGROUNDS = [
  {
    value: "white-silk",
    label: "White Silk",
    url: "https://d2xsxph8kpxj0f.cloudfront.net/310519663482618714/HBSXFxHmEnEJMgVvzKnhpZ/silk-white_4e696371.png",
    textColor: "#111111",
    subTextColor: "#444444",
    dividerColor: "rgba(0,0,0,0.15)",
    gradeColor: "#111111",
    subGradeColor: "#1d4ed8",
    certColor: "#555555",
  },
  {
    value: "black-silk",
    label: "Black Silk",
    url: "https://d2xsxph8kpxj0f.cloudfront.net/310519663482618714/HBSXFxHmEnEJMgVvzKnhpZ/silk-black_68b626e4.png",
    textColor: "#ffffff",
    subTextColor: "#cccccc",
    dividerColor: "rgba(255,255,255,0.15)",
    gradeColor: "#ffffff",
    subGradeColor: "#60a5fa",
    certColor: "#aaaaaa",
  },
  {
    value: "red-silk",
    label: "Red Silk",
    url: "https://d2xsxph8kpxj0f.cloudfront.net/310519663482618714/HBSXFxHmEnEJMgVvzKnhpZ/silk-red_40963c62.png",
    textColor: "#ffffff",
    subTextColor: "#ffcccc",
    dividerColor: "rgba(255,255,255,0.2)",
    gradeColor: "#ffffff",
    subGradeColor: "#fde68a",
    certColor: "#ffbbbb",
  },
] as const;

export const LABEL_BORDER_COLORS = [
  { value: "white",  label: "White",  hex: "#ffffff" },
  { value: "orange", label: "Orange", hex: "#f97316" },
  { value: "red",    label: "Red",    hex: "#c41e3a" },
  { value: "blue",   label: "Blue",   hex: "#1d4ed8" },
  { value: "black",  label: "Black",  hex: "#000000" },
] as const;

export type LabelBackground = typeof LABEL_BACKGROUNDS[number]["value"];
export type LabelBorderColor = typeof LABEL_BORDER_COLORS[number]["value"];

export interface SlabLabelData {
  // Card info
  playerName?: string;
  cardCompany?: string;   // e.g. "Topps", "Panini", "Upper Deck"
  year?: string;
  setName?: string;
  cardNumber?: string;
  sport?: string;
  // Grades
  overallGrade?: number | string;
  gradeLabel?: string;    // e.g. "MINT GEM"
  centering?: number | string;
  corners?: number | string;
  edges?: number | string;
  surface?: number | string;
  // Identity
  certNumber?: string;
  cardId?: number;        // used to build QR verification URL
  // Style
  background?: LabelBackground;
  borderColor?: LabelBorderColor;
  // Logo
  logoUrl?: string;
}

const SCG_LOGO = "https://d2xsxph8kpxj0f.cloudfront.net/310519663482618714/HBSXFxHmEnEJMgVvzKnhpZ/logo_white_border_bb86c840.png";
const BORDER_PX = 6; // ≈ 1/4 inch

function gradeNameFromScore(score: number | string | undefined): string {
  const n = Number(score);
  if (isNaN(n)) return "";
  if (n === 10) return "MINT GEM";
  if (n >= 9.5) return "GEM MINT";
  if (n >= 9)   return "MINT";
  if (n >= 8.5) return "NM-MT+";
  if (n >= 8)   return "NM-MT";
  if (n >= 7.5) return "NM+";
  if (n >= 7)   return "NM";
  if (n >= 6)   return "EX-MT";
  if (n >= 5)   return "EX";
  if (n >= 4)   return "VG-EX";
  if (n >= 3)   return "VG";
  if (n >= 2)   return "GOOD";
  return "POOR";
}

/** Returns the inline HTML string for a FRONT label (for print windows) */
export function buildFrontLabelHtml(card: SlabLabelData, verifyBaseUrl = "https://www.sportcardsonline.com"): string {
  const bg = LABEL_BACKGROUNDS.find(b => b.value === (card.background || "white-silk")) ?? LABEL_BACKGROUNDS[0];
  const border = LABEL_BORDER_COLORS.find(b => b.value === (card.borderColor || "red")) ?? LABEL_BORDER_COLORS[2];
  const overlayBg = bg.value === "white-silk" ? "rgba(255,255,255,0.18)" : "rgba(0,0,0,0.32)";
  const gradeNum = card.overallGrade ? parseFloat(String(card.overallGrade)) : null;
  const gradeLabelText = gradeNum ? gradeNameFromScore(gradeNum) : (card.gradeLabel || null);
  const certNum = card.certNumber || "N/A";
  const verifyUrl = card.cardId ? `${verifyBaseUrl}/verify/${card.cardId}` : `${verifyBaseUrl}/verify/${certNum}`;
  const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=72x72&data=${encodeURIComponent(verifyUrl)}&bgcolor=ffffff&color=000000&margin=2`;

  return `
<div class="scg-label scg-front" style="
  width:320px;
  border-radius:14px;
  overflow:hidden;
  box-shadow:0 6px 32px rgba(0,0,0,0.45);
  border:${BORDER_PX}px solid ${border.hex};
  background-image:url('${bg.url}');
  background-size:cover;
  background-position:center;
  font-family:'Oswald',sans-serif;
  position:relative;
">
  <!-- Semi-transparent overlay for readability -->
  <div style="position:absolute;inset:0;background:${bg.value === 'white-silk' ? 'rgba(255,255,255,0.18)' : 'rgba(0,0,0,0.32)'};pointer-events:none;"></div>

  <!-- Content -->
  <div style="position:relative;padding:14px 16px 12px;">

    <!-- TOP ROW: Logo left | Card company right -->
    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:10px;">
      <div style="display:flex;align-items:center;gap:8px;">
        <img src="${SCG_LOGO}" style="height:30px;width:auto;" alt="SCG" />
        <div style="font-size:13px;font-weight:900;letter-spacing:2px;color:${bg.textColor};text-shadow:0 1px 3px rgba(0,0,0,0.5);">SCG GRADING</div>
      </div>
      ${card.cardCompany ? `<div style="font-size:10px;font-weight:700;color:${bg.subTextColor};letter-spacing:1px;text-transform:uppercase;text-shadow:0 1px 2px rgba(0,0,0,0.4);">${card.cardCompany}</div>` : ""}
    </div>

    <!-- DIVIDER -->
    <div style="height:1px;background:${border.hex};opacity:0.7;margin-bottom:10px;"></div>

    <!-- PLAYER NAME -->
    <div style="font-size:22px;font-weight:900;color:${bg.textColor};letter-spacing:0.5px;line-height:1.1;text-shadow:0 1px 4px rgba(0,0,0,0.5);margin-bottom:4px;">${card.playerName || "—"}</div>

    <!-- YEAR / SET / CARD# -->
    <div style="font-size:11px;color:${bg.subTextColor};margin-bottom:12px;letter-spacing:0.5px;text-shadow:0 1px 2px rgba(0,0,0,0.4);">
      ${[card.year, card.setName, card.cardNumber ? `#${card.cardNumber}` : ""].filter(Boolean).join("  ·  ")}
    </div>

    <!-- DIVIDER -->
    <div style="height:1px;background:${bg.dividerColor};margin-bottom:10px;"></div>

    <!-- GRADE ROW: big grade number + name left | QR right -->
    <div style="display:flex;align-items:center;justify-content:space-between;">
      <div>
        <div style="font-size:52px;font-weight:900;color:${border.hex};line-height:1;text-shadow:0 2px 8px rgba(0,0,0,0.5);">${gradeNum || "—"}</div>
        <div style="font-size:13px;font-weight:700;color:${bg.textColor};letter-spacing:2px;text-transform:uppercase;text-shadow:0 1px 3px rgba(0,0,0,0.4);">${gradeLabelText || ''}</div>
        <div style="font-size:9px;color:${bg.certColor};margin-top:4px;letter-spacing:1px;">CERT# ${certNum}</div>
      </div>
      <div style="text-align:center;">
        <img src="${qrUrl}" style="width:72px;height:72px;border-radius:6px;border:2px solid ${border.hex};" alt="QR" />
        <div style="font-size:7px;color:${bg.certColor};margin-top:3px;letter-spacing:0.5px;">SCAN TO VERIFY</div>
      </div>
    </div>

  </div>
</div>`;
}

/** Returns the inline HTML string for a BACK label (for print windows) */
export function buildBackLabelHtml(card: SlabLabelData, verifyBaseUrl = "https://www.sportcardsonline.com"): string {
  const bg = LABEL_BACKGROUNDS.find(b => b.value === (card.background || "white-silk")) ?? LABEL_BACKGROUNDS[0];
  const border = LABEL_BORDER_COLORS.find(b => b.value === (card.borderColor || "red")) ?? LABEL_BORDER_COLORS[2];
  const certNum = card.certNumber || "N/A";
  const verifyUrl = card.cardId ? `${verifyBaseUrl}/verify/${card.cardId}` : `${verifyBaseUrl}/verify/${certNum}`;
  const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=80x80&data=${encodeURIComponent(verifyUrl)}&bgcolor=ffffff&color=000000&margin=2`;

  const subGrades = [
    { label: "Centering", val: card.centering },
    { label: "Corners",   val: card.corners },
    { label: "Edges",     val: card.edges },
    { label: "Surface",   val: card.surface },
  ];

  return `
<div class="scg-label scg-back" style="
  width:320px;
  border-radius:14px;
  overflow:hidden;
  box-shadow:0 6px 32px rgba(0,0,0,0.45);
  border:${BORDER_PX}px solid ${border.hex};
  background-image:url('${bg.url}');
  background-size:cover;
  background-position:center;
  font-family:'Oswald',sans-serif;
  position:relative;
">
  <div style="position:absolute;inset:0;background:${bg.value === 'white-silk' ? 'rgba(255,255,255,0.18)' : 'rgba(0,0,0,0.38)'};pointer-events:none;"></div>

  <div style="position:relative;padding:14px 16px 12px;">

    <!-- TOP ROW: Logo left | SCG GRADING text right -->
    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px;">
      <img src="${SCG_LOGO}" style="height:28px;width:auto;" alt="SCG" />
      <div style="font-size:11px;font-weight:700;color:${bg.subTextColor};letter-spacing:2px;text-transform:uppercase;text-shadow:0 1px 2px rgba(0,0,0,0.5);">Sport Cards Grading</div>
    </div>

    <!-- DIVIDER -->
    <div style="height:1px;background:${border.hex};opacity:0.7;margin-bottom:10px;"></div>

    <!-- SUB-GRADES centered -->
    <div style="display:flex;justify-content:space-around;margin-bottom:12px;">
      ${subGrades.map(g => `
        <div style="text-align:center;">
          <div style="font-size:22px;font-weight:900;color:${bg.subGradeColor};text-shadow:0 1px 4px rgba(0,0,0,0.5);">${g.val ?? "—"}</div>
          <div style="font-size:8px;color:${bg.subTextColor};text-transform:uppercase;letter-spacing:1px;margin-top:2px;">${g.label}</div>
        </div>
      `).join("")}
    </div>

    <!-- DIVIDER -->
    <div style="height:1px;background:${bg.dividerColor};margin-bottom:10px;"></div>

    <!-- CERT + DISCLAIMER -->
    <div style="font-size:9px;color:${bg.certColor};line-height:1.5;margin-bottom:10px;text-align:center;">
      This card has been graded and authenticated by Sport Cards Grading (SCG) using AI-powered analysis.<br/>
      Grade reflects card condition at time of submission.<br/>
      <span style="color:${border.hex};font-weight:700;">www.SportCardsOnline.com</span>
    </div>

    <!-- BOTTOM ROW: CERT# left | QR right -->
    <div style="display:flex;align-items:flex-end;justify-content:space-between;">
      <div>
        <div style="font-size:9px;color:${bg.certColor};letter-spacing:1px;">CERT#</div>
        <div style="font-size:13px;font-weight:900;color:${bg.textColor};letter-spacing:1px;text-shadow:0 1px 3px rgba(0,0,0,0.5);">${certNum}</div>
        <div style="font-size:8px;color:${bg.certColor};margin-top:2px;">Scan to verify authenticity</div>
      </div>
      <img src="${qrUrl}" style="width:80px;height:80px;border-radius:6px;border:2px solid ${border.hex};" alt="QR Barcode" />
    </div>

  </div>
</div>`;
}

/** Builds a complete print-ready HTML page with front + back labels */
export function buildPrintPage(cards: SlabLabelData[], verifyBaseUrl = "https://www.sportcardsonline.com"): string {
  const labelPairs = cards.map(card => `
    <div class="label-pair">
      <div class="label-side">${buildFrontLabelHtml(card, verifyBaseUrl)}</div>
      <div class="label-side">${buildBackLabelHtml(card, verifyBaseUrl)}</div>
    </div>
    <div style="page-break-after:always;"></div>
  `).join("");

  return `<!DOCTYPE html>
<html>
<head>
  <title>SCG Labels</title>
  <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@400;600;700;900&display=swap" rel="stylesheet" />
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body { font-family: 'Oswald', sans-serif; background: #e5e5e5; padding: 24px; }
    .label-pair {
      display: flex;
      gap: 24px;
      justify-content: center;
      align-items: flex-start;
      margin-bottom: 32px;
      flex-wrap: wrap;
    }
    .label-side { display: flex; flex-direction: column; align-items: center; gap: 6px; }
    .label-side::after {
      content: attr(data-side);
      font-size: 10px;
      color: #888;
      letter-spacing: 1px;
      text-transform: uppercase;
    }
    @media print {
      body { background: white; padding: 0; }
      .label-pair { page-break-inside: avoid; }
    }
  </style>
</head>
<body>
  ${labelPairs}
  <script>window.onload = () => window.print();</script>
</body>
</html>`;
}

/** React component for inline label preview (used in GradeCards, MyCollection card detail) */
export function SlabLabelPreview({ card, side = "front" }: { card: SlabLabelData; side?: "front" | "back" }) {
  const bg = LABEL_BACKGROUNDS.find(b => b.value === (card.background || "white-silk")) ?? LABEL_BACKGROUNDS[0];
  const border = LABEL_BORDER_COLORS.find(b => b.value === (card.borderColor || "red")) ?? LABEL_BORDER_COLORS[2];
  const gradeNum = Number(card.overallGrade ?? 0);
  const gradeName = card.gradeLabel || gradeNameFromScore(gradeNum);
  const certNum = card.certNumber || "N/A";
  const verifyBaseUrl = window.location.origin;
  const verifyUrl = card.cardId ? `${verifyBaseUrl}/verify/${card.cardId}` : `${verifyBaseUrl}/verify/${certNum}`;
  const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=72x72&data=${encodeURIComponent(verifyUrl)}&bgcolor=ffffff&color=000000&margin=2`;

  const overlayBg = bg.value === "white-silk" ? "rgba(255,255,255,0.18)" : "rgba(0,0,0,0.32)";

  if (side === "back") {
    const subGrades = [
      { label: "Centering", val: card.centering },
      { label: "Corners",   val: card.corners },
      { label: "Edges",     val: card.edges },
      { label: "Surface",   val: card.surface },
    ];
    return (
      <div style={{
        width: 320, borderRadius: 14, overflow: "hidden",
        boxShadow: "0 6px 32px rgba(0,0,0,0.45)",
        border: `${BORDER_PX}px solid ${border.hex}`,
        backgroundImage: `url('${bg.url}')`,
        backgroundSize: "cover", backgroundPosition: "center",
        fontFamily: "'Oswald', sans-serif", position: "relative",
      }}>
        <div style={{ position: "absolute", inset: 0, background: overlayBg, pointerEvents: "none" }} />
        <div style={{ position: "relative", padding: "14px 16px 12px" }}>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 8 }}>
            <img src={SCG_LOGO} style={{ height: 28, width: "auto" }} alt="SCG" />
            <div style={{ fontSize: 11, fontWeight: 700, color: bg.subTextColor, letterSpacing: 2, textTransform: "uppercase", textShadow: "0 1px 2px rgba(0,0,0,0.5)" }}>Sport Cards Grading</div>
          </div>
          <div style={{ height: 1, background: border.hex, opacity: 0.7, marginBottom: 10 }} />
          <div style={{ display: "flex", justifyContent: "space-around", marginBottom: 12 }}>
            {subGrades.map(g => (
              <div key={g.label} style={{ textAlign: "center" }}>
                <div style={{ fontSize: 22, fontWeight: 900, color: bg.subGradeColor, textShadow: "0 1px 4px rgba(0,0,0,0.5)" }}>{g.val ?? "—"}</div>
                <div style={{ fontSize: 8, color: bg.subTextColor, textTransform: "uppercase", letterSpacing: 1, marginTop: 2 }}>{g.label}</div>
              </div>
            ))}
          </div>
          <div style={{ height: 1, background: bg.dividerColor, marginBottom: 10 }} />
          <div style={{ fontSize: 9, color: bg.certColor, lineHeight: 1.5, marginBottom: 10, textAlign: "center" }}>
            Graded & authenticated by Sport Cards Grading (SCG).<br />
            <span style={{ color: border.hex, fontWeight: 700 }}>www.SportCardsOnline.com</span>
          </div>
          <div style={{ display: "flex", alignItems: "flex-end", justifyContent: "space-between" }}>
            <div>
              <div style={{ fontSize: 9, color: bg.certColor, letterSpacing: 1 }}>CERT#</div>
              <div style={{ fontSize: 13, fontWeight: 900, color: bg.textColor, letterSpacing: 1, textShadow: "0 1px 3px rgba(0,0,0,0.5)" }}>{certNum}</div>
              <div style={{ fontSize: 8, color: bg.certColor, marginTop: 2 }}>Scan to verify</div>
            </div>
            <img src={qrUrl} style={{ width: 80, height: 80, borderRadius: 6, border: `2px solid ${border.hex}` }} alt="QR" />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div style={{
      width: 320, borderRadius: 14, overflow: "hidden",
      boxShadow: "0 6px 32px rgba(0,0,0,0.45)",
      border: `${BORDER_PX}px solid ${border.hex}`,
      backgroundImage: `url('${bg.url}')`,
      backgroundSize: "cover", backgroundPosition: "center",
      fontFamily: "'Oswald', sans-serif", position: "relative",
    }}>
      <div style={{ position: "absolute", inset: 0, background: overlayBg, pointerEvents: "none" }} />
      <div style={{ position: "relative", padding: "14px 16px 12px" }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 10 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
            <img src={SCG_LOGO} style={{ height: 30, width: "auto" }} alt="SCG" />
            <div style={{ fontSize: 13, fontWeight: 900, letterSpacing: 2, color: bg.textColor, textShadow: "0 1px 3px rgba(0,0,0,0.5)" }}>SCG GRADING</div>
          </div>
          {card.cardCompany && (
            <div style={{ fontSize: 10, fontWeight: 700, color: bg.subTextColor, letterSpacing: 1, textTransform: "uppercase", textShadow: "0 1px 2px rgba(0,0,0,0.4)" }}>{card.cardCompany}</div>
          )}
        </div>
        <div style={{ height: 1, background: border.hex, opacity: 0.7, marginBottom: 10 }} />
        <div style={{ fontSize: 22, fontWeight: 900, color: bg.textColor, letterSpacing: 0.5, lineHeight: 1.1, textShadow: "0 1px 4px rgba(0,0,0,0.5)", marginBottom: 4 }}>{card.playerName || "—"}</div>
        <div style={{ fontSize: 11, color: bg.subTextColor, marginBottom: 12, letterSpacing: 0.5, textShadow: "0 1px 2px rgba(0,0,0,0.4)" }}>
          {[card.year, card.setName, card.cardNumber ? `#${card.cardNumber}` : ""].filter(Boolean).join("  ·  ")}
        </div>
        <div style={{ height: 1, background: bg.dividerColor, marginBottom: 10 }} />
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <div>
            <div style={{ fontSize: 52, fontWeight: 900, color: border.hex, lineHeight: 1, textShadow: "0 2px 8px rgba(0,0,0,0.5)" }}>{gradeNum || "—"}</div>
            <div style={{ fontSize: 13, fontWeight: 700, color: bg.textColor, letterSpacing: 2, textTransform: "uppercase", textShadow: "0 1px 3px rgba(0,0,0,0.4)" }}>{gradeName}</div>
            <div style={{ fontSize: 9, color: bg.certColor, marginTop: 4, letterSpacing: 1 }}>CERT# {certNum}</div>
          </div>
          <div style={{ textAlign: "center" }}>
            <img src={qrUrl} style={{ width: 72, height: 72, borderRadius: 6, border: `2px solid ${border.hex}` }} alt="QR" />
            <div style={{ fontSize: 7, color: bg.certColor, marginTop: 3, letterSpacing: 0.5 }}>SCAN TO VERIFY</div>
          </div>
        </div>
      </div>
    </div>
  );
}
