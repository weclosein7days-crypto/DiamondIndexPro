/**
 * HeroSection — 3-column layout.
 * Col 1 (45%): marketing copy + CTAs
 * Col 2 (35%): large Panini box, small Caitlin Clark card at corner
 * Col 3 (20%): Game Room casino ad
 */
import { Link } from "wouter";
import { Dice6, Camera, BarChart2, ShoppingCart, Trophy, Zap, Gift, Heart } from "lucide-react";

const BOX_IMG  = "https://d2xsxph8kpxj0f.cloudfront.net/310519663482618714/HBSXFxHmEnEJMgVvzKnhpZ/prizm-wnba-box_0ca80d71.png";
const CARD_IMG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663482618714/HBSXFxHmEnEJMgVvzKnhpZ/caitlin-clark-auto_ff5f6a76.jpg";

interface Props {
  compsOpen: boolean;
  setCompsOpen: (v: boolean) => void;
  valuesOpen: boolean;
  setValuesOpen: (v: boolean) => void;
}

export default function HeroSection({ setCompsOpen, setValuesOpen }: Props) {
  return (
    <section className="bg-[#080808] border-b border-white/[0.06] overflow-hidden">
      <div className="max-w-[1440px] mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-[45fr_35fr_20fr] min-h-[320px]">

          {/* ══ COL 1 — Copy (45%) ══════════════════════════════════════ */}
          <div className="flex flex-col justify-center px-8 md:px-12 py-10 border-b lg:border-b-0 lg:border-r border-white/[0.06]">
            <p className="text-white/30 text-[10px] font-black uppercase tracking-[0.25em] mb-3">
              The Collector's Marketplace
            </p>
            <h1
              className="text-4xl md:text-5xl xl:text-[3.4rem] font-black text-white leading-[1.05] mb-4"
              style={{ fontFamily: "Oswald, sans-serif" }}
            >
              Buy, Sell &amp; Grade<br />
              <span className="text-[#c41e3a]">Sports Cards</span><br />
              <span className="text-white/80">Like a Pro.</span>
            </h1>
            <p className="text-white/50 text-base mb-7 max-w-md leading-relaxed">
              AI-powered card grading, live auctions, and verified vault storage — everything a serious collector needs in one place.
            </p>

            <div className="flex flex-wrap gap-3 mb-6">
              <Link href="/">
                <span className="inline-flex items-center gap-2 bg-[#c41e3a] hover:bg-[#c41e3a]/90 text-white font-bold px-6 py-3 rounded-xl text-sm transition-all shadow-lg shadow-[#c41e3a]/25 hover:-translate-y-0.5">
                  <ShoppingCart className="w-4 h-4" />Shop Cards
                </span>
              </Link>
              <Link href="/grade">
                <span className="inline-flex items-center gap-2 bg-white/[0.07] hover:bg-white/[0.12] border border-white/15 text-white font-bold px-6 py-3 rounded-xl text-sm transition-all hover:-translate-y-0.5">
                  <Camera className="w-4 h-4 text-[#c41e3a]" />Grade a Card
                </span>
              </Link>
              <button
                onClick={() => { setCompsOpen(true); setValuesOpen(false); }}
                className="inline-flex items-center gap-2 bg-white/[0.07] hover:bg-white/[0.12] border border-white/15 text-white font-bold px-6 py-3 rounded-xl text-sm transition-all hover:-translate-y-0.5"
              >
                <BarChart2 className="w-4 h-4 text-yellow-400" />Free Comps
              </button>
            </div>

            <div className="flex gap-6">
              {[
                { val: "10K+", label: "Cards Listed" },
                { val: "SCO",  label: "AI Grading"   },
                { val: "FREE", label: "Vault Storage" },
              ].map(({ val, label }) => (
                <div key={label}>
                  <div className="text-lg font-black text-white" style={{ fontFamily: "Oswald, sans-serif" }}>{val}</div>
                  <div className="text-white/35 text-[10px] uppercase tracking-widest">{label}</div>
                </div>
              ))}
            </div>
          </div>

          {/* ══ COL 2 — Box + Card (35%) ════════════════════════════════ */}
          <div className="relative flex items-center justify-center bg-[#0a0a0a] border-b lg:border-b-0 lg:border-r border-white/[0.06] py-8 px-4 overflow-hidden">
            {/* subtle glow */}
            <div className="absolute inset-0 bg-gradient-to-br from-[#c41e3a]/5 via-transparent to-transparent pointer-events-none" />

            {/* Box — fills most of the column */}
            <div className="relative w-full max-w-[260px]">
              <img
                src={BOX_IMG}
                alt="2025 Panini Prizm WNBA Hobby Box"
                className="w-full h-auto object-contain drop-shadow-2xl hover:scale-[1.03] transition-transform duration-500"
              />

              {/* Card — small, bottom-right corner of box */}
              <img
                src={CARD_IMG}
                alt="Caitlin Clark Prizm Auto"
                className="absolute rounded-lg drop-shadow-2xl hover:scale-110 transition-transform duration-300 cursor-pointer"
                style={{
                  width: "28%",
                  bottom: "-10px",
                  right: "-14px",
                  transform: "rotate(8deg)",
                  zIndex: 10,
                }}
                onMouseEnter={e => (e.currentTarget.style.transform = "rotate(0deg) scale(1.15)")}
                onMouseLeave={e => (e.currentTarget.style.transform = "rotate(8deg)")}
              />
            </div>
          </div>

          {/* ══ COL 3 — Casino Ad (20%) ══════════════════════════════════ */}
          <Link href="/game-room">
            <div className="relative flex flex-col justify-between bg-gradient-to-b from-[#0f0a00] to-[#0a0a0a] hover:from-[#1a1000] hover:to-[#0d0d0d] transition-colors cursor-pointer h-full min-h-[260px] overflow-hidden group">
              {/* Gold top accent bar */}
              <div className="h-1 w-full bg-gradient-to-r from-yellow-600 via-yellow-400 to-yellow-600" />

              {/* Content */}
              <div className="flex flex-col items-center justify-center flex-1 px-5 py-8 text-center gap-4">
                {/* Icon */}
                <div className="w-14 h-14 rounded-2xl bg-yellow-500/10 border border-yellow-500/20 flex items-center justify-center text-3xl group-hover:scale-110 transition-transform">
                  🎰
                </div>

                <div>
                  <p className="text-yellow-400 text-[10px] font-black uppercase tracking-[0.2em] mb-1">SCO Game Room</p>
                  <h3 className="text-white text-xl font-black leading-tight mb-2" style={{ fontFamily: "Oswald, sans-serif" }}>
                    Play Free.<br />Win Real Cards.
                  </h3>
                  <p className="text-white/50 text-xs leading-relaxed">
                    No purchase needed. Spin, play poker or blackjack — winners receive actual sports cards shipped to their door.
                  </p>
                </div>

                {/* Feature pills */}
                <div className="flex flex-col gap-1.5 w-full">
                  {[
                    { icon: <Gift className="w-3 h-3" />, text: "Free plays every 30 min" },
                    { icon: <Trophy className="w-3 h-3" />, text: "Win graded card prizes" },
                    { icon: <Zap className="w-3 h-3" />, text: "Poker · Blackjack · Slots" },
                  ].map(({ icon, text }) => (
                    <div key={text} className="flex items-center gap-2 bg-white/[0.04] rounded-lg px-3 py-1.5">
                      <span className="text-yellow-400 shrink-0">{icon}</span>
                      <span className="text-white/60 text-[10px] font-semibold text-left">{text}</span>
                    </div>
                  ))}
                </div>

                {/* CTA */}
                <span className="inline-flex items-center gap-2 bg-yellow-500 hover:bg-yellow-400 text-black font-black text-xs px-5 py-2.5 rounded-xl transition-colors shadow-lg shadow-yellow-500/20 w-full justify-center group-hover:-translate-y-0.5 transition-transform">
                  <Dice6 className="w-3.5 h-3.5" />Enter Game Room
                </span>
              </div>

              {/* Gold bottom accent bar */}
              <div className="h-1 w-full bg-gradient-to-r from-yellow-600 via-yellow-400 to-yellow-600" />
            </div>
          </Link>

        </div>
      </div>

      {/* ── Why We Collect CTA banner ─────────────────────────────── */}
      <div className="border-t border-white/[0.06] bg-gradient-to-r from-[#0a0a0a] via-[#0d0a0a] to-[#0a0a0a] py-5 px-4 flex flex-col items-center gap-1.5">
        <Link href="/why-we-collect">
          <span className="inline-flex items-center gap-3 bg-red-700/20 hover:bg-red-700/30 border border-red-600/40 hover:border-red-500/60 text-white font-black text-base md:text-lg px-8 py-3.5 rounded-full transition-all duration-300 hover:-translate-y-0.5 shadow-lg shadow-red-900/20 hover:shadow-red-800/40" style={{ fontFamily: 'Oswald, sans-serif' }}>
            <Heart className="w-5 h-5 text-red-400 fill-red-400" />
            This is Why We Collect
          </span>
        </Link>
        <p className="text-white/30 text-xs italic">
          Based on a True Story by <span className="text-white/50">Chasing Cards</span>
        </p>
      </div>
    </section>
  );
}
