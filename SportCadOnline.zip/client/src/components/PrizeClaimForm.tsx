import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { Package, MapPin, CreditCard, Trophy } from "lucide-react";

interface PrizeClaimFormProps {
  open: boolean;
  onClose: () => void;
  prize: {
    cardTitle: string;
    cardValue?: number;
    gamePlayId?: number;
    prizeVaultId?: number;
    claimType: "game_win" | "showcase_redeem";
    creditsRedeemed?: number;
  };
}

export default function PrizeClaimForm({ open, onClose, prize }: PrizeClaimFormProps) {
  const [form, setForm] = useState({
    name: "",
    address: "",
    city: "",
    state: "",
    zip: "",
  });
  const [step, setStep] = useState<"form" | "paying" | "done">("form");

  const claimMutation = trpc.game.claimPrize.useMutation({
    onSuccess: (data: { success: boolean; checkoutUrl: string | null }) => {
      if (data.checkoutUrl) {
        setStep("paying");
        toast.success("Redirecting to pay $2.50 shipping...");
        window.open(data.checkoutUrl, "_blank");
        // After a short delay, show done state
        setTimeout(() => setStep("done"), 3000);
      } else {
        setStep("done");
        toast.success("Prize claimed! We'll ship it soon.");
      }
    },
    onError: (err: { message: string }) => {
      toast.error(err.message);
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name || !form.address || !form.city || !form.state || !form.zip) {
      toast.error("Please fill in all shipping fields");
      return;
    }
    claimMutation.mutate({
      cardTitle: prize.cardTitle,
      cardValue: prize.cardValue ?? 0,
      gamePlayId: prize.gamePlayId,
      prizeVaultId: prize.prizeVaultId,
      claimType: prize.claimType,
      creditsRedeemed: prize.creditsRedeemed ?? 0,
      shippingName: form.name,
      shippingAddress: form.address,
      shippingCity: form.city,
      shippingState: form.state,
      shippingZip: form.zip,
      origin: window.location.origin,
    });
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-md bg-[#0d1f3c] border-yellow-500/30 text-white">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-yellow-400 font-black" style={{ fontFamily: "Oswald, sans-serif" }}>
            <Trophy className="w-5 h-5" />
            CLAIM YOUR PRIZE CARD
          </DialogTitle>
        </DialogHeader>

        {step === "done" ? (
          <div className="text-center py-8">
            <div className="text-5xl mb-4">🎉</div>
            <h3 className="text-xl font-black text-yellow-400 mb-2" style={{ fontFamily: "Oswald, sans-serif" }}>
              CLAIM SUBMITTED!
            </h3>
            <p className="text-white/70 text-sm mb-1">
              <strong className="text-white">{prize.cardTitle}</strong> is reserved for you.
            </p>
            <p className="text-white/50 text-xs">
              Once shipping is confirmed, we'll mail your card within 3–5 business days.
              Track it in My Collection → Orders.
            </p>
            <Button onClick={onClose} className="mt-6 bg-yellow-500 hover:bg-yellow-400 text-black font-black">
              Back to Game Room
            </Button>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Prize summary */}
            <div className="rounded-lg border border-yellow-500/30 bg-yellow-500/10 p-3 flex items-center gap-3">
              <Package className="w-8 h-8 text-yellow-400 shrink-0" />
              <div>
                <p className="font-black text-white text-sm">{prize.cardTitle}</p>
                {prize.cardValue && prize.cardValue > 0 && (
                  <p className="text-yellow-400 text-xs">Est. value: ${prize.cardValue.toFixed(2)}</p>
                )}
                <p className="text-white/50 text-xs">$2.50 flat shipping fee</p>
              </div>
            </div>

            {/* Shipping form */}
            <div>
              <Label className="text-white/70 text-xs flex items-center gap-1 mb-1">
                <MapPin className="w-3 h-3" /> Shipping Address
              </Label>
              <div className="space-y-2">
                <Input
                  placeholder="Full Name"
                  value={form.name}
                  onChange={e => setForm(f => ({ ...f, name: e.target.value }))}
                  className="bg-black/40 border-white/20 text-white placeholder:text-white/30"
                />
                <Input
                  placeholder="Street Address"
                  value={form.address}
                  onChange={e => setForm(f => ({ ...f, address: e.target.value }))}
                  className="bg-black/40 border-white/20 text-white placeholder:text-white/30"
                />
                <div className="grid grid-cols-3 gap-2">
                  <Input
                    placeholder="City"
                    value={form.city}
                    onChange={e => setForm(f => ({ ...f, city: e.target.value }))}
                    className="bg-black/40 border-white/20 text-white placeholder:text-white/30 col-span-1"
                  />
                  <Input
                    placeholder="State"
                    value={form.state}
                    onChange={e => setForm(f => ({ ...f, state: e.target.value }))}
                    className="bg-black/40 border-white/20 text-white placeholder:text-white/30"
                  />
                  <Input
                    placeholder="ZIP"
                    value={form.zip}
                    onChange={e => setForm(f => ({ ...f, zip: e.target.value }))}
                    className="bg-black/40 border-white/20 text-white placeholder:text-white/30"
                  />
                </div>
              </div>
            </div>

            {/* Fee notice */}
            <div className="rounded-lg border border-white/10 bg-black/30 p-3 flex items-center gap-2 text-xs text-white/60">
              <CreditCard className="w-4 h-4 text-white/40 shrink-0" />
              <span>You'll be charged <strong className="text-white">$2.50</strong> for shipping via Stripe. Your card is reserved immediately.</span>
            </div>

            <Button
              type="submit"
              disabled={claimMutation.isPending || step === "paying"}
              className="w-full bg-yellow-500 hover:bg-yellow-400 text-black font-black gap-2"
            >
              <Package className="w-4 h-4" />
              {claimMutation.isPending ? "Processing..." : step === "paying" ? "Redirecting to payment..." : "Claim & Pay $2.50 Shipping"}
            </Button>
          </form>
        )}
      </DialogContent>
    </Dialog>
  );
}
