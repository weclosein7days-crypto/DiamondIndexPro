/**
 * TriviaPopup — 1-question-per-minute animated educational trivia overlay
 *
 * Features:
 * - Pops up every 60 seconds while Kids Corner is active
 * - Age-matched questions from the kid's DOB
 * - Animated sports-themed reveal (ball bounce in, confetti on correct)
 * - Spaced repetition: wrong answers get rephrased and re-queued
 * - Sound effects via Web Audio API (no external files)
 * - 15-second countdown timer per question
 */

import { useState, useEffect, useRef, useCallback } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

// ─── Sound Engine ─────────────────────────────────────────────────────────────

function createAudioContext(): AudioContext | null {
  try {
    return new (window.AudioContext || (window as any).webkitAudioContext)();
  } catch {
    return null;
  }
}

function playTone(ctx: AudioContext, freq: number, duration: number, type: OscillatorType = "sine", gain = 0.3) {
  const osc = ctx.createOscillator();
  const gainNode = ctx.createGain();
  osc.connect(gainNode);
  gainNode.connect(ctx.destination);
  osc.type = type;
  osc.frequency.setValueAtTime(freq, ctx.currentTime);
  gainNode.gain.setValueAtTime(gain, ctx.currentTime);
  gainNode.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + duration);
  osc.start(ctx.currentTime);
  osc.stop(ctx.currentTime + duration);
}

function playCorrectSound(ctx: AudioContext) {
  // Happy ascending arpeggio
  [523, 659, 784, 1047].forEach((freq, i) => {
    setTimeout(() => playTone(ctx, freq, 0.2, "sine", 0.4), i * 80);
  });
  // Kids cheer simulation — quick noise burst
  setTimeout(() => {
    const bufferSize = ctx.sampleRate * 0.3;
    const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) data[i] = (Math.random() * 2 - 1) * 0.15;
    const source = ctx.createBufferSource();
    source.buffer = buffer;
    const filter = ctx.createBiquadFilter();
    filter.type = "bandpass";
    filter.frequency.value = 2000;
    source.connect(filter);
    filter.connect(ctx.destination);
    source.start();
  }, 320);
}

function playWrongSound(ctx: AudioContext) {
  // Sad descending tones
  [400, 300, 220].forEach((freq, i) => {
    setTimeout(() => playTone(ctx, freq, 0.25, "sawtooth", 0.2), i * 120);
  });
}

function playTickSound(ctx: AudioContext) {
  playTone(ctx, 880, 0.05, "square", 0.1);
}

function playPopInSound(ctx: AudioContext) {
  // Bouncy pop
  [300, 600, 900].forEach((freq, i) => {
    setTimeout(() => playTone(ctx, freq, 0.1, "sine", 0.25), i * 40);
  });
}

// ─── Confetti ─────────────────────────────────────────────────────────────────

interface ConfettiPiece {
  id: number;
  x: number;
  color: string;
  delay: number;
  size: number;
}

function Confetti() {
  const pieces: ConfettiPiece[] = Array.from({ length: 30 }, (_, i) => ({
    id: i,
    x: Math.random() * 100,
    color: ["#FFD700", "#FF6B6B", "#4ECDC4", "#45B7D1", "#96CEB4", "#FFEAA7", "#DDA0DD"][i % 7],
    delay: Math.random() * 0.5,
    size: 6 + Math.random() * 8,
  }));

  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none">
      {pieces.map((p) => (
        <div
          key={p.id}
          className="absolute top-0 animate-confetti-fall"
          style={{
            left: `${p.x}%`,
            width: p.size,
            height: p.size,
            backgroundColor: p.color,
            borderRadius: Math.random() > 0.5 ? "50%" : "2px",
            animationDelay: `${p.delay}s`,
            animationDuration: `${1.5 + Math.random()}s`,
          }}
        />
      ))}
    </div>
  );
}

// ─── Sport Icons ──────────────────────────────────────────────────────────────

const SPORT_EMOJI: Record<string, string> = {
  basketball: "🏀",
  baseball: "⚾",
  football: "🏈",
  soccer: "⚽",
  hockey: "🏒",
  default: "🏆",
};

const SUBJECT_COLORS: Record<string, { bg: string; border: string; label: string }> = {
  math: { bg: "from-blue-600 to-blue-800", border: "border-blue-400", label: "Math" },
  reading: { bg: "from-purple-600 to-purple-800", border: "border-purple-400", label: "Reading" },
  science: { bg: "from-green-600 to-green-800", border: "border-green-400", label: "Science" },
  history: { bg: "from-amber-600 to-amber-800", border: "border-amber-400", label: "History" },
  sports_facts: { bg: "from-red-600 to-red-800", border: "border-red-400", label: "Sports" },
};

// ─── Main Component ───────────────────────────────────────────────────────────

interface TriviaPopupProps {
  kidId: number;
  kidName: string;
  /** interval in seconds between questions (default 60) */
  intervalSeconds?: number;
  onCreditsEarned?: (amount: number) => void;
}

type Phase = "idle" | "animating-in" | "question" | "result" | "fun-fact";

export function TriviaPopup({
  kidId,
  kidName,
  intervalSeconds = 60,
  onCreditsEarned,
}: TriviaPopupProps) {
  const [phase, setPhase] = useState<Phase>("idle");
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
  const [isCorrect, setIsCorrect] = useState<boolean | null>(null);
  const [creditsEarned, setCreditsEarned] = useState(0);
  const [countdown, setCountdown] = useState(15);
  const [showConfetti, setShowConfetti] = useState(false);
  const [nextIn, setNextIn] = useState(intervalSeconds);
  const [questionData, setQuestionData] = useState<any>(null);
  const [isTimedOut, setIsTimedOut] = useState(false);

  const audioCtxRef = useRef<AudioContext | null>(null);
  const countdownRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const nextTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const autoCloseRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const getAudio = useCallback(() => {
    if (!audioCtxRef.current) {
      audioCtxRef.current = createAudioContext();
    }
    return audioCtxRef.current;
  }, []);

  // tRPC
  const { refetch: fetchQuestion } = trpc.kidsTrivia.getNextQuestion.useQuery(
    { kidId },
    { enabled: false }
  );
  const submitAnswer = trpc.kidsTrivia.submitAnswer.useMutation();
  const generateMore = trpc.kidsTrivia.generateMoreQuestions.useMutation();

  // ── Countdown timer while question is showing ──────────────────────────────
  useEffect(() => {
    if (phase !== "question") {
      if (countdownRef.current) clearInterval(countdownRef.current);
      return;
    }
    setCountdown(15);
    countdownRef.current = setInterval(() => {
      setCountdown((c) => {
        if (c <= 1) {
          clearInterval(countdownRef.current!);
          // Auto-submit wrong on timeout
          setIsTimedOut(true);
          handleTimeout();
          return 0;
        }
        const audio = getAudio();
        if (audio && c <= 5) playTickSound(audio);
        return c - 1;
      });
    }, 1000);
    return () => { if (countdownRef.current) clearInterval(countdownRef.current); };
  }, [phase]);

  // ── Next-question countdown (shown in corner) ──────────────────────────────
  useEffect(() => {
    setNextIn(intervalSeconds);
    nextTimerRef.current = setInterval(() => {
      setNextIn((n) => {
        if (n <= 1) {
          clearInterval(nextTimerRef.current!);
          triggerQuestion();
          return intervalSeconds;
        }
        return n - 1;
      });
    }, 1000);
    return () => { if (nextTimerRef.current) clearInterval(nextTimerRef.current); };
  }, [kidId]);

  // ── Trigger a question ─────────────────────────────────────────────────────
  const triggerQuestion = useCallback(async () => {
    const result = await fetchQuestion();
    const data = result.data;
    if (!data || !data.questionId) {
      // Need to generate more
      if ((data as any)?.needsGeneration) {
        await generateMore.mutateAsync({ kidId, count: 15 });
        const result2 = await fetchQuestion();
        if (!result2.data?.questionId) return;
        setQuestionData(result2.data);
      } else {
        return;
      }
    } else {
      setQuestionData(data);
    }

    setSelectedAnswer(null);
    setIsCorrect(null);
    setIsTimedOut(false);
    setShowConfetti(false);
    setPhase("animating-in");

    const audio = getAudio();
    if (audio) playPopInSound(audio);

    setTimeout(() => setPhase("question"), 400);
  }, [fetchQuestion, generateMore, kidId, getAudio]);

  // ── Handle answer selection ────────────────────────────────────────────────
  const handleAnswer = useCallback(async (answer: string) => {
    if (selectedAnswer || !questionData) return;
    if (countdownRef.current) clearInterval(countdownRef.current);

    setSelectedAnswer(answer);
    const correct = answer.trim().toLowerCase() === questionData.correctAnswer.trim().toLowerCase();
    setIsCorrect(correct);

    const audio = getAudio();
    if (audio) {
      if (correct) playCorrectSound(audio);
      else playWrongSound(audio);
    }

    if (correct) setShowConfetti(true);

    // Submit to server
    try {
      const res = await submitAnswer.mutateAsync({
        kidId,
        questionId: questionData.questionId,
        rephraseId: questionData.rephraseId ?? null,
        selectedAnswer: answer,
        correctAnswer: questionData.correctAnswer,
        subject: questionData.subject ?? "sports_facts",
        creditsReward: questionData.creditsReward ?? 5,
      });
      if (res.isCorrect) {
        setCreditsEarned(res.creditsAwarded);
        onCreditsEarned?.(res.creditsAwarded);
      }
    } catch (e) {
      console.error("Submit answer failed:", e);
    }

    setPhase("result");

    // Auto-advance to fun fact
    autoCloseRef.current = setTimeout(() => {
      setPhase("fun-fact");
      // Auto-close after fun fact
      autoCloseRef.current = setTimeout(() => {
        setPhase("idle");
        setNextIn(intervalSeconds);
        // Restart next-question timer
        if (nextTimerRef.current) clearInterval(nextTimerRef.current);
        nextTimerRef.current = setInterval(() => {
          setNextIn((n) => {
            if (n <= 1) {
              clearInterval(nextTimerRef.current!);
              triggerQuestion();
              return intervalSeconds;
            }
            return n - 1;
          });
        }, 1000);
      }, 5000);
    }, 2000);
  }, [selectedAnswer, questionData, kidId, submitAnswer, onCreditsEarned, getAudio, intervalSeconds, triggerQuestion]);

  const handleTimeout = useCallback(() => {
    if (!questionData) return;
    setSelectedAnswer("__timeout__");
    setIsCorrect(false);
    const audio = getAudio();
    if (audio) playWrongSound(audio);
    setPhase("result");
    autoCloseRef.current = setTimeout(() => {
      setPhase("fun-fact");
      autoCloseRef.current = setTimeout(() => setPhase("idle"), 5000);
    }, 2000);
  }, [questionData, getAudio]);

  const handleClose = useCallback(() => {
    if (autoCloseRef.current) clearTimeout(autoCloseRef.current);
    if (countdownRef.current) clearInterval(countdownRef.current);
    setPhase("idle");
    setNextIn(intervalSeconds);
  }, [intervalSeconds]);

  if (phase === "idle") {
    return (
      <div className="fixed bottom-4 right-4 z-40">
        <div className="bg-gray-900/80 backdrop-blur-sm border border-yellow-500/30 rounded-full px-3 py-1.5 text-xs text-yellow-400 font-bold flex items-center gap-1.5">
          <span className="text-base">🧠</span>
          <span>Quiz in {nextIn}s</span>
        </div>
      </div>
    );
  }

  const subjectStyle = SUBJECT_COLORS[questionData?.subject ?? "sports_facts"] ?? SUBJECT_COLORS.sports_facts;
  const sportEmoji = SPORT_EMOJI[questionData?.sport ?? "default"] ?? "🏆";

  return (
    <div className={`fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm transition-opacity duration-300 ${phase === "animating-in" ? "opacity-0" : "opacity-100"}`}>
      {showConfetti && <Confetti />}

      <div
        className={`relative w-full max-w-lg bg-gray-900 rounded-2xl border-2 ${subjectStyle.border} shadow-2xl overflow-hidden transition-all duration-400 ${phase === "animating-in" ? "scale-50 opacity-0" : "scale-100 opacity-100"}`}
        style={{ transform: phase === "animating-in" ? "scale(0.5) translateY(50px)" : "scale(1) translateY(0)" }}
      >
        {/* Header */}
        <div className={`bg-gradient-to-r ${subjectStyle.bg} px-5 py-3 flex items-center justify-between`}>
          <div className="flex items-center gap-2">
            <span className="text-2xl">{sportEmoji}</span>
            <div>
              <div className="text-white font-black text-sm uppercase tracking-wider">
                {subjectStyle.label} Challenge!
              </div>
              <div className="text-white/70 text-xs">
                {questionData?.isRephrase ? "🔄 Let's try again!" : `Hey ${kidName}!`}
              </div>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {phase === "question" && (
              <div className={`w-10 h-10 rounded-full border-2 flex items-center justify-center font-black text-lg ${countdown <= 5 ? "border-red-400 text-red-400 animate-pulse" : "border-white/50 text-white"}`}>
                {countdown}
              </div>
            )}
            <button onClick={handleClose} className="text-white/60 hover:text-white text-xl leading-none">×</button>
          </div>
        </div>

        {/* Difficulty & Credits Badge */}
        <div className="px-5 pt-3 flex items-center gap-2">
          <Badge variant="outline" className="text-xs capitalize border-yellow-500/50 text-yellow-400">
            {questionData?.difficulty}
          </Badge>
          <Badge variant="outline" className="text-xs border-green-500/50 text-green-400">
            +{questionData?.creditsReward} credits
          </Badge>
          {questionData?.isRephrase && (
            <Badge variant="outline" className="text-xs border-orange-500/50 text-orange-400">
              🔄 Retry
            </Badge>
          )}
        </div>

        {/* Question */}
        <div className="px-5 py-4">
          <p className="text-white font-bold text-base leading-relaxed">
            {questionData?.question}
          </p>
        </div>

        {/* Answer Choices */}
        {(phase === "question" || phase === "result") && (
          <div className="px-5 pb-4 grid grid-cols-1 gap-2">
            {(questionData?.choices ?? []).map((choice: string, i: number) => {
              const isSelected = selectedAnswer === choice;
              const isRight = choice.trim().toLowerCase() === questionData?.correctAnswer?.trim().toLowerCase();
              let btnClass = "w-full text-left px-4 py-3 rounded-xl border-2 font-semibold text-sm transition-all duration-200 ";

              if (phase === "result") {
                if (isRight) btnClass += "bg-green-600/30 border-green-400 text-green-300";
                else if (isSelected && !isRight) btnClass += "bg-red-600/30 border-red-400 text-red-300";
                else btnClass += "bg-gray-800/50 border-gray-700 text-gray-500";
              } else {
                btnClass += "bg-gray-800 border-gray-700 text-white hover:bg-gray-700 hover:border-yellow-500/50 active:scale-95";
              }

              return (
                <button
                  key={i}
                  className={btnClass}
                  onClick={() => phase === "question" && handleAnswer(choice)}
                  disabled={phase === "result"}
                >
                  <span className="mr-2 font-black text-yellow-400">{["A", "B", "C", "D"][i]}.</span>
                  {choice}
                  {phase === "result" && isRight && <span className="ml-2">✅</span>}
                  {phase === "result" && isSelected && !isRight && <span className="ml-2">❌</span>}
                </button>
              );
            })}
          </div>
        )}

        {/* Result Banner */}
        {phase === "result" && (
          <div className={`mx-5 mb-4 rounded-xl p-3 text-center font-black text-lg ${isCorrect ? "bg-green-600/20 border border-green-500 text-green-300" : "bg-red-600/20 border border-red-500 text-red-300"}`}>
            {isTimedOut ? (
              "⏰ Time's up! We'll try again later!"
            ) : isCorrect ? (
              <>🎉 CORRECT! +{creditsEarned} credits!</>
            ) : (
              "Not quite! We'll give you a different example soon 💪"
            )}
          </div>
        )}

        {/* Fun Fact */}
        {phase === "fun-fact" && questionData?.funFact && (
          <div className="px-5 pb-5">
            <div className="bg-yellow-500/10 border border-yellow-500/30 rounded-xl p-4">
              <div className="text-yellow-400 font-black text-xs uppercase tracking-wider mb-1">⚡ Fun Fact!</div>
              <p className="text-white/90 text-sm leading-relaxed">{questionData.funFact}</p>
            </div>
            <Button
              onClick={handleClose}
              className="w-full mt-3 bg-yellow-500 hover:bg-yellow-400 text-black font-black"
            >
              Got it! Back to playing 🎮
            </Button>
          </div>
        )}

        {/* Progress bar for countdown */}
        {phase === "question" && (
          <div className="h-1 bg-gray-800">
            <div
              className={`h-full transition-all duration-1000 ${countdown <= 5 ? "bg-red-500" : "bg-yellow-500"}`}
              style={{ width: `${(countdown / 15) * 100}%` }}
            />
          </div>
        )}
      </div>
    </div>
  );
}
