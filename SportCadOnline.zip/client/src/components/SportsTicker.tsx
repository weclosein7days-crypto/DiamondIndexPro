/**
 * SportsTicker — fixed bottom bar showing scrolling sports news, card releases,
 * upcoming games, and breaking news. Shown on all pages. Pauses on hover.
 * Powered by sportsData.tickerNews for live content.
 */
import { useEffect, useRef } from "react";
import { trpc } from "@/lib/trpc";

const FALLBACK_ITEMS = [
  { id: 1, text: "🏀 Final Four: Duke, Auburn, Florida, Houston — April 5 & 7", category: "NCAA" },
  { id: 2, text: "⚾ MLB Opening Day: Shohei Ohtani leads Dodgers vs Cubs", category: "MLB" },
  { id: 3, text: "🃏 2025 Topps Series 1 Baseball — Skenes & De La Cruz rookies out now", category: "Cards" },
  { id: 4, text: "🏀 WNBA Draft: Paige Bueckers #1 pick — Dallas Wings", category: "WNBA" },
  { id: 5, text: "🏈 NFL Draft: Cam Ward, Travis Hunter top prospects — April 24-26", category: "NFL" },
  { id: 6, text: "🃏 2025-26 Panini Prizm Basketball releasing soon — Cooper Flagg RC", category: "Cards" },
  { id: 7, text: "🏀 NBA: Nikola Jokic leads Nuggets in playoff push", category: "NBA" },
  { id: 8, text: "🏒 NHL Playoffs: Stanley Cup race heating up", category: "NHL" },
  { id: 9, text: "🃏 PSA grading: 15 business days for bulk submissions", category: "Cards" },
  { id: 10, text: "⚽ MLS: Lionel Messi leads Inter Miami into playoff contention", category: "MLS" },
];

const CATEGORY_COLORS: Record<string, string> = {
  NCAA:  "text-orange-400",
  NBA:   "text-orange-300",
  WNBA:  "text-pink-400",
  MLB:   "text-blue-400",
  NFL:   "text-green-400",
  CFB:   "text-yellow-400",
  NHL:   "text-cyan-400",
  MLS:   "text-emerald-400",
  Cards: "text-yellow-300",
  News:  "text-red-400",
};

interface TickerItem {
  type: string;
  text: string;
  league?: string;
}

export default function SportsTicker() {
  const { data: liveItems } = trpc.sportsData.tickerNews.useQuery(undefined, {
    staleTime: 5 * 60 * 1000,
    refetchInterval: 10 * 60 * 1000,
    refetchOnWindowFocus: false,
  });

  const items: { id: number; text: string; category: string }[] = (() => {
    if (liveItems && liveItems.length > 0) {
      return liveItems.map((item: TickerItem, i: number) => {
        let category = "News";
        if (item.type === "release") category = "Cards";
        else if (item.type === "news" && item.league) {
          const leagueMap: Record<string, string> = {
            "NCAA Men's Basketball": "NCAA",
            "NCAA Women's Basketball": "NCAA",
            "MLB": "MLB", "NHL": "NHL", "NBA": "NBA", "NFL": "NFL", "MLS": "MLS",
          };
          category = leagueMap[item.league] ?? "News";
        }
        return { id: i, text: item.text, category };
      });
    }
    return FALLBACK_ITEMS;
  })();

  const trackRef = useRef<HTMLDivElement>(null);
  const pausedRef = useRef(false);
  const posRef = useRef(0);
  const rafRef = useRef<number>(0);

  useEffect(() => {
    const track = trackRef.current;
    if (!track) return;

    // Speed: pixels per frame at 60fps → ~1px/frame = 60px/s
    const speed = 0.6;

    const animate = () => {
      if (!pausedRef.current) {
        posRef.current += speed;
        const halfWidth = track.scrollWidth / 2;
        if (posRef.current >= halfWidth) posRef.current = 0;
        track.style.transform = `translateX(-${posRef.current}px)`;
      }
      rafRef.current = requestAnimationFrame(animate);
    };

    rafRef.current = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(rafRef.current);
  }, [items]);

  return (
    <div
      className="fixed bottom-0 left-0 right-0 z-[100] h-8 overflow-hidden select-none"
      style={{
        background: "linear-gradient(90deg, #0a0f1a 0%, #0d1527 50%, #0a0f1a 100%)",
        borderTop: "1px solid rgba(196,30,58,0.4)",
        boxShadow: "0 -2px 20px rgba(0,0,0,0.6)",
      }}
      onMouseEnter={() => { pausedRef.current = true; }}
      onMouseLeave={() => { pausedRef.current = false; }}
    >
      {/* Left fade + label */}
      <div className="absolute left-0 top-0 bottom-0 z-10 flex items-center pointer-events-none">
        <div
          className="flex items-center gap-1.5 px-3 h-full shrink-0"
          style={{ background: "linear-gradient(90deg, #0a0f1a 70%, transparent)" }}
        >
          <span
            className="text-[10px] font-black tracking-[0.2em] text-[#c41e3a] uppercase"
            style={{ fontFamily: "Oswald, sans-serif" }}
          >
            SCO NEWS
          </span>
          <span className="w-px h-3 bg-[#c41e3a]/50" />
        </div>
      </div>

      {/* Right fade */}
      <div
        className="absolute right-0 top-0 bottom-0 w-16 z-10 pointer-events-none"
        style={{ background: "linear-gradient(270deg, #0a0f1a 60%, transparent)" }}
      />

      {/* Scrolling track — duplicated for seamless loop */}
      <div className="flex items-center h-full pl-24">
        <div ref={trackRef} className="flex items-center gap-0 whitespace-nowrap will-change-transform">
          {[0, 1].map((pass) => (
            <div key={pass} className="flex items-center gap-0 shrink-0">
              {items.map((item, i) => (
                <span key={`${pass}-${i}`} className="inline-flex items-center gap-2 px-5">
                  <span
                    className={`text-[10px] font-black tracking-widest uppercase ${CATEGORY_COLORS[item.category] ?? "text-yellow-400"}`}
                    style={{ fontFamily: "Oswald, sans-serif" }}
                  >
                    {item.category}
                  </span>
                  <span className="text-[#c41e3a]/50 text-xs">▸</span>
                  <span
                    className="text-[11px] text-white/80 font-medium tracking-wide"
                    style={{ fontFamily: "Inter, sans-serif" }}
                  >
                    {item.text.replace(/^[^\s]+\s/, "")}
                  </span>
                  <span className="text-white/20 text-xs mx-2">◆</span>
                </span>
              ))}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
