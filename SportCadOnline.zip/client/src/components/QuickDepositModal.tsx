import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { Coins, Zap, Crown, Star, Gift, Sparkles, ExternalLink } from "lucide-react";

type PackageId = "25" | "50" | "100" | "250" | "500" | "1000";

interface Package {
  id: PackageId;
  credits: number;
  bonus: number;
  price: number;
  label: string;
  icon: React.ReactNode;
  color: string;
  border: string;
  badge?: string;
  popular?: boolean;
  best?: boolean;
}

const PACKAGES: Package[] = [
  {
    id: "25",
    credits: 25,
    bonus: 0,
    price: 25,
    label: "Starter",
    icon: <Gift className="w-5 h-5" />,
    color: "from-slate-700 to-slate-900",
    border: "border-slate-500/40",
  },
  {
    id: "50",
    credits: 50,
    bonus: 0,
    price: 50,
    label: "Player",
    icon: <Coins className="w-5 h-5" />,
    color: "from-blue-700 to-blue-900",
    border: "border-blue-500/40",
  },
  {
    id: "100",
    credits: 100,
    bonus: 0,
    price: 100,
    label: "Pro",
    icon: <Star className="w-5 h-5" />,
    color: "from-green-700 to-green-900",
    border: "border-green-500/40",
    popular: true,
  },
  {
    id: "250",
    credits: 250,
    bonus: 6,
    price: 250,
    label: "High Roller",
    icon: <Zap className="w-5 h-5" />,
    color: "from-purple-700 to-purple-900",
    border: "border-purple-500/40",
    badge: "+6 BONUS",
  },
  {
    id: "500",
    credits: 500,
    bonus: 25,
    price: 500,
    label: "Whale",
    icon: <Sparkles className="w-5 h-5" />,
    color: "from-orange-600 to-red-800",
    border: "border-orange-500/40",
    badge: "+25 BONUS",
    best: true,
  },
  {
    id: "1000",
    credits: 1000,
    bonus: 100,
    price: 1000,
    label: "Elite",
    icon: <Crown className="w-5 h-5" />,
    color: "from-yellow-500 to-amber-700",
    border: "border-yellow-400/60",
    badge: "+100 BONUS",
  },
];

interface QuickDepositModalProps {
  open: boolean;
  onClose: () => void;
  currentCredits?: number;
  returnPath?: string;
}

export default function QuickDepositModal({ open, onClose, currentCredits = 0, returnPath }: QuickDepositModalProps) {
  const [selectedId, setSelectedId] = useState<PackageId>("100");
  const [loading, setLoading] = useState(false);

  const buyCredits = trpc.credits.buyCredits.useMutation({
    onSuccess: (data) => {
      if (data.url) {
        toast.success("Redirecting to secure checkout...", { duration: 3000 });
        window.open(data.url, "_blank");
        onClose();
      }
    },
    onError: (err) => {
      toast.error(err.message || "Failed to start checkout.");
      setLoading(false);
    },
  });

  const handleBuy = () => {
    setLoading(true);
    buyCredits.mutate({
      packageId: selectedId,
      origin: window.location.origin,
      returnPath: returnPath || "/game-room",
    });
  };

  const selected = PACKAGES.find(p => p.id === selectedId)!;
  const totalCredits = selected.credits + selected.bonus;

  return (
    <Dialog open={open} onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="max-w-lg bg-[#060e1a] border border-yellow-500/30 text-white p-0 overflow-hidden">
        {/* Header */}
        <div className="bg-gradient-to-r from-yellow-600/20 via-amber-500/10 to-yellow-600/20 border-b border-yellow-500/20 px-6 py-4">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-yellow-400 font-black text-xl" style={{ fontFamily: "Oswald, sans-serif" }}>
              <Zap className="w-5 h-5 animate-pulse" />
              QUICK DEPOSIT
            </DialogTitle>
          </DialogHeader>
          <div className="flex items-center gap-2 mt-1">
            <Coins className="w-4 h-4 text-yellow-400/70" />
            <span className="text-white/50 text-sm">Current balance:</span>
            <span className="text-yellow-400 font-black text-sm">{currentCredits.toLocaleString()} credits</span>
          </div>
        </div>

        {/* Package grid */}
        <div className="px-6 py-4">
          <p className="text-white/40 text-xs font-bold uppercase tracking-widest mb-3">Select a package</p>
          <div className="grid grid-cols-3 gap-2">
            {PACKAGES.map((pkg) => (
              <button
                key={pkg.id}
                onClick={() => setSelectedId(pkg.id)}
                className={`relative rounded-xl border-2 p-3 text-center transition-all duration-200 overflow-hidden
                  ${selectedId === pkg.id
                    ? `${pkg.border.replace("/40", "")} ring-2 ring-yellow-400/60 scale-[1.03]`
                    : `${pkg.border} hover:scale-[1.01]`
                  }`}
                style={{ background: selectedId === pkg.id ? undefined : "rgba(0,0,0,0.4)" }}
              >
                {selectedId === pkg.id && (
                  <div className={`absolute inset-0 bg-gradient-to-b ${pkg.color} opacity-30`} />
                )}

                {/* Popular / Best badge */}
                {pkg.popular && (
                  <div className="absolute -top-0.5 -right-0.5 bg-green-500 text-white text-[8px] font-black px-1.5 py-0.5 rounded-bl-lg">
                    POPULAR
                  </div>
                )}
                {pkg.best && (
                  <div className="absolute -top-0.5 -right-0.5 bg-orange-500 text-white text-[8px] font-black px-1.5 py-0.5 rounded-bl-lg">
                    BEST VALUE
                  </div>
                )}

                <div className="relative z-10">
                  <div className="flex justify-center mb-1 text-white/70">{pkg.icon}</div>
                  <p className="text-white font-black text-base leading-none">{pkg.credits}</p>
                  {pkg.bonus > 0 && (
                    <p className="text-yellow-400 text-[10px] font-bold">+{pkg.bonus} bonus</p>
                  )}
                  <p className="text-white/40 text-[10px] mt-0.5">{pkg.label}</p>
                  <p className="text-white/70 font-bold text-xs mt-1">${pkg.price}</p>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Summary + CTA */}
        <div className="px-6 pb-6">
          <div className="bg-black/40 border border-white/10 rounded-xl p-4 mb-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-white/50 text-xs">You'll receive</p>
                <p className="text-yellow-400 font-black text-2xl leading-none">
                  {totalCredits.toLocaleString()}
                  <span className="text-white/50 text-sm font-normal ml-1">credits</span>
                </p>
                {selected.bonus > 0 && (
                  <p className="text-green-400 text-xs mt-0.5">Includes {selected.bonus} bonus credits!</p>
                )}
              </div>
              <div className="text-right">
                <p className="text-white/50 text-xs">Total</p>
                <p className="text-white font-black text-2xl">${selected.price}</p>
                <p className="text-white/30 text-[10px]">
                  ${(selected.price / totalCredits).toFixed(2)}/credit
                </p>
              </div>
            </div>
            <div className="mt-3 pt-3 border-t border-white/10 space-y-1">
              <p className="text-white/40 text-xs">
                After purchase, credits are added instantly. Use them for auctions, grading, and all casino games.
              </p>
              <a href="/loyalty" className="text-yellow-400/60 text-xs hover:text-yellow-400 transition-colors">
                🏆 View your loyalty tier for deposit bonuses →
              </a>
            </div>
          </div>

          <Button
            className="w-full font-black text-base gap-2 bg-yellow-500 hover:bg-yellow-400 text-black h-12"
            onClick={handleBuy}
            disabled={loading}
          >
            {loading ? (
              <>
                <div className="w-4 h-4 border-2 border-black/30 border-t-black rounded-full animate-spin" />
                Opening Checkout...
              </>
            ) : (
              <>
                <ExternalLink className="w-4 h-4" />
                Buy {totalCredits} Credits — ${selected.price}
              </>
            )}
          </Button>
          <p className="text-white/20 text-[10px] text-center mt-2">
            Secure checkout via Stripe · Opens in new tab
          </p>
        </div>
      </DialogContent>
    </Dialog>
  );
}
