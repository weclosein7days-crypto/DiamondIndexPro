/**
 * MascotCharacter — Maverick (boy, Dallas Mavericks) & Caitlin (girl, Indiana Fever)
 * Custom art made for SportCardsOnline.com Kids Corner.
 *
 * The single source image contains both characters side-by-side.
 * We use CSS object-position to "crop" to each character independently,
 * then layer speech bubbles and CSS keyframe animations on top.
 *
 * States:
 *  idle       — sitting, occasional wave
 *  excited    — bouncing up and down
 *  cheer      — arms up, big smile (win)
 *  sad        — head drop (loss)
 *  thinking   — finger on chin (trivia)
 *  hype       — jumping (card pull reveal)
 *  celebrate  — full party mode (level-up)
 *  watching   — leaning forward, eyes wide
 */

import { useEffect, useState, useRef } from "react";

const MASCOT_CDN = "https://d2xsxph8kpxj0f.cloudfront.net/310519663522483910/L9wJitqmU3uwF2WPjH8hRS/kids-corner-mascot_08fe6054.jpg";

export type MascotState =
  | "idle"
  | "excited"
  | "cheer"
  | "sad"
  | "thinking"
  | "hype"
  | "celebrate"
  | "watching";

export type MascotCharacter = "maverick" | "caitlin" | "both";

interface MascotProps {
  character?: MascotCharacter;
  state?: MascotState;
  size?: "sm" | "md" | "lg" | "xl";
  speech?: string;
  speechSide?: "left" | "right" | "top";
  className?: string;
  /** Auto-cycle through idle animations */
  animated?: boolean;
  /** Flip horizontally */
  flip?: boolean;
}

// Speech bubble messages for each state
const STATE_SPEECHES: Record<MascotState, string[]> = {
  idle:      ["Wanna trade?", "Check out my cards!", "Let's play! 🎮", "What's your favorite team?"],
  excited:   ["OH YEAH! 🔥", "Let's GO!", "This is gonna be EPIC!", "I'm so pumped! 🏀"],
  cheer:     ["YESSS! 🏆", "YOU DID IT!", "WINNER WINNER! 🎉", "That's what I'm talking about!"],
  sad:       ["Aww, tough break...", "You'll get 'em next time!", "Don't give up! 💪", "Shake it off!"],
  thinking:  ["Hmm, let me think...", "Do you know this one?", "Use your sports brain! 🧠", "Think carefully..."],
  hype:      ["OH WOW! 🤩", "LEGENDARY PULL??", "OPEN IT! OPEN IT!", "This could be HUGE! 🎴"],
  celebrate: ["LEVEL UP! 🚀", "YOU'RE A SUPERSTAR! ⭐", "HALL OF FAME MATERIAL!", "INCREDIBLE! 🏆🎊"],
  watching:  ["Ooh, nice move!", "I see what you're doing...", "Go for it!", "You've got this! 👀"],
};

const SIZE_MAP = {
  sm: { width: 80,  height: 80  },
  md: { width: 120, height: 120 },
  lg: { width: 180, height: 180 },
  xl: { width: 260, height: 260 },
};

// CSS animation keyframes injected once
const KEYFRAMES = `
@keyframes mascot-bounce {
  0%, 100% { transform: translateY(0); }
  50% { transform: translateY(-12px); }
}
@keyframes mascot-shake {
  0%, 100% { transform: rotate(0deg); }
  20% { transform: rotate(-8deg); }
  40% { transform: rotate(8deg); }
  60% { transform: rotate(-5deg); }
  80% { transform: rotate(5deg); }
}
@keyframes mascot-pulse {
  0%, 100% { transform: scale(1); }
  50% { transform: scale(1.08); }
}
@keyframes mascot-droop {
  0% { transform: translateY(0) rotate(0deg); }
  100% { transform: translateY(6px) rotate(-5deg); }
}
@keyframes mascot-wave {
  0%, 100% { transform: rotate(0deg); }
  25% { transform: rotate(-3deg); }
  75% { transform: rotate(3deg); }
}
@keyframes mascot-celebrate {
  0%   { transform: translateY(0) scale(1) rotate(0deg); }
  25%  { transform: translateY(-20px) scale(1.1) rotate(-5deg); }
  50%  { transform: translateY(0) scale(1) rotate(5deg); }
  75%  { transform: translateY(-15px) scale(1.05) rotate(-3deg); }
  100% { transform: translateY(0) scale(1) rotate(0deg); }
}
@keyframes mascot-hype {
  0%, 100% { transform: translateY(0) scale(1); }
  30%  { transform: translateY(-18px) scale(1.12); }
  60%  { transform: translateY(-8px) scale(1.05); }
}
@keyframes speech-pop {
  0%   { transform: scale(0.5) translateY(8px); opacity: 0; }
  70%  { transform: scale(1.05) translateY(-2px); opacity: 1; }
  100% { transform: scale(1) translateY(0); opacity: 1; }
}
@keyframes mascot-idle-float {
  0%, 100% { transform: translateY(0); }
  50% { transform: translateY(-5px); }
}
`;

const STATE_ANIMATION: Record<MascotState, string> = {
  idle:      "mascot-idle-float 3s ease-in-out infinite",
  excited:   "mascot-bounce 0.5s ease-in-out infinite",
  cheer:     "mascot-celebrate 0.8s ease-in-out infinite",
  sad:       "mascot-droop 0.4s ease-out forwards",
  thinking:  "mascot-wave 2s ease-in-out infinite",
  hype:      "mascot-hype 0.6s ease-in-out infinite",
  celebrate: "mascot-celebrate 0.7s ease-in-out infinite",
  watching:  "mascot-pulse 2s ease-in-out infinite",
};

let keyframesInjected = false;

function injectKeyframes() {
  if (keyframesInjected) return;
  keyframesInjected = true;
  const style = document.createElement("style");
  style.textContent = KEYFRAMES;
  document.head.appendChild(style);
}

// ── Single character (cropped from the full image) ────────────────────────────
function SingleMascot({
  character,
  state = "idle",
  size = "md",
  speech,
  speechSide = "top",
  flip = false,
}: {
  character: "maverick" | "caitlin";
  state?: MascotState;
  size?: keyof typeof SIZE_MAP;
  speech?: string;
  speechSide?: "left" | "right" | "top";
  flip?: boolean;
}) {
  const { width, height } = SIZE_MAP[size];
  const animation = STATE_ANIMATION[state];

  // The full image is ~800×800. Maverick occupies the left ~50%, Caitlin the right ~50%.
  // We render the full image at 2× the desired width and shift it left/right.
  const imgWidth = width * 2;
  const objectPosition = character === "maverick" ? "0% center" : "100% center";

  return (
    <div style={{ position: "relative", display: "inline-flex", flexDirection: "column", alignItems: "center" }}>
      {/* Speech bubble — top */}
      {speech && speechSide === "top" && (
        <div style={{
          position: "absolute",
          bottom: "100%",
          left: "50%",
          transform: "translateX(-50%)",
          marginBottom: 8,
          background: "white",
          color: "#1a1a2e",
          borderRadius: 14,
          padding: "6px 10px",
          fontSize: Math.max(10, width * 0.09),
          fontWeight: 900,
          whiteSpace: "nowrap",
          maxWidth: 200,
          textAlign: "center",
          boxShadow: "0 4px 16px rgba(0,0,0,0.25)",
          animation: "speech-pop 0.3s ease-out forwards",
          zIndex: 10,
          fontFamily: "Oswald, sans-serif",
        }}>
          {speech}
          {/* Tail */}
          <div style={{
            position: "absolute",
            top: "100%",
            left: "50%",
            transform: "translateX(-50%)",
            width: 0,
            height: 0,
            borderLeft: "6px solid transparent",
            borderRight: "6px solid transparent",
            borderTop: "8px solid white",
          }} />
        </div>
      )}

      {/* Character image */}
      <div style={{
        width,
        height,
        overflow: "hidden",
        borderRadius: "50% 50% 45% 45%",
        animation,
        transform: flip ? "scaleX(-1)" : undefined,
        filter: state === "sad" ? "saturate(0.6) brightness(0.85)" : undefined,
        transition: "filter 0.3s",
      }}>
        <img
          src={MASCOT_CDN}
          alt={character === "maverick" ? "Maverick" : "Caitlin"}
          style={{
            width: imgWidth,
            height: "auto",
            objectFit: "cover",
            objectPosition,
            marginLeft: character === "maverick" ? 0 : -width,
            display: "block",
            pointerEvents: "none",
            userSelect: "none",
          }}
          draggable={false}
        />
      </div>

      {/* Speech bubble — left */}
      {speech && speechSide === "left" && (
        <div style={{
          position: "absolute",
          right: "100%",
          top: "30%",
          marginRight: 8,
          background: "white",
          color: "#1a1a2e",
          borderRadius: 14,
          padding: "6px 10px",
          fontSize: Math.max(10, width * 0.09),
          fontWeight: 900,
          whiteSpace: "nowrap",
          maxWidth: 180,
          textAlign: "center",
          boxShadow: "0 4px 16px rgba(0,0,0,0.25)",
          animation: "speech-pop 0.3s ease-out forwards",
          zIndex: 10,
          fontFamily: "Oswald, sans-serif",
        }}>
          {speech}
          <div style={{
            position: "absolute",
            top: "50%",
            left: "100%",
            transform: "translateY(-50%)",
            width: 0, height: 0,
            borderTop: "6px solid transparent",
            borderBottom: "6px solid transparent",
            borderLeft: "8px solid white",
          }} />
        </div>
      )}

      {/* Speech bubble — right */}
      {speech && speechSide === "right" && (
        <div style={{
          position: "absolute",
          left: "100%",
          top: "30%",
          marginLeft: 8,
          background: "white",
          color: "#1a1a2e",
          borderRadius: 14,
          padding: "6px 10px",
          fontSize: Math.max(10, width * 0.09),
          fontWeight: 900,
          whiteSpace: "nowrap",
          maxWidth: 180,
          textAlign: "center",
          boxShadow: "0 4px 16px rgba(0,0,0,0.25)",
          animation: "speech-pop 0.3s ease-out forwards",
          zIndex: 10,
          fontFamily: "Oswald, sans-serif",
        }}>
          {speech}
          <div style={{
            position: "absolute",
            top: "50%",
            right: "100%",
            transform: "translateY(-50%)",
            width: 0, height: 0,
            borderTop: "6px solid transparent",
            borderBottom: "6px solid transparent",
            borderRight: "8px solid white",
          }} />
        </div>
      )}

      {/* Name tag */}
      <div style={{
        marginTop: 4,
        fontSize: Math.max(9, width * 0.08),
        fontWeight: 900,
        color: character === "maverick" ? "#60a5fa" : "#f472b6",
        fontFamily: "Oswald, sans-serif",
        letterSpacing: "0.05em",
        textTransform: "uppercase",
      }}>
        {character === "maverick" ? "Maverick" : "Caitlin"}
      </div>
    </div>
  );
}

// ── Full image (both characters) ──────────────────────────────────────────────
function BothMascots({
  state = "idle",
  size = "lg",
  speech,
}: {
  state?: MascotState;
  size?: keyof typeof SIZE_MAP;
  speech?: string;
}) {
  const { width, height } = SIZE_MAP[size];
  const animation = STATE_ANIMATION[state];
  return (
    <div style={{ position: "relative", display: "inline-block" }}>
      {speech && (
        <div style={{
          position: "absolute",
          bottom: "100%",
          left: "50%",
          transform: "translateX(-50%)",
          marginBottom: 8,
          background: "white",
          color: "#1a1a2e",
          borderRadius: 14,
          padding: "8px 14px",
          fontSize: 13,
          fontWeight: 900,
          whiteSpace: "nowrap",
          maxWidth: 280,
          textAlign: "center",
          boxShadow: "0 4px 16px rgba(0,0,0,0.3)",
          animation: "speech-pop 0.3s ease-out forwards",
          zIndex: 10,
          fontFamily: "Oswald, sans-serif",
        }}>
          {speech}
          <div style={{
            position: "absolute",
            top: "100%",
            left: "50%",
            transform: "translateX(-50%)",
            width: 0, height: 0,
            borderLeft: "7px solid transparent",
            borderRight: "7px solid transparent",
            borderTop: "9px solid white",
          }} />
        </div>
      )}
      <img
        src={MASCOT_CDN}
        alt="Maverick and Caitlin"
        style={{
          width,
          height,
          objectFit: "cover",
          borderRadius: 16,
          animation,
          display: "block",
          pointerEvents: "none",
          userSelect: "none",
        }}
        draggable={false}
      />
    </div>
  );
}

// ── Main exported component ───────────────────────────────────────────────────
export default function MascotCharacter({
  character = "both",
  state = "idle",
  size = "md",
  speech: propSpeech,
  speechSide = "top",
  className = "",
  animated = true,
  flip = false,
}: MascotProps) {
  const [currentSpeech, setCurrentSpeech] = useState<string | undefined>(propSpeech);
  const [currentState, setCurrentState] = useState<MascotState>(state);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    injectKeyframes();
  }, []);

  // Sync external state changes
  useEffect(() => {
    setCurrentState(state);
    if (propSpeech !== undefined) {
      setCurrentSpeech(propSpeech);
    }
  }, [state, propSpeech]);

  // Auto-rotate idle speeches
  useEffect(() => {
    if (!animated || propSpeech !== undefined) return;
    const speeches = STATE_SPEECHES[currentState];
    let idx = 0;
    setCurrentSpeech(speeches[0]);
    timerRef.current = setInterval(() => {
      idx = (idx + 1) % speeches.length;
      setCurrentSpeech(speeches[idx]);
    }, 4000);
    return () => { if (timerRef.current) clearInterval(timerRef.current); };
  }, [currentState, animated, propSpeech]);

  return (
    <div className={className} style={{ display: "inline-flex", alignItems: "flex-end", gap: 8 }}>
      {character === "both" ? (
        <BothMascots state={currentState} size={size} speech={currentSpeech} />
      ) : (
        <SingleMascot
          character={character}
          state={currentState}
          size={size}
          speech={currentSpeech}
          speechSide={speechSide}
          flip={flip}
        />
      )}
    </div>
  );
}

// ── Convenience: Courtside Duo (fixed position, bottom corners) ───────────────
export function CourtsideMascots({
  leftState = "watching",
  rightState = "watching",
  leftSpeech,
  rightSpeech,
  size = "md",
}: {
  leftState?: MascotState;
  rightState?: MascotState;
  leftSpeech?: string;
  rightSpeech?: string;
  size?: keyof typeof SIZE_MAP;
}) {
  useEffect(() => { injectKeyframes(); }, []);
  return (
    <>
      {/* Maverick — bottom left */}
      <div style={{
        position: "fixed",
        bottom: 16,
        left: 16,
        zIndex: 40,
        pointerEvents: "none",
      }}>
        <SingleMascot character="maverick" state={leftState} size={size} speech={leftSpeech} speechSide="right" />
      </div>
      {/* Caitlin — bottom right */}
      <div style={{
        position: "fixed",
        bottom: 16,
        right: 16,
        zIndex: 40,
        pointerEvents: "none",
      }}>
        <SingleMascot character="caitlin" state={rightState} size={size} speech={rightSpeech} speechSide="left" flip />
      </div>
    </>
  );
}

// ── Convenience: Trivia Host ──────────────────────────────────────────────────
export function TriviaHost({
  question,
  character = "maverick",
}: {
  question: string;
  character?: "maverick" | "caitlin";
}) {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 12 }}>
      <SingleMascot character={character} state="thinking" size="sm" />
      <div style={{
        background: "rgba(255,255,255,0.08)",
        border: "1px solid rgba(255,255,255,0.15)",
        borderRadius: 16,
        padding: "10px 14px",
        flex: 1,
      }}>
        <p style={{
          color: "white",
          fontWeight: 900,
          fontSize: 15,
          fontFamily: "Oswald, sans-serif",
          lineHeight: 1.4,
          margin: 0,
        }}>{question}</p>
      </div>
    </div>
  );
}

// ── Convenience: Level-up Celebration ────────────────────────────────────────
export function LevelUpCelebration({ levelName, onDone }: { levelName: string; onDone: () => void }) {
  useEffect(() => {
    injectKeyframes();
    const t = setTimeout(onDone, 4000);
    return () => clearTimeout(t);
  }, [onDone]);

  return (
    <div style={{
      position: "fixed",
      inset: 0,
      zIndex: 9999,
      background: "rgba(0,0,0,0.85)",
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      justifyContent: "center",
      gap: 16,
    }}>
      <div style={{ animation: "mascot-celebrate 0.7s ease-in-out infinite" }}>
        <img
          src={MASCOT_CDN}
          alt="Level Up!"
          style={{ width: 280, height: 280, objectFit: "cover", borderRadius: 20 }}
          draggable={false}
        />
      </div>
      <div style={{
        background: "linear-gradient(135deg, #f59e0b, #ef4444)",
        borderRadius: 20,
        padding: "16px 32px",
        textAlign: "center",
        boxShadow: "0 0 40px rgba(245,158,11,0.6)",
      }}>
        <p style={{ color: "white", fontFamily: "Oswald, sans-serif", fontSize: 14, margin: 0, opacity: 0.8 }}>LEVEL UP!</p>
        <p style={{ color: "white", fontFamily: "Oswald, sans-serif", fontSize: 32, fontWeight: 900, margin: "4px 0 0" }}>
          🏆 {levelName}
        </p>
      </div>
      <p style={{ color: "rgba(255,255,255,0.5)", fontSize: 12 }}>Maverick & Caitlin are cheering for you!</p>
    </div>
  );
}
