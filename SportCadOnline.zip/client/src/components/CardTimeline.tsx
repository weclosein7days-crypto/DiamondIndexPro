import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import {
  PackagePlus, Star, ShoppingBag, Gavel, ArrowLeftRight,
  DollarSign, Truck, CheckCircle2, StickyNote, Download,
  Clock, Tag, AlertCircle, Package
} from "lucide-react";

const EVENT_CONFIG: Record<string, { icon: typeof PackagePlus; color: string; label: string }> = {
  added:               { icon: PackagePlus,     color: "text-blue-400",    label: "Added to Collection" },
  graded:              { icon: Star,            color: "text-yellow-400",  label: "Graded" },
  listed:              { icon: ShoppingBag,     color: "text-green-400",   label: "Listed in Arena" },
  delisted:            { icon: ShoppingBag,     color: "text-gray-400",    label: "Delisted" },
  auction_started:     { icon: Gavel,           color: "text-orange-400",  label: "Auction Started" },
  auction_ended:       { icon: Gavel,           color: "text-orange-300",  label: "Auction Ended" },
  bid_received:        { icon: Tag,             color: "text-purple-400",  label: "Bid Received" },
  trade_offered:       { icon: ArrowLeftRight,  color: "text-cyan-400",    label: "Trade Offered" },
  trade_agreed:        { icon: ArrowLeftRight,  color: "text-cyan-300",    label: "Trade Agreed" },
  trade_fee_paid:      { icon: DollarSign,      color: "text-green-300",   label: "Trade Fee Paid" },
  shipped_to_scg:      { icon: Truck,           color: "text-blue-300",    label: "Shipped to SCG" },
  received_by_scg:     { icon: Package,         color: "text-blue-200",    label: "Received by SCG" },
  shipped_to_recipient:{ icon: Truck,           color: "text-purple-300",  label: "Shipped to Recipient" },
  delivered:           { icon: CheckCircle2,    color: "text-green-400",   label: "Delivered" },
  sold:                { icon: DollarSign,      color: "text-emerald-400", label: "Sold" },
  traded:              { icon: ArrowLeftRight,  color: "text-emerald-300", label: "Trade Completed" },
  price_updated:       { icon: Tag,             color: "text-yellow-300",  label: "Price Updated" },
  note_added:          { icon: StickyNote,      color: "text-gray-300",    label: "Note Added" },
  imported:            { icon: Download,        color: "text-blue-400",    label: "Imported" },
};

interface CardTimelineProps {
  collectionItemId: number;
  ownerEmail?: string;
}

export function CardTimeline({ collectionItemId }: CardTimelineProps) {
  const [noteText, setNoteText] = useState("");
  const [showNoteInput, setShowNoteInput] = useState(false);

  const { data: events, refetch, isLoading } = trpc.collection.getEvents.useQuery(
    { id: collectionItemId },
    { enabled: !!collectionItemId }
  );

  const addNote = trpc.collection.addNote.useMutation({
    onSuccess: () => {
      toast.success("Note added to card history");
      setNoteText("");
      setShowNoteInput(false);
      refetch();
    },
    onError: (e) => toast.error(e.message || "Failed to add note"),
  });

  const handleAddNote = () => {
    if (!noteText.trim()) return;
    addNote.mutate({ id: collectionItemId, note: noteText.trim() });
  };

  if (isLoading) {
    return (
      <div className="space-y-2 py-2">
        {[1, 2, 3].map(i => (
          <div key={i} className="flex gap-3 animate-pulse">
            <div className="w-7 h-7 rounded-full bg-white/10 shrink-0" />
            <div className="flex-1 space-y-1.5 pt-1">
              <div className="h-3 bg-white/10 rounded w-1/3" />
              <div className="h-2.5 bg-white/5 rounded w-2/3" />
            </div>
          </div>
        ))}
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {/* Add note button */}
      <div className="flex items-center justify-between">
        <span className="text-xs text-white/40 font-medium uppercase tracking-wider">Card History</span>
        <Button
          size="sm"
          variant="ghost"
          className="h-6 text-xs text-white/50 hover:text-white px-2"
          onClick={() => setShowNoteInput(!showNoteInput)}
        >
          <StickyNote className="w-3 h-3 mr-1" />
          Add Note
        </Button>
      </div>

      {showNoteInput && (
        <div className="space-y-2 bg-white/5 rounded-lg p-3">
          <Textarea
            value={noteText}
            onChange={e => setNoteText(e.target.value)}
            placeholder="Add a note to this card's history..."
            className="bg-white/5 border-white/10 text-white text-sm resize-none h-20"
            maxLength={500}
          />
          <div className="flex gap-2 justify-end">
            <Button size="sm" variant="ghost" className="h-7 text-xs text-white/40" onClick={() => setShowNoteInput(false)}>Cancel</Button>
            <Button size="sm" className="h-7 text-xs bg-blue-600 hover:bg-blue-700" onClick={handleAddNote} disabled={addNote.isPending || !noteText.trim()}>
              {addNote.isPending ? "Saving..." : "Save Note"}
            </Button>
          </div>
        </div>
      )}

      {/* Timeline */}
      {!events || events.length === 0 ? (
        <div className="flex flex-col items-center py-6 text-center">
          <Clock className="w-8 h-8 text-white/20 mb-2" />
          <p className="text-sm text-white/30">No history yet</p>
          <p className="text-xs text-white/20 mt-0.5">Events will appear here as this card moves through its lifecycle</p>
        </div>
      ) : (
        <div className="relative">
          {/* Vertical line */}
          <div className="absolute left-3.5 top-3 bottom-3 w-px bg-white/10" />
          <div className="space-y-3">
            {events.map((event, idx) => {
              const config = EVENT_CONFIG[event.eventType] ?? { icon: AlertCircle, color: "text-white/40", label: event.eventType };
              const Icon = config.icon;
              let metadata: Record<string, unknown> = {};
              try { if (event.metadata) metadata = JSON.parse(event.metadata); } catch {}
              return (
                <div key={event.id} className={`flex gap-3 ${idx === 0 ? "opacity-100" : "opacity-80"}`}>
                  <div className={`w-7 h-7 rounded-full bg-[#0d1f3c] border border-white/10 flex items-center justify-center shrink-0 z-10 ${config.color}`}>
                    <Icon className="w-3.5 h-3.5" />
                  </div>
                  <div className="flex-1 min-w-0 pt-0.5">
                    <div className="flex items-baseline gap-2 flex-wrap">
                      <span className={`text-xs font-semibold ${config.color}`}>{config.label}</span>
                      <span className="text-[10px] text-white/30">
                        {new Date(event.createdAt).toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric", hour: "2-digit", minute: "2-digit" })}
                      </span>
                    </div>
                    {event.description && (
                      <p className="text-xs text-white/50 mt-0.5 leading-relaxed">{event.description}</p>
                    )}
                    {Boolean(metadata.price) && (
                      <span className="inline-block mt-1 text-[10px] bg-green-500/10 text-green-400 px-1.5 py-0.5 rounded">
                        ${String(metadata.price)}
                      </span>
                    )}
                    {Boolean(metadata.tracking) && (
                      <span className="inline-block mt-1 text-[10px] bg-blue-500/10 text-blue-400 px-1.5 py-0.5 rounded font-mono">
                        {String(metadata.tracking)}
                      </span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
