/**
 * CardWinModal — Platform-wide card prize cash-out dialog.
 *
 * Used by every game (Pack Rip, Blackjack, Roulette, Spin Wheel, Poker, etc.)
 * whenever a real house card is awarded as a prize.
 *
 * Flow:
 *  1. Modal opens showing the card in an AcrylicCardCase with its value.
 *  2. Player chooses:
 *     a) "Take Credits"  → award card value as credits
 *     b) "Claim Card"    → second step: "Vault It (Free)" or "Ship It ($4.99)"
 *  3. If "Ship It", a shipping address form is shown before confirming.
 */
import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { AcrylicCardCase } from "@/components/AcrylicCardCase";
import { trpc } from "@/lib/trpc";
import { Coins, Package, Warehouse, Truck, CheckCircle, Loader2, X } from "lucide-react";

export interface CardPrize {
  id: number;
  playerName: string;
  year: string;
  setName: string;
  gradeScore: string | null;
  gradeCompany: string | null;
  frontImageUrl: string | null;
  price: number;
}

interface CardWinModalProps {
  open: boolean;
  prize: CardPrize | null;
  /** Outcome label shown at the top (e.g. "💎 MEGA JACKPOT!") */
  outcomeLabel?: string;
  /** Outcome type for glow colour */
  outcomeType?: "jackpot" | "mini_jackpot" | "card_prize" | string;
  onClose: () => void;
  /** Called after a successful claim so the parent can refresh balance */
  onClaimed?: (creditsAwarded: number, message: string) => void;
}

type Step = "choose" | "ship_form" | "done";

export function CardWinModal({
  open,
  prize,
  outcomeLabel,
  outcomeType,
  onClose,
  onClaimed,
}: CardWinModalProps) {
  const [step, setStep] = useState<Step>("choose");
  const [doneMessage, setDoneMessage] = useState("");
  const [shipName, setShipName] = useState("");
  const [shipAddress, setShipAddress] = useState("");
  const [shipCity, setShipCity] = useState("");
  const [shipState, setShipState] = useState("");
  const [shipZip, setShipZip] = useState("");

  const claimMutation = trpc.game.claimCardPrize.useMutation({
    onSuccess: (data) => {
      setDoneMessage(data.message);
      setStep("done");
      onClaimed?.(data.creditsAwarded, data.message);
    },
  });

  if (!prize) return null;

  const glowClass =
    outcomeType === "jackpot"
      ? "shadow-[0_0_60px_rgba(234,179,8,0.5)]"
      : outcomeType === "mini_jackpot"
      ? "shadow-[0_0_40px_rgba(168,85,247,0.4)]"
      : "shadow-[0_0_30px_rgba(59,130,246,0.35)]";

  const borderClass =
    outcomeType === "jackpot"
      ? "border-yellow-500"
      : outcomeType === "mini_jackpot"
      ? "border-purple-500"
      : "border-blue-500";

  const handleCredits = () => {
    claimMutation.mutate({ cardId: prize.id, choice: "credits" });
  };

  const handleVault = () => {
    claimMutation.mutate({ cardId: prize.id, choice: "vault" });
  };

  const handleShipSubmit = () => {
    const fullAddress = `${shipName}\n${shipAddress}\n${shipCity}, ${shipState} ${shipZip}`;
    claimMutation.mutate({
      cardId: prize.id,
      choice: "ship",
      shippingAddress: fullAddress,
      shippingName: shipName,
    });
  };

  const isLoading = claimMutation.isPending;

  return (
    <Dialog open={open} onOpenChange={(o) => { if (!o && step === "done") onClose(); }}>
      <DialogContent
        className={`max-w-md bg-gray-950 border-2 ${borderClass} ${glowClass} text-white`}
        style={{ fontFamily: "Oswald, sans-serif" }}
      >
        {/* Close button only after done */}
        {step === "done" && (
          <button
            onClick={onClose}
            className="absolute top-3 right-3 text-white/40 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        )}

        <DialogHeader className="pb-2">
          <DialogTitle className="text-center text-2xl font-black tracking-wide text-white">
            {outcomeLabel || "🃏 You Won a Card!"}
          </DialogTitle>
        </DialogHeader>

        {/* ── Step 1: Choose ── */}
        {step === "choose" && (
          <div className="flex flex-col items-center gap-5">
            {/* Card display */}
            <div className="relative">
              <AcrylicCardCase
                imageUrl={prize.frontImageUrl ?? undefined}
                cardName={prize.playerName}
                grade={prize.gradeScore ?? undefined}
                gradingCompany={prize.gradeCompany ?? "SCG"}
                size="lg"
                animated
              />
              {/* Value badge */}
              <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 whitespace-nowrap">
                <Badge className="bg-green-600 text-white text-xs font-bold px-3 py-1">
                  Est. Value: ${prize.price.toFixed(2)}
                </Badge>
              </div>
            </div>

            {/* Card info */}
            <div className="text-center mt-2">
              <p className="text-white font-black text-xl tracking-wide">{prize.playerName}</p>
              <p className="text-white/60 text-sm">
                {prize.year} {prize.setName}
                {prize.gradeScore && (
                  <span className="ml-2 text-yellow-400">
                    {prize.gradeCompany} {prize.gradeScore}
                  </span>
                )}
              </p>
            </div>

            {/* Choice buttons */}
            <div className="w-full space-y-3">
              <p className="text-center text-white/50 text-sm uppercase tracking-widest">
                What would you like to do?
              </p>

              {/* Take Credits */}
              <Button
                className="w-full h-14 bg-gradient-to-r from-yellow-600 to-orange-600 hover:from-yellow-500 hover:to-orange-500 text-white font-black text-base border-0"
                onClick={handleCredits}
                disabled={isLoading}
              >
                <Coins className="w-5 h-5 mr-2" />
                Take {Math.ceil(prize.price)} Credits
                <span className="ml-2 text-xs opacity-70">(card value in credits)</span>
              </Button>

              {/* Claim Card */}
              <Button
                className="w-full h-14 bg-gradient-to-r from-blue-700 to-indigo-700 hover:from-blue-600 hover:to-indigo-600 text-white font-black text-base border-0"
                onClick={() => setStep("ship_form")}
                disabled={isLoading}
              >
                <Package className="w-5 h-5 mr-2" />
                Claim the Card
                <span className="ml-2 text-xs opacity-70">(vault or ship)</span>
              </Button>
            </div>
          </div>
        )}

        {/* ── Step 2: Vault or Ship ── */}
        {step === "ship_form" && (
          <div className="flex flex-col gap-4">
            <p className="text-center text-white/70 text-sm">
              How should we handle your{" "}
              <span className="text-white font-bold">{prize.playerName}</span>?
            </p>

            {/* Vault option */}
            <button
              className="w-full rounded-xl border-2 border-green-600 bg-green-900/30 hover:bg-green-900/50 p-4 text-left transition-all group"
              onClick={handleVault}
              disabled={isLoading}
            >
              <div className="flex items-center gap-3">
                <Warehouse className="w-8 h-8 text-green-400 flex-shrink-0" />
                <div>
                  <p className="text-white font-black text-base">Vault It — Free</p>
                  <p className="text-green-300/70 text-xs mt-0.5">
                    We hold it safely at SCO's facility. View it in your Vault anytime. Ship later for $4.99.
                  </p>
                </div>
              </div>
            </button>

            {/* Ship option */}
            <div className="rounded-xl border-2 border-blue-600 bg-blue-900/20 p-4">
              <div className="flex items-center gap-3 mb-3">
                <Truck className="w-8 h-8 text-blue-400 flex-shrink-0" />
                <div>
                  <p className="text-white font-black text-base">Ship It — $4.99</p>
                  <p className="text-blue-300/70 text-xs mt-0.5">
                    We'll mail it to you within 3-5 business days in a protective sleeve.
                  </p>
                </div>
              </div>

              {/* Shipping form */}
              <div className="space-y-2">
                <div>
                  <Label className="text-white/60 text-xs">Full Name</Label>
                  <Input
                    value={shipName}
                    onChange={(e) => setShipName(e.target.value)}
                    placeholder="John Smith"
                    className="bg-white/5 border-white/20 text-white placeholder:text-white/30 h-9 text-sm"
                  />
                </div>
                <div>
                  <Label className="text-white/60 text-xs">Street Address</Label>
                  <Input
                    value={shipAddress}
                    onChange={(e) => setShipAddress(e.target.value)}
                    placeholder="123 Main St"
                    className="bg-white/5 border-white/20 text-white placeholder:text-white/30 h-9 text-sm"
                  />
                </div>
                <div className="grid grid-cols-5 gap-2">
                  <div className="col-span-2">
                    <Label className="text-white/60 text-xs">City</Label>
                    <Input
                      value={shipCity}
                      onChange={(e) => setShipCity(e.target.value)}
                      placeholder="Chicago"
                      className="bg-white/5 border-white/20 text-white placeholder:text-white/30 h-9 text-sm"
                    />
                  </div>
                  <div className="col-span-1">
                    <Label className="text-white/60 text-xs">State</Label>
                    <Input
                      value={shipState}
                      onChange={(e) => setShipState(e.target.value)}
                      placeholder="IL"
                      maxLength={2}
                      className="bg-white/5 border-white/20 text-white placeholder:text-white/30 h-9 text-sm"
                    />
                  </div>
                  <div className="col-span-2">
                    <Label className="text-white/60 text-xs">ZIP</Label>
                    <Input
                      value={shipZip}
                      onChange={(e) => setShipZip(e.target.value)}
                      placeholder="60601"
                      maxLength={10}
                      className="bg-white/5 border-white/20 text-white placeholder:text-white/30 h-9 text-sm"
                    />
                  </div>
                </div>
                <Button
                  className="w-full h-10 bg-blue-600 hover:bg-blue-500 text-white font-black text-sm mt-1"
                  onClick={handleShipSubmit}
                  disabled={isLoading || !shipName || !shipAddress || !shipCity || !shipState || !shipZip}
                >
                  {isLoading ? (
                    <Loader2 className="w-4 h-4 animate-spin mr-2" />
                  ) : (
                    <Truck className="w-4 h-4 mr-2" />
                  )}
                  Confirm — Ship for $4.99
                </Button>
              </div>
            </div>

            <Button
              variant="ghost"
              className="text-white/40 hover:text-white text-xs"
              onClick={() => setStep("choose")}
              disabled={isLoading}
            >
              ← Back
            </Button>
          </div>
        )}

        {/* ── Step 3: Done ── */}
        {step === "done" && (
          <div className="flex flex-col items-center gap-5 py-4">
            <CheckCircle className="w-16 h-16 text-green-400" />
            <p className="text-white font-black text-xl text-center">{doneMessage}</p>
            <Button
              className="w-full h-12 bg-green-600 hover:bg-green-500 text-white font-black text-base"
              onClick={onClose}
            >
              Continue Playing
            </Button>
          </div>
        )}

        {claimMutation.isError && (
          <p className="text-red-400 text-xs text-center mt-2">
            {claimMutation.error?.message || "Something went wrong. Please try again."}
          </p>
        )}
      </DialogContent>
    </Dialog>
  );
}
