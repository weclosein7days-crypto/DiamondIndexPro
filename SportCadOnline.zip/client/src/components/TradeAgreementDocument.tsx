import { useRef } from "react";
import { Button } from "@/components/ui/button";
import { Download, Printer } from "lucide-react";

const LOGO_URL = "https://d2xsxph8kpxj0f.cloudfront.net/310/pasted_file_NDxW0y_image.png";
const SCO_ADDRESS = "SportCardsOnline.com — SCO Secured Location";

interface TradeParty {
  name: string;
  email: string;
  address?: string;
  city?: string;
  state?: string;
  zip?: string;
  phone?: string;
  signedAt?: Date | string | null;
}

interface TradeCard {
  title: string;
  imageUrl?: string;
  grade?: string;
}

interface TradeAgreementDocumentProps {
  tradeId: number;
  initiator: TradeParty;
  receiver: TradeParty;
  offeredCards: TradeCard[];   // initiator's cards
  requestedCards: TradeCard[]; // receiver's cards
  agreedAt?: Date | string | null;
  ticketNumber?: string;
}

function formatAddress(p: TradeParty) {
  const parts = [p.address, [p.city, p.state, p.zip].filter(Boolean).join(", ")].filter(Boolean);
  return parts.join("\n") || "Address on file";
}

function formatDate(d?: Date | string | null) {
  if (!d) return new Date().toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric" });
  return new Date(d).toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric" });
}

function CursiveSignature({ name }: { name: string }) {
  return (
    <span
      style={{
        fontFamily: "'Dancing Script', 'Brush Script MT', cursive",
        fontSize: 28,
        color: "#1a237e",
        letterSpacing: 1,
        display: "inline-block",
        borderBottom: "2px solid #1a237e",
        paddingBottom: 2,
        minWidth: 180,
        lineHeight: 1.2,
      }}
    >
      {name}
    </span>
  );
}

function CardThumbDoc({ card }: { card: TradeCard }) {
  return (
    <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 4, width: 80 }}>
      <div style={{
        width: 60, height: 84, borderRadius: 4, overflow: "hidden",
        border: "1px solid #ccc", background: "#f5f5f5",
        display: "flex", alignItems: "center", justifyContent: "center"
      }}>
        {card.imageUrl ? (
          <img src={card.imageUrl} alt={card.title} style={{ width: "100%", height: "100%", objectFit: "cover" }} />
        ) : (
          <span style={{ fontSize: 24 }}>🃏</span>
        )}
      </div>
      {card.grade && (
        <span style={{ fontSize: 9, fontWeight: 700, color: "#b8860b", background: "#fffde7", border: "1px solid #f9a825", borderRadius: 3, padding: "1px 4px" }}>
          SCG {card.grade}
        </span>
      )}
      <p style={{ fontSize: 9, textAlign: "center", color: "#333", lineHeight: 1.2, maxWidth: 76, margin: 0 }}>{card.title}</p>
    </div>
  );
}

export default function TradeAgreementDocument({
  tradeId, initiator, receiver, offeredCards, requestedCards, agreedAt, ticketNumber
}: TradeAgreementDocumentProps) {
  const docRef = useRef<HTMLDivElement>(null);

  const handlePrint = () => {
    const content = docRef.current;
    if (!content) return;
    const printWindow = window.open("", "_blank", "width=900,height=700");
    if (!printWindow) return;
    printWindow.document.write(`
      <!DOCTYPE html>
      <html>
      <head>
        <title>SCO Trade Agreement #${tradeId}</title>
        <link href="https://fonts.googleapis.com/css2?family=Dancing+Script:wght@600&family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
        <style>
          * { margin: 0; padding: 0; box-sizing: border-box; }
          body { font-family: 'Inter', sans-serif; background: white; color: #111; }
          @media print {
            body { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
          }
        </style>
      </head>
      <body>
        ${content.innerHTML}
      </body>
      </html>
    `);
    printWindow.document.close();
    printWindow.focus();
    setTimeout(() => { printWindow.print(); }, 500);
  };

  const docDate = formatDate(agreedAt);
  const ticket = ticketNumber || `SCO-${tradeId}-${Date.now().toString().slice(-6)}`;

  return (
    <div>
      {/* Action buttons (not printed) */}
      <div className="flex gap-2 mb-4 no-print">
        <Button onClick={handlePrint} className="bg-[#1a237e] hover:bg-[#283593] text-white gap-2">
          <Printer className="w-4 h-4" /> Print Agreement
        </Button>
        <Button onClick={handlePrint} variant="outline" className="border-[#1a237e] text-[#1a237e] gap-2">
          <Download className="w-4 h-4" /> Download PDF
        </Button>
      </div>

      {/* The printable document */}
      <div
        ref={docRef}
        style={{
          background: "white",
          color: "#111",
          fontFamily: "'Inter', 'Helvetica Neue', Arial, sans-serif",
          maxWidth: 820,
          margin: "0 auto",
          padding: "40px 48px",
          border: "1px solid #e0e0e0",
          borderRadius: 8,
          fontSize: 13,
          lineHeight: 1.6,
        }}
      >
        {/* Google Fonts for print */}
        <link href="https://fonts.googleapis.com/css2?family=Dancing+Script:wght@600&family=Inter:wght@400;600;700&display=swap" rel="stylesheet" />

        {/* ── HEADER ── */}
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 24, borderBottom: "3px solid #C41E3A", paddingBottom: 16 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
            <img src={LOGO_URL} alt="SportCardsOnline" style={{ height: 56, width: "auto" }} />
            <div>
              <div style={{ fontSize: 20, fontWeight: 700, color: "#C41E3A", letterSpacing: 0.5 }}>SportCardsOnline.com</div>
              <div style={{ fontSize: 11, color: "#555", letterSpacing: 1, textTransform: "uppercase" }}>Official Trade Agreement</div>
            </div>
          </div>
          <div style={{ textAlign: "right" }}>
            <div style={{ fontSize: 11, color: "#777" }}>Agreement #</div>
            <div style={{ fontSize: 18, fontWeight: 700, color: "#1a237e" }}>{ticket}</div>
            <div style={{ fontSize: 11, color: "#777", marginTop: 2 }}>Date: {docDate}</div>
          </div>
        </div>

        {/* ── TITLE ── */}
        <div style={{ textAlign: "center", marginBottom: 24 }}>
          <h1 style={{ fontSize: 22, fontWeight: 700, color: "#1a237e", marginBottom: 4 }}>
            Sports Card Trade Agreement
          </h1>
          <p style={{ fontSize: 12, color: "#555" }}>
            This agreement is entered into between the two parties listed below, facilitated and escrowed by SportCardsOnline.com ("SCO").
          </p>
        </div>

        {/* ── PARTIES ── */}
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20, marginBottom: 24 }}>
          {[
            { label: "Party A — Trade Initiator", party: initiator, cards: offeredCards, side: "#C41E3A" },
            { label: "Party B — Trade Receiver", party: receiver, cards: requestedCards, side: "#1a237e" },
          ].map(({ label, party, cards, side }) => (
            <div key={label} style={{ border: `2px solid ${side}`, borderRadius: 8, overflow: "hidden" }}>
              <div style={{ background: side, color: "white", padding: "8px 14px", fontSize: 11, fontWeight: 700, letterSpacing: 1, textTransform: "uppercase" }}>
                {label}
              </div>
              <div style={{ padding: "12px 14px" }}>
                <p style={{ fontWeight: 700, fontSize: 14, marginBottom: 2 }}>{party.name || "—"}</p>
                <p style={{ color: "#555", fontSize: 11, marginBottom: 6 }}>{party.email}</p>
                {party.phone && <p style={{ fontSize: 11, color: "#444", marginBottom: 2 }}>📞 {party.phone}</p>}
                <p style={{ fontSize: 11, color: "#444", whiteSpace: "pre-line" }}>
                  📍 {formatAddress(party)}
                </p>

                {/* Cards being given up */}
                <div style={{ marginTop: 12, borderTop: "1px solid #eee", paddingTop: 10 }}>
                  <p style={{ fontSize: 10, fontWeight: 700, color: side, textTransform: "uppercase", letterSpacing: 0.8, marginBottom: 8 }}>
                    Cards Being Traded Away:
                  </p>
                  <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
                    {cards.length > 0 ? cards.map((c, i) => (
                      <CardThumbDoc key={i} card={c} />
                    )) : (
                      <p style={{ fontSize: 11, color: "#999", fontStyle: "italic" }}>No cards listed</p>
                    )}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* ── ESCROW SHIPPING INSTRUCTIONS ── */}
        <div style={{ background: "#e8f5e9", border: "1px solid #a5d6a7", borderRadius: 8, padding: "14px 18px", marginBottom: 24 }}>
          <p style={{ fontWeight: 700, color: "#2e7d32", fontSize: 13, marginBottom: 8 }}>
            📦 Shipping Instructions — Both Parties Must Follow
          </p>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16, fontSize: 12, color: "#333" }}>
            <div>
              <p style={{ fontWeight: 600, marginBottom: 4 }}>Step 1 — Prepare Your Package</p>
              <ul style={{ paddingLeft: 16, lineHeight: 1.8 }}>
                <li>Place your cards in a protective sleeve or top loader</li>
                <li>Put cards in an <strong>unsealed inner envelope</strong> labeled with your name</li>
                <li>Write Trade ID <strong>#{tradeId}</strong> on the outside of the package</li>
              </ul>
            </div>
            <div>
              <p style={{ fontWeight: 600, marginBottom: 4 }}>Step 2 — Ship to SCO</p>
              <div style={{ background: "#fff", border: "1px solid #c8e6c9", borderRadius: 6, padding: "8px 12px", lineHeight: 1.8 }}>
                <strong>{SCO_ADDRESS}</strong><br />
                Attn: Trade Escrow Dept.<br />
                Trade ID: #{tradeId}<br />
                <span style={{ fontSize: 11, color: "#666" }}>Use a trackable shipping method (USPS Priority, UPS, FedEx)</span>
              </div>
            </div>
          </div>
          <div style={{ marginTop: 10, fontSize: 12, color: "#555" }}>
            <p style={{ fontWeight: 600, marginBottom: 2 }}>Step 3 — Submit Your Tracking Number</p>
            <p>After shipping, log in to <strong>sportcardsonline.com/trades</strong> and enter your tracking number on this trade. SCO will verify both packages, confirm card condition, and forward each party's new cards.</p>
          </div>
        </div>

        {/* ── TERMS ── */}
        <div style={{ background: "#fafafa", border: "1px solid #e0e0e0", borderRadius: 8, padding: "12px 16px", marginBottom: 24, fontSize: 11, color: "#555", lineHeight: 1.7 }}>
          <p style={{ fontWeight: 700, color: "#333", marginBottom: 6, fontSize: 12 }}>Terms & Conditions</p>
          <p>1. Both parties agree to ship the cards listed above to the SCO Secured Location within <strong>7 business days</strong> of signing this agreement.</p>
          <p>2. A trade escrow fee of <strong>$10.00 per party</strong> is required before cards are forwarded. Payment link will be sent via email.</p>
          <p>3. SCO will inspect cards upon receipt to verify they match the description in this agreement. If a card does not match, SCO will contact both parties before proceeding.</p>
          <p>4. Once both parties' cards are received and verified, SCO will ship each party's new cards within <strong>3–5 business days</strong>.</p>
          <p>5. The SCO Guarantee covers authenticity and condition verification for all cards processed through this escrow service.</p>
          <p>6. Either party may cancel this trade before shipping by contacting SCO. Once cards are received, the trade is considered final.</p>
          <p style={{ marginTop: 6, fontStyle: "italic" }}>SportCardsOnline.com acts solely as an escrow facilitator and is not responsible for cards lost in transit. We strongly recommend insured, trackable shipping.</p>
        </div>

        {/* ── SIGNATURES ── */}
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 32, marginBottom: 24 }}>
          {[
            { label: "Party A Signature", party: initiator, signedAt: initiator.signedAt },
            { label: "Party B Signature", party: receiver, signedAt: receiver.signedAt },
          ].map(({ label, party, signedAt }) => (
            <div key={label}>
              <p style={{ fontSize: 11, color: "#777", marginBottom: 8, textTransform: "uppercase", letterSpacing: 0.8 }}>{label}</p>
              <CursiveSignature name={party.name || party.email} />
              <div style={{ marginTop: 8, fontSize: 11, color: "#555" }}>
                <p><strong>Name:</strong> {party.name || "—"}</p>
                <p><strong>Email:</strong> {party.email}</p>
                <p><strong>Date:</strong> {formatDate(signedAt)}</p>
                <p style={{ marginTop: 4, fontSize: 10, color: "#888" }}>
                  ✓ Digitally agreed via SportCardsOnline.com
                </p>
              </div>
            </div>
          ))}
        </div>

        {/* ── SCO WITNESS ── */}
        <div style={{ borderTop: "2px solid #C41E3A", paddingTop: 16, display: "flex", alignItems: "flex-start", justifyContent: "space-between" }}>
          <div>
            <p style={{ fontSize: 11, color: "#777", marginBottom: 6, textTransform: "uppercase", letterSpacing: 0.8 }}>Facilitated & Escrowed By</p>
            <CursiveSignature name="SportCardsOnline.com" />
            <p style={{ fontSize: 11, color: "#555", marginTop: 6 }}>
              <strong>SportCardsOnline.com</strong> — SCO Trade Escrow Service<br />
              Date: {docDate}
            </p>
          </div>
          <div style={{ textAlign: "right" }}>
            <img src={LOGO_URL} alt="SCO" style={{ height: 40, width: "auto", opacity: 0.7 }} />
            <p style={{ fontSize: 10, color: "#999", marginTop: 4 }}>sportcardsonline.com</p>
            <p style={{ fontSize: 10, color: "#999" }}>Trade ID: #{tradeId}</p>
          </div>
        </div>

        {/* ── FOOTER ── */}
        <div style={{ marginTop: 20, borderTop: "1px solid #eee", paddingTop: 12, textAlign: "center", fontSize: 10, color: "#aaa" }}>
          This document was generated by SportCardsOnline.com on {docDate}. Agreement #{ticket}.
          Questions? Email support@sportcardsonline.com or visit sportcardsonline.com/trades
        </div>
      </div>
    </div>
  );
}
