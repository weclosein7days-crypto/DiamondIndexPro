import { useState, useEffect } from "react";
import { trpc } from "@/lib/trpc";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { toast } from "sonner";
import {
  Trash2, Save, Star, Tag, TrendingUp, Clock, Package,
  CheckCircle, ToggleLeft, ToggleRight, ExternalLink
} from "lucide-react";

interface CardProfileDrawerProps {
  cardId: number | null;
  onClose: () => void;
  onDeleted?: () => void;
  onUpdated?: () => void;
}

const STATUS_COLORS: Record<string, string> = {
  active: "bg-green-500/20 text-green-400 border-green-500/30",
  sold: "bg-blue-500/20 text-blue-400 border-blue-500/30",
  draft: "bg-white/10 text-white/40 border-white/10",
  auction: "bg-orange-500/20 text-orange-400 border-orange-500/30",
  traded: "bg-purple-500/20 text-purple-400 border-purple-500/30",
  casino: "bg-yellow-500/20 text-yellow-400 border-yellow-500/30",
  bank: "bg-indigo-500/20 text-indigo-400 border-indigo-500/30",
};

export function CardProfileDrawer({ cardId, onClose, onDeleted, onUpdated }: CardProfileDrawerProps) {
  const [form, setForm] = useState<Record<string, string | boolean>>({});
  const [dirty, setDirty] = useState(false);

  const { data: profile, isLoading, isError, error, refetch } = trpc.admin.adminGetCardProfile.useQuery(
    { cardId: cardId! },
    { enabled: cardId !== null, retry: 1 }
  );

  const updateCard = trpc.admin.adminUpdateCardFull.useMutation({
    onSuccess: () => {
      toast.success("Card updated");
      setDirty(false);
      refetch();
      onUpdated?.();
    },
    onError: (e) => toast.error(e.message),
  });

  const deleteCard = trpc.admin.deleteCardAdmin.useMutation({
    onSuccess: () => {
      toast.success("Card deleted");
      onDeleted?.();
      onClose();
    },
    onError: (e) => toast.error(e.message),
  });

  // Populate form when card loads
  useEffect(() => {
    if (profile?.card) {
      const c = profile.card;
      setForm({
        title: c.title ?? "",
        playerName: c.playerName ?? "",
        year: c.year ?? "",
        manufacturer: c.manufacturer ?? "",
        cardNumber: c.cardNumber ?? "",
        setName: c.setName ?? "",
        sport: c.sport ?? "baseball",
        price: c.price ?? "",
        shippingFee: c.cardShippingFee ?? "",
        aiGrade: c.aiGrade ?? "",
        status: c.status ?? "draft",
        description: c.description ?? "",
        isUpAndComing: c.isUpAndComing ?? false,
        isShowcaseCard: c.isShowcaseCard ?? false,
        featuredOnMain: c.featuredOnMain ?? false,
      });
      setDirty(false);
    }
  }, [profile?.card?.id]);

  const set = (key: string, val: string | boolean) => {
    setForm(prev => ({ ...prev, [key]: val }));
    setDirty(true);
  };

  const handleSave = () => {
    if (!cardId) return;
    const payload: Record<string, unknown> = { cardId };
    if (form.title) payload.title = form.title as string;
    if (form.playerName) payload.playerName = form.playerName as string;
    if (form.year !== undefined) payload.year = form.year as string;
    if (form.manufacturer !== undefined) payload.manufacturer = form.manufacturer as string;
    if (form.cardNumber !== undefined) payload.cardNumber = form.cardNumber as string;
    if (form.setName !== undefined) payload.setName = form.setName as string;
    if (form.sport) payload.sport = form.sport as any;
    if (form.price !== undefined) payload.price = form.price as string;
    if (form.shippingFee !== undefined && form.shippingFee !== "") payload.cardShippingFee = form.shippingFee as string;
    if (form.aiGrade !== undefined && form.aiGrade !== "") payload.aiGrade = form.aiGrade as string;
    if (form.status) payload.status = form.status as any;
    if (form.description !== undefined) payload.description = form.description as string;
    payload.isUpAndComing = form.isUpAndComing as boolean;
    payload.isShowcaseCard = form.isShowcaseCard as boolean;
    payload.featuredOnMain = form.featuredOnMain as boolean;
    updateCard.mutate(payload as any);
  };

  const card = profile?.card;
  const history = profile?.history ?? [];
  const orderHistory = profile?.orderHistory ?? [];

  return (
    <Sheet open={cardId !== null} onOpenChange={open => { if (!open) onClose(); }}>
      <SheetContent side="right" className="w-full sm:max-w-2xl bg-[#0a1628] border-white/10 text-white overflow-y-auto p-0">
        {isLoading && (
          <div className="flex items-center justify-center h-full">
            <div className="w-6 h-6 border-2 border-[#C41E3A] border-t-transparent rounded-full animate-spin" />
          </div>
        )}
        {isError && (
          <div className="flex flex-col items-center justify-center h-full gap-3 p-6 text-center">
            <div className="text-4xl">⚠️</div>
            <div className="text-red-400 text-sm font-semibold">Failed to load card</div>
            <div className="text-white/40 text-xs max-w-xs">{(error as any)?.message ?? "Server error — the card may have missing columns. Check migrations."}</div>
            <button onClick={() => refetch()} className="mt-2 text-xs bg-[#C41E3A] hover:bg-[#a01830] text-white px-4 py-1.5 rounded-lg">Retry</button>
          </div>
        )}
        {!isLoading && !isError && !card && (
          <div className="flex items-center justify-center h-full">
            <div className="text-white/40 text-sm">Card not found</div>
          </div>
        )}
        {card && (
          <div className="flex flex-col h-full">
            {/* Header */}
            <SheetHeader className="p-5 border-b border-white/10 bg-[#0d1f3c]">
              <div className="flex items-start gap-4">
                {card.frontImageUrl && (
                  <img src={card.frontImageUrl} alt="" className="w-16 h-20 object-cover rounded-lg border border-white/10 flex-shrink-0" />
                )}
                <div className="flex-1 min-w-0">
                  <SheetTitle className="text-white text-base font-bold line-clamp-2 leading-tight">{card.title}</SheetTitle>
                  <div className="flex items-center gap-2 mt-1 flex-wrap">
                    <Badge className={`text-xs capitalize ${STATUS_COLORS[card.status] ?? "bg-white/10 text-white/40"}`}>{card.status}</Badge>
                    {card.aiGrade && <Badge className="text-xs bg-yellow-500/20 text-yellow-400 border-yellow-500/30">SCG {parseFloat(card.aiGrade).toFixed(1)}</Badge>}
                    {card.isDropship && <Badge className="text-xs bg-blue-500/20 text-blue-400 border-blue-500/30">eBay Dropship</Badge>}
                    {card.isUpAndComing && <Badge className="text-xs bg-purple-500/20 text-purple-400 border-purple-500/30">Up & Coming</Badge>}
                    {card.isShowcaseCard && <Badge className="text-xs bg-amber-500/20 text-amber-400 border-amber-500/30">Showcase</Badge>}
                  </div>
                  <div className="text-xs text-white/40 mt-1">ID #{card.id} · {card.sellerEmail}</div>
                </div>
                <div className="text-right flex-shrink-0">
                  <div className="text-xl font-bold text-green-400">${parseFloat(card.price ?? "0").toFixed(2)}</div>
                  {card.sourcePrice && <div className="text-xs text-white/40">eBay: ${parseFloat(card.sourcePrice).toFixed(2)}</div>}
                </div>
              </div>
            </SheetHeader>

            {/* Body */}
            <div className="flex-1 overflow-y-auto p-5 space-y-6">

              {/* Edit Fields */}
              <section>
                <h3 className="text-xs font-semibold text-white/40 uppercase tracking-wider mb-3">Card Details</h3>
                <div className="grid grid-cols-2 gap-3">
                  <div className="col-span-2">
                    <label className="text-xs text-white/50 mb-1 block">Title</label>
                    <Input value={form.title as string} onChange={e => set("title", e.target.value)} className="bg-white/5 border-white/10 text-white text-sm h-8" />
                  </div>
                  <div>
                    <label className="text-xs text-white/50 mb-1 block">Player Name</label>
                    <Input value={form.playerName as string} onChange={e => set("playerName", e.target.value)} className="bg-white/5 border-white/10 text-white text-sm h-8" />
                  </div>
                  <div>
                    <label className="text-xs text-white/50 mb-1 block">Year</label>
                    <Input value={form.year as string} onChange={e => set("year", e.target.value)} className="bg-white/5 border-white/10 text-white text-sm h-8" />
                  </div>
                  <div>
                    <label className="text-xs text-white/50 mb-1 block">Set Name</label>
                    <Input value={form.setName as string} onChange={e => set("setName", e.target.value)} className="bg-white/5 border-white/10 text-white text-sm h-8" />
                  </div>
                  <div>
                    <label className="text-xs text-white/50 mb-1 block">Card #</label>
                    <Input value={form.cardNumber as string} onChange={e => set("cardNumber", e.target.value)} className="bg-white/5 border-white/10 text-white text-sm h-8" />
                  </div>
                  <div>
                    <label className="text-xs text-white/50 mb-1 block">Manufacturer</label>
                    <Input value={form.manufacturer as string} onChange={e => set("manufacturer", e.target.value)} className="bg-white/5 border-white/10 text-white text-sm h-8" />
                  </div>
                  <div>
                    <label className="text-xs text-white/50 mb-1 block">Sport</label>
                    <Select value={form.sport as string} onValueChange={v => set("sport", v)}>
                      <SelectTrigger className="h-8 text-sm bg-white/5 border-white/10 text-white"><SelectValue /></SelectTrigger>
                      <SelectContent className="bg-[#0d1f3c] border-white/10">
                        {["baseball","basketball","football","hockey","soccer","other"].map(s => (
                          <SelectItem key={s} value={s} className="text-white capitalize hover:bg-white/10">{s}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </section>

              <Separator className="bg-white/10" />

              {/* Price & Grade */}
              <section>
                <h3 className="text-xs font-semibold text-white/40 uppercase tracking-wider mb-3">Pricing & Grade</h3>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs text-white/50 mb-1 block">Price ($)</label>
                    <Input type="number" value={form.price as string} onChange={e => set("price", e.target.value)} className="bg-white/5 border-white/10 text-white text-sm h-8" />
                  </div>
                  <div>
                    <label className="text-xs text-white/50 mb-1 block">SCG Grade</label>
                    <Input placeholder="e.g. 9.5" value={form.aiGrade as string} onChange={e => set("aiGrade", e.target.value)} className="bg-white/5 border-white/10 text-white text-sm h-8" />
                  </div>
                  <div>
                    <label className="text-xs text-white/50 mb-1 block">Shipping Override ($)</label>
                    <Input type="number" step="0.01" placeholder={`Auto: $${parseFloat(form.price as string || "0") < 100 ? "4.50" : parseFloat(form.price as string || "0") < 500 ? "7.00" : "14.95"}`} value={form.shippingFee as string} onChange={e => set("shippingFee", e.target.value)} className="bg-white/5 border-white/10 text-white text-sm h-8" />
                  </div>
                  <div className="col-span-2">
                    <p className="text-xs text-white/30">Auto-rates: under $100 = $4.50 · $100–$500 = $7.00 · $500+ = $14.95. Leave blank to use auto.</p>
                  </div>
                </div>
              </section>

              <Separator className="bg-white/10" />

              {/* Status & Flags */}
              <section>
                <h3 className="text-xs font-semibold text-white/40 uppercase tracking-wider mb-3">Status & Flags</h3>
                <div className="grid grid-cols-2 gap-3 mb-3">
                  <div className="col-span-2">
                    <label className="text-xs text-white/50 mb-1 block">Status</label>
                    <Select value={form.status as string} onValueChange={v => set("status", v)}>
                      <SelectTrigger className="h-8 text-sm bg-white/5 border-white/10 text-white"><SelectValue /></SelectTrigger>
                      <SelectContent className="bg-[#0d1f3c] border-white/10">
                        {["active","draft","sold","auction","traded","casino","bank"].map(s => (
                          <SelectItem key={s} value={s} className="text-white capitalize hover:bg-white/10">{s}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="flex flex-wrap gap-3">
                  {[
                    { key: "featuredOnMain", label: "Featured on Main" },
                    { key: "isUpAndComing", label: "Up & Coming" },
                    { key: "isShowcaseCard", label: "Showcase" },
                  ].map(({ key, label }) => (
                    <button
                      key={key}
                      onClick={() => set(key, !(form[key] as boolean))}
                      className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium border transition-colors ${
                        form[key] ? "bg-[#C41E3A]/20 text-[#C41E3A] border-[#C41E3A]/40" : "bg-white/5 text-white/40 border-white/10 hover:bg-white/10"
                      }`}
                    >
                      {form[key] ? <ToggleRight className="w-3.5 h-3.5" /> : <ToggleLeft className="w-3.5 h-3.5" />}
                      {label}
                    </button>
                  ))}
                </div>
              </section>

              <Separator className="bg-white/10" />

              {/* Description */}
              <section>
                <h3 className="text-xs font-semibold text-white/40 uppercase tracking-wider mb-3">Description</h3>
                <Textarea
                  value={form.description as string}
                  onChange={e => set("description", e.target.value)}
                  rows={3}
                  className="bg-white/5 border-white/10 text-white text-sm resize-none"
                  placeholder="Card description..."
                />
              </section>

              {/* eBay link if dropship */}
              {card.ebayListingUrl && (
                <>
                  <Separator className="bg-white/10" />
                  <section>
                    <h3 className="text-xs font-semibold text-white/40 uppercase tracking-wider mb-2">eBay Listing</h3>
                    <a href={card.ebayListingUrl} target="_blank" rel="noopener noreferrer"
                      className="flex items-center gap-2 text-xs text-blue-400 hover:text-blue-300 underline">
                      <ExternalLink className="w-3 h-3" /> View on eBay
                    </a>
                  </section>
                </>
              )}

              {/* Order History */}
              {orderHistory.length > 0 && (
                <>
                  <Separator className="bg-white/10" />
                  <section>
                    <h3 className="text-xs font-semibold text-white/40 uppercase tracking-wider mb-3 flex items-center gap-1.5">
                      <Package className="w-3.5 h-3.5" /> Order History ({orderHistory.length})
                    </h3>
                    <div className="space-y-2">
                      {orderHistory.map(o => (
                        <div key={o.id} className="bg-white/5 rounded-lg p-3 text-xs">
                          <div className="flex items-center justify-between mb-1">
                            <span className="font-mono text-white/40">#{o.ticketNumber ?? o.id}</span>
                            <Badge className={`text-xs capitalize ${STATUS_COLORS[o.status] ?? "bg-white/10 text-white/40"}`}>{o.status}</Badge>
                          </div>
                          <div className="text-white/60">Buyer: {o.buyerEmail}</div>
                          <div className="flex items-center justify-between mt-1">
                            <span className="text-green-400 font-semibold">${parseFloat(o.totalAmount ?? "0").toFixed(2)}</span>
                            {o.trackingNumber && <span className="font-mono text-white/40">{o.trackingNumber}</span>}
                          </div>
                          {o.deliveredAt && (
                            <div className="flex items-center gap-1 text-green-400 mt-1">
                              <CheckCircle className="w-3 h-3" /> Delivered {new Date(o.deliveredAt).toLocaleDateString()}
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  </section>
                </>
              )}

              {/* Event History */}
              {history.length > 0 && (
                <>
                  <Separator className="bg-white/10" />
                  <section>
                    <h3 className="text-xs font-semibold text-white/40 uppercase tracking-wider mb-3 flex items-center gap-1.5">
                      <Clock className="w-3.5 h-3.5" /> Activity Log ({history.length})
                    </h3>
                    <div className="space-y-1.5 max-h-48 overflow-y-auto">
                      {history.slice(0, 20).map((h: any) => (
                        <div key={h.id} className="flex items-start gap-2 text-xs">
                          <span className="text-white/30 flex-shrink-0 w-20">{new Date(h.createdAt).toLocaleDateString()}</span>
                          <span className="text-white/60 capitalize">{(h.eventType ?? "").replace(/_/g, " ")}</span>
                          {h.description && <span className="text-white/40 truncate">{h.description}</span>}
                        </div>
                      ))}
                    </div>
                  </section>
                </>
              )}
            </div>

            {/* Footer Actions */}
            <div className="p-4 border-t border-white/10 bg-[#0d1f3c] flex items-center justify-between gap-3">
              <Button
                variant="ghost"
                size="sm"
                className="text-red-400 hover:bg-red-500/10 hover:text-red-300"
                onClick={() => {
                  if (!confirm(`Delete "${card.title}"? This cannot be undone.`)) return;
                  deleteCard.mutate({ cardId: card.id });
                }}
                disabled={deleteCard.isPending}
              >
                <Trash2 className="w-4 h-4 mr-1.5" /> Delete Card
              </Button>
              <div className="flex gap-2">
                <Button variant="ghost" size="sm" className="text-white/40 hover:bg-white/10" onClick={onClose}>
                  Cancel
                </Button>
                <Button
                  size="sm"
                  className="bg-[#C41E3A] hover:bg-[#a01830] text-white"
                  onClick={handleSave}
                  disabled={!dirty || updateCard.isPending}
                >
                  <Save className="w-4 h-4 mr-1.5" />
                  {updateCard.isPending ? "Saving..." : "Save Changes"}
                </Button>
              </div>
            </div>
          </div>
        )}
      </SheetContent>
    </Sheet>
  );
}
