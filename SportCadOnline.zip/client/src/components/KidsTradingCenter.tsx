/**
 * KidsTradingCenter — Kids can browse each other's collections and trade cards.
 * Appie and Giffy each have their own collection seeded from the server.
 */
import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

interface KidsTradingCenterProps {
  kidId: number;
  kidName: string;
}

const RARITY_COLORS: Record<string, string> = {
  common: "bg-gray-200 text-gray-700",
  uncommon: "bg-green-200 text-green-800",
  rare: "bg-blue-200 text-blue-800",
  epic: "bg-purple-200 text-purple-800",
  legendary: "bg-yellow-200 text-yellow-800",
};

const SPORT_EMOJI: Record<string, string> = {
  basketball: "🏀", baseball: "⚾", football: "🏈",
  hockey: "🏒", soccer: "⚽", default: "🃏",
};

function CardTile({ card, selected, onClick, showSelect }: {
  card: any; selected?: boolean; onClick?: () => void; showSelect?: boolean;
}) {
  const emoji = SPORT_EMOJI[card.sport] || SPORT_EMOJI.default;
  return (
    <div
      onClick={onClick}
      className={`relative rounded-xl border-2 p-3 cursor-pointer transition-all select-none
        ${selected ? "border-yellow-400 bg-yellow-50 shadow-lg scale-105" : "border-gray-200 bg-white hover:border-blue-300 hover:shadow-md"}
        ${showSelect ? "cursor-pointer" : ""}`}
      style={{ minWidth: 120 }}
    >
      {selected && (
        <div className="absolute -top-2 -right-2 bg-yellow-400 text-black text-xs font-black rounded-full w-6 h-6 flex items-center justify-center shadow">✓</div>
      )}
      <div className="text-3xl text-center mb-1">{emoji}</div>
      <p className="text-xs font-bold text-gray-900 text-center leading-tight line-clamp-2">{card.playerName}</p>
      <p className="text-[10px] text-gray-500 text-center">{card.year} {card.setName}</p>
      <div className="mt-1 flex justify-center">
        <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded-full uppercase ${RARITY_COLORS[card.rarity] || RARITY_COLORS.common}`}>
          {card.rarity}
        </span>
      </div>
      <p className="text-[10px] text-green-700 font-bold text-center mt-0.5">~${card.estimatedValue}</p>
    </div>
  );
}

export default function KidsTradingCenter({ kidId, kidName }: KidsTradingCenterProps) {
  const [tab, setTab] = useState<"myCollection" | "tradeCenter" | "trades">("myCollection");
  const [selectedOtherKid, setSelectedOtherKid] = useState<any>(null);
  const [mySelectedCard, setMySelectedCard] = useState<any>(null);
  const [theirSelectedCard, setTheirSelectedCard] = useState<any>(null);
  const [tradeMessage, setTradeMessage] = useState("");

  const { data: myCards, refetch: refetchMyCards } = trpc.kidsCollection.getMyCollection.useQuery({ kidId });
  const { data: otherKids } = trpc.kidsCollection.getOtherKids.useQuery({ myKidId: kidId });
  const { data: myTrades, refetch: refetchTrades } = trpc.kidsCollection.getMyTrades.useQuery({ kidId });

  const sendTrade = trpc.kidsCollection.sendTradeOffer.useMutation({
    onSuccess: () => {
      toast.success("🤝 Trade offer sent!");
      setMySelectedCard(null);
      setTheirSelectedCard(null);
      setTradeMessage("");
      refetchTrades();
    },
    onError: (e) => toast.error(e.message),
  });

  const acceptTrade = trpc.kidsCollection.acceptTrade.useMutation({
    onSuccess: () => {
      toast.success("🎉 Trade accepted! Cards swapped!");
      refetchMyCards();
      refetchTrades();
    },
    onError: (e) => toast.error(e.message),
  });

  const declineTrade = trpc.kidsCollection.declineTrade.useMutation({
    onSuccess: () => {
      toast("Trade declined.");
      refetchTrades();
    },
    onError: (e) => toast.error(e.message),
  });

  const pendingIncoming = myTrades?.filter(t => t.isIncoming && t.status === "pending") || [];
  const pendingOutgoing = myTrades?.filter(t => !t.isIncoming && t.status === "pending") || [];
  const completedTrades = myTrades?.filter(t => t.status === "accepted" || t.status === "declined") || [];

  return (
    <div className="bg-gradient-to-b from-indigo-950 to-blue-950 rounded-2xl p-4 text-white">
      {/* Header */}
      <div className="flex items-center gap-3 mb-4">
        <div className="text-3xl">🃏</div>
        <div>
          <h2 className="text-xl font-black text-yellow-400" style={{ fontFamily: "Oswald, sans-serif" }}>
            {kidName}'s Card Collection
          </h2>
          <p className="text-xs text-blue-300">{myCards?.length || 0} cards in your collection</p>
        </div>
        {pendingIncoming.length > 0 && (
          <div className="ml-auto bg-red-500 text-white text-xs font-black px-2 py-1 rounded-full animate-pulse">
            {pendingIncoming.length} Trade{pendingIncoming.length > 1 ? "s" : ""} Waiting!
          </div>
        )}
      </div>

      {/* Tabs */}
      <div className="flex gap-2 mb-4">
        {[
          { key: "myCollection", label: "My Cards", emoji: "📦" },
          { key: "tradeCenter", label: "Trade Center", emoji: "🤝" },
          { key: "trades", label: `Trades${pendingIncoming.length > 0 ? ` (${pendingIncoming.length})` : ""}`, emoji: "📬" },
        ].map(t => (
          <button
            key={t.key}
            onClick={() => setTab(t.key as any)}
            className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all ${tab === t.key ? "bg-yellow-400 text-black" : "bg-white/10 text-white hover:bg-white/20"}`}
          >
            {t.emoji} {t.label}
          </button>
        ))}
      </div>

      {/* ── My Collection ─────────────────────────────────────────────── */}
      {tab === "myCollection" && (
        <div>
          {!myCards || myCards.length === 0 ? (
            <div className="text-center py-8 text-blue-300">
              <div className="text-5xl mb-2">📭</div>
              <p className="font-bold">No cards yet!</p>
              <p className="text-xs">Do a card pull to get your first card.</p>
            </div>
          ) : (
            <div className="grid grid-cols-3 gap-2 max-h-80 overflow-y-auto pr-1">
              {myCards.map(card => (
                <CardTile key={card.id} card={card} />
              ))}
            </div>
          )}
        </div>
      )}

      {/* ── Trade Center ──────────────────────────────────────────────── */}
      {tab === "tradeCenter" && (
        <div>
          {/* Pick who to trade with */}
          {!selectedOtherKid ? (
            <div>
              <p className="text-sm text-blue-200 mb-3">Who do you want to trade with?</p>
              {!otherKids || otherKids.length === 0 ? (
                <div className="text-center py-8 text-blue-300">
                  <div className="text-4xl mb-2">👥</div>
                  <p className="font-bold">No other kids found yet.</p>
                  <p className="text-xs">Ask a friend to join Kids Corner!</p>
                </div>
              ) : (
                <div className="flex flex-col gap-2">
                  {otherKids.map(kid => (
                    <button
                      key={kid.id}
                      onClick={() => setSelectedOtherKid(kid)}
                      className="flex items-center gap-3 bg-white/10 hover:bg-white/20 rounded-xl p-3 transition-all text-left"
                    >
                      <span className="text-3xl">{kid.avatarEmoji}</span>
                      <div>
                        <p className="font-bold text-white">{kid.displayName}</p>
                        <p className="text-xs text-blue-300">Level {kid.level} • {kid.cardCount} cards</p>
                      </div>
                      <span className="ml-auto text-yellow-400 text-lg">→</span>
                    </button>
                  ))}
                </div>
              )}
            </div>
          ) : (
            <div>
              {/* Trade builder */}
              <div className="flex items-center gap-2 mb-3">
                <button onClick={() => { setSelectedOtherKid(null); setMySelectedCard(null); setTheirSelectedCard(null); }}
                  className="text-blue-300 hover:text-white text-sm">← Back</button>
                <span className="text-white font-bold">Trading with {selectedOtherKid.displayName} {selectedOtherKid.avatarEmoji}</span>
              </div>

              <div className="grid grid-cols-2 gap-3 mb-3">
                {/* My card to offer */}
                <div>
                  <p className="text-xs text-yellow-400 font-bold mb-1">📤 Your offer:</p>
                  {mySelectedCard ? (
                    <div onClick={() => setMySelectedCard(null)}>
                      <CardTile card={mySelectedCard} selected />
                      <p className="text-[10px] text-blue-300 text-center mt-1">Tap to change</p>
                    </div>
                  ) : (
                    <div className="border-2 border-dashed border-white/30 rounded-xl p-3 text-center text-blue-300 text-xs">
                      Pick a card from your collection below
                    </div>
                  )}
                </div>
                {/* Their card to request */}
                <div>
                  <p className="text-xs text-yellow-400 font-bold mb-1">📥 You want:</p>
                  {theirSelectedCard ? (
                    <div onClick={() => setTheirSelectedCard(null)}>
                      <CardTile card={theirSelectedCard} selected />
                      <p className="text-[10px] text-blue-300 text-center mt-1">Tap to change</p>
                    </div>
                  ) : (
                    <div className="border-2 border-dashed border-white/30 rounded-xl p-3 text-center text-blue-300 text-xs">
                      Pick a card from their collection below
                    </div>
                  )}
                </div>
              </div>

              {/* Message */}
              <input
                value={tradeMessage}
                onChange={e => setTradeMessage(e.target.value)}
                placeholder="Add a message (optional)..."
                className="w-full bg-white/10 border border-white/20 rounded-xl px-3 py-2 text-sm text-white placeholder-blue-300 mb-3 outline-none focus:border-yellow-400"
                maxLength={255}
              />

              {/* Send trade button */}
              <button
                disabled={!mySelectedCard || !theirSelectedCard || sendTrade.isPending}
                onClick={() => sendTrade.mutate({
                  offererId: kidId,
                  receiverId: selectedOtherKid.id,
                  offeredCardId: mySelectedCard.id,
                  requestedCardId: theirSelectedCard.id,
                  message: tradeMessage || undefined,
                })}
                className="w-full py-3 bg-gradient-to-r from-yellow-400 to-orange-500 text-black font-black rounded-xl disabled:opacity-40 disabled:cursor-not-allowed hover:from-yellow-300 hover:to-orange-400 transition-all mb-4"
              >
                {sendTrade.isPending ? "Sending..." : "🤝 Send Trade Offer!"}
              </button>

              {/* Card pickers */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <p className="text-xs text-blue-300 font-bold mb-2">Your cards:</p>
                  <div className="grid grid-cols-2 gap-1 max-h-48 overflow-y-auto">
                    {(myCards || []).map(card => (
                      <CardTile key={card.id} card={card}
                        selected={mySelectedCard?.id === card.id}
                        onClick={() => setMySelectedCard(card)}
                        showSelect />
                    ))}
                  </div>
                </div>
                <div>
                  <p className="text-xs text-blue-300 font-bold mb-2">{selectedOtherKid.displayName}'s cards:</p>
                  <div className="grid grid-cols-2 gap-1 max-h-48 overflow-y-auto">
                    {(selectedOtherKid.cards || []).map((card: any) => (
                      <CardTile key={card.id} card={card}
                        selected={theirSelectedCard?.id === card.id}
                        onClick={() => setTheirSelectedCard(card)}
                        showSelect />
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ── Trades Inbox ──────────────────────────────────────────────── */}
      {tab === "trades" && (
        <div className="space-y-3 max-h-96 overflow-y-auto pr-1">
          {pendingIncoming.length === 0 && pendingOutgoing.length === 0 && completedTrades.length === 0 && (
            <div className="text-center py-8 text-blue-300">
              <div className="text-4xl mb-2">📭</div>
              <p className="font-bold">No trades yet!</p>
              <p className="text-xs">Go to Trade Center to send your first offer.</p>
            </div>
          )}

          {pendingIncoming.length > 0 && (
            <div>
              <p className="text-xs text-yellow-400 font-bold mb-2">📬 Incoming Offers:</p>
              {pendingIncoming.map(trade => (
                <div key={trade.id} className="bg-white/10 rounded-xl p-3 mb-2">
                  <p className="text-sm font-bold text-white mb-1">
                    {trade.offerer?.displayName} wants to trade!
                  </p>
                  <div className="flex items-center gap-2 text-xs text-blue-200 mb-2">
                    <span>They offer: <strong className="text-white">{trade.offeredCard?.playerName}</strong></span>
                    <span>⇄</span>
                    <span>They want: <strong className="text-white">{trade.requestedCard?.playerName}</strong></span>
                  </div>
                  {trade.message && <p className="text-xs text-blue-300 italic mb-2">"{trade.message}"</p>}
                  <div className="flex gap-2">
                    <button
                      onClick={() => acceptTrade.mutate({ tradeId: trade.id, kidId })}
                      className="flex-1 py-1.5 bg-green-500 hover:bg-green-400 text-white font-bold text-xs rounded-lg transition-all"
                    >✅ Accept</button>
                    <button
                      onClick={() => declineTrade.mutate({ tradeId: trade.id, kidId })}
                      className="flex-1 py-1.5 bg-red-500 hover:bg-red-400 text-white font-bold text-xs rounded-lg transition-all"
                    >❌ Decline</button>
                  </div>
                </div>
              ))}
            </div>
          )}

          {pendingOutgoing.length > 0 && (
            <div>
              <p className="text-xs text-blue-300 font-bold mb-2">📤 Your Pending Offers:</p>
              {pendingOutgoing.map(trade => (
                <div key={trade.id} className="bg-white/5 rounded-xl p-3 mb-2 border border-white/10">
                  <p className="text-xs text-blue-200">
                    Offered <strong className="text-white">{trade.offeredCard?.playerName}</strong> to {trade.receiver?.displayName} for <strong className="text-white">{trade.requestedCard?.playerName}</strong>
                  </p>
                  <p className="text-[10px] text-yellow-400 mt-1">⏳ Waiting for response...</p>
                  <button
                    onClick={() => declineTrade.mutate({ tradeId: trade.id, kidId })}
                    className="mt-2 text-[10px] text-red-400 hover:text-red-300"
                  >Cancel offer</button>
                </div>
              ))}
            </div>
          )}

          {completedTrades.length > 0 && (
            <div>
              <p className="text-xs text-gray-400 font-bold mb-2">📋 Trade History:</p>
              {completedTrades.slice(0, 10).map(trade => (
                <div key={trade.id} className="bg-white/5 rounded-xl p-2 mb-1 border border-white/5">
                  <div className="flex items-center gap-2 text-xs">
                    <span className={trade.status === "accepted" ? "text-green-400" : "text-red-400"}>
                      {trade.status === "accepted" ? "✅" : "❌"}
                    </span>
                    <span className="text-gray-300">
                      {trade.isIncoming ? `${trade.offerer?.displayName} offered ` : "You offered "}
                      <strong className="text-white">{trade.offeredCard?.playerName}</strong>
                      {" for "}
                      <strong className="text-white">{trade.requestedCard?.playerName}</strong>
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
