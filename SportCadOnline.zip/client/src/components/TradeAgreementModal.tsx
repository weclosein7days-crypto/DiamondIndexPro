import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { CheckCircle, Package, Shield, Truck, Star, AlertCircle, FileText, MapPin } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import TradeAgreementDocument from "./TradeAgreementDocument";

const LOGO_URL = "https://d2xsxph8kpxj0f.cloudfront.net/310/pasted_file_NDxW0y_image.png";

interface TradeCard {
  title: string;
  imageUrl?: string;
  grade?: string;
}

interface TradeAgreementModalProps {
  open: boolean;
  onClose: () => void;
  trade: {
    id: number;
    initiatorEmail: string;
    initiatorName?: string;
    receiverEmail: string;
    receiverName?: string;
    offeredCardTitles?: string[];
    offeredCardImages?: string[];
    offeredCardGrades?: string[];
    requestedCardTitles?: string[];
    requestedCardImages?: string[];
    requestedCardGrades?: string[];
    status: string;
    initiatorAgreed?: boolean;
    receiverAgreed?: boolean;
    initiatorTracking?: string;
    receiverTracking?: string;
    initiatorSignedAt?: string | null;
    receiverSignedAt?: string | null;
    initiatorAddress?: string;
    initiatorCity?: string;
    initiatorState?: string;
    initiatorZip?: string;
    initiatorPhone?: string;
    receiverAddress?: string;
    receiverCity?: string;
    receiverState?: string;
    receiverZip?: string;
    receiverPhone?: string;
    ticketNumber?: string;
    agreementSentAt?: string | null;
    message?: string;
  };
  currentUserEmail: string;
  onTradeUpdated?: () => void;
}

const ESCROW_STEPS = [
  { icon: CheckCircle, label: "Both parties agree to the trade terms", color: "text-green-400" },
  { icon: Package, label: "Each party ships their cards to SCO HQ", color: "text-blue-400" },
  { icon: Shield, label: "SCO verifies card condition matches description", color: "text-yellow-400" },
  { icon: Truck, label: "SCO ships each party's new cards to them", color: "text-orange-400" },
  { icon: Star, label: "Trade complete — both parties rate the experience", color: "text-purple-400" },
];

function CardThumb({ title, imageUrl }: { title: string; imageUrl?: string }) {
  return (
    <div className="flex flex-col items-center gap-1 w-24">
      <div className="w-16 rounded border border-white/20 overflow-hidden bg-[#0d1f3c] flex items-center justify-center" style={{ height: 88 }}>
        {imageUrl ? (
          <img src={imageUrl} alt={title} className="w-full h-full object-cover" />
        ) : (
          <div className="text-white/30 text-xs text-center px-1">No Image</div>
        )}
      </div>
      <p className="text-white/70 text-xs text-center leading-tight line-clamp-2">{title}</p>
    </div>
  );
}

interface AddressFormValues {
  address: string;
  city: string;
  state: string;
  zip: string;
  phone: string;
}

function AddressForm({ values, onChange }: { values: AddressFormValues; onChange: (v: AddressFormValues) => void }) {
  const set = (k: keyof AddressFormValues) => (e: React.ChangeEvent<HTMLInputElement>) =>
    onChange({ ...values, [k]: e.target.value });
  return (
    <div className="space-y-3">
      <div>
        <Label className="text-white/70 text-xs">Street Address *</Label>
        <Input value={values.address} onChange={set("address")} placeholder="123 Main St" className="mt-1 bg-[#0d1f3c] border-white/20 text-white placeholder:text-white/30 text-sm" />
      </div>
      <div className="grid grid-cols-3 gap-2">
        <div className="col-span-1">
          <Label className="text-white/70 text-xs">City *</Label>
          <Input value={values.city} onChange={set("city")} placeholder="Columbus" className="mt-1 bg-[#0d1f3c] border-white/20 text-white placeholder:text-white/30 text-sm" />
        </div>
        <div>
          <Label className="text-white/70 text-xs">State *</Label>
          <Input value={values.state} onChange={set("state")} placeholder="OH" maxLength={2} className="mt-1 bg-[#0d1f3c] border-white/20 text-white placeholder:text-white/30 text-sm" />
        </div>
        <div>
          <Label className="text-white/70 text-xs">ZIP *</Label>
          <Input value={values.zip} onChange={set("zip")} placeholder="43215" className="mt-1 bg-[#0d1f3c] border-white/20 text-white placeholder:text-white/30 text-sm" />
        </div>
      </div>
      <div>
        <Label className="text-white/70 text-xs">Phone (optional)</Label>
        <Input value={values.phone} onChange={set("phone")} placeholder="(555) 555-5555" className="mt-1 bg-[#0d1f3c] border-white/20 text-white placeholder:text-white/30 text-sm" />
      </div>
    </div>
  );
}

export default function TradeAgreementModal({
  open, onClose, trade, currentUserEmail, onTradeUpdated
}: TradeAgreementModalProps) {
  const [trackingNumber, setTrackingNumber] = useState("");
  const [showTracking, setShowTracking] = useState(false);
  const [showAddressForm, setShowAddressForm] = useState(false);
  const [addressValues, setAddressValues] = useState<AddressFormValues>({ address: "", city: "", state: "", zip: "", phone: "" });

  const isInitiator = trade.initiatorEmail === currentUserEmail;
  const isReceiver = trade.receiverEmail === currentUserEmail;
  const myAgreed = isInitiator ? !!trade.initiatorAgreed : !!trade.receiverAgreed;
  const bothAgreed = !!trade.initiatorAgreed && !!trade.receiverAgreed;
  const myTracking = isInitiator ? trade.initiatorTracking : trade.receiverTracking;
  const otherTracking = isInitiator ? trade.receiverTracking : trade.initiatorTracking;
  const otherName = isInitiator ? (trade.receiverName || trade.receiverEmail) : (trade.initiatorName || trade.initiatorEmail);

  const agreeToTrade = trpc.trades.agreeToTrade.useMutation({
    onSuccess: (data) => {
      toast.success(data.bothAgreed
        ? "🎉 Both parties agreed! Check your messages for next steps and your printable agreement."
        : "✅ You agreed! Waiting for the other party...");
      setShowAddressForm(false);
      onTradeUpdated?.();
    },
    onError: () => toast.error("Failed to agree to trade. Please try again."),
  });

  const addTracking = trpc.trades.addTracking.useMutation({
    onSuccess: () => {
      toast.success("Tracking number added! SCO will verify your package.");
      setTrackingNumber("");
      setShowTracking(false);
      onTradeUpdated?.();
    },
    onError: () => toast.error("Failed to add tracking number."),
  });

  const respondToTrade = trpc.trades.respond.useMutation({
    onSuccess: () => {
      toast.success("Trade response sent.");
      onTradeUpdated?.();
      onClose();
    },
    onError: () => toast.error("Failed to respond to trade."),
  });

  const handleAgreeClick = () => {
    setShowAddressForm(true);
  };

  const handleConfirmAgree = () => {
    if (!addressValues.address || !addressValues.city || !addressValues.state || !addressValues.zip) {
      toast.error("Please fill in your shipping address before agreeing.");
      return;
    }
    agreeToTrade.mutate({
      id: trade.id,
      address: addressValues.address,
      city: addressValues.city,
      state: addressValues.state,
      zip: addressValues.zip,
      phone: addressValues.phone,
    });
  };

  const handleAddTracking = () => {
    if (!trackingNumber.trim()) return;
    addTracking.mutate({ id: trade.id, trackingNumber: trackingNumber.trim() });
  };

  const handleDecline = () => {
    respondToTrade.mutate({ tradeId: trade.id, status: "rejected" });
  };

  const offeredCards: TradeCard[] = (trade.offeredCardTitles || []).map((title, i) => ({
    title,
    imageUrl: trade.offeredCardImages?.[i],
    grade: trade.offeredCardGrades?.[i],
  }));
  const requestedCards: TradeCard[] = (trade.requestedCardTitles || []).map((title, i) => ({
    title,
    imageUrl: trade.requestedCardImages?.[i],
    grade: trade.requestedCardGrades?.[i],
  }));

  // Build party objects for the agreement document
  const initiatorParty = {
    name: trade.initiatorName || trade.initiatorEmail,
    email: trade.initiatorEmail,
    address: trade.initiatorAddress,
    city: trade.initiatorCity,
    state: trade.initiatorState,
    zip: trade.initiatorZip,
    phone: trade.initiatorPhone,
    signedAt: trade.initiatorSignedAt,
  };
  const receiverParty = {
    name: trade.receiverName || trade.receiverEmail,
    email: trade.receiverEmail,
    address: trade.receiverAddress,
    city: trade.receiverCity,
    state: trade.receiverState,
    zip: trade.receiverZip,
    phone: trade.receiverPhone,
    signedAt: trade.receiverSignedAt,
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-3xl bg-[#0a1628] border border-white/10 text-white p-0 overflow-hidden max-h-[90vh] overflow-y-auto">
        {/* Header with logo */}
        <div className="bg-gradient-to-r from-[#C41E3A] to-[#8B0000] px-6 py-4 flex items-center gap-3 sticky top-0 z-10">
          <img src={LOGO_URL} alt="SportCardsOnline" className="h-10 w-auto" />
          <div>
            <h2 className="text-white font-bold text-lg" style={{ fontFamily: "Oswald, sans-serif" }}>
              Trade Agreement #{trade.id}
            </h2>
            <p className="text-white/70 text-xs">Protected by SCO Escrow Service</p>
          </div>
          <div className="ml-auto flex items-center gap-2">
            {trade.ticketNumber && (
              <span className="text-white/60 text-xs font-mono">{trade.ticketNumber}</span>
            )}
            <Badge className={
              trade.status === "agreed" ? "bg-green-600 text-white" :
              trade.status === "shipped" ? "bg-blue-600 text-white" :
              trade.status === "completed" ? "bg-purple-600 text-white" :
              trade.status === "pending" ? "bg-yellow-600 text-white" :
              "bg-gray-600 text-white"
            }>
              {trade.status.toUpperCase()}
            </Badge>
          </div>
        </div>

        {bothAgreed ? (
          /* ── BOTH AGREED: Show tabs for Agreement Details + Printable Agreement ── */
          <Tabs defaultValue="details" className="p-0">
            <TabsList className="w-full rounded-none border-b border-white/10 bg-[#0d1f3c] h-10">
              <TabsTrigger value="details" className="flex-1 text-xs data-[state=active]:bg-[#0a1628] data-[state=active]:text-white text-white/50">
                <CheckCircle className="w-3 h-3 mr-1" /> Agreement Details
              </TabsTrigger>
              <TabsTrigger value="agreement" className="flex-1 text-xs data-[state=active]:bg-[#0a1628] data-[state=active]:text-white text-white/50">
                <FileText className="w-3 h-3 mr-1" /> Print / Download Agreement
              </TabsTrigger>
            </TabsList>

            <TabsContent value="details" className="p-6 space-y-5 mt-0">
              {/* Agreement confirmed banner */}
              <div className="bg-green-900/30 border border-green-500/40 rounded-lg p-4 flex items-start gap-3">
                <CheckCircle className="w-5 h-5 text-green-400 mt-0.5 shrink-0" />
                <div>
                  <p className="text-green-300 font-bold text-sm">Trade Agreement Confirmed!</p>
                  <p className="text-green-200/70 text-xs mt-1">
                    Both parties have digitally agreed. Check your messages and email for the full next-steps instructions.
                    You can also print or download your signed agreement from the tab above.
                  </p>
                </div>
              </div>

              {/* Cards */}
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-[#0d1f3c] rounded-lg p-3 border border-white/10">
                  <p className="text-white/50 text-xs font-semibold uppercase tracking-wider mb-3">
                    {isInitiator ? "Your Cards (Sending)" : `${trade.initiatorName || trade.initiatorEmail}'s Cards`}
                  </p>
                  <div className="flex flex-wrap gap-2">
                    {offeredCards.map((c, i) => <CardThumb key={i} title={c.title} imageUrl={c.imageUrl} />)}
                  </div>
                </div>
                <div className="bg-[#0d1f3c] rounded-lg p-3 border border-white/10">
                  <p className="text-white/50 text-xs font-semibold uppercase tracking-wider mb-3">
                    {isReceiver ? "Your Cards (Sending)" : `${trade.receiverName || trade.receiverEmail}'s Cards`}
                  </p>
                  <div className="flex flex-wrap gap-2">
                    {requestedCards.map((c, i) => <CardThumb key={i} title={c.title} imageUrl={c.imageUrl} />)}
                  </div>
                </div>
              </div>

              {/* Next steps */}
              <div className="bg-blue-900/20 border border-blue-500/30 rounded-lg p-4">
                <p className="text-blue-300 font-bold text-sm mb-3 flex items-center gap-2">
                  <Package className="w-4 h-4" /> Next Steps — Ship Your Cards
                </p>
                <div className="space-y-2 text-xs text-blue-200/80">
                  <p>1️⃣ <strong>Prepare:</strong> Cards in sleeve, unsealed inner envelope with your name, Trade ID #{trade.id} on outside</p>
                  <p>2️⃣ <strong>Ship to:</strong> SportCardsOnline.com — SCO Secured Location, Attn: Trade Escrow, Trade ID: #{trade.id}</p>
                  <p>3️⃣ <strong>Add tracking below</strong> after shipping</p>
                  <p>4️⃣ <strong>Pay $10 escrow fee</strong> via the Pay Fee button on your Trades page</p>
                </div>
              </div>

              {/* Tracking section */}
              <div className="bg-[#0d1f3c] rounded-lg p-4 border border-white/10">
                <p className="text-white/70 text-xs font-semibold uppercase tracking-wider mb-3">Tracking Numbers</p>
                {!myTracking ? (
                  showTracking ? (
                    <div className="flex gap-2">
                      <Input
                        value={trackingNumber}
                        onChange={e => setTrackingNumber(e.target.value)}
                        placeholder="Enter your tracking number..."
                        className="bg-[#0a1628] border-white/20 text-white placeholder:text-white/30 text-sm"
                      />
                      <Button size="sm" onClick={handleAddTracking} disabled={addTracking.isPending || !trackingNumber.trim()} className="bg-blue-600 hover:bg-blue-700 text-white shrink-0">
                        {addTracking.isPending ? "Saving..." : "Save"}
                      </Button>
                    </div>
                  ) : (
                    <Button size="sm" variant="outline" onClick={() => setShowTracking(true)} className="border-blue-500/50 text-blue-300 hover:bg-blue-900/30">
                      <Truck className="w-4 h-4 mr-1" /> Add My Tracking Number
                    </Button>
                  )
                ) : (
                  <div className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-400" />
                    <span className="text-green-300 text-sm">Your tracking: <strong>{myTracking}</strong></span>
                  </div>
                )}
                {otherTracking && (
                  <div className="mt-2 flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-400" />
                    <span className="text-green-300 text-sm">{otherName}'s tracking: <strong>{otherTracking}</strong></span>
                  </div>
                )}
                {!otherTracking && (
                  <p className="text-white/30 text-xs mt-2">Waiting for {otherName} to add their tracking number...</p>
                )}
              </div>

              {trade.status === "completed" && (
                <div className="flex items-center gap-2 bg-green-900/20 border border-green-500/30 rounded-lg p-3">
                  <Star className="w-4 h-4 text-yellow-400" />
                  <span className="text-green-300 text-sm font-semibold">Trade completed! Cards have been delivered.</span>
                </div>
              )}
            </TabsContent>

            <TabsContent value="agreement" className="p-6 mt-0">
              <div className="mb-4 p-3 bg-green-900/20 border border-green-500/30 rounded-lg text-xs text-green-200/80">
                <p className="font-semibold text-green-300 mb-1">✅ Signed Trade Agreement</p>
                <p>This agreement was digitally signed by both parties. You can print it or save it as a PDF for your records. A copy was also emailed to both parties.</p>
              </div>
              <div className="bg-white rounded-lg overflow-hidden">
                <TradeAgreementDocument
                  tradeId={trade.id}
                  initiator={initiatorParty}
                  receiver={receiverParty}
                  offeredCards={offeredCards}
                  requestedCards={requestedCards}
                  agreedAt={trade.agreementSentAt}
                  ticketNumber={trade.ticketNumber}
                />
              </div>
            </TabsContent>
          </Tabs>
        ) : (
          /* ── NOT YET BOTH AGREED: Show standard agreement view ── */
          <div className="p-6 space-y-5">
            {/* Cards being traded */}
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-[#0d1f3c] rounded-lg p-3 border border-white/10">
                <p className="text-white/50 text-xs font-semibold uppercase tracking-wider mb-3">
                  {isInitiator ? "Your Cards (Offering)" : `${otherName}'s Cards (Offering)`}
                </p>
                <div className="flex flex-wrap gap-2">
                  {offeredCards.map((c, i) => <CardThumb key={i} title={c.title} imageUrl={c.imageUrl} />)}
                </div>
              </div>
              <div className="bg-[#0d1f3c] rounded-lg p-3 border border-white/10">
                <p className="text-white/50 text-xs font-semibold uppercase tracking-wider mb-3">
                  {isReceiver ? "Your Cards (Offering)" : `${otherName}'s Cards (Requesting)`}
                </p>
                <div className="flex flex-wrap gap-2">
                  {requestedCards.map((c, i) => <CardThumb key={i} title={c.title} imageUrl={c.imageUrl} />)}
                </div>
              </div>
            </div>

            {trade.message && (
              <div className="bg-[#0d1f3c] rounded-lg p-3 border border-white/10">
                <p className="text-white/50 text-xs font-semibold uppercase tracking-wider mb-1">Message</p>
                <p className="text-white/80 text-sm">{trade.message}</p>
              </div>
            )}

            <Separator className="bg-white/10" />

            {/* SCO Escrow Steps */}
            <div>
              <p className="text-white/50 text-xs font-semibold uppercase tracking-wider mb-3">How SCO Protects Both Parties</p>
              <div className="space-y-2">
                {ESCROW_STEPS.map((step, i) => (
                  <div key={i} className="flex items-center gap-3">
                    <div className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold bg-white/10 text-white/50`}>{i + 1}</div>
                    <step.icon className={`w-4 h-4 ${step.color}`} />
                    <span className="text-white/70 text-sm">{step.label}</span>
                  </div>
                ))}
              </div>
            </div>

            <Separator className="bg-white/10" />

            {/* Agreement status */}
            <div className="grid grid-cols-2 gap-3">
              <div className={`rounded-lg p-3 border text-center ${trade.initiatorAgreed ? "border-green-500/50 bg-green-900/20" : "border-white/10 bg-[#0d1f3c]"}`}>
                <p className="text-white/50 text-xs mb-1">{isInitiator ? "You" : (trade.initiatorName || trade.initiatorEmail)}</p>
                {trade.initiatorAgreed
                  ? <p className="text-green-400 text-sm font-semibold flex items-center justify-center gap-1"><CheckCircle className="w-4 h-4" /> Agreed</p>
                  : <p className="text-white/40 text-sm">Pending...</p>}
              </div>
              <div className={`rounded-lg p-3 border text-center ${trade.receiverAgreed ? "border-green-500/50 bg-green-900/20" : "border-white/10 bg-[#0d1f3c]"}`}>
                <p className="text-white/50 text-xs mb-1">{isReceiver ? "You" : (trade.receiverName || trade.receiverEmail)}</p>
                {trade.receiverAgreed
                  ? <p className="text-green-400 text-sm font-semibold flex items-center justify-center gap-1"><CheckCircle className="w-4 h-4" /> Agreed</p>
                  : <p className="text-white/40 text-sm">Pending...</p>}
              </div>
            </div>

            {/* Address form — shown when user clicks "I Agree" */}
            {showAddressForm && !myAgreed && (
              <div className="bg-[#0d1f3c] border border-yellow-500/30 rounded-lg p-4">
                <div className="flex items-center gap-2 mb-3">
                  <MapPin className="w-4 h-4 text-yellow-400" />
                  <p className="text-yellow-300 font-semibold text-sm">Enter Your Shipping Address</p>
                </div>
                <p className="text-white/50 text-xs mb-3">
                  Your address will appear on the trade agreement so SCO can ship your new cards to you after verification.
                </p>
                <AddressForm values={addressValues} onChange={setAddressValues} />
                <div className="flex gap-2 mt-4">
                  <Button variant="outline" size="sm" onClick={() => setShowAddressForm(false)} className="border-white/20 text-white/70 hover:bg-white/10">
                    Cancel
                  </Button>
                  <Button
                    size="sm"
                    onClick={handleConfirmAgree}
                    disabled={agreeToTrade.isPending}
                    className="flex-1 bg-gradient-to-r from-[#C41E3A] to-[#8B0000] hover:from-[#a01830] hover:to-[#6b0000] text-white font-bold"
                  >
                    <CheckCircle className="w-4 h-4 mr-2" />
                    {agreeToTrade.isPending ? "Agreeing..." : "Confirm & Sign Agreement"}
                  </Button>
                </div>
              </div>
            )}

            {/* Action buttons */}
            {(trade.status === "pending" || trade.status === "accepted") && !showAddressForm && (
              <div className="flex gap-3">
                {!myAgreed && (isInitiator || isReceiver) && (
                  <Button
                    className="flex-1 bg-gradient-to-r from-[#C41E3A] to-[#8B0000] hover:from-[#a01830] hover:to-[#6b0000] text-white font-bold"
                    onClick={handleAgreeClick}
                  >
                    <CheckCircle className="w-4 h-4 mr-2" />
                    I Agree to This Trade
                  </Button>
                )}
                {myAgreed && !bothAgreed && (
                  <div className="flex-1 flex items-center justify-center gap-2 bg-green-900/20 border border-green-500/30 rounded-lg py-3">
                    <CheckCircle className="w-4 h-4 text-green-400" />
                    <span className="text-green-300 text-sm">You agreed — waiting for {otherName}...</span>
                  </div>
                )}
                {isReceiver && !myAgreed && (
                  <Button
                    variant="outline"
                    className="border-red-500/50 text-red-400 hover:bg-red-900/20"
                    onClick={handleDecline}
                    disabled={respondToTrade.isPending}
                  >
                    Decline
                  </Button>
                )}
              </div>
            )}

            {trade.status === "completed" && (
              <div className="flex items-center gap-2 bg-green-900/20 border border-green-500/30 rounded-lg p-3">
                <Star className="w-4 h-4 text-yellow-400" />
                <span className="text-green-300 text-sm font-semibold">Trade completed! Cards have been delivered.</span>
              </div>
            )}
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
