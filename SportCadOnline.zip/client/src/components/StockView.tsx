import { useState, useMemo } from "react";
import { trpc } from "@/lib/trpc";
import { TrendingUp, TrendingDown, Minus, BarChart2, ArrowUpDown, Flame, Activity, DollarSign, RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";

// ─── Mini sparkline SVG ───────────────────────────────────────────────────────
function Sparkline({ prices, width = 60, height = 22 }: { prices: number[]; width?: number; height?: number }) {
  if (prices.length < 2) {
    return <div style={{ width, height }} className="flex items-center justify-center text-white/20 text-[10px]">—</div>;
  }
  const min = Math.min(...prices);
  const max = Math.max(...prices);
  const range = max - min || 1;
  const pad = 2;
  const pts = prices.map((p, i) => {
    const x = pad + (i / (prices.length - 1)) * (width - pad * 2);
    const y = height - pad - ((p - min) / range) * (height - pad * 2);
    return `${x.toFixed(1)},${y.toFixed(1)}`;
  });
  const rising = prices[prices.length - 1] >= prices[0];
  const color = rising ? "#22c55e" : "#ef4444";
  return (
    <svg width={width} height={height} className="shrink-0 overflow-visible">
      <polyline points={pts.join(" ")} fill="none" stroke={color} strokeWidth="1.5" strokeLinejoin="round" />
      <circle cx={pts[pts.length - 1].split(",")[0]} cy={pts[pts.length - 1].split(",")[1]}
        r="2" fill={color} />
    </svg>
  );
}

// ─── Per-card ticker row ──────────────────────────────────────────────────────
function CardTicker({ item, rank }: { item: any; rank: number }) {
  const estValue = parseFloat(item.estimatedValueHigh || item.estimatedValueLow || "0");
  const cardName = item.playerName || item.cardTitle || "Unknown Card";
  const searchQuery = `${cardName} ${item.year || ""} ${item.setName || ""} ${item.gradeLabel || ""}`.trim();

  const { data, isFetching } = trpc.ebay.getSoldComps.useQuery(
    { query: searchQuery, limit: 6 },
    { enabled: searchQuery.length >= 3, staleTime: 5 * 60 * 1000 }
  );

  const sales = data?.sales || [];
  const prices = sales.map((s: any) => s.price as number).filter((p: number) => p > 0);
  const latestSale = prices[0] ?? null;
  const prevSale = prices[1] ?? latestSale;
  const change = latestSale !== null && prevSale !== null ? latestSale - prevSale : null;
  const changePct = change !== null && prevSale ? (change / prevSale) * 100 : null;
  const vsEst = latestSale !== null && estValue > 0 ? ((latestSale - estValue) / estValue) * 100 : null;
  const isHot = vsEst !== null && vsEst > 10;
  const isTrending = changePct !== null && changePct > 5;
  const isDown = changePct !== null && changePct < -5;

  return (
    <div className={`flex items-center gap-3 px-4 py-3 border-b border-white/5 hover:bg-white/3 transition-colors group ${rank <= 3 ? "bg-white/[0.02]" : ""}`}>
      {/* Rank */}
      <span className="text-xs text-white/20 w-5 text-right shrink-0 font-mono">{rank}</span>

      {/* Card image */}
      <div className="w-8 h-11 rounded shrink-0 overflow-hidden bg-white/5">
        {item.frontImageUrl
          ? <img src={item.frontImageUrl} alt={cardName} className="w-full h-full object-cover" />
          : <div className="w-full h-full flex items-center justify-center text-white/10 text-[8px]">IMG</div>}
      </div>

      {/* Card info */}
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-1.5">
          <span className="text-sm font-semibold text-white truncate">{cardName}</span>
          {isHot && <span className="text-[10px] bg-orange-500/20 text-orange-400 border border-orange-500/30 rounded px-1 py-0.5 shrink-0">🔥 HOT</span>}
          {isTrending && !isHot && <span className="text-[10px] bg-green-500/20 text-green-400 border border-green-500/30 rounded px-1 py-0.5 shrink-0">📈 TRENDING</span>}
          {isDown && <span className="text-[10px] bg-red-500/20 text-red-400 border border-red-500/30 rounded px-1 py-0.5 shrink-0">📉 DIP</span>}
        </div>
        <div className="flex items-center gap-2 mt-0.5">
          {item.gradeLabel && <span className="text-[10px] text-blue-400 font-mono">{item.gradeLabel}</span>}
          {item.year && <span className="text-[10px] text-white/30">{item.year}</span>}
          {item.setName && <span className="text-[10px] text-white/30 truncate">{item.setName}</span>}
        </div>
      </div>

      {/* Sparkline */}
      <div className="hidden sm:block shrink-0">
        {isFetching
          ? <div className="w-[60px] h-[22px] bg-white/5 rounded animate-pulse" />
          : <Sparkline prices={[...prices].reverse()} />}
      </div>

      {/* Last eBay sale */}
      <div className="text-right shrink-0 w-20">
        <p className="text-xs text-white/40 uppercase tracking-wide">eBay Last</p>
        {isFetching
          ? <div className="h-4 w-16 bg-white/5 rounded animate-pulse mt-0.5" />
          : latestSale !== null
            ? <p className="text-sm font-bold text-white">${latestSale.toFixed(2)}</p>
            : <p className="text-sm text-white/20">—</p>}
      </div>

      {/* Change */}
      <div className="text-right shrink-0 w-24">
        <p className="text-xs text-white/40 uppercase tracking-wide">Change</p>
        {isFetching
          ? <div className="h-4 w-20 bg-white/5 rounded animate-pulse mt-0.5" />
          : change !== null
            ? (
              <div className={`flex items-center justify-end gap-0.5 ${change >= 0 ? "text-green-400" : "text-red-400"}`}>
                {change > 0 ? <TrendingUp className="w-3 h-3" /> : change < 0 ? <TrendingDown className="w-3 h-3" /> : <Minus className="w-3 h-3" />}
                <span className="text-xs font-bold">{change >= 0 ? "+" : ""}${Math.abs(change).toFixed(2)}</span>
              </div>
            )
            : <p className="text-sm text-white/20">—</p>}
        {changePct !== null && (
          <p className={`text-[10px] ${changePct >= 0 ? "text-green-400/60" : "text-red-400/60"}`}>
            {changePct >= 0 ? "+" : ""}{changePct.toFixed(1)}%
          </p>
        )}
      </div>

      {/* Est. value */}
      <div className="text-right shrink-0 w-20">
        <p className="text-xs text-white/40 uppercase tracking-wide">Est. Value</p>
        <p className="text-sm font-bold text-yellow-400">{estValue > 0 ? `$${estValue.toFixed(2)}` : "—"}</p>
        {vsEst !== null && (
          <p className={`text-[10px] ${vsEst >= 0 ? "text-green-400/60" : "text-red-400/60"}`}>
            {vsEst >= 0 ? "▲" : "▼"} {Math.abs(vsEst).toFixed(1)}% vs est
          </p>
        )}
      </div>
    </div>
  );
}

// ─── Portfolio Summary Bar ────────────────────────────────────────────────────
function PortfolioSummary({ collection }: { collection: any[] }) {
  const totalEst = collection.reduce((sum, item) => {
    const v = parseFloat(item.estimatedValueHigh || item.estimatedValueLow || "0");
    return sum + v;
  }, 0);
  const cardsWithValue = collection.filter(item => parseFloat(item.estimatedValueHigh || item.estimatedValueLow || "0") > 0).length;
  const gradedCount = collection.filter(item => item.gradeLabel).length;

  return (
    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-4">
      <div className="bg-gradient-to-br from-yellow-500/10 to-yellow-500/5 border border-yellow-500/20 rounded-xl p-4">
        <div className="flex items-center gap-2 mb-1">
          <DollarSign className="w-4 h-4 text-yellow-400" />
          <span className="text-xs text-white/50 uppercase tracking-wide">Portfolio Value</span>
        </div>
        <p className="text-2xl font-black text-yellow-400">${totalEst.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</p>
        <p className="text-xs text-white/30 mt-0.5">{cardsWithValue} cards with value</p>
      </div>

      <div className="bg-gradient-to-br from-blue-500/10 to-blue-500/5 border border-blue-500/20 rounded-xl p-4">
        <div className="flex items-center gap-2 mb-1">
          <BarChart2 className="w-4 h-4 text-blue-400" />
          <span className="text-xs text-white/50 uppercase tracking-wide">Total Cards</span>
        </div>
        <p className="text-2xl font-black text-blue-400">{collection.length}</p>
        <p className="text-xs text-white/30 mt-0.5">{gradedCount} graded</p>
      </div>

      <div className="bg-gradient-to-br from-green-500/10 to-green-500/5 border border-green-500/20 rounded-xl p-4">
        <div className="flex items-center gap-2 mb-1">
          <TrendingUp className="w-4 h-4 text-green-400" />
          <span className="text-xs text-white/50 uppercase tracking-wide">Avg Card Value</span>
        </div>
        <p className="text-2xl font-black text-green-400">
          {cardsWithValue > 0 ? `$${(totalEst / cardsWithValue).toFixed(2)}` : "—"}
        </p>
        <p className="text-xs text-white/30 mt-0.5">across valued cards</p>
      </div>

      <div className="bg-gradient-to-br from-[#c41e3a]/10 to-[#c41e3a]/5 border border-[#c41e3a]/20 rounded-xl p-4">
        <div className="flex items-center gap-2 mb-1">
          <Flame className="w-4 h-4 text-[#c41e3a]" />
          <span className="text-xs text-white/50 uppercase tracking-wide">Live eBay Data</span>
        </div>
        <p className="text-2xl font-black text-[#ff6b6b]">LIVE</p>
        <p className="text-xs text-white/30 mt-0.5">Prices update on view</p>
      </div>
    </div>
  );
}

// ─── Sort controls ────────────────────────────────────────────────────────────
type SortKey = "value" | "player" | "grade" | "sport";

// ─── Main StockView export ────────────────────────────────────────────────────
export default function StockView({ collection }: { collection: any[] }) {
  const [sortKey, setSortKey] = useState<SortKey>("value");
  const [sortAsc, setSortAsc] = useState(false);

  const sorted = useMemo(() => {
    const arr = [...collection];
    arr.sort((a, b) => {
      let va: number | string = 0, vb: number | string = 0;
      if (sortKey === "value") {
        va = parseFloat(a.estimatedValueHigh || a.estimatedValueLow || "0");
        vb = parseFloat(b.estimatedValueHigh || b.estimatedValueLow || "0");
      } else if (sortKey === "player") {
        va = (a.playerName || a.cardTitle || "").toLowerCase();
        vb = (b.playerName || b.cardTitle || "").toLowerCase();
      } else if (sortKey === "grade") {
        va = parseFloat(a.overallGrade || "0");
        vb = parseFloat(b.overallGrade || "0");
      } else if (sortKey === "sport") {
        va = a.sport || "";
        vb = b.sport || "";
      }
      if (typeof va === "number" && typeof vb === "number") {
        return sortAsc ? va - vb : vb - va;
      }
      return sortAsc
        ? String(va).localeCompare(String(vb))
        : String(vb).localeCompare(String(va));
    });
    return arr;
  }, [collection, sortKey, sortAsc]);

  const toggleSort = (key: SortKey) => {
    if (sortKey === key) setSortAsc(a => !a);
    else { setSortKey(key); setSortAsc(false); }
  };

  return (
    <div className="space-y-4">
      {/* Portfolio summary */}
      <PortfolioSummary collection={collection} />

      {/* Disclaimer */}
      <div className="flex items-center gap-2 bg-blue-500/5 border border-blue-500/20 rounded-lg px-4 py-2.5 text-xs text-blue-300/60">
        <Activity className="w-3.5 h-3.5 shrink-0" />
        Live eBay data is pulled per card on load. Prices reflect recent active listings in the Trading Cards category — not guaranteed sold prices. Refresh the page to update.
      </div>

      {/* Table header */}
      <div className="bg-[#0d1f3c] rounded-xl border border-white/10 overflow-hidden">
        <div className="flex items-center gap-3 px-4 py-2.5 border-b border-white/10 bg-white/[0.02]">
          <span className="text-xs text-white/30 w-5 shrink-0">#</span>
          <span className="text-xs text-white/30 w-8 shrink-0" />
          <div className="flex-1 flex items-center gap-4">
            <button onClick={() => toggleSort("player")}
              className="flex items-center gap-1 text-xs text-white/40 hover:text-white/70 uppercase tracking-wide">
              Card <ArrowUpDown className="w-3 h-3" />
            </button>
          </div>
          <span className="text-xs text-white/30 hidden sm:block w-[60px] text-center uppercase tracking-wide">Trend</span>
          <span className="text-xs text-white/30 w-20 text-right uppercase tracking-wide">eBay Last</span>
          <button onClick={() => toggleSort("value")}
            className="flex items-center justify-end gap-1 text-xs text-white/40 hover:text-white/70 uppercase tracking-wide w-24">
            Change <ArrowUpDown className="w-3 h-3" />
          </button>
          <button onClick={() => toggleSort("value")}
            className="flex items-center justify-end gap-1 text-xs text-white/40 hover:text-white/70 uppercase tracking-wide w-20">
            Est. Val <ArrowUpDown className="w-3 h-3" />
          </button>
        </div>

        {/* Rows */}
        {sorted.map((item, i) => (
          <CardTicker key={item.id} item={item} rank={i + 1} />
        ))}

        {collection.length === 0 && (
          <div className="text-center py-16 text-white/30">
            <BarChart2 className="w-10 h-10 mx-auto mb-3 opacity-20" />
            <p className="text-sm">No cards in your collection yet</p>
          </div>
        )}
      </div>

      <p className="text-[10px] text-white/20 text-center flex items-center justify-center gap-1">
        <RefreshCw className="w-3 h-3" />
        eBay data refreshes automatically · Sorted by {sortKey} {sortAsc ? "↑" : "↓"}
      </p>
    </div>
  );
}
