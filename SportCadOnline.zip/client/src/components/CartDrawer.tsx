/**
 * CartDrawer — slide-out cart panel from the right side
 */
import { useCart } from "@/contexts/CartContext";
import { Button } from "@/components/ui/button";
import { X, Trash2, ShoppingCart, Package, Loader2 } from "lucide-react";
import { Link } from "wouter";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

interface CartDrawerProps {
  open: boolean;
  onClose: () => void;
}

export default function CartDrawer({ open, onClose }: CartDrawerProps) {
  const { items, removeItem, clearCart, subtotal } = useCart();
  const { isAuthenticated } = useAuth();
  const createCartCheckout = trpc.orders.createCartCheckoutSession.useMutation();

  const handleCheckoutAll = async () => {
    if (!isAuthenticated || items.length === 0) return;
    try {
      const { checkoutUrl } = await createCartCheckout.mutateAsync({
        items: items.map(i => ({
          cardId: i.id,
          cardTitle: i.title,
          cardImageUrl: i.frontImageUrl ?? undefined,
          sellerEmail: i.sellerEmail,
          sellerStoreName: i.storeName ?? undefined,
          price: i.price,
        })),
        origin: window.location.origin,
      });
      toast.info("Opening checkout...");
      window.open(checkoutUrl, "_blank");
      onClose();
    } catch (e: any) {
      toast.error(e.message || "Checkout failed");
    }
  };

  return (
    <>
      {/* Backdrop */}
      {open && (
        <div
          className="fixed inset-0 z-[80] bg-black/50 backdrop-blur-sm"
          onClick={onClose}
        />
      )}

      {/* Drawer */}
      <div className={`fixed top-0 right-0 h-full w-80 z-[90] bg-[#0a1628] border-l border-white/10 shadow-2xl flex flex-col transition-transform duration-300 ${open ? "translate-x-0" : "translate-x-full"}`}>
        {/* Header */}
        <div className="flex items-center justify-between px-4 py-3 border-b border-white/10 shrink-0">
          <div className="flex items-center gap-2">
            <ShoppingCart className="w-4 h-4 text-[#c41e3a]" />
            <span className="font-bold text-white">Cart</span>
            {items.length > 0 && (
              <span className="bg-[#c41e3a] text-white text-xs font-bold rounded-full w-5 h-5 flex items-center justify-center">
                {items.length}
              </span>
            )}
          </div>
          <button onClick={onClose} className="text-white/50 hover:text-white transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Items */}
        <div className="flex-1 overflow-y-auto py-2">
          {items.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full gap-3 text-white/30 px-6">
              <ShoppingCart className="w-12 h-12 opacity-30" />
              <p className="text-sm text-center">Your cart is empty. Browse the marketplace to add cards.</p>
              <Button asChild size="sm" variant="outline" className="border-white/20 text-white/60 hover:bg-white/10" onClick={onClose}>
                <Link href="/">Browse Marketplace</Link>
              </Button>
            </div>
          ) : (
            <div className="space-y-1 px-2">
              {items.map(item => (
                <div key={item.id} className="flex gap-2.5 p-2 rounded-lg bg-[#0d1f3c] border border-white/5 hover:border-white/10 transition-colors">
                  {/* Image */}
                  <div className="w-12 h-16 rounded bg-[#0a1628] overflow-hidden shrink-0 border border-white/10">
                    {item.frontImageUrl ? (
                      <img src={item.frontImageUrl} alt={item.title} className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center">
                        <Package className="w-4 h-4 text-white/20" />
                      </div>
                    )}
                  </div>
                  {/* Info */}
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-semibold text-white line-clamp-1">{item.playerName}</p>
                    <p className="text-[10px] text-white/40 line-clamp-1 mb-1">{item.title}</p>
                    {item.aiGrade && (
                      <span className="text-[9px] bg-[#c41e3a]/20 text-[#ff6b6b] border border-[#c41e3a]/30 rounded px-1 py-0.5">
                        SCG {item.aiGrade}
                      </span>
                    )}
                    <p className="text-sm font-bold text-[#c41e3a] mt-1">${parseFloat(item.price).toFixed(2)}</p>
                  </div>
                  {/* Remove */}
                  <button
                    onClick={() => removeItem(item.id)}
                    className="text-white/20 hover:text-red-400 transition-colors shrink-0 self-start mt-1"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Footer */}
        {items.length > 0 && (
          <div className="shrink-0 border-t border-white/10 p-4 space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-sm text-white/60">Subtotal ({items.length} {items.length === 1 ? "card" : "cards"})</span>
              <span className="text-lg font-black text-white">${subtotal.toFixed(2)}</span>
            </div>
            <p className="text-[10px] text-white/30">10% platform fee applies at checkout. Payment held in escrow until shipped.</p>
            {isAuthenticated ? (
              <>
                <Button
                  className="w-full bg-[#c41e3a] hover:bg-[#c41e3a]/90 text-white font-bold gap-2"
                  onClick={handleCheckoutAll}
                  disabled={createCartCheckout.isPending}
                >
                  {createCartCheckout.isPending
                    ? <Loader2 className="w-4 h-4 animate-spin" />
                    : <ShoppingCart className="w-4 h-4" />}
                  {createCartCheckout.isPending ? "Opening Stripe..." : `Checkout — $${subtotal.toFixed(2)}`}
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  className="w-full text-white/30 hover:text-red-400 hover:bg-red-500/10 text-xs"
                  onClick={clearCart}
                >
                  Clear Cart
                </Button>
              </>
            ) : (
              <Button asChild className="w-full bg-[#c41e3a] hover:bg-[#c41e3a]/90 text-white">
                <a href={getLoginUrl()}>Sign In to Checkout</a>
              </Button>
            )}
          </div>
        )}
      </div>
    </>
  );
}
