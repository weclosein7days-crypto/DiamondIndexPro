/**
 * AcrylicCardCase — Premium magnetic one-touch holder style card display
 * Mimics the look of a real acrylic/glass card case with:
 * - Beveled translucent acrylic border
 * - Gold screw cap at top
 * - Subtle light refraction / glare effects
 * - Inner card with slight perspective tilt
 */

import { cn } from "@/lib/utils";

interface AcrylicCardCaseProps {
  /** Card image URL */
  imageUrl?: string;
  /** Card name for alt text */
  cardName?: string;
  /** Grade label (e.g. "9.5", "10") — shown on a label strip at bottom */
  grade?: string | number | null;
  /** Grading company label (e.g. "SCG") */
  gradingCompany?: string;
  /** Extra CSS classes on the outer wrapper */
  className?: string;
  /** Size variant */
  size?: "sm" | "md" | "lg" | "xl";
  /** Whether to show a glow/shimmer animation */
  animated?: boolean;
  /** Click handler */
  onClick?: () => void;
}

const SIZE_MAP = {
  sm: { outer: "w-32 h-44", inner: "w-24 h-36", screw: "w-3 h-3", label: "text-[9px]" },
  md: { outer: "w-44 h-60", inner: "w-34 h-48", screw: "w-4 h-4", label: "text-[10px]" },
  lg: { outer: "w-56 h-76", inner: "w-44 h-60", screw: "w-5 h-5", label: "text-xs" },
  xl: { outer: "w-72 h-96", inner: "w-56 h-76", screw: "w-6 h-6", label: "text-sm" },
};

export function AcrylicCardCase({
  imageUrl,
  cardName = "Sports Card",
  grade,
  gradingCompany = "SCG",
  className,
  size = "md",
  animated = true,
  onClick,
}: AcrylicCardCaseProps) {
  const s = SIZE_MAP[size];

  return (
    <div
      className={cn("relative flex flex-col items-center select-none", onClick && "cursor-pointer", className)}
      onClick={onClick}
      style={{ filter: "drop-shadow(0 8px 32px rgba(100,180,255,0.35)) drop-shadow(0 2px 8px rgba(0,0,0,0.5))" }}
    >
      {/* Outer acrylic shell */}
      <div
        className={cn(
          "relative flex flex-col items-center justify-center rounded-[10px]",
          s.outer,
          animated && "transition-transform duration-300 hover:scale-105 hover:-rotate-1"
        )}
        style={{
          background: "linear-gradient(145deg, rgba(220,240,255,0.55) 0%, rgba(180,220,255,0.25) 40%, rgba(200,230,255,0.45) 100%)",
          border: "2px solid rgba(255,255,255,0.7)",
          boxShadow: [
            "inset 0 1px 0 rgba(255,255,255,0.9)",
            "inset 0 -1px 0 rgba(180,210,240,0.4)",
            "inset 1px 0 0 rgba(255,255,255,0.6)",
            "inset -1px 0 0 rgba(180,210,240,0.3)",
            "0 4px 24px rgba(100,160,220,0.3)",
          ].join(", "),
          backdropFilter: "blur(2px)",
        }}
      >
        {/* Top bevel highlight */}
        <div
          className="absolute top-0 left-2 right-2 h-[3px] rounded-full"
          style={{ background: "linear-gradient(90deg, transparent, rgba(255,255,255,0.95), transparent)" }}
        />

        {/* Left bevel highlight */}
        <div
          className="absolute left-0 top-4 bottom-4 w-[3px] rounded-full"
          style={{ background: "linear-gradient(180deg, transparent, rgba(255,255,255,0.7), transparent)" }}
        />

        {/* Right bevel shadow */}
        <div
          className="absolute right-0 top-4 bottom-4 w-[2px] rounded-full"
          style={{ background: "linear-gradient(180deg, transparent, rgba(140,180,220,0.4), transparent)" }}
        />

        {/* Bottom bevel shadow */}
        <div
          className="absolute bottom-0 left-2 right-2 h-[2px] rounded-full"
          style={{ background: "linear-gradient(90deg, transparent, rgba(140,180,220,0.5), transparent)" }}
        />

        {/* Gold screw cap at top center */}
        <div
          className={cn("absolute -top-1 left-1/2 -translate-x-1/2 rounded-full z-20 flex items-center justify-center", s.screw)}
          style={{
            background: "radial-gradient(circle at 35% 35%, #ffe066, #d4a017 50%, #8b6000 100%)",
            border: "1px solid rgba(255,220,50,0.8)",
            boxShadow: "0 1px 4px rgba(0,0,0,0.5), inset 0 1px 0 rgba(255,255,255,0.4)",
          }}
        >
          {/* Screw slot */}
          <div
            className="w-[55%] h-[2px] rounded-full"
            style={{ background: "rgba(80,50,0,0.6)", transform: "rotate(45deg)" }}
          />
        </div>

        {/* Inner card area */}
        <div
          className={cn("relative overflow-hidden rounded-[4px]", s.inner)}
          style={{
            margin: "12px 10px 10px",
            boxShadow: "inset 0 0 0 1px rgba(255,255,255,0.3), 0 2px 8px rgba(0,0,0,0.4)",
          }}
        >
          {imageUrl ? (
            <img
              src={imageUrl}
              alt={cardName}
              className="w-full h-full object-cover"
              style={{ imageRendering: "auto" }}
            />
          ) : (
            /* Placeholder when no image */
            <div
              className="w-full h-full flex flex-col items-center justify-center gap-2"
              style={{
                background: "linear-gradient(135deg, #1a2a3a 0%, #0d1a2a 100%)",
              }}
            >
              <div className="text-white/20 text-4xl">🃏</div>
              <div className="text-white/30 text-[10px] font-medium tracking-widest uppercase">Card</div>
            </div>
          )}

          {/* Glare overlay — diagonal light streak */}
          <div
            className="absolute inset-0 pointer-events-none"
            style={{
              background: "linear-gradient(125deg, rgba(255,255,255,0.18) 0%, rgba(255,255,255,0.05) 30%, transparent 60%)",
            }}
          />
        </div>

        {/* Grade label strip at bottom */}
        {grade != null && (
          <div
            className={cn("absolute bottom-[6px] left-[10px] right-[10px] flex items-center justify-between rounded-[3px] px-2 py-[2px]", s.label)}
            style={{
              background: "linear-gradient(90deg, rgba(10,20,40,0.85), rgba(20,30,60,0.85))",
              border: "1px solid rgba(255,255,255,0.15)",
            }}
          >
            <span className="text-white/50 font-semibold tracking-widest uppercase">{gradingCompany}</span>
            <span className="text-white font-black tracking-tight">{grade}</span>
          </div>
        )}

        {/* Animated shimmer sweep */}
        {animated && (
          <div
            className="absolute inset-0 rounded-[10px] pointer-events-none overflow-hidden"
            style={{ zIndex: 10 }}
          >
            <div
              className="absolute inset-0"
              style={{
                background: "linear-gradient(105deg, transparent 40%, rgba(255,255,255,0.12) 50%, transparent 60%)",
                animation: "acrylicShimmer 3s ease-in-out infinite",
              }}
            />
          </div>
        )}
      </div>

      {/* Card name below case */}
      {cardName && cardName !== "Sports Card" && (
        <div className="mt-2 text-center max-w-[160px]">
          <div className="text-white/70 text-[11px] font-medium truncate">{cardName}</div>
        </div>
      )}

      <style>{`
        @keyframes acrylicShimmer {
          0% { transform: translateX(-100%); }
          50% { transform: translateX(100%); }
          100% { transform: translateX(100%); }
        }
      `}</style>
    </div>
  );
}
