import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { Link, useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import {
  Menu, X, Coins, LogOut, LayoutDashboard, Shield, Award, Gavel,
  ArrowLeftRight, Camera, Gift, Mail, BarChart2, TrendingUp,
  ShoppingCart, ChevronDown, Search, Dice6, Package,
  Star, Trophy, Users, MessageSquare, HelpCircle, Vault, Rocket, Crown, Newspaper, Baby
} from "lucide-react";
import { useState, useEffect, useRef } from "react";
import { CompsPanel, ValuesPanel } from "@/components/CompsPanel";
import CartDrawer from "@/components/CartDrawer";
import { useCart } from "@/contexts/CartContext";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

const LOGO_URL = "https://d2xsxph8kpxj0f.cloudfront.net/310519663482618714/HBSXFxHmEnEJMgVvzKnhpZ/logo_transparent_8c903811.png";

interface NavItem {
  label: string;
  href?: string;
  action?: string;
  icon: React.ElementType;
  badge?: string;
  dividerBefore?: boolean;
  authOnly?: boolean;
  mobileHide?: boolean;
}
interface NavGroup {
  label: string;
  items: NavItem[];
  authOnly?: boolean;
  mobileHide?: boolean;
}

const NAV_GROUPS: NavGroup[] = [
  {
    label: "Marketplace",
    items: [
      { label: "Shop Cards", href: "/", icon: ShoppingCart },
      { label: "Find Any Card", href: "/find-cards", icon: Search, badge: "NEW" },
      { label: "Live Auctions", href: "/auctions", icon: Gavel, mobileHide: true },
      { label: "Trade Depot", href: "/trades", icon: ArrowLeftRight, authOnly: true, mobileHide: true },
      { label: "My Orders", href: "/orders", icon: Package, authOnly: true },
      { label: "Contact Us", href: "/contact", icon: Mail, dividerBefore: true },
      { label: "How It Works", href: "/how-it-works", icon: HelpCircle },
      { label: "Game Room", href: "/game-room", icon: Dice6, badge: "FREE", dividerBefore: true },
      { label: "Tournaments", href: "/game-room/tournaments", icon: Trophy },
      { label: "Prize Showcase", href: "/game-room/showcase", icon: Star },
      { label: "Pack Rip", href: "/game-room", icon: Gift },
    ],
  },
  {
    label: "Grading",
    items: [
      { label: "Grade a Card", href: "/grade", icon: Camera, badge: "AI" },
    ],
  },
  {
    label: "My Account",
    authOnly: true,
    items: [
      { label: "Dashboard", href: "/dashboard", icon: LayoutDashboard },
      { label: "My Collection", href: "/my-collection", icon: Award },
      { label: "My Vault", href: "/vault", icon: Vault },
      { label: "Credits & Loyalty", href: "/credits", icon: Coins },
      { label: "Messages", href: "/messages", icon: MessageSquare },
      { label: "Refer a Friend", href: "/referral", icon: Users, dividerBefore: true },
    ],
  },
  {
    label: "Blog",
    items: [
      { label: "Card News & Insights", href: "/blog", icon: Newspaper },
      { label: "Content Dashboard", href: "/content-dashboard", icon: BarChart2 },
    ],
  },
  {
    label: "Kids Corner",
    items: [
      { label: "🏆 Kids Corner", href: "/kids-corner", icon: Baby, badge: "FREE" },
    ],
  },
];
// Kids Corner is always rendered LAST — see desktop nav below

export default function NavBar() {
  const { user, isAuthenticated, loading } = useAuth();
  const [location] = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [compsOpen, setCompsOpen] = useState(false);
  const [valuesOpen, setValuesOpen] = useState(false);
  const [cartOpen, setCartOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const searchRef = useRef<HTMLInputElement>(null);
  const { totalCount } = useCart();

  const prevLocation = useRef(location);
  useEffect(() => {
    if (location !== prevLocation.current) {
      setCompsOpen(false);
      setValuesOpen(false);
      setMobileMenuOpen(false);
      prevLocation.current = location;
    }
  }, [location]);

  useEffect(() => {
    if (searchOpen) searchRef.current?.focus();
  }, [searchOpen]);

  const logout = trpc.auth.logout.useMutation();
  const { data: creditAccount } = trpc.credits.myAccount.useQuery(undefined, { enabled: isAuthenticated });

  const handleLogout = async () => {
    await logout.mutateAsync();
    window.location.href = "/";
  };

  const isAdmin = user?.role === "admin";

  const visibleGroups = NAV_GROUPS.map((g) => {
    if (g.label === "My Account" && isAdmin) {
      return {
        ...g,
        items: g.items.map((item) =>
          item.href === "/my-collection"
            ? { ...item, label: "House Collection", href: "/collection" }
            : item
        ),
      };
    }
    return g;
  }).filter((g) => !g.authOnly || isAuthenticated);

  function handleNavAction(action?: string) {
    if (action === "comps") { setCompsOpen(true); setValuesOpen(false); }
    if (action === "values") { setValuesOpen(true); setCompsOpen(false); }
  }

  function handleSearch(e: React.FormEvent) {
    e.preventDefault();
    if (searchQuery.trim()) {
      window.location.href = `/?q=${encodeURIComponent(searchQuery.trim())}`;
      setSearchOpen(false);
      setSearchQuery("");
    }
  }

  return (
    <>
      <nav className="fixed top-0 left-0 right-0 z-50 bg-white border-b border-gray-200 shadow-sm">
        <div className="max-w-[1440px] mx-auto px-4 lg:px-6">
          <div className="flex items-center justify-between h-[52px]">

            {/* Logo */}
            <Link href="/" className="flex items-center shrink-0 mr-5">
              <img
                src={LOGO_URL}
                alt="SportCardsOnline.com"
                className="h-10 w-auto object-contain"
                style={{ background: "transparent" }}
              />
            </Link>

            {/* Desktop Nav Groups */}
            <div className="hidden lg:flex items-center gap-0 flex-1">
              {visibleGroups.filter(g => g.label !== "Kids Corner").map((group) => (
                <DropdownMenu key={group.label}>
                  <DropdownMenuTrigger asChild>
                    <button className="flex items-center gap-1 px-3.5 py-1.5 text-[13px] font-semibold text-gray-700 hover:text-gray-900 hover:bg-gray-100 rounded-md transition-all whitespace-nowrap group outline-none">
                      {group.label}
                      <ChevronDown className="w-3.5 h-3.5 text-gray-400 group-hover:text-gray-600 transition-colors mt-px" />
                    </button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent
                    align="start"
                    sideOffset={6}
                    className="min-w-[210px] bg-white border border-gray-200 shadow-xl rounded-xl p-1.5"
                  >
                    {group.items
                      .filter((item) => !item.authOnly || isAuthenticated)
                      .map((item) => (
                        <div key={item.label}>
                          {item.dividerBefore && <DropdownMenuSeparator className="bg-gray-200 my-1" />}
                          {item.href ? (
                            <DropdownMenuItem asChild>
                              <Link
                                href={item.href}
                                className="flex items-center gap-2.5 px-3 py-2 text-[13px] text-gray-700 hover:text-gray-900 hover:bg-gray-100 rounded-lg cursor-pointer transition-colors"
                              >
                                <item.icon className="w-3.5 h-3.5 shrink-0 text-gray-400" />
                                <span className="flex-1">{item.label}</span>
                                {item.badge && (
                                  <span className={`text-[9px] font-black px-1.5 py-0.5 rounded-full uppercase tracking-wider ${
                                    item.badge === "FREE"
                                      ? "bg-[#c41e3a] text-white"
                                      : "bg-yellow-500 text-black"
                                  }`}>
                                    {item.badge}
                                  </span>
                                )}
                              </Link>
                            </DropdownMenuItem>
                          ) : (
                            <DropdownMenuItem
                              className="flex items-center gap-2.5 px-3 py-2 text-[13px] text-gray-700 hover:text-gray-900 hover:bg-gray-100 rounded-lg cursor-pointer transition-colors"
                              onClick={() => handleNavAction(item.action)}
                            >
                              <item.icon className="w-3.5 h-3.5 shrink-0 text-gray-400" />
                              <span className="flex-1">{item.label}</span>
                            </DropdownMenuItem>
                          )}
                        </div>
                      ))}
                  </DropdownMenuContent>
                </DropdownMenu>
              ))}
              {/* Standalone: Card Values & Comps */}
              <button
                onClick={() => { setValuesOpen(true); setCompsOpen(false); }}
                className="flex items-center gap-1 px-3.5 py-1.5 text-[13px] font-semibold text-gray-700 hover:text-gray-900 hover:bg-gray-100 rounded-md transition-all whitespace-nowrap outline-none"
              >
                <TrendingUp className="w-3.5 h-3.5 text-gray-400" />
                Card Values
              </button>
              <button
                onClick={() => { setCompsOpen(true); setValuesOpen(false); }}
                className="flex items-center gap-1 px-3.5 py-1.5 text-[13px] font-semibold text-gray-700 hover:text-gray-900 hover:bg-gray-100 rounded-md transition-all whitespace-nowrap outline-none"
              >
                <BarChart2 className="w-3.5 h-3.5 text-gray-400" />
                Comps
              </button>
              {/* Kids Corner — always last, spaced away from the rest */}
              {visibleGroups.filter(g => g.label === "Kids Corner").map((group) => (
                <DropdownMenu key={group.label}>
                  <DropdownMenuTrigger asChild>
                    <button className="flex items-center gap-1 ml-6 px-3 py-1.5 text-[13px] font-black rounded-md transition-all whitespace-nowrap outline-none hover:bg-gray-100">
                      <span style={{color:'#4285F4'}}>K</span><span style={{color:'#EA4335'}}>i</span><span style={{color:'#FBBC05'}}>d</span><span style={{color:'#34A853'}}>s</span>
                      <span className="mx-0.5"> </span>
                      <span style={{color:'#EA4335'}}>C</span><span style={{color:'#4285F4'}}>o</span><span style={{color:'#FBBC05'}}>r</span><span style={{color:'#34A853'}}>n</span><span style={{color:'#EA4335'}}>e</span><span style={{color:'#4285F4'}}>r</span>
                      <ChevronDown className="w-3.5 h-3.5 text-gray-400 ml-0.5" />
                    </button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="start" sideOffset={6} className="min-w-[210px] bg-white border border-gray-200 shadow-xl rounded-xl p-1.5">
                    {group.items.map((item) => (
                      <DropdownMenuItem key={item.label} asChild>
                        <Link href={item.href!} className="flex items-center gap-2.5 px-3 py-2 text-[13px] text-gray-700 hover:text-gray-900 hover:bg-gray-100 rounded-lg cursor-pointer transition-colors">
                          <item.icon className="w-3.5 h-3.5 shrink-0 text-gray-400" />
                          <span className="flex-1">{item.label}</span>
                          {item.badge && <span className="text-[9px] font-black px-1.5 py-0.5 rounded-full uppercase tracking-wider bg-[#c41e3a] text-white">{item.badge}</span>}
                        </Link>
                      </DropdownMenuItem>
                    ))}
                  </DropdownMenuContent>
                </DropdownMenu>
              ))}
            </div>

            {/* Right Side */}
            <div className="flex items-center gap-0.5">

              {/* Search */}
              {searchOpen ? (
                <form onSubmit={handleSearch} className="flex items-center mr-1">
                  <input
                    ref={searchRef}
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Search cards…"
                    className="w-44 h-8 bg-white border border-gray-300 rounded-l-lg text-gray-900 text-xs px-3 placeholder-gray-400 outline-none focus:border-[#c41e3a] transition-colors"
                    onBlur={() => { if (!searchQuery) setSearchOpen(false); }}
                  />
                  <button
                    type="submit"
                    className="h-8 px-2.5 bg-[#c41e3a] hover:bg-[#c41e3a]/90 text-white rounded-r-lg transition-colors"
                  >
                    <Search className="w-3.5 h-3.5" />
                  </button>
                </form>
              ) : (
                <button
                  onClick={() => setSearchOpen(true)}
                  className="flex items-center justify-center w-8 h-8 rounded-md text-gray-500 hover:text-gray-900 hover:bg-gray-100 transition-colors"
                  title="Search"
                >
                  <Search className="w-4 h-4" />
                </button>
              )}

              {/* Credits pill */}
              {isAuthenticated && creditAccount && (
                <Link href="/credits">
                  <button className="flex items-center gap-1 h-8 px-2.5 rounded-md text-gray-700 hover:text-gray-900 hover:bg-gray-100 transition-colors text-xs font-bold">
                    <Coins className="w-3.5 h-3.5 text-yellow-400" />
                    <span>{creditAccount.credits}</span>
                  </button>
                </Link>
              )}

              {/* Cart */}
              <button
                onClick={() => setCartOpen(true)}
                className="relative flex items-center justify-center w-8 h-8 rounded-md text-gray-500 hover:text-gray-900 hover:bg-gray-100 transition-colors"
                title="Cart"
              >
                <ShoppingCart className="w-4 h-4" />
                {totalCount > 0 && (
                  <span className="absolute -top-0.5 -right-0.5 w-4 h-4 bg-[#c41e3a] text-white text-[9px] font-black rounded-full flex items-center justify-center leading-none">
                    {totalCount > 9 ? "9+" : totalCount}
                  </span>
                )}
              </button>

              {/* Divider */}
              <div className="w-px h-5 bg-gray-200 mx-1 hidden sm:block" />

              {/* Account / Sign In */}
              {loading ? (
                <div className="w-8 h-8 rounded-full bg-gray-200 animate-pulse" />
              ) : isAuthenticated && user ? (
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <button className="flex items-center gap-1.5 h-8 pl-1.5 pr-2.5 rounded-md hover:bg-gray-100 transition-colors outline-none">
                      <div className="w-6 h-6 rounded-full bg-[#c41e3a] flex items-center justify-center text-white text-[11px] font-black shrink-0">
                        {(user.name || user.email || "U")[0].toUpperCase()}
                      </div>
                      <span className="hidden sm:inline text-xs font-semibold text-gray-700">
                        {user.name?.split(" ")[0] || "Account"}
                      </span>
                      <ChevronDown className="w-3 h-3 text-gray-400 hidden sm:inline" />
                    </button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="w-56 bg-white border border-gray-200 shadow-xl rounded-xl p-1.5">
                    <div className="px-3 py-2 border-b border-gray-200 mb-1">
                      <div className="text-sm font-bold text-gray-900 truncate">{user.name || "Account"}</div>
                      <div className="text-xs text-gray-500 truncate">{user.email}</div>
                    </div>
                    {[
                      { href: "/dashboard", icon: LayoutDashboard, label: "My Dashboard" },
                      { href: isAdmin ? "/collection" : "/my-collection", icon: Award, label: isAdmin ? "House Collection" : "My Collection" },
                      { href: "/vault", icon: Vault, label: "My Vault" },
                      { href: "/credits", icon: Coins, label: `Credits: ${creditAccount?.credits ?? 0}`, accent: "text-yellow-400" },
                      { href: "/orders", icon: Package, label: "My Orders" },
                      { href: "/messages", icon: MessageSquare, label: "Messages" },
                      { href: "/loyalty", icon: Trophy, label: "Loyalty Program" },
                      { href: "/referral", icon: Gift, label: "Refer a Friend" },
                    ].map(({ href, icon: Icon, label, accent }) => (
                      <DropdownMenuItem key={href} asChild>
                        <Link href={href} className="flex items-center gap-2.5 px-3 py-2 text-[13px] text-gray-700 hover:text-gray-900 hover:bg-gray-100 rounded-lg cursor-pointer transition-colors">
                          <Icon className={`w-3.5 h-3.5 shrink-0 ${accent || "text-gray-400"}`} />
                          {label}
                        </Link>
                      </DropdownMenuItem>
                    ))}
                    {isAdmin && (
                      <>
                        <DropdownMenuSeparator className="bg-gray-200 my-1" />
                        <DropdownMenuItem asChild>
                          <Link href="/admin" className="flex items-center gap-2.5 px-3 py-2 text-[13px] text-[#c41e3a] hover:bg-[#c41e3a]/10 rounded-lg cursor-pointer font-bold transition-colors">
                            <Shield className="w-3.5 h-3.5" />Admin Panel
                          </Link>
                        </DropdownMenuItem>
                      </>
                    )}
                    <DropdownMenuSeparator className="bg-gray-200 my-1" />
                    <DropdownMenuItem
                      onClick={handleLogout}
                      className="flex items-center gap-2.5 px-3 py-2 text-[13px] text-red-400 hover:text-red-300 hover:bg-red-500/10 rounded-lg cursor-pointer transition-colors"
                    >
                      <LogOut className="w-3.5 h-3.5" />Sign Out
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              ) : (
                <a
                  href={getLoginUrl()}
                  className="flex items-center h-8 px-4 bg-[#c41e3a] hover:bg-[#c41e3a]/90 text-white text-xs font-bold rounded-md transition-colors ml-1"
                >
                  Sign In
                </a>
              )}

              {/* Mobile toggle */}
              <button
                className="lg:hidden flex items-center justify-center w-8 h-8 rounded-md text-gray-600 hover:text-gray-900 hover:bg-gray-100 transition-colors ml-1"
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              >
                {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
              </button>
            </div>
          </div>

          {/* Mobile Menu */}
          {mobileMenuOpen && (
            <div className="lg:hidden border-t border-white/[0.08] py-3 bg-[#0a0a0a] max-h-[80vh] overflow-y-auto">
              {visibleGroups.filter((g) => !g.mobileHide).map((group) => (
                <div key={group.label} className="mb-2">
                  <div className="px-3 py-1 text-[10px] font-black text-white/25 uppercase tracking-[0.15em]">{group.label}</div>
                  {group.items
                    .filter((item) => (!item.authOnly || isAuthenticated) && !item.mobileHide)
                    .map((item) => (
                      <div key={item.label}>
                        {item.href ? (
                          <Link href={item.href}>
                            <button
                              className="w-full flex items-center gap-3 px-3 py-2.5 text-sm text-white/65 hover:text-white hover:bg-white/[0.06] rounded-lg transition-colors text-left"
                              onClick={() => setMobileMenuOpen(false)}
                            >
                              <item.icon className="w-4 h-4 text-white/30 shrink-0" />
                              <span className="flex-1">{item.label}</span>
                              {item.badge && (
                                <span className={`text-[9px] font-black px-1.5 py-0.5 rounded-full uppercase ${
                                  item.badge === "FREE" ? "bg-[#c41e3a] text-white" : "bg-yellow-500 text-black"
                                }`}>{item.badge}</span>
                              )}
                            </button>
                          </Link>
                        ) : (
                          <button
                            className="w-full flex items-center gap-3 px-3 py-2.5 text-sm text-white/65 hover:text-white hover:bg-white/[0.06] rounded-lg transition-colors text-left"
                            onClick={() => { handleNavAction(item.action); setMobileMenuOpen(false); }}
                          >
                            <item.icon className="w-4 h-4 text-white/30 shrink-0" />
                            {item.label}
                          </button>
                        )}
                      </div>
                    ))}
                </div>
              ))}
              <div className="border-t border-white/[0.08] pt-2 mt-1 px-1">
                <button
                  className="w-full flex items-center gap-3 px-3 py-2.5 text-sm text-white/65 hover:text-white hover:bg-white/[0.06] rounded-lg transition-colors"
                  onClick={() => { setCartOpen(true); setMobileMenuOpen(false); }}
                >
                  <ShoppingCart className="w-4 h-4 text-white/30" />
                  <span className="flex-1">Cart</span>
                  {totalCount > 0 && (
                    <span className="bg-[#c41e3a] text-white text-[9px] font-black rounded-full px-1.5 py-0.5">{totalCount}</span>
                  )}
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Slide-out panels */}
        <CompsPanel open={compsOpen} onClose={() => setCompsOpen(false)} />
        <ValuesPanel open={valuesOpen} onClose={() => setValuesOpen(false)} />
      </nav>

      <CartDrawer open={cartOpen} onClose={() => setCartOpen(false)} />
    </>
  );
}
