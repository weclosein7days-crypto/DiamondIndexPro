import { Link, useLocation } from "wouter";
import { ShoppingCart, Camera, TrendingUp, BarChart2, User, Plus } from "lucide-react";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";

const tabs = [
  { label: "Shop", href: "/", icon: ShoppingCart },
  { label: "Sell", href: "/my-collection", icon: Plus, authOnly: true },
  { label: "Grade", href: "/grade", icon: Camera },
  { label: "Comps", href: null, icon: TrendingUp, action: "comps" },
  { label: "Values", href: null, icon: BarChart2, action: "values" },
  { label: "Account", href: "/dashboard", icon: User, authOnly: true },
];

interface MobileBottomNavProps {
  onComps?: () => void;
  onValues?: () => void;
}

export function MobileBottomNav({ onComps, onValues }: MobileBottomNavProps) {
  const [location] = useLocation();
  const { isAuthenticated } = useAuth();

  const isActive = (href: string | null) => {
    if (!href) return false;
    if (href === "/") return location === "/";
    return location.startsWith(href);
  };

  const handleTab = (tab: typeof tabs[0]) => {
    if (tab.authOnly && !isAuthenticated) {
      window.location.href = getLoginUrl();
      return;
    }
    if (tab.action === "comps") { onComps?.(); return; }
    if (tab.action === "values") { onValues?.(); return; }
  };

  return (
    <nav className="lg:hidden fixed bottom-0 left-0 right-0 z-50 bg-[#0a0a0a] border-t border-white/10" style={{ paddingBottom: 'env(safe-area-inset-bottom, 0px)' }}>
      <div className="flex items-stretch h-[58px]">
        {tabs.map((tab) => {
          const active = isActive(tab.href);
          const content = (
            <div className={`flex flex-col items-center justify-center gap-0.5 flex-1 h-full px-1 transition-colors ${
              active ? "text-[#c41e3a]" : "text-white/40"
            }`}>
              <tab.icon className={`w-5 h-5 ${active ? "text-[#c41e3a]" : "text-white/40"}`} />
              <span className="text-[9px] font-semibold uppercase tracking-wide leading-none">{tab.label}</span>
              {active && <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-6 h-0.5 bg-[#c41e3a] rounded-full" />}
            </div>
          );

          if (tab.href && !tab.action) {
            if (tab.authOnly && !isAuthenticated) {
              return (
                <button key={tab.label} className="flex-1 relative flex items-center justify-center" onClick={() => handleTab(tab)}>
                  {content}
                </button>
              );
            }
            return (
              <Link key={tab.label} href={tab.href} className="flex-1 relative flex items-center justify-center">
                {content}
              </Link>
            );
          }

          return (
            <button key={tab.label} className="flex-1 relative flex items-center justify-center" onClick={() => handleTab(tab)}>
              {content}
            </button>
          );
        })}
      </div>
    </nav>
  );
}
