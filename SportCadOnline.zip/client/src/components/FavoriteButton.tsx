import { Heart } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { cn } from "@/lib/utils";
import { useState } from "react";
import { toast } from "sonner";

interface FavoriteButtonProps {
  cardId: number;
  initialFavorited?: boolean;
  className?: string;
  size?: "sm" | "md";
}

export function FavoriteButton({ cardId, initialFavorited = false, className, size = "sm" }: FavoriteButtonProps) {
  const { isAuthenticated } = useAuth();
  const [favorited, setFavorited] = useState(initialFavorited);
  const utils = trpc.useUtils();

  const toggleMutation = trpc.favorites.toggle.useMutation({
    onMutate: () => {
      // Optimistic update
      setFavorited(prev => !prev);
    },
    onSuccess: (data) => {
      setFavorited(data.favorited);
      utils.favorites.myIds.invalidate();
      utils.favorites.myCards.invalidate();
      if (data.favorited) {
        toast.success("Added to favorites ❤️");
      } else {
        toast.info("Removed from favorites");
      }
    },
    onError: () => {
      // Rollback optimistic update
      setFavorited(prev => !prev);
      toast.error("Failed to update favorites");
    },
  });

  const handleClick = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (!isAuthenticated) {
      toast.info("Sign in to save favorites");
      return;
    }
    toggleMutation.mutate({ cardId });
  };

  const iconSize = size === "sm" ? "w-3.5 h-3.5" : "w-5 h-5";
  const btnSize = size === "sm" ? "w-6 h-6" : "w-8 h-8";

  return (
    <button
      onClick={handleClick}
      className={cn(
        "flex items-center justify-center rounded-full transition-all duration-200 z-10",
        btnSize,
        favorited
          ? "bg-red-500/90 text-white shadow-lg shadow-red-500/40 scale-110"
          : "bg-black/50 text-white/60 hover:bg-red-500/80 hover:text-white hover:scale-110",
        className
      )}
      title={favorited ? "Remove from favorites" : "Add to favorites"}
    >
      <Heart className={cn(iconSize, favorited ? "fill-current" : "")} />
    </button>
  );
}

/**
 * Hook to get all favorited card IDs for the current user.
 * Returns a Set for O(1) lookup.
 */
export function useFavoriteIds(): Set<number> {
  const { isAuthenticated } = useAuth();
  const { data } = trpc.favorites.myIds.useQuery(undefined, {
    enabled: isAuthenticated,
    staleTime: 30_000,
  });
  return new Set(data || []);
}
