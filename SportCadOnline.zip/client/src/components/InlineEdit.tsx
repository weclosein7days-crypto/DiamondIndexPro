import { useState, useRef, useEffect, KeyboardEvent } from "react";
import { cn } from "@/lib/utils";

// ─── Grade label map ────────────────────────────────────────────────────────
export const GRADE_LABELS: Record<string, string> = {
  "10": "GEM MINT",
  "9.5": "MINT+",
  "9": "MINT",
  "8.5": "NM-MT+",
  "8": "NM-MT",
  "7.5": "NM+",
  "7": "NM",
  "6.5": "EX-MT+",
  "6": "EX-MT",
  "5.5": "EX+",
  "5": "EX",
  "4.5": "VG-EX+",
  "4": "VG-EX",
  "3.5": "VG+",
  "3": "VG",
  "2": "GOOD",
  "1.5": "FAIR",
  "1": "POOR",
};

// ─── InlineEdit ─────────────────────────────────────────────────────────────
interface InlineEditProps {
  value: string;
  onSave: (newValue: string) => void;
  prefix?: string;
  suffix?: string;
  className?: string;
  inputClassName?: string;
  displayClassName?: string;
  validate?: (v: string) => boolean;
  format?: (v: string) => string;
  type?: "text" | "number";
  placeholder?: string;
}

export function InlineEdit({
  value,
  onSave,
  prefix = "",
  suffix = "",
  className,
  inputClassName,
  displayClassName,
  validate,
  format,
  type = "text",
  placeholder,
}: InlineEditProps) {
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState(value);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (editing) {
      setDraft(value);
      setTimeout(() => inputRef.current?.select(), 0);
    }
  }, [editing, value]);

  const commit = () => {
    const trimmed = draft.trim();
    if (!trimmed) { cancel(); return; }
    if (validate && !validate(trimmed)) { cancel(); return; }
    if (trimmed !== value) onSave(trimmed);
    setEditing(false);
  };

  const cancel = () => {
    setDraft(value);
    setEditing(false);
  };

  const onKey = (e: KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter") commit();
    if (e.key === "Escape") cancel();
  };

  const displayed = format ? format(value) : value;

  if (editing) {
    return (
      <input
        ref={inputRef}
        type={type}
        value={draft}
        onChange={e => setDraft(e.target.value)}
        onBlur={commit}
        onKeyDown={onKey}
        placeholder={placeholder}
        className={cn(
          "w-full bg-[#0a1628] border border-[#C41E3A]/60 rounded px-2 py-0.5 text-xs text-white outline-none focus:border-[#C41E3A] focus:ring-1 focus:ring-[#C41E3A]/40",
          inputClassName
        )}
        style={{ minWidth: 60 }}
      />
    );
  }

  return (
    <span
      className={cn(
        "cursor-pointer group inline-flex items-center gap-0.5 rounded px-1 py-0.5 hover:bg-white/10 transition-colors",
        className
      )}
      title="Click to edit"
      onClick={() => setEditing(true)}
    >
      <span className={cn("text-xs", displayClassName)}>
        {prefix}{displayed}{suffix}
      </span>
      <span className="opacity-0 group-hover:opacity-40 text-[10px] text-white ml-0.5">✎</span>
    </span>
  );
}

// ─── InlineGradeEdit ────────────────────────────────────────────────────────
interface InlineGradeEditProps {
  grade: string | null | undefined;
  gradeLabel?: string | null;
  onSave: (grade: string, label: string) => void;
  className?: string;
}

export function InlineGradeEdit({ grade, gradeLabel, onSave, className }: InlineGradeEditProps) {
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState(grade || "");
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (editing) {
      setDraft(grade || "");
      setTimeout(() => inputRef.current?.select(), 0);
    }
  }, [editing, grade]);

  const commit = () => {
    const trimmed = draft.trim();
    if (!trimmed) { cancel(); return; }
    const num = parseFloat(trimmed);
    if (isNaN(num) || num < 1 || num > 10) { cancel(); return; }
    const normalized = num % 1 === 0 ? num.toFixed(0) : num.toFixed(1);
    const label = GRADE_LABELS[normalized] || `GRADE ${normalized}`;
    onSave(normalized, label);
    setEditing(false);
  };

  const cancel = () => {
    setDraft(grade || "");
    setEditing(false);
  };

  const onKey = (e: KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter") commit();
    if (e.key === "Escape") cancel();
  };

  const displayLabel = gradeLabel || (grade ? GRADE_LABELS[grade] : null);

  if (editing) {
    return (
      <input
        ref={inputRef}
        type="number"
        min="1"
        max="10"
        step="0.5"
        value={draft}
        onChange={e => setDraft(e.target.value)}
        onBlur={commit}
        onKeyDown={onKey}
        placeholder="1–10"
        className={cn(
          "w-16 bg-[#0a1628] border border-[#E8C547]/60 rounded px-2 py-0.5 text-xs text-[#E8C547] outline-none focus:border-[#E8C547] focus:ring-1 focus:ring-[#E8C547]/40",
          className
        )}
      />
    );
  }

  if (!grade) {
    return (
      <span
        className="cursor-pointer text-white/30 text-xs hover:text-white/60 hover:bg-white/10 rounded px-1 py-0.5 transition-colors"
        title="Click to set grade"
        onClick={() => setEditing(true)}
      >
        Raw ✎
      </span>
    );
  }

  return (
    <span
      className={cn(
        "cursor-pointer group inline-flex flex-col items-start rounded px-1 py-0.5 hover:bg-[#E8C547]/10 transition-colors",
        className
      )}
      title="Click to edit grade (all sub-grades will auto-update)"
      onClick={() => setEditing(true)}
    >
      <span className="flex items-center gap-1">
        <span className="text-xs font-bold text-[#E8C547]">{grade}</span>
        <span className="opacity-0 group-hover:opacity-40 text-[10px] text-white">✎</span>
      </span>
      {displayLabel && (
        <span className="text-[9px] text-[#E8C547]/60 leading-none">{displayLabel}</span>
      )}
    </span>
  );
}
