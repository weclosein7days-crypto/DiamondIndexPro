import { useState, useCallback } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useAuth } from "@/_core/hooks/useAuth";
import { toast } from "sonner";
import {
  X, Search, TrendingUp, TrendingDown, Minus, ExternalLink,
  BarChart2, BookmarkPlus, Check, ChevronDown, ChevronUp,
} from "lucide-react";

// ─── tiny inline sparkline ───────────────────────────────────────────────────
function Sparkline({ prices }: { prices: number[] }) {
  if (prices.length < 2) return null;
  const min = Math.min(...prices);
  const max = Math.max(...prices);
  const range = max - min || 1;
  const W = 80, H = 28, pad = 3;
  const pts = prices.map((p, i) => {
    const x = pad + (i / (prices.length - 1)) * (W - pad * 2);
    const y = H - pad - ((p - min) / range) * (H - pad * 2);
    return `${x},${y}`;
  });
  const rising = prices[prices.length - 1] >= prices[0];
  return (
    <svg width={W} height={H} className="shrink-0">
      <polyline points={pts.join(" ")} fill="none"
        stroke={rising ? "#22c55e" : "#ef4444"} strokeWidth="1.5" strokeLinejoin="round" />
      <circle cx={pts[pts.length - 1].split(",")[0]} cy={pts[pts.length - 1].split(",")[1]}
        r="2.5" fill={rising ? "#22c55e" : "#ef4444"} />
    </svg>
  );
}

// ─── Collection Picker Popover ────────────────────────────────────────────────
type SaleRow = { title: string; price: number; soldDate: string | null; condition: string; itemUrl: string | null };
type CollItem = { id: number; cardTitle: string; playerName: string; year: string | null; setName: string | null; frontImageUrl: string | null };

function CollectionPicker({
  sale,
  onClose,
}: {
  sale: SaleRow;
  onClose: () => void;
}) {
  const [search, setSearch] = useState("");
  const [saved, setSaved] = useState<number | null>(null);

  const { data: collection } = trpc.collection.list.useQuery();
  const saveComp = trpc.comps.save.useMutation({
    onSuccess: (_, vars) => {
      setSaved(vars.collectionItemId);
      toast.success("Comp saved to card!");
      setTimeout(onClose, 1200);
    },
    onError: () => toast.error("Failed to save comp"),
  });

  const items: CollItem[] = (collection || []).filter((c: CollItem) => {
    if (!search.trim()) return true;
    const q = search.toLowerCase();
    return (
      c.cardTitle.toLowerCase().includes(q) ||
      c.playerName.toLowerCase().includes(q) ||
      (c.year || "").includes(q) ||
      (c.setName || "").toLowerCase().includes(q)
    );
  });

  return (
    <div className="absolute right-0 top-full mt-1 z-[80] w-72 bg-[#0d1f3c] border border-white/20 rounded-xl shadow-2xl overflow-hidden">
      <div className="px-3 py-2 border-b border-white/10 flex items-center justify-between">
        <span className="text-xs font-semibold text-white/70">Pick a card to attach this comp</span>
        <button onClick={onClose} className="text-white/40 hover:text-white">
          <X className="w-3.5 h-3.5" />
        </button>
      </div>
      <div className="px-3 py-2 border-b border-white/10">
        <Input
          value={search}
          onChange={e => setSearch(e.target.value)}
          placeholder="Filter collection…"
          className="h-7 text-xs bg-white/5 border-white/15 text-white placeholder:text-white/30"
        />
      </div>
      <div className="max-h-52 overflow-y-auto">
        {items.length === 0 && (
          <p className="text-center text-xs text-white/30 py-6">No cards found</p>
        )}
        {items.map((c: CollItem) => (
          <button
            key={c.id}
            disabled={saveComp.isPending || saved === c.id}
            onClick={() =>
              saveComp.mutate({
                collectionItemId: c.id,
                salePrice: sale.price,
                saleDate: sale.soldDate ?? undefined,
                condition: sale.condition,
                platform: "eBay",
                sourceUrl: sale.itemUrl ?? undefined,
                title: sale.title,
              })
            }
            className="w-full flex items-center gap-2.5 px-3 py-2 hover:bg-white/8 transition-colors text-left disabled:opacity-60"
          >
            {c.frontImageUrl ? (
              <img src={c.frontImageUrl} alt="" className="w-7 h-9 object-cover rounded shrink-0" />
            ) : (
              <div className="w-7 h-9 bg-white/10 rounded shrink-0" />
            )}
            <div className="flex-1 min-w-0">
              <p className="text-xs font-medium text-white truncate">{c.playerName}</p>
              <p className="text-[10px] text-white/40 truncate">
                {[c.year, c.setName].filter(Boolean).join(" · ")}
              </p>
            </div>
            {saved === c.id ? (
              <Check className="w-3.5 h-3.5 text-green-400 shrink-0" />
            ) : (
              <BookmarkPlus className="w-3.5 h-3.5 text-white/30 shrink-0" />
            )}
          </button>
        ))}
      </div>
    </div>
  );
}

// ─── Comps Panel (eBay sold) ──────────────────────────────────────────────────
export function CompsPanel({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { user } = useAuth();
  const [query, setQuery] = useState("");
  const [submitted, setSubmitted] = useState("");
  const [pickerRow, setPickerRow] = useState<number | null>(null);

  const { data, isFetching } = trpc.ebay.getSoldComps.useQuery(
    { query: submitted, limit: 12 },
    { enabled: submitted.length >= 2 }
  );

  const handleSearch = useCallback(() => {
    if (query.trim().length >= 2) { setSubmitted(query.trim()); setPickerRow(null); }
  }, [query]);

  if (!open) return null;

  const sales: SaleRow[] = data?.sales || [];
  const prices = sales.map(s => s.price).filter(Boolean);
  const avg = prices.length ? prices.reduce((a, b) => a + b, 0) / prices.length : 0;
  const high = prices.length ? Math.max(...prices) : 0;
  const low = prices.length ? Math.min(...prices) : 0;
  const latest = prices[0] ?? 0;
  const prev = prices[1] ?? latest;
  const change = latest - prev;
  const changePct = prev ? (change / prev) * 100 : 0;

  return (
    <>
      {/* Backdrop */}
      <div className="fixed inset-0 z-[60] bg-black/60 backdrop-blur-sm" onClick={onClose} />

      {/* Drawer */}
      <div className="fixed right-0 top-0 bottom-0 z-[70] w-full max-w-md bg-[#0a1628] border-l border-white/10 shadow-2xl flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-white/10 bg-[#0d1f3c]">
          <div className="flex items-center gap-2">
            <BarChart2 className="w-5 h-5 text-[#c41e3a]" />
            <span className="font-bold text-white text-lg">eBay Comps</span>
            <span className="text-xs text-white/40 font-normal">Recent sold prices</span>
          </div>
          <Button variant="ghost" size="icon" className="text-white/60 hover:text-white h-8 w-8" onClick={onClose}>
            <X className="w-4 h-4" />
          </Button>
        </div>

        {/* Search */}
        <div className="px-5 py-3 border-b border-white/10">
          <div className="flex gap-2">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/40" />
              <Input
                value={query}
                onChange={e => setQuery(e.target.value)}
                onKeyDown={e => e.key === "Enter" && handleSearch()}
                placeholder="e.g. 2003 LeBron James Topps PSA 10"
                className="pl-9 bg-white/5 border-white/15 text-white placeholder:text-white/30 text-sm"
              />
            </div>
            <Button onClick={handleSearch} disabled={isFetching || query.trim().length < 2}
              className="bg-[#c41e3a] hover:bg-[#c41e3a]/90 text-white shrink-0">
              {isFetching ? "..." : "Search"}
            </Button>
          </div>
          <p className="text-xs text-white/30 mt-1.5">Searches eBay's trading card category (category 212)</p>
        </div>

        {/* Results */}
        <div className="flex-1 overflow-y-auto px-5 py-4 space-y-4">
          {!submitted && (
            <div className="text-center py-16 text-white/30">
              <BarChart2 className="w-12 h-12 mx-auto mb-3 opacity-20" />
              <p className="text-sm">Search a card to see recent eBay sales</p>
              <p className="text-xs mt-1">Include grade (PSA 10, BGS 9.5) for best results</p>
            </div>
          )}

          {submitted && isFetching && (
            <div className="space-y-2">
              {Array.from({ length: 6 }).map((_, i) => (
                <div key={i} className="h-12 bg-white/5 rounded-lg animate-pulse" />
              ))}
            </div>
          )}

          {submitted && !isFetching && sales.length === 0 && (
            <div className="text-center py-12 text-white/40 text-sm">
              No recent eBay listings found for "{submitted}".<br />
              <span className="text-xs">Try a broader search term.</span>
            </div>
          )}

          {submitted && !isFetching && sales.length > 0 && (
            <>
              {/* Summary stats */}
              <div className="grid grid-cols-4 gap-2 mb-2">
                {[
                  { label: "Latest", value: `$${latest.toFixed(2)}` },
                  { label: "Avg", value: `$${avg.toFixed(2)}` },
                  { label: "High", value: `$${high.toFixed(2)}` },
                  { label: "Low", value: `$${low.toFixed(2)}` },
                ].map(s => (
                  <div key={s.label} className="bg-white/5 rounded-lg p-2 text-center">
                    <p className="text-[10px] text-white/40 uppercase tracking-wide">{s.label}</p>
                    <p className="text-sm font-bold text-white">{s.value}</p>
                  </div>
                ))}
              </div>

              {/* Trend line */}
              <div className="flex items-center justify-between bg-white/5 rounded-lg px-4 py-2">
                <div className="flex items-center gap-2">
                  {change > 0 ? <TrendingUp className="w-4 h-4 text-green-400" /> :
                   change < 0 ? <TrendingDown className="w-4 h-4 text-red-400" /> :
                   <Minus className="w-4 h-4 text-white/40" />}
                  <span className={`text-sm font-bold ${change > 0 ? "text-green-400" : change < 0 ? "text-red-400" : "text-white/60"}`}>
                    {change >= 0 ? "+" : ""}${change.toFixed(2)} ({changePct >= 0 ? "+" : ""}{changePct.toFixed(1)}%)
                  </span>
                  <span className="text-xs text-white/30">vs prev sale</span>
                </div>
                <Sparkline prices={[...prices].reverse()} />
              </div>

              {/* Sales table */}
              <div className="rounded-lg overflow-visible border border-white/10">
                <table className="w-full text-xs">
                  <thead>
                    <tr className="bg-white/5 text-white/40 uppercase tracking-wide">
                      <th className="text-left px-3 py-2">Card</th>
                      <th className="text-right px-3 py-2">Price</th>
                      <th className="text-right px-3 py-2">Cond.</th>
                      <th className="px-2 py-2 text-right">
                        {user && <span className="text-[9px] text-white/30">Add</span>}
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    {sales.map((sale, i) => (
                      <tr key={i} className={`border-t border-white/5 ${i === 0 ? "bg-white/5" : ""} relative`}>
                        <td className="px-3 py-2 text-white/70 max-w-[140px]">
                          <p className="truncate">{sale.title}</p>
                          {sale.soldDate && (
                            <p className="text-[10px] text-white/30">
                              {new Date(sale.soldDate).toLocaleDateString()}
                            </p>
                          )}
                        </td>
                        <td className="px-3 py-2 text-right font-bold text-green-400 whitespace-nowrap">
                          ${sale.price.toFixed(2)}
                        </td>
                        <td className="px-3 py-2 text-right text-white/50 text-[10px]">{sale.condition}</td>
                        <td className="px-2 py-2 text-right">
                          <div className="flex items-center justify-end gap-1">
                            {sale.itemUrl && (
                              <a href={sale.itemUrl} target="_blank" rel="noopener noreferrer"
                                className="text-white/30 hover:text-white/70">
                                <ExternalLink className="w-3 h-3" />
                              </a>
                            )}
                            {user && (
                              <div className="relative">
                                <button
                                  onClick={() => setPickerRow(pickerRow === i ? null : i)}
                                  title="Add this comp to a card in my collection"
                                  className={`flex items-center gap-0.5 px-1.5 py-1 rounded text-[10px] font-medium transition-colors ${
                                    pickerRow === i
                                      ? "bg-[#c41e3a] text-white"
                                      : "bg-white/10 text-white/60 hover:bg-white/20 hover:text-white"
                                  }`}
                                >
                                  <BookmarkPlus className="w-3 h-3" />
                                  {pickerRow === i
                                    ? <ChevronUp className="w-2.5 h-2.5" />
                                    : <ChevronDown className="w-2.5 h-2.5" />}
                                </button>
                                {pickerRow === i && (
                                  <CollectionPicker
                                    sale={sale}
                                    onClose={() => setPickerRow(null)}
                                  />
                                )}
                              </div>
                            )}
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {user && (
                <p className="text-[10px] text-white/20 text-center">
                  Click <BookmarkPlus className="w-2.5 h-2.5 inline" /> on any row to save it as a price reference on a card in your collection.
                </p>
              )}
              <p className="text-[10px] text-white/20 text-center">
                Data from eBay Browse API · Sports Cards category · Sorted by recency
              </p>
            </>
          )}
        </div>
      </div>
    </>
  );
}

// ─── Values Panel (SportsCardsPro graded comps) ───────────────────────────────
export function ValuesPanel({ open, onClose }: { open: boolean; onClose: () => void }) {
  const [query, setQuery] = useState("");
  const [submitted, setSubmitted] = useState("");
  const [selectedId, setSelectedId] = useState<string | null>(null);

  const { data: results, isFetching: searching } = trpc.cardSearch.search.useQuery(
    { query: submitted },
    { enabled: submitted.length >= 2 }
  );

  // Find the selected card's name from search results for fallback display
  const selectedCard = (results as { id: string; name: string; consoleName: string; imageUrl: string | null }[] | undefined)?.find(r => r.id === selectedId);

  const { data: comps, isFetching: loadingComps, isError: compsError } = trpc.cardSearch.getComps.useQuery(
    { id: selectedId!, name: selectedCard?.name, consoleName: selectedCard?.consoleName },
    { enabled: !!selectedId, retry: 1, staleTime: 5 * 60 * 1000 }
  );

  const handleSearch = useCallback(() => {
    if (query.trim().length >= 2) { setSubmitted(query.trim()); setSelectedId(null); }
  }, [query]);

  if (!open) return null;

  return (
    <>
      <div className="fixed inset-0 z-[60] bg-black/60 backdrop-blur-sm" onClick={onClose} />
      <div className="fixed right-0 top-0 bottom-0 z-[70] w-full max-w-md bg-[#0a1628] border-l border-white/10 shadow-2xl flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-white/10 bg-[#0d1f3c]">
          <div className="flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-yellow-400" />
            <span className="font-bold text-white text-lg">Card Values</span>
            <span className="text-xs text-white/40 font-normal">PSA · BGS · SCG</span>
          </div>
          <Button variant="ghost" size="icon" className="text-white/60 hover:text-white h-8 w-8" onClick={onClose}>
            <X className="w-4 h-4" />
          </Button>
        </div>

        {/* Search */}
        <div className="px-5 py-3 border-b border-white/10">
          <div className="flex gap-2">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/40" />
              <Input
                value={query}
                onChange={e => setQuery(e.target.value)}
                onKeyDown={e => e.key === "Enter" && handleSearch()}
                placeholder="e.g. 2003 LeBron James Topps"
                className="pl-9 bg-white/5 border-white/15 text-white placeholder:text-white/30 text-sm"
              />
            </div>
            <Button onClick={handleSearch} disabled={searching || query.trim().length < 2}
              className="bg-yellow-500 hover:bg-yellow-400 text-black font-bold shrink-0">
              {searching ? "..." : "Search"}
            </Button>
          </div>
          <p className="text-xs text-white/30 mt-1.5">Powered by SportsCardsPro · PSA, BGS, SGC grades</p>
        </div>

        {/* Results */}
        <div className="flex-1 overflow-y-auto px-5 py-4 space-y-3">
          {!submitted && (
            <div className="text-center py-16 text-white/30">
              <TrendingUp className="w-12 h-12 mx-auto mb-3 opacity-20" />
              <p className="text-sm">Search a card to see graded values</p>
            </div>
          )}

          {submitted && searching && (
            <div className="space-y-2">
              {Array.from({ length: 4 }).map((_, i) => (
                <div key={i} className="h-14 bg-white/5 rounded-lg animate-pulse" />
              ))}
            </div>
          )}

          {submitted && !searching && (!results || results.length === 0) && (
            <div className="text-center py-12 text-white/40 text-sm">
              No results for "{submitted}".<br />
              <span className="text-xs">SportsCardsPro API key may be required.</span>
            </div>
          )}

          {results && results.length > 0 && !selectedId && (
            <div className="space-y-2">
              <p className="text-xs text-white/40 uppercase tracking-wide mb-2">Select a card to see values</p>
              {(results as { id: string; name: string; consoleName: string; imageUrl: string | null }[]).map(r => (
                <button key={r.id} onClick={() => setSelectedId(r.id)}
                  className="w-full flex items-center gap-3 bg-white/5 hover:bg-white/10 rounded-lg px-3 py-2.5 text-left transition-colors">
                  {r.imageUrl && <img src={r.imageUrl} alt="" className="w-8 h-10 object-cover rounded shrink-0" />}
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-white truncate">{r.name}</p>
                    <p className="text-xs text-white/40 truncate">{r.consoleName}</p>
                  </div>
                </button>
              ))}
            </div>
          )}

          {selectedId && (
            <>
              <button onClick={() => setSelectedId(null)} className="text-xs text-white/40 hover:text-white flex items-center gap-1 mb-3">
                ← Back to results
              </button>
              {/* Card name header — always shown once a card is selected */}
              {selectedCard && (
                <div className="bg-white/5 rounded-lg px-3 py-2 mb-3">
                  <p className="text-sm font-bold text-white">{selectedCard.name}</p>
                  <p className="text-xs text-white/40">{selectedCard.consoleName}</p>
                </div>
              )}
              {loadingComps && (
                <div className="space-y-2">
                  {Array.from({ length: 3 }).map((_, i) => (
                    <div key={i} className="h-10 bg-white/5 rounded-lg animate-pulse" />
                  ))}
                </div>
              )}
              {/* Error state */}
              {!loadingComps && compsError && (
                <div className="text-center py-10 text-white/40">
                  <TrendingUp className="w-10 h-10 mx-auto mb-3 opacity-20" />
                  <p className="text-sm">Could not load pricing data.</p>
                  <p className="text-xs mt-1">SportsCardsPro lookup failed — try eBay Comps for recent sold prices.</p>
                  {selectedCard && (
                    <a
                      href={`https://www.ebay.com/sch/i.html?_nkw=${encodeURIComponent(selectedCard.name + " " + selectedCard.consoleName)}&LH_Sold=1&LH_Complete=1`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1 mt-3 text-xs text-yellow-400 hover:text-yellow-300 underline"
                    >
                      <ExternalLink className="w-3 h-3" /> Search eBay sold listings
                    </a>
                  )}
                </div>
              )}
              {/* No pricing data state */}
              {!loadingComps && !compsError && comps && comps.psaGrades.length === 0 && comps.bgsGrades.length === 0 && comps.scgAvg == null && (
                <div className="text-center py-10 text-white/40">
                  <TrendingUp className="w-10 h-10 mx-auto mb-3 opacity-20" />
                  <p className="text-sm">No grade pricing data available yet.</p>
                  <p className="text-xs mt-1">SportsCardsPro hasn't indexed prices for this card.</p>
                  {selectedCard && (
                    <a
                      href={`https://www.ebay.com/sch/i.html?_nkw=${encodeURIComponent(selectedCard.name + " " + selectedCard.consoleName)}&LH_Sold=1&LH_Complete=1`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1 mt-3 text-xs text-yellow-400 hover:text-yellow-300 underline"
                    >
                      <ExternalLink className="w-3 h-3" /> Search eBay sold listings
                    </a>
                  )}
                </div>
              )}
              {/* No data loaded yet (edge case: not loading, no error, no data) */}
              {!loadingComps && !compsError && !comps && (
                <div className="text-center py-10 text-white/40">
                  <TrendingUp className="w-10 h-10 mx-auto mb-3 opacity-20" />
                  <p className="text-sm">Loading pricing data...</p>
                </div>
              )}
              {comps && (comps.psaGrades.length > 0 || comps.bgsGrades.length > 0 || comps.scgAvg != null) && (
                <div className="space-y-3">
                  {/* Source badge */}
                  <div className="flex items-center justify-between">
                    <div className="bg-white/5 rounded-lg px-3 py-2 flex-1 mr-2">
                      <p className="text-sm font-bold text-white">{comps.name}</p>
                      <p className="text-xs text-white/40">{comps.set}</p>
                    </div>
                    <span className="text-[10px] text-white/30 bg-white/5 rounded px-2 py-1 shrink-0">eBay live</span>
                  </div>
                  {/* PSA grades */}
                  {comps.psaGrades && comps.psaGrades.length > 0 && (
                    <div className="bg-white/5 rounded-lg overflow-hidden">
                      <div className="px-3 py-1.5 bg-blue-900/40 text-xs font-bold text-blue-300 uppercase tracking-wide flex items-center justify-between">
                        <span>PSA</span>
                        <span className="text-[10px] text-blue-300/50 font-normal normal-case">avg · min · max</span>
                      </div>
                      <table className="w-full text-xs">
                        <tbody>
                          {(comps.psaGrades as Array<{ grade: string; avg: number; min: number; max: number; count: number }>).map(g => (
                            <tr key={g.grade} className="border-t border-white/5">
                              <td className="px-3 py-1.5 text-white/60">{g.grade}</td>
                              <td className="px-3 py-1.5 text-right font-bold text-green-400">${g.avg.toFixed(2)}</td>
                              <td className="px-2 py-1.5 text-right text-white/30 text-[10px]">${g.min.toFixed(0)}–${g.max.toFixed(0)}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  )}
                  {/* BGS grades */}
                  {comps.bgsGrades && comps.bgsGrades.length > 0 && (
                    <div className="bg-white/5 rounded-lg overflow-hidden">
                      <div className="px-3 py-1.5 bg-yellow-900/40 text-xs font-bold text-yellow-300 uppercase tracking-wide flex items-center justify-between">
                        <span>BGS / Beckett</span>
                        <span className="text-[10px] text-yellow-300/50 font-normal normal-case">avg · min · max</span>
                      </div>
                      <table className="w-full text-xs">
                        <tbody>
                          {(comps.bgsGrades as Array<{ grade: string; avg: number; min: number; max: number; count: number }>).map(g => (
                            <tr key={g.grade} className="border-t border-white/5">
                              <td className="px-3 py-1.5 text-white/60">{g.grade}</td>
                              <td className="px-3 py-1.5 text-right font-bold text-green-400">${g.avg.toFixed(2)}</td>
                              <td className="px-2 py-1.5 text-right text-white/30 text-[10px]">${g.min.toFixed(0)}–${g.max.toFixed(0)}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  )}
                  {/* SGC grades */}
                  {comps.sgcGrades && (comps.sgcGrades as any[]).length > 0 && (
                    <div className="bg-white/5 rounded-lg overflow-hidden">
                      <div className="px-3 py-1.5 bg-purple-900/40 text-xs font-bold text-purple-300 uppercase tracking-wide">SGC</div>
                      <table className="w-full text-xs">
                        <tbody>
                          {(comps.sgcGrades as Array<{ grade: string; avg: number; min: number; max: number }>).map(g => (
                            <tr key={g.grade} className="border-t border-white/5">
                              <td className="px-3 py-1.5 text-white/60">{g.grade}</td>
                              <td className="px-3 py-1.5 text-right font-bold text-green-400">${g.avg.toFixed(2)}</td>
                              <td className="px-2 py-1.5 text-right text-white/30 text-[10px]">${g.min.toFixed(0)}–${g.max.toFixed(0)}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  )}
                  {/* Ungraded */}
                  {(comps as any).ungradedPrice != null && (
                    <div className="bg-white/5 rounded-lg px-3 py-2 flex items-center justify-between">
                      <span className="text-xs text-white/50">Raw / Ungraded</span>
                      <span className="text-sm font-bold text-white/70">${((comps as any).ungradedPrice as number).toFixed(2)}</span>
                    </div>
                  )}
                  {/* SCG estimated value */}
                  {comps.scgAvg != null && (
                    <div className="bg-[#c41e3a]/10 border border-[#c41e3a]/30 rounded-lg px-4 py-3 flex items-center justify-between">
                      <div>
                        <p className="text-xs font-bold text-[#c41e3a] uppercase tracking-wide">SCG Estimated Value</p>
                        <p className="text-[10px] text-white/30">Best grade avg + 10% premium</p>
                      </div>
                      <p className="text-xl font-black text-white">${comps.scgAvg.toFixed(2)}</p>
                    </div>
                  )}
                  {/* eBay deep link */}
                  {selectedCard && (
                    <a
                      href={`https://www.ebay.com/sch/i.html?_nkw=${encodeURIComponent(selectedCard.name + " " + selectedCard.consoleName)}&LH_Sold=1&LH_Complete=1`}
                      target="_blank" rel="noopener noreferrer"
                      className="inline-flex items-center gap-1 text-xs text-yellow-400 hover:text-yellow-300 underline"
                    >
                      <ExternalLink className="w-3 h-3" /> View eBay sold listings
                    </a>
                  )}
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </>
  );
}
