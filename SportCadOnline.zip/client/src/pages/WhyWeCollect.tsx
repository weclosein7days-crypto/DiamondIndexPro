import { Link } from "wouter";
import { ChevronLeft, Heart, Share2, ExternalLink } from "lucide-react";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import Footer from "@/components/Footer";

export default function WhyWeCollect() {
  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: "This is Why We Collect — Support Matt's Family",
        text: "A heartfelt story about why sports cards matter. Please take a moment to read and share.",
        url: window.location.href,
      }).catch(() => {});
    } else {
      navigator.clipboard.writeText(window.location.href).then(() => {
        toast.success("Link copied to clipboard — please share it!");
      });
    }
  };

  return (
    <div className="min-h-screen bg-[#0a1628] text-white flex flex-col">
      {/* Back nav */}
      <div className="container py-4">
        <Link href="/" className="inline-flex items-center gap-1.5 text-white/50 hover:text-white text-sm transition-colors">
          <ChevronLeft className="w-4 h-4" />
          Back to Home
        </Link>
      </div>

      {/* Hero banner */}
      <section className="bg-gradient-to-b from-[#0d1f3c] to-[#0a1628] border-b border-white/10 pb-12 pt-4">
        <div className="container max-w-3xl mx-auto text-center">
          {/* Heart icon */}
          <div className="flex justify-center mb-5">
            <span className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-red-600/20 border-2 border-red-500/50 shadow-[0_0_40px_rgba(239,68,68,0.3)]">
              <Heart className="w-8 h-8 text-red-400 fill-red-400" />
            </span>
          </div>

          <h1
            className="text-4xl md:text-5xl font-black text-white mb-3 leading-tight"
            style={{ fontFamily: "Oswald, sans-serif" }}
          >
            This is Why We Collect
          </h1>
          <p className="text-white/50 text-sm italic mb-6">
            Based on a True Story by{" "}
            <a
              href="https://www.youtube.com/@ChasingCardboard"
              target="_blank"
              rel="noopener noreferrer"
              className="text-white/70 hover:text-white underline underline-offset-2 transition-colors"
            >
              Chasing Cardboard
            </a>
          </p>

          {/* Divider */}
          <div className="flex items-center gap-4 mb-8">
            <div className="flex-1 h-px bg-white/10" />
            <span className="text-red-400 text-lg">♥</span>
            <div className="flex-1 h-px bg-white/10" />
          </div>

          {/* Story content */}
          <div className="text-left space-y-5 text-white/80 text-base leading-relaxed">
            <h2
              className="text-2xl font-black text-white text-center"
              style={{ fontFamily: "Oswald, sans-serif" }}
            >
              Support Matt's Family
            </h2>

            <p className="text-center text-white/60 font-medium text-lg">
              Please Take a Moment — This Story Matters
            </p>

            <p>
              Watch this powerful video to understand why so many people are coming together right now.
            </p>

            {/* Video embed */}
            <div className="rounded-xl overflow-hidden border border-white/10 shadow-[0_0_40px_rgba(0,0,0,0.5)] my-6">
              <div className="relative w-full" style={{ paddingBottom: "56.25%" }}>
                <iframe
                  className="absolute inset-0 w-full h-full"
                  src="https://www.youtube.com/embed/95gf3XloGh4?rel=0"
                  title="Lift Matt's Family in Prayers &amp; Support — Chasing Cardboard"
                  frameBorder="0"
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  allowFullScreen
                />
              </div>
            </div>

            <p>
              A heartfelt thank you to{" "}
              <a
                href="https://www.youtube.com/@ChasingCardboard"
                target="_blank"
                rel="noopener noreferrer"
                className="text-red-400 hover:text-red-300 underline underline-offset-2 transition-colors font-semibold"
              >
                Chasing Cardboard
              </a>{" "}
              for helping bring attention to a story that truly deserves to be heard.
            </p>

            <p>
              Matt's family is facing an incredibly difficult time, and they need support from people like you.
            </p>

            <p>
              Every act of kindness — whether it's a donation, a share, or simply keeping them in your thoughts and prayers — makes a real difference.
            </p>
          </div>

          {/* CTA buttons */}
          <div className="mt-10 flex flex-col items-center gap-4">
            <a
              href="https://www.gofundme.com/f/lift-matts-family-in-prayers-support"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2.5 bg-red-600 hover:bg-red-500 text-white font-black text-lg px-10 py-4 rounded-full shadow-[0_0_30px_rgba(239,68,68,0.4)] hover:shadow-[0_0_50px_rgba(239,68,68,0.6)] transition-all duration-300"
              style={{ fontFamily: "Oswald, sans-serif" }}
            >
              <Heart className="w-5 h-5 fill-white" />
              Donate Now — Help Matt's Family
              <ExternalLink className="w-4 h-4 opacity-70" />
            </a>

            <p className="text-white/40 text-sm">
              Can't donate right now?{" "}
              <button
                onClick={handleShare}
                className="text-white/60 hover:text-white underline underline-offset-2 transition-colors inline-flex items-center gap-1"
              >
                <Share2 className="w-3.5 h-3.5" />
                Sharing this page
              </button>{" "}
              can help reach someone who can.
            </p>
          </div>

          {/* Divider */}
          <div className="flex items-center gap-4 mt-12">
            <div className="flex-1 h-px bg-white/10" />
            <span className="text-red-400 text-lg">♥</span>
            <div className="flex-1 h-px bg-white/10" />
          </div>

          {/* Attribution */}
          <p className="mt-6 text-white/30 text-xs">
            SportCardsOnline.com proudly supports the sports card community and the families within it.
          </p>
        </div>
      </section>

      <Footer />
    </div>
  );
}
