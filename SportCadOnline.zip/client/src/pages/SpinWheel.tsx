import { useState, useRef, useEffect } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { ArrowLeft, Sparkles, Trophy, Zap } from "lucide-react";
import { useSFX } from "@/hooks/useSFX";

// Prize wheel segments
const SEGMENTS = [
  { label: "5 Credits", value: 5, color: "#1a472a", textColor: "#fff", type: "credits" },
  { label: "10 Credits", value: 10, color: "#c41e3a", textColor: "#fff", type: "credits" },
  { label: "25 Credits", value: 25, color: "#1a3a6b", textColor: "#fff", type: "credits" },
  { label: "Try Again", value: 0, color: "#2a2a2a", textColor: "#aaa", type: "none" },
  { label: "50 Credits", value: 50, color: "#7b2d8b", textColor: "#fff", type: "credits" },
  { label: "5 Credits", value: 5, color: "#1a472a", textColor: "#fff", type: "credits" },
  { label: "100 Credits", value: 100, color: "#b8860b", textColor: "#fff", type: "credits" },
  { label: "Try Again", value: 0, color: "#2a2a2a", textColor: "#aaa", type: "none" },
  { label: "15 Credits", value: 15, color: "#c41e3a", textColor: "#fff", type: "credits" },
  { label: "JACKPOT! 🏆", value: 500, color: "#ffd700", textColor: "#000", type: "jackpot" },
  { label: "5 Credits", value: 5, color: "#1a472a", textColor: "#fff", type: "credits" },
  { label: "Try Again", value: 0, color: "#2a2a2a", textColor: "#aaa", type: "none" },
];

const NUM_SEGMENTS = SEGMENTS.length;
const SEGMENT_ANGLE = 360 / NUM_SEGMENTS;

export default function SpinWheel() {
  const { isAuthenticated } = useAuth();
  const [spinning, setSpinning] = useState(false);
  const [rotation, setRotation] = useState(0);
  const [result, setResult] = useState<typeof SEGMENTS[0] | null>(null);
  const [hasSpunToday, setHasSpunToday] = useState(false);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const spinResult = trpc.game.freeSpin.useMutation();
  const { data: me } = trpc.auth.me.useQuery(undefined, { enabled: isAuthenticated });
  const { data: creditAccount, refetch: refetchCredits } = trpc.credits.myAccount.useQuery(undefined, { enabled: isAuthenticated });
  const sfx = useSFX();
  const tickTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Check if user has spun today (stored in localStorage)
  useEffect(() => {
    const lastSpin = localStorage.getItem("sco_last_spin");
    if (lastSpin) {
      const lastDate = new Date(lastSpin).toDateString();
      const today = new Date().toDateString();
      if (lastDate === today) setHasSpunToday(true);
    }
  }, []);

  // Draw the wheel
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const cx = canvas.width / 2;
    const cy = canvas.height / 2;
    const radius = Math.min(cx, cy) - 10;

    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Draw segments
    SEGMENTS.forEach((seg, i) => {
      const startAngle = ((i * SEGMENT_ANGLE - 90) * Math.PI) / 180;
      const endAngle = (((i + 1) * SEGMENT_ANGLE - 90) * Math.PI) / 180;

      ctx.beginPath();
      ctx.moveTo(cx, cy);
      ctx.arc(cx, cy, radius, startAngle, endAngle);
      ctx.closePath();
      ctx.fillStyle = seg.color;
      ctx.fill();
      ctx.strokeStyle = "#fff";
      ctx.lineWidth = 2;
      ctx.stroke();

      // Draw text
      ctx.save();
      ctx.translate(cx, cy);
      ctx.rotate(startAngle + (SEGMENT_ANGLE * Math.PI) / 360);
      ctx.textAlign = "right";
      ctx.fillStyle = seg.textColor;
      ctx.font = seg.type === "jackpot" ? "bold 11px Oswald, sans-serif" : "10px Oswald, sans-serif";
      ctx.fillText(seg.label, radius - 8, 4);
      ctx.restore();
    });

    // Center circle
    ctx.beginPath();
    ctx.arc(cx, cy, 20, 0, 2 * Math.PI);
    ctx.fillStyle = "#0a1628";
    ctx.fill();
    ctx.strokeStyle = "#c41e3a";
    ctx.lineWidth = 3;
    ctx.stroke();

    // SCO text in center
    ctx.fillStyle = "#c41e3a";
    ctx.font = "bold 8px Oswald, sans-serif";
    ctx.textAlign = "center";
    ctx.fillText("SCO", cx, cy + 3);
  }, []);

  const handleSpin = async () => {
    if (spinning || hasSpunToday) return;
    if (!isAuthenticated) {
      toast.error("Sign in to spin the wheel!");
      return;
    }

    setSpinning(true);
    setResult(null);

    // Play spin start whoosh
    sfx.spinStart();

    // Schedule decelerating tick sounds (fast → slow over 4 seconds)
    let tickCount = 0;
    const scheduleTick = (delay: number) => {
      tickTimerRef.current = setTimeout(() => {
        sfx.tick();
        tickCount++;
        // Gradually slow: each tick adds ~10ms to the interval, capped at 500ms
        const nextDelay = Math.min(delay + 10, 500);
        if (tickCount < 50) scheduleTick(nextDelay);
      }, delay);
    };
    scheduleTick(80);

    try {
      const res = await spinResult.mutateAsync();
      const segmentIndex = res.segmentIndex;
      
      // Calculate rotation: spin 5-8 full rotations + land on segment
      const extraSpins = (5 + Math.floor(Math.random() * 3)) * 360;
      const segmentOffset = segmentIndex * SEGMENT_ANGLE;
      const targetRotation = rotation + extraSpins + (360 - segmentOffset);
      
      setRotation(targetRotation);
      
      // Wait for animation to complete (4 seconds)
      await new Promise(r => setTimeout(r, 4500));

      // Stop ticking and play landing sound
      if (tickTimerRef.current) clearTimeout(tickTimerRef.current);
      sfx.spinStop();
      
      const segment = SEGMENTS[segmentIndex];
      setResult(segment);
      setHasSpunToday(true);
      localStorage.setItem("sco_last_spin", new Date().toISOString());
      
      // Play result sound after a short pause
      setTimeout(() => {
        if (segment.type === "jackpot") {
          sfx.cheer();
          toast.success(`🏆 JACKPOT! You won ${segment.value} credits!`, { duration: 6000 });
        } else if (segment.type === "credits") {
          sfx.creditEarned();
          toast.success(`🎉 You won ${segment.value} credits!`);
        } else {
          sfx.groan();
          toast.info("Better luck next time! Come back tomorrow for another free spin.");
        }
      }, 300);

      refetchCredits();
    } catch (e: any) {
      if (tickTimerRef.current) clearTimeout(tickTimerRef.current);
      toast.error(e.message || "Failed to spin");
    } finally {
      setSpinning(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#0a1628] to-[#050d1a] py-8">
      <div className="container max-w-2xl">
        <Link href="/game-room">
          <Button variant="ghost" className="mb-6 gap-2 text-white/70 hover:text-white">
            <ArrowLeft className="w-4 h-4" />← Game Room
          </Button>
        </Link>

        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-3 bg-red-600/90 border-2 border-red-400 rounded-2xl px-5 py-2 mb-4 shadow-[0_0_20px_rgba(239,68,68,0.5)] animate-pulse">
            <span className="text-white text-base">🎰</span>
            <div>
              <div className="text-white font-black text-sm uppercase tracking-widest">FREE PLAY 4 NOW</div>
              <div className="text-red-200 text-[10px] font-bold">⚠️ No Prizes — Free play mode active</div>
            </div>
            <span className="text-white text-base">🎰</span>
          </div>
          <h1 className="text-4xl font-black text-white mb-2" style={{ fontFamily: "Oswald, sans-serif" }}>
            🎡 Spin the Wheel
          </h1>
          <p className="text-white/60">One free spin per day. Win credits or the JACKPOT!</p>
        </div>

        {/* Wheel container */}
        <div className="relative flex items-center justify-center mb-8">
          {/* Pointer */}
          <div className="absolute top-0 left-1/2 -translate-x-1/2 z-10 -mt-1">
            <div className="w-0 h-0 border-l-[12px] border-r-[12px] border-t-[24px] border-l-transparent border-r-transparent border-t-[#c41e3a]" />
          </div>

          {/* Spinning canvas */}
          <div
            style={{
              transform: `rotate(${rotation}deg)`,
              transition: spinning ? "transform 4.5s cubic-bezier(0.17, 0.67, 0.12, 0.99)" : "none",
            }}
          >
            <canvas ref={canvasRef} width={320} height={320} className="rounded-full shadow-[0_0_40px_rgba(196,30,58,0.4)]" />
          </div>
        </div>

        {/* Result */}
        {result && (
          <div className={`text-center mb-6 p-4 rounded-xl border ${
            result.type === "jackpot" 
              ? "bg-yellow-500/20 border-yellow-500/50 text-yellow-400" 
              : result.type === "credits"
              ? "bg-green-500/20 border-green-500/50 text-green-400"
              : "bg-white/5 border-white/10 text-white/50"
          }`}>
            {result.type === "jackpot" && <Trophy className="w-8 h-8 mx-auto mb-2 text-yellow-400" />}
            {result.type === "credits" && <Zap className="w-8 h-8 mx-auto mb-2 text-green-400" />}
            <p className="text-2xl font-black">{result.label}</p>
            {result.type !== "none" && <p className="text-sm mt-1">Added to your balance!</p>}
          </div>
        )}

        {/* Spin button */}
        <div className="text-center">
          {!isAuthenticated ? (
            <Button size="lg" className="bg-[#c41e3a] hover:bg-[#c41e3a]/90 text-white font-bold px-10" asChild>
              <a href="/api/oauth/login">Sign In to Spin Free</a>
            </Button>
          ) : hasSpunToday && !spinning ? (
            <div>
              <Button size="lg" disabled className="bg-white/10 text-white/40 font-bold px-10 cursor-not-allowed">
                Come Back Tomorrow
              </Button>
              <p className="text-white/40 text-sm mt-2">You've used your free spin for today</p>
            </div>
          ) : (
            <Button
              size="lg"
              className="bg-gradient-to-r from-[#c41e3a] to-[#8b0000] hover:from-[#c41e3a]/90 hover:to-[#8b0000]/90 text-white font-black px-12 text-lg shadow-[0_0_20px_rgba(196,30,58,0.5)]"
              onClick={handleSpin}
              disabled={spinning}
              style={{ fontFamily: "Oswald, sans-serif" }}
            >
              {spinning ? (
                <span className="flex items-center gap-2">
                  <Sparkles className="w-5 h-5 animate-spin" /> Spinning...
                </span>
              ) : (
                "🎡 SPIN FREE"
              )}
            </Button>
          )}
        </div>

        {/* Balance */}
        {isAuthenticated && me && (
          <p className="text-center text-white/40 text-sm mt-4">
            Your balance: <span className="text-yellow-400 font-bold">{creditAccount?.credits ?? 0} credits</span>
          </p>
        )}

        {/* Info */}
        <div className="mt-8 text-center text-white/30 text-xs space-y-1">
          <p>One free spin per day per account.</p>
          <p>Credits are virtual currency with no cash value.</p>
        </div>
      </div>
    </div>
  );
}
