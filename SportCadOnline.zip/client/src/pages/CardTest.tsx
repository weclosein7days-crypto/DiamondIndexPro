/**
 * CardTest — Full-size slab preview with options panel.
 */
import { useState } from "react";
import { SlabFrame } from "@/components/SlabFrame";

const CARD_IMAGE = "https://d2xsxph8kpxj0f.cloudfront.net/310519663482618714/HBSXFxHmEnEJMgVvzKnhpZ/house-cards/caitlin-clark-front-65b1e4801e60.jpg";

const LABEL_BGS = [
  { value: "white-silk", label: "White Silk" },
  { value: "black-silk", label: "Black Silk" },
  { value: "red-silk",   label: "Red Silk"   },
];

const BORDERS = [
  { value: "red",    label: "Red",    hex: "#c41e3a" },
  { value: "blue",   label: "Blue",   hex: "#1d4ed8" },
  { value: "white",  label: "White",  hex: "#ffffff" },
  { value: "orange", label: "Orange", hex: "#f97316" },
  { value: "black",  label: "Black",  hex: "#333333" },
];

export default function CardTest() {
  const [bg, setBg] = useState("white-silk");
  const [border, setBorder] = useState("red");

  return (
    <div style={{
      background: "#0d1a2e",
      minHeight: "100vh",
      display: "flex",
      alignItems: "stretch",
      padding: 0,
      margin: 0,
    }}>

      {/* LEFT — giant card taking up most of the screen */}
      <div style={{
        flex: "1 1 0",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        padding: "60px 40px",
        background: "#0a1525",
      }}>
        <div style={{ width: "min(700px, 75vw)", aspectRatio: "2/3" }}>
          <SlabFrame
            imageUrl={CARD_IMAGE}
            altText="Caitlin Clark"
            labelBg={bg}
            labelBorder={border}
            labelMode="with_label"
            grade="10"
            gradeLabel="GEM MINT"
            playerName="Caitlin Clark"
            setName="Panini Chronicled"
            year="2025"
            cardNumber="55"
            certNumber="CC2025001"
            cardId={13}
          />
        </div>
      </div>

      {/* RIGHT — narrow options panel */}
      <div style={{
        width: 260,
        flexShrink: 0,
        background: "#111c2e",
        borderLeft: "1px solid #1e3050",
        display: "flex",
        flexDirection: "column",
        gap: 32,
        padding: "60px 24px",
      }}>

        {/* Label Background */}
        <div>
          <div style={{ color: "#aaa", fontSize: 11, letterSpacing: 2, textTransform: "uppercase", marginBottom: 12 }}>Label Background</div>
          <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
            {LABEL_BGS.map(opt => (
              <button
                key={opt.value}
                onClick={() => setBg(opt.value)}
                style={{
                  padding: "10px 16px",
                  borderRadius: 6,
                  border: bg === opt.value ? "2px solid #f97316" : "2px solid #334",
                  background: bg === opt.value ? "rgba(249,115,22,0.15)" : "rgba(255,255,255,0.05)",
                  color: bg === opt.value ? "#f97316" : "#ccc",
                  cursor: "pointer",
                  fontSize: 13,
                  fontWeight: bg === opt.value ? 700 : 400,
                  textAlign: "left",
                  transition: "all 0.15s",
                }}
              >
                {opt.label} {bg === opt.value ? "✓" : ""}
              </button>
            ))}
          </div>
        </div>

        {/* Border Color */}
        <div>
          <div style={{ color: "#aaa", fontSize: 11, letterSpacing: 2, textTransform: "uppercase", marginBottom: 12 }}>Border Color</div>
          <div style={{ display: "flex", flexWrap: "wrap", gap: 10 }}>
            {BORDERS.map(opt => (
              <button
                key={opt.value}
                onClick={() => setBorder(opt.value)}
                title={opt.label}
                style={{
                  width: 40,
                  height: 40,
                  borderRadius: "50%",
                  border: border === opt.value ? "3px solid #f97316" : "3px solid transparent",
                  background: opt.hex,
                  cursor: "pointer",
                  outline: border === opt.value ? "2px solid #f97316" : "none",
                  outlineOffset: 2,
                  transition: "all 0.15s",
                }}
              />
            ))}
          </div>
          <div style={{ color: "#888", fontSize: 12, marginTop: 10 }}>
            Selected: <span style={{ color: "#fff", fontWeight: 600 }}>{BORDERS.find(b => b.value === border)?.label}</span>
          </div>
        </div>

        {/* Summary */}
        <div style={{ borderTop: "1px solid #223", paddingTop: 20 }}>
          <div style={{ color: "#666", fontSize: 11, letterSpacing: 1, textTransform: "uppercase", marginBottom: 8 }}>Current Selection</div>
          <div style={{ color: "#fff", fontSize: 13 }}>Label: <span style={{ color: "#f97316" }}>{LABEL_BGS.find(b => b.value === bg)?.label}</span></div>
          <div style={{ color: "#fff", fontSize: 13, marginTop: 4 }}>Border: <span style={{ color: "#f97316" }}>{BORDERS.find(b => b.value === border)?.label}</span></div>
        </div>
      </div>
    </div>
  );
}
