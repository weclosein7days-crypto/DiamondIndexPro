import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { toast } from "sonner";
import {
  Copy, Share2, Twitter, Facebook, MessageCircle, Gift, Users, DollarSign,
  TrendingUp, CheckCircle2, Star, Zap, Crown, Shield, ChevronRight, Link2
} from "lucide-react";
import { getLoginUrl } from "@/const";

// Flat credit rewards — no plan required
const TIER1_CREDITS = 20;
const TIER2_CREDITS = 10;

export default function Referral() {
  const { user, isAuthenticated } = useAuth();
  const [copied, setCopied] = useState(false);

  const affiliateQuery = trpc.affiliate.myAffiliate.useQuery(undefined, {
    enabled: isAuthenticated,
  });
  const joinMutation = trpc.affiliate.joinAffiliate.useMutation({
    onSuccess: () => {
      affiliateQuery.refetch();
      toast.success("Referral link created! Start sharing to earn credits.");
    },
  });
  const referralsQuery = trpc.affiliate.myReferrals.useQuery(undefined, {
    enabled: isAuthenticated,
  });

  const affiliate = affiliateQuery.data;
  const referrals = referralsQuery.data || [];
  const refLink = affiliate
    ? `${window.location.origin}/?ref=${affiliate.referralCode}`
    : null;

  const handleCopy = () => {
    if (!refLink) return;
    navigator.clipboard.writeText(refLink).then(() => {
      setCopied(true);
      toast.success("Referral link copied to clipboard!");
      setTimeout(() => setCopied(false), 2500);
    });
  };

  const handleShare = (platform: "twitter" | "facebook" | "sms") => {
    if (!refLink) return;
    const text = encodeURIComponent(
      "Join me on SportCardsOnline.com — the best platform to buy, sell, grade, and trade sports cards! Use my link to sign up:"
    );
    const url = encodeURIComponent(refLink);
    if (platform === "twitter") {
      window.open(`https://twitter.com/intent/tweet?text=${text}&url=${url}`, "_blank");
    } else if (platform === "facebook") {
      window.open(`https://www.facebook.com/sharer/sharer.php?u=${url}`, "_blank");
    } else if (platform === "sms") {
      window.open(`sms:?body=${text}%20${url}`, "_blank");
    }
  };

  const totalEarnings = parseFloat(affiliate?.totalEarnings || "0");
  const pendingPayout = parseFloat(affiliate?.pendingPayout || "0");
  const totalReferrals = affiliate?.totalReferrals || 0;

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center px-4"
        style={{ background: "linear-gradient(135deg, #060e1a 0%, #0a1628 50%, #0d1f3c 100%)" }}>
        <div className="text-center max-w-md">
          <div className="w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6"
            style={{ background: "rgba(196,30,58,0.15)", border: "2px solid rgba(196,30,58,0.4)" }}>
            <Gift className="w-10 h-10" style={{ color: "#C41E3A" }} />
          </div>
          <h1 className="text-3xl font-black text-white mb-3">Refer a Friend</h1>
          <p style={{ color: "#94a3b8" }} className="mb-6">
            Sign in to get your unique referral link and start earning credits for every friend you bring to SportCardsOnline.
          </p>
          <Button
            onClick={() => window.location.href = getLoginUrl("/referral")}
            className="font-bold px-8 py-3"
            style={{ background: "#C41E3A", color: "white", border: "none" }}
          >
            Sign In to Get Your Link
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen" style={{ background: "linear-gradient(135deg, #060e1a 0%, #0a1628 50%, #0d1f3c 100%)" }}>
      {/* Hero */}
      <div className="relative py-14 text-center overflow-hidden">
        <div className="absolute inset-0 opacity-10"
          style={{ backgroundImage: "radial-gradient(circle at 50% 50%, #C41E3A 0%, transparent 70%)" }} />
        <div className="relative z-10">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full text-sm font-semibold mb-4"
            style={{ background: "rgba(196,30,58,0.15)", border: "1px solid rgba(196,30,58,0.3)", color: "#f87171" }}>
            <Gift className="w-4 h-4" />
            Refer a Friend Program
          </div>
          <h1 className="text-4xl md:text-5xl font-black text-white mb-3">
            Share &amp; <span style={{ color: "#C41E3A" }}>Earn Credits</span>
          </h1>
          <p className="text-lg max-w-2xl mx-auto" style={{ color: "#94a3b8" }}>
            Earn <strong className="text-white">{TIER1_CREDITS} free credits</strong> for every friend who signs up, plus <strong className="text-white">{TIER2_CREDITS} credits</strong> when their referrals join too. No plan required — just sign up!
          </p>
        </div>
      </div>

      <div className="max-w-5xl mx-auto px-4 pb-16 space-y-8">

        {/* Stats Row */}
        {affiliate && (
          <div className="grid grid-cols-3 gap-4">
            {[
              { label: "Total Referrals", value: totalReferrals, icon: Users, color: "#60a5fa" },
              { label: "Credits Earned", value: `${Math.round(totalEarnings * 100)} credits`, icon: TrendingUp, color: "#4ade80" },
              { label: "Tier 1 Reward", value: `${TIER1_CREDITS} credits`, icon: Gift, color: "#fbbf24" },
            ].map((stat) => (
              <Card key={stat.label} style={{ background: "#0d1f3c", border: "1px solid #1e3a5f" }}>
                <CardContent className="p-4 flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0"
                    style={{ background: `${stat.color}20`, border: `1px solid ${stat.color}40` }}>
                    <stat.icon className="w-5 h-5" style={{ color: stat.color }} />
                  </div>
                  <div>
                    <p className="text-white font-bold text-xl leading-none">{stat.value}</p>
                    <p style={{ color: "#94a3b8", fontSize: "12px" }} className="mt-0.5">{stat.label}</p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {/* Referral Link Card */}
        <Card style={{ background: "#0d1f3c", border: "1px solid #1e3a5f" }}>
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Link2 className="w-5 h-5" style={{ color: "#C41E3A" }} />
              Your Referral Link
            </CardTitle>
          </CardHeader>
          <CardContent>
            {!affiliate ? (
              <div className="text-center py-6">
                <p style={{ color: "#94a3b8" }} className="mb-4">
                  You don't have a referral link yet. Create one to start earning credits!
                </p>
                <Button
                  onClick={() => joinMutation.mutate()}
                  disabled={joinMutation.isPending}
                  className="font-bold px-8"
                  style={{ background: "#C41E3A", color: "white", border: "none" }}
                >
                  {joinMutation.isPending ? "Creating..." : "Create My Referral Link"}
                </Button>
              </div>
            ) : (
              <div className="space-y-4">
                {/* Link display */}
                <div className="flex items-center gap-2 p-3 rounded-lg" style={{ background: "#060e1a", border: "1px solid #1e3a5f" }}>
                  <span className="flex-1 text-sm font-mono truncate" style={{ color: "#60a5fa" }}>{refLink}</span>
                  <Button
                    onClick={handleCopy}
                    size="sm"
                    className="shrink-0 font-semibold"
                    style={{ background: copied ? "#052e16" : "#C41E3A", color: copied ? "#4ade80" : "white", border: "none" }}
                  >
                    {copied ? (
                      <span className="flex items-center gap-1.5"><CheckCircle2 className="w-4 h-4" /> Copied!</span>
                    ) : (
                      <span className="flex items-center gap-1.5"><Copy className="w-4 h-4" /> Copy</span>
                    )}
                  </Button>
                </div>

                {/* Referral code badge */}
                <div className="flex items-center gap-2">
                  <span style={{ color: "#94a3b8", fontSize: "13px" }}>Your code:</span>
                  <span className="font-mono font-bold px-3 py-1 rounded text-sm"
                    style={{ background: "rgba(196,30,58,0.15)", border: "1px solid rgba(196,30,58,0.3)", color: "#f87171" }}>
                    {affiliate.referralCode}
                  </span>
                </div>

                {/* Share buttons */}
                <div className="flex items-center gap-2 flex-wrap pt-1">
                  <span style={{ color: "#94a3b8", fontSize: "13px" }}>Share via:</span>
                  <Button onClick={() => handleShare("twitter")} size="sm" variant="outline"
                    style={{ borderColor: "#1e3a5f", color: "#60a5fa", background: "transparent" }}
                    className="flex items-center gap-1.5">
                    <Twitter className="w-3.5 h-3.5" /> Twitter
                  </Button>
                  <Button onClick={() => handleShare("facebook")} size="sm" variant="outline"
                    style={{ borderColor: "#1e3a5f", color: "#818cf8", background: "transparent" }}
                    className="flex items-center gap-1.5">
                    <Facebook className="w-3.5 h-3.5" /> Facebook
                  </Button>
                  <Button onClick={() => handleShare("sms")} size="sm" variant="outline"
                    style={{ borderColor: "#1e3a5f", color: "#4ade80", background: "transparent" }}
                    className="flex items-center gap-1.5">
                    <MessageCircle className="w-3.5 h-3.5" /> Text
                  </Button>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* How It Works */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* 2-Tier Explanation */}
          <Card style={{ background: "#0d1f3c", border: "1px solid #1e3a5f" }}>
            <CardHeader>
              <CardTitle className="text-white text-lg">How the 2-Tier System Works</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-start gap-3 p-3 rounded-lg" style={{ background: "rgba(74,222,128,0.05)", border: "1px solid rgba(74,222,128,0.2)" }}>
                <div className="w-8 h-8 rounded-full flex items-center justify-center text-sm font-black flex-shrink-0"
                  style={{ background: "#4ade8020", color: "#4ade80", border: "1px solid #4ade8040" }}>1</div>
                <div>
                  <p className="text-white font-semibold text-sm">Direct Referral (Tier 1)</p>
                  <p style={{ color: "#94a3b8", fontSize: "13px" }}>
                    When your friend signs up using your referral link, you automatically earn <strong className="text-white">{TIER1_CREDITS} free credits</strong> — no subscription required.
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-3 p-3 rounded-lg" style={{ background: "rgba(96,165,250,0.05)", border: "1px solid rgba(96,165,250,0.2)" }}>
                <div className="w-8 h-8 rounded-full flex items-center justify-center text-sm font-black flex-shrink-0"
                  style={{ background: "#60a5fa20", color: "#60a5fa", border: "1px solid #60a5fa40" }}>2</div>
                <div>
                  <p className="text-white font-semibold text-sm">Second-Level Referral (Tier 2)</p>
                  <p style={{ color: "#94a3b8", fontSize: "13px" }}>
                    When someone your friend referred also signs up, you earn <strong className="text-white">{TIER2_CREDITS} bonus credits</strong> automatically — two levels of rewards!
                  </p>
                </div>
              </div>
              <div className="p-3 rounded-lg" style={{ background: "rgba(196,30,58,0.05)", border: "1px solid rgba(196,30,58,0.2)" }}>
                <p style={{ color: "#94a3b8", fontSize: "12px" }}>
                  Referral attribution is tracked for <strong className="text-white">30 days</strong> via cookie and IP. Credits are awarded automatically when a referred user creates their account.
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Credit Summary */}
          <Card style={{ background: "#0d1f3c", border: "1px solid #1e3a5f" }}>
            <CardHeader>
              <CardTitle className="text-white text-lg">What You Earn</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex items-center justify-between p-3 rounded-lg"
                  style={{ background: "rgba(74,222,128,0.05)", border: "1px solid rgba(74,222,128,0.2)" }}>
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-full flex items-center justify-center text-sm font-black"
                      style={{ background: "#4ade8020", color: "#4ade80", border: "1px solid #4ade8040" }}>1</div>
                    <div>
                      <p className="text-white font-semibold text-sm">Direct Referral (Tier 1)</p>
                      <p style={{ color: "#94a3b8", fontSize: "12px" }}>Friend signs up with your link</p>
                    </div>
                  </div>
                  <p style={{ color: "#4ade80" }} className="font-black text-xl">+{TIER1_CREDITS}</p>
                </div>
                <div className="flex items-center justify-between p-3 rounded-lg"
                  style={{ background: "rgba(96,165,250,0.05)", border: "1px solid rgba(96,165,250,0.2)" }}>
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-full flex items-center justify-center text-sm font-black"
                      style={{ background: "#60a5fa20", color: "#60a5fa", border: "1px solid #60a5fa40" }}>2</div>
                    <div>
                      <p className="text-white font-semibold text-sm">Second-Level (Tier 2)</p>
                      <p style={{ color: "#94a3b8", fontSize: "12px" }}>Your friend refers someone</p>
                    </div>
                  </div>
                  <p style={{ color: "#60a5fa" }} className="font-black text-xl">+{TIER2_CREDITS}</p>
                </div>
                <div className="p-3 rounded-lg text-center" style={{ background: "rgba(196,30,58,0.05)", border: "1px solid rgba(196,30,58,0.2)" }}>
                  <p style={{ color: "#f87171", fontSize: "13px" }} className="font-semibold">No plan required — free for everyone!</p>
                  <p style={{ color: "#94a3b8", fontSize: "12px" }} className="mt-0.5">Credits awarded instantly when your referral creates an account.</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Referral History */}
        {affiliate && (
          <Card style={{ background: "#0d1f3c", border: "1px solid #1e3a5f" }}>
            <CardHeader>
              <CardTitle className="text-white text-lg flex items-center gap-2">
                <Users className="w-5 h-5" style={{ color: "#C41E3A" }} />
                Your Referrals
                <span className="ml-auto text-sm font-normal" style={{ color: "#94a3b8" }}>
                  {referrals.length} total
                </span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              {referrals.length === 0 ? (
                <div className="text-center py-8">
                  <Share2 className="w-10 h-10 mx-auto mb-3" style={{ color: "#1e3a5f" }} />
                  <p style={{ color: "#94a3b8" }}>No referrals yet. Share your link to start earning!</p>
                </div>
              ) : (
                <div className="space-y-2">
                  {referrals.map((ref: any) => (
                    <div key={ref.id} className="flex items-center justify-between p-3 rounded-lg"
                      style={{ background: "#060e1a", border: "1px solid #1e3a5f" }}>
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold"
                          style={{ background: "#1e3a5f", color: "#60a5fa" }}>
                          {(ref.referredName || ref.referredEmail || "?")[0].toUpperCase()}
                        </div>
                        <div>
                          <p className="text-white text-sm font-medium">
                            {ref.referredName || ref.referredEmail}
                          </p>
                          <p style={{ color: "#475569", fontSize: "12px" }}>
                            {new Date(ref.createdAt).toLocaleDateString()}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        <span className="text-sm font-bold" style={{ color: "#4ade80" }}>
                          +${parseFloat(ref.commissionAmount || "0").toFixed(2)}
                        </span>
                        <span className={`px-2 py-0.5 rounded text-xs font-semibold ${
                          ref.status === "paid"
                            ? "text-green-400"
                            : ref.status === "cancelled"
                            ? "text-red-400"
                            : "text-yellow-400"
                        }`} style={{
                          background: ref.status === "paid"
                            ? "rgba(74,222,128,0.1)"
                            : ref.status === "cancelled"
                            ? "rgba(248,113,113,0.1)"
                            : "rgba(251,191,36,0.1)",
                        }}>
                          {ref.status}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        )}

        {/* Terms */}
        <p style={{ color: "#475569", fontSize: "12px", textAlign: "center" }}>
          Credits are awarded when a referred user creates their account. Referral attribution is tracked for 30 days.
          Credits have no cash value and can only be used on SportCardsOnline.com. Abuse of the referral system may result in account suspension.
        </p>
      </div>
    </div>
  );
}
