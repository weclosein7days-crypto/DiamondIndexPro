import { useState, useRef, useCallback } from "react";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "sonner";
import {
  Search, X, Send, ArrowLeftRight, CheckCircle2, XCircle,
  RefreshCw, Clock, Package, Truck, Star, ChevronRight,
  User, Plus, Inbox, History, Shield, AlertCircle
} from "lucide-react";
import { Link } from "wouter";

// ─── Types ───────────────────────────────────────────────────────────────────

interface CardItem {
  id: number;
  cardTitle?: string;
  playerName?: string;
  year?: string;
  setName?: string;
  sport?: string;
  frontImageUrl?: string;
  imageUrl?: string;
  overallGrade?: string;
  aiGrade?: string;
  certNumber?: string;
  source?: string;
  sellerEmail?: string;
  storeName?: string;
}

interface TradeCard {
  id: number;
  title: string;
  image?: string;
  grade?: string;
  year?: string;
  set?: string;
}

// ─── Status config ────────────────────────────────────────────────────────────

const STATUS: Record<string, { label: string; color: string; icon: React.ReactNode }> = {
  pending:            { label: "Pending",          color: "bg-amber-100 text-amber-800 border-amber-200",    icon: <Clock className="w-3 h-3" /> },
  countered:          { label: "Counter-Offer",    color: "bg-orange-100 text-orange-800 border-orange-200", icon: <RefreshCw className="w-3 h-3" /> },
  accepted:           { label: "Accepted",         color: "bg-green-100 text-green-800 border-green-200",    icon: <CheckCircle2 className="w-3 h-3" /> },
  agreed:             { label: "Agreed — Pay Fee", color: "bg-blue-100 text-blue-800 border-blue-200",       icon: <Shield className="w-3 h-3" /> },
  fee_pending:        { label: "Fee Pending",      color: "bg-purple-100 text-purple-800 border-purple-200", icon: <AlertCircle className="w-3 h-3" /> },
  paid_ready_to_ship: { label: "Ready to Ship",    color: "bg-sky-100 text-sky-800 border-sky-200",          icon: <Package className="w-3 h-3" /> },
  shipped:            { label: "Shipped",          color: "bg-indigo-100 text-indigo-800 border-indigo-200", icon: <Truck className="w-3 h-3" /> },
  completed:          { label: "Completed",        color: "bg-emerald-100 text-emerald-800 border-emerald-200", icon: <Star className="w-3 h-3" /> },
  rejected:           { label: "Declined",         color: "bg-red-100 text-red-800 border-red-200",          icon: <XCircle className="w-3 h-3" /> },
  cancelled:          { label: "Cancelled",        color: "bg-gray-100 text-gray-600 border-gray-200",       icon: <X className="w-3 h-3" /> },
};

// ─── Small card thumbnail ─────────────────────────────────────────────────────

function CardThumb({ card, onRemove, draggable, onDragStart }: {
  card: TradeCard;
  onRemove?: () => void;
  draggable?: boolean;
  onDragStart?: (e: React.DragEvent) => void;
}) {
  return (
    <div
      draggable={draggable}
      onDragStart={onDragStart}
      className={`relative group flex items-center gap-3 p-2.5 rounded-xl border border-gray-200 bg-white shadow-sm hover:shadow-md transition-all ${draggable ? "cursor-grab active:cursor-grabbing" : ""}`}
    >
      <div className="w-10 h-14 rounded-lg overflow-hidden bg-gray-100 flex-shrink-0 border border-gray-200">
        {card.image ? (
          <img src={card.image} alt={card.title} className="w-full h-full object-cover" />
        ) : (
          <div className="w-full h-full flex items-center justify-center text-gray-300 text-xl">🃏</div>
        )}
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-sm font-semibold text-gray-800 truncate">{card.title}</p>
        {card.year && <p className="text-xs text-gray-400 truncate">{card.year} {card.set}</p>}
        {card.grade && (
          <span className="inline-block mt-0.5 text-xs font-bold text-amber-700 bg-amber-50 border border-amber-200 px-1.5 py-0.5 rounded-md">
            SCG {card.grade}
          </span>
        )}
      </div>
      {onRemove && (
        <button
          onClick={onRemove}
          className="opacity-0 group-hover:opacity-100 transition-opacity absolute top-1.5 right-1.5 w-5 h-5 rounded-full bg-red-100 hover:bg-red-200 flex items-center justify-center text-red-500"
        >
          <X className="w-3 h-3" />
        </button>
      )}
    </div>
  );
}

// ─── Drop Zone ────────────────────────────────────────────────────────────────

function DropZone({ cards, onDrop, onRemove, label, color, empty }: {
  cards: TradeCard[];
  onDrop: (e: React.DragEvent) => void;
  onRemove: (id: number) => void;
  label: string;
  color: "red" | "blue";
  empty: string;
}) {
  const [over, setOver] = useState(false);
  const accent = color === "red"
    ? { border: "border-red-300", bg: "bg-red-50", text: "text-red-700", dot: "bg-red-500" }
    : { border: "border-blue-300", bg: "bg-blue-50", text: "text-blue-700", dot: "bg-blue-500" };

  return (
    <div
      onDragOver={e => { e.preventDefault(); setOver(true); }}
      onDragLeave={() => setOver(false)}
      onDrop={e => { setOver(false); onDrop(e); }}
      className={`rounded-2xl border-2 border-dashed transition-all min-h-[180px] p-3 ${
        over ? `${accent.border} ${accent.bg} scale-[1.01]` : "border-gray-200 bg-gray-50/50"
      }`}
    >
      <div className="flex items-center gap-2 mb-3">
        <span className={`w-2.5 h-2.5 rounded-full ${accent.dot}`} />
        <span className={`text-xs font-bold uppercase tracking-wider ${accent.text}`}>{label}</span>
        {cards.length > 0 && (
          <span className={`ml-auto text-xs font-semibold ${accent.text} ${accent.bg} border ${accent.border} px-2 py-0.5 rounded-full`}>
            {cards.length} card{cards.length !== 1 ? "s" : ""}
          </span>
        )}
      </div>
      {cards.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-8 text-gray-400">
          <Plus className="w-6 h-6 mb-1 opacity-40" />
          <p className="text-xs text-center">{empty}</p>
        </div>
      ) : (
        <div className="space-y-2">
          {cards.map(c => (
            <CardThumb key={c.id} card={c} onRemove={() => onRemove(c.id)} />
          ))}
        </div>
      )}
    </div>
  );
}

// ─── Trade Row (inbox/history) ────────────────────────────────────────────────

function TradeRow({ trade, myEmail, onAccept, onDecline, onCounter, onViewAgreement }: {
  trade: any;
  myEmail: string;
  onAccept?: () => void;
  onDecline?: () => void;
  onCounter?: () => void;
  onViewAgreement?: () => void;
}) {
  const isInitiator = trade.initiatorEmail === myEmail;
  const other = isInitiator
    ? (trade.receiverName || trade.receiverEmail)
    : (trade.initiatorName || trade.initiatorEmail);
  const st = STATUS[trade.status] ?? STATUS.pending;
  const myCards: string[] = isInitiator ? (trade.offeredCardTitles ?? []) : (trade.requestedCardTitles ?? []);
  const theirCards: string[] = isInitiator ? (trade.requestedCardTitles ?? []) : (trade.offeredCardTitles ?? []);
  const myImages: string[] = isInitiator ? (trade.offeredCardImages ?? []) : (trade.requestedCardImages ?? []);
  const theirImages: string[] = isInitiator ? (trade.requestedCardImages ?? []) : (trade.offeredCardImages ?? []);

  return (
    <div className="bg-white rounded-2xl border border-gray-200 shadow-sm hover:shadow-md transition-all overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 border-b border-gray-100 bg-gray-50/60">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-full bg-gradient-to-br from-gray-200 to-gray-300 flex items-center justify-center">
            <User className="w-4 h-4 text-gray-500" />
          </div>
          <div>
            <p className="text-sm font-semibold text-gray-800">{other}</p>
            <p className="text-xs text-gray-400">Trade #{trade.id} · {new Date(trade.createdAt).toLocaleDateString()}</p>
          </div>
        </div>
        <Badge className={`flex items-center gap-1 text-xs border ${st.color}`}>
          {st.icon}{st.label}
        </Badge>
      </div>

      {/* Cards preview */}
      <div className="px-4 py-3 grid grid-cols-2 gap-3">
        <div>
          <p className="text-xs font-semibold text-red-600 mb-2 uppercase tracking-wide">You Send</p>
          <div className="flex gap-1.5 flex-wrap">
            {myCards.slice(0, 3).map((t, i) => (
              <div key={i} className="w-10 h-14 rounded-lg overflow-hidden bg-gray-100 border border-gray-200 flex-shrink-0">
                {myImages[i] ? (
                  <img src={myImages[i]} alt={t} className="w-full h-full object-cover" />
                ) : (
                  <div className="w-full h-full flex items-center justify-center text-gray-300 text-lg">🃏</div>
                )}
              </div>
            ))}
            {myCards.length > 3 && (
              <div className="w-10 h-14 rounded-lg bg-gray-100 border border-gray-200 flex items-center justify-center text-xs font-bold text-gray-500">
                +{myCards.length - 3}
              </div>
            )}
          </div>
          <p className="text-xs text-gray-500 mt-1 truncate">{myCards.slice(0, 2).join(", ")}{myCards.length > 2 ? ` +${myCards.length - 2} more` : ""}</p>
        </div>
        <div>
          <p className="text-xs font-semibold text-blue-600 mb-2 uppercase tracking-wide">You Receive</p>
          <div className="flex gap-1.5 flex-wrap">
            {theirCards.slice(0, 3).map((t, i) => (
              <div key={i} className="w-10 h-14 rounded-lg overflow-hidden bg-gray-100 border border-gray-200 flex-shrink-0">
                {theirImages[i] ? (
                  <img src={theirImages[i]} alt={t} className="w-full h-full object-cover" />
                ) : (
                  <div className="w-full h-full flex items-center justify-center text-gray-300 text-lg">🃏</div>
                )}
              </div>
            ))}
            {theirCards.length > 3 && (
              <div className="w-10 h-14 rounded-lg bg-gray-100 border border-gray-200 flex items-center justify-center text-xs font-bold text-gray-500">
                +{theirCards.length - 3}
              </div>
            )}
          </div>
          <p className="text-xs text-gray-500 mt-1 truncate">{theirCards.slice(0, 2).join(", ")}{theirCards.length > 2 ? ` +${theirCards.length - 2} more` : ""}</p>
        </div>
      </div>

      {/* Message */}
      {trade.message && (
        <div className="px-4 pb-2">
          <p className="text-xs text-gray-500 italic bg-gray-50 rounded-lg px-3 py-2 border border-gray-100">"{trade.message}"</p>
        </div>
      )}

      {/* Actions */}
      {(onAccept || onDecline || onCounter || onViewAgreement) && (
        <div className="px-4 py-3 border-t border-gray-100 flex items-center gap-2 flex-wrap">
          {onAccept && (
            <Button size="sm" onClick={onAccept} className="bg-green-600 hover:bg-green-700 text-white gap-1.5 rounded-xl">
              <CheckCircle2 className="w-3.5 h-3.5" /> Accept
            </Button>
          )}
          {onCounter && (
            <Button size="sm" variant="outline" onClick={onCounter} className="gap-1.5 rounded-xl border-orange-300 text-orange-700 hover:bg-orange-50">
              <RefreshCw className="w-3.5 h-3.5" /> Counter
            </Button>
          )}
          {onDecline && (
            <Button size="sm" variant="outline" onClick={onDecline} className="gap-1.5 rounded-xl border-red-200 text-red-600 hover:bg-red-50">
              <XCircle className="w-3.5 h-3.5" /> Decline
            </Button>
          )}
          {onViewAgreement && (
            <Button size="sm" variant="outline" onClick={onViewAgreement} className="gap-1.5 rounded-xl ml-auto">
              View Agreement <ChevronRight className="w-3.5 h-3.5" />
            </Button>
          )}
        </div>
      )}
    </div>
  );
}

// ─── Counter-Offer Dialog ─────────────────────────────────────────────────────

function CounterDialog({ trade, myEmail, myCards, open, onClose, onSuccess }: {
  trade: any;
  myEmail: string;
  myCards: CardItem[];
  open: boolean;
  onClose: () => void;
  onSuccess: () => void;
}) {
  const isInitiator = trade.initiatorEmail === myEmail;
  const [offerCards, setOfferCards] = useState<TradeCard[]>([]);
  const [requestCards, setRequestCards] = useState<TradeCard[]>([]);
  const [message, setMessage] = useState("");
  const [search, setSearch] = useState("");
  const dragCard = useRef<TradeCard | null>(null);

  const counterMutation = trpc.trades.counterOffer.useMutation({
    onSuccess: () => { toast.success("Counter-offer sent!"); onSuccess(); onClose(); },
    onError: (e) => toast.error(e.message),
  });

  const filteredMine = myCards.filter(c =>
    !offerCards.find(s => s.id === c.id) &&
    (c.playerName?.toLowerCase().includes(search.toLowerCase()) ||
     c.cardTitle?.toLowerCase().includes(search.toLowerCase()))
  );

  const toChip = (c: CardItem): TradeCard => ({
    id: c.id,
    title: c.playerName || c.cardTitle || "Card",
    image: c.frontImageUrl || c.imageUrl,
    grade: c.overallGrade || c.aiGrade,
    year: c.year,
    set: c.setName,
  });

  const handleSubmit = () => {
    if (offerCards.length === 0 || requestCards.length === 0) {
      toast.error("Add at least one card to each side");
      return;
    }
    counterMutation.mutate({
      id: trade.id,
      offeredCardIds: isInitiator ? offerCards.map(c => c.id) : requestCards.map(c => c.id),
      offeredCardTitles: isInitiator ? offerCards.map(c => c.title) : requestCards.map(c => c.title),
      offeredCardImages: isInitiator ? offerCards.map(c => c.image ?? "") : requestCards.map(c => c.image ?? ""),
      requestedCardIds: isInitiator ? requestCards.map(c => c.id) : offerCards.map(c => c.id),
      requestedCardTitles: isInitiator ? requestCards.map(c => c.title) : offerCards.map(c => c.title),
      requestedCardImages: isInitiator ? requestCards.map(c => c.image ?? "") : offerCards.map(c => c.image ?? ""),
      message,
    });
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <RefreshCw className="w-5 h-5 text-orange-500" /> Counter-Offer
          </DialogTitle>
        </DialogHeader>
        <div className="grid grid-cols-2 gap-4">
          {/* My cards picker */}
          <div>
            <p className="text-sm font-semibold text-gray-700 mb-2">My Cards (drag to offer)</p>
            <Input
              placeholder="Search..."
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="mb-2 h-8 text-sm"
            />
            <div className="space-y-1.5 max-h-48 overflow-y-auto pr-1">
              {filteredMine.map(c => {
                const chip = toChip(c);
                return (
                  <div
                    key={c.id}
                    draggable
                    onDragStart={() => { dragCard.current = chip; }}
                    onClick={() => setOfferCards(p => p.find(x => x.id === c.id) ? p : [...p, chip])}
                    className="flex items-center gap-2 p-2 rounded-lg border border-gray-200 bg-white hover:border-red-300 hover:bg-red-50 cursor-pointer transition-all"
                  >
                    <div className="w-8 h-11 rounded bg-gray-100 overflow-hidden flex-shrink-0">
                      {c.frontImageUrl || c.imageUrl ? (
                        <img src={c.frontImageUrl || c.imageUrl} alt="" className="w-full h-full object-cover" />
                      ) : <div className="w-full h-full flex items-center justify-center text-gray-300">🃏</div>}
                    </div>
                    <div className="min-w-0">
                      <p className="text-xs font-medium text-gray-800 truncate">{c.playerName || c.cardTitle}</p>
                      {(c.overallGrade || c.aiGrade) && <p className="text-xs text-amber-600">SCG {c.overallGrade || c.aiGrade}</p>}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
          {/* Drop zones */}
          <div className="space-y-3">
            <DropZone
              cards={offerCards}
              onDrop={e => {
                e.preventDefault();
                if (dragCard.current && !offerCards.find(c => c.id === dragCard.current!.id)) {
                  setOfferCards(p => [...p, dragCard.current!]);
                }
              }}
              onRemove={id => setOfferCards(p => p.filter(c => c.id !== id))}
              label="I'm Offering"
              color="red"
              empty="Drag or click cards to offer"
            />
            <DropZone
              cards={requestCards}
              onDrop={e => {
                e.preventDefault();
                if (dragCard.current && !requestCards.find(c => c.id === dragCard.current!.id)) {
                  setRequestCards(p => [...p, dragCard.current!]);
                }
              }}
              onRemove={id => setRequestCards(p => p.filter(c => c.id !== id))}
              label="I Want"
              color="blue"
              empty="Add cards you want in return"
            />
          </div>
        </div>
        <Textarea
          placeholder="Add a message (optional)..."
          value={message}
          onChange={e => setMessage(e.target.value)}
          className="mt-2 text-sm resize-none"
          rows={2}
        />
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button onClick={handleSubmit} disabled={counterMutation.isPending} className="bg-orange-600 hover:bg-orange-700 text-white gap-2">
            <Send className="w-4 h-4" /> Send Counter-Offer
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ─── Main Page ────────────────────────────────────────────────────────────────

export default function Trades() {
  const { user, isAuthenticated } = useAuth();

  // My collection for the left panel
  const { data: myCollection = [] } = trpc.collection.list.useQuery(undefined, { enabled: isAuthenticated });

  // Seller search for right panel
  const [sellerSearch, setSellerSearch] = useState("");
  const [selectedSeller, setSelectedSeller] = useState<{ email: string; name: string } | null>(null);
  const { data: sellerResults = [] } = trpc.cards.searchSellers.useQuery(
    { query: sellerSearch },
    { enabled: sellerSearch.length >= 2 }
  );
  const { data: theirCollection = [] } = trpc.cards.getBySeller.useQuery(
    { sellerEmail: selectedSeller?.email ?? "" },
    { enabled: !!selectedSeller }
  );

  // My trades
  const utils = trpc.useUtils();
  const { data: myTrades = [], isLoading: tradesLoading } = trpc.trades.myTrades.useQuery(undefined, { enabled: isAuthenticated });

  // Trade builder state
  const [myCards, setMyCards] = useState<TradeCard[]>([]);
  const [theirCards, setTheirCards] = useState<TradeCard[]>([]);
  const [message, setMessage] = useState("");
  const [mySearch, setMySearch] = useState("");
  const [theirSearch, setTheirSearch] = useState("");
  const dragCard = useRef<{ card: TradeCard; side: "mine" | "theirs" } | null>(null);

  // Dialogs
  const [counterTrade, setCounterTrade] = useState<any | null>(null);
  const [ebayBlock, setEbayBlock] = useState<string | null>(null);

  // Mutations
  const createTrade = trpc.trades.create.useMutation({
    onSuccess: () => {
      toast.success("Trade offer sent!");
      setMyCards([]); setTheirCards([]); setMessage(""); setSelectedSeller(null);
      utils.trades.myTrades.invalidate();
    },
    onError: e => toast.error(e.message),
  });
  const respondMutation = trpc.trades.updateStatus.useMutation({
    onSuccess: () => { toast.success("Done!"); utils.trades.myTrades.invalidate(); },
    onError: e => toast.error(e.message),
  });

  const toChip = (c: CardItem): TradeCard => ({
    id: c.id,
    title: (c.playerName || c.cardTitle || "Card"),
    image: c.frontImageUrl || c.imageUrl,
    grade: c.overallGrade || c.aiGrade,
    year: c.year,
    set: c.setName,
  });

  const addMyCard = useCallback((c: CardItem) => {
    if (c.source === "ebay_import") { setEbayBlock(c.playerName || c.cardTitle || "This card"); return; }
    const chip = toChip(c);
    setMyCards(p => p.find(x => x.id === chip.id) ? p : [...p, chip]);
  }, []);

  const addTheirCard = useCallback((c: CardItem) => {
    const chip = toChip(c);
    if (!selectedSeller && c.sellerEmail) {
      setSelectedSeller({ email: c.sellerEmail, name: (c as any).storeName || c.sellerEmail });
    }
    setTheirCards(p => p.find(x => x.id === chip.id) ? p : [...p, chip]);
  }, [selectedSeller]);

  const handleSend = () => {
    if (!selectedSeller) { toast.error("Select a seller first"); return; }
    if (myCards.length === 0 || theirCards.length === 0) { toast.error("Add at least one card to each side"); return; }
    createTrade.mutate({
      receiverEmail: selectedSeller.email,
      receiverName: selectedSeller.name,
      offeredCardIds: myCards.map(c => c.id),
      offeredCardTitles: myCards.map(c => c.title),
      offeredCardImages: myCards.map(c => c.image ?? ""),
      requestedCardIds: theirCards.map(c => c.id),
      requestedCardTitles: theirCards.map(c => c.title),
      requestedCardImages: theirCards.map(c => c.image ?? ""),
      message: message || undefined,
    });
  };

  const filteredMine = (myCollection as CardItem[]).filter(c =>
    !myCards.find(s => s.id === c.id) &&
    ((c.playerName || c.cardTitle || "").toLowerCase().includes(mySearch.toLowerCase()))
  );

  const filteredTheirs = (theirCollection as CardItem[]).filter(c =>
    !theirCards.find(s => s.id === c.id) &&
    ((c.playerName || c.cardTitle || "").toLowerCase().includes(theirSearch.toLowerCase()))
  );

  const incoming = (myTrades as any[]).filter(t => t.receiverEmail === user?.email);
  const outgoing = (myTrades as any[]).filter(t => t.initiatorEmail === user?.email);
  const pendingCount = incoming.filter(t => t.status === "pending" || t.status === "countered").length;

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-gray-100 flex items-center justify-center p-4">
        <div className="bg-white rounded-3xl shadow-xl p-10 max-w-sm w-full text-center border border-gray-100">
          <div className="w-16 h-16 rounded-2xl bg-red-50 border border-red-100 flex items-center justify-center mx-auto mb-4">
            <ArrowLeftRight className="w-8 h-8 text-red-600" />
          </div>
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Trade Depot</h2>
          <p className="text-gray-500 mb-6">Sign in to propose and manage card trades with other collectors.</p>
          <a href={getLoginUrl()} className="block w-full bg-red-600 hover:bg-red-700 text-white font-semibold py-3 rounded-xl transition-colors">
            Sign In to Trade
          </a>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-gray-100">

      {/* ── Page Header ── */}
      <div className="bg-white border-b border-gray-200 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3 flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
              <ArrowLeftRight className="w-6 h-6 text-red-600" />
              Trade Depot
            </h1>
            <p className="text-sm text-gray-500 mt-0.5">Build a trade offer, send it, and track it through completion</p>
          </div>
          <div className="flex items-center gap-2 bg-green-50 border border-green-200 rounded-xl px-3 py-2">
            <Shield className="w-4 h-4 text-green-600" />
            <span className="text-sm font-semibold text-green-700">SCO Escrow Protected</span>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3 space-y-3">

        {/* ── Step Indicator ── */}
        <div className="flex items-center gap-2 text-sm">
          {[
            { n: 1, label: "Pick Your Cards" },
            { n: 2, label: "Find Their Cards" },
            { n: 3, label: "Send Offer" },
          ].map((s, i) => (
            <div key={s.n} className="flex items-center gap-2">
              {i > 0 && <ChevronRight className="w-4 h-4 text-gray-300" />}
              <div className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full font-medium transition-all ${
                (s.n === 1 && myCards.length > 0) || (s.n === 2 && theirCards.length > 0) || (s.n === 3 && myCards.length > 0 && theirCards.length > 0)
                  ? "bg-red-600 text-white shadow-sm"
                  : "bg-white border border-gray-200 text-gray-500"
              }`}>
                <span className="w-5 h-5 rounded-full bg-current/10 flex items-center justify-center text-xs font-bold">{s.n}</span>
                {s.label}
              </div>
            </div>
          ))}
        </div>

        {/* ── Trade Builder ── */}
        <div className="grid grid-cols-1 lg:grid-cols-[1fr_260px_1fr] gap-3">

          {/* LEFT — My Collection */}
          <div className="bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden">
            <div className="px-4 py-3 border-b border-gray-100 bg-gray-50/60">
              <h3 className="font-semibold text-gray-800 flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-red-500" />
                My Collection
              </h3>
              <div className="relative mt-2">
                <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-gray-400" />
                <Input
                  value={mySearch}
                  onChange={e => setMySearch(e.target.value)}
                  placeholder="Search my cards..."
                  className="pl-8 h-8 text-sm"
                />
              </div>
            </div>
            <div className="p-2 max-h-60 overflow-y-auto">
              {filteredMine.length === 0 ? (
                <div className="text-center py-8 text-gray-400">
                  <p className="text-sm">No cards in your collection.</p>
                  <Link href="/grade-cards" className="text-red-500 hover:underline text-xs mt-1 block">Grade cards first →</Link>
                </div>
              ) : (
                <div className="grid grid-cols-4 gap-1.5">
                  {filteredMine.map((c: CardItem) => (
                    <div
                      key={c.id}
                      draggable
                      onDragStart={() => { dragCard.current = { card: toChip(c), side: "mine" }; }}
                      onClick={() => addMyCard(c)}
                      className={`cursor-pointer rounded-xl border transition-all hover:shadow-md ${
                        myCards.find(s => s.id === c.id)
                          ? "border-red-400 bg-red-50 ring-1 ring-red-300"
                          : "border-gray-200 bg-white hover:border-red-300"
                      }`}
                    >
                      <div className="aspect-[5/7] rounded-t-lg overflow-hidden bg-gray-100">
                        {c.frontImageUrl || c.imageUrl ? (
                          <img src={c.frontImageUrl || c.imageUrl} alt="" className="w-full h-full object-cover" />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center text-gray-300 text-lg">🃏</div>
                        )}
                      </div>
                      <div className="p-1">
                        <p className="text-[10px] font-medium text-gray-800 truncate leading-tight">{c.playerName || c.cardTitle}</p>
                        {(c.overallGrade || c.aiGrade) && (
                          <p className="text-[10px] text-amber-600 font-bold">SCG {c.overallGrade || c.aiGrade}</p>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* CENTER — Trade Board */}
          <div className="flex flex-col gap-2">
            {/* Drop zones */}
            <DropZone
              cards={myCards}
              onDrop={e => {
                e.preventDefault();
                if (dragCard.current?.side === "mine") {
                  addMyCard(dragCard.current.card as any);
                }
              }}
              onRemove={id => setMyCards(p => p.filter(c => c.id !== id))}
              label="I'm Offering"
              color="red"
              empty="Click or drag cards from your collection"
            />

            {/* Arrow */}
            <div className="flex items-center justify-center">
              <div className="flex items-center gap-2 bg-white border border-gray-200 rounded-full px-3 py-1.5 shadow-sm">
                <ArrowLeftRight className="w-4 h-4 text-gray-400" />
                <span className="text-xs text-gray-500 font-medium">Trade</span>
              </div>
            </div>

            <DropZone
              cards={theirCards}
              onDrop={e => {
                e.preventDefault();
                if (dragCard.current?.side === "theirs") {
                  addTheirCard(dragCard.current.card as any);
                }
              }}
              onRemove={id => setTheirCards(p => p.filter(c => c.id !== id))}
              label="I Want"
              color="blue"
              empty="Click or drag cards from their collection"
            />

            {/* Message + Send */}
            <div className="bg-white rounded-2xl border border-gray-200 p-3 shadow-sm space-y-2">
              {selectedSeller && (
                <div className="flex items-center gap-2 bg-blue-50 border border-blue-200 rounded-xl px-3 py-2">
                  <User className="w-3.5 h-3.5 text-blue-600" />
                  <span className="text-xs font-semibold text-blue-700">{selectedSeller.name}</span>
                  <button onClick={() => { setSelectedSeller(null); setTheirCards([]); }} className="ml-auto text-blue-400 hover:text-blue-600">
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>
              )}
              <Textarea
                placeholder="Add a message to your offer (optional)..."
                value={message}
                onChange={e => setMessage(e.target.value)}
                className="text-sm resize-none border-gray-200"
                rows={2}
              />
              <Button
                onClick={handleSend}
                disabled={createTrade.isPending || myCards.length === 0 || theirCards.length === 0 || !selectedSeller}
                className="w-full bg-red-600 hover:bg-red-700 text-white rounded-xl gap-2 font-semibold"
              >
                <Send className="w-4 h-4" />
                {createTrade.isPending ? "Sending..." : "Send Trade Offer"}
              </Button>
              {(!selectedSeller && theirCards.length === 0) && (
                <p className="text-xs text-gray-400 text-center">Search for a seller on the right to begin</p>
              )}
            </div>
          </div>

          {/* RIGHT — Their Collection */}
          <div className="bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden">
            <div className="px-4 py-3 border-b border-gray-100 bg-gray-50/60">
              <h3 className="font-semibold text-gray-800 flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-blue-500" />
                Their Collection
              </h3>
              {/* Seller search */}
              <div className="relative mt-2">
                <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-gray-400" />
                <Input
                  value={sellerSearch}
                  onChange={e => { setSellerSearch(e.target.value); setSelectedSeller(null); }}
                  placeholder="Search by seller or card name..."
                  className="pl-8 h-8 text-sm"
                />
              </div>
              {/* Seller results dropdown */}
              {sellerSearch.length >= 2 && !selectedSeller && sellerResults.length > 0 && (
                <div className="mt-1 bg-white border border-gray-200 rounded-xl shadow-lg overflow-hidden">
                  {(sellerResults as any[]).slice(0, 5).map((s: any) => (
                    <button
                      key={s.email}
                      onClick={() => { setSelectedSeller({ email: s.email, name: s.storeName || s.name || s.email }); setSellerSearch(""); }}
                      className="w-full flex items-center gap-2 px-3 py-2 hover:bg-gray-50 text-left border-b border-gray-100 last:border-0"
                    >
                      <div className="w-7 h-7 rounded-full bg-blue-100 flex items-center justify-center flex-shrink-0">
                        <User className="w-3.5 h-3.5 text-blue-600" />
                      </div>
                      <div>
                        <p className="text-xs font-semibold text-gray-800">{s.storeName || s.name || s.email}</p>
                        <p className="text-xs text-gray-400">{s.cardCount} cards available</p>
                      </div>
                    </button>
                  ))}
                </div>
              )}
              {selectedSeller && (
                <div className="mt-2 relative">
                  <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-gray-400" />
                  <Input
                    value={theirSearch}
                    onChange={e => setTheirSearch(e.target.value)}
                    placeholder="Filter their cards..."
                    className="pl-8 h-8 text-sm"
                  />
                </div>
              )}
            </div>
            <div className="p-3">
              {!selectedSeller ? (
                <div className="text-center py-12 text-gray-400">
                  <User className="w-8 h-8 mx-auto mb-2 opacity-30" />
                  <p className="text-sm">Search for a collector above to see their cards</p>
                </div>
              ) : filteredTheirs.length === 0 ? (
                <div className="text-center py-12 text-gray-400">
                  <p className="text-sm">No tradeable cards found.</p>
                </div>
              ) : (
                <div className="grid grid-cols-3 gap-2">
                  {filteredTheirs.map((c: CardItem) => (
                    <div
                      key={c.id}
                      draggable
                      onDragStart={() => { dragCard.current = { card: toChip(c), side: "theirs" }; }}
                      onClick={() => addTheirCard(c)}
                      className={`cursor-pointer rounded-xl border transition-all hover:shadow-md ${
                        theirCards.find(s => s.id === c.id)
                          ? "border-blue-400 bg-blue-50 ring-1 ring-blue-300"
                          : "border-gray-200 bg-white hover:border-blue-300"
                      }`}
                    >
                      <div className="aspect-[5/7] rounded-t-lg overflow-hidden bg-gray-100">
                        {c.frontImageUrl || c.imageUrl ? (
                          <img src={c.frontImageUrl || c.imageUrl} alt="" className="w-full h-full object-cover" />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center text-gray-300 text-lg">🃏</div>
                        )}
                      </div>
                      <div className="p-1">
                        <p className="text-[10px] font-medium text-gray-800 truncate leading-tight">{c.playerName || c.cardTitle}</p>
                        {(c.overallGrade || c.aiGrade) && (
                          <p className="text-[10px] text-amber-600 font-bold">SCG {c.overallGrade || c.aiGrade}</p>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* ── Trade Inbox / History ── */}
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
          <Tabs defaultValue="inbox">
            <div className="px-4 pt-4 border-b border-gray-100">
              <TabsList className="bg-gray-100 rounded-xl">
                <TabsTrigger value="inbox" className="rounded-lg gap-1.5 data-[state=active]:bg-white data-[state=active]:shadow-sm">
                  <Inbox className="w-4 h-4" />
                  Inbox
                  {pendingCount > 0 && (
                    <span className="ml-1 bg-red-500 text-white text-xs font-bold w-5 h-5 rounded-full flex items-center justify-center">
                      {pendingCount}
                    </span>
                  )}
                </TabsTrigger>
                <TabsTrigger value="sent" className="rounded-lg gap-1.5 data-[state=active]:bg-white data-[state=active]:shadow-sm">
                  <Send className="w-4 h-4" />
                  Sent
                </TabsTrigger>
                <TabsTrigger value="history" className="rounded-lg gap-1.5 data-[state=active]:bg-white data-[state=active]:shadow-sm">
                  <History className="w-4 h-4" />
                  History
                </TabsTrigger>
              </TabsList>
            </div>

            {/* Inbox */}
            <TabsContent value="inbox" className="p-4">
              {tradesLoading ? (
                <div className="text-center py-8 text-gray-400 text-sm">Loading...</div>
              ) : incoming.filter(t => !["completed", "rejected", "cancelled"].includes(t.status)).length === 0 ? (
                <div className="text-center py-12 text-gray-400">
                  <Inbox className="w-10 h-10 mx-auto mb-2 opacity-30" />
                  <p className="text-sm">No incoming trade offers.</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {incoming
                    .filter(t => !["completed", "rejected", "cancelled"].includes(t.status))
                    .map(t => (
                      <TradeRow
                        key={t.id}
                        trade={t}
                        myEmail={user?.email ?? ""}
                        onAccept={["pending", "countered"].includes(t.status) ? () => respondMutation.mutate({ id: t.id, status: "accepted" }) : undefined}
                        onDecline={["pending", "countered"].includes(t.status) ? () => respondMutation.mutate({ id: t.id, status: "rejected" }) : undefined}
                        onCounter={["pending", "countered"].includes(t.status) ? () => setCounterTrade(t) : undefined}
                        onViewAgreement={["agreed", "fee_pending", "paid_ready_to_ship", "shipped"].includes(t.status) ? () => {} : undefined}
                      />
                    ))}
                </div>
              )}
            </TabsContent>

            {/* Sent */}
            <TabsContent value="sent" className="p-4">
              {outgoing.filter(t => !["completed", "rejected", "cancelled"].includes(t.status)).length === 0 ? (
                <div className="text-center py-12 text-gray-400">
                  <Send className="w-10 h-10 mx-auto mb-2 opacity-30" />
                  <p className="text-sm">No active outgoing offers.</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {outgoing
                    .filter(t => !["completed", "rejected", "cancelled"].includes(t.status))
                    .map(t => (
                      <TradeRow
                        key={t.id}
                        trade={t}
                        myEmail={user?.email ?? ""}
                        onDecline={t.status === "pending" ? () => respondMutation.mutate({ id: t.id, status: "cancelled" }) : undefined}
                        onViewAgreement={["agreed", "fee_pending", "paid_ready_to_ship", "shipped"].includes(t.status) ? () => {} : undefined}
                      />
                    ))}
                </div>
              )}
            </TabsContent>

            {/* History */}
            <TabsContent value="history" className="p-4">
              {(myTrades as any[]).filter(t => ["completed", "rejected", "cancelled"].includes(t.status)).length === 0 ? (
                <div className="text-center py-12 text-gray-400">
                  <History className="w-10 h-10 mx-auto mb-2 opacity-30" />
                  <p className="text-sm">No completed trades yet.</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {(myTrades as any[])
                    .filter(t => ["completed", "rejected", "cancelled"].includes(t.status))
                    .map(t => (
                      <TradeRow key={t.id} trade={t} myEmail={user?.email ?? ""} />
                    ))}
                </div>
              )}
            </TabsContent>
          </Tabs>
        </div>
      </div>

      {/* ── Counter-Offer Dialog ── */}
      {counterTrade && (
        <CounterDialog
          trade={counterTrade}
          myEmail={user?.email ?? ""}
          myCards={myCollection as CardItem[]}
          open={!!counterTrade}
          onClose={() => setCounterTrade(null)}
          onSuccess={() => utils.trades.myTrades.invalidate()}
        />
      )}

      {/* ── eBay Block Dialog ── */}
      <Dialog open={!!ebayBlock} onOpenChange={() => setEbayBlock(null)}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-amber-700">
              <AlertCircle className="w-5 h-5" /> eBay Import — Not Tradeable
            </DialogTitle>
          </DialogHeader>
          <p className="text-sm text-gray-600">
            <strong>{ebayBlock}</strong> was imported from eBay and cannot be traded on this platform. Only cards graded or listed directly on SportCardsOnline are eligible for trades.
          </p>
          <DialogFooter>
            <Button onClick={() => setEbayBlock(null)} className="rounded-xl">Got it</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
