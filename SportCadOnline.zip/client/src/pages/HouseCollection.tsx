import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Award, Search, Camera, Gavel, Trash2, Settings,
  Package, Tag, Pencil, BarChart2, Eye,
  Filter, RefreshCw,
  ChevronLeft, ChevronRight, ArrowUpDown, Shield, Dice5,
  CheckSquare, Square, X, Layers
} from "lucide-react";
import { useState, useMemo, useCallback } from "react";
import { Link } from "wouter";
import { toast } from "sonner";

// ─── Status config ─────────────────────────────────────────────────────────────
const STATUS_CFG: Record<string, { label: string; color: string }> = {
  bank:    { label: "House",   color: "bg-indigo-500/20 text-indigo-300 border-indigo-500/30" },
  draft:   { label: "Draft",   color: "bg-gray-500/20 text-gray-400 border-gray-500/30" },
  active:  { label: "Listed",  color: "bg-green-500/20 text-green-400 border-green-500/30" },
  auction: { label: "Auction", color: "bg-orange-500/20 text-orange-400 border-orange-500/30" },
  casino:  { label: "Casino",  color: "bg-yellow-500/20 text-yellow-300 border-yellow-500/30" },
  sold:    { label: "Sold",    color: "bg-blue-500/20 text-blue-400 border-blue-500/30" },
  traded:  { label: "Traded",  color: "bg-purple-500/20 text-purple-400 border-purple-500/30" },
};

const PAGE_SIZE = 50;

// ─── Edit Card dialog ──────────────────────────────────────────────────────────
function EditCardDialog({ card, onDone }: { card: any; onDone: () => void }) {
  const [open, setOpen] = useState(false);
  const [price, setPrice] = useState(card.price ? parseFloat(card.price).toFixed(2) : "");
  const [grade, setGrade] = useState(card.aiGrade ? String(card.aiGrade) : "");
  const [status, setStatus] = useState(card.status ?? "bank");
  const adminUpdate = trpc.admin.adminUpdateCard.useMutation({
    onSuccess: () => { toast.success("Card updated"); setOpen(false); onDone(); },
    onError: (e: any) => toast.error(e.message),
  });
  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <button className="p-1 rounded hover:bg-white/10 text-white/40 hover:text-white transition-colors" title="Edit">
          <Pencil className="w-3 h-3" />
        </button>
      </DialogTrigger>
      <DialogContent className="max-w-sm">
        <DialogHeader><DialogTitle>Edit Card</DialogTitle></DialogHeader>
        <div className="space-y-3 pt-1">
          <p className="text-sm text-muted-foreground font-medium">{card.playerName} — {card.title}</p>
          <div>
            <label className="text-xs font-medium text-white/60 mb-1 block">Price ($)</label>
            <Input value={price} onChange={e => setPrice(e.target.value)} placeholder="e.g. 49.99" type="number" step="0.01" />
          </div>
          <div>
            <label className="text-xs font-medium text-white/60 mb-1 block">Grade (e.g. 9.5)</label>
            <Input value={grade} onChange={e => setGrade(e.target.value)} placeholder="e.g. 9.5" />
          </div>
          <div>
            <label className="text-xs font-medium text-white/60 mb-1 block">Status</label>
            <Select value={status} onValueChange={setStatus}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {Object.entries(STATUS_CFG).map(([v, c]) => (
                  <SelectItem key={v} value={v}>{c.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <Button className="w-full bg-[#c41e3a] hover:bg-[#a01830] text-white" disabled={adminUpdate.isPending}
            onClick={() => adminUpdate.mutate({ cardId: card.id, price: price || undefined, aiGrade: grade || undefined, status })}>
            {adminUpdate.isPending ? "Saving..." : "Save Changes"}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

// ─── List to Arena dialog (110% of vault price) ────────────────────────────────
function ListDialog({ card, onDone }: { card: any; onDone: () => void }) {
  const [open, setOpen] = useState(false);
  const vaultPrice = card.price ? parseFloat(String(card.price)) : 0;
  const suggestedPrice = (vaultPrice * 1.10).toFixed(2);
  const [price, setPrice] = useState(suggestedPrice);
  const adminUpdate = trpc.admin.adminUpdateCard.useMutation({
    onSuccess: () => { toast.success("Card listed in Arena!"); setOpen(false); onDone(); },
    onError: (e: any) => toast.error(e.message),
  });
  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <button className="p-1 rounded hover:bg-white/10 text-white/40 hover:text-green-400 transition-colors" title="List in Arena">
          <Tag className="w-3 h-3" />
        </button>
      </DialogTrigger>
      <DialogContent className="max-w-sm">
        <DialogHeader><DialogTitle>List in the Arena</DialogTitle></DialogHeader>
        <div className="space-y-3 pt-1">
          <p className="text-sm text-muted-foreground">{card.playerName} — {card.title}</p>
          {vaultPrice > 0 && (
            <div className="bg-green-500/10 border border-green-500/20 rounded-lg p-3 text-xs">
              <p className="text-green-300 font-semibold">House Pricing</p>
              <p className="text-white/60 mt-0.5">House price: <span className="text-white font-bold">${vaultPrice.toFixed(2)}</span> → Suggested list price: <span className="text-white font-bold">${suggestedPrice}</span> (110%)</p>
            </div>
          )}
          <div>
            <label className="text-xs font-medium text-white/60 mb-1 block">Listing Price ($)</label>
            <Input value={price} onChange={e => setPrice(e.target.value)} placeholder="e.g. 49.99" type="number" step="0.01" />
          </div>
          <Button className="w-full bg-green-600 hover:bg-green-500 text-white" disabled={adminUpdate.isPending || !price}
            onClick={() => adminUpdate.mutate({ cardId: card.id, price, status: "active" })}>
            {adminUpdate.isPending ? "Listing..." : "🏟️ List in Arena"}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

// ─── Auction dialog (70% of vault price, 5 days) ──────────────────────────────
function AuctionDialog({ card, onDone }: { card: any; onDone: () => void }) {
  const [open, setOpen] = useState(false);
  const vaultPrice = card.price ? parseFloat(String(card.price)) : 0;
  const suggestedBid = (vaultPrice * 0.70).toFixed(2);
  const [startPrice, setStartPrice] = useState(suggestedBid);
  const createAuction = trpc.auctions.create.useMutation({
    onSuccess: () => { toast.success("Auction started!"); setOpen(false); onDone(); },
    onError: (e: any) => toast.error(e.message),
  });
  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <button className="p-1 rounded hover:bg-white/10 text-white/40 hover:text-orange-400 transition-colors" title="Send to Auction">
          <Gavel className="w-3 h-3" />
        </button>
      </DialogTrigger>
      <DialogContent className="max-w-sm">
        <DialogHeader><DialogTitle>Send to Auction</DialogTitle></DialogHeader>
        <div className="space-y-3 pt-1">
          <p className="text-sm text-muted-foreground">{card.playerName} — {card.title}</p>
          {vaultPrice > 0 && (
            <div className="bg-orange-500/10 border border-orange-500/20 rounded-lg p-3 text-xs">
              <p className="text-orange-300 font-semibold">House Auction Rules</p>
              <p className="text-white/60 mt-0.5">House price: <span className="text-white font-bold">${vaultPrice.toFixed(2)}</span> → Starting bid: <span className="text-white font-bold">${suggestedBid}</span> (70%)</p>
              <p className="text-white/60 mt-0.5">Duration: <span className="text-white font-bold">5 days</span></p>
            </div>
          )}
          <div>
            <label className="text-xs font-medium text-white/60 mb-1 block">Starting Bid ($)</label>
            <Input value={startPrice} onChange={e => setStartPrice(e.target.value)} type="number" step="0.01" />
          </div>
          <Button className="w-full bg-orange-600 hover:bg-orange-500 text-white" disabled={createAuction.isPending || !startPrice}
            onClick={() => createAuction.mutate({
              cardId: card.id,
              cardTitle: card.title,
              cardImageUrl: card.frontImageUrl ?? undefined,
              startingPrice: startPrice,
              durationDays: 5,
              playerName: card.playerName ?? undefined,
              gradeInfo: card.aiGrade ? `SCG ${card.aiGrade}` : undefined,
            })}>
            {createAuction.isPending ? "Starting..." : "🔨 Start Auction"}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

// ─── Assign to Casino dialog ───────────────────────────────────────────────────
function AssignCasinoDialog({ card, onDone }: { card: any; onDone: () => void }) {
  const [open, setOpen] = useState(false);
  const isInCasino = card.status === "casino";
  const adminUpdate = trpc.admin.adminUpdateCard.useMutation({
    onSuccess: () => { toast.success(isInCasino ? "Card returned to House" : "Card assigned to Casino!"); setOpen(false); onDone(); },
    onError: (e: any) => toast.error(e.message),
  });
  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <button
          className={`p-1 rounded hover:bg-white/10 transition-colors ${isInCasino ? "text-yellow-400" : "text-white/40 hover:text-yellow-400"}`}
          title={isInCasino ? "Remove from Casino" : "Assign to Casino"}>
          <Dice5 className="w-3 h-3" />
        </button>
      </DialogTrigger>
      <DialogContent className="max-w-sm">
        <DialogHeader><DialogTitle>{isInCasino ? "Remove from Casino" : "Assign to Casino"}</DialogTitle></DialogHeader>
        <div className="space-y-3 pt-1">
          <p className="text-sm text-muted-foreground">{card.playerName} — {card.title}</p>
          {!isInCasino ? (
            <div className="bg-yellow-500/10 border border-yellow-500/20 rounded-lg p-3 text-xs">
              <p className="text-yellow-300 font-semibold">SCO Game Room Assignment</p>
              <p className="text-white/60 mt-0.5">This card will be available as a prize in the SCO Casino Game Room.</p>
            </div>
          ) : (
            <div className="bg-indigo-500/10 border border-indigo-500/20 rounded-lg p-3 text-xs">
              <p className="text-indigo-300">Card will be returned to House.</p>
            </div>
          )}
          <Button
            className={`w-full text-white ${isInCasino ? "bg-indigo-600 hover:bg-indigo-500" : "bg-yellow-600 hover:bg-yellow-500"}`}
            disabled={adminUpdate.isPending}
            onClick={() => adminUpdate.mutate({ cardId: card.id, status: isInCasino ? "bank" : "casino" })}>
            {adminUpdate.isPending ? "Updating..." : isInCasino ? "↩ Return to House" : "🎰 Assign to Casino"}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

// ─── Card actions ──────────────────────────────────────────────────────────────
function CardActions({ card, refetch, deleteCard }: { card: any; refetch: () => void; deleteCard: any }) {
  const canList = !["active", "auction", "sold"].includes(card.status ?? "");
  const canAuction = !["auction", "sold"].includes(card.status ?? "");
  return (
    <div className="flex items-center gap-1">
      <EditCardDialog card={card} onDone={refetch} />
      {canList && <ListDialog card={card} onDone={refetch} />}
      {canAuction && <AuctionDialog card={card} onDone={refetch} />}
      <AssignCasinoDialog card={card} onDone={refetch} />
      <a href={`/card/${card.id}`} className="p-1 rounded hover:bg-white/10 text-white/40 hover:text-blue-400 transition-colors" title="View Card">
        <Eye className="w-3 h-3" />
      </a>
      <button className="p-1 rounded hover:bg-white/10 text-white/40 hover:text-red-400 transition-colors"
        onClick={() => { if (confirm(`Delete "${card.title}"?`)) deleteCard.mutate({ cardId: card.id }); }}>
        <Trash2 className="w-3 h-3" />
      </button>
    </div>
  );
}

// ─── Bulk Action Toolbar ───────────────────────────────────────────────────────
function BulkToolbar({
  selectedIds,
  onClearSelection,
  onBulkVault,
  onBulkCasino,
  onBulkArena,
  onBulkAuction,
  onBulkDelete,
  isPending,
}: {
  selectedIds: Set<number>;
  onClearSelection: () => void;
  onBulkVault: () => void;
  onBulkCasino: () => void;
  onBulkArena: () => void;
  onBulkAuction: () => void;
  onBulkDelete: () => void;
  isPending: boolean;
}) {
  const count = selectedIds.size;
  if (count === 0) return null;
  return (
    <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 flex items-center gap-2 bg-[#1a1f35] border border-white/20 rounded-2xl px-4 py-3 shadow-2xl shadow-black/60">
      <span className="text-sm font-bold text-white mr-2">{count} selected</span>
      <Button size="sm" variant="outline"
        className="border-indigo-500/40 text-indigo-300 hover:bg-indigo-500/20 gap-1.5"
        disabled={isPending} onClick={onBulkVault}>
        <Package className="w-3.5 h-3.5" />Move to House
      </Button>
      <Button size="sm" variant="outline"
        className="border-yellow-500/40 text-yellow-300 hover:bg-yellow-500/20 gap-1.5"
        disabled={isPending} onClick={onBulkCasino}>
        <Dice5 className="w-3.5 h-3.5" />Assign Casino
      </Button>
      <Button size="sm" variant="outline"
        className="border-green-500/40 text-green-300 hover:bg-green-500/20 gap-1.5"
        disabled={isPending} onClick={onBulkArena}>
        <Tag className="w-3.5 h-3.5" />List in Arena
      </Button>
      <Button size="sm" variant="outline"
        className="border-orange-500/40 text-orange-300 hover:bg-orange-500/20 gap-1.5"
        disabled={isPending} onClick={onBulkAuction}>
        <Gavel className="w-3.5 h-3.5" />Send to Auction
      </Button>
      <Button size="sm" variant="outline"
        className="border-red-500/40 text-red-400 hover:bg-red-500/20 gap-1.5"
        disabled={isPending} onClick={onBulkDelete}>
        <Trash2 className="w-3.5 h-3.5" />Delete
      </Button>
      <button onClick={onClearSelection} className="ml-1 p-1 rounded-full hover:bg-white/10 text-white/40 hover:text-white transition-colors">
        <X className="w-4 h-4" />
      </button>
    </div>
  );
}

// ─── Main page ─────────────────────────────────────────────────────────────────
export default function HouseCollection() {
  const { isAuthenticated } = useAuth();
  const [search, setSearch] = useState("");
  const [sportFilter, setSportFilter] = useState("all");
  const [statusFilter, setStatusFilter] = useState("all");
  const [sortBy, setSortBy] = useState("newest");
  const [viewMode, setViewMode] = useState<"grid" | "list">("list");
  const [page, setPage] = useState(1);
  // Source tab: "house" | "ebay"
  const [sourceTab, setSourceTab] = useState<"all" | "house" | "ebay">("house");

  // ── Bulk selection state ──
  const [selectedIds, setSelectedIds] = useState<Set<number>>(new Set());

  // ── Server-side paginated query (ALL house cards, all statuses) ──
  const queryInput = useMemo(() => ({
    search: search || undefined,
    status: statusFilter !== "all" ? statusFilter : undefined,
    sport: sportFilter !== "all" ? sportFilter : undefined,
    source: sourceTab !== "all" ? sourceTab as "house" | "ebay" : undefined,
    limit: PAGE_SIZE,
    offset: (page - 1) * PAGE_SIZE,
    sortBy: ({ newest: "newest", oldest: "oldest", price_hi: "price_high", price_lo: "price_low", player: "player" } as Record<string, any>)[sortBy] ?? "newest",
  }), [search, statusFilter, sportFilter, sourceTab, page, sortBy]);

  const { data: houseData, isLoading, refetch } = trpc.admin.houseCards.useQuery(queryInput, { enabled: isAuthenticated });
  const paginated = houseData?.cards ?? [];
  const totalFiltered = houseData?.total ?? 0;
  const byStatus = houseData?.byStatus ?? {};
  const deleteCard = trpc.admin.deleteCardAdmin.useMutation({
    onSuccess: () => { toast.success("Card deleted"); refetch(); },
    onError: (e: any) => toast.error(e.message),
  });

  // Bulk mutations
  const bulkUpdateStatus = trpc.admin.bulkUpdateCardStatus.useMutation({
    onSuccess: (data) => {
      toast.success(`Updated ${data.updated} cards`);
      setSelectedIds(new Set());
      refetch();
    },
    onError: (e: any) => toast.error(e.message),
  });
  const bulkDelete = trpc.admin.bulkDeleteCards.useMutation({
    onSuccess: (data) => {
      toast.success(`Deleted ${data.deleted} cards`);
      setSelectedIds(new Set());
      refetch();
    },
    onError: (e: any) => toast.error(e.message),
  });

  const isBulkPending = bulkUpdateStatus.isPending || bulkDelete.isPending;

  // Stats from full-collection byStatus breakdown (always shows all 753 cards)
  const stats = useMemo(() => ({
    total: Object.values(byStatus).reduce((s: number, v) => s + Number(v), 0),
    vault:   Number(byStatus["bank"] ?? 0),
    listed:  Number(byStatus["active"] ?? 0),
    auction: Number(byStatus["auction"] ?? 0),
    casino:  Number(byStatus["casino"] ?? 0),
    sold:    Number(byStatus["sold"] ?? 0),
    value:   paginated.reduce((sum: number, c: any) => sum + (c.price ? parseFloat(String(c.price)) : 0), 0),
  }), [byStatus, paginated]);

  const totalPages = Math.max(1, Math.ceil(totalFiltered / PAGE_SIZE));
  const resetPage = () => setPage(1);

  // ── Selection helpers ──
  const pageIds = paginated.map(c => c.id);
  const allPageSelected = pageIds.length > 0 && pageIds.every(id => selectedIds.has(id));
  const somePageSelected = pageIds.some(id => selectedIds.has(id));

  function toggleCard(id: number) {
    setSelectedIds(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  }

  function toggleSelectAll() {
    if (allPageSelected) {
      // Deselect all on this page
      setSelectedIds(prev => {
        const next = new Set(prev);
        pageIds.forEach(id => next.delete(id));
        return next;
      });
    } else {
      // Select all on this page
      setSelectedIds(prev => {
        const next = new Set(prev);
        pageIds.forEach(id => next.add(id));
        return next;
      });
    }
  }

  // ── Bulk action handlers ──
  function handleBulkVault() {
    if (!confirm(`Move ${selectedIds.size} cards to House?`)) return;
    bulkUpdateStatus.mutate({ ids: Array.from(selectedIds), status: "bank" });
  }
  function handleBulkCasino() {
    if (!confirm(`Assign ${selectedIds.size} cards to Casino?`)) return;
    bulkUpdateStatus.mutate({ ids: Array.from(selectedIds), status: "casino" });
  }
  function handleBulkArena() {
    if (!confirm(`List ${selectedIds.size} cards in the Arena (status → active)? You can update individual prices afterwards.`)) return;
    bulkUpdateStatus.mutate({ ids: Array.from(selectedIds), status: "active" });
  }
  function handleBulkAuction() {
    if (!confirm(`Send ${selectedIds.size} cards to Auction (status → auction)? Each will be listed at 70% of house price.`)) return;
    bulkUpdateStatus.mutate({ ids: Array.from(selectedIds), status: "auction" });
  }
  function handleBulkDelete() {
    if (!confirm(`Permanently delete ${selectedIds.size} cards? This cannot be undone.`)) return;
    bulkDelete.mutate({ ids: Array.from(selectedIds) });
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-[#0a0f1e] flex items-center justify-center">
        <div className="text-center">
          <Shield className="w-16 h-16 text-white/10 mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-white mb-2">House Collection</h2>
          <p className="text-white/40 mb-6">Admin access required.</p>
          <Button asChild className="bg-[#c41e3a] text-white"><a href={getLoginUrl()}>Sign In</a></Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0a0f1e] text-white">
      <div className="max-w-[1600px] mx-auto px-4 py-6">

        {/* ── Header ── */}
        <div className="flex flex-wrap items-start justify-between gap-4 mb-6">
          <div>
            <h1 className="text-2xl font-bold flex items-center gap-2">
              <Shield className="w-6 h-6 text-[#c41e3a]" />
              House Collection
            </h1>
            <p className="text-white/40 text-sm mt-0.5">SCO CRM — house · casino · auction · marketplace</p>
          </div>
          <div className="flex flex-wrap gap-2">
            <Button asChild size="sm" className="bg-[#c41e3a] hover:bg-[#a01830] text-white gap-1.5">
              <Link href="/grade"><Camera className="w-3.5 h-3.5" />Grade a Card</Link>
            </Button>
            <Button asChild size="sm" variant="outline" className="border-white/20 text-white/70 hover:bg-white/10 gap-1.5">
              <Link href="/admin"><Settings className="w-3.5 h-3.5" />Admin Panel</Link>
            </Button>
            <Button asChild size="sm" variant="outline" className="border-white/20 text-white/70 hover:bg-white/10 gap-1.5">
              <Link href="/auctions"><Gavel className="w-3.5 h-3.5" />Live Auctions</Link>
            </Button>
            <Button size="sm" variant="outline" className="border-white/20 text-white/70 hover:bg-white/10 gap-1.5" onClick={() => refetch()}>
              <RefreshCw className="w-3.5 h-3.5" />Refresh
            </Button>
          </div>
        </div>

        {/* ── Source Tabs ── */}
        <div className="flex gap-1 mb-5 bg-white/5 rounded-xl p-1 w-fit">
          {([
            { key: "house", label: "House Cards",  count: null },
            { key: "ebay",  label: "eBay Cards",   count: null },
          ] as const).map(tab => (
            <button
              key={tab.key}
              onClick={() => { setSourceTab(tab.key); resetPage(); }}
              className={`px-4 py-1.5 rounded-lg text-sm font-medium transition-all ${
                sourceTab === tab.key
                  ? "bg-[#c41e3a] text-white shadow"
                  : "text-white/50 hover:text-white hover:bg-white/5"
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* ── Stats bar ── */}
        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-3 mb-6">
          {[
            { label: "Total",       value: stats.total,   color: "text-white",       border: "border-white/10",         status: "all" },
            { label: "House",       value: stats.vault,   color: "text-indigo-300",  border: "border-indigo-500/20",    status: "bank" },
            { label: "Listed",      value: stats.listed,  color: "text-green-400",   border: "border-green-500/20",     status: "active" },
            { label: "Auction",     value: stats.auction, color: "text-orange-400",  border: "border-orange-500/20",    status: "auction" },
            { label: "Casino",      value: stats.casino,  color: "text-yellow-300",  border: "border-yellow-500/20",    status: "casino" },
            { label: "Sold",        value: stats.sold,    color: "text-blue-400",    border: "border-blue-500/20",      status: "sold" },
            { label: "Inventory $", value: `$${stats.value.toLocaleString("en-US", { maximumFractionDigits: 0 })}`, color: "text-yellow-400", border: "border-yellow-500/20", status: null },
          ].map(({ label, value, color, border, status }) => (
            <button key={label}
              onClick={() => { if (status !== null) { setStatusFilter(status); resetPage(); } }}
              className={`bg-white/5 border ${border} rounded-xl p-3 text-left transition-all hover:bg-white/8 ${statusFilter === status ? "ring-1 ring-white/20" : ""} ${status !== null ? "cursor-pointer" : "cursor-default"}`}>
              <p className="text-[10px] text-white/40 uppercase tracking-wider mb-1">{label}</p>
              <p className={`text-xl font-bold ${color}`}>{value}</p>
            </button>
          ))}
        </div>

        {/* ── Filters ── */}
        <div className="flex flex-wrap gap-2 mb-4">
          <div className="relative flex-1 min-w-[200px]">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/30" />
            <Input
              value={search}
              onChange={e => { setSearch(e.target.value); resetPage(); }}
              placeholder="Search player, set, year, cert#..."
              className="pl-9 bg-white/5 border-white/10 text-white placeholder:text-white/30"
            />
          </div>
          <Select value={statusFilter} onValueChange={v => { setStatusFilter(v); resetPage(); }}>
            <SelectTrigger className="w-36 bg-white/5 border-white/10 text-white/70">
              <Filter className="w-3.5 h-3.5 mr-1.5" /><SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              {Object.entries(STATUS_CFG).map(([v, c]) => (
                <SelectItem key={v} value={v}>{c.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={sportFilter} onValueChange={v => { setSportFilter(v); resetPage(); }}>
            <SelectTrigger className="w-36 bg-white/5 border-white/10 text-white/70">
              <SelectValue placeholder="Sport" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Sports</SelectItem>
              {["baseball","basketball","football","hockey","soccer","golf","other"].map(s => (
                <SelectItem key={s} value={s} className="capitalize">{s}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={sortBy} onValueChange={v => { setSortBy(v); resetPage(); }}>
            <SelectTrigger className="w-40 bg-white/5 border-white/10 text-white/70">
              <ArrowUpDown className="w-3.5 h-3.5 mr-1.5" /><SelectValue placeholder="Sort" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="newest">Newest First</SelectItem>
              <SelectItem value="oldest">Oldest First</SelectItem>
              <SelectItem value="player">Player A–Z</SelectItem>
              <SelectItem value="price_hi">Price: High → Low</SelectItem>
              <SelectItem value="price_lo">Price: Low → High</SelectItem>
              <SelectItem value="grade_hi">Grade: High → Low</SelectItem>
              <SelectItem value="status">By Status</SelectItem>
            </SelectContent>
          </Select>
          <div className="flex gap-1">
            <Button size="sm" variant={viewMode === "list" ? "default" : "outline"}
              className={viewMode === "list" ? "bg-[#c41e3a] text-white" : "border-white/20 text-white/50 hover:bg-white/10"}
              onClick={() => setViewMode("list")} title="List view">
              <Package className="w-3.5 h-3.5" />
            </Button>
            <Button size="sm" variant={viewMode === "grid" ? "default" : "outline"}
              className={viewMode === "grid" ? "bg-[#c41e3a] text-white" : "border-white/20 text-white/50 hover:bg-white/10"}
              onClick={() => setViewMode("grid")} title="Grid view">
              <BarChart2 className="w-3.5 h-3.5" />
            </Button>
          </div>
        </div>

        {/* ── Result count + select-all row ── */}
        {!isLoading && totalFiltered > 0 && (
          <div className="flex items-center justify-between mb-3">
            <p className="text-xs text-white/30">
              {totalFiltered === stats.total
                ? `${totalFiltered} cards total`
                : `${totalFiltered} of ${stats.total} cards`}
              {totalPages > 1 && ` · Page ${page} of ${totalPages}`}
              {selectedIds.size > 0 && <span className="text-[#c41e3a] font-bold ml-2">· {selectedIds.size} selected</span>}
            </p>
            <button
              onClick={toggleSelectAll}
              className="flex items-center gap-1.5 text-xs text-white/50 hover:text-white transition-colors"
            >
              {allPageSelected
                ? <CheckSquare className="w-3.5 h-3.5 text-[#c41e3a]" />
                : somePageSelected
                  ? <Layers className="w-3.5 h-3.5 text-white/40" />
                  : <Square className="w-3.5 h-3.5" />}
              {allPageSelected ? "Deselect page" : "Select page"}
            </button>
          </div>
        )}

        {/* ── Loading skeleton ── */}
        {isLoading && (
          <div className="space-y-1">
            {Array.from({ length: 10 }).map((_, i) => (
              <div key={i} className="h-14 bg-white/5 rounded-lg animate-pulse" />
            ))}
          </div>
        )}

        {/* ── List View ── */}
        {!isLoading && viewMode === "list" && paginated.length > 0 && (
          <div className="space-y-1">
            <div className="grid grid-cols-[28px_40px_2fr_1fr_1fr_1fr_1fr_auto] gap-3 px-3 py-1.5 text-[10px] text-white/30 uppercase tracking-wider border-b border-white/5">
              <span></span><span></span><span>Card</span><span>Sport</span><span>Grade</span><span>Price</span><span>Status</span><span>Actions</span>
            </div>
            {paginated.map(card => {
              const scfg = STATUS_CFG[card.status ?? "draft"] ?? STATUS_CFG.draft;
              const isSelected = selectedIds.has(card.id);
              return (
                <div key={card.id}
                  className={`grid grid-cols-[28px_40px_2fr_1fr_1fr_1fr_1fr_auto] gap-3 items-center px-3 py-2 rounded-lg border transition-all group cursor-pointer
                    ${isSelected
                      ? "bg-[#c41e3a]/10 border-[#c41e3a]/30"
                      : "bg-white/3 hover:bg-white/5 border-white/5 hover:border-white/10"}`}
                  onClick={() => toggleCard(card.id)}
                >
                  {/* Checkbox */}
                  <div className="flex items-center justify-center" onClick={e => e.stopPropagation()}>
                    <button onClick={() => toggleCard(card.id)} className="text-white/40 hover:text-white transition-colors">
                      {isSelected
                        ? <CheckSquare className="w-4 h-4 text-[#c41e3a]" />
                        : <Square className="w-4 h-4" />}
                    </button>
                  </div>
                  {/* Image */}
                  <div className="w-8 h-11 bg-white/5 rounded overflow-hidden shrink-0">
                    {card.frontImageUrl
                      ? <img src={card.frontImageUrl} alt={card.title} className="w-full h-full object-cover" />
                      : <div className="w-full h-full flex items-center justify-center"><Award className="w-4 h-4 text-white/10" /></div>}
                  </div>
                  <div className="min-w-0">
                    <p className="font-semibold text-sm truncate">{card.playerName}</p>
                    <p className="text-[10px] text-white/40 truncate">{card.year} {card.setName || card.title}</p>
                    {card.certNumber && <p className="text-[9px] text-white/25 font-mono">{card.certNumber}</p>}
                  </div>
                  <span className="text-sm text-white/60 capitalize">{card.sport}</span>
                  <span className="text-sm font-bold text-white/80">{card.aiGrade ? parseFloat(String(card.aiGrade)).toFixed(1) : "—"}</span>
                  <span className="text-sm font-bold text-green-400">{card.price ? `$${parseFloat(String(card.price)).toFixed(2)}` : "—"}</span>
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${scfg.color}`}>{scfg.label}</span>
                  <div className="opacity-0 group-hover:opacity-100 transition-opacity" onClick={e => e.stopPropagation()}>
                    <CardActions card={card} refetch={refetch} deleteCard={deleteCard} />
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* ── Grid View ── */}
        {!isLoading && viewMode === "grid" && paginated.length > 0 && (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3">
            {paginated.map(card => {
              const scfg = STATUS_CFG[card.status ?? "draft"] ?? STATUS_CFG.draft;
              const isSelected = selectedIds.has(card.id);
              return (
                <div key={card.id}
                  className={`group relative bg-white/5 border rounded-xl overflow-hidden transition-all cursor-pointer
                    ${isSelected ? "border-[#c41e3a]/60 ring-2 ring-[#c41e3a]/30" : "border-white/10 hover:border-white/20"}`}
                  onClick={() => toggleCard(card.id)}
                >
                  {/* Checkbox overlay */}
                  <div className="absolute top-2 left-2 z-10" onClick={e => e.stopPropagation()}>
                    <button onClick={() => toggleCard(card.id)} className="text-white/60 hover:text-white transition-colors drop-shadow-lg">
                      {isSelected
                        ? <CheckSquare className="w-4 h-4 text-[#c41e3a]" />
                        : <Square className="w-4 h-4 opacity-0 group-hover:opacity-100 transition-opacity" />}
                    </button>
                  </div>
                  <div className="aspect-[2/3] bg-white/5 relative overflow-hidden">
                    {card.frontImageUrl
                      ? <img src={card.frontImageUrl} alt={card.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" />
                      : <div className="w-full h-full flex items-center justify-center"><Award className="w-10 h-10 text-white/10" /></div>}
                    <span className={`absolute top-1.5 right-1.5 text-[8px] font-bold px-1.5 py-0.5 rounded-full border leading-none ${scfg.color}`}>{scfg.label}</span>
                    {card.aiGrade && (
                      <span className="absolute bottom-1.5 right-1.5 text-[8px] font-bold px-1.5 py-0.5 rounded-full bg-black/60 text-white border border-white/20 leading-none">
                        {parseFloat(String(card.aiGrade)).toFixed(1)}
                      </span>
                    )}
                    <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center" onClick={e => e.stopPropagation()}>
                      <CardActions card={card} refetch={refetch} deleteCard={deleteCard} />
                    </div>
                  </div>
                  <div className="p-2">
                    <p className="font-semibold text-xs truncate">{card.playerName}</p>
                    <p className="text-[10px] text-white/40 truncate">{card.year} {card.setName || ""}</p>
                    <p className="text-sm font-bold text-green-400 mt-0.5">{card.price ? `$${parseFloat(String(card.price)).toFixed(2)}` : "—"}</p>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* ── Empty state ── */}
        {!isLoading && paginated.length === 0 && (
          <div className="text-center py-20">
            <Award className="w-20 h-20 text-white/5 mx-auto mb-4" />
            {stats.total > 0 ? (
              <>
                <h3 className="text-xl font-bold mb-2">No cards match your filters</h3>
                <Button variant="outline" className="border-white/20 text-white/60 hover:bg-white/10"
                  onClick={() => { setSearch(""); setStatusFilter("all"); setSportFilter("all"); resetPage(); }}>
                  Clear Filters
                </Button>
              </>
            ) : (
              <>
                <h3 className="text-xl font-bold mb-2">House Collection is empty</h3>
                <p className="text-white/40 mb-6">Grade a card or add one via the Admin Panel to get started.</p>
                <div className="flex flex-wrap gap-3 justify-center">
                  <Button asChild className="bg-[#c41e3a] hover:bg-[#a01830] text-white gap-2">
                    <Link href="/grade"><Camera className="w-4 h-4" />Grade a Card</Link>
                  </Button>
                  <Button asChild variant="outline" className="border-white/20 text-white/70 hover:bg-white/10 gap-2">
                    <Link href="/admin"><Settings className="w-4 h-4" />Admin Panel</Link>
                  </Button>
                </div>
              </>
            )}
          </div>
        )}

        {/* ── Pagination ── */}
        {totalPages > 1 && (
          <div className="flex items-center justify-between mt-6 pt-4 border-t border-white/10">
            <p className="text-xs text-white/40">Page {page} of {totalPages} · {totalFiltered} cards</p>
            <div className="flex items-center gap-2">
              <Button size="sm" variant="outline" className="border-white/20 text-white/60 hover:bg-white/10 gap-1"
                disabled={page === 1} onClick={() => setPage(p => p - 1)}>
                <ChevronLeft className="w-3.5 h-3.5" />Prev
              </Button>
              <div className="flex gap-1">
                {Array.from({ length: Math.min(7, totalPages) }, (_, i) => {
                  const start = Math.max(1, Math.min(totalPages - 6, page - 3));
                  const p = start + i;
                  if (p > totalPages) return null;
                  return (
                    <button key={p} onClick={() => setPage(p)}
                      className={`w-8 h-8 rounded text-xs font-medium transition-colors ${p === page ? "bg-[#c41e3a] text-white" : "text-white/40 hover:bg-white/10"}`}>
                      {p}
                    </button>
                  );
                })}
              </div>
              <Button size="sm" variant="outline" className="border-white/20 text-white/60 hover:bg-white/10 gap-1"
                disabled={page === totalPages} onClick={() => setPage(p => p + 1)}>
                Next<ChevronRight className="w-3.5 h-3.5" />
              </Button>
            </div>
          </div>
        )}

      </div>

      {/* ── Bulk Action Toolbar (floating) ── */}
      <BulkToolbar
        selectedIds={selectedIds}
        onClearSelection={() => setSelectedIds(new Set())}
        onBulkVault={handleBulkVault}
        onBulkCasino={handleBulkCasino}
        onBulkArena={handleBulkArena}
        onBulkAuction={handleBulkAuction}
        onBulkDelete={handleBulkDelete}
        isPending={isBulkPending}
      />
    </div>
  );
}
