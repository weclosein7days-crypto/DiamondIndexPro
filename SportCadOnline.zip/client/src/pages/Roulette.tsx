import { useState, useEffect, useRef, useCallback, useMemo } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

// ─── American Roulette: 38 pockets (0, 00, 1-36) ─────────────────────────────
const WHEEL_ORDER: (number | "00")[] = [
  0, 28, 9, 26, 30, 11, 7, 20, 32, 17, 5, 22, 34, 15, 3, 24, 36, 13, 1,
  "00", 27, 10, 25, 29, 12, 8, 19, 31, 18, 6, 21, 33, 16, 4, 23, 35, 14, 2,
];
const NUM_POCKETS = 38;
const DEG_PER_POCKET = 360 / NUM_POCKETS;
const REDS = new Set([1,3,5,7,9,12,14,16,18,19,21,23,25,27,30,32,34,36]);
// 20-second total spin duration
const SPIN_DURATION = 20000;

function getPocketColor(n: number | "00"): "green" | "red" | "black" {
  if (n === 0 || n === "00") return "green";
  return REDS.has(n as number) ? "red" : "black";
}

// ─── Sound Engine ─────────────────────────────────────────────────────────────
function createAudioCtx() {
  try { return new (window.AudioContext || (window as any).webkitAudioContext)(); } catch { return null; }
}

function playSpinSound(ctx: AudioContext): void {
  const dur = SPIN_DURATION / 1000;
  const sr = ctx.sampleRate;
  const buf = ctx.createBuffer(1, Math.floor(sr * dur), sr);
  const d = buf.getChannelData(0);
  let b0=0,b1=0,b2=0,b3=0,b4=0,b5=0;
  for (let i=0;i<d.length;i++) {
    const w=Math.random()*2-1;
    b0=0.99886*b0+w*0.0555179; b1=0.99332*b1+w*0.0750759;
    b2=0.96900*b2+w*0.1538520; b3=0.86650*b3+w*0.3104856;
    b4=0.55000*b4+w*0.5329522; b5=-0.7616*b5-w*0.0168980;
    d[i]=(b0+b1+b2+b3+b4+b5+w*0.5362)*0.11;
  }
  const src=ctx.createBufferSource(); src.buffer=buf;
  const hp=ctx.createBiquadFilter(); hp.type="highpass"; hp.frequency.value=200;
  const bp=ctx.createBiquadFilter(); bp.type="bandpass"; bp.Q.value=0.7;
  bp.frequency.setValueAtTime(1600,ctx.currentTime);
  bp.frequency.exponentialRampToValueAtTime(600,ctx.currentTime+dur*0.6);
  bp.frequency.exponentialRampToValueAtTime(220,ctx.currentTime+dur*0.9);
  bp.frequency.exponentialRampToValueAtTime(120,ctx.currentTime+dur);
  const g=ctx.createGain();
  g.gain.setValueAtTime(0,ctx.currentTime);
  g.gain.linearRampToValueAtTime(0.25,ctx.currentTime+0.5);
  g.gain.setValueAtTime(0.25,ctx.currentTime+dur*0.65);
  g.gain.linearRampToValueAtTime(0.08,ctx.currentTime+dur*0.85);
  g.gain.linearRampToValueAtTime(0,ctx.currentTime+dur);
  src.connect(hp); hp.connect(bp); bp.connect(g); g.connect(ctx.destination);
  src.start(); src.stop(ctx.currentTime+dur);
}

function playBounceClick(ctx: AudioContext, atOffset: number, intensity: number) {
  const t=ctx.currentTime+atOffset;
  const bufSize=Math.floor(ctx.sampleRate*0.035);
  const buf=ctx.createBuffer(1,bufSize,ctx.sampleRate);
  const d=buf.getChannelData(0);
  for(let i=0;i<bufSize;i++) d[i]=(Math.random()*2-1)*Math.exp(-i/(bufSize*0.12));
  const noise=ctx.createBufferSource(); noise.buffer=buf;
  const osc=ctx.createOscillator(); osc.type="triangle";
  osc.frequency.setValueAtTime(2200,t); osc.frequency.exponentialRampToValueAtTime(500,t+0.035);
  const ng=ctx.createGain(); ng.gain.setValueAtTime(intensity*0.5,t); ng.gain.exponentialRampToValueAtTime(0.001,t+0.045);
  const og=ctx.createGain(); og.gain.setValueAtTime(intensity*0.28,t); og.gain.exponentialRampToValueAtTime(0.001,t+0.055);
  noise.connect(ng); ng.connect(ctx.destination);
  osc.connect(og); og.connect(ctx.destination);
  noise.start(t); noise.stop(t+0.05); osc.start(t); osc.stop(t+0.06);
}

function scheduleBounceClicks(ctx: AudioContext, phaseDur: number) {
  // 22 clicks, getting closer together as ball slows
  for(let i=0;i<22;i++) {
    const p=i/22;
    const at=p*phaseDur*0.92;
    playBounceClick(ctx,at,1-p*0.8);
  }
}

function playWinFanfare(ctx: AudioContext) {
  const t=ctx.currentTime;
  // Drum roll
  for(let i=0;i<14;i++) {
    const at=t+i*0.03;
    const bs=Math.floor(ctx.sampleRate*0.022);
    const b=ctx.createBuffer(1,bs,ctx.sampleRate);
    const d=b.getChannelData(0);
    for(let j=0;j<bs;j++) d[j]=(Math.random()*2-1)*Math.exp(-j/(bs*0.25));
    const s=ctx.createBufferSource(); s.buffer=b;
    const g=ctx.createGain(); g.gain.setValueAtTime(0.2+i*0.012,at); g.gain.exponentialRampToValueAtTime(0.001,at+0.025);
    s.connect(g); g.connect(ctx.destination); s.start(at); s.stop(at+0.03);
  }
  // Ascending chord
  [523.25,659.25,783.99,1046.5,1318.5].forEach((freq,i) => {
    const at=t+0.42+i*0.08;
    const o=ctx.createOscillator(); o.type="sine"; o.frequency.value=freq;
    const g=ctx.createGain(); g.gain.setValueAtTime(0,at); g.gain.linearRampToValueAtTime(0.3,at+0.03); g.gain.exponentialRampToValueAtTime(0.001,at+0.65);
    o.connect(g); g.connect(ctx.destination); o.start(at); o.stop(at+0.7);
    const o2=ctx.createOscillator(); o2.type="triangle"; o2.frequency.value=freq*2;
    const g2=ctx.createGain(); g2.gain.setValueAtTime(0,at); g2.gain.linearRampToValueAtTime(0.09,at+0.02); g2.gain.exponentialRampToValueAtTime(0.001,at+0.4);
    o2.connect(g2); g2.connect(ctx.destination); o2.start(at); o2.stop(at+0.45);
  });
  // Bell sustain
  const ba=t+0.42+5*0.08+0.06;
  const bell=ctx.createOscillator(); bell.type="sine"; bell.frequency.value=2093;
  const bg=ctx.createGain(); bg.gain.setValueAtTime(0.38,ba); bg.gain.exponentialRampToValueAtTime(0.001,ba+2.5);
  bell.connect(bg); bg.connect(ctx.destination); bell.start(ba); bell.stop(ba+2.8);
}

function playLoseSound(ctx: AudioContext) {
  const t=ctx.currentTime;
  const o=ctx.createOscillator(); o.type="sawtooth";
  o.frequency.setValueAtTime(380,t); o.frequency.linearRampToValueAtTime(220,t+0.3); o.frequency.linearRampToValueAtTime(140,t+0.6);
  const g=ctx.createGain(); g.gain.setValueAtTime(0.18,t); g.gain.linearRampToValueAtTime(0.12,t+0.5); g.gain.exponentialRampToValueAtTime(0.001,t+0.65);
  const lp=ctx.createBiquadFilter(); lp.type="lowpass"; lp.frequency.value=550;
  o.connect(lp); lp.connect(g); g.connect(ctx.destination); o.start(t); o.stop(t+0.7);
}

function playClickSound(ctx: AudioContext) {
  const t=ctx.currentTime;
  const o=ctx.createOscillator(); const g=ctx.createGain();
  o.type="sine"; o.frequency.setValueAtTime(800,t); o.frequency.exponentialRampToValueAtTime(350,t+0.06);
  g.gain.setValueAtTime(0.2,t); g.gain.exponentialRampToValueAtTime(0.001,t+0.06);
  o.connect(g); g.connect(ctx.destination); o.start(t); o.stop(t+0.07);
}

// ─── Bet Types ────────────────────────────────────────────────────────────────
type BetType =
  | { kind: "straight"; number: number | "00" }
  | { kind: "color"; color: "red" | "black" }
  | { kind: "parity"; parity: "odd" | "even" }
  | { kind: "half"; half: "low" | "high" }
  | { kind: "dozen"; dozen: 1 | 2 | 3 }
  | { kind: "column"; column: 1 | 2 | 3 };

function betLabel(bet: BetType): string {
  switch (bet.kind) {
    case "straight": return `${bet.number}`;
    case "color": return bet.color === "red" ? "Red" : "Black";
    case "parity": return bet.parity === "odd" ? "Odd" : "Even";
    case "half": return bet.half === "low" ? "1–18" : "19–36";
    case "dozen": return `${(bet.dozen-1)*12+1}–${bet.dozen*12}`;
    case "column": return `Col ${bet.column}`;
  }
}
function betPayout(bet: BetType): number {
  switch (bet.kind) {
    case "straight": return 35;
    case "color": case "parity": case "half": return 1;
    case "dozen": case "column": return 2;
  }
}

// ─── Premium Canvas Roulette Wheel ────────────────────────────────────────────
// Draws a top-down flat view (no fake perspective) with rich gradients and detail.
// The wheel is 340px — compact but detailed.
function RouletteWheel({
  spinning, targetDeg, onSpinEnd, winningPocket, showWin, zoomedIn, onBallAngle,
}: {
  spinning: boolean;
  targetDeg: number;
  onSpinEnd: () => void;
  winningPocket: number | "00" | null;
  showWin: boolean;
  zoomedIn: boolean;
  onBallAngle?: (angleDeg: number) => void;
}) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animRef = useRef<number>(0);
  const stateRef = useRef({
    wheelDeg: 0,
    ballAngle: 270,
    ballBounceOffset: 0,
    spinning: false,
    targetDeg: 0,
    startTime: 0,
    startWheelDeg: 0,
    startBallAngle: 270,
    winningPocket: null as number | "00" | null,
    showWin: false,
  });

  const SIZE = 340;
  const cx = SIZE / 2;
  const cy = SIZE / 2;

  // Radii
  const R_OUTER = 166;    // outermost edge
  const R_WOOD_IN = 154;  // inner wood rim
  const R_TRACK = 148;    // ball track outer
  const R_TRACK_IN = 138; // ball track inner
  const R_PKT_OUT = 132;  // pocket outer
  const R_PKT_IN = 82;    // pocket inner
  const R_CONE = 78;      // decorative cone
  const R_HUB = 46;       // center hub
  const R_BALL = 148;     // ball orbit (in track)

  const toRad = (d: number) => d * Math.PI / 180;

  useEffect(() => { stateRef.current.winningPocket = winningPocket; }, [winningPocket]);
  useEffect(() => { stateRef.current.showWin = showWin; }, [showWin]);

  useEffect(() => {
    if (spinning) {
      const s = stateRef.current;
      s.spinning = true;
      s.startTime = performance.now();
      s.startWheelDeg = s.wheelDeg;
      s.startBallAngle = s.ballAngle;
      s.targetDeg = targetDeg;
    }
  }, [spinning, targetDeg]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    // Pre-build pocket colors
    const pocketColors = WHEEL_ORDER.map(n => getPocketColor(n));

    function draw() {
      const s = stateRef.current;
      ctx!.clearRect(0, 0, SIZE, SIZE);
      const c = ctx!;

      // ── Outer shadow ──
      c.save();
      c.shadowColor = "rgba(0,0,0,0.95)";
      c.shadowBlur = 30;
      c.shadowOffsetY = 6;
      c.beginPath(); c.arc(cx, cy, R_OUTER, 0, Math.PI*2);
      c.fillStyle = "#0a0500"; c.fill();
      c.restore();

      // ── Outer chrome ring ──
      const chromeGrad = c.createLinearGradient(cx-R_OUTER, cy-R_OUTER, cx+R_OUTER, cy+R_OUTER);
      chromeGrad.addColorStop(0, "#fff8d0");
      chromeGrad.addColorStop(0.15, "#FFD700");
      chromeGrad.addColorStop(0.35, "#c8960c");
      chromeGrad.addColorStop(0.5, "#8B6914");
      chromeGrad.addColorStop(0.65, "#c8960c");
      chromeGrad.addColorStop(0.85, "#FFD700");
      chromeGrad.addColorStop(1, "#fff8d0");
      c.beginPath(); c.arc(cx, cy, R_OUTER, 0, Math.PI*2);
      c.strokeStyle = chromeGrad; c.lineWidth = 7; c.stroke();

      // ── Mahogany wood rim ──
      const woodGrad = c.createRadialGradient(cx-20, cy-30, 10, cx, cy, R_OUTER);
      woodGrad.addColorStop(0, "#9B4A1A");
      woodGrad.addColorStop(0.25, "#7B3410");
      woodGrad.addColorStop(0.55, "#5a2408");
      woodGrad.addColorStop(0.8, "#3a1705");
      woodGrad.addColorStop(1, "#1e0d02");
      c.beginPath(); c.arc(cx, cy, R_OUTER-4, 0, Math.PI*2);
      c.fillStyle = woodGrad; c.fill();

      // Wood sheen
      const sheen = c.createLinearGradient(cx-R_OUTER, cy-R_OUTER, cx+R_OUTER*0.4, cy);
      sheen.addColorStop(0, "rgba(255,190,90,0.22)");
      sheen.addColorStop(0.4, "rgba(255,190,90,0.05)");
      sheen.addColorStop(1, "rgba(0,0,0,0)");
      c.beginPath(); c.arc(cx, cy, R_OUTER-4, 0, Math.PI*2);
      c.fillStyle = sheen; c.fill();

      // Wood grain arcs
      for (let a=0; a<360; a+=20) {
        c.beginPath();
        c.arc(cx, cy, R_WOOD_IN+5, toRad(a), toRad(a+18));
        c.strokeStyle = "rgba(255,150,50,0.055)"; c.lineWidth = 2.5; c.stroke();
      }

      // ── Inner gold rim ──
      c.beginPath(); c.arc(cx, cy, R_WOOD_IN, 0, Math.PI*2);
      c.strokeStyle = chromeGrad; c.lineWidth = 3; c.stroke();
      c.beginPath(); c.arc(cx, cy, R_WOOD_IN-4, 0, Math.PI*2);
      c.strokeStyle = "rgba(255,215,0,0.3)"; c.lineWidth = 1; c.stroke();

      // ── Ball track ──
      const trackGrad = c.createRadialGradient(cx, cy, R_TRACK_IN, cx, cy, R_TRACK);
      trackGrad.addColorStop(0, "#120900");
      trackGrad.addColorStop(0.4, "#1c0e03");
      trackGrad.addColorStop(0.7, "#0f0700");
      trackGrad.addColorStop(1, "#080400");
      c.beginPath(); c.arc(cx, cy, R_TRACK, 0, Math.PI*2);
      c.fillStyle = trackGrad; c.fill();
      // Track inner edge highlight
      c.beginPath(); c.arc(cx, cy, R_TRACK_IN, 0, Math.PI*2);
      c.strokeStyle = "rgba(255,215,0,0.18)"; c.lineWidth = 1; c.stroke();
      c.beginPath(); c.arc(cx, cy, R_TRACK, 0, Math.PI*2);
      c.strokeStyle = "rgba(255,215,0,0.1)"; c.lineWidth = 1; c.stroke();

      // ── ROTATING WHEEL ──
      c.save();
      c.translate(cx, cy);
      c.rotate(toRad(s.wheelDeg));
      c.translate(-cx, -cy);

      const winIdx = s.winningPocket !== null ? WHEEL_ORDER.indexOf(s.winningPocket as number) : -1;

      WHEEL_ORDER.forEach((num, i) => {
        const startA = toRad(i * DEG_PER_POCKET - DEG_PER_POCKET/2);
        const endA   = toRad(i * DEG_PER_POCKET + DEG_PER_POCKET/2);
        const midA   = (startA + endA) / 2;
        const color  = pocketColors[i];
        const isWin  = s.showWin && i === winIdx;

        // Pocket fill with depth gradient
        c.beginPath();
        c.moveTo(cx + R_PKT_IN*Math.cos(startA), cy + R_PKT_IN*Math.sin(startA));
        c.arc(cx, cy, R_PKT_OUT, startA, endA);
        c.arc(cx, cy, R_PKT_IN, endA, startA, true);
        c.closePath();

        // Radial gradient from pocket center outward for 3D depth
        const pgx = cx + (R_PKT_IN+18)*Math.cos(midA);
        const pgy = cy + (R_PKT_IN+18)*Math.sin(midA);
        const pg = c.createRadialGradient(pgx, pgy, 2, cx, cy, R_PKT_OUT+5);

        if (color === "green") {
          pg.addColorStop(0, isWin ? "#5af59a" : "#2ecc71");
          pg.addColorStop(0.5, isWin ? "#22c55e" : "#1a7a40");
          pg.addColorStop(1, isWin ? "#15803d" : "#0d3d1f");
        } else if (color === "red") {
          pg.addColorStop(0, isWin ? "#ff8080" : "#e74c3c");
          pg.addColorStop(0.5, isWin ? "#dc2626" : "#8b1a1a");
          pg.addColorStop(1, isWin ? "#991b1b" : "#450d0d");
        } else {
          pg.addColorStop(0, isWin ? "#9ca3af" : "#4b5563");
          pg.addColorStop(0.5, isWin ? "#6b7280" : "#1f2937");
          pg.addColorStop(1, isWin ? "#374151" : "#060a0f");
        }
        c.fillStyle = pg; c.fill();

        // Winner pulse glow
        if (isWin) {
          c.save();
          c.shadowColor = color === "red" ? "#ff4444" : color === "green" ? "#44ff88" : "#aaaaaa";
          c.shadowBlur = 22;
          c.fill();
          c.restore();
        }

        // Pocket inner shadow (dark edge at inner arc)
        const innerShadow = c.createRadialGradient(cx, cy, R_PKT_IN-6, cx, cy, R_PKT_IN+8);
        innerShadow.addColorStop(0, "rgba(0,0,0,0.55)");
        innerShadow.addColorStop(1, "rgba(0,0,0,0)");
        c.beginPath();
        c.moveTo(cx + R_PKT_IN*Math.cos(startA), cy + R_PKT_IN*Math.sin(startA));
        c.arc(cx, cy, R_PKT_OUT, startA, endA);
        c.arc(cx, cy, R_PKT_IN, endA, startA, true);
        c.closePath();
        c.fillStyle = innerShadow; c.fill();

        // Gold fret divider
        c.beginPath();
        c.moveTo(cx + R_PKT_IN*Math.cos(startA), cy + R_PKT_IN*Math.sin(startA));
        c.lineTo(cx + R_PKT_OUT*Math.cos(startA), cy + R_PKT_OUT*Math.sin(startA));
        c.strokeStyle = "#D4A017"; c.lineWidth = 1.4; c.stroke();

        // Fret diamond tip
        const dtx = cx + (R_PKT_IN-4)*Math.cos(startA);
        const dty = cy + (R_PKT_IN-4)*Math.sin(startA);
        c.beginPath(); c.arc(dtx, dty, 2.2, 0, Math.PI*2);
        c.fillStyle = "#FFD700"; c.fill();
        c.beginPath(); c.arc(dtx, dty, 2.2, 0, Math.PI*2);
        c.strokeStyle = "#8B6914"; c.lineWidth = 0.5; c.stroke();

        // Number text
        const textR = (R_PKT_IN + R_PKT_OUT) / 2 + 1;
        const tx = cx + textR*Math.cos(midA);
        const ty = cy + textR*Math.sin(midA);
        c.save();
        c.translate(tx, ty);
        c.rotate(midA + Math.PI/2);
        c.font = `bold ${num === "00" ? 8.5 : 9.5}px Arial, sans-serif`;
        c.fillStyle = isWin ? "#FFD700" : "#ffffff";
        c.textAlign = "center";
        c.textBaseline = "middle";
        // Always add a dark outline for legibility
        c.shadowColor = "rgba(0,0,0,0.9)";
        c.shadowBlur = 3;
        if (isWin) { c.shadowColor = "#FFD700"; c.shadowBlur = 10; }
        c.fillText(String(num), 0, 0);
        // Stroke outline for extra contrast
        c.strokeStyle = isWin ? "rgba(0,0,0,0.5)" : "rgba(0,0,0,0.7)";
        c.lineWidth = 0.5;
        c.strokeText(String(num), 0, 0);
        c.restore();
      });

      // ── Inner cone ring ──
      const coneGrad = c.createRadialGradient(cx, cy, 0, cx, cy, R_CONE);
      coneGrad.addColorStop(0, "#2d1505");
      coneGrad.addColorStop(0.7, "#1a0a02");
      coneGrad.addColorStop(1, "#0d0602");
      c.beginPath(); c.arc(cx, cy, R_CONE, 0, Math.PI*2);
      c.fillStyle = coneGrad; c.fill();
      c.beginPath(); c.arc(cx, cy, R_CONE, 0, Math.PI*2);
      c.strokeStyle = "#C8A000"; c.lineWidth = 2; c.stroke();
      c.beginPath(); c.arc(cx, cy, R_CONE-4, 0, Math.PI*2);
      c.strokeStyle = "rgba(255,215,0,0.18)"; c.lineWidth = 1; c.stroke();

      // Decorative spokes
      for (let a=0; a<360; a+=45) {
        c.beginPath();
        c.moveTo(cx + (R_HUB+3)*Math.cos(toRad(a)), cy + (R_HUB+3)*Math.sin(toRad(a)));
        c.lineTo(cx + (R_CONE-7)*Math.cos(toRad(a)), cy + (R_CONE-7)*Math.sin(toRad(a)));
        c.strokeStyle = "rgba(210,160,0,0.6)"; c.lineWidth = 1.4; c.stroke();
      }

      // ── Hub ──
      const hubG = c.createRadialGradient(cx-12, cy-14, 4, cx, cy, R_HUB+4);
      hubG.addColorStop(0, "#fff8c0");
      hubG.addColorStop(0.18, "#FFD700");
      hubG.addColorStop(0.5, "#B8860B");
      hubG.addColorStop(0.78, "#7a5800");
      hubG.addColorStop(1, "#3d2c00");
      c.beginPath(); c.arc(cx, cy, R_HUB+4, 0, Math.PI*2);
      c.fillStyle = hubG; c.fill();
      c.strokeStyle = "#FFD700"; c.lineWidth = 2; c.stroke();

      const hubMid = c.createRadialGradient(cx-10, cy-12, 3, cx, cy, R_HUB-4);
      hubMid.addColorStop(0, "#fffbe0"); hubMid.addColorStop(0.3, "#FFD700");
      hubMid.addColorStop(0.7, "#8B6914"); hubMid.addColorStop(1, "#4a3800");
      c.beginPath(); c.arc(cx, cy, R_HUB-4, 0, Math.PI*2);
      c.fillStyle = hubMid; c.fill();

      c.beginPath(); c.arc(cx, cy, R_HUB-11, 0, Math.PI*2);
      c.strokeStyle = "rgba(255,215,0,0.45)"; c.lineWidth = 1; c.stroke();

      const hubCenter = c.createRadialGradient(cx, cy, 0, cx, cy, R_HUB-15);
      hubCenter.addColorStop(0, "#2d1505"); hubCenter.addColorStop(1, "#0d0602");
      c.beginPath(); c.arc(cx, cy, R_HUB-15, 0, Math.PI*2);
      c.fillStyle = hubCenter; c.fill();
      c.strokeStyle = "#8B6914"; c.lineWidth = 1; c.stroke();

      // Hub specular
      c.save();
      c.beginPath(); c.ellipse(cx-9, cy-11, 11, 6, -0.5, 0, Math.PI*2);
      c.fillStyle = "rgba(255,255,255,0.13)"; c.fill();
      c.restore();

      // SCO text
      c.font = "900 10px Georgia, serif";
      c.fillStyle = "#FFD700"; c.textAlign = "center"; c.textBaseline = "middle";
      c.fillText("SCO", cx, cy-4);
      c.font = "bold 5px Georgia, serif";
      c.fillStyle = "rgba(255,215,0,0.55)";
      c.fillText("ROULETTE", cx, cy+7);

      c.restore(); // end rotating group

      // No fixed pointer — the ball determines the winner

      // ── Spinning ball ──
      if (s.spinning) {
        const orbitR = R_BALL + s.ballBounceOffset;
        const bx = cx + orbitR*Math.cos(toRad(s.ballAngle));
        const by = cy + orbitR*Math.sin(toRad(s.ballAngle));
        const br = 6 * (1 + (s.ballBounceOffset/14)*0.3);

        // Shadow on track
        c.beginPath();
        c.ellipse(
          cx + R_BALL*Math.cos(toRad(s.ballAngle))+1,
          cy + R_BALL*Math.sin(toRad(s.ballAngle))+2,
          6+s.ballBounceOffset*0.25, 4+s.ballBounceOffset*0.1, 0, 0, Math.PI*2
        );
        c.fillStyle = "rgba(0,0,0,0.4)"; c.fill();

        // Ball body
        const bg = c.createRadialGradient(bx-br*0.32, by-br*0.32, br*0.08, bx, by, br);
        bg.addColorStop(0, "#ffffff");
        bg.addColorStop(0.35, "#eeeeee");
        bg.addColorStop(1, "#999999");
        c.save();
        c.shadowColor = "rgba(0,0,0,0.65)"; c.shadowBlur = 7; c.shadowOffsetX = 1; c.shadowOffsetY = 2;
        c.beginPath(); c.arc(bx, by, br, 0, Math.PI*2);
        c.fillStyle = bg; c.fill();
        c.restore();

        // Specular
        c.beginPath();
        c.ellipse(bx-br*0.32, by-br*0.32, br*0.38, br*0.26, -0.5, 0, Math.PI*2);
        c.fillStyle = "rgba(255,255,255,0.88)"; c.fill();
      }

      // ── Ball resting in winning pocket ──
      if (s.showWin && !s.spinning && s.winningPocket !== null) {
        const wi = WHEEL_ORDER.indexOf(s.winningPocket as number);
        if (wi >= 0) {
          const ma = toRad(wi*DEG_PER_POCKET + DEG_PER_POCKET/2 + s.wheelDeg);
          const br2 = (R_PKT_IN + R_PKT_OUT)/2 + 7;
          const bx2 = cx + br2*Math.cos(ma);
          const by2 = cy + br2*Math.sin(ma);
          c.beginPath(); c.ellipse(bx2+1, by2+2, 6, 4, 0, 0, Math.PI*2);
          c.fillStyle = "rgba(0,0,0,0.4)"; c.fill();
          const bg2 = c.createRadialGradient(bx2-2, by2-2, 1, bx2, by2, 6);
          bg2.addColorStop(0, "#ffffff"); bg2.addColorStop(0.4, "#eeeeee"); bg2.addColorStop(1, "#999999");
          c.beginPath(); c.arc(bx2, by2, 6, 0, Math.PI*2);
          c.fillStyle = bg2; c.fill();
          c.beginPath(); c.ellipse(bx2-1.8, by2-1.8, 2.2, 1.6, 0, 0, Math.PI*2);
          c.fillStyle = "rgba(255,255,255,0.88)"; c.fill();
        }
      }

      // ── Win glow overlay ──
      if (s.showWin && s.winningPocket !== null) {
        const wc = getPocketColor(s.winningPocket);
        const wglow = c.createRadialGradient(cx, cy, R_PKT_IN, cx, cy, R_OUTER+10);
        wglow.addColorStop(0, "rgba(0,0,0,0)");
        wglow.addColorStop(0.65, "rgba(0,0,0,0)");
        wglow.addColorStop(1, wc === "red" ? "rgba(239,68,68,0.38)" : wc === "green" ? "rgba(34,197,94,0.38)" : "rgba(100,100,100,0.22)");
        c.beginPath(); c.arc(cx, cy, R_OUTER+10, 0, Math.PI*2);
        c.fillStyle = wglow; c.fill();
      }
    }

    function tick(now: number) {
      const s = stateRef.current;
      if (s.spinning) {
        const elapsed = now - s.startTime;
        const t = Math.min(elapsed / SPIN_DURATION, 1);

        // Physics: fast start, very gradual deceleration (ease-out power 6)
        const eased = 1 - Math.pow(1 - t, 6);
        // Wheel spins 7 full rotations + lands exactly at targetDeg
        const startNorm = ((s.startWheelDeg % 360) + 360) % 360;
        const wheelTotal = 360 * 7 + ((s.targetDeg - startNorm + 360) % 360);
        s.wheelDeg = s.startWheelDeg + wheelTotal * eased;

        // Ball: counter-spins faster, decelerates earlier
        const ballT = Math.min(elapsed / (SPIN_DURATION * 0.88), 1);
        const ballEased = 1 - Math.pow(1 - ballT, 5);
        s.ballAngle = s.startBallAngle - (360 * 15) * ballEased;

        // Bounce: starts at 72% of spin (14.4s), lasts 5.6s
        // Ball rolls inward from track into pocket
        if (t >= 0.72) {
          const bp = (t - 0.72) / 0.28;
          const amp = 14 * (1 - bp);
          const freq = 9 + bp * 16;
          s.ballBounceOffset = amp * Math.abs(Math.sin(bp * Math.PI * freq));
          // In final 30%: ball drifts strongly inward into the pocket
          if (bp > 0.70) {
            const inward = (bp - 0.70) / 0.30;
            // Move ball inward by up to 58px (from R_BALL=148 toward pocket mid ~107)
            s.ballBounceOffset -= inward * 58;
          }
        } else {
          s.ballBounceOffset = 0;
        }

        if (t >= 1) {
          s.spinning = false;
          s.ballBounceOffset = 0;
          // Snap ball angle to exactly align with the winning pocket at pointer (270°)
          // The pocket sits at 270° in canvas coords after the wheel has rotated
          s.ballAngle = 270;
          onSpinEnd();
        }
        // Report ball angle for zoom tracking
        if (onBallAngle) onBallAngle(s.ballAngle);
      }
      draw();
      animRef.current = requestAnimationFrame(tick);
    }

    animRef.current = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(animRef.current);
  }, [onSpinEnd]);

  return (
    <div className="relative flex items-center justify-center" style={{ width: SIZE, height: SIZE }}>
      <canvas ref={canvasRef} width={SIZE} height={SIZE} />
    </div>
  );
}

// ─── Compact Number Grid ──────────────────────────────────────────────────────
const GRID_LAYOUT = [
  [3,6,9,12,15,18,21,24,27,30,33,36],
  [2,5,8,11,14,17,20,23,26,29,32,35],
  [1,4,7,10,13,16,19,22,25,28,31,34],
];

function NumberGrid({ onBet, activeBets, disabled }: {
  onBet: (bet: BetType) => void;
  activeBets: { bet: BetType; amount: number }[];
  disabled: boolean;
}) {
  const hasBet = (bet: BetType) => activeBets.some(b => JSON.stringify(b.bet) === JSON.stringify(bet));
  return (
    <div className={`flex flex-col gap-0.5 transition-opacity ${disabled ? "opacity-25 pointer-events-none" : ""}`}>
      {/* 0 and 00 */}
      <div className="flex gap-0.5 justify-center mb-0.5">
        {([0, "00"] as (number | "00")[]).map(n => (
          <button key={String(n)} onClick={() => onBet({ kind: "straight", number: n as number | "00" })}
            className={`w-9 h-6 rounded text-white text-xs font-bold border-2 transition-all
              ${hasBet({ kind: "straight", number: n as number | "00" })
                ? "ring-2 ring-yellow-400 scale-110 bg-green-500 border-green-300"
                : "bg-green-800 border-green-600 hover:bg-green-700 hover:scale-105"}`}>
            {n}
          </button>
        ))}
      </div>
      {/* Number grid */}
      {GRID_LAYOUT.map((row, ri) => (
        <div key={ri} className="flex gap-0.5">
          {row.map(n => {
            const color = getPocketColor(n);
            const active = hasBet({ kind: "straight", number: n });
            return (
              <button key={n} onClick={() => onBet({ kind: "straight", number: n })}
                className={`w-6 h-6 rounded text-white text-xs font-bold border transition-all
                  ${active ? "ring-2 ring-yellow-400 scale-110 border-yellow-400" : "hover:scale-105"}
                  ${color === "red"
                    ? active ? "bg-red-500 border-red-300" : "bg-red-800 border-red-600"
                    : active ? "bg-gray-600 border-gray-400" : "bg-gray-900 border-gray-700"}`}>
                {n}
              </button>
            );
          })}
          <button onClick={() => onBet({ kind: "column", column: (3-ri) as 1|2|3 })}
            className={`w-8 h-6 rounded text-yellow-300 text-xs font-bold border transition-all
              ${hasBet({ kind: "column", column: (3-ri) as 1|2|3 })
                ? "ring-2 ring-yellow-400 bg-yellow-700/60 border-yellow-400"
                : "border-yellow-700/50 bg-yellow-900/30 hover:bg-yellow-800/40"}`}>
            2:1
          </button>
        </div>
      ))}
      {/* Dozens */}
      <div className="flex gap-0.5 mt-0.5">
        {([1,2,3] as (1|2|3)[]).map(d => (
          <button key={d} onClick={() => onBet({ kind: "dozen", dozen: d })}
            className={`flex-1 h-6 rounded text-yellow-300 text-xs font-bold border transition-all
              ${hasBet({ kind: "dozen", dozen: d })
                ? "ring-2 ring-yellow-400 bg-yellow-700/60 border-yellow-400"
                : "border-yellow-700/50 bg-yellow-900/30 hover:bg-yellow-800/40"}`}>
            {(d-1)*12+1}–{d*12}
          </button>
        ))}
      </div>
      {/* Outside bets */}
      <div className="flex gap-0.5 mt-0.5">
        {[
          { label: "1-18", bet: { kind: "half", half: "low" } as BetType },
          { label: "Even", bet: { kind: "parity", parity: "even" } as BetType },
          { label: "🔴", bet: { kind: "color", color: "red" } as BetType, cls: "bg-red-900/60 border-red-600" },
          { label: "⚫", bet: { kind: "color", color: "black" } as BetType, cls: "bg-gray-900 border-gray-700" },
          { label: "Odd", bet: { kind: "parity", parity: "odd" } as BetType },
          { label: "19-36", bet: { kind: "half", half: "high" } as BetType },
        ].map(({ label, bet, cls }) => (
          <button key={label} onClick={() => onBet(bet)}
            className={`flex-1 h-6 rounded text-white text-xs font-bold border transition-all
              ${hasBet(bet)
                ? "ring-2 ring-yellow-400 bg-yellow-700/60 border-yellow-400"
                : `border-yellow-700/50 bg-yellow-900/30 hover:bg-yellow-800/40 ${cls||""}`}`}>
            {label}
          </button>
        ))}
      </div>
    </div>
  );
}

// ─── Main Component ───────────────────────────────────────────────────────────
export default function Roulette() {
  const { isAuthenticated } = useAuth();
  const { data: account, refetch: refetchAccount } = trpc.credits.myAccount.useQuery(
    undefined, { enabled: isAuthenticated }
  );
  const playRoulette = trpc.game.playRoulette.useMutation();

  const [bets, setBets] = useState<{ bet: BetType; amount: number }[]>([]);
  const [lastBets, setLastBets] = useState<{ bet: BetType; amount: number }[]>([]);
  const [chipValue, setChipValue] = useState(1);
  const [spinning, setSpinning] = useState(false);
  const [targetDeg, setTargetDeg] = useState(0);
  const [result, setResult] = useState<{ number: number | "00"; winnings: number; netWin: number } | null>(null);
  const [showWin, setShowWin] = useState(false);
  const [lastResults, setLastResults] = useState<(number | "00")[]>([]);
  const [zoomedIn, setZoomedIn] = useState(false);
  const [ballAngleDeg, setBallAngleDeg] = useState(270);

  const pendingResult = useRef<{ number: number | "00"; winnings: number; netWin: number } | null>(null);
  const audioCtxRef = useRef<AudioContext | null>(null);
  const zoomTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const bounceTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const MAX_BET = 5;
  const totalBet = useMemo(() => bets.reduce((s, b) => s + b.amount, 0), [bets]);
  const credits = account?.credits ?? 0;

  const getAudioCtx = useCallback(() => {
    if (!audioCtxRef.current) audioCtxRef.current = createAudioCtx();
    return audioCtxRef.current;
  }, []);

  const addBet = useCallback((bet: BetType) => {
    if (spinning) return;
    if (totalBet + chipValue > MAX_BET) { toast.error(`Max total bet is ${MAX_BET} credits`); return; }
    if (chipValue > credits - totalBet) { toast.error("Not enough credits"); return; }
    const ctx = getAudioCtx();
    if (ctx) playClickSound(ctx);
    setBets(prev => {
      const idx = prev.findIndex(b => JSON.stringify(b.bet) === JSON.stringify(bet));
      if (idx >= 0) {
        const updated = [...prev];
        updated[idx] = { ...updated[idx], amount: updated[idx].amount + chipValue };
        return updated;
      }
      return [...prev, { bet, amount: chipValue }];
    });
  }, [spinning, totalBet, chipValue, credits, getAudioCtx]);

  const clearBets = () => { if (!spinning) setBets([]); };

  const spin = async () => {
    if (spinning || bets.length === 0) return;
    if (!isAuthenticated) { toast.error("Please log in to play"); return; }

    setSpinning(true);
    setZoomedIn(false);
    setResult(null);
    setShowWin(false);

    const ctx = getAudioCtx();
    if (ctx) {
      try {
        if (ctx.state === "suspended") await ctx.resume();
        playSpinSound(ctx);
      } catch {}
    }

    // Zoom in at t=15s (5s before end)
    if (zoomTimerRef.current) clearTimeout(zoomTimerRef.current);
    zoomTimerRef.current = setTimeout(() => setZoomedIn(true), 14000);

    // Bounce clicks at t=14.4s (72% of 20s)
    if (bounceTimerRef.current) clearTimeout(bounceTimerRef.current);
    bounceTimerRef.current = setTimeout(() => {
      const audioCtx = getAudioCtx();
      if (audioCtx) { try { scheduleBounceClicks(audioCtx, 5.6); } catch {} }
    }, 14400);

    try {
      const res = await playRoulette.mutateAsync({ bets: bets.map(b => ({ bet: b.bet, amount: b.amount })) });
      const idx = WHEEL_ORDER.indexOf(res.resultNumber as number);
      // Pocket i is drawn at angle (i * DEG_PER_POCKET) in the wheel's local frame.
      // The pointer sits at the TOP of the canvas = 270° in canvas coords.
      // After wheel rotates by wheelDeg, pocket i is at: (i * DEG_PER_POCKET + wheelDeg) mod 360.
      // We want that to equal 270°, so: wheelDeg = 270 - i * DEG_PER_POCKET (mod 360).
      const pocketCenter = idx * DEG_PER_POCKET;
      const target = ((270 - pocketCenter) % 360 + 360) % 360;
      pendingResult.current = {
        number: res.resultNumber as number | "00",
        winnings: res.winnings,
        netWin: res.netWin,
      };
      setTargetDeg(target);
    } catch (e: unknown) {
      toast.error((e as Error).message || "Spin failed");
      setSpinning(false);
      if (zoomTimerRef.current) clearTimeout(zoomTimerRef.current);
      if (bounceTimerRef.current) clearTimeout(bounceTimerRef.current);
    }
  };

  const handleSpinEnd = useCallback(() => {
    setSpinning(false);
    setZoomedIn(false);
    setBallAngleDeg(270);
    setShowWin(true);
    if (pendingResult.current) {
      const r = pendingResult.current;
      setResult(r);
      setLastResults(prev => [r.number, ...prev].slice(0, 10));
      const ctx = getAudioCtx();
      if (ctx) {
        setTimeout(() => {
          if (r.netWin > 0) playWinFanfare(ctx);
          else playLoseSound(ctx);
        }, 300);
      }
      setTimeout(() => {
        refetchAccount();
        setLastBets(bets);
        setBets([]);
        pendingResult.current = null;
      }, 600);
    }
  }, [getAudioCtx, refetchAccount]);

  const resultColor = result ? getPocketColor(result.number) : null;
  const resultBg = resultColor === "red" ? "#7f1d1d" : resultColor === "green" ? "#14532d" : "#1f2937";
  const resultText = resultColor === "red" ? "#fca5a5" : resultColor === "green" ? "#86efac" : "#d1d5db";
  const resultGlow = resultColor === "red" ? "rgba(239,68,68,0.55)" : resultColor === "green" ? "rgba(34,197,94,0.55)" : "rgba(100,100,100,0.3)";

  return (
    <div className="h-screen flex flex-col text-white overflow-hidden select-none"
      style={{ background: "radial-gradient(ellipse at top, #0d2a0d 0%, #071407 40%, #030803 100%)" }}>

      {/* ── Header ── */}
      <div className="flex-shrink-0 border-b border-yellow-900/40 bg-black/60 px-4 py-2 flex items-center justify-between backdrop-blur-sm">
        <div className="flex items-center gap-3">
          <Link href="/game-room" className="text-yellow-500 hover:text-yellow-300 text-sm font-semibold">← Game Room</Link>
          <span className="text-white/20">|</span>
          <h1 className="text-base font-black text-yellow-400 tracking-wider" style={{ fontFamily: "serif" }}>
            🎡 AMERICAN ROULETTE
          </h1>
          <span className="hidden md:inline text-white/30 text-xs">Double-zero · 5.26% house edge</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="hidden sm:flex items-center gap-1.5 bg-red-600/80 border border-red-400/60 rounded-lg px-3 py-1 animate-pulse">
            <span className="text-white text-xs font-black">🎰 FREE PLAY 4 NOW — No Prizes</span>
          </div>
          <div className="bg-black/60 border border-yellow-700/40 rounded-lg px-3 py-1">
            <span className="text-yellow-400 text-sm font-bold">💰 {credits.toLocaleString()} cr</span>
          </div>
        </div>
      </div>

      {/* ── Main two-column layout ── */}
      <div className="flex-1 flex overflow-hidden min-h-0">

        {/* ── Left: Wheel ── */}
        <div className="flex-shrink-0 flex flex-col items-center justify-center px-4 gap-2"
          style={{ width: 380 }}>
          {/* Zoom container: clips to 340x340, translates to follow ball when zoomedIn */}
          <div style={{ width: 340, height: 340, overflow: "hidden", position: "relative" }}>
            {(() => {
              // Ball position in canvas coords (cx=170, cy=170, orbitR=148)
              const rad = ballAngleDeg * Math.PI / 180;
              const bx = 170 + 148 * Math.cos(rad); // ball x in canvas
              const by = 170 + 148 * Math.sin(rad); // ball y in canvas
              // Zoom in gently so the ball AND its pocket are both visible.
              // 1.25× keeps ~100px of wheel context around the ball so the pocket
              const scale = zoomedIn ? 1.25 : 1.0;
              // Center on the ball but clamp so we never pan more than 80px from origin
              // (prevents the pocket from sliding off-screen).
              const clamp = (v: number, lo: number, hi: number) => Math.max(lo, Math.min(hi, v));
              const tx = zoomedIn ? clamp(170 - bx * scale, -80, 80) : 0;
              const ty = zoomedIn ? clamp(170 - by * scale, -80, 80) : 0;
              return (
                <div style={{
                  transform: `translate(${tx}px, ${ty}px) scale(${scale})`,
                  transformOrigin: "0 0",
                  transition: zoomedIn ? "transform 1.2s cubic-bezier(0.22,1,0.36,1)" : "transform 0.6s ease-in",
                  willChange: "transform",
                }}>
                  <RouletteWheel
                    spinning={spinning}
                    targetDeg={targetDeg}
                    onSpinEnd={handleSpinEnd}
                    winningPocket={result?.number ?? null}
                    showWin={showWin}
                    zoomedIn={zoomedIn}
                    onBallAngle={setBallAngleDeg}
                  />
                </div>
              );
            })()}
          </div>
          {/* Status line */}
          <div className="h-5 flex items-center justify-center">
            {spinning && !zoomedIn && (
              <span className="text-yellow-400 text-xs font-bold animate-pulse">🎡 No more bets — spinning...</span>
            )}
            {zoomedIn && (
              <span className="text-yellow-300 text-sm font-black animate-pulse tracking-widest"
                style={{ fontFamily: "Georgia, serif", textShadow: "0 0 18px rgba(255,215,0,0.8)" }}>
                🎯 FINAL APPROACH...
              </span>
            )}
          </div>
        </div>

        {/* ── Right: Fixed-height betting panel ── */}
        <div className="flex-1 flex flex-col gap-1 p-2 overflow-hidden min-w-0">

          {/* ── Result + last 10 ── */}
          <div className="flex-shrink-0 flex items-center gap-1.5 bg-black/50 border border-yellow-900/40 rounded-lg px-2 py-1.5">
            {/* Big winning number */}
            <div className="flex-shrink-0 w-11 h-11 rounded-full flex items-center justify-center border-4 font-black text-lg transition-all duration-500"
              style={{
                background: result ? resultBg : "rgba(0,0,0,0.4)",
                borderColor: result ? resultText : "rgba(255,215,0,0.2)",
                color: result ? resultText : "rgba(255,255,255,0.2)",
                boxShadow: result ? `0 0 28px 6px ${resultGlow}` : "none",
                fontFamily: "Georgia, serif",
              }}>
              {result ? result.number : "—"}
            </div>
            {/* Win/loss */}
            <div className="flex-shrink-0 flex flex-col justify-center min-w-[60px]">
              {result ? (
                <>
                  <div className="text-xs font-bold uppercase tracking-widest leading-tight" style={{ color: resultText, fontSize: "10px" }}>
                    {resultColor === "red" ? "🔴 RED" : resultColor === "green" ? "🟢 GREEN" : "⚫ BLACK"}
                  </div>
                  {result.netWin > 0 ? (
                    <div className="text-green-400 font-black text-sm leading-tight">+{result.netWin} cr</div>
                  ) : result.netWin === 0 && result.winnings > 0 ? (
                    <div className="text-blue-400 font-bold text-xs">Push</div>
                  ) : (
                    <div className="text-red-400 font-bold text-xs">No win</div>
                  )}
                </>
              ) : (
                <div className="text-white/20 text-xs">Last result</div>
              )}
            </div>
            {/* Last 10 chain */}
            <div className="flex-1 flex flex-col gap-0.5 min-w-0">
              <div className="text-yellow-400/50 font-bold uppercase tracking-widest" style={{ fontSize: "9px" }}>Last 10</div>
              <div className="flex gap-0.5 flex-wrap">
                {lastResults.length === 0 ? (
                  <span className="text-white/20 text-xs">—</span>
                ) : (
                  lastResults.map((n, i) => {
                    const c = getPocketColor(n);
                    return (
                      <div key={i} className="relative">
                        <span
                          className={`w-5 h-5 rounded-full flex items-center justify-center font-black text-white border shadow-md
                            ${c === "green" ? "bg-green-700 border-green-400" : c === "red" ? "bg-red-700 border-red-400" : "bg-gray-800 border-gray-500"}`}
                          style={{ fontFamily: "Georgia, serif", fontSize: "8px" }}
                        >{n}</span>
                        {i === 0 && (
                          <span className="absolute -top-0.5 -right-0.5 w-1.5 h-1.5 bg-yellow-400 rounded-full border border-black" />
                        )}
                      </div>
                    );
                  })
                )}
              </div>
            </div>
          </div>

          {/* ── Chip selector ── */}
          <div className="flex-shrink-0 bg-black/40 border border-yellow-900/40 rounded-lg px-2 py-1">
            <div className="flex items-center gap-1.5">
              <span className="text-yellow-400/60 font-bold uppercase tracking-widest flex-shrink-0" style={{ fontSize: "9px" }}>Chip:</span>
              <div className="flex gap-1">
                {[0.5, 1, 2, 5].map(v => {
                  const colors: Record<number, string> = {
                    0.5: "from-gray-500 to-gray-700 border-gray-400",
                    1: "from-blue-600 to-blue-800 border-blue-400",
                    2: "from-red-600 to-red-800 border-red-400",
                    5: "from-yellow-500 to-yellow-700 border-yellow-300",
                  };
                  return (
                    <button key={v} onClick={() => setChipValue(v)}
                      className={`relative w-7 h-7 rounded-full font-black border-2 transition-all bg-gradient-to-b text-white
                        ${colors[v]}
                        ${chipValue === v
                          ? "scale-125 shadow-[0_0_10px_rgba(255,215,0,0.7)] ring-2 ring-yellow-300"
                          : "opacity-55 hover:opacity-90 hover:scale-110"}`}
                      style={{ fontSize: "9px" }}>
                      <span className="absolute inset-0 rounded-full border border-white/20" />
                      {v < 1 ? "½" : v}
                    </button>
                  );
                })}
              </div>
              <div className="ml-auto text-right">
                <div className="text-yellow-400 text-xs font-bold">{totalBet}/{MAX_BET} cr</div>
              </div>
            </div>
          </div>

          {/* ── Betting table ── */}
          <div className="flex-shrink-0 bg-black/40 border border-green-900/40 rounded-lg p-1.5 relative overflow-hidden">
            <div className="absolute inset-0 opacity-4 pointer-events-none"
              style={{ backgroundImage: "repeating-linear-gradient(45deg, #fff 0, #fff 1px, transparent 0, transparent 50%)", backgroundSize: "5px 5px" }} />
            <NumberGrid onBet={addBet} activeBets={bets} disabled={spinning} />
          </div>

          {/* ── Active bets (compact) ── */}
          {bets.length > 0 && (
            <div className="flex-shrink-0 bg-black/30 border border-yellow-700/20 rounded-lg px-2 py-0.5 max-h-12 overflow-y-auto">
              {bets.map((b, i) => (
                <div key={i} className="flex justify-between items-center py-0.5" style={{ fontSize: "10px" }}>
                  <span className="text-white/70">{betLabel(b.bet)}
                    <span className="text-white/30 ml-1">({betPayout(b.bet)}:1)</span>
                  </span>
                  <span className="text-yellow-400 font-bold">{b.amount}cr</span>
                </div>
              ))}
            </div>
          )}

          {/* ── SPIN — always at bottom, never pushed down ── */}
          <div className="flex-shrink-0 flex gap-2 mt-auto">
            <Button variant="outline" onClick={clearBets}
              disabled={spinning || bets.length === 0}
              className="w-14 border-red-700/50 text-red-400 hover:bg-red-900/20 bg-transparent text-xs h-10">
              Clear
            </Button>
            {lastBets.length > 0 && bets.length === 0 && !spinning && (
              <Button variant="outline" onClick={() => {
                // Restore last bets if credits allow
                const total = lastBets.reduce((s, b) => s + b.amount, 0);
                if (total > credits) { toast.error("Not enough credits for repeat bet"); return; }
                setBets(lastBets);
              }}
                className="w-20 border-blue-700/50 text-blue-300 hover:bg-blue-900/20 bg-transparent text-xs h-10">
                🔁 Repeat
              </Button>
            )}
            <Button onClick={spin}
              disabled={spinning || bets.length === 0 || !isAuthenticated}
              className="flex-1 font-black text-lg h-10 text-black tracking-widest"
              style={{
                background: spinning
                  ? "linear-gradient(135deg, #6b7280, #4b5563)"
                  : "linear-gradient(135deg, #FFD700, #B8860B)",
                boxShadow: spinning ? "none" : "0 0 28px rgba(255,215,0,0.5), 0 4px 16px rgba(0,0,0,0.5)",
                letterSpacing: "0.12em",
              }}>
              {spinning ? "🎡 Spinning..." : "🎡  SPIN!"}
            </Button>
          </div>

          {!isAuthenticated && (
            <p className="flex-shrink-0 text-center text-yellow-400/60 text-xs">
              <Link href="/api/oauth/login" className="underline hover:text-yellow-300">Log in</Link> to play
            </p>
          )}
        </div>
      </div>
    </div>
  );
}
