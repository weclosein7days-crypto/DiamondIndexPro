import { trpc } from "@/lib/trpc";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import {
  Coins, Star, Zap, Crown, Award, CheckCircle, Info,
  Camera, ShoppingBag, Gavel, RefreshCw, Plus
} from "lucide-react";
import { toast } from "sonner";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import NavBar from "@/components/NavBar";
import Footer from "@/components/Footer";

// ─── Plan definitions ────────────────────────────────────────────────────────
const PLANS = [
  {
    key: "free",
    name: "Free",
    price: 0,
    credits: 25,
    icon: Award,
    iconColor: "text-white/50",
    accent: "border-white/20 bg-white/5",
    features: [
      "25 credits / month",
      "Browse the marketplace",
      "Buy cards (registration required)",
      "AI grading (uses credits)",
      "Cannot list or sell cards",
    ],
    cta: "Current Free Plan",
    ctaClass: "bg-white/10 text-white/50 cursor-default",
  },
  {
    key: "starter",
    name: "Starter",
    price: 9.99,
    credits: 100,
    icon: Star,
    iconColor: "text-blue-400",
    accent: "border-blue-500/40 bg-blue-500/5",
    features: [
      "100 credits / month",
      "List & sell cards",
      "AI grading",
      "Live auctions",
      "Affiliate program access",
    ],
    cta: "Upgrade to Starter",
    ctaClass: "bg-blue-600 hover:bg-blue-700 text-white",
  },
  {
    key: "pro",
    name: "Pro",
    price: 19.99,
    credits: 500,
    icon: Zap,
    iconColor: "text-purple-400",
    accent: "border-purple-500/40 bg-purple-500/5",
    popular: true,
    features: [
      "500 credits / month",
      "Everything in Starter",
      "Batch grading",
      "Analytics dashboard",
      "Priority support",
    ],
    cta: "Upgrade to Pro",
    ctaClass: "bg-purple-600 hover:bg-purple-700 text-white",
  },
  {
    key: "elite",
    name: "Elite",
    price: 29.99,
    credits: 1000,
    icon: Crown,
    iconColor: "text-[#E8C547]",
    accent: "border-[#E8C547]/50 bg-[#E8C547]/5",
    features: [
      "1,000 credits / month",
      "Everything in Pro",
      "Custom label colors",
      "Featured store badge",
      "Dedicated support",
    ],
    cta: "Upgrade to Elite",
    ctaClass: "bg-[#E8C547] hover:bg-[#d4b040] text-black font-bold",
  },
];

// ─── Add-on credit packs per plan ────────────────────────────────────────────
const ADDON_PACKS: Record<string, { credits: number; price: number; label: string }[]> = {
  free: [
    { credits: 50,  price: 5.00,  label: "Half Starter Pack" },
    { credits: 100, price: 9.99,  label: "Full Starter Pack" },
  ],
  starter: [
    { credits: 50,  price: 5.00,  label: "Half Pack" },
    { credits: 100, price: 9.99,  label: "Full Pack" },
  ],
  pro: [
    { credits: 250, price: 10.00, label: "Half Pack" },
    { credits: 500, price: 19.99, label: "Full Pack" },
  ],
  elite: [
    { credits: 500,  price: 15.00, label: "Half Pack" },
    { credits: 1000, price: 29.99, label: "Full Pack" },
  ],
};

// ─── Credit cost table ────────────────────────────────────────────────────────
const CREDIT_COSTS = [
  { icon: Camera,      label: "AI Card Grading",     cost: "2 credits per card",   note: "Front + back analysis, condition report, estimated value" },
  { icon: ShoppingBag, label: "Arena Listing",        cost: "Free",                 note: "No credits required to list a card for sale" },
  { icon: Gavel,       label: "Auction — 5 Days",     cost: "3 credits",            note: "5-day auction listing" },
  { icon: Gavel,       label: "Auction — 7 Days",     cost: "5 credits",            note: "7-day auction listing" },
  { icon: Gavel,       label: "Auction — 10 Days",    cost: "8 credits",            note: "10-day auction listing" },
  { icon: RefreshCw,   label: "Trade Offers",         cost: "$10/person",           note: "SCG escrow fee charged when both parties agree to a trade" },
];

export default function Credits() {
  const { isAuthenticated } = useAuth();
  const { data: account } = trpc.credits.myAccount.useQuery(undefined, { enabled: isAuthenticated });

  const currentPlan = account?.plan ?? "free";
  const addonPacks = ADDON_PACKS[currentPlan] ?? ADDON_PACKS.free;

  if (!isAuthenticated) {
    return (
      <>
        <NavBar />
        <div className="min-h-screen bg-[#0a1628] flex items-center justify-center">
          <div className="text-center space-y-4 px-4">
            <Coins className="w-16 h-16 text-white/20 mx-auto" />
            <h2 className="text-2xl font-bold text-white">Sign In to Manage Credits</h2>
            <p className="text-white/50 text-sm max-w-xs mx-auto">
              Create a free account to get 25 credits each month — no credit card required.
            </p>
            <a
              href={getLoginUrl()}
              className="inline-block bg-[#C41E3A] hover:bg-[#a01830] text-white px-6 py-2 rounded-lg font-medium transition-colors"
            >
              Sign In / Register Free
            </a>
          </div>
        </div>
        <Footer />
      </>
    );
  }

  return (
    <>
      <NavBar />
      <div className="min-h-screen bg-[#0a1628] pb-16">
        <div className="container max-w-5xl py-8 space-y-10">

          {/* ── Header ─────────────────────────────────────────────────── */}
          <div>
            <h1 className="text-3xl font-black text-white mb-1" style={{ fontFamily: "Oswald, sans-serif" }}>
              Credits &amp; Plans
            </h1>
            <p className="text-white/50 text-sm">
              Credits power grading and auctions. Your plan determines how many you get each month.
            </p>
          </div>

          {/* ── Current balance card ────────────────────────────────────── */}
          {account && (
            <div className="bg-gradient-to-r from-[#0d1f3c] to-[#1a3a6b]/30 border border-white/10 rounded-2xl p-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <div className="flex items-center gap-4">
                <div className="w-14 h-14 rounded-xl bg-[#E8C547]/10 border border-[#E8C547]/30 flex items-center justify-center">
                  <Coins className="w-7 h-7 text-[#E8C547]" />
                </div>
                <div>
                  <p className="text-white/50 text-xs uppercase tracking-wide">Available Credits</p>
                  <p className="text-4xl font-black text-white">{account.credits.toLocaleString()}</p>
                </div>
              </div>
              <div className="text-right space-y-1">
                <Badge className="bg-[#1a3a6b] text-white border-white/20 capitalize text-xs">
                  {account.plan} Plan
                </Badge>
                <p className="text-xs text-white/40">Total purchased: {account.totalPurchased ?? 0}</p>
                <p className="text-xs text-white/40">Total spent: {account.totalSpent ?? 0}</p>
              </div>
            </div>
          )}

          {/* ── How to earn credits ─────────────────────────────── */}
          <div>
            <h2 className="text-xl font-bold text-white mb-1" style={{ fontFamily: "Oswald, sans-serif" }}>
              How to Earn Credits
            </h2>
            <p className="text-white/40 text-xs mb-5">
              Credits are free to earn — no subscription required.
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="bg-[#0d1f3c] border border-[#E8C547]/30 rounded-2xl p-5">
                <div className="w-10 h-10 rounded-xl bg-[#E8C547]/10 border border-[#E8C547]/30 flex items-center justify-center mb-3">
                  <Star className="w-5 h-5 text-[#E8C547]" />
                </div>
                <div className="font-bold text-white mb-1">Sign Up Bonus</div>
                <div className="text-3xl font-black text-[#E8C547] mb-1">25</div>
                <p className="text-xs text-white/50">Free credits when you create your account. No credit card needed.</p>
              </div>
              <div className="bg-[#0d1f3c] border border-green-500/30 rounded-2xl p-5">
                <div className="w-10 h-10 rounded-xl bg-green-500/10 border border-green-500/30 flex items-center justify-center mb-3">
                  <Award className="w-5 h-5 text-green-400" />
                </div>
                <div className="font-bold text-white mb-1">Refer a Friend</div>
                <div className="text-3xl font-black text-green-400 mb-1">20</div>
                <p className="text-xs text-white/50">Earn 20 credits for each friend who signs up with your referral link. Plus 10 credits for tier 2!</p>
                <a href="/referral" className="inline-block mt-2 text-xs text-[#C41E3A] hover:underline font-semibold">Get your link →</a>
              </div>
              <div className="bg-[#0d1f3c] border border-blue-500/30 rounded-2xl p-5">
                <div className="w-10 h-10 rounded-xl bg-blue-500/10 border border-blue-500/30 flex items-center justify-center mb-3">
                  <Coins className="w-5 h-5 text-blue-400" />
                </div>
                <div className="font-bold text-white mb-1">Buy Credits</div>
                <div className="text-3xl font-black text-blue-400 mb-1">+</div>
                <p className="text-xs text-white/50">Need more? Purchase credit packs below. Credits never expire and stack with earned credits.</p>
              </div>
            </div>
          </div>

          <Separator className="bg-white/10" />

          {/* ── Add-on credit packs ─────────────────────────────────────── */}
          <div>
            <h2 className="text-xl font-bold text-white mb-1" style={{ fontFamily: "Oswald, sans-serif" }}>
              Add More Credits
            </h2>
            <p className="text-white/40 text-xs mb-5">
              Need more credits before your plan resets? Purchase a top-up pack at your plan's rate.
              Add-on credits never expire and stack with your monthly allowance.
            </p>
            <div className="grid grid-cols-2 gap-4 max-w-md">
              {addonPacks.map((pack) => (
                <div
                  key={pack.credits}
                  className="bg-[#0d1f3c] border border-white/10 rounded-xl p-5 text-center hover:border-[#E8C547]/40 transition-all group"
                >
                  <div className="flex items-center justify-center gap-1 mb-1">
                    <Plus className="w-4 h-4 text-[#E8C547]" />
                    <span className="text-3xl font-black text-[#E8C547] group-hover:scale-110 transition-transform inline-block">
                      {pack.credits.toLocaleString()}
                    </span>
                  </div>
                  <div className="text-xs text-white/40 mb-1">credits</div>
                  <div className="text-xs text-white/30 mb-3">{pack.label}</div>
                  <div className="font-bold text-xl text-white mb-4">${pack.price.toFixed(2)}</div>
                  <Button
                    size="sm"
                    className="w-full bg-[#C41E3A] hover:bg-[#a01830] text-white text-xs"
                    onClick={() => toast.info("Credit purchase via Stripe coming soon!")}
                  >
                    Buy {pack.credits.toLocaleString()} Credits
                  </Button>
                </div>
              ))}
            </div>
            <p className="text-white/30 text-xs mt-3 flex items-start gap-1.5">
              <Info className="w-3.5 h-3.5 shrink-0 mt-0.5" />
              Add-on packs are priced at your current plan's per-credit rate. Upgrading your plan gives you a better rate and more monthly credits.
            </p>
          </div>

          <Separator className="bg-white/10" />

          {/* ── What credits are used for ──────────────────────────────── */}
          <div>
            <h2 className="text-xl font-bold text-white mb-5" style={{ fontFamily: "Oswald, sans-serif" }}>
              What Are Credits Used For?
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {CREDIT_COSTS.map(({ icon: Icon, label, cost, note }) => (
                <div key={label} className="bg-[#0d1f3c] border border-white/10 rounded-xl p-4 flex gap-3">
                  <div className="w-9 h-9 rounded-lg bg-[#1a3a6b] flex items-center justify-center shrink-0">
                    <Icon className="w-4 h-4 text-[#E8C547]" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2 mb-0.5 flex-wrap">
                      <span className="text-sm font-semibold text-white">{label}</span>
                      <Badge className="bg-[#C41E3A]/20 text-[#C41E3A] border-[#C41E3A]/30 text-[10px] px-1.5 py-0">{cost}</Badge>
                    </div>
                    <p className="text-xs text-white/50">{note}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* ── Fee structure ──────────────────────────────────────────── */}
          <div className="bg-[#0d1f3c] border border-white/10 rounded-2xl p-6">
            <h3 className="font-bold text-white mb-2 flex items-center gap-2" style={{ fontFamily: "Oswald, sans-serif" }}>
              <Coins className="w-4 h-4 text-[#E8C547]" /> Platform Fees (Separate from Credits)
            </h3>
            <p className="text-white/50 text-xs mb-4">
              Platform fees are deducted from your sale proceeds automatically — they are separate from credits and only apply when you sell.
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-sm">
              <div className="space-y-1">
                <div className="font-semibold text-white">Arena Sale</div>
                <p className="text-white/50 text-xs">You keep <span className="text-green-400 font-bold">90%</span> of the sale price. Platform fee: 10%.</p>
              </div>
              <div className="space-y-1">
                <div className="font-semibold text-white">Auction Listing Fee</div>
                <p className="text-white/50 text-xs"><span className="text-[#E8C547] font-bold">10%</span> of starting price, deducted from final proceeds.</p>
              </div>
              <div className="space-y-1">
                <div className="font-semibold text-white">Auction Sale Fee</div>
                <p className="text-white/50 text-xs">Additional <span className="text-[#E8C547] font-bold">5%</span> of final bid. Total platform take: up to 15%.</p>
              </div>
            </div>
          </div>

        </div>
      </div>
      <Footer />
    </>
  );
}
