/**
 * Rock Paper Scissors — Kids Corner Game
 *
 * ALL THREE players (kid + Maverick + Caitlin) throw simultaneously.
 * Animated hand gestures, 3-2-1-SHOOT countdown, trash talk dialogue.
 * Web Audio API for countdown beeps, throw whoosh, cheer/groan.
 */

import { useState, useEffect, useRef, useCallback } from "react";
import { useSFX } from "@/hooks/useSFX";

const MASCOT_CDN = "https://d2xsxph8kpxj0f.cloudfront.net/310519663522483910/L9wJitqmU3uwF2WPjH8hRS/kids-corner-mascot_08fe6054.jpg";

type Throw = "rock" | "paper" | "scissors";
type GameState = "pick" | "countdown" | "reveal" | "result";

// Sound provided by useSFX hook

// ── Game logic ────────────────────────────────────────────────────────────────
function beats(a: Throw, b: Throw) {
  return (a === "rock" && b === "scissors") || (a === "scissors" && b === "paper") || (a === "paper" && b === "rock");
}

function getOutcome(kid: Throw, mav: Throw, cait: Throw): { kidResult: "win" | "lose" | "tie"; winner: string } {
  const kidBeats = [mav, cait].filter(t => beats(kid, t)).length;
  const mavBeats = [kid, cait].filter(t => beats(mav, t)).length;
  const caitBeats = [kid, mav].filter(t => beats(cait, t)).length;
  const max = Math.max(kidBeats, mavBeats, caitBeats);
  if (max === 0) return { kidResult: "tie", winner: "tie" };
  if (kidBeats === max && mavBeats < max && caitBeats < max) return { kidResult: "win", winner: "kid" };
  if (mavBeats === max && kidBeats < max) return { kidResult: "lose", winner: "maverick" };
  if (caitBeats === max && kidBeats < max) return { kidResult: "lose", winner: "caitlin" };
  return { kidResult: "tie", winner: "tie" };
}

const THROW_EMOJI: Record<Throw, string> = { rock: "✊", paper: "🖐️", scissors: "✌️" };
const THROW_LABEL: Record<Throw, string> = { rock: "ROCK", paper: "PAPER", scissors: "SCISSORS" };

// ── Dialogue banks ────────────────────────────────────────────────────────────
const PRE_GAME = [
  "I've been practicing my rock throw ALL week 😤",
  "Scissors always wins... trust me 😏",
  "I'm going paper, I'm going paper... or am I? 🤔",
  "My hand is ready. Are YOU ready? 🤜",
  "Three-way RPS? This is MY game! 😎",
];
const WIN_LINES = [
  "CALLED IT! I'm undefeated! 🏆",
  "You can't beat the BEST! 😂",
  "Did you even try?? 😂",
  "TOO EASY! Rematch? 😈",
];
const LOSE_LINES = [
  "I demand a rematch! 😤",
  "That was... a practice round 😅",
  "My hand slipped! 🙄",
  "Lucky throw! 😒",
];
const TIE_LINES = [
  "A TIE?! We're all too good! 🤝",
  "Great minds think alike! 🧠",
  "Nobody wins... nobody loses... 🤷",
];
const TRASH_TALK = [
  "Bet you're going rock... 👀",
  "I can READ your mind! 🔮",
  "Don't overthink it! 😂",
  "I already know what you're throwing 😏",
];

const rand = (arr: string[]) => arr[Math.floor(Math.random() * arr.length)];
const randThrow = (): Throw => (["rock", "paper", "scissors"] as Throw[])[Math.floor(Math.random() * 3)];

// ── Hand animation component ──────────────────────────────────────────────────
function HandDisplay({
  throw: t,
  hidden,
  label,
  color,
  isShaking,
}: {
  throw: Throw | null;
  hidden?: boolean;
  label: string;
  color: string;
  isShaking?: boolean;
}) {
  return (
    <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 8 }}>
      <div style={{ color: "rgba(255,255,255,0.5)", fontSize: 11, textTransform: "uppercase", letterSpacing: 2, fontFamily: "Oswald, sans-serif" }}>
        {label}
      </div>
      <div style={{
        width: 90,
        height: 90,
        borderRadius: 20,
        border: `3px solid ${color}`,
        background: `${color}22`,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        fontSize: 44,
        boxShadow: `0 0 20px ${color}44`,
        animation: isShaking
          ? "hand-shake 0.15s ease-in-out infinite"
          : t
          ? "hand-reveal 0.4s cubic-bezier(0.34,1.56,0.64,1) forwards"
          : "none",
        transition: "all 0.3s",
      }}>
        {hidden || !t ? "❓" : THROW_EMOJI[t]}
      </div>
      {!hidden && t && (
        <div style={{
          color,
          fontWeight: 900,
          fontSize: 12,
          fontFamily: "Oswald, sans-serif",
          letterSpacing: 2,
          animation: "speech-pop 0.3s ease-out forwards",
        }}>
          {THROW_LABEL[t]}
        </div>
      )}
    </div>
  );
}

// ── Character portrait ────────────────────────────────────────────────────────
function CharPortrait({
  character,
  size = 80,
  state,
  speech,
  speechSide = "top",
}: {
  character: "maverick" | "caitlin";
  size?: number;
  state: "idle" | "excited" | "sad" | "thinking";
  speech?: string;
  speechSide?: "left" | "right" | "top";
}) {
  const imgW = size * 2;
  const objPos = character === "maverick" ? "0% 15%" : "100% 15%";
  const marginLeft = character === "maverick" ? 0 : -size;
  const animations = {
    idle: "mascot-idle-float 3s ease-in-out infinite",
    excited: "mascot-bounce 0.5s ease-in-out infinite",
    sad: "mascot-droop 0.4s ease-out forwards",
    thinking: "mascot-wave 2s ease-in-out infinite",
  };
  return (
    <div style={{ position: "relative", display: "inline-flex", flexDirection: "column", alignItems: "center" }}>
      {speech && (
        <div style={{
          position: "absolute",
          ...(speechSide === "top" ? { bottom: "100%", left: "50%", transform: "translateX(-50%)", marginBottom: 6 } : {}),
          ...(speechSide === "right" ? { left: "105%", top: "10%", marginLeft: 6 } : {}),
          ...(speechSide === "left" ? { right: "105%", top: "10%", marginRight: 6 } : {}),
          background: "white",
          color: "#1a1a2e",
          borderRadius: 12,
          padding: "6px 10px",
          fontSize: 11,
          fontWeight: 900,
          whiteSpace: "nowrap",
          maxWidth: 180,
          textAlign: "center",
          boxShadow: "0 4px 12px rgba(0,0,0,0.3)",
          animation: "speech-pop 0.3s ease-out forwards",
          zIndex: 20,
          fontFamily: "Oswald, sans-serif",
        }}>
          {speech}
        </div>
      )}
      <div style={{
        width: size, height: size, overflow: "hidden", borderRadius: "50%",
        border: `3px solid ${character === "maverick" ? "#60a5fa" : "#f472b6"}`,
        boxShadow: `0 0 16px ${character === "maverick" ? "rgba(96,165,250,0.4)" : "rgba(244,114,182,0.4)"}`,
        animation: animations[state],
        filter: state === "sad" ? "saturate(0.5) brightness(0.8)" : undefined,
      }}>
        <img src={MASCOT_CDN} alt={character} style={{ width: imgW, height: "auto", objectFit: "cover", objectPosition: objPos, marginLeft, display: "block", pointerEvents: "none" }} draggable={false} />
      </div>
      <div style={{ marginTop: 3, fontSize: 10, fontWeight: 900, color: character === "maverick" ? "#60a5fa" : "#f472b6", fontFamily: "Oswald, sans-serif", textTransform: "uppercase", letterSpacing: 1 }}>
        {character === "maverick" ? "Maverick" : "Caitlin"}
      </div>
    </div>
  );
}

// ── Inject keyframes ──────────────────────────────────────────────────────────
let injected = false;
function injectStyles() {
  if (injected) return; injected = true;
  const s = document.createElement("style");
  s.textContent = `
    @keyframes hand-shake { 0%,100%{transform:translateY(0)} 50%{transform:translateY(-8px)} }
    @keyframes hand-reveal { 0%{transform:scale(0.3) rotate(-20deg);opacity:0} 60%{transform:scale(1.2) rotate(5deg);opacity:1} 100%{transform:scale(1) rotate(0deg);opacity:1} }
    @keyframes countdown-pop { 0%{transform:scale(0.2);opacity:0} 50%{transform:scale(1.3);opacity:1} 100%{transform:scale(1);opacity:1} }
    @keyframes shoot-flash { 0%{opacity:1} 50%{opacity:0.3} 100%{opacity:1} }
    @keyframes mascot-idle-float { 0%,100%{transform:translateY(0)} 50%{transform:translateY(-6px)} }
    @keyframes mascot-bounce { 0%,100%{transform:translateY(0)} 50%{transform:translateY(-14px)} }
    @keyframes mascot-droop { 0%{transform:translateY(0) rotate(0deg)} 100%{transform:translateY(6px) rotate(-8deg)} }
    @keyframes mascot-wave { 0%,100%{transform:rotate(0deg)} 25%{transform:rotate(-4deg)} 75%{transform:rotate(4deg)} }
    @keyframes speech-pop { 0%{transform:scale(0.5);opacity:0} 70%{transform:scale(1.05);opacity:1} 100%{transform:scale(1);opacity:1} }
    @keyframes result-pop { 0%{transform:scale(0.3) rotate(-10deg);opacity:0} 60%{transform:scale(1.15) rotate(3deg);opacity:1} 100%{transform:scale(1) rotate(0deg);opacity:1} }
  `;
  document.head.appendChild(s);
}

// ── Main game ─────────────────────────────────────────────────────────────────
interface RPSProps {
  kidName: string;
  onEarnCredits: (n: number) => void;
  onClose: () => void;
}

export default function RockPaperScissors({ kidName, onEarnCredits, onClose }: RPSProps) {
  useEffect(() => { injectStyles(); }, []);
  const sound = useSFX();

  const [gameState, setGameState] = useState<GameState>("pick");
  const [kidThrow, setKidThrow] = useState<Throw | null>(null);
  const [mavThrow, setMavThrow] = useState<Throw | null>(null);
  const [caitThrow, setCaitThrow] = useState<Throw | null>(null);
  const [countdown, setCountdown] = useState<number | null>(null);
  const [outcome, setOutcome] = useState<{ kidResult: "win" | "lose" | "tie"; winner: string } | null>(null);
  const [score, setScore] = useState({ kid: 0, maverick: 0, caitlin: 0, tie: 0 });
  const [totalWon, setTotalWon] = useState(0);
  const [mavSpeech, setMavSpeech] = useState<string | undefined>(rand(TRASH_TALK));
  const [caitSpeech, setCaitSpeech] = useState<string | undefined>(rand(PRE_GAME));
  const [mavState, setMavState] = useState<"idle" | "excited" | "sad" | "thinking">("thinking");
  const [caitState, setCaitState] = useState<"idle" | "excited" | "sad" | "thinking">("idle");
  const [round, setRound] = useState(1);
  const [isShaking, setIsShaking] = useState(false);

  const startCountdown = useCallback((chosen: Throw) => {
    setKidThrow(chosen);
    setGameState("countdown");
    setMavThrow(null); setCaitThrow(null);
    setMavSpeech("Here we go! 🤜"); setCaitSpeech("I'm ready! ✊");
    setMavState("thinking"); setCaitState("thinking");
    setIsShaking(true);

    let count = 3;
    setCountdown(count);
    sound.beep(440);

    const interval = setInterval(() => {
      count--;
      if (count > 0) {
        setCountdown(count);
        sound.beep(count === 1 ? 660 : 440);
      } else {
        clearInterval(interval);
        setCountdown(0); // "SHOOT!"
        setIsShaking(false);
        sound.whoosh();

        // Reveal all throws
        const mav = randThrow();
        const cait = randThrow();
        setMavThrow(mav);
        setCaitThrow(cait);
        setGameState("reveal");

        setTimeout(() => {
          const result = getOutcome(chosen, mav, cait);
          setOutcome(result);
          setGameState("result");

          if (result.kidResult === "win") {
            onEarnCredits(5);
            setTotalWon(t => t + 5);
            setScore(s => ({ ...s, kid: s.kid + 1 }));
            setMavState("sad"); setCaitState("sad");
            setMavSpeech(rand(LOSE_LINES));
            setCaitSpeech(rand(LOSE_LINES));
            sound.cheer();
          } else if (result.kidResult === "lose") {
            setScore(s => ({ ...s, [result.winner]: s[result.winner as keyof typeof s] + 1 }));
            if (result.winner === "maverick") {
              setMavState("excited"); setCaitState("sad");
              setMavSpeech(rand(WIN_LINES)); setCaitSpeech(rand(LOSE_LINES));
            } else {
              setCaitState("excited"); setMavState("sad");
              setCaitSpeech(rand(WIN_LINES)); setMavSpeech(rand(LOSE_LINES));
            }
            sound.groan();
          } else {
            setScore(s => ({ ...s, tie: s.tie + 1 }));
            setMavState("idle"); setCaitState("idle");
            setMavSpeech(rand(TIE_LINES)); setCaitSpeech(rand(TIE_LINES));
          }
        }, 600);
      }
    }, 900);
  }, [onEarnCredits, sound]);

  const nextRound = () => {
    setKidThrow(null); setMavThrow(null); setCaitThrow(null);
    setCountdown(null); setOutcome(null);
    setGameState("pick");
    setRound(r => r + 1);
    setMavState("thinking"); setCaitState("idle");
    setMavSpeech(rand(TRASH_TALK)); setCaitSpeech(rand(PRE_GAME));
  };

  return (
    <div style={{
      minHeight: "100vh",
      background: "linear-gradient(160deg, #0a0a1a 0%, #0f1a2e 50%, #1a0a3e 100%)",
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      padding: "24px 16px",
      fontFamily: "Oswald, sans-serif",
    }}>
      {/* Header */}
      <div style={{ width: "100%", maxWidth: 640, display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
        <button onClick={onClose} style={{ background: "rgba(255,255,255,0.1)", border: "none", color: "white", borderRadius: 8, padding: "6px 14px", cursor: "pointer", fontSize: 14, fontFamily: "Oswald, sans-serif" }}>
          ← Back
        </button>
        <h1 style={{ color: "white", fontSize: 20, fontWeight: 900, margin: 0, letterSpacing: 2 }}>
          ✊🖐️✌️ ROCK PAPER SCISSORS
        </h1>
        <div style={{ background: "rgba(251,191,36,0.2)", border: "1px solid #fbbf24", borderRadius: 8, padding: "4px 12px", color: "#fbbf24", fontSize: 13, fontWeight: 900 }}>
          +{totalWon} credits
        </div>
      </div>

      {/* Scoreboard */}
      <div style={{ display: "flex", gap: 10, marginBottom: 20, background: "rgba(255,255,255,0.05)", borderRadius: 12, padding: "10px 20px", border: "1px solid rgba(255,255,255,0.1)" }}>
        {[
          { label: kidName, score: score.kid, color: "#34d399" },
          { label: "Maverick", score: score.maverick, color: "#60a5fa" },
          { label: "Caitlin", score: score.caitlin, color: "#f472b6" },
          { label: "Tie", score: score.tie, color: "rgba(255,255,255,0.4)" },
        ].map(p => (
          <div key={p.label} style={{ textAlign: "center", minWidth: 60 }}>
            <div style={{ color: p.color, fontWeight: 900, fontSize: 20 }}>{p.score}</div>
            <div style={{ color: "rgba(255,255,255,0.5)", fontSize: 10, textTransform: "uppercase", letterSpacing: 1 }}>{p.label}</div>
          </div>
        ))}
        <div style={{ textAlign: "center", minWidth: 40, borderLeft: "1px solid rgba(255,255,255,0.1)", paddingLeft: 10 }}>
          <div style={{ color: "white", fontWeight: 900, fontSize: 20 }}>R{round}</div>
          <div style={{ color: "rgba(255,255,255,0.5)", fontSize: 10, textTransform: "uppercase", letterSpacing: 1 }}>Round</div>
        </div>
      </div>

      {/* Countdown overlay */}
      {gameState === "countdown" && countdown !== null && (
        <div style={{
          fontSize: countdown === 0 ? 52 : 80,
          fontWeight: 900,
          color: countdown === 0 ? "#f59e0b" : "white",
          letterSpacing: countdown === 0 ? 4 : 0,
          animation: "countdown-pop 0.4s cubic-bezier(0.34,1.56,0.64,1) forwards",
          marginBottom: 16,
          textShadow: "0 0 40px rgba(255,255,255,0.5)",
        }}>
          {countdown === 0 ? "SHOOT! 💥" : countdown}
        </div>
      )}

      {/* Three-player arena */}
      <div style={{ width: "100%", maxWidth: 640, display: "flex", alignItems: "flex-end", justifyContent: "space-around", gap: 8, marginBottom: 20 }}>
        {/* Maverick */}
        <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 12 }}>
          <CharPortrait character="maverick" size={75} state={mavState} speech={mavSpeech} speechSide="right" />
          <HandDisplay
            throw={mavThrow}
            hidden={gameState === "countdown"}
            label="Maverick"
            color="#60a5fa"
            isShaking={isShaking}
          />
        </div>

        {/* Kid (center) */}
        <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 12 }}>
          <div style={{
            width: 75, height: 75, borderRadius: "50%",
            background: "linear-gradient(135deg, #34d399, #059669)",
            display: "flex", alignItems: "center", justifyContent: "center",
            fontSize: 32,
            boxShadow: "0 0 20px rgba(52,211,153,0.4)",
            border: "3px solid #34d399",
          }}>
            🧒
          </div>
          <div style={{ color: "#34d399", fontWeight: 900, fontSize: 10, fontFamily: "Oswald, sans-serif", textTransform: "uppercase", letterSpacing: 1 }}>
            {kidName}
          </div>
          <HandDisplay
            throw={kidThrow}
            hidden={gameState === "countdown"}
            label="You"
            color="#34d399"
            isShaking={isShaking}
          />
        </div>

        {/* Caitlin */}
        <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 12 }}>
          <CharPortrait character="caitlin" size={75} state={caitState} speech={caitSpeech} speechSide="left" />
          <HandDisplay
            throw={caitThrow}
            hidden={gameState === "countdown"}
            label="Caitlin"
            color="#f472b6"
            isShaking={isShaking}
          />
        </div>
      </div>

      {/* Result banner */}
      {gameState === "result" && outcome && (
        <div style={{
          padding: "12px 28px",
          borderRadius: 18,
          background: outcome.kidResult === "win"
            ? "linear-gradient(135deg, #065f46, #059669)"
            : outcome.kidResult === "tie"
            ? "linear-gradient(135deg, #1e3a5f, #2563eb)"
            : "linear-gradient(135deg, #7f1d1d, #dc2626)",
          color: "white",
          fontWeight: 900,
          fontSize: 18,
          letterSpacing: 2,
          textTransform: "uppercase",
          animation: "result-pop 0.4s ease-out forwards",
          boxShadow: outcome.kidResult === "win"
            ? "0 0 30px rgba(5,150,105,0.6)"
            : outcome.kidResult === "tie"
            ? "0 0 30px rgba(37,99,235,0.5)"
            : "0 0 30px rgba(220,38,38,0.6)",
          marginBottom: 16,
          textAlign: "center",
        }}>
          {outcome.kidResult === "win"
            ? `🏆 YOU WIN! +5 credits! 🎉`
            : outcome.kidResult === "tie"
            ? `🤝 THREE-WAY TIE! Nobody wins!`
            : `${outcome.winner === "maverick" ? "Maverick" : "Caitlin"} wins this round! 😤`}
        </div>
      )}

      {/* Pick buttons or Next Round */}
      {gameState === "pick" && (
        <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 12 }}>
          <p style={{ color: "rgba(255,255,255,0.6)", fontSize: 13, margin: 0 }}>
            {kidName}, pick your throw — all three reveal at once!
          </p>
          <div style={{ display: "flex", gap: 14 }}>
            {(["rock", "paper", "scissors"] as Throw[]).map(t => (
              <button
                key={t}
                onClick={() => startCountdown(t)}
                style={{
                  width: 100,
                  height: 90,
                  borderRadius: 16,
                  border: "2px solid rgba(255,255,255,0.2)",
                  background: "rgba(255,255,255,0.05)",
                  color: "white",
                  cursor: "pointer",
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                  justifyContent: "center",
                  gap: 6,
                  transition: "all 0.15s",
                  fontFamily: "Oswald, sans-serif",
                }}
                onMouseEnter={e => {
                  (e.currentTarget as HTMLButtonElement).style.background = "rgba(255,255,255,0.12)";
                  (e.currentTarget as HTMLButtonElement).style.transform = "scale(1.08)";
                  (e.currentTarget as HTMLButtonElement).style.borderColor = "rgba(255,255,255,0.5)";
                }}
                onMouseLeave={e => {
                  (e.currentTarget as HTMLButtonElement).style.background = "rgba(255,255,255,0.05)";
                  (e.currentTarget as HTMLButtonElement).style.transform = "scale(1)";
                  (e.currentTarget as HTMLButtonElement).style.borderColor = "rgba(255,255,255,0.2)";
                }}
              >
                <span style={{ fontSize: 36 }}>{THROW_EMOJI[t]}</span>
                <span style={{ fontWeight: 900, fontSize: 12, letterSpacing: 2, textTransform: "uppercase" }}>{THROW_LABEL[t]}</span>
              </button>
            ))}
          </div>
        </div>
      )}

      {gameState === "result" && (
        <button
          onClick={nextRound}
          style={{
            padding: "13px 36px",
            borderRadius: 16,
            border: "none",
            background: "linear-gradient(135deg, #7c3aed, #4f46e5)",
            color: "white",
            fontWeight: 900,
            fontSize: 17,
            letterSpacing: 2,
            cursor: "pointer",
            fontFamily: "Oswald, sans-serif",
            boxShadow: "0 0 30px rgba(124,58,237,0.5)",
          }}>
          Next Round →
        </button>
      )}

      <p style={{ color: "rgba(255,255,255,0.3)", fontSize: 11, marginTop: 20, textAlign: "center" }}>
        Beat both Maverick AND Caitlin = +5 credits • All three throw at the same time!
      </p>
    </div>
  );
}
