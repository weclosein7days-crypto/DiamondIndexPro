/**
 * CARD BATTLE
 *
 * Rules:
 * - Each player flips 1 card per turn. Highest card wins both cards.
 * - Tie: each player lays 3 cards face-down, then flips a 4th face-up. Highest face-up wins all cards.
 * - If a player has fewer than 4 cards during a tie, they use however many they have; last card is the face-up.
 * - If a player runs out of cards they're eliminated.
 * - 8-minute game clock. Whoever has the most cards when time expires wins.
 * - 5-second shot clock per flip — if you don't flip in time you lose that round.
 * - Winner earns 52 × wager credits.
 * - Maverick and Caitlin are opponents with trash talk.
 */
import { useState, useEffect, useRef, useCallback } from "react";
import MascotCharacter from "@/components/MascotCharacter";
import { useSFX } from "@/hooks/useSFX";

// ── Card types ────────────────────────────────────────────────────────────────
const SUITS = ["♠", "♥", "♦", "♣"];
const RANKS = ["2","3","4","5","6","7","8","9","10","J","Q","K","A"];
const RANK_VALUES: Record<string, number> = {
  "2":2,"3":3,"4":4,"5":5,"6":6,"7":7,"8":8,"9":9,"10":10,
  "J":11,"Q":12,"K":13,"A":14,
};

interface Card { suit: string; rank: string; value: number; id: string; }
type Phase = "wager" | "playing" | "tie" | "result";
type Player = "player" | "maverick" | "caitlin";

function buildDeck(): Card[] {
  const deck: Card[] = [];
  for (const suit of SUITS) {
    for (const rank of RANKS) {
      deck.push({ suit, rank, value: RANK_VALUES[rank], id: `${rank}${suit}` });
    }
  }
  return deck;
}

function shuffle(deck: Card[]): Card[] {
  const d = [...deck];
  for (let i = d.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [d[i], d[j]] = [d[j], d[i]];
  }
  return d;
}

// ── Trash talk lines ──────────────────────────────────────────────────────────
const MAVERICK_WIN = ["Boom! Maverick takes it! 🏀", "That's mine! Easy money!", "Told ya I was better!", "Swish! Cards belong to me now!"];
const MAVERICK_LOSE = ["Lucky...", "Whatever, just warming up.", "I let you have that one.", "Ugh, no fair!"];
const MAVERICK_TIE = ["Oh it's WAR time! Let's go!", "Tie?! Bring it on!", "Three down, let's settle this!"];
const CAITLIN_WIN = ["WNBA champion right here! 🏆", "That's how Caitlin does it!", "Too easy! Next card!", "Clark scores again!"];
const CAITLIN_LOSE = ["Okay okay, you got lucky.", "I'll get you next time!", "That was a fluke!", "Hmph!"];
const CAITLIN_TIE = ["WAR! I live for this!", "Three cards down, let's go!", "Tie game — I'm ready!"];
const PLAYER_WIN_LINES = ["Nice flip! 🎉", "You got it!", "Cards are yours!", "Keep it up!"];
const SHOT_CLOCK_EXPIRED = ["Too slow! You lose this round! ⏰", "Time's up! Round goes to the house!", "Tick tock! You snooze you lose!"];

function pick<T>(arr: T[]): T { return arr[Math.floor(Math.random() * arr.length)]; }

// ── Card face component ───────────────────────────────────────────────────────
function CardFace({ card, faceDown, small }: { card?: Card; faceDown?: boolean; small?: boolean }) {
  const size = small ? "w-10 h-14 text-xs" : "w-16 h-24 text-base";
  const isRed = card?.suit === "♥" || card?.suit === "♦";

  if (faceDown || !card) {
    return (
      <div className={`${size} rounded-lg border-2 border-gray-600 bg-gradient-to-br from-blue-800 to-blue-950 flex items-center justify-center shadow-lg`}>
        <span className="text-blue-400 text-xl">🃏</span>
      </div>
    );
  }

  return (
    <div className={`${size} rounded-lg border-2 border-gray-300 bg-white flex flex-col items-start justify-between p-1 shadow-lg`}>
      <div className={`font-black leading-none ${isRed ? "text-red-600" : "text-gray-900"} ${small ? "text-xs" : "text-sm"}`}>
        {card.rank}<br />{card.suit}
      </div>
      <div className={`self-end rotate-180 font-black leading-none ${isRed ? "text-red-600" : "text-gray-900"} ${small ? "text-xs" : "text-sm"}`}>
        {card.rank}<br />{card.suit}
      </div>
    </div>
  );
}

// ── Player area ───────────────────────────────────────────────────────────────
function PlayerArea({ name, emoji, cardCount, topCard, faceDown, isActive, shotClock, isTie, tieCards }: {
  name: string; emoji: string; cardCount: number; topCard?: Card;
  faceDown?: boolean; isActive?: boolean; shotClock?: number;
  isTie?: boolean; tieCards?: (Card | null)[];
}) {
  return (
    <div className={`flex flex-col items-center gap-1 p-3 rounded-2xl transition-all ${isActive ? "bg-yellow-400/20 ring-2 ring-yellow-400" : "bg-white/5"}`}>
      <div className="text-2xl">{emoji}</div>
      <p className="text-xs font-bold text-white">{name}</p>
      <p className="text-[10px] text-blue-300">{cardCount} cards</p>

      {/* Tie cards: 3 face-down + 1 face-up */}
      {isTie && tieCards ? (
        <div className="flex gap-1 mt-1">
          {tieCards.map((c, i) => (
            <CardFace key={i} card={c || undefined} faceDown={i < tieCards.length - 1} small />
          ))}
        </div>
      ) : (
        <div className="mt-1">
          <CardFace card={topCard} faceDown={faceDown} />
        </div>
      )}

      {isActive && shotClock !== undefined && (
        <div className={`text-lg font-black ${shotClock <= 2 ? "text-red-400 animate-pulse" : "text-yellow-400"}`}>
          ⏱ {shotClock}s
        </div>
      )}
    </div>
  );
}

// ── Main game component ───────────────────────────────────────────────────────
interface GameTimeProps {
  onBack: () => void;
  kidCredits: number;
  onCreditsChange: (delta: number) => void;
}

export default function GameTime({ onBack, kidCredits, onCreditsChange }: GameTimeProps) {
  const sfx = useSFX();
  const [phase, setPhase] = useState<Phase>("wager");
  const [wager, setWager] = useState(1);

  // Decks
  const [playerDeck, setPlayerDeck] = useState<Card[]>([]);
  const [maverickDeck, setMaverickDeck] = useState<Card[]>([]);
  const [caitlinDeck, setCaitlinDeck] = useState<Card[]>([]);

  // Current round cards
  const [playerCard, setPlayerCard] = useState<Card | null>(null);
  const [maverickCard, setMaverickCard] = useState<Card | null>(null);
  const [caitlinCard, setCaitlinCard] = useState<Card | null>(null);

  // Tie state
  const [tieActive, setTieActive] = useState(false);
  const [playerTieCards, setPlayerTieCards] = useState<(Card | null)[]>([]);
  const [maverickTieCards, setMaverickTieCards] = useState<(Card | null)[]>([]);
  const [caitlinTieCards, setCaitlinTieCards] = useState<(Card | null)[]>([]);
  const [tiePool, setTiePool] = useState<Card[]>([]); // cards in the pot from tie

  // Game clock (8 minutes = 480s)
  const [gameTime, setGameTime] = useState(480);
  const [shotClock, setShotClock] = useState(5);
  const [message, setMessage] = useState("Flip your card!");
  const [mascotState, setMascotState] = useState<"idle" | "cheer" | "sad" | "hype">("idle");
  const [resultMsg, setResultMsg] = useState("");
  const [winner, setWinner] = useState<Player | "draw" | null>(null);
  const [roundWinner, setRoundWinner] = useState<Player | "tie" | null>(null);
  const [playerFlipped, setPlayerFlipped] = useState(false);
  const [showResult, setShowResult] = useState(false);

  const gameTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const shotTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // ── Start game ──────────────────────────────────────────────────────────────
  const startGame = useCallback(() => {
    const deck = shuffle(buildDeck());
    // Deal 17-18 cards each (52 total / 3 players)
    const p = deck.slice(0, 18);
    const m = deck.slice(18, 35);
    const c = deck.slice(35, 52);
    setPlayerDeck(p);
    setMaverickDeck(m);
    setCaitlinDeck(c);
    setPlayerCard(null); setMaverickCard(null); setCaitlinCard(null);
    setTieActive(false);
    setTiePool([]);
    setGameTime(480);
    setShotClock(5);
    setMessage("Flip your card!");
    setMascotState("idle");
    setRoundWinner(null);
    setPlayerFlipped(false);
    setShowResult(false);
    setPhase("playing");
  }, []);

  // ── Game clock ──────────────────────────────────────────────────────────────
  useEffect(() => {
    if (phase !== "playing") return;
    gameTimerRef.current = setInterval(() => {
      setGameTime(t => {
        if (t <= 1) {
          clearInterval(gameTimerRef.current!);
          endGame();
          return 0;
        }
        return t - 1;
      });
    }, 1000);
    return () => clearInterval(gameTimerRef.current!);
  }, [phase]);

  // ── Shot clock ──────────────────────────────────────────────────────────────
  useEffect(() => {
    if (phase !== "playing" || playerFlipped) return;
    shotTimerRef.current = setInterval(() => {
      setShotClock(s => {
        if (s <= 1) {
          clearInterval(shotTimerRef.current!);
          // Shot clock expired — player loses this round
          setMessage(pick(SHOT_CLOCK_EXPIRED));
          // AI still flips, player loses top card to pot
          autoResolveRound(true);
          return 5;
        }
        return s - 1;
      });
    }, 1000);
    return () => clearInterval(shotTimerRef.current!);
  }, [phase, playerFlipped]);

  function resetShotClock() {
    clearInterval(shotTimerRef.current!);
    setShotClock(5);
  }

  // ── Player flips ────────────────────────────────────────────────────────────
  function playerFlip() {
    if (playerFlipped || phase !== "playing") return;
    if (playerDeck.length === 0) return;

    sfx.cardFlip(); // play flip sound
    resetShotClock();
    setPlayerFlipped(true);

    const [pCard, ...pRest] = playerDeck;
    const [mCard, ...mRest] = maverickDeck.length > 0 ? [maverickDeck[0], ...maverickDeck.slice(1)] : [null, ...maverickDeck];
    const [cCard, ...cRest] = caitlinDeck.length > 0 ? [caitlinDeck[0], ...caitlinDeck.slice(1)] : [null, ...caitlinDeck];

    setPlayerCard(pCard);
    setMaverickCard(mCard || null);
    setCaitlinCard(cCard || null);
    setPlayerDeck(pRest);
    if (mCard) setMaverickDeck(mRest);
    if (cCard) setCaitlinDeck(cRest);

    // Resolve after a short delay so the flip animation plays
    setTimeout(() => resolveRound(pCard, mCard, cCard, pRest, mRest, cRest, []), 1200);
  }

  function autoResolveRound(shotExpired: boolean) {
    if (playerDeck.length === 0) return;
    const [pCard, ...pRest] = playerDeck;
    const [mCard, ...mRest] = maverickDeck.length > 0 ? [maverickDeck[0], ...maverickDeck.slice(1)] : [null, ...maverickDeck];
    const [cCard, ...cRest] = caitlinDeck.length > 0 ? [caitlinDeck[0], ...caitlinDeck.slice(1)] : [null, ...caitlinDeck];

    setPlayerCard(pCard);
    setMaverickCard(mCard || null);
    setCaitlinCard(cCard || null);
    setPlayerDeck(pRest);
    if (mCard) setMaverickDeck(mRest);
    if (cCard) setCaitlinDeck(cRest);

    // If shot clock expired, player loses their card to the pot (no win possible)
    if (shotExpired) {
      const pot = [pCard, mCard, cCard].filter(Boolean) as Card[];
      // Give pot to Maverick (arbitrary) or split
      setMaverickDeck(prev => [...prev, ...pot]);
      setPlayerFlipped(false);
      setRoundWinner("maverick");
      setTimeout(nextRound, 1800);
    } else {
      setTimeout(() => resolveRound(pCard, mCard, cCard, pRest, mRest, cRest, []), 1200);
    }
  }

  function resolveRound(
    pCard: Card, mCard: Card | null, cCard: Card | null,
    pRest: Card[], mRest: Card[], cRest: Card[],
    extraPot: Card[]
  ) {
    const cards = [
      { player: "player" as Player, card: pCard },
      ...(mCard ? [{ player: "maverick" as Player, card: mCard }] : []),
      ...(cCard ? [{ player: "caitlin" as Player, card: cCard }] : []),
    ];

    const maxVal = Math.max(...cards.map(c => c.card.value));
    const winners = cards.filter(c => c.card.value === maxVal);
    const pot = [...extraPot, ...cards.map(c => c.card)];

    if (winners.length > 1) {
      // TIE — enter war
      sfx.war(); // dramatic WAR sting
      setTieActive(true);
      setTiePool(pot);
      setMessage("⚔️ WAR! Lay 3 cards face-down then flip your 4th!");
      setMascotState("hype");
      setRoundWinner("tie");
      // AI lays their tie cards automatically
      resolveTie(pRest, mRest, cRest, pot);
    } else {
      const w = winners[0].player;
      setRoundWinner(w);
      awardPot(w, pot, pRest, mRest, cRest);
    }
  }

  function resolveTie(pRest: Card[], mRest: Card[], cRest: Card[], pot: Card[]) {
    // Each player lays up to 3 face-down cards + 1 face-up
    function takeTieCards(deck: Card[]): { tieCards: (Card | null)[]; remaining: Card[] } {
      if (deck.length === 0) return { tieCards: [], remaining: [] };
      const count = Math.min(4, deck.length);
      const taken = deck.slice(0, count);
      const remaining = deck.slice(count);
      // Pad to 4 with nulls if fewer cards
      const padded: (Card | null)[] = [...taken];
      while (padded.length < 4) padded.unshift(null);
      return { tieCards: padded, remaining };
    }

    const { tieCards: pTie, remaining: pAfterTie } = takeTieCards(pRest);
    const { tieCards: mTie, remaining: mAfterTie } = takeTieCards(mRest);
    const { tieCards: cTie, remaining: cAfterTie } = takeTieCards(cRest);

    setPlayerTieCards(pTie);
    setMaverickTieCards(mTie);
    setCaitlinTieCards(cTie);

    // All cards go into the pot
    const allTieCards = [...pTie, ...mTie, ...cTie].filter(Boolean) as Card[];
    const newPot = [...pot, ...allTieCards];

    // Face-up cards are the last in each array
    const pFaceUp = pTie[pTie.length - 1];
    const mFaceUp = mTie[mTie.length - 1];
    const cFaceUp = cTie[cTie.length - 1];

    setTimeout(() => {
      // Compare face-up cards
      const faceUps = [
        ...(pFaceUp ? [{ player: "player" as Player, card: pFaceUp }] : []),
        ...(mFaceUp ? [{ player: "maverick" as Player, card: mFaceUp }] : []),
        ...(cFaceUp ? [{ player: "caitlin" as Player, card: cFaceUp }] : []),
      ];

      if (faceUps.length === 0) {
        // Everyone ran out — draw
        setTieActive(false);
        setPlayerFlipped(false);
        nextRound();
        return;
      }

      const maxVal = Math.max(...faceUps.map(f => f.card.value));
      const tieWinners = faceUps.filter(f => f.card.value === maxVal);

      if (tieWinners.length > 1) {
        // Another tie! Recurse
        setTiePool(newPot);
        resolveTie(pAfterTie, mAfterTie, cAfterTie, newPot);
      } else {
        const w = tieWinners[0].player;
        setTieActive(false);
        setRoundWinner(w);
        awardPot(w, newPot, pAfterTie, mAfterTie, cAfterTie);
      }
    }, 2000);
  }

  function awardPot(winner: Player, pot: Card[], pRest: Card[], mRest: Card[], cRest: Card[]) {
    if (winner === "player") {
      sfx.warWin(); // player wins the pile
      setPlayerDeck(prev => [...prev, ...pRest, ...pot]);
      setMaverickDeck(mRest);
      setCaitlinDeck(cRest);
      setMessage(pick(PLAYER_WIN_LINES));
      setMascotState("sad");
    } else if (winner === "maverick") {
      sfx.cardFlip(); // AI wins
      setMaverickDeck(prev => [...prev, ...mRest, ...pot]);
      setPlayerDeck(pRest);
      setCaitlinDeck(cRest);
      setMessage(pick(MAVERICK_WIN));
      setMascotState("cheer");
    } else {
      sfx.cardFlip(); // AI wins
      setCaitlinDeck(prev => [...prev, ...cRest, ...pot]);
      setPlayerDeck(pRest);
      setMaverickDeck(mRest);
      setMessage(pick(CAITLIN_WIN));
      setMascotState("cheer");
    }

    // Check eliminations
    setTimeout(() => {
      checkElimination();
      setPlayerFlipped(false);
      nextRound();
    }, 1800);
  }

  function checkElimination() {
    // If a player has 0 cards, they're out — game might end
    const pOut = playerDeck.length === 0;
    const mOut = maverickDeck.length === 0;
    const cOut = caitlinDeck.length === 0;
    if (pOut || (mOut && cOut)) {
      endGame();
    }
  }

  function nextRound() {
    setPlayerCard(null);
    setMaverickCard(null);
    setCaitlinCard(null);
    setPlayerTieCards([]);
    setMaverickTieCards([]);
    setCaitlinTieCards([]);
    setTiePool([]);
    setRoundWinner(null);
    setMascotState("idle");
    setShotClock(5);
    setMessage("Flip your card!");
  }

  function endGame() {
    clearInterval(gameTimerRef.current!);
    clearInterval(shotTimerRef.current!);

    const pCount = playerDeck.length + (playerCard ? 1 : 0);
    const mCount = maverickDeck.length + (maverickCard ? 1 : 0);
    const cCount = caitlinDeck.length + (caitlinCard ? 1 : 0);

    let w: Player | "draw";
    if (pCount > mCount && pCount > cCount) {
      w = "player";
      const prize = 52 * wager;
      onCreditsChange(prize);
      setResultMsg(`🏆 YOU WIN! You had the most cards! +${prize} credits!`);
      setMascotState("sad");
      setTimeout(() => { sfx.cheer(); sfx.creditEarned(); }, 300);
    } else if (mCount >= pCount && mCount >= cCount) {
      w = "maverick";
      onCreditsChange(-wager);
      setResultMsg(`😤 Maverick wins with ${mCount} cards! Better luck next time!`);
      setMascotState("cheer");
      setTimeout(() => sfx.groan(), 300);
    } else if (cCount >= pCount) {
      w = "caitlin";
      onCreditsChange(-wager);
      setResultMsg(`🏆 Caitlin wins with ${cCount} cards! She's unstoppable!`);
      setMascotState("cheer");
      setTimeout(() => sfx.groan(), 300);
    } else {
      w = "draw";
      setResultMsg(`🤝 It's a draw! No credits lost or gained.`);
      setMascotState("idle");
    }

    setWinner(w);
    setPhase("result");
  }

  const formatTime = (s: number) => `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`;

  // ── Wager screen ────────────────────────────────────────────────────────────
  if (phase === "wager") {
    return (
      <div className="h-full bg-gradient-to-b from-green-950 via-green-900 to-green-950 flex flex-col items-center justify-center p-4 overflow-y-auto">
        <button onClick={onBack} className="absolute top-4 left-4 text-green-300 hover:text-white text-sm">← Back</button>
        <div className="text-center mb-8">
          <div className="text-6xl mb-3">🃏</div>
          <h1 className="text-4xl font-black text-yellow-400 mb-1" style={{ fontFamily: "Oswald, sans-serif" }}>CARD BATTLE</h1>
          <p className="text-green-300 text-sm">Card Battle • 3 Players • 8 Minutes</p>
        </div>

        {/* Rules */}
        <div className="bg-black/30 rounded-2xl p-4 mb-6 max-w-sm w-full text-sm text-green-200 space-y-1">
          <p>🃏 Flip 1 card — highest card wins the pile</p>
          <p>⚔️ Tie? Lay 3 face-down, flip a 4th to break it</p>
          <p>⏱ 5-second shot clock — flip or lose the round!</p>
          <p>⏰ 8-minute game — most cards wins</p>
          <p>🏆 Win = 52 × your wager in credits</p>
        </div>

        {/* Wager */}
        <div className="bg-black/30 rounded-2xl p-4 mb-6 max-w-sm w-full">
          <p className="text-center text-yellow-400 font-bold mb-3">Choose Your Wager</p>
          <div className="flex gap-2 justify-center mb-2">
            {[1,2,3,4,5].map(w => (
              <button key={w} onClick={() => setWager(w)}
                className={`w-12 h-12 rounded-xl font-black text-lg transition-all ${wager === w ? "bg-yellow-400 text-black scale-110" : "bg-white/10 text-white hover:bg-white/20"}`}>
                {w}
              </button>
            ))}
          </div>
          <p className="text-center text-green-300 text-xs">Win = 52 × {wager} = <strong className="text-yellow-400">{52 * wager} credits</strong></p>
          <p className="text-center text-green-400 text-xs mt-1">Your credits: {kidCredits}</p>
        </div>

        <button
          onClick={startGame}
          disabled={kidCredits < wager}
          className="bg-gradient-to-r from-yellow-400 to-orange-500 text-black font-black text-xl px-10 py-4 rounded-2xl shadow-xl hover:scale-105 transition-all disabled:opacity-40"
        >
          🎮 DEAL CARDS!
        </button>
        {kidCredits < wager && <p className="text-red-400 text-xs mt-2">Not enough credits!</p>}
      </div>
    );
  }

  // ── Result screen ───────────────────────────────────────────────────────────
  if (phase === "result") {
    return (
      <div className="h-full bg-gradient-to-b from-green-950 to-green-900 flex flex-col items-center justify-center p-4 text-center overflow-y-auto">
        <div className="text-6xl mb-4">{winner === "player" ? "🏆" : winner === "draw" ? "🤝" : "😤"}</div>
        <h2 className="text-3xl font-black text-yellow-400 mb-3" style={{ fontFamily: "Oswald, sans-serif" }}>GAME OVER!</h2>
        <p className="text-white text-lg font-bold mb-2">{resultMsg}</p>
        <div className="flex gap-4 text-sm text-green-300 mb-6">
          <span>You: {playerDeck.length} cards</span>
          <span>Maverick: {maverickDeck.length} cards</span>
          <span>Caitlin: {caitlinDeck.length} cards</span>
        </div>
        <div className="flex gap-3">
          <button onClick={() => setPhase("wager")}
            className="bg-yellow-400 text-black font-black px-6 py-3 rounded-xl hover:bg-yellow-300 transition-all">
            🔄 Play Again
          </button>
          <button onClick={onBack}
            className="bg-white/10 text-white font-bold px-6 py-3 rounded-xl hover:bg-white/20 transition-all">
            ← Back
          </button>
        </div>
      </div>
    );
  }

  // ── Playing screen ──────────────────────────────────────────────────────────
  return (
    <div className="h-full bg-gradient-to-b from-green-950 via-green-900 to-green-950 flex flex-col p-3 overflow-y-auto">
      {/* Header */}
      <div className="flex items-center justify-between mb-3">
        <button onClick={onBack} className="text-green-300 hover:text-white text-sm">← Exit</button>
        <div className="text-center">
          <div className={`text-xl font-black ${gameTime <= 60 ? "text-red-400 animate-pulse" : "text-yellow-400"}`} style={{ fontFamily: "Oswald, sans-serif" }}>
            ⏰ {formatTime(gameTime)}
          </div>
          <p className="text-[10px] text-green-300">Wager: {wager} cr</p>
        </div>
        <div className="text-right">
          <p className="text-xs text-green-300">Your cards</p>
          <p className="text-xl font-black text-white">{playerDeck.length}</p>
        </div>
      </div>

      {/* Message */}
      <div className="bg-black/30 rounded-xl px-4 py-2 text-center mb-3">
        <p className="text-sm font-bold text-yellow-400">{message}</p>
      </div>

      {/* Players */}
      <div className="grid grid-cols-3 gap-2 mb-3">
        <PlayerArea
          name="You"
          emoji="🧒"
          cardCount={playerDeck.length}
          topCard={playerCard || undefined}
          faceDown={!playerCard}
          isActive={!playerFlipped && phase === "playing"}
          shotClock={!playerFlipped ? shotClock : undefined}
          isTie={tieActive}
          tieCards={tieActive ? playerTieCards : undefined}
        />
        <PlayerArea
          name="Maverick"
          emoji="🏀"
          cardCount={maverickDeck.length}
          topCard={maverickCard || undefined}
          faceDown={!maverickCard}
          isTie={tieActive}
          tieCards={tieActive ? maverickTieCards : undefined}
        />
        <PlayerArea
          name="Caitlin"
          emoji="🏆"
          cardCount={caitlinDeck.length}
          topCard={caitlinCard || undefined}
          faceDown={!caitlinCard}
          isTie={tieActive}
          tieCards={tieActive ? caitlinTieCards : undefined}
        />
      </div>

      {/* Round winner indicator */}
      {roundWinner && (
        <div className={`text-center py-2 rounded-xl mb-3 font-black text-sm
          ${roundWinner === "player" ? "bg-green-500/30 text-green-300" :
            roundWinner === "tie" ? "bg-yellow-500/30 text-yellow-300" :
            "bg-red-500/30 text-red-300"}`}>
          {roundWinner === "player" ? "🏆 You win this round!" :
           roundWinner === "tie" ? "⚔️ BATTLE!" :
           roundWinner === "maverick" ? "😤 Maverick wins this round!" :
           "🏆 Caitlin wins this round!"}
        </div>
      )}

      {/* Tie pot indicator */}
      {tiePool.length > 0 && (
        <div className="text-center text-xs text-yellow-400 mb-2">
          ⚔️ {tiePool.length} cards in the war pot!
        </div>
      )}

      {/* Flip button */}
      {!playerFlipped && phase === "playing" && !tieActive && (
        <button
          onClick={playerFlip}
          className="w-full py-5 bg-gradient-to-r from-yellow-400 to-orange-500 text-black font-black text-2xl rounded-2xl shadow-xl hover:scale-105 active:scale-95 transition-all mt-auto"
          style={{ fontFamily: "Oswald, sans-serif" }}
        >
          🃏 FLIP!
        </button>
      )}

      {/* Mascot reactions */}
      <div className="flex justify-between mt-3 px-4">
        <div className="opacity-70">
          <MascotCharacter character="maverick" state={mascotState === "cheer" ? "cheer" : mascotState === "sad" ? "idle" : "idle"} size="sm" />
        </div>
        <div className="opacity-70">
          <MascotCharacter character="caitlin" state={mascotState === "cheer" ? "cheer" : mascotState === "sad" ? "idle" : "idle"} size="sm" />
        </div>
      </div>
    </div>
  );
}
