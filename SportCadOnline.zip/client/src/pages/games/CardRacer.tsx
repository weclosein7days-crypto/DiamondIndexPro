/**
 * CARD RACER — Kids Corner Game
 *
 * Arrow-key racing game. Collectibles are real card images from the database.
 * 100+ cards randomly shuffled each session. Dodge obstacles, collect cards!
 */
import { useEffect, useRef, useState, useCallback } from "react";
import { Button } from "@/components/ui/button";
import { trpc } from "@/lib/trpc";

// ─── Web Audio Sound Engine ───────────────────────────────────────────────────
function createAudio() {
  let ctx: AudioContext | null = null;
  const getCtx = () => {
    if (!ctx) ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
    if (ctx.state === "suspended") ctx.resume();
    return ctx;
  };

  const play = (fn: (ctx: AudioContext) => void) => {
    try { fn(getCtx()); } catch {}
  };

  return {
    coin: () => play(ctx => {
      [880, 1320].forEach((freq, i) => {
        const o = ctx.createOscillator();
        const g = ctx.createGain();
        o.connect(g); g.connect(ctx.destination);
        o.frequency.value = freq;
        o.type = "sine";
        const t = ctx.currentTime + i * 0.06;
        g.gain.setValueAtTime(0.35, t);
        g.gain.exponentialRampToValueAtTime(0.001, t + 0.18);
        o.start(t); o.stop(t + 0.2);
      });
    }),

    collect: () => play(ctx => {
      [523, 659, 784, 1047].forEach((freq, i) => {
        const o = ctx.createOscillator();
        const g = ctx.createGain();
        o.connect(g); g.connect(ctx.destination);
        o.type = "triangle";
        o.frequency.value = freq;
        const t = ctx.currentTime + i * 0.07;
        g.gain.setValueAtTime(0.3, t);
        g.gain.exponentialRampToValueAtTime(0.001, t + 0.22);
        o.start(t); o.stop(t + 0.25);
      });
    }),

    crash: () => play(ctx => {
      const buf = ctx.createBuffer(1, ctx.sampleRate * 0.25, ctx.sampleRate);
      const d = buf.getChannelData(0);
      for (let i = 0; i < d.length; i++) d[i] = (Math.random() * 2 - 1) * Math.exp(-i / (ctx.sampleRate * 0.05));
      const src = ctx.createBufferSource();
      src.buffer = buf;
      const f = ctx.createBiquadFilter();
      f.type = "lowpass"; f.frequency.value = 200;
      const g = ctx.createGain();
      g.gain.setValueAtTime(0.8, ctx.currentTime);
      g.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.25);
      src.connect(f); f.connect(g); g.connect(ctx.destination);
      src.start(); src.stop(ctx.currentTime + 0.3);
    }),

    boost: () => play(ctx => {
      const o = ctx.createOscillator();
      const g = ctx.createGain();
      o.connect(g); g.connect(ctx.destination);
      o.type = "sawtooth";
      o.frequency.setValueAtTime(200, ctx.currentTime);
      o.frequency.exponentialRampToValueAtTime(1200, ctx.currentTime + 0.3);
      g.gain.setValueAtTime(0.25, ctx.currentTime);
      g.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.35);
      o.start(); o.stop(ctx.currentTime + 0.4);
    }),

    fanfare: () => play(ctx => {
      [392, 494, 587, 784, 988].forEach((freq, i) => {
        const o = ctx.createOscillator();
        const g = ctx.createGain();
        o.connect(g); g.connect(ctx.destination);
        o.type = "square";
        o.frequency.value = freq;
        const t = ctx.currentTime + i * 0.12;
        g.gain.setValueAtTime(0.2, t);
        g.gain.exponentialRampToValueAtTime(0.001, t + 0.3);
        o.start(t); o.stop(t + 0.35);
      });
    }),
  };
}

const sfx = createAudio();

// ─── Types ────────────────────────────────────────────────────────────────────
interface RealCard {
  id: number;
  playerName: string | null;
  sport: string | null;
  frontImageUrl: string | null;
  gradeScore: string | null;
  gradeCompany: string | null;
  setName: string | null;
  year: string | null;
  source: string | null;
}

interface Obj {
  id: number;
  lane: number;
  y: number;
  type: "card" | "cone" | "oil" | "boost";
  cardIndex: number; // index into the shuffled card pool
}

const LANES = 5;
const LANE_W = 80;
const GAME_W = LANES * LANE_W;   // 400
const GAME_H = 520;
const CAR_H = 56;
const CAR_W = 44;
const OBJ_SIZE = 48;
const SPAWN_INTERVAL = 900; // ms between spawns
const BASE_SPEED = 3.5;

let _id = 0;
const uid = () => ++_id;

// ─── Mini Card Image Component ────────────────────────────────────────────────
function MiniCard({ card, size = OBJ_SIZE }: { card: RealCard; size?: number }) {
  const [errored, setErrored] = useState(false);
  const src = card.frontImageUrl;
  const sportEmoji = card.sport === "basketball" ? "🏀" : card.sport === "baseball" ? "⚾" :
    card.sport === "football" ? "🏈" : card.sport === "soccer" ? "⚽" :
    card.sport === "hockey" ? "🏒" : "🎴";

  if (!src || errored) {
    return (
      <div style={{ width: size, height: size * 1.4, borderRadius: 4, background: "linear-gradient(135deg, #1e3a5f, #0f2040)", border: "1.5px solid rgba(74,222,128,0.6)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 22 }}>
        {sportEmoji}
      </div>
    );
  }

  return (
    <div style={{ width: size, height: size * 1.4, borderRadius: 4, overflow: "hidden", border: "1.5px solid rgba(74,222,128,0.6)", boxShadow: "0 0 8px rgba(74,222,128,0.5)" }}>
      <img
        src={src}
        alt={card.playerName || "card"}
        style={{ width: "100%", height: "100%", objectFit: "cover" }}
        onError={() => setErrored(true)}
      />
    </div>
  );
}

// ─── Component ────────────────────────────────────────────────────────────────
export default function CardRacer({ onCreditsEarned }: { onCreditsEarned: (n: number) => void }) {
  const [phase, setPhase] = useState<"idle" | "playing" | "dead">("idle");
  const [lane, setLane] = useState(2);
  const [objects, setObjects] = useState<Obj[]>([]);
  const [score, setScore] = useState(0);
  const [collected, setCollected] = useState(0);
  const [roadOffset, setRoadOffset] = useState(0);
  const [flashLane, setFlashLane] = useState<number | null>(null);
  const [hitFlash, setHitFlash] = useState(false);
  const [boostActive, setBoostActive] = useState(false);
  const [creditsEarned, setCreditsEarned] = useState(0);
  const [collectedCards, setCollectedCards] = useState<RealCard[]>([]);
  const [cardPool, setCardPool] = useState<RealCard[]>([]);
  const cardPoolIndexRef = useRef(0);

  const laneRef = useRef(lane);
  const phaseRef = useRef(phase);
  const boostRef = useRef(false);
  const frameRef = useRef<number>(0);
  const lastSpawnRef = useRef<number>(0);
  const lastFrameRef = useRef<number>(0);
  const objectsRef = useRef<Obj[]>([]);
  const scoreRef = useRef(0);
  const collectedRef = useRef(0);
  const cardPoolRef = useRef<RealCard[]>([]);

  laneRef.current = lane;
  phaseRef.current = phase;
  boostRef.current = boostActive;
  objectsRef.current = objects;
  scoreRef.current = score;
  collectedRef.current = collected;
  cardPoolRef.current = cardPool;

  // ── Fetch real card pool ──────────────────────────────────────────────────────
  const { data: poolData } = trpc.kids.getCardPool.useQuery({ limit: 150 });

  useEffect(() => {
    if (poolData?.cards && poolData.cards.length > 0) {
      // Fisher-Yates shuffle
      const arr = [...poolData.cards];
      for (let i = arr.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [arr[i], arr[j]] = [arr[j], arr[i]];
      }
      setCardPool(arr);
    }
  }, [poolData]);

  // ── Key handler ──────────────────────────────────────────────────────────────
  const handleKey = useCallback((e: KeyboardEvent) => {
    if (phaseRef.current !== "playing") return;
    if (e.key === "ArrowLeft" || e.key === "a" || e.key === "A") {
      e.preventDefault();
      setLane(l => Math.max(0, l - 1));
    }
    if (e.key === "ArrowRight" || e.key === "d" || e.key === "D") {
      e.preventDefault();
      setLane(l => Math.min(LANES - 1, l + 1));
    }
  }, []);

  useEffect(() => {
    window.addEventListener("keydown", handleKey);
    return () => window.removeEventListener("keydown", handleKey);
  }, [handleKey]);

  // ── Game loop ─────────────────────────────────────────────────────────────────
  const startGame = () => {
    // Re-shuffle card pool for each new game
    const arr = [...cardPoolRef.current];
    for (let i = arr.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [arr[i], arr[j]] = [arr[j], arr[i]];
    }
    setCardPool(arr);
    cardPoolIndexRef.current = 0;

    setPhase("playing");
    setLane(2);
    setObjects([]);
    setScore(0);
    setCollected(0);
    setHitFlash(false);
    setBoostActive(false);
    setCreditsEarned(0);
    setCollectedCards([]);
    objectsRef.current = [];
    scoreRef.current = 0;
    collectedRef.current = 0;
    lastSpawnRef.current = 0;
    lastFrameRef.current = 0;
    sfx.coin();
  };

  useEffect(() => {
    if (phase !== "playing") return;

    const loop = (ts: number) => {
      if (phaseRef.current !== "playing") return;
      const dt = lastFrameRef.current ? Math.min(ts - lastFrameRef.current, 50) : 16;
      lastFrameRef.current = ts;

      const speed = (BASE_SPEED + scoreRef.current * 0.002) * (boostRef.current ? 1.8 : 1);

      // Scroll road
      setRoadOffset(o => (o + speed * 2) % 80);

      // Spawn objects
      if (ts - lastSpawnRef.current > SPAWN_INTERVAL) {
        lastSpawnRef.current = ts;
        const spawnLane = Math.floor(Math.random() * LANES);
        const r = Math.random();
        const type: Obj["type"] = r < 0.55 ? "card" : r < 0.75 ? "boost" : r < 0.88 ? "cone" : "oil";
        const pool = cardPoolRef.current;
        const cardIdx = pool.length > 0 ? cardPoolIndexRef.current % pool.length : 0;
        if (type === "card") cardPoolIndexRef.current++;
        const newObj: Obj = { id: uid(), lane: spawnLane, y: -OBJ_SIZE * 1.4, type, cardIndex: cardIdx };
        objectsRef.current = [...objectsRef.current, newObj];
        setObjects([...objectsRef.current]);
      }

      // Move objects + collision
      const curLane = laneRef.current;
      let hit = false;
      let earnedCards: RealCard[] = [];
      let boostHit = false;

      const updated = objectsRef.current
        .map(o => ({ ...o, y: o.y + speed }))
        .filter(o => {
          if (o.y > GAME_H) return false;
          const carTop = GAME_H - 90;
          const carBot = GAME_H - 30;
          if (o.y + OBJ_SIZE * 1.4 > carTop && o.y < carBot && o.lane === curLane) {
            if (o.type === "card") {
              const pool = cardPoolRef.current;
              if (pool.length > 0) earnedCards.push(pool[o.cardIndex % pool.length]);
              return false;
            }
            if (o.type === "boost") { boostHit = true; return false; }
            if (o.type === "cone" || o.type === "oil") { hit = true; return false; }
          }
          return true;
        });

      objectsRef.current = updated;
      setObjects(updated);

      if (earnedCards.length > 0) {
        collectedRef.current += earnedCards.length;
        setCollected(c => c + earnedCards.length);
        scoreRef.current += earnedCards.length * 10;
        setScore(s => s + earnedCards.length * 10);
        setFlashLane(curLane);
        setCollectedCards(prev => [...prev, ...earnedCards].slice(-5)); // keep last 5
        setTimeout(() => setFlashLane(null), 200);
        sfx.collect();
      }

      if (boostHit) {
        setBoostActive(true);
        boostRef.current = true;
        sfx.boost();
        setTimeout(() => { setBoostActive(false); boostRef.current = false; }, 3000);
      }

      if (hit) {
        setHitFlash(true);
        setTimeout(() => setHitFlash(false), 300);
        scoreRef.current = Math.max(0, scoreRef.current - 50);
        setScore(Math.max(0, scoreRef.current));
        sfx.crash();
      }

      frameRef.current = requestAnimationFrame(loop);
    };

    frameRef.current = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(frameRef.current);
  }, [phase]);

  // ── End game (30s timer) ──────────────────────────────────────────────────────
  const [timeLeft, setTimeLeft] = useState(30);
  useEffect(() => {
    if (phase !== "playing") return;
    setTimeLeft(30);
    const t = setInterval(() => {
      setTimeLeft(prev => {
        if (prev <= 1) {
          clearInterval(t);
          const credits = Math.floor(scoreRef.current / 10);
          setCreditsEarned(credits);
          onCreditsEarned(credits);
          setPhase("dead");
          sfx.fanfare();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(t);
  }, [phase]);

  // ── Render ──────────────────────────────────────────────────────────────────
  const laneX = (l: number) => l * LANE_W + (LANE_W - CAR_W) / 2;

  return (
    <div className="flex flex-col items-center gap-2 h-full" style={{ fontFamily: "'Oswald', sans-serif" }}>
      {/* HUD */}
      <div className="flex items-center gap-4 w-full max-w-sm px-2">
        <div className="flex items-center gap-1.5 bg-black/60 rounded-full px-3 py-1 border border-yellow-500/40">
          <span className="text-yellow-400 text-xs font-black">SCORE</span>
          <span className="text-white font-black text-sm">{score}</span>
        </div>
        <div className="flex items-center gap-1.5 bg-black/60 rounded-full px-3 py-1 border border-green-500/40">
          <span className="text-green-400 text-xs">🎴</span>
          <span className="text-white font-black text-sm">{collected}</span>
        </div>
        {phase === "playing" && (
          <div className="flex items-center gap-1.5 bg-black/60 rounded-full px-3 py-1 border border-red-500/40 ml-auto">
            <span className="text-red-400 text-xs font-black">⏱</span>
            <span className="text-white font-black text-sm">{timeLeft}s</span>
          </div>
        )}
        {boostActive && (
          <div className="text-yellow-300 font-black text-xs animate-pulse">⚡ BOOST!</div>
        )}
      </div>

      {/* Collected cards strip */}
      {collectedCards.length > 0 && (
        <div className="flex gap-1 items-center h-8">
          {collectedCards.map((c, i) => (
            <div key={i} style={{ width: 22, height: 30, borderRadius: 3, overflow: "hidden", border: "1px solid rgba(74,222,128,0.5)" }}>
              {c.frontImageUrl ? (
                <img src={c.frontImageUrl} alt="" style={{ width: "100%", height: "100%", objectFit: "cover" }} />
              ) : (
                <div style={{ width: "100%", height: "100%", background: "#1e3a5f", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 10 }}>🎴</div>
              )}
            </div>
          ))}
          <span className="text-green-400 text-[10px] font-bold ml-1">collected!</span>
        </div>
      )}

      {/* Game canvas */}
      <div
        className="relative overflow-hidden rounded-xl border-2 border-white/20 select-none"
        style={{
          width: GAME_W,
          height: GAME_H,
          background: "#1a1a2e",
          boxShadow: hitFlash ? "0 0 30px rgba(255,50,50,0.8)" : "0 0 20px rgba(0,0,0,0.8)",
          transition: "box-shadow 0.1s",
        }}
      >
        {/* Road */}
        <div className="absolute inset-0" style={{ background: "linear-gradient(180deg, #1a1a2e 0%, #16213e 100%)" }}>
          {[1,2,3,4].map(i => (
            <div key={i} className="absolute top-0 bottom-0" style={{
              left: i * LANE_W - 1,
              width: 2,
              background: "repeating-linear-gradient(180deg, rgba(255,255,255,0.25) 0px, rgba(255,255,255,0.25) 20px, transparent 20px, transparent 40px)",
              backgroundPositionY: roadOffset,
            }} />
          ))}
          {flashLane !== null && (
            <div className="absolute top-0 bottom-0 pointer-events-none" style={{
              left: flashLane * LANE_W, width: LANE_W,
              background: "rgba(74,222,128,0.25)",
              transition: "opacity 0.2s",
            }} />
          )}
        </div>

        {/* Objects */}
        {objects.map(o => {
          const pool = cardPool;
          const card = pool.length > 0 ? pool[o.cardIndex % pool.length] : null;
          const objLeft = o.lane * LANE_W + (LANE_W - OBJ_SIZE) / 2;

          if (o.type === "card" && card) {
            return (
              <div key={o.id} className="absolute" style={{
                left: objLeft,
                top: o.y,
                filter: "drop-shadow(0 0 6px rgba(74,222,128,0.8))",
              }}>
                <MiniCard card={card} size={OBJ_SIZE} />
              </div>
            );
          }

          return (
            <div key={o.id} className="absolute flex items-center justify-center text-2xl"
              style={{
                left: objLeft,
                top: o.y,
                width: OBJ_SIZE,
                height: OBJ_SIZE,
                fontSize: 28,
                filter: o.type === "boost" ? "drop-shadow(0 0 8px rgba(250,204,21,0.9))" :
                        "drop-shadow(0 0 4px rgba(239,68,68,0.7))",
              }}
            >
              {o.type === "boost" ? "⚡" : o.type === "cone" ? "🚧" : "🛢️"}
            </div>
          );
        })}

        {/* Car */}
        <div
          className="absolute flex items-center justify-center text-4xl"
          style={{
            left: laneX(lane),
            bottom: 30,
            width: CAR_W,
            height: CAR_H,
            transition: "left 0.12s cubic-bezier(0.25,0.46,0.45,0.94)",
            filter: boostActive
              ? "drop-shadow(0 0 12px rgba(250,204,21,0.9))"
              : "drop-shadow(0 4px 8px rgba(0,0,0,0.8))",
            fontSize: 36,
          }}
        >
          🏎️
        </div>

        {/* Idle overlay */}
        {phase === "idle" && (
          <div className="absolute inset-0 flex flex-col items-center justify-center gap-4"
            style={{ background: "rgba(0,0,0,0.75)" }}>
            <div className="text-5xl">🏎️</div>
            <div className="text-white font-black text-xl tracking-widest">CARD RACER</div>
            <div className="text-white/60 text-xs text-center px-6">
              Use ← → arrow keys to dodge obstacles<br/>
              Collect real sports cards to score!<br/>
              ⚡ Boost pads speed you up!
            </div>
            {cardPool.length === 0 && (
              <div className="text-yellow-400/70 text-xs">Loading {poolData ? poolData.cards.length : "…"} real cards…</div>
            )}
            <Button
              onClick={startGame}
              disabled={cardPool.length === 0}
              className="mt-2 font-black tracking-widest text-black disabled:opacity-50"
              style={{ background: "linear-gradient(135deg, #fbbf24, #f59e0b)", border: "none" }}
            >
              🏁 START RACE
            </Button>
          </div>
        )}

        {/* Dead overlay */}
        {phase === "dead" && (
          <div className="absolute inset-0 flex flex-col items-center justify-center gap-3"
            style={{ background: "rgba(0,0,0,0.82)" }}>
            <div className="text-5xl">🏁</div>
            <div className="text-white font-black text-xl tracking-widest">RACE OVER!</div>
            <div className="text-yellow-400 font-black text-2xl">+{creditsEarned} credits</div>
            <div className="text-white/60 text-sm">Cards collected: {collected} · Score: {score}</div>
            {/* Show last few collected cards */}
            {collectedCards.length > 0 && (
              <div className="flex gap-1 mt-1">
                {collectedCards.slice(-4).map((c, i) => (
                  <div key={i} style={{ width: 28, height: 38, borderRadius: 3, overflow: "hidden", border: "1px solid rgba(74,222,128,0.5)" }}>
                    {c.frontImageUrl ? (
                      <img src={c.frontImageUrl} alt="" style={{ width: "100%", height: "100%", objectFit: "cover" }} />
                    ) : <div style={{ width: "100%", height: "100%", background: "#1e3a5f", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 12 }}>🎴</div>}
                  </div>
                ))}
              </div>
            )}
            <div className="flex gap-3 mt-2">
              <Button
                onClick={startGame}
                className="font-black tracking-widest text-black"
                style={{ background: "linear-gradient(135deg, #fbbf24, #f59e0b)", border: "none" }}
              >
                🔁 RACE AGAIN
              </Button>
            </div>
          </div>
        )}
      </div>

      {/* Mobile touch controls */}
      <div className="flex gap-8 mt-1">
        <button
          className="w-14 h-14 rounded-full bg-white/10 border border-white/20 text-2xl active:bg-white/25 select-none"
          onPointerDown={() => setLane(l => Math.max(0, l - 1))}
        >◀</button>
        <button
          className="w-14 h-14 rounded-full bg-white/10 border border-white/20 text-2xl active:bg-white/25 select-none"
          onPointerDown={() => setLane(l => Math.min(LANES - 1, l + 1))}
        >▶</button>
      </div>
    </div>
  );
}
