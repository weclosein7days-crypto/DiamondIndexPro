/**
 * Heads or Tails — Kids Corner Game
 *
 * Maverick and Caitlin take turns flipping the coin.
 * The flipper does the toss animation; the watcher trash-talks or hypes.
 * 3D CSS coin flip with a wooden table surface.
 * Web Audio API for coin sounds.
 */

import { useState, useEffect, useRef, useCallback } from "react";
import { useSFX } from "@/hooks/useSFX";

const MASCOT_CDN = "https://d2xsxph8kpxj0f.cloudfront.net/310519663522483910/L9wJitqmU3uwF2WPjH8hRS/kids-corner-mascot_08fe6054.jpg";

// Sound provided by useSFX hook

// ── Dialogue banks ────────────────────────────────────────────────────────────
const TRASH_TALK = [
  "Bet you can't call it right! 😏",
  "I already know what it's gonna be...",
  "Ooooh this is gonna be GOOD 👀",
  "My prediction? You're WRONG. 😂",
  "Don't choke! 😬",
  "I've been watching — you always pick wrong!",
  "Nervous? You should be! 😈",
];

const HYPE_WIN = [
  "YESSS!! I KNEW IT! 🎉",
  "Called it from a MILE away! 🏆",
  "THAT'S WHAT I'M TALKING ABOUT! 🔥",
  "WINNER WINNER! 🏅",
  "You are TOO GOOD at this! ⭐",
];

const COMMISERATE_LOSE = [
  "Aww man... shake it off! 💪",
  "So close! Try again!",
  "That coin is RIGGED I tell you 😤",
  "Next one is yours for SURE!",
  "I've lost that one too... it happens 😅",
];

const FLIPPER_HYPE = [
  "Watch this technique... 🤌",
  "I've been practicing this flip ALL week!",
  "Here we gooooo! 🚀",
  "This is gonna be PERFECT! ✨",
  "Nobody flips like me! 😎",
];

const rand = (arr: string[]) => arr[Math.floor(Math.random() * arr.length)];

// ── Character portrait (cropped from full image) ──────────────────────────────
function CharacterPortrait({
  character,
  size = 100,
  state = "idle",
  speech,
  speechSide = "right",
  flip = false,
}: {
  character: "maverick" | "caitlin";
  size?: number;
  state?: "idle" | "excited" | "sad" | "thinking" | "throwing";
  speech?: string;
  speechSide?: "left" | "right" | "top";
  flip?: boolean;
}) {
  const imgW = size * 2;
  const objPos = character === "maverick" ? "0% 15%" : "100% 15%";
  const marginLeft = character === "maverick" ? 0 : -size;

  const animations: Record<string, string> = {
    idle:     "mascot-idle-float 3s ease-in-out infinite",
    excited:  "mascot-bounce 0.5s ease-in-out infinite",
    sad:      "mascot-droop 0.4s ease-out forwards",
    thinking: "mascot-wave 2s ease-in-out infinite",
    throwing: "mascot-throw 0.4s ease-out forwards",
  };

  return (
    <div style={{ position: "relative", display: "inline-flex", flexDirection: "column", alignItems: "center" }}>
      {/* Speech bubble */}
      {speech && (
        <div style={{
          position: "absolute",
          ...(speechSide === "top"   ? { bottom: "100%", left: "50%", transform: "translateX(-50%)", marginBottom: 8 } : {}),
          ...(speechSide === "right" ? { left: "100%", top: "20%", marginLeft: 8 } : {}),
          ...(speechSide === "left"  ? { right: "100%", top: "20%", marginRight: 8 } : {}),
          background: "white",
          color: "#1a1a2e",
          borderRadius: 14,
          padding: "7px 12px",
          fontSize: Math.max(10, size * 0.12),
          fontWeight: 900,
          whiteSpace: "nowrap",
          maxWidth: 200,
          textAlign: "center",
          boxShadow: "0 4px 16px rgba(0,0,0,0.3)",
          animation: "speech-pop 0.3s ease-out forwards",
          zIndex: 20,
          fontFamily: "Oswald, sans-serif",
          lineHeight: 1.3,
        }}>
          {speech}
          {/* Tail */}
          {speechSide === "top" && (
            <div style={{ position: "absolute", top: "100%", left: "50%", transform: "translateX(-50%)", width: 0, height: 0, borderLeft: "6px solid transparent", borderRight: "6px solid transparent", borderTop: "8px solid white" }} />
          )}
          {speechSide === "right" && (
            <div style={{ position: "absolute", right: "100%", top: "50%", transform: "translateY(-50%)", width: 0, height: 0, borderTop: "6px solid transparent", borderBottom: "6px solid transparent", borderRight: "8px solid white" }} />
          )}
          {speechSide === "left" && (
            <div style={{ position: "absolute", left: "100%", top: "50%", transform: "translateY(-50%)", width: 0, height: 0, borderTop: "6px solid transparent", borderBottom: "6px solid transparent", borderLeft: "8px solid white" }} />
          )}
        </div>
      )}

      <div style={{
        width: size,
        height: size,
        overflow: "hidden",
        borderRadius: "50%",
        border: `3px solid ${character === "maverick" ? "#60a5fa" : "#f472b6"}`,
        boxShadow: `0 0 20px ${character === "maverick" ? "rgba(96,165,250,0.5)" : "rgba(244,114,182,0.5)"}`,
        animation: animations[state] || animations.idle,
        transform: flip ? "scaleX(-1)" : undefined,
        filter: state === "sad" ? "saturate(0.5) brightness(0.8)" : undefined,
        transition: "filter 0.3s",
      }}>
        <img
          src={MASCOT_CDN}
          alt={character}
          style={{ width: imgW, height: "auto", objectFit: "cover", objectPosition: objPos, marginLeft, display: "block", pointerEvents: "none" }}
          draggable={false}
        />
      </div>

      <div style={{
        marginTop: 4,
        fontSize: Math.max(9, size * 0.1),
        fontWeight: 900,
        color: character === "maverick" ? "#60a5fa" : "#f472b6",
        fontFamily: "Oswald, sans-serif",
        letterSpacing: "0.05em",
        textTransform: "uppercase",
      }}>
        {character === "maverick" ? "Maverick 🏀" : "Caitlin 🏀"}
      </div>
    </div>
  );
}

// ── Coin component ────────────────────────────────────────────────────────────
function Coin({ isFlipping, result }: { isFlipping: boolean; result: "heads" | "tails" | null }) {
  return (
    <div style={{ perspective: 600, width: 120, height: 120, margin: "0 auto" }}>
      <div style={{
        width: 120,
        height: 120,
        position: "relative",
        transformStyle: "preserve-3d",
        animation: isFlipping
          ? "coin-flip 1.2s cubic-bezier(0.4,0,0.2,1) forwards"
          : result
          ? `coin-settle-${result} 0.3s ease-out forwards`
          : "none",
        borderRadius: "50%",
      }}>
        {/* Heads face */}
        <div style={{
          position: "absolute", inset: 0, borderRadius: "50%",
          backfaceVisibility: "hidden",
          background: "radial-gradient(circle at 35% 35%, #fde68a, #f59e0b, #92400e)",
          display: "flex", alignItems: "center", justifyContent: "center",
          boxShadow: "inset 0 -4px 12px rgba(0,0,0,0.3), 0 4px 20px rgba(245,158,11,0.5)",
          border: "4px solid #fbbf24",
        }}>
          <div style={{ textAlign: "center" }}>
            <div style={{ fontSize: 36 }}>🦅</div>
            <div style={{ color: "#92400e", fontWeight: 900, fontSize: 11, fontFamily: "Oswald, sans-serif", letterSpacing: 2 }}>HEADS</div>
          </div>
        </div>
        {/* Tails face */}
        <div style={{
          position: "absolute", inset: 0, borderRadius: "50%",
          backfaceVisibility: "hidden",
          transform: "rotateY(180deg)",
          background: "radial-gradient(circle at 35% 35%, #c4b5fd, #7c3aed, #3b0764)",
          display: "flex", alignItems: "center", justifyContent: "center",
          boxShadow: "inset 0 -4px 12px rgba(0,0,0,0.3), 0 4px 20px rgba(124,58,237,0.5)",
          border: "4px solid #a78bfa",
        }}>
          <div style={{ textAlign: "center" }}>
            <div style={{ fontSize: 36 }}>⚡</div>
            <div style={{ color: "#c4b5fd", fontWeight: 900, fontSize: 11, fontFamily: "Oswald, sans-serif", letterSpacing: 2 }}>TAILS</div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ── Inject keyframes ──────────────────────────────────────────────────────────
let injected = false;
function injectStyles() {
  if (injected) return;
  injected = true;
  const s = document.createElement("style");
  s.textContent = `
    @keyframes coin-flip {
      0%   { transform: rotateY(0deg) translateY(0); }
      20%  { transform: rotateY(360deg) translateY(-80px); }
      40%  { transform: rotateY(720deg) translateY(-120px); }
      60%  { transform: rotateY(1080deg) translateY(-60px); }
      80%  { transform: rotateY(1440deg) translateY(-20px); }
      90%  { transform: rotateY(1620deg) translateY(-5px); }
      100% { transform: rotateY(1800deg) translateY(0); }
    }
    @keyframes coin-settle-heads {
      0%   { transform: rotateY(1800deg); }
      100% { transform: rotateY(1800deg); }
    }
    @keyframes coin-settle-tails {
      0%   { transform: rotateY(1980deg); }
      100% { transform: rotateY(1980deg); }
    }
    @keyframes mascot-idle-float {
      0%, 100% { transform: translateY(0); }
      50% { transform: translateY(-6px); }
    }
    @keyframes mascot-bounce {
      0%, 100% { transform: translateY(0); }
      50% { transform: translateY(-14px); }
    }
    @keyframes mascot-droop {
      0% { transform: translateY(0) rotate(0deg); }
      100% { transform: translateY(6px) rotate(-8deg); }
    }
    @keyframes mascot-wave {
      0%, 100% { transform: rotate(0deg); }
      25% { transform: rotate(-4deg); }
      75% { transform: rotate(4deg); }
    }
    @keyframes mascot-throw {
      0%   { transform: translateY(0) rotate(0deg); }
      30%  { transform: translateY(-20px) rotate(-15deg); }
      60%  { transform: translateY(-30px) rotate(10deg); }
      100% { transform: translateY(0) rotate(0deg); }
    }
    @keyframes speech-pop {
      0%   { transform: scale(0.5); opacity: 0; }
      70%  { transform: scale(1.05); opacity: 1; }
      100% { transform: scale(1); opacity: 1; }
    }
    @keyframes result-pop {
      0%   { transform: scale(0.3) rotate(-10deg); opacity: 0; }
      60%  { transform: scale(1.15) rotate(3deg); opacity: 1; }
      100% { transform: scale(1) rotate(0deg); opacity: 1; }
    }
    @keyframes table-wobble {
      0%, 100% { transform: rotate(0deg); }
      25% { transform: rotate(-1deg); }
      75% { transform: rotate(1deg); }
    }
  `;
  document.head.appendChild(s);
}

// ── Main Game ─────────────────────────────────────────────────────────────────
interface HeadsOrTailsProps {
  kidName: string;
  onEarnCredits: (amount: number) => void;
  onClose: () => void;
}

export default function HeadsOrTails({ kidName, onEarnCredits, onClose }: HeadsOrTailsProps) {
  useEffect(() => { injectStyles(); }, []);

  // Who is the current flipper (rotates each round)
  const [flipperTurn, setFlipperTurn] = useState<"maverick" | "caitlin">("maverick");
  const [kidChoice, setKidChoice] = useState<"heads" | "tails" | null>(null);
  const [isFlipping, setIsFlipping] = useState(false);
  const [result, setResult] = useState<"heads" | "tails" | null>(null);
  const [outcome, setOutcome] = useState<"win" | "lose" | null>(null);
  const [round, setRound] = useState(1);
  const [score, setScore] = useState({ kid: 0, maverick: 0, caitlin: 0 });
  const [flipperSpeech, setFlipperSpeech] = useState<string | undefined>(rand(FLIPPER_HYPE));
  const [watcherSpeech, setWatcherSpeech] = useState<string | undefined>(rand(TRASH_TALK));
  const [flipperState, setFlipperState] = useState<"idle" | "excited" | "sad" | "thinking" | "throwing">("thinking");
  const [watcherState, setWatcherState] = useState<"idle" | "excited" | "sad" | "thinking" | "throwing">("idle");
  const [totalWon, setTotalWon] = useState(0);
  const sound = useSFX();

  const watcher = flipperTurn === "maverick" ? "caitlin" : "maverick";

  const flip = useCallback(() => {
    if (!kidChoice || isFlipping) return;
    setIsFlipping(true);
    setResult(null);
    setOutcome(null);
    setFlipperState("throwing");
    setFlipperSpeech(rand(FLIPPER_HYPE));
    setWatcherSpeech("Ooooh here it goes... 👀");
    setWatcherState("watching" as any);
    sound.coinFlip();

    setTimeout(() => {
      const landed: "heads" | "tails" = Math.random() < 0.5 ? "heads" : "tails";
      setResult(landed);
      setIsFlipping(false);
      sound.coinLand();

      const won = landed === kidChoice;
      setOutcome(won ? "win" : "lose");

      if (won) {
        const earned = 3;
        onEarnCredits(earned);
        setTotalWon(t => t + earned);
        setScore(s => ({ ...s, kid: s.kid + 1 }));
        setFlipperState("sad");
        setWatcherState("excited");
        setFlipperSpeech("Beginner's luck... 😤");
        setWatcherSpeech(rand(HYPE_WIN));
        sound.cheer();
      } else {
        // Flipper's character wins
        setScore(s => ({ ...s, [flipperTurn]: s[flipperTurn] + 1 }));
        setFlipperState("excited");
        setWatcherState("sad");
        setFlipperSpeech(rand(HYPE_WIN));
        setWatcherSpeech(rand(COMMISERATE_LOSE));
        sound.groan();
      }
    }, 1400);
  }, [kidChoice, isFlipping, flipperTurn, onEarnCredits, sound]);

  const nextRound = () => {
    setKidChoice(null);
    setResult(null);
    setOutcome(null);
    setRound(r => r + 1);
    // Rotate flipper
    setFlipperTurn(prev => prev === "maverick" ? "caitlin" : "maverick");
    setFlipperState("thinking");
    setWatcherState("idle");
    setFlipperSpeech(rand(FLIPPER_HYPE));
    setWatcherSpeech(rand(TRASH_TALK));
  };

  const flipper = flipperTurn;

  return (
    <div style={{
      minHeight: "100vh",
      background: "linear-gradient(160deg, #0a0a1a 0%, #1a0a2e 50%, #0a1a3e 100%)",
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      padding: "24px 16px",
      fontFamily: "Oswald, sans-serif",
    }}>
      {/* Header */}
      <div style={{ width: "100%", maxWidth: 600, display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
        <button onClick={onClose} style={{ background: "rgba(255,255,255,0.1)", border: "none", color: "white", borderRadius: 8, padding: "6px 14px", cursor: "pointer", fontSize: 14, fontFamily: "Oswald, sans-serif" }}>
          ← Back
        </button>
        <h1 style={{ color: "white", fontSize: 22, fontWeight: 900, margin: 0, letterSpacing: 2 }}>
          🪙 HEADS OR TAILS
        </h1>
        <div style={{ background: "rgba(251,191,36,0.2)", border: "1px solid #fbbf24", borderRadius: 8, padding: "4px 12px", color: "#fbbf24", fontSize: 13, fontWeight: 900 }}>
          +{totalWon} credits
        </div>
      </div>

      {/* Score board */}
      <div style={{ display: "flex", gap: 12, marginBottom: 20, background: "rgba(255,255,255,0.05)", borderRadius: 12, padding: "10px 20px", border: "1px solid rgba(255,255,255,0.1)" }}>
        {[
          { label: kidName, score: score.kid, color: "#34d399" },
          { label: "Maverick", score: score.maverick, color: "#60a5fa" },
          { label: "Caitlin", score: score.caitlin, color: "#f472b6" },
        ].map(p => (
          <div key={p.label} style={{ textAlign: "center", minWidth: 70 }}>
            <div style={{ color: p.color, fontWeight: 900, fontSize: 22 }}>{p.score}</div>
            <div style={{ color: "rgba(255,255,255,0.6)", fontSize: 11, textTransform: "uppercase", letterSpacing: 1 }}>{p.label}</div>
          </div>
        ))}
        <div style={{ textAlign: "center", minWidth: 50, borderLeft: "1px solid rgba(255,255,255,0.1)", paddingLeft: 12 }}>
          <div style={{ color: "white", fontWeight: 900, fontSize: 22 }}>R{round}</div>
          <div style={{ color: "rgba(255,255,255,0.6)", fontSize: 11, textTransform: "uppercase", letterSpacing: 1 }}>Round</div>
        </div>
      </div>

      {/* Characters + Coin stage */}
      <div style={{ width: "100%", maxWidth: 600, display: "flex", alignItems: "flex-end", justifyContent: "space-between", marginBottom: 24, gap: 8 }}>

        {/* Left character */}
        <div style={{ flex: 1, display: "flex", justifyContent: "flex-end" }}>
          {flipper === "maverick" ? (
            <CharacterPortrait character="maverick" size={90} state={flipperState} speech={flipperSpeech} speechSide="right" />
          ) : (
            <CharacterPortrait character="caitlin" size={90} state={watcherState} speech={watcherSpeech} speechSide="right" />
          )}
        </div>

        {/* Coin + table */}
        <div style={{ flex: 2, display: "flex", flexDirection: "column", alignItems: "center", gap: 8 }}>
          {/* Flipper label */}
          <div style={{ color: "rgba(255,255,255,0.5)", fontSize: 11, textTransform: "uppercase", letterSpacing: 2, marginBottom: 4 }}>
            {flipper === "maverick" ? "Maverick" : "Caitlin"} is flipping
          </div>

          {/* Coin */}
          <Coin isFlipping={isFlipping} result={result} />

          {/* Wooden table */}
          <div style={{
            width: 200,
            height: 18,
            background: "linear-gradient(180deg, #92400e 0%, #78350f 60%, #451a03 100%)",
            borderRadius: "0 0 8px 8px",
            boxShadow: "0 6px 20px rgba(0,0,0,0.5)",
            animation: isFlipping ? "table-wobble 0.3s ease-in-out" : "none",
            border: "2px solid #b45309",
          }} />

          {/* Result banner */}
          {result && outcome && (
            <div style={{
              marginTop: 12,
              padding: "10px 24px",
              borderRadius: 16,
              background: outcome === "win"
                ? "linear-gradient(135deg, #065f46, #059669)"
                : "linear-gradient(135deg, #7f1d1d, #dc2626)",
              color: "white",
              fontWeight: 900,
              fontSize: 20,
              letterSpacing: 2,
              textTransform: "uppercase",
              animation: "result-pop 0.4s ease-out forwards",
              boxShadow: outcome === "win"
                ? "0 0 30px rgba(5,150,105,0.6)"
                : "0 0 30px rgba(220,38,38,0.6)",
            }}>
              {result === "heads" ? "🦅 HEADS!" : "⚡ TAILS!"} — {outcome === "win" ? "YOU WIN! +3 credits 🎉" : "WRONG! Better luck next time 😅"}
            </div>
          )}
        </div>

        {/* Right character */}
        <div style={{ flex: 1, display: "flex", justifyContent: "flex-start" }}>
          {flipper === "caitlin" ? (
            <CharacterPortrait character="caitlin" size={90} state={flipperState} speech={flipperSpeech} speechSide="left" flip />
          ) : (
            <CharacterPortrait character="maverick" size={90} state={watcherState} speech={watcherSpeech} speechSide="left" />
          )}
        </div>
      </div>

      {/* Kid's choice + action */}
      {!result ? (
        <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 16, width: "100%", maxWidth: 400 }}>
          <p style={{ color: "rgba(255,255,255,0.7)", fontSize: 14, margin: 0, textAlign: "center" }}>
            {kidName}, pick your call before {flipper === "maverick" ? "Maverick" : "Caitlin"} flips!
          </p>
          <div style={{ display: "flex", gap: 16 }}>
            {(["heads", "tails"] as const).map(side => (
              <button
                key={side}
                onClick={() => setKidChoice(side)}
                disabled={isFlipping}
                style={{
                  width: 120,
                  height: 80,
                  borderRadius: 16,
                  border: `3px solid ${kidChoice === side ? "#fbbf24" : "rgba(255,255,255,0.2)"}`,
                  background: kidChoice === side
                    ? "linear-gradient(135deg, rgba(251,191,36,0.3), rgba(245,158,11,0.2))"
                    : "rgba(255,255,255,0.05)",
                  color: "white",
                  cursor: isFlipping ? "not-allowed" : "pointer",
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                  justifyContent: "center",
                  gap: 4,
                  transition: "all 0.2s",
                  transform: kidChoice === side ? "scale(1.05)" : "scale(1)",
                  fontFamily: "Oswald, sans-serif",
                }}>
                <span style={{ fontSize: 28 }}>{side === "heads" ? "🦅" : "⚡"}</span>
                <span style={{ fontWeight: 900, fontSize: 14, letterSpacing: 2, textTransform: "uppercase" }}>{side}</span>
              </button>
            ))}
          </div>
          <button
            onClick={flip}
            disabled={!kidChoice || isFlipping}
            style={{
              padding: "14px 40px",
              borderRadius: 16,
              border: "none",
              background: !kidChoice || isFlipping
                ? "rgba(255,255,255,0.1)"
                : "linear-gradient(135deg, #f59e0b, #ef4444)",
              color: "white",
              fontWeight: 900,
              fontSize: 18,
              letterSpacing: 2,
              cursor: !kidChoice || isFlipping ? "not-allowed" : "pointer",
              fontFamily: "Oswald, sans-serif",
              boxShadow: !kidChoice || isFlipping ? "none" : "0 0 30px rgba(245,158,11,0.5)",
              transition: "all 0.2s",
            }}>
            {isFlipping ? "🪙 FLIPPING..." : "🪙 FLIP IT!"}
          </button>
        </div>
      ) : (
        <button
          onClick={nextRound}
          style={{
            padding: "14px 40px",
            borderRadius: 16,
            border: "none",
            background: "linear-gradient(135deg, #7c3aed, #4f46e5)",
            color: "white",
            fontWeight: 900,
            fontSize: 18,
            letterSpacing: 2,
            cursor: "pointer",
            fontFamily: "Oswald, sans-serif",
            boxShadow: "0 0 30px rgba(124,58,237,0.5)",
          }}>
          {flipper === "maverick" ? "Caitlin" : "Maverick"}'s turn to flip! →
        </button>
      )}

      {/* Win 3 credits note */}
      <p style={{ color: "rgba(255,255,255,0.35)", fontSize: 11, marginTop: 20, textAlign: "center" }}>
        Correct call = +3 credits • Maverick & Caitlin rotate flipping each round
      </p>
    </div>
  );
}
