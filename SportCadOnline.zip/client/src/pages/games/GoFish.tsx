/**
 * 3-Handed Go Fish — Kids Corner Game
 *
 * Kid vs Maverick vs Caitlin.
 * Maverick: aggressive, trash-talks, asks for high-value cards first.
 * Caitlin: strategic, calm, collects quietly then surprises everyone.
 *
 * FIX: All mutable game state is mirrored in useRef so aiTurn() always
 * reads the latest values, eliminating the stale-closure freeze that
 * occurred on the 3rd player's turn.
 */

import { useState, useEffect, useRef, useCallback } from "react";
import { useSFX } from "@/hooks/useSFX";

const MASCOT_CDN = "https://d2xsxph8kpxj0f.cloudfront.net/310519663522483910/L9wJitqmU3uwF2WPjH8hRS/kids-corner-mascot_08fe6054.jpg";

// ── Types ─────────────────────────────────────────────────────────────────────
type Suit = "♠" | "♥" | "♦" | "♣";
type Rank = "A" | "2" | "3" | "4" | "5" | "6" | "7" | "8" | "9" | "10" | "J" | "Q" | "K";
interface Card { rank: Rank; suit: Suit; id: string; }
type Player = "kid" | "maverick" | "caitlin";
type Phase = "dealing" | "playing" | "asking" | "gofish" | "gameover";

const RANKS: Rank[] = ["A","2","3","4","5","6","7","8","9","10","J","Q","K"];
const SUITS: Suit[] = ["♠","♥","♦","♣"];
const RANK_ORDER: Record<Rank, number> = { A:1,2:2,3:3,4:4,5:5,6:6,7:7,8:8,9:9,10:10,J:11,Q:12,K:13 };

function buildDeck(): Card[] {
  const deck: Card[] = [];
  for (const rank of RANKS) for (const suit of SUITS) deck.push({ rank, suit, id: `${rank}${suit}` });
  return deck;
}
function shuffle<T>(arr: T[]): T[] {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}
function findBooks(hand: Card[]): { books: Rank[]; remaining: Card[] } {
  const counts: Partial<Record<Rank, Card[]>> = {};
  for (const c of hand) { if (!counts[c.rank]) counts[c.rank] = []; counts[c.rank]!.push(c); }
  const books: Rank[] = [];
  const remaining: Card[] = [];
  for (const [rank, cards] of Object.entries(counts) as [Rank, Card[]][]) {
    if (cards.length === 4) books.push(rank);
    else remaining.push(...cards);
  }
  return { books, remaining };
}
function hasRank(hand: Card[], rank: Rank) { return hand.some(c => c.rank === rank); }
function uniqueRanks(hand: Card[]): Rank[] {
  const seen: Partial<Record<Rank, true>> = {};
  const result: Rank[] = [];
  for (const c of hand) { if (!seen[c.rank]) { seen[c.rank] = true; result.push(c.rank); } }
  return result;
}

// Sound provided by useSFX hook

// ── Dialogue ─────────────────────────────────────────────────────────────────────────────────
const MAV_ASK = (rank: Rank) => [
  `Hand over all your ${rank}s... NOW! 😤`,
  `I know you've got ${rank}s. Don't even try to hide it! 👀`,
  `Give me your ${rank}s or face the consequences! 😈`,
  `${rank}s. All of them. Right now! 🤜`,
][Math.floor(Math.random() * 4)];

const CAIT_ASK = (rank: Rank) => [
  `Excuse me, do you happen to have any ${rank}s? 😊`,
  `I'd love a ${rank} if you have one...`,
  `${rank}s please! Pretty please? 🌸`,
  `Could I have your ${rank}s? Thank you! ✨`,
][Math.floor(Math.random() * 4)];

const MAV_GOFISH = [
  "GO FISH! Ha! 😂", "Nope! GO FISH! 🎣", "NOTHING for you! GO FISH! 😏",
];
const CAIT_GOFISH = [
  "Oh! Go Fish! 🎣", "Hmm, Go Fish! 🐟", "Sorry! Go Fish! 😅",
];
const MAV_BOOK = (rank: Rank) => `BOOK OF ${rank}s! That's MINE! 🏆`;
const CAIT_BOOK = (rank: Rank) => `Book of ${rank}s! I've been waiting for that! ✨`;
const MAV_WIN = ["I DOMINATED! Nobody beats Maverick! 🏆", "TOLD YOU! I'm the GOAT! 🐐"];
const CAIT_WIN = ["I win! Strategy always beats aggression! 😊🏆", "Quiet and deadly! That's me! ✨"];
const KID_WIN_MAV = ["Ugh... beginner's luck... 😤", "I let you win! 😒"];
const KID_WIN_CAIT = ["Wow, you're actually good! 😮", "I'll get you next time! 🤝"];
const rand = (arr: string[]) => arr[Math.floor(Math.random() * arr.length)];

// ── Card display ──────────────────────────────────────────────────────────────
function PlayingCard({ card, faceDown = false, small = false }: { card: Card; faceDown?: boolean; small?: boolean }) {
  const isRed = card.suit === "♥" || card.suit === "♦";
  const size = small ? { w: 36, h: 50, fontSize: 11 } : { w: 52, h: 72, fontSize: 14 };
  return (
    <div style={{
      width: size.w, height: size.h,
      borderRadius: small ? 5 : 8,
      border: "2px solid rgba(255,255,255,0.3)",
      background: faceDown
        ? "linear-gradient(135deg, #1e3a5f, #7c3aed)"
        : "white",
      display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center",
      boxShadow: "0 2px 8px rgba(0,0,0,0.4)",
      flexShrink: 0,
      transition: "transform 0.2s",
      cursor: "default",
    }}>
      {!faceDown && (
        <>
          <div style={{ color: isRed ? "#dc2626" : "#1a1a2e", fontWeight: 900, fontSize: size.fontSize, lineHeight: 1 }}>{card.rank}</div>
          <div style={{ color: isRed ? "#dc2626" : "#1a1a2e", fontSize: size.fontSize + 2, lineHeight: 1 }}>{card.suit}</div>
        </>
      )}
      {faceDown && <div style={{ fontSize: small ? 16 : 22 }}>🂠</div>}
    </div>
  );
}

// ── Character portrait ────────────────────────────────────────────────────────
function CharPortrait({ character, size = 70, state, speech, speechSide = "top" }: {
  character: "maverick" | "caitlin";
  size?: number;
  state: "idle" | "excited" | "sad" | "thinking";
  speech?: string;
  speechSide?: "left" | "right" | "top";
}) {
  const imgW = size * 2;
  const objPos = character === "maverick" ? "0% 15%" : "100% 15%";
  const marginLeft = character === "maverick" ? 0 : -size;
  const anims = { idle: "mascot-idle-float 3s ease-in-out infinite", excited: "mascot-bounce 0.5s ease-in-out infinite", sad: "mascot-droop 0.4s ease-out forwards", thinking: "mascot-wave 2s ease-in-out infinite" };
  return (
    <div style={{ position: "relative", display: "inline-flex", flexDirection: "column", alignItems: "center" }}>
      {speech && (
        <div style={{
          position: "absolute",
          ...(speechSide === "top" ? { bottom: "100%", left: "50%", transform: "translateX(-50%)", marginBottom: 6 } : {}),
          ...(speechSide === "right" ? { left: "105%", top: "10%" } : {}),
          ...(speechSide === "left" ? { right: "105%", top: "10%" } : {}),
          background: "white", color: "#1a1a2e", borderRadius: 12, padding: "6px 10px",
          fontSize: 11, fontWeight: 900, whiteSpace: "pre-wrap", maxWidth: 170, textAlign: "center",
          boxShadow: "0 4px 12px rgba(0,0,0,0.3)", animation: "speech-pop 0.3s ease-out forwards",
          zIndex: 20, fontFamily: "Oswald, sans-serif", lineHeight: 1.3,
        }}>{speech}</div>
      )}
      <div style={{
        width: size, height: size, overflow: "hidden", borderRadius: "50%",
        border: `3px solid ${character === "maverick" ? "#60a5fa" : "#f472b6"}`,
        boxShadow: `0 0 16px ${character === "maverick" ? "rgba(96,165,250,0.4)" : "rgba(244,114,182,0.4)"}`,
        animation: anims[state], filter: state === "sad" ? "saturate(0.5) brightness(0.8)" : undefined,
      }}>
        <img src={MASCOT_CDN} alt={character} style={{ width: imgW, height: "auto", objectFit: "cover", objectPosition: objPos, marginLeft, display: "block", pointerEvents: "none" }} draggable={false} />
      </div>
      <div style={{ marginTop: 3, fontSize: 10, fontWeight: 900, color: character === "maverick" ? "#60a5fa" : "#f472b6", fontFamily: "Oswald, sans-serif", textTransform: "uppercase", letterSpacing: 1 }}>
        {character === "maverick" ? "Maverick" : "Caitlin"}
      </div>
    </div>
  );
}

// ── Inject styles ─────────────────────────────────────────────────────────────
let injected = false;
function injectStyles() {
  if (injected) return; injected = true;
  const s = document.createElement("style");
  s.textContent = `
    @keyframes mascot-idle-float { 0%,100%{transform:translateY(0)} 50%{transform:translateY(-6px)} }
    @keyframes mascot-bounce { 0%,100%{transform:translateY(0)} 50%{transform:translateY(-14px)} }
    @keyframes mascot-droop { 0%{transform:translateY(0) rotate(0deg)} 100%{transform:translateY(6px) rotate(-8deg)} }
    @keyframes mascot-wave { 0%,100%{transform:rotate(0deg)} 25%{transform:rotate(-4deg)} 75%{transform:rotate(4deg)} }
    @keyframes speech-pop { 0%{transform:scale(0.5);opacity:0} 70%{transform:scale(1.05);opacity:1} 100%{transform:scale(1);opacity:1} }
    @keyframes card-deal { 0%{transform:translateY(-40px) scale(0.5);opacity:0} 100%{transform:translateY(0) scale(1);opacity:1} }
    @keyframes book-collect { 0%{transform:scale(1)} 50%{transform:scale(1.3) rotate(5deg)} 100%{transform:scale(0) rotate(20deg);opacity:0} }
    @keyframes result-pop { 0%{transform:scale(0.3) rotate(-10deg);opacity:0} 60%{transform:scale(1.15) rotate(3deg);opacity:1} 100%{transform:scale(1) rotate(0deg);opacity:1} }
    @keyframes gofish-bounce { 0%{transform:translateY(0)} 50%{transform:translateY(-20px)} 100%{transform:translateY(0)} }
  `;
  document.head.appendChild(s);
}

// ── Game state stored in refs (avoids stale closures in aiTurn) ───────────────
interface GameState {
  kidHand: Card[];
  mavHand: Card[];
  caitHand: Card[];
  kidBooks: Rank[];
  mavBooks: Rank[];
  caitBooks: Rank[];
  deck: Card[];
  phase: Phase;
}

// ── Main game ─────────────────────────────────────────────────────────────────
interface GoFishProps {
  kidName: string;
  onEarnCredits: (n: number) => void;
  onClose: () => void;
}

export default function GoFish({ kidName, onEarnCredits, onClose }: GoFishProps) {
  useEffect(() => { injectStyles(); }, []);
  const sound = useSFX();

  // React state for rendering
  const [phase, setPhase] = useState<Phase>("dealing");
  const [kidHand, setKidHand] = useState<Card[]>([]);
  const [mavHand, setMavHand] = useState<Card[]>([]);
  const [caitHand, setCaitHand] = useState<Card[]>([]);
  const [kidBooks, setKidBooks] = useState<Rank[]>([]);
  const [mavBooks, setMavBooks] = useState<Rank[]>([]);
  const [caitBooks, setCaitBooks] = useState<Rank[]>([]);
  const [deckLen, setDeckLen] = useState(0);
  const [currentTurn, setCurrentTurn] = useState<Player>("kid");
  const [message, setMessage] = useState("");
  const [mavSpeech, setMavSpeech] = useState<string | undefined>(undefined);
  const [caitSpeech, setCaitSpeech] = useState<string | undefined>(undefined);
  const [mavState, setMavState] = useState<"idle" | "excited" | "sad" | "thinking">("idle");
  const [caitState, setCaitState] = useState<"idle" | "excited" | "sad" | "thinking">("idle");
  const [selectedRank, setSelectedRank] = useState<Rank | null>(null);
  const [askTarget, setAskTarget] = useState<"maverick" | "caitlin" | null>(null);
  const [goFishAnim, setGoFishAnim] = useState(false);
  const [totalWon, setTotalWon] = useState(0);
  const [winner, setWinner] = useState<Player | "tie" | null>(null);
  const [dealAnim, setDealAnim] = useState(false);

  // ── Authoritative game state in refs (always current, no stale closures) ────
  const gs = useRef<GameState>({
    kidHand: [], mavHand: [], caitHand: [],
    kidBooks: [], mavBooks: [], caitBooks: [],
    deck: [], phase: "dealing",
  });

  // Helper: sync ref + React state together
  const applyState = useCallback((patch: Partial<GameState>) => {
    const next = { ...gs.current, ...patch };
    gs.current = next;
    if (patch.kidHand !== undefined) setKidHand(patch.kidHand);
    if (patch.mavHand !== undefined) setMavHand(patch.mavHand);
    if (patch.caitHand !== undefined) setCaitHand(patch.caitHand);
    if (patch.kidBooks !== undefined) setKidBooks(patch.kidBooks);
    if (patch.mavBooks !== undefined) setMavBooks(patch.mavBooks);
    if (patch.caitBooks !== undefined) setCaitBooks(patch.caitBooks);
    if (patch.deck !== undefined) setDeckLen(patch.deck.length);
    if (patch.phase !== undefined) setPhase(patch.phase);
  }, []);

  // ── Deal cards ──────────────────────────────────────────────────────────────
  const dealNewGame = useCallback(() => {
    const d = shuffle(buildDeck());
    const kid: Card[] = []; const mav: Card[] = []; const cait: Card[] = [];
    for (let i = 0; i < 21; i++) {
      if (i % 3 === 0) kid.push(d[i]);
      else if (i % 3 === 1) mav.push(d[i]);
      else cait.push(d[i]);
    }
    const remaining = d.slice(21);
    setDealAnim(true);
    for (let i = 0; i < 7; i++) setTimeout(() => sound.deal(), i * 120);
    setTimeout(() => {
      const kb = findBooks(kid); const mb = findBooks(mav); const cb = findBooks(cait);
      applyState({
        kidHand: kb.remaining, mavHand: mb.remaining, caitHand: cb.remaining,
        kidBooks: kb.books, mavBooks: mb.books, caitBooks: cb.books,
        deck: remaining, phase: "playing",
      });
      setCurrentTurn("kid");
      setDealAnim(false);
      setMessage(`${kidName}, it's your turn! Pick a rank and ask Maverick or Caitlin.`);
      setMavSpeech("I've got a GREAT hand... 😏");
      setCaitSpeech("Let the best player win! 😊");
    }, 1200);
  }, [applyState, kidName, sound]);

  useEffect(() => { dealNewGame(); }, []); // eslint-disable-line react-hooks/exhaustive-deps

  // ── Check for books — operates on provided hands (not stale state) ──────────
  const checkBooks = useCallback((state: GameState): GameState => {
    const kb = findBooks(state.kidHand);
    const mb = findBooks(state.mavHand);
    const cb = findBooks(state.caitHand);
    if (kb.books.length > 0) { sound.book(); kb.books.forEach(r => setMessage(`📚 ${kidName} got a book of ${r}s!`)); }
    if (mb.books.length > 0) { sound.book(); mb.books.forEach(r => { setMavSpeech(MAV_BOOK(r)); setMavState("excited"); }); }
    if (cb.books.length > 0) { sound.book(); cb.books.forEach(r => { setCaitSpeech(CAIT_BOOK(r)); setCaitState("excited"); }); }
    return {
      ...state,
      kidHand: kb.remaining, mavHand: mb.remaining, caitHand: cb.remaining,
      kidBooks: [...state.kidBooks, ...kb.books],
      mavBooks: [...state.mavBooks, ...mb.books],
      caitBooks: [...state.caitBooks, ...cb.books],
    };
  }, [kidName, sound]);

  // ── Check game over — returns true if game ended ────────────────────────────
  const checkGameOver = useCallback((state: GameState): boolean => {
    const { kidBooks: kb, mavBooks: mb, caitBooks: cb, deck, kidHand, mavHand, caitHand } = state;
    const total = kb.length + mb.length + cb.length;
    if (total < 13 && deck.length > 0) return false;
    if (kidHand.length === 0 && mavHand.length === 0 && caitHand.length === 0 && deck.length === 0) {
      const max = Math.max(kb.length, mb.length, cb.length);
      if (kb.length === max && mb.length < max && cb.length < max) {
        setWinner("kid");
        const earned = 10;
        onEarnCredits(earned);
        setTotalWon(t => t + earned);
        setMavSpeech(rand(KID_WIN_MAV));
        setCaitSpeech(rand(KID_WIN_CAIT));
        setMavState("sad"); setCaitState("sad");
        sound.cheer();
      } else if (mb.length === max) {
        setWinner("maverick");
        setMavSpeech(rand(MAV_WIN));
        setCaitSpeech("Good game everyone! 🤝");
        setMavState("excited"); setCaitState("idle");
      } else if (cb.length === max) {
        setWinner("caitlin");
        setCaitSpeech(rand(CAIT_WIN));
        setMavSpeech("Caitlin got lucky... 😤");
        setCaitState("excited"); setMavState("sad");
      } else {
        setWinner("tie");
        setMavSpeech("A TIE?! Rematch! 😤");
        setCaitSpeech("Well played everyone! 🤝");
      }
      applyState({ ...state, phase: "gameover" });
      return true;
    }
    return false;
  }, [applyState, onEarnCredits, sound]);

  // ── AI turn — reads from gs.current (always fresh) ─────────────────────────
  // Using useRef for the function itself so it never goes stale in setTimeout
  const aiTurnRef = useRef<(player: "maverick" | "caitlin") => void>(() => {});

  aiTurnRef.current = (player: "maverick" | "caitlin") => {
    // Always read from the ref — never from closure
    const state = gs.current;
    if (state.phase === "gameover") return;

    setCurrentTurn(player);
    const hand = player === "maverick" ? state.mavHand : state.caitHand;

    if (hand.length === 0) {
      // Skip to next player
      const next: Player = player === "maverick" ? "caitlin" : "kid";
      setTimeout(() => {
        if (next === "kid") {
          setCurrentTurn("kid");
          setMessage(`${kidName}, it's your turn!`);
        } else {
          aiTurnRef.current("caitlin");
        }
      }, 500);
      return;
    }

    const ranks = uniqueRanks(hand);
    let askRank: Rank;
    if (player === "maverick") {
      askRank = [...ranks].sort((a, b) => RANK_ORDER[b] - RANK_ORDER[a])[0];
    } else {
      const countMap: Partial<Record<Rank, number>> = {};
      for (const c of hand) countMap[c.rank] = (countMap[c.rank] || 0) + 1;
      askRank = [...ranks].sort((a, b) => (countMap[b] || 0) - (countMap[a] || 0))[0];
    }

    const kidHas = hasRank(state.kidHand, askRank);
    const otherAI = player === "maverick" ? state.caitHand : state.mavHand;
    const otherHas = hasRank(otherAI, askRank);
    const target: Player = kidHas ? "kid" : otherHas ? (player === "maverick" ? "caitlin" : "maverick") : "kid";

    const speech = player === "maverick" ? MAV_ASK(askRank) : CAIT_ASK(askRank);
    if (player === "maverick") { setMavSpeech(speech); setMavState("thinking"); }
    else { setCaitSpeech(speech); setCaitState("thinking"); }

    setTimeout(() => {
      // Re-read from ref inside the timeout — this is the key fix
      const s = gs.current;
      if (s.phase === "gameover") return;

      const targetHand = target === "kid" ? s.kidHand : target === "maverick" ? s.mavHand : s.caitHand;
      const currentHand = player === "maverick" ? s.mavHand : s.caitHand;
      const got = targetHand.filter(c => c.rank === askRank);
      const targetName = target === "kid" ? kidName : target === "maverick" ? "Maverick" : "Caitlin";

      if (got.length > 0) {
        const newAIHand = [...currentHand, ...got];
        const newTargetHand = targetHand.filter(c => c.rank !== askRank);
        setMessage(`${player === "maverick" ? "Maverick" : "Caitlin"} asked ${targetName} for ${askRank}s and got ${got.length}!`);

        let newState: GameState;
        if (player === "maverick") {
          setMavState("excited");
          setMavSpeech(`YES! Got ${got.length} ${askRank}${got.length > 1 ? "s" : ""}! 🏆`);
          newState = {
            ...s,
            mavHand: newAIHand,
            kidHand: target === "kid" ? newTargetHand : s.kidHand,
            caitHand: target === "caitlin" ? newTargetHand : s.caitHand,
          };
        } else {
          setCaitState("excited");
          setCaitSpeech(`Thank you! ${askRank}s are mine now! ✨`);
          newState = {
            ...s,
            caitHand: newAIHand,
            kidHand: target === "kid" ? newTargetHand : s.kidHand,
            mavHand: target === "maverick" ? newTargetHand : s.mavHand,
          };
        }

        const afterBooks = checkBooks(newState);
        applyState(afterBooks);
        if (!checkGameOver(afterBooks)) {
          setTimeout(() => aiTurnRef.current(player), 1800);
        }
      } else {
        // Go Fish for AI
        sound.goFish();
        if (player === "maverick") { setMavSpeech("...Go Fish 😤"); setMavState("sad"); }
        else { setCaitSpeech("Oh! Go Fish! 🎣"); setCaitState("idle"); }

        let newState: GameState = { ...s };
        if (s.deck.length > 0) {
          const drawn = s.deck[0];
          const newDeck = s.deck.slice(1);
          const newAIHand = [...currentHand, drawn];
          sound.deal();
          setMessage(`${player === "maverick" ? "Maverick" : "Caitlin"} went fishing...`);
          newState = {
            ...s,
            deck: newDeck,
            mavHand: player === "maverick" ? newAIHand : s.mavHand,
            caitHand: player === "caitlin" ? newAIHand : s.caitHand,
          };
        } else {
          setMessage(`${player === "maverick" ? "Maverick" : "Caitlin"} has no cards to draw.`);
        }

        const afterBooks = checkBooks(newState);
        applyState(afterBooks);

        if (!checkGameOver(afterBooks)) {
          const next: Player = player === "maverick" ? "caitlin" : "kid";
          setTimeout(() => {
            if (next === "kid") {
              setCurrentTurn("kid");
              setMessage(`${kidName}, your turn! Pick a rank and ask someone.`);
            } else {
              aiTurnRef.current("caitlin");
            }
          }, 1200);
        }
      }
    }, 1200);
  };

  // ── Kid asks ────────────────────────────────────────────────────────────────
  const kidAsk = useCallback(() => {
    if (!selectedRank || !askTarget || gs.current.phase !== "playing") return;
    const s = gs.current;
    const targetHand = askTarget === "maverick" ? s.mavHand : s.caitHand;
    const got = targetHand.filter(c => c.rank === selectedRank);
    const targetName = askTarget === "maverick" ? "Maverick" : "Caitlin";

    if (got.length > 0) {
      const newKidHand = [...s.kidHand, ...got];
      const newTargetHand = targetHand.filter(c => c.rank !== selectedRank);
      if (askTarget === "maverick") {
        setMavSpeech(`FINE! Take them! 😤`);
        setMavState("sad");
      } else {
        setCaitSpeech(`Here you go! 😊`);
        setCaitState("thinking");
      }
      setMessage(`${targetName} had ${got.length} ${selectedRank}${got.length > 1 ? "s" : ""}! Go again!`);

      const newState: GameState = {
        ...s,
        kidHand: newKidHand,
        mavHand: askTarget === "maverick" ? newTargetHand : s.mavHand,
        caitHand: askTarget === "caitlin" ? newTargetHand : s.caitHand,
      };
      const afterBooks = checkBooks(newState);
      applyState(afterBooks);
      checkGameOver(afterBooks);
      // Kid gets another turn — stay on "kid"
      setCurrentTurn("kid");
    } else {
      // Go Fish!
      sound.goFish();
      setGoFishAnim(true);
      setTimeout(() => setGoFishAnim(false), 800);
      if (askTarget === "maverick") { setMavSpeech(rand(MAV_GOFISH)); setMavState("excited"); }
      else { setCaitSpeech(rand(CAIT_GOFISH)); setCaitState("thinking"); }

      let newState: GameState = { ...s };
      if (s.deck.length > 0) {
        const drawn = s.deck[0];
        const newDeck = s.deck.slice(1);
        const newKidHand = [...s.kidHand, drawn];
        sound.deal();
        setMessage(`Go Fish! You drew a ${drawn.rank}${drawn.suit}. Maverick's turn.`);
        newState = { ...s, deck: newDeck, kidHand: newKidHand };
      } else {
        setMessage(`Go Fish! No cards left in deck. Maverick's turn.`);
      }

      const afterBooks = checkBooks(newState);
      applyState(afterBooks);

      if (!checkGameOver(afterBooks)) {
        setSelectedRank(null); setAskTarget(null);
        setTimeout(() => aiTurnRef.current("maverick"), 1500);
        return;
      }
    }
    setSelectedRank(null); setAskTarget(null);
  }, [selectedRank, askTarget, applyState, checkBooks, checkGameOver, sound]);

  const resetGame = useCallback(() => {
    setPhase("dealing");
    setKidHand([]); setMavHand([]); setCaitHand([]);
    setKidBooks([]); setMavBooks([]); setCaitBooks([]);
    setDeckLen(0);
    setCurrentTurn("kid"); setWinner(null); setMessage("");
    setSelectedRank(null); setAskTarget(null);
    setMavSpeech(undefined); setCaitSpeech(undefined);
    setMavState("idle"); setCaitState("idle");
    gs.current = {
      kidHand: [], mavHand: [], caitHand: [],
      kidBooks: [], mavBooks: [], caitBooks: [],
      deck: [], phase: "dealing",
    };
    dealNewGame();
  }, [dealNewGame]);

  return (
    <div style={{ minHeight: "100vh", background: "linear-gradient(160deg, #0a0a1a 0%, #0f1a0a 50%, #1a0a1a 100%)", display: "flex", flexDirection: "column", alignItems: "center", padding: "20px 12px", fontFamily: "Oswald, sans-serif" }}>
      {/* Header */}
      <div style={{ width: "100%", maxWidth: 700, display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
        <button onClick={onClose} style={{ background: "rgba(255,255,255,0.1)", border: "none", color: "white", borderRadius: 8, padding: "6px 14px", cursor: "pointer", fontSize: 14, fontFamily: "Oswald, sans-serif" }}>← Back</button>
        <h1 style={{ color: "white", fontSize: 20, fontWeight: 900, margin: 0, letterSpacing: 2 }}>🐟 3-HANDED GO FISH</h1>
        <div style={{ background: "rgba(251,191,36,0.2)", border: "1px solid #fbbf24", borderRadius: 8, padding: "4px 12px", color: "#fbbf24", fontSize: 13, fontWeight: 900 }}>+{totalWon} credits</div>
      </div>

      {/* Score / books */}
      <div style={{ display: "flex", gap: 16, marginBottom: 12, background: "rgba(255,255,255,0.05)", borderRadius: 12, padding: "8px 20px", border: "1px solid rgba(255,255,255,0.1)", width: "100%", maxWidth: 700, justifyContent: "space-around" }}>
        {[
          { label: kidName, books: kidBooks, color: "#34d399" },
          { label: "Maverick", books: mavBooks, color: "#60a5fa" },
          { label: "Caitlin", books: caitBooks, color: "#f472b6" },
        ].map(p => (
          <div key={p.label} style={{ textAlign: "center" }}>
            <div style={{ color: p.color, fontWeight: 900, fontSize: 18 }}>📚 {p.books.length}</div>
            <div style={{ color: "rgba(255,255,255,0.5)", fontSize: 10, textTransform: "uppercase", letterSpacing: 1 }}>{p.label}</div>
            <div style={{ display: "flex", gap: 2, flexWrap: "wrap", justifyContent: "center", marginTop: 2 }}>
              {p.books.map(r => <span key={r} style={{ background: p.color, color: "black", borderRadius: 4, padding: "1px 5px", fontSize: 9, fontWeight: 900 }}>{r}</span>)}
            </div>
          </div>
        ))}
        <div style={{ textAlign: "center" }}>
          <div style={{ color: "rgba(255,255,255,0.6)", fontWeight: 900, fontSize: 18 }}>🃏 {deckLen}</div>
          <div style={{ color: "rgba(255,255,255,0.4)", fontSize: 10, textTransform: "uppercase", letterSpacing: 1 }}>Deck</div>
        </div>
      </div>

      {/* Characters row */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", width: "100%", maxWidth: 700, marginBottom: 12 }}>
        <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 8 }}>
          <CharPortrait character="maverick" size={65} state={mavState} speech={mavSpeech} speechSide="right" />
          <div style={{ display: "flex", gap: 2, flexWrap: "wrap", justifyContent: "center", maxWidth: 160 }}>
            {mavHand.slice(0, 7).map((c, i) => <PlayingCard key={i} card={c} faceDown small />)}
            {mavHand.length > 7 && <span style={{ color: "rgba(255,255,255,0.4)", fontSize: 10, alignSelf: "center" }}>+{mavHand.length - 7}</span>}
          </div>
          <div style={{ color: "#60a5fa", fontSize: 10, fontWeight: 900 }}>{mavHand.length} cards</div>
        </div>

        {/* Center: message + Go Fish anim */}
        <div style={{ flex: 1, textAlign: "center", padding: "0 12px" }}>
          {goFishAnim && (
            <div style={{ fontSize: 40, animation: "gofish-bounce 0.8s ease-in-out", marginBottom: 8 }}>🐟</div>
          )}
          <div style={{ color: "white", fontSize: 13, fontWeight: 700, lineHeight: 1.4, minHeight: 40 }}>{message}</div>
          {currentTurn === "kid" && phase === "playing" && (
            <div style={{ marginTop: 4, color: "#34d399", fontSize: 11, fontWeight: 900, letterSpacing: 1 }}>⬇️ YOUR TURN</div>
          )}
          {currentTurn !== "kid" && phase === "playing" && (
            <div style={{ marginTop: 4, color: currentTurn === "maverick" ? "#60a5fa" : "#f472b6", fontSize: 11, fontWeight: 900, letterSpacing: 1 }}>
              ⏳ {currentTurn === "maverick" ? "MAVERICK" : "CAITLIN"}'S TURN...
            </div>
          )}
        </div>

        <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 8 }}>
          <CharPortrait character="caitlin" size={65} state={caitState} speech={caitSpeech} speechSide="left" />
          <div style={{ display: "flex", gap: 2, flexWrap: "wrap", justifyContent: "center", maxWidth: 160 }}>
            {caitHand.slice(0, 7).map((c, i) => <PlayingCard key={i} card={c} faceDown small />)}
            {caitHand.length > 7 && <span style={{ color: "rgba(255,255,255,0.4)", fontSize: 10, alignSelf: "center" }}>+{caitHand.length - 7}</span>}
          </div>
          <div style={{ color: "#f472b6", fontSize: 10, fontWeight: 900 }}>{caitHand.length} cards</div>
        </div>
      </div>

      {/* Kid's hand */}
      <div style={{ width: "100%", maxWidth: 700, background: "rgba(52,211,153,0.05)", border: "1px solid rgba(52,211,153,0.2)", borderRadius: 16, padding: "12px", marginBottom: 12 }}>
        <div style={{ color: "#34d399", fontSize: 11, fontWeight: 900, letterSpacing: 2, textTransform: "uppercase", marginBottom: 8 }}>
          {kidName}'s Hand ({kidHand.length} cards)
        </div>
        <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
          {kidHand.map((c, i) => (
            <div
              key={c.id}
              onClick={() => currentTurn === "kid" && phase === "playing" && setSelectedRank(c.rank)}
              style={{
                cursor: currentTurn === "kid" ? "pointer" : "default",
                transform: selectedRank === c.rank ? "translateY(-12px)" : "translateY(0)",
                transition: "transform 0.2s",
                animation: dealAnim ? `card-deal 0.3s ease-out ${i * 80}ms both` : "none",
                outline: selectedRank === c.rank ? "3px solid #34d399" : "none",
                borderRadius: 8,
              }}>
              <PlayingCard card={c} />
            </div>
          ))}
          {kidHand.length === 0 && <span style={{ color: "rgba(255,255,255,0.3)", fontSize: 12 }}>No cards in hand</span>}
        </div>
      </div>

      {/* Ask controls */}
      {currentTurn === "kid" && phase === "playing" && selectedRank && (
        <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 10, marginBottom: 12 }}>
          <div style={{ color: "white", fontSize: 13 }}>
            Ask for <strong style={{ color: "#fbbf24" }}>{selectedRank}s</strong> from:
          </div>
          <div style={{ display: "flex", gap: 12 }}>
            {(["maverick", "caitlin"] as const).map(target => (
              <button
                key={target}
                onClick={() => { setAskTarget(target); }}
                style={{
                  padding: "10px 24px",
                  borderRadius: 12,
                  border: `2px solid ${askTarget === target ? (target === "maverick" ? "#60a5fa" : "#f472b6") : "rgba(255,255,255,0.2)"}`,
                  background: askTarget === target ? (target === "maverick" ? "rgba(96,165,250,0.2)" : "rgba(244,114,182,0.2)") : "rgba(255,255,255,0.05)",
                  color: "white",
                  fontWeight: 900,
                  fontSize: 14,
                  cursor: "pointer",
                  fontFamily: "Oswald, sans-serif",
                  textTransform: "uppercase",
                  letterSpacing: 1,
                }}>
                {target === "maverick" ? "Maverick 🏀" : "Caitlin 🏀"}
              </button>
            ))}
          </div>
          {askTarget && (
            <button
              onClick={kidAsk}
              style={{
                padding: "12px 32px",
                borderRadius: 14,
                border: "none",
                background: "linear-gradient(135deg, #f59e0b, #ef4444)",
                color: "white",
                fontWeight: 900,
                fontSize: 16,
                cursor: "pointer",
                fontFamily: "Oswald, sans-serif",
                letterSpacing: 2,
                boxShadow: "0 0 24px rgba(245,158,11,0.5)",
              }}>
              ASK FOR {selectedRank}s! 🎴
            </button>
          )}
        </div>
      )}

      {/* Game over */}
      {phase === "gameover" && winner && (
        <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 12, padding: "20px", background: "rgba(0,0,0,0.6)", borderRadius: 20, border: "1px solid rgba(255,255,255,0.1)", animation: "result-pop 0.4s ease-out forwards" }}>
          <div style={{ fontSize: 48 }}>{winner === "kid" ? "🏆" : winner === "tie" ? "🤝" : "😤"}</div>
          <div style={{ color: "white", fontWeight: 900, fontSize: 22, letterSpacing: 2, textAlign: "center" }}>
            {winner === "kid" ? `${kidName} WINS! +10 credits! 🎉` : winner === "tie" ? "IT'S A TIE! 🤝" : `${winner === "maverick" ? "Maverick" : "Caitlin"} wins this round!`}
          </div>
          <div style={{ color: "rgba(255,255,255,0.6)", fontSize: 13 }}>
            Final books — {kidName}: {kidBooks.length} | Maverick: {mavBooks.length} | Caitlin: {caitBooks.length}
          </div>
          <div style={{ display: "flex", gap: 12 }}>
            <button onClick={resetGame} style={{ padding: "12px 28px", borderRadius: 14, border: "none", background: "linear-gradient(135deg, #7c3aed, #4f46e5)", color: "white", fontWeight: 900, fontSize: 15, cursor: "pointer", fontFamily: "Oswald, sans-serif", letterSpacing: 2 }}>
              Play Again! 🔄
            </button>
            <button onClick={onClose} style={{ padding: "12px 28px", borderRadius: 14, border: "1px solid rgba(255,255,255,0.2)", background: "transparent", color: "white", fontWeight: 900, fontSize: 15, cursor: "pointer", fontFamily: "Oswald, sans-serif" }}>
              Back to Arcade
            </button>
          </div>
        </div>
      )}

      {phase === "dealing" && (
        <div style={{ color: "white", fontSize: 18, fontWeight: 900, letterSpacing: 2, animation: "mascot-bounce 0.5s ease-in-out infinite" }}>
          🃏 Dealing cards...
        </div>
      )}

      <p style={{ color: "rgba(255,255,255,0.3)", fontSize: 11, marginTop: 16, textAlign: "center" }}>
        Win = +10 credits • Collect 4-of-a-kind books • Most books wins!
      </p>
    </div>
  );
}
