import { useState } from "react";
import { useRoute } from "wouter";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/_core/hooks/useAuth";
import { ShoppingCart, Award, ArrowLeft, CheckCircle, AlertTriangle, Loader2, Truck, ExternalLink } from "lucide-react";
import { Link } from "wouter";
import { toast } from "sonner";

export default function CardDetail() {
  const [, params] = useRoute("/arena/:id");
  const id = parseInt(params?.id || "0");
  const { isAuthenticated } = useAuth();
  const { data: card, isLoading, refetch } = trpc.cards.getById.useQuery({ id });
  const createOrder = trpc.orders.create.useMutation();
  const checkAvailability = trpc.orders.checkDropshipAvailability.useMutation();

  const [availabilityStatus, setAvailabilityStatus] = useState<"idle" | "checking" | "available" | "unavailable">("idle");

  const isDropship = !!(card as any)?.isDropship;
  const shippingFee = parseFloat((card as any)?.cardShippingFee ?? "0");
  const totalPrice = parseFloat(card?.price ?? "0") + shippingFee;

  const handleCheckAvailability = async () => {
    if (!card) return;
    setAvailabilityStatus("checking");
    try {
      const result = await checkAvailability.mutateAsync({ cardId: card.id, ebayItemId: (card as any).ebayItemId || "" });
      if (result.available) {
        setAvailabilityStatus("available");
        toast.success("Card is available — ready to purchase!");
      } else {
        setAvailabilityStatus("unavailable");
        toast.error("This card just sold on eBay and has been removed from our inventory.");
        refetch();
      }
    } catch {
      setAvailabilityStatus("idle");
      toast.error("Could not verify availability. Please try again.");
    }
  };

  const handleBuyNow = async () => {
    if (!card) return;
    // For dropship cards, require availability check first
    if (isDropship && availabilityStatus !== "available") {
      toast.warning("Please verify availability before purchasing.");
      return;
    }
    try {
      await createOrder.mutateAsync({
        cardId: card.id,
        cardTitle: card.title,
        cardImageUrl: card.frontImageUrl || undefined,
        sellerEmail: card.sellerEmail,
        sellerStoreName: card.storeName || undefined,
        price: card.price || "0",
      });
      toast.success("Order placed! Check your orders page.");
    } catch (e: any) {
      toast.error(e.message || "Failed to place order");
    }
  };

  if (isLoading) return (
    <div className="min-h-screen bg-[#0a1628] flex items-center justify-center">
      <Loader2 className="w-8 h-8 text-white/30 animate-spin" />
    </div>
  );
  if (!card) return (
    <div className="min-h-screen bg-[#0a1628] flex items-center justify-center">
      <p className="text-white/50">Card not found</p>
    </div>
  );

  return (
    <div className="min-h-screen bg-[#0a1628] pb-20">
      <div className="max-w-5xl mx-auto px-4 py-8">
        <Link href="/arena">
          <Button variant="ghost" className="mb-6 gap-2 text-white/60 hover:text-white hover:bg-white/10">
            <ArrowLeft className="w-4 h-4" />Back to Arena
          </Button>
        </Link>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Card Image */}
          <div className="space-y-4">
            <div className="aspect-[3/4] bg-[#0d1f3c] rounded-xl overflow-hidden border border-white/10">
              {card.frontImageUrl ? (
                <img src={card.frontImageUrl} alt={card.title} className="w-full h-full object-cover" />
              ) : (
                <div className="w-full h-full flex items-center justify-center">
                  <Award className="w-16 h-16 text-white/10" />
                </div>
              )}
            </div>
            {card.backImageUrl && (
              <div className="aspect-[3/4] bg-[#0d1f3c] rounded-xl overflow-hidden border border-white/10">
                <img src={card.backImageUrl} alt={`${card.title} back`} className="w-full h-full object-cover" />
              </div>
            )}
          </div>

          {/* Card Info */}
          <div>
            {/* Badges */}
            <div className="flex gap-2 mb-3 flex-wrap">
              {isDropship && (
                <Badge className="bg-blue-500/20 text-blue-400 border border-blue-500/30 text-xs">
                  eBay Sourced
                </Badge>
              )}
              {card.sport && (
                <Badge className="bg-white/10 text-white/60 border border-white/10 text-xs capitalize">
                  {card.sport}
                </Badge>
              )}
              {((card as any).gradeCompany && (card as any).gradeCompany !== 'none' && (card as any).gradeScore) ? (
                <Badge className="bg-[#E8C547]/20 text-[#E8C547] border border-[#E8C547]/30 text-xs font-black">
                  {(card as any).gradeCompany === 'Beckett' ? 'BGS' : (card as any).gradeCompany} {(card as any).gradeScore}
                </Badge>
              ) : card.aiGrade ? (
                <Badge className="bg-[#E8C547]/20 text-[#E8C547] border border-[#E8C547]/30 text-xs font-black">
                  {card.aiGradeLabel || `SCG ${card.aiGrade}`}
                </Badge>
              ) : null}
            </div>

            <h1 className="text-2xl font-black text-white mb-1" style={{ fontFamily: "Oswald, sans-serif" }}>{card.title}</h1>
            <p className="text-white/50 text-sm mb-4">{card.playerName}</p>

            {/* Price */}
            <div className="bg-[#0d1f3c] border border-white/10 rounded-xl p-4 mb-4">
              <div className="flex items-end gap-3 mb-2">
                <span className="text-4xl font-black text-green-400">${parseFloat(card.price || "0").toFixed(2)}</span>
                {shippingFee > 0 && (
                  <span className="text-white/40 text-sm mb-1">+ ${shippingFee.toFixed(2)} shipping</span>
                )}
                {shippingFee === 0 && isDropship && (
                  <span className="text-green-500 text-sm mb-1 font-semibold">Free Shipping</span>
                )}
              </div>
              {shippingFee > 0 && (
                <div className="flex items-center gap-1 text-white/60 text-sm">
                  <Truck className="w-3.5 h-3.5" />
                  <span>Total: <strong className="text-white">${totalPrice.toFixed(2)}</strong></span>
                </div>
              )}
            </div>

            {/* eBay Availability Check */}
            {isDropship && (
              <div className="mb-4">
                {availabilityStatus === "idle" && (
                  <Button
                    variant="outline"
                    className="w-full gap-2 border-blue-500/30 text-blue-400 hover:bg-blue-500/10 bg-transparent"
                    onClick={handleCheckAvailability}
                  >
                    <CheckCircle className="w-4 h-4" />
                    Check Availability Before Buying
                  </Button>
                )}
                {availabilityStatus === "checking" && (
                  <div className="flex items-center justify-center gap-2 py-2 text-white/50 text-sm">
                    <Loader2 className="w-4 h-4 animate-spin" />
                    Verifying availability on eBay...
                  </div>
                )}
                {availabilityStatus === "available" && (
                  <div className="flex items-center gap-2 py-2 px-3 bg-green-500/10 border border-green-500/20 rounded-lg text-green-400 text-sm">
                    <CheckCircle className="w-4 h-4 shrink-0" />
                    <span>Available — this card is in stock on eBay</span>
                  </div>
                )}
                {availabilityStatus === "unavailable" && (
                  <div className="flex items-center gap-2 py-2 px-3 bg-red-500/10 border border-red-500/20 rounded-lg text-red-400 text-sm">
                    <AlertTriangle className="w-4 h-4 shrink-0" />
                    <span>Sorry — this card just sold. It has been removed from our inventory.</span>
                  </div>
                )}
              </div>
            )}

            {/* Buy Button */}
            {availabilityStatus !== "unavailable" && (
              isAuthenticated ? (
                <Button
                  size="lg"
                  className="w-full gap-2 bg-[#C41E3A] hover:bg-[#a01830] text-white font-bold"
                  onClick={handleBuyNow}
                  disabled={createOrder.isPending || (isDropship && availabilityStatus !== "available")}
                >
                  {createOrder.isPending ? (
                    <><Loader2 className="w-5 h-5 animate-spin" /> Processing...</>
                  ) : (
                    <><ShoppingCart className="w-5 h-5" /> {isDropship && availabilityStatus !== "available" ? "Verify Availability First" : "Buy Now"}</>
                  )}
                </Button>
              ) : (
                <Button size="lg" className="w-full bg-[#C41E3A] hover:bg-[#a01830] text-white font-bold" asChild>
                  <a href="/api/oauth/login">Sign In to Purchase</a>
                </Button>
              )
            )}

            {/* Card Details */}
            <div className="mt-6 space-y-2 text-sm text-white/50 border-t border-white/10 pt-4">
              {card.storeName && <p><span className="text-white/30">Sold by:</span> {card.storeName}</p>}
              {card.year && <p><span className="text-white/30">Year:</span> {card.year}</p>}
              {card.setName && <p><span className="text-white/30">Set:</span> {card.setName}</p>}
              {card.cardNumber && <p><span className="text-white/30">Card #:</span> {card.cardNumber}</p>}
              {(card as any).ebayListingUrl && (
                <a
                  href={(card as any).ebayListingUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1 text-blue-400 hover:underline text-xs mt-1"
                >
                  <ExternalLink className="w-3 h-3" />
                  View original eBay listing
                </a>
              )}
              {card.description && <p className="mt-4 text-white/40">{card.description}</p>}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
