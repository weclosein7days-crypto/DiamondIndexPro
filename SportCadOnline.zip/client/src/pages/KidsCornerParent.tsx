import { useState } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import Footer from "@/components/Footer";
import { trpc } from "@/lib/trpc";
import { ArrowLeft, ChevronDown, Heart, ShoppingCart, ExternalLink } from "lucide-react";
import { type HouseCard } from "@/data/houseCards";

// ─── Credit packages ──────────────────────────────────────────────────────────
const CREDIT_PACKAGES = [
  { id: "starter",   label: "Starter 🌱",    credits: 100,  price: 1,  popular: false },
  { id: "player",    label: "Player 🎴",     credits: 200,  price: 2,  popular: false },
  { id: "allstar",   label: "All-Star ⭐",   credits: 500,  price: 5,  popular: true  },
  { id: "mvp",       label: "MVP 🏆",        credits: 1000, price: 10, popular: false },
  { id: "champion",  label: "Champion 💪",   credits: 1500, price: 15, popular: false },
  { id: "hof",       label: "Hall of Fame 👑", credits: 2000, price: 20, popular: false },
];

// ─── Reward catalogs ──────────────────────────────────────────────────────────
const CHORES = [
  { label: "Mowed the Lawn",   credits: 30 },
  { label: "Did the Dishes",   credits: 15 },
  { label: "Cleaned Their Room", credits: 20 },
  { label: "Took Out the Trash", credits: 10 },
  { label: "Vacuumed",         credits: 15 },
  { label: "Other Chore",      credits: 10 },
];

const GOOD_DEEDS = [
  { label: "Helped a Family Member", credits: 25 },
  { label: "Helped a Friend",        credits: 20 },
  { label: "Went to Church",         credits: 30 },
  { label: "Helped an Elder",        credits: 30 },
  { label: "Did a Kind Act",         credits: 20 },
  { label: "Other Good Deed",        credits: 15 },
];

const ACADEMIC = [
  { label: "Got an A on a Test",         credits: 100 },
  { label: "Got a B on a Test",          credits: 50  },
  { label: "A or B on Report Card",      credits: 150 },
  { label: "No Late / Absences",         credits: 50  },
  { label: "Studied Hard",              credits: 25  },
  { label: "Tutored Someone",           credits: 40  },
  { label: "Memorized a Bible Verse",   credits: 35  },
  { label: "Learned a Multiplication Table", credits: 30 },
  { label: "Other Achievement",         credits: 20  },
];

const SPECIAL_EVENTS = [
  { label: "Birthday",           credits: 200 },
  { label: "Christmas",          credits: 300 },
  { label: "Hanukkah",           credits: 300 },
  { label: "Easter",             credits: 150 },
  { label: "Graduation",         credits: 500 },
  { label: "Signed Up for a Sport", credits: 100 },
  { label: "Other Special Day",  credits: 100 },
];

// ─── Section wrapper ──────────────────────────────────────────────────────────
function Section({ icon, title, subtitle, children }: { icon: string; title: string; subtitle: string; children: React.ReactNode }) {
  return (
    <div className="bg-white/5 border border-white/10 rounded-3xl p-6 mb-6">
      <div className="flex items-center gap-3 mb-4">
        <span className="text-3xl">{icon}</span>
        <div>
          <h3 className="text-white font-black text-xl" style={{ fontFamily: "Oswald, sans-serif" }}>{title}</h3>
          <p className="text-white/50 text-xs">{subtitle}</p>
        </div>
      </div>
      {children}
    </div>
  );
}

// ─── Reward Dropdown ──────────────────────────────────────────────────────────
function RewardDropdown({
  title, emoji, items, onAward
}: {
  title: string;
  emoji: string;
  items: { label: string; credits: number }[];
  onAward: (credits: number, reason: string) => void;
}) {
  const [open, setOpen] = useState(false);
  const [selected, setSelected] = useState<{ label: string; credits: number } | null>(null);

  return (
    <div className="mb-3">
      <button
        onClick={() => setOpen(o => !o)}
        className="w-full flex items-center justify-between bg-white/5 hover:bg-white/10 border border-white/10 rounded-2xl px-4 py-3 transition-all"
      >
        <span className="text-white font-bold text-sm">{emoji} {title}</span>
        <ChevronDown className={`w-4 h-4 text-white/50 transition-transform ${open ? "rotate-180" : ""}`} />
      </button>
      {open && (
        <div className="mt-2 bg-black/30 border border-white/10 rounded-2xl p-3 space-y-2">
          {items.map(item => (
            <button
              key={item.label}
              onClick={() => setSelected(item)}
              className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-sm transition-all ${
                selected?.label === item.label
                  ? "bg-yellow-400/20 border border-yellow-400/40 text-yellow-300"
                  : "bg-white/5 hover:bg-white/10 text-white/80 border border-transparent"
              }`}
            >
              <span>{item.label}</span>
              <span className="text-yellow-400 font-black text-xs">+{item.credits} credits</span>
            </button>
          ))}
          {selected && (
            <Button
              onClick={() => {
                onAward(selected.credits, selected.label);
                setSelected(null);
                setOpen(false);
              }}
              className="w-full bg-gradient-to-r from-yellow-400 to-orange-500 text-black font-black mt-2 rounded-xl"
            >
              🏆 Award {selected.credits} Credits for "{selected.label}"
            </Button>
          )}
        </div>
      )}
    </div>
  );
}

// ─── Wish List Section ────────────────────────────────────────────────────────
function WishListSection({ kidName, wishList }: { kidName: string; wishList: HouseCard[] }) {
  if (wishList.length === 0) {
    return (
      <div className="text-center py-10 bg-white/5 rounded-2xl border border-white/10">
        <div className="text-4xl mb-3">❤️</div>
        <p className="text-white/60 font-bold">No cards on the wish list yet!</p>
        <p className="text-white/40 text-sm mt-1">{kidName || "Your child"} hasn't added any cards to their wish list.</p>
        <p className="text-white/30 text-xs mt-1">They can add up to 5 cards from the Card Showcase in Kids Corner.</p>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      <div className="flex items-center gap-2 mb-2">
        <Heart className="w-4 h-4 text-pink-400 fill-pink-400" />
        <p className="text-pink-300 font-bold text-sm">{kidName || "Your child"} wants these {wishList.length} card{wishList.length !== 1 ? "s" : ""}:</p>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        {wishList.map((card, i) => (
          <div key={card.id} className="flex gap-3 bg-white/5 border border-pink-500/20 rounded-2xl p-3 hover:border-pink-400/40 transition-all">
            {/* Card image */}
            <div className="w-16 flex-shrink-0 rounded-xl overflow-hidden border border-white/10">
              <img
                src={card.cdnImageUrl || card.ebayImageUrl}
                alt={card.player}
                className="w-full h-auto object-cover"
                onError={e => { (e.target as HTMLImageElement).src = card.ebayImageUrl; }}
              />
            </div>
            {/* Card info */}
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-1 mb-0.5">
                <span className="text-pink-400 font-black text-xs">#{i + 1}</span>
                <span className="bg-yellow-400 text-black font-black text-[8px] rounded-full w-3.5 h-3.5 flex items-center justify-center">H</span>
                <span className="text-white/30 text-[9px]">House Card</span>
              </div>
              <p className="text-white font-black text-sm leading-tight truncate">{card.player}</p>
              <p className="text-white/50 text-[10px]">{card.sport}</p>
              <p className="text-white/30 text-[9px] mt-0.5 line-clamp-1">{card.name}</p>
              <div className="flex items-center gap-2 mt-1.5">
                <span className="text-yellow-400 font-black text-xs">⚡ {card.creditCost} credits</span>
              </div>
            </div>
            {/* eBay link */}
            <div className="flex-shrink-0 flex flex-col items-end gap-1">
              <a
                href={`https://www.ebay.com/itm/${card.ebayItemId.replace("v1|", "").split("|")[0]}`}
                target="_blank"
                rel="noreferrer"
                className="flex items-center gap-1 bg-blue-600/20 hover:bg-blue-600/40 border border-blue-500/30 rounded-lg px-2 py-1 text-blue-300 text-[9px] font-bold transition-all"
                onClick={e => e.stopPropagation()}
              >
                <ExternalLink className="w-2.5 h-2.5" />
                eBay
              </a>
              <span className="text-white/30 text-[9px] text-right">Buy the real<br/>version!</span>
            </div>
          </div>
        ))}
      </div>
      <div className="bg-pink-500/10 border border-pink-500/20 rounded-2xl p-3 text-center">
        <p className="text-pink-300 font-bold text-sm">💜 These are the real cards your child wants!</p>
        <p className="text-white/50 text-xs mt-1">Click the eBay link to buy the actual physical card as a gift. The H badge means it's a verified house card.</p>
      </div>
    </div>
  );
}

// ─── Learning Stats Panel ─────────────────────────────────────────────────────
function LearningStatsPanel({ kidName }: { kidName: string }) {
  const kidDbId = parseInt(localStorage.getItem("kc_db_id") || "0", 10);
  const { data: stats } = trpc.kidsTrivia.getLearningStats.useQuery(
    { kidId: kidDbId },
    { enabled: kidDbId > 0 }
  );

  if (!kidDbId) {
    return (
      <div className="bg-white/5 border border-white/10 rounded-2xl p-4 text-center">
        <p className="text-3xl mb-2">🧠</p>
        <p className="text-white/50 text-sm">Learning stats will appear after {kidName} plays trivia for the first time!</p>
      </div>
    );
  }

  const SUBJECTS = [
    { key: "math", label: "Math", emoji: "➕", color: "text-blue-400", bg: "bg-blue-500/10 border-blue-500/20" },
    { key: "reading", label: "Reading", emoji: "📖", color: "text-purple-400", bg: "bg-purple-500/10 border-purple-500/20" },
    { key: "science", label: "Science", emoji: "🔬", color: "text-green-400", bg: "bg-green-500/10 border-green-500/20" },
    { key: "history", label: "History", emoji: "📜", color: "text-amber-400", bg: "bg-amber-500/10 border-amber-500/20" },
    { key: "sports_facts", label: "Sports", emoji: "🏆", color: "text-red-400", bg: "bg-red-500/10 border-red-500/20" },
  ];

  return (
    <div className="space-y-4">
      {/* Summary row */}
      <div className="grid grid-cols-3 gap-3">
        <div className="bg-yellow-400/10 border border-yellow-400/20 rounded-2xl p-3 text-center">
          <p className="text-yellow-400 font-black text-xl">{stats?.totalAnswered ?? 0}</p>
          <p className="text-white/40 text-[10px] mt-0.5">Questions Answered</p>
        </div>
        <div className="bg-green-500/10 border border-green-500/20 rounded-2xl p-3 text-center">
          <p className="text-green-400 font-black text-xl">{stats?.accuracy ?? 0}%</p>
          <p className="text-white/40 text-[10px] mt-0.5">Accuracy Rate</p>
        </div>
        <div className="bg-orange-500/10 border border-orange-500/20 rounded-2xl p-3 text-center">
          <p className="text-orange-400 font-black text-xl">
            {Math.max(...(stats?.subjectMastery?.map((m: any) => m.currentStreak ?? 0) ?? [0]))}
          </p>
          <p className="text-white/40 text-[10px] mt-0.5">Best Streak</p>
        </div>
      </div>

      {/* Subject breakdown */}
      <div className="bg-white/5 border border-white/10 rounded-2xl p-4">
        <p className="text-white/60 text-xs font-bold uppercase tracking-wider mb-3">Subject Mastery</p>
        <div className="space-y-2">
          {SUBJECTS.map(sub => {
            const mastery = stats?.subjectMastery?.find((m: any) => m.subject === sub.key);
            const correct = mastery?.totalCorrect ?? 0;
            const total = mastery?.totalAnswered ?? 0;
            const pct = total > 0 ? Math.round((correct / total) * 100) : 0;
            return (
              <div key={sub.key} className="flex items-center gap-3">
                <span className="text-base w-6">{sub.emoji}</span>
                <span className="text-white/70 text-xs w-16">{sub.label}</span>
                <div className="flex-1 bg-white/10 rounded-full h-2">
                  <div
                    className={`h-2 rounded-full transition-all duration-500 ${pct >= 80 ? 'bg-green-500' : pct >= 50 ? 'bg-yellow-500' : 'bg-red-500'}`}
                    style={{ width: `${pct}%` }}
                  />
                </div>
                <span className="text-white/50 text-xs w-12 text-right">{correct}/{total}</span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Today's activity */}
      <div className="bg-white/5 border border-white/10 rounded-2xl p-3 text-center">
        <p className="text-white/40 text-xs">Questions answered today: <span className="text-yellow-400 font-black">{stats?.answeredToday ?? 0}</span></p>
      </div>
    </div>
  );
}

// ─── Kid Stats Panel ──────────────────────────────────────────────────────────
function KidStatsPanel({ kidName }: { kidName: string }) {
  const credits = parseInt(localStorage.getItem("kc_credits") || "0", 10);
  const cards = (() => { try { return JSON.parse(localStorage.getItem("kc_cards") || "[]").length; } catch { return 0; } })();
  const streak = parseInt(localStorage.getItem("kc_streak") || "0", 10);
  const referrals = parseInt(localStorage.getItem("kc_referrals") || "0", 10);
  const lastLogin = localStorage.getItem("kc_last_login") || "Never";
  const wishListCount = (() => { try { return JSON.parse(localStorage.getItem("kc_wishlist") || "[]").length; } catch { return 0; } })();

  const LEVELS = [
    { cardsNeeded: 3, referralsNeeded: 0, label: "Freshman" },
    { cardsNeeded: 8, referralsNeeded: 1, label: "Sophomore" },
    { cardsNeeded: 15, referralsNeeded: 2, label: "Junior" },
    { cardsNeeded: 25, referralsNeeded: 3, label: "Senior" },
    { cardsNeeded: 35, referralsNeeded: 4, label: "Rookie Pro" },
    { cardsNeeded: 45, referralsNeeded: 5, label: "1st Year Pro" },
    { cardsNeeded: 55, referralsNeeded: 6, label: "2nd Year Pro" },
    { cardsNeeded: 65, referralsNeeded: 7, label: "3rd Year Pro" },
    { cardsNeeded: 75, referralsNeeded: 8, label: "4th Year Pro" },
    { cardsNeeded: 90, referralsNeeded: 9, label: "5th Year Pro" },
    { cardsNeeded: 105, referralsNeeded: 10, label: "6th Year Pro" },
    { cardsNeeded: 120, referralsNeeded: 11, label: "7th Year Pro" },
    { cardsNeeded: 140, referralsNeeded: 12, label: "8th Year Pro" },
    { cardsNeeded: 160, referralsNeeded: 13, label: "9th Year Pro" },
    { cardsNeeded: 180, referralsNeeded: 14, label: "10th Year Pro" },
    { cardsNeeded: 200, referralsNeeded: 15, label: "Hall of Fame" },
  ];
  const currentLevel = LEVELS.reduce((best, lvl) => {
    if (cards >= lvl.cardsNeeded && referrals >= lvl.referralsNeeded) return lvl;
    return best;
  }, LEVELS[0]);

  return (
    <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
      {[
        { label: "Credits Balance", value: credits.toLocaleString(), icon: "⚡", color: "text-yellow-400", bg: "bg-yellow-400/10 border-yellow-400/20" },
        { label: "Cards Collected", value: cards, icon: "🎴", color: "text-blue-400", bg: "bg-blue-500/10 border-blue-500/20" },
        { label: "Login Streak", value: `${streak} days`, icon: "🔥", color: "text-orange-400", bg: "bg-orange-500/10 border-orange-500/20" },
        { label: "Friends Invited", value: referrals, icon: "👥", color: "text-green-400", bg: "bg-green-500/10 border-green-500/20" },
        { label: "Wish List", value: `${wishListCount}/5 cards`, icon: "❤️", color: "text-pink-400", bg: "bg-pink-500/10 border-pink-500/20" },
        { label: "Current Level", value: currentLevel.label, icon: "🏆", color: "text-purple-400", bg: "bg-purple-500/10 border-purple-500/20" },
      ].map(stat => (
        <div key={stat.label} className={`rounded-2xl p-4 border ${stat.bg} text-center`}>
          <p className={`${stat.color} font-black text-xl leading-none`}>{stat.icon}</p>
          <p className={`${stat.color} font-black text-lg mt-1`}>{stat.value}</p>
          <p className="text-white/40 text-[10px] mt-0.5">{stat.label}</p>
        </div>
      ))}
      <div className="col-span-2 md:col-span-3 bg-white/5 border border-white/10 rounded-2xl p-3 text-center">
        <p className="text-white/40 text-xs">Last active: <span className="text-white/70 font-bold">{lastLogin}</span></p>
      </div>
    </div>
  );
}

// ─── Main Parent Zone Page ────────────────────────────────────────────────────
export default function KidsCornerParent() {
  const [kidName] = useState(() => localStorage.getItem("kc_name") || "");
  const [selectedPkg, setSelectedPkg] = useState<typeof CREDIT_PACKAGES[0] | null>(null);
  const [giftDate, setGiftDate] = useState("");
  const [giftPkg, setGiftPkg] = useState<typeof CREDIT_PACKAGES[0] | null>(null);
  const [awardLog, setAwardLog] = useState<{ reason: string; credits: number; date: string }[]>(() => {
    try { return JSON.parse(localStorage.getItem("kc_parent_awards") || "[]"); } catch { return []; }
  });

  // Read wish list from localStorage (synced by kids corner)
  const wishList: HouseCard[] = (() => {
    try { return JSON.parse(localStorage.getItem("kc_wishlist") || "[]"); } catch { return []; }
  })();

  const buyCredits = trpc.kids.buyCredits.useMutation({
    onSuccess: (data) => {
      if (data?.checkoutUrl) {
        toast.info("Redirecting to secure checkout...");
        window.open(data.checkoutUrl, "_blank");
      }
    },
    onError: () => toast.error("Checkout failed. Please try again."),
  });

  const handleAward = (credits: number, reason: string) => {
    const entry = { reason, credits, date: new Date().toLocaleDateString() };
    const updated = [entry, ...awardLog];
    setAwardLog(updated);
    localStorage.setItem("kc_parent_awards", JSON.stringify(updated));
    const current = parseInt(localStorage.getItem("kc_credits") || "50", 10);
    localStorage.setItem("kc_credits", String(current + credits));
    toast.success(`🏆 ${credits} credits awarded to ${kidName || "your child"} for: ${reason}`);
  };

  const handleScheduleGift = () => {
    if (!giftPkg) { toast.error("Please select a credit package for the gift."); return; }
    if (!giftDate) { toast.error("Please select a delivery date."); return; }
    toast.success(`🎁 Gift scheduled! ${giftPkg.credits} credits will drop at 2:30am on ${giftDate} — ${kidName || "your child"} will wake up to a surprise!`);
    setGiftPkg(null);
    setGiftDate("");
  };

  const referralCode = localStorage.getItem("kc_ref_code") || "";
  const referralSignups: { name: string; date: string; credits: number }[] = (() => {
    try { return JSON.parse(localStorage.getItem("kc_ref_signups") || "[]"); } catch { return []; }
  })();
  const referralLink = referralCode ? `${window.location.origin}/kids-corner?ref=${referralCode}` : "";

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-blue-950 to-slate-950">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-900 via-indigo-900 to-purple-900 border-b border-white/10 px-4 py-4">
        <div className="max-w-4xl mx-auto flex items-center gap-4">
          <Link href="/kids-corner">
            <button className="flex items-center gap-2 text-white/70 hover:text-white text-sm font-bold transition-colors">
              <ArrowLeft className="w-4 h-4" /> Back to Kids Corner
            </button>
          </Link>
          <div className="flex-1 text-center">
            <h1 className="text-white font-black text-2xl" style={{ fontFamily: "Oswald, sans-serif" }}>
              👨‍👩‍👧 PARENT ZONE
            </h1>
            <p className="text-blue-300 text-xs">Your child's account management dashboard</p>
          </div>
          <Badge className="bg-blue-500/20 text-blue-300 border-blue-500/30 text-xs font-bold">PARENTS ONLY</Badge>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 py-8 space-y-2">

        {/* Kid name display */}
        {kidName && (
          <div className="text-center mb-6">
            <p className="text-white/50 text-sm">Managing account for:</p>
            <p className="text-yellow-400 font-black text-3xl" style={{ fontFamily: "Oswald, sans-serif" }}>
              ⭐ {kidName}'s Kids Corner
            </p>
          </div>
        )}

        {/* ── Kid Activity Stats ── */}
        <Section icon="📊" title="ACTIVITY STATS" subtitle="Your child's current progress and balances">
          {kidName ? (
            <KidStatsPanel kidName={kidName} />
          ) : (
            <div className="text-center py-6 bg-yellow-400/10 border border-yellow-400/20 rounded-2xl">
              <p className="text-yellow-400 font-bold">👀 Have your child create their profile first!</p>
              <Link href="/kids-corner">
                <Button className="mt-3 bg-yellow-400 text-black font-black rounded-xl">Go to Kids Corner →</Button>
              </Link>
            </div>
          )}
        </Section>

        {/* ── Learning Stats ── */}
        <Section icon="🧠" title="LEARNING PROGRESS" subtitle="Age-matched educational trivia — math, reading, science, history & sports">
          {kidName ? (
            <LearningStatsPanel kidName={kidName} />
          ) : (
            <div className="text-center py-6 bg-blue-400/10 border border-blue-400/20 rounded-2xl">
              <p className="text-blue-400 font-bold">📚 Learning stats appear after your child plays trivia!</p>
            </div>
          )}
        </Section>

        {/* ── Wish List ── */}
        <Section icon="❤️" title="WISH LIST" subtitle="Cards your child wants — buy the real versions as gifts!">
          <WishListSection kidName={kidName} wishList={wishList} />
        </Section>

        {/* ── Play Time Rules ── */}
        <Section icon="⏱️" title="DAILY PLAY TIME" subtitle="How play time works and how to grant bonus time">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
            <div className="bg-blue-500/10 border border-blue-500/20 rounded-2xl p-4">
              <p className="text-blue-300 font-black text-sm mb-1">📅 Standard Daily Limit</p>
              <p className="text-white font-black text-3xl">1 Hour</p>
              <p className="text-white/50 text-xs mt-1">Every child gets 1 hour of Kids Corner play time per day. Keeps it fun and balanced!</p>
            </div>
            <div className="bg-green-500/10 border border-green-500/20 rounded-2xl p-4">
              <p className="text-green-300 font-black text-sm mb-1">🎁 Bonus Hour (1× per week)</p>
              <p className="text-white font-black text-3xl">+1 Hour</p>
              <p className="text-white/50 text-xs mt-1">Award 1 extra hour per week when your child does something great. Use the reward section below!</p>
            </div>
          </div>
          <div className="bg-yellow-400/10 border border-yellow-400/20 rounded-2xl p-4">
            <p className="text-yellow-400 font-bold text-sm mb-2">💡 How to Grant Extra Play Time</p>
            <p className="text-white/70 text-xs leading-relaxed">
              Select a chore, good deed, or achievement below and award credits. Each award also grants a <strong className="text-yellow-400">bonus play session</strong> that week. 
              Your child can also earn hours by completing in-game challenges and weekly trivia streaks!
            </p>
          </div>
        </Section>

        {/* ── Reward Good Behavior ── */}
        <Section icon="🏆" title="REWARD GREAT BEHAVIOR" subtitle="Award bonus credits for chores, good deeds, and academic achievements">
          <RewardDropdown title="Chores" emoji="🧹" items={CHORES} onAward={handleAward} />
          <RewardDropdown title="Good Deeds" emoji="❤️" items={GOOD_DEEDS} onAward={handleAward} />
          <RewardDropdown title="Academic Achievements" emoji="📚" items={ACADEMIC} onAward={handleAward} />
          <RewardDropdown title="Special Events" emoji="🎉" items={SPECIAL_EVENTS} onAward={handleAward} />

          {awardLog.length > 0 && (
            <div className="mt-4">
              <p className="text-white/50 text-xs font-bold mb-2">📋 Recent Awards</p>
              <div className="space-y-1 max-h-40 overflow-y-auto">
                {awardLog.slice(0, 10).map((a, i) => (
                  <div key={i} className="flex items-center justify-between bg-black/20 rounded-xl px-3 py-2">
                    <span className="text-white/80 text-xs">{a.reason}</span>
                    <span className="text-white/40 text-[10px]">{a.date}</span>
                    <span className="text-yellow-400 font-black text-xs">+{a.credits}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </Section>

        {/* ── Buy Credits ── */}
        <Section icon="💳" title="ADD CREDITS" subtitle="100 credits = $1.00 — give your child more card pulls!">
          <div className="grid grid-cols-2 md:grid-cols-3 gap-3 mb-4">
            {CREDIT_PACKAGES.map(pkg => (
              <button
                key={pkg.id}
                onClick={() => setSelectedPkg(pkg)}
                className={`relative rounded-2xl p-4 border-2 text-center transition-all ${
                  selectedPkg?.id === pkg.id
                    ? "border-yellow-400 bg-yellow-400/10"
                    : "border-white/10 bg-white/5 hover:bg-white/10"
                }`}
              >
                {pkg.popular && (
                  <span className="absolute -top-2 left-1/2 -translate-x-1/2 bg-yellow-400 text-black text-[10px] font-black px-2 py-0.5 rounded-full">POPULAR</span>
                )}
                <div className="text-white font-black text-sm">{pkg.label}</div>
                <div className="text-yellow-400 font-black text-xl">{pkg.credits.toLocaleString()}</div>
                <div className="text-white/50 text-xs">credits</div>
                <div className="text-green-400 font-black text-base mt-1">${pkg.price}.00</div>
              </button>
            ))}
          </div>
          {selectedPkg && (
            <div className="bg-yellow-400/10 border border-yellow-400/30 rounded-2xl p-4 flex items-center justify-between gap-4">
              <div>
                <p className="text-white font-bold text-sm">Selected: {selectedPkg.label}</p>
                <p className="text-white/50 text-xs">{selectedPkg.credits.toLocaleString()} credits for ${selectedPkg.price}.00</p>
              </div>
              <Button
                onClick={() => {
                  if (!kidName) { toast.error("Please have your child set up their profile first!"); return; }
                  buyCredits.mutate({ creditAmount: selectedPkg.credits, kidName, origin: window.location.origin });
                }}
                disabled={buyCredits.isPending}
                className="bg-gradient-to-r from-yellow-400 to-orange-500 text-black font-black px-6 rounded-xl"
              >
                {buyCredits.isPending ? "Loading..." : `Buy for $${selectedPkg.price}`}
              </Button>
            </div>
          )}
          <p className="text-white/30 text-[10px] mt-3 text-center">
            Secure checkout via Stripe. Credits are added instantly after payment.
          </p>
        </Section>

        {/* ── Holiday Gift Scheduler ── */}
        <Section icon="🎁" title="HOLIDAY CREDIT GIFT" subtitle="Schedule a credit drop for a special occasion — they'll wake up to a surprise!">
          <p className="text-white/60 text-sm mb-4">
            Pick a date and a credit package. We'll add the credits to {kidName ? `${kidName}'s` : "your child's"} account at <strong className="text-yellow-400">2:30am</strong> on that day — so they wake up with more credits waiting for them!
          </p>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-3 mb-4">
            {CREDIT_PACKAGES.map(pkg => (
              <button
                key={pkg.id}
                onClick={() => setGiftPkg(pkg)}
                className={`rounded-2xl p-3 border-2 text-center transition-all ${
                  giftPkg?.id === pkg.id
                    ? "border-pink-400 bg-pink-400/10"
                    : "border-white/10 bg-white/5 hover:bg-white/10"
                }`}
              >
                <div className="text-white font-bold text-xs">{pkg.label}</div>
                <div className="text-yellow-400 font-black text-lg">{pkg.credits.toLocaleString()}</div>
                <div className="text-green-400 font-bold text-sm">${pkg.price}</div>
              </button>
            ))}
          </div>
          <div className="flex flex-col md:flex-row gap-3">
            <div className="flex-1">
              <label className="text-white/50 text-xs font-bold block mb-1">🗓️ Gift Delivery Date</label>
              <input
                type="date"
                value={giftDate}
                onChange={e => setGiftDate(e.target.value)}
                min={new Date().toISOString().slice(0, 10)}
                className="w-full bg-white/10 border border-white/20 rounded-xl px-4 py-2 text-white text-sm focus:outline-none focus:border-yellow-400"
              />
            </div>
            <div className="flex items-end">
              <Button
                onClick={handleScheduleGift}
                disabled={!giftPkg || !giftDate}
                className="bg-gradient-to-r from-pink-500 to-purple-600 text-white font-black px-6 rounded-xl"
              >
                🎁 Schedule Gift
              </Button>
            </div>
          </div>
          {giftPkg && giftDate && (
            <div className="mt-3 bg-pink-500/10 border border-pink-500/20 rounded-2xl p-3 text-center">
              <p className="text-pink-300 font-bold text-sm">
                🎁 {giftPkg.credits.toLocaleString()} credits will be gifted to {kidName || "your child"} on <span className="text-yellow-400">{new Date(giftDate + "T12:00:00").toLocaleDateString("en-US", { weekday: "long", month: "long", day: "numeric" })}</span> at 2:30am!
              </p>
            </div>
          )}
        </Section>

        {/* ── Referral Tracking ── */}
        <Section icon="🔗" title="REFERRAL TRACKING" subtitle="Share your child's unique link — both accounts earn credits when friends join!">
          {referralCode ? (
            <>
              <div className="bg-black/30 border border-white/10 rounded-2xl p-4 mb-4">
                <p className="text-white/50 text-xs font-bold mb-2">📎 {kidName ? `${kidName}'s` : "Your Child's"} Referral Link</p>
                <div className="flex items-center gap-2">
                  <code className="flex-1 bg-white/5 border border-white/10 rounded-xl px-3 py-2 text-green-400 text-xs font-mono break-all">{referralLink}</code>
                  <button
                    onClick={() => { navigator.clipboard.writeText(referralLink); toast.success("Link copied!"); }}
                    className="bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold px-3 py-2 rounded-xl whitespace-nowrap"
                  >
                    Copy
                  </button>
                </div>
              </div>
              <div className="grid grid-cols-3 gap-3 mb-4">
                <div className="bg-black/20 rounded-2xl p-3 text-center">
                  <div className="text-yellow-400 font-black text-2xl">{referralSignups.length}</div>
                  <div className="text-white/50 text-[10px]">Friends Joined</div>
                </div>
                <div className="bg-black/20 rounded-2xl p-3 text-center">
                  <div className="text-green-400 font-black text-2xl">{referralSignups.length * 50}</div>
                  <div className="text-white/50 text-[10px]">Credits Earned</div>
                </div>
                <div className="bg-black/20 rounded-2xl p-3 text-center">
                  <div className="text-blue-400 font-black text-2xl">{referralSignups.length}</div>
                  <div className="text-white/50 text-[10px]">Level Progress</div>
                </div>
              </div>
              <div className="flex flex-wrap gap-2">
                <a href={`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(referralLink)}`} target="_blank" rel="noreferrer"
                  className="bg-blue-700 hover:bg-blue-600 text-white font-bold text-xs py-2 px-4 rounded-xl">📱 Facebook</a>
                <a href={`https://twitter.com/intent/tweet?text=${encodeURIComponent(`My kid is building their sports card collection FREE on SportCardsOnline.com! Join here: ${referralLink}`)}`} target="_blank" rel="noreferrer"
                  className="bg-black hover:bg-gray-900 text-white font-bold text-xs py-2 px-4 rounded-xl border border-white/20">✖ Twitter/X</a>
                <a href={`sms:?body=${encodeURIComponent(`Hey! My kid is building their sports card collection FREE on SportCardsOnline.com Kids Corner! Join here: ${referralLink}`)}`}
                  className="bg-green-600 hover:bg-green-500 text-white font-bold text-xs py-2 px-4 rounded-xl">💬 Text</a>
                <a href={`mailto:?subject=Join Kids Corner on SportCardsOnline.com!&body=${encodeURIComponent(`Hey! My kid is building their sports card collection FREE on SportCardsOnline.com Kids Corner! Join here: ${referralLink}`)}`}
                  className="bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs py-2 px-4 rounded-xl">📧 Email</a>
              </div>
            </>
          ) : (
            <div className="bg-yellow-400/10 border border-yellow-400/20 rounded-2xl p-4 text-center">
              <p className="text-yellow-400 font-bold text-sm">👀 Have your child create their Kids Corner profile first!</p>
              <p className="text-white/50 text-xs mt-1">Once they set up their profile, a unique referral link will appear here.</p>
              <Link href="/kids-corner">
                <Button className="mt-3 bg-yellow-400 text-black font-black rounded-xl">Go to Kids Corner →</Button>
              </Link>
            </div>
          )}
        </Section>

        {/* ── How It All Works ── */}
        <Section icon="📖" title="HOW KIDS CORNER WORKS" subtitle="Everything you need to know as a parent">
          <div className="space-y-3 text-sm text-white/70 leading-relaxed">
            <div className="bg-white/5 rounded-2xl p-4">
              <p className="text-white font-bold mb-1">🎮 What is Kids Corner?</p>
              <p>Kids Corner is a free, educational sports card collecting experience for children ages 6 and up. Kids build their own online card collection, play trivia, spin the Sports Spin Wheel, browse the Card Showcase, and progress through levels — all while learning about sports history, math, and strategy.</p>
            </div>
            <div className="bg-white/5 rounded-2xl p-4">
              <p className="text-white font-bold mb-1">💰 How do credits work?</p>
              <p>Credits are the in-game currency. Kids earn them for free by logging in daily, answering trivia, spinning the wheel, and completing weekly challenges. Credits are used to pull cards from the Card Shop. You can also purchase credits ($1 = 100 credits) or award them for good behavior.</p>
            </div>
            <div className="bg-white/5 rounded-2xl p-4">
              <p className="text-white font-bold mb-1">❤️ What is the Wish List?</p>
              <p>Kids can browse the Card Showcase (100 real sports cards with photos) and add up to 5 cards to their wish list. You can see their wish list right here in the Parent Zone, with links to buy the real physical cards on eBay as gifts!</p>
            </div>
            <div className="bg-white/5 rounded-2xl p-4">
              <p className="text-white font-bold mb-1">🏆 What is the Hall of Fame?</p>
              <p>The ultimate goal! Kids progress from Freshman through college levels, get drafted, advance through 10 Pro years, and reach the Hall of Fame. The first kid to reach the Hall of Fame wins a <span className="text-yellow-400 font-bold">FREE Caitlin Clark Rookie Card</span>!</p>
            </div>
          </div>
        </Section>

        {/* Back to Kids Corner */}
        <div className="text-center pb-6">
          <Link href="/kids-corner">
            <Button className="bg-gradient-to-r from-yellow-400 to-orange-500 text-black font-black text-base px-8 py-4 rounded-2xl shadow-xl">
              ← Back to Kids Corner
            </Button>
          </Link>
        </div>
      </div>

      <Footer />
    </div>
  );
}
