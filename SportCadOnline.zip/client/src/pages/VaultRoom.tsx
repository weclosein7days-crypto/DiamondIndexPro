import { useState, useEffect } from "react";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import NavBar from "@/components/NavBar";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Link, useLocation } from "wouter";
import { Vault, AlertTriangle, ChevronRight, Package, Coins, ShieldCheck, TrendingUp, ArrowRight, Star, Lock, Truck, RefreshCw, CheckCircle2 } from "lucide-react";
import { toast } from "sonner";

// ─── Vault Status Labels ─────────────────────────────────────────────────────
const STATUS_LABELS: Record<string, { label: string; color: string }> = {
  vaulted:       { label: "In Vault",       color: "bg-green-500/20 text-green-400 border-green-500/30" },
  vault_listed:  { label: "Listed",         color: "bg-blue-500/20 text-blue-400 border-blue-500/30" },
  vault_auction: { label: "In Auction",     color: "bg-purple-500/20 text-purple-400 border-purple-500/30" },
  vault_sold:    { label: "Sold",           color: "bg-gray-500/20 text-gray-400 border-gray-500/30" },
  vault_shipped: { label: "Shipped to You", color: "bg-yellow-500/20 text-yellow-400 border-yellow-500/30" },
};

// ─── Vault Rules Modal ────────────────────────────────────────────────────────
function VaultRulesModal({ open, onClose }: { open: boolean; onClose: () => void }) {
  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="bg-[#0d1117] border border-yellow-500/30 text-white max-w-2xl max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl font-black text-yellow-400 flex items-center gap-2">
            <Vault className="w-6 h-6" /> How the SCO Vault Works
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6 mt-2">
          {/* What is the Vault */}
          <div className="bg-yellow-500/5 border border-yellow-500/20 rounded-xl p-4">
            <h3 className="text-yellow-400 font-bold text-lg mb-2">🏦 What Is the Vault?</h3>
            <p className="text-white/70 text-sm leading-relaxed">
              The SCO Vault is your personal secure storage at our facility. When you vault a card, it physically lives
              at our location — but it shows up in your digital vault with its full value. Think of it as a safety
              deposit box for your sports cards.
            </p>
          </div>

          {/* How to add cards */}
          <div>
            <h3 className="text-white font-bold text-base mb-3 flex items-center gap-2">
              <Package className="w-4 h-4 text-yellow-400" /> How to Add Cards to Your Vault
            </h3>
            <div className="space-y-3">
              {[
                {
                  step: "1",
                  title: "Buy a Card",
                  desc: "Purchase any card from the SCO marketplace or arena. At checkout, select \"Vault It\" instead of shipping to your address. The card goes directly into your vault — no shipping fee.",
                },
                {
                  step: "2",
                  title: "Win a Card in the Game Room",
                  desc: "When you win a physical card prize in the Game Room, you can choose to vault it instead of having it shipped. Select \"Send to Vault\" on the prize claim screen.",
                },
                {
                  step: "3",
                  title: "Win or Complete a Trade",
                  desc: "Cards received in a trade can be vaulted at the time of the trade agreement. Select \"Vault\" as your delivery preference in the trade form.",
                },
                {
                  step: "4",
                  title: "Ship a Card to Us",
                  desc: "Already own a card? Ship it to our facility (179 Chapman Dr, Granville, OH). Once received and verified, it will appear in your vault within 2–3 business days.",
                },
              ].map((item) => (
                <div key={item.step} className="flex gap-3 bg-white/5 border border-white/10 rounded-lg p-3">
                  <div className="w-7 h-7 rounded-full bg-yellow-500 text-black font-black text-sm flex items-center justify-center flex-shrink-0">
                    {item.step}
                  </div>
                  <div>
                    <div className="text-white font-semibold text-sm">{item.title}</div>
                    <div className="text-white/50 text-xs mt-0.5 leading-relaxed">{item.desc}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* What you can do with vaulted cards */}
          <div>
            <h3 className="text-white font-bold text-base mb-3 flex items-center gap-2">
              <Coins className="w-4 h-4 text-yellow-400" /> What You Can Do With Vaulted Cards
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {[
                {
                  icon: "💰",
                  title: "Exchange for Credits",
                  desc: "Sell your vaulted card back to SCO for credits instantly. A 10% vault fee applies. Credits can be used in the Game Room or to buy more cards.",
                },
                {
                  icon: "🏪",
                  title: "List on Marketplace",
                  desc: "List your vaulted card for sale on the SCO marketplace. SCO-vaulted cards get a special badge showing buyers it's verified and guaranteed.",
                },
                {
                  icon: "🔨",
                  title: "Send to Auction",
                  desc: "Put your card in a 3-day auction with a minimum bid and optional Buy Now price. Auctions relist automatically until sold.",
                },
                {
                  icon: "📦",
                  title: "Ship to Yourself",
                  desc: "Request your card be shipped to your address anytime. Standard shipping rates apply. Your card leaves the vault and arrives at your door.",
                },
              ].map((item) => (
                <div key={item.title} className="bg-white/5 border border-white/10 rounded-lg p-3">
                  <div className="text-xl mb-1">{item.icon}</div>
                  <div className="text-white font-semibold text-sm">{item.title}</div>
                  <div className="text-white/50 text-xs mt-1 leading-relaxed">{item.desc}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Guarantee */}
          <div className="bg-green-500/5 border border-green-500/20 rounded-xl p-4">
            <h3 className="text-green-400 font-bold text-base mb-2 flex items-center gap-2">
              <ShieldCheck className="w-4 h-4" /> SCO Vault Guarantee
            </h3>
            <p className="text-white/70 text-sm leading-relaxed">
              Every card in the SCO Vault is physically verified, stored securely, and insured. We guarantee the
              authenticity and condition of all vaulted cards. If a card is lost or damaged while in our care,
              we will replace it at full market value.
            </p>
          </div>

          <Button
            className="w-full bg-yellow-500 hover:bg-yellow-400 text-black font-black"
            onClick={onClose}
          >
            Got It — Let's Go!
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

// ─── Trade-In Confirmation Modal ──────────────────────────────────────────────
function TradeInModal({
  card,
  open,
  onClose,
  onConfirm,
  isPending,
}: {
  card: any;
  open: boolean;
  onClose: () => void;
  onConfirm: () => void;
  isPending: boolean;
}) {
  const estimatedValue = card?.estimatedValueHigh
    ? Number(card.estimatedValueHigh)
    : card?.estimatedValueLow
    ? Number(card.estimatedValueLow)
    : 0;
  const fee = estimatedValue * 0.10;
  const creditsAwarded = Math.floor(estimatedValue * 0.90);

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="bg-[#0d1117] border border-yellow-500/30 text-white max-w-md">
        <DialogHeader>
          <DialogTitle className="text-xl font-black text-yellow-400 flex items-center gap-2">
            <RefreshCw className="w-5 h-5" /> Trade In for Credits
          </DialogTitle>
          <DialogDescription className="text-white/50 text-sm mt-1">
            Exchange this card for SCO credits. This action cannot be undone.
          </DialogDescription>
        </DialogHeader>

        {card && (
          <div className="space-y-4 mt-2">
            {/* Card preview */}
            <div className="flex items-center gap-3 bg-white/5 border border-white/10 rounded-xl p-3">
              <div className="w-12 h-16 rounded-lg overflow-hidden bg-white/10 flex-shrink-0 border border-white/10">
                {card.frontImageUrl ? (
                  <img src={card.frontImageUrl} alt={card.playerName} className="w-full h-full object-cover" />
                ) : (
                  <div className="w-full h-full flex items-center justify-center text-white/20 text-xs text-center p-1">No Image</div>
                )}
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-white font-bold text-sm truncate">{card.playerName || card.cardTitle || "Unknown Card"}</div>
                <div className="text-white/50 text-xs truncate mt-0.5">
                  {[card.year, card.setName, card.cardNumber && `#${card.cardNumber}`].filter(Boolean).join(" · ")}
                </div>
                {card.overallGrade && (
                  <div className="text-yellow-400 text-xs font-bold mt-1">
                    {card.gradingCompany || "SCG"} {card.overallGrade}
                  </div>
                )}
              </div>
            </div>

            {/* Credit breakdown */}
            <div className="bg-black/40 border border-yellow-500/20 rounded-xl p-4 space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-white/60">Estimated Card Value</span>
                <span className="text-white font-semibold">${estimatedValue.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-white/60">Vault Fee (10%)</span>
                <span className="text-red-400 font-semibold">−${fee.toFixed(2)}</span>
              </div>
              <div className="border-t border-white/10 pt-2 flex justify-between">
                <span className="text-yellow-400 font-bold">Credits You Receive</span>
                <span className="text-yellow-400 font-black text-lg">{creditsAwarded} credits</span>
              </div>
            </div>

            {/* Warning */}
            <div className="flex items-start gap-2 bg-red-500/5 border border-red-500/20 rounded-lg p-3">
              <AlertTriangle className="w-4 h-4 text-red-400 flex-shrink-0 mt-0.5" />
              <p className="text-red-300/80 text-xs leading-relaxed">
                Once traded in, this card will be listed in a 3-day SCO auction. This action is permanent and cannot be reversed.
              </p>
            </div>

            {/* Buttons */}
            <div className="flex gap-3 pt-1">
              <Button
                variant="outline"
                className="flex-1 border-white/20 text-white/60 hover:bg-white/5"
                onClick={onClose}
                disabled={isPending}
              >
                Cancel
              </Button>
              <Button
                className="flex-1 bg-yellow-500 hover:bg-yellow-400 text-black font-black"
                onClick={onConfirm}
                disabled={isPending || estimatedValue === 0}
              >
                {isPending ? (
                  <><RefreshCw className="w-4 h-4 mr-2 animate-spin" /> Processing...</>
                ) : (
                  <><CheckCircle2 className="w-4 h-4 mr-2" /> Confirm Trade-In</>
                )}
              </Button>
            </div>
            {estimatedValue === 0 && (
              <p className="text-red-400 text-xs text-center">This card has no estimated value on file. Trade-in is unavailable.</p>
            )}
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}

// ─── Vault Card Row ───────────────────────────────────────────────────────────
function VaultCardRow({ card, onTradeIn }: { card: any; onTradeIn: (card: any) => void }) {
  const statusInfo = STATUS_LABELS[card.listingStatus] ?? { label: card.listingStatus, color: "bg-white/10 text-white/60" };
  const estimatedValue = card.estimatedValueHigh
    ? `$${Number(card.estimatedValueHigh).toFixed(2)}`
    : card.estimatedValueLow
    ? `$${Number(card.estimatedValueLow).toFixed(2)}`
    : "—";

  const canTradeIn = card.listingStatus === "vaulted";

  return (
    <div className="flex items-center gap-4 bg-white/5 hover:bg-white/8 border border-white/10 rounded-xl p-4 transition-colors">
      {/* Card image */}
      <div className="w-14 h-20 rounded-lg overflow-hidden bg-white/10 flex-shrink-0 border border-white/10">
        {card.frontImageUrl ? (
          <img src={card.frontImageUrl} alt={card.playerName} className="w-full h-full object-cover" />
        ) : (
          <div className="w-full h-full flex items-center justify-center text-white/20 text-xs text-center p-1">No Image</div>
        )}
      </div>

      {/* Card info */}
      <div className="flex-1 min-w-0">
        <div className="text-white font-bold text-sm truncate">{card.playerName || card.cardTitle || "Unknown Card"}</div>
        <div className="text-white/50 text-xs truncate mt-0.5">
          {[card.year, card.setName, card.cardNumber && `#${card.cardNumber}`].filter(Boolean).join(" · ")}
        </div>
        {card.overallGrade && (
          <div className="text-yellow-400 text-xs font-bold mt-1">
            {card.gradingCompany || "SCG"} {card.overallGrade}
          </div>
        )}
      </div>

      {/* Value */}
      <div className="text-right flex-shrink-0">
        <div className="text-green-400 font-bold text-sm">{estimatedValue}</div>
        <div className="text-white/30 text-xs">est. value</div>
      </div>

      {/* Status */}
      <Badge className={`text-xs border flex-shrink-0 ${statusInfo.color}`}>
        {statusInfo.label}
      </Badge>

      {/* Trade In Button */}
      {canTradeIn && (
        <Button
          size="sm"
          className="bg-yellow-500 hover:bg-yellow-400 text-black font-black text-xs px-3 py-1.5 h-auto flex-shrink-0 flex items-center gap-1.5 shadow-lg shadow-yellow-500/20"
          onClick={() => onTradeIn(card)}
        >
          <RefreshCw className="w-3.5 h-3.5" />
          Trade In for Credits
        </Button>
      )}
    </div>
  );
}

// ─── Main Vault Page ──────────────────────────────────────────────────────────
export default function VaultRoom() {
  const { isAuthenticated } = useAuth();
  const [, navigate] = useLocation();
  const [showRules, setShowRules] = useState(false);
  const [tradeInCard, setTradeInCard] = useState<any>(null);

  const utils = trpc.useUtils();
  const { data: vaultCards, isLoading } = trpc.vault.myVault.useQuery(undefined, {
    enabled: isAuthenticated,
  });

  const sellForCredits = trpc.vault.sellForCredits.useMutation({
    onSuccess: (data) => {
      toast.success(`🎉 Trade-in complete! You received ${data.creditsAwarded} credits.`);
      setTradeInCard(null);
      utils.vault.myVault.invalidate();
      utils.credits.myAccount.invalidate();
    },
    onError: (err) => {
      toast.error(err.message || "Trade-in failed. Please try again.");
    },
  });

  // Flash the warning sign
  const [flashOn, setFlashOn] = useState(true);
  useEffect(() => {
    if (!isAuthenticated || (vaultCards && vaultCards.length > 0)) return;
    const interval = setInterval(() => setFlashOn(p => !p), 600);
    return () => clearInterval(interval);
  }, [isAuthenticated, vaultCards]);

  // Redirect to login if not authenticated
  useEffect(() => {
    if (!isAuthenticated) {
      window.location.href = getLoginUrl("/vault");
    }
  }, [isAuthenticated]);

  if (!isAuthenticated) return null;

  // Calculate totals
  const totalCards = vaultCards?.length ?? 0;
  const totalValue = vaultCards?.reduce((sum, c) => sum + (c.estimatedValueHigh ? Number(c.estimatedValueHigh) : 0), 0) ?? 0;
  const activeVaulted = vaultCards?.filter(c => c.listingStatus === "vaulted").length ?? 0;

  const isEmpty = !isLoading && totalCards === 0;

  return (
    <div className="min-h-screen bg-[#0a0e14] text-white flex flex-col">
      <NavBar />

      {/* Hero Header */}
      <div className="relative overflow-hidden bg-gradient-to-b from-[#0d1117] to-[#0a0e14] border-b border-yellow-500/20">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,rgba(234,179,8,0.08),transparent_70%)]" />
        <div className="relative max-w-5xl mx-auto px-4 py-8">
          <div className="flex items-center gap-4 mb-4">
            {/* Vault SVG icon */}
            <div className="w-16 h-16 rounded-2xl bg-yellow-500/10 border border-yellow-500/30 flex items-center justify-center">
              <svg viewBox="0 0 140 170" className="w-10 h-10" fill="none">
                <defs>
                  <linearGradient id="vg2" x1="0" y1="0" x2="1" y2="1">
                    <stop offset="0%" stopColor="#c8922a"/>
                    <stop offset="100%" stopColor="#7a4f10"/>
                  </linearGradient>
                </defs>
                <rect x="10" y="10" width="120" height="150" rx="4" fill="url(#vg2)" stroke="#c8922a" strokeWidth="2.5"/>
                <rect x="18" y="18" width="104" height="134" rx="3" fill="none" stroke="#e8b84b" strokeWidth="1.5" opacity="0.5"/>
                <circle cx="70" cy="80" r="28" fill="none" stroke="#e8b84b" strokeWidth="3"/>
                <circle cx="70" cy="80" r="18" fill="none" stroke="#e8b84b" strokeWidth="2"/>
                <circle cx="70" cy="80" r="5" fill="#e8b84b"/>
                <line x1="70" y1="52" x2="70" y2="62" stroke="#e8b84b" strokeWidth="2.5" strokeLinecap="round"/>
                <line x1="70" y1="98" x2="70" y2="108" stroke="#e8b84b" strokeWidth="2.5" strokeLinecap="round"/>
                <line x1="42" y1="80" x2="52" y2="80" stroke="#e8b84b" strokeWidth="2.5" strokeLinecap="round"/>
                <line x1="88" y1="80" x2="98" y2="80" stroke="#e8b84b" strokeWidth="2.5" strokeLinecap="round"/>
                <rect x="118" y="65" width="12" height="30" rx="3" fill="#c8922a" stroke="#e8b84b" strokeWidth="1.5"/>
                <circle cx="124" cy="80" r="4" fill="#e8b84b"/>
                <line x1="30" y1="140" x2="110" y2="140" stroke="#e8b84b" strokeWidth="1.5" opacity="0.4"/>
              </svg>
            </div>
            <div>
              <h1 className="text-4xl font-black text-white" style={{ fontFamily: "Oswald, sans-serif", letterSpacing: "0.05em" }}>
                MY VAULT
              </h1>
              <p className="text-yellow-400/70 text-sm mt-1">Your cards, securely stored at SCO headquarters</p>
            </div>
          </div>

          {/* Digital Counter — only show if has cards */}
          {totalCards > 0 && (
            <div className="grid grid-cols-3 gap-4 mt-6">
              <div className="bg-black/40 border border-yellow-500/20 rounded-xl p-4 text-center">
                <div className="text-4xl font-black text-yellow-400 tabular-nums" style={{ fontFamily: "Oswald, sans-serif" }}>
                  {totalCards.toString().padStart(2, "0")}
                </div>
                <div className="text-white/50 text-xs mt-1 uppercase tracking-wide">Cards in Vault</div>
              </div>
              <div className="bg-black/40 border border-green-500/20 rounded-xl p-4 text-center">
                <div className="text-4xl font-black text-green-400 tabular-nums" style={{ fontFamily: "Oswald, sans-serif" }}>
                  ${totalValue.toFixed(0)}
                </div>
                <div className="text-white/50 text-xs mt-1 uppercase tracking-wide">Total Value</div>
              </div>
              <div className="bg-black/40 border border-blue-500/20 rounded-xl p-4 text-center">
                <div className="text-4xl font-black text-blue-400 tabular-nums" style={{ fontFamily: "Oswald, sans-serif" }}>
                  {activeVaulted.toString().padStart(2, "0")}
                </div>
                <div className="text-white/50 text-xs mt-1 uppercase tracking-wide">Available</div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 max-w-5xl mx-auto w-full px-4 py-8">

        {/* Empty State — Flashing Warning */}
        {isEmpty && (
          <div className="flex flex-col items-center justify-center py-16 gap-6">
            {/* Flashing danger sign */}
            <div className={`transition-opacity duration-300 ${flashOn ? "opacity-100" : "opacity-20"}`}>
              <div className="flex items-center gap-3 bg-red-500/10 border-2 border-red-500 rounded-2xl px-8 py-5">
                <AlertTriangle className="w-10 h-10 text-red-500 flex-shrink-0" />
                <div>
                  <div className="text-red-400 font-black text-2xl tracking-wide" style={{ fontFamily: "Oswald, sans-serif" }}>
                    ⚠️ WARNING
                  </div>
                  <div className="text-red-300/80 text-sm mt-0.5">You do not have any cards in your vault.</div>
                </div>
              </div>
            </div>

            {/* CTA */}
            <div className="text-center max-w-md">
              <p className="text-white/60 text-sm leading-relaxed mb-6">
                Your vault is empty. The SCO Vault lets you store cards at our secure facility and access their
                value as credits anytime — without shipping fees.
              </p>
              <Button
                className="bg-yellow-500 hover:bg-yellow-400 text-black font-black text-base px-8 py-3 h-auto rounded-xl"
                onClick={() => setShowRules(true)}
              >
                <Vault className="w-5 h-5 mr-2" />
                CLICK TO LEARN HOW TO ADD TO YOUR VAULT
              </Button>
            </div>

            {/* Quick benefits */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 w-full max-w-2xl mt-4">
              {[
                { icon: <ShieldCheck className="w-5 h-5 text-green-400" />, title: "Fully Insured", desc: "Every card is verified and insured at full market value" },
                { icon: <Coins className="w-5 h-5 text-yellow-400" />, title: "Instant Credits", desc: "Exchange any vaulted card for credits anytime (10% fee)" },
                { icon: <Truck className="w-5 h-5 text-blue-400" />, title: "Ship Anytime", desc: "Request your card shipped to you whenever you want" },
              ].map((b) => (
                <div key={b.title} className="bg-white/5 border border-white/10 rounded-xl p-4 text-center">
                  <div className="flex justify-center mb-2">{b.icon}</div>
                  <div className="text-white font-semibold text-sm">{b.title}</div>
                  <div className="text-white/40 text-xs mt-1">{b.desc}</div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Loading */}
        {isLoading && (
          <div className="flex items-center justify-center py-20">
            <div className="w-8 h-8 border-2 border-yellow-500/30 border-t-yellow-500 rounded-full animate-spin" />
          </div>
        )}

        {/* Vault Cards List */}
        {!isLoading && totalCards > 0 && (
          <div className="space-y-4">
            {/* Action buttons */}
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-white font-bold text-lg">Your Vaulted Cards</h2>
              <Button
                variant="outline"
                size="sm"
                className="border-yellow-500/30 text-yellow-400 hover:bg-yellow-500/10"
                onClick={() => setShowRules(true)}
              >
                <Star className="w-3.5 h-3.5 mr-1.5" /> Vault Rules
              </Button>
            </div>

            {/* Credits promo banner */}
            <div className="bg-gradient-to-r from-yellow-500/10 to-amber-500/5 border border-yellow-500/30 rounded-xl p-4 flex items-center gap-4 mb-6">
              <Coins className="w-8 h-8 text-yellow-400 flex-shrink-0" />
              <div className="flex-1">
                <div className="text-yellow-400 font-bold text-sm">💡 Turn Your Cards Into Credits</div>
                <div className="text-white/60 text-xs mt-0.5">
                  Exchange any vaulted card for credits instantly — just a 10% vault fee. Use credits in the Game Room or to buy more cards.
                </div>
              </div>
              <Link href="/credits">
                <Button size="sm" className="bg-yellow-500 hover:bg-yellow-400 text-black font-bold flex-shrink-0">
                  Get Credits <ArrowRight className="w-3.5 h-3.5 ml-1" />
                </Button>
              </Link>
            </div>

            {/* Card list */}
            <div className="space-y-3">
              {vaultCards!.map((card) => (
                <VaultCardRow key={card.id} card={card} onTradeIn={setTradeInCard} />
              ))}
            </div>

            {/* Bottom CTA */}
            <div className="text-center pt-8 pb-4">
              <p className="text-white/30 text-xs mb-3">Want to add more cards to your vault?</p>
              <div className="flex justify-center gap-3">
                <Link href="/collection">
                  <Button variant="outline" size="sm" className="border-white/20 text-white/60 hover:bg-white/5">
                    Browse Cards <ChevronRight className="w-3.5 h-3.5 ml-1" />
                  </Button>
                </Link>
                <Button
                  variant="outline"
                  size="sm"
                  className="border-yellow-500/30 text-yellow-400 hover:bg-yellow-500/10"
                  onClick={() => setShowRules(true)}
                >
                  How to Add Cards
                </Button>
              </div>
            </div>
          </div>
        )}
      </div>

      <Footer />

      {/* Vault Rules Modal */}
      <VaultRulesModal open={showRules} onClose={() => setShowRules(false)} />

      {/* Trade-In Confirmation Modal */}
      <TradeInModal
        card={tradeInCard}
        open={!!tradeInCard}
        onClose={() => setTradeInCard(null)}
        onConfirm={() => {
          if (tradeInCard) {
            sellForCredits.mutate({ collectionId: tradeInCard.id });
          }
        }}
        isPending={sellForCredits.isPending}
      />
    </div>
  );
}
