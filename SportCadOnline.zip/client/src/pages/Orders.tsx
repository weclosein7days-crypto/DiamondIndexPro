import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "sonner";
import {
  Package, ShoppingCart, Truck, CheckCircle, Clock,
  XCircle, DollarSign, Shield, AlertTriangle
} from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";

const REASON_LABELS: Record<string, string> = {
  item_not_received:     "Item Not Received",
  item_not_as_described: "Item Not as Described",
  damaged_item:          "Item Arrived Damaged",
  wrong_item:            "Wrong Item Sent",
  other:                 "Other",
};

function ReportProblemModal({ order, open, onClose, onSuccess }: {
  order: any; open: boolean; onClose: () => void; onSuccess: () => void;
}) {
  const [reason, setReason] = useState<string>("");
  const [description, setDescription] = useState("");
  const openDispute = trpc.disputes.openDispute.useMutation({
    onSuccess: () => {
      toast.success("Dispute opened. Our team will review your case within 1-2 business days.");
      onSuccess(); onClose();
    },
    onError: (err) => toast.error(err.message),
  });
  const handleSubmit = () => {
    if (!reason) { toast.error("Please select a reason"); return; }
    if (description.trim().length < 10) { toast.error("Please describe the issue (at least 10 characters)"); return; }
    openDispute.mutate({ orderId: order.id, reason: reason as any, description: description.trim() });
  };
  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="bg-[#0d1f3c] border border-white/10 text-white max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-white">
            <AlertTriangle className="w-5 h-5 text-red-400" /> Report a Problem
          </DialogTitle>
          <DialogDescription className="text-white/50 text-sm">
            Order #{order.id} — {order.cardTitle}
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4 pt-2">
          <div className="bg-blue-500/10 border border-blue-500/20 rounded-lg p-3 text-xs text-blue-300 flex gap-2">
            <Shield className="w-4 h-4 flex-shrink-0 mt-0.5" />
            <span>Your payment is protected by SCO Escrow. We will investigate and resolve your case fairly.</span>
          </div>
          <div className="space-y-1.5">
            <Label className="text-white/70 text-sm">What's the problem?</Label>
            <Select value={reason} onValueChange={setReason}>
              <SelectTrigger className="bg-white/5 border-white/10 text-white">
                <SelectValue placeholder="Select a reason..." />
              </SelectTrigger>
              <SelectContent className="bg-[#0d1f3c] border-white/10">
                {Object.entries(REASON_LABELS).map(([val, label]) => (
                  <SelectItem key={val} value={val} className="text-white hover:bg-white/10">{label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1.5">
            <Label className="text-white/70 text-sm">Describe the issue</Label>
            <Textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Please provide as much detail as possible — what happened, when, and what you expected..."
              className="bg-white/5 border-white/10 text-white placeholder:text-white/30 min-h-[100px] resize-none"
              maxLength={2000}
            />
            <p className="text-white/30 text-xs text-right">{description.length}/2000</p>
          </div>
          <div className="flex gap-2 pt-1">
            <Button variant="outline" onClick={onClose} className="flex-1 border-white/10 text-white/70 hover:bg-white/5">Cancel</Button>
            <Button onClick={handleSubmit} disabled={openDispute.isPending} className="flex-1 bg-red-600 hover:bg-red-700 text-white">
              {openDispute.isPending ? "Submitting..." : "Submit Dispute"}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

// --- Status helpers ------------------------------------------------------------
const STATUS: Record<string, { label: string; color: string; icon: any }> = {
  pending:   { label: "Pending Payment",  color: "bg-yellow-500/20 text-yellow-400 border-yellow-500/30",  icon: Clock },
  paid:      { label: "Paid — Awaiting Shipment", color: "bg-blue-500/20 text-blue-400 border-blue-500/30", icon: DollarSign },
  shipped:   { label: "Shipped",          color: "bg-purple-500/20 text-purple-400 border-purple-500/30", icon: Truck },
  delivered: { label: "Delivered",        color: "bg-green-500/20 text-green-400 border-green-500/30",    icon: CheckCircle },
  cancelled: { label: "Cancelled",        color: "bg-red-500/20 text-red-400 border-red-500/30",          icon: XCircle },
  refunded:  { label: "Refunded",         color: "bg-gray-500/20 text-gray-400 border-gray-500/30",       icon: XCircle },
};

// --- Single order card ---------------------------------------------------------
function OrderCard({ order, isSeller, onTrackingAdded }: {
  order: any;
  isSeller: boolean;
  onTrackingAdded: () => void;
}) {
  const [tracking, setTracking] = useState("");
  const [showDispute, setShowDispute] = useState(false);
  const canDispute = !isSeller && ["paid", "label_created", "shipped", "delivered"].includes(order.status);
  const addTracking = trpc.orders.addTracking.useMutation({
    onSuccess: () => { toast.success("Tracking added! Buyer notified."); setTracking(""); onTrackingAdded(); },
    onError: (e) => toast.error(e.message),
  });

  const s = STATUS[order.status] ?? STATUS.pending;
  const Icon = s.icon;
  const total = parseFloat(order.totalAmount ?? order.price ?? "0").toFixed(2);

  return (
    <div className="bg-[#0d1f3c] border border-white/10 rounded-xl p-4 hover:border-white/20 transition-all">
      <div className="flex items-start gap-4">
        {/* Card thumbnail */}
        <div className="w-12 h-[67px] rounded bg-white/10 flex-shrink-0 overflow-hidden">
          {order.cardImageUrl ? (
            <img src={order.cardImageUrl} alt={order.cardTitle} className="w-full h-full object-contain" loading="lazy" decoding="async" />
          ) : (
            <div className="w-full h-full flex items-center justify-center text-white/20 text-xl">🃏</div>
          )}
        </div>

        {/* Order info */}
        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between gap-2 mb-2">
            <div>
              <p className="font-semibold text-white text-sm truncate">{order.cardTitle ?? `Order #${order.id}`}</p>
              <p className="text-xs text-white/50">
                {isSeller
                  ? `Buyer: ${order.buyerName ?? order.buyerEmail}`
                  : `Seller: ${order.sellerStoreName ?? order.sellerEmail}`}
              </p>
              <p className="text-xs text-white/30">{new Date(order.createdAt).toLocaleDateString()}</p>
            </div>
            <div className="text-right flex-shrink-0">
              <p className="font-bold text-green-400 text-sm">${total}</p>
              <Badge className={`text-xs border mt-1 ${s.color}`}>
                <Icon className="w-2.5 h-2.5 mr-1 inline" />{s.label}
              </Badge>
            </div>
          </div>

          {/* Tracking info */}
          {order.trackingNumber && (
            <div className="bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-xs mb-2 flex items-center gap-2">
              <Truck className="w-3 h-3 text-purple-400 flex-shrink-0" />
              <span className="text-white/60">Tracking:</span>
              <span className="font-mono text-white">{order.trackingNumber}</span>
              {order.shippingMethod && (
                <span className="text-white/40">({order.shippingMethod.replace(/_/g, " ")})</span>
              )}
            </div>
          )}

          {/* Seller: add tracking */}
          {isSeller && order.status === "paid" && !order.trackingNumber && (
            <div className="flex gap-2 mt-2">
              <Input
                value={tracking}
                onChange={e => setTracking(e.target.value)}
                placeholder="Enter tracking number..."
                className="h-8 text-xs bg-white/5 border-white/10 text-white placeholder:text-white/30 flex-1"
              />
              <Button
                size="sm"
                onClick={() => addTracking.mutate({ orderId: order.id, trackingNumber: tracking })}
                disabled={!tracking || addTracking.isPending}
                className="h-8 text-xs bg-purple-600 hover:bg-purple-700"
              >
                <Truck className="w-3 h-3 mr-1" /> Mark Shipped
              </Button>
            </div>
          )}

          {/* Buyer: escrow note */}
          {!isSeller && order.status === "shipped" && (
            <div className="flex items-center gap-2 mt-2 text-xs text-white/40">
              <Shield className="w-3 h-3 text-green-400" />
              <span>Funds held in escrow — released to seller 3 days after delivery.</span>
            </div>
          )}

          {/* Buyer: Report a Problem */}
          {canDispute && (
            <div className="pt-2 mt-2 border-t border-white/5">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowDispute(true)}
                className="text-red-400 hover:text-red-300 hover:bg-red-500/10 text-xs h-7 px-2"
              >
                <AlertTriangle className="w-3 h-3 mr-1" />
                Report a Problem
              </Button>
            </div>
          )}

          {/* Disputed notice */}
          {order.status === "disputed" && (
            <div className="bg-red-500/10 border border-red-500/20 rounded-lg p-2 mt-2 text-xs text-red-300 flex items-center gap-2">
              <AlertTriangle className="w-3 h-3 flex-shrink-0" />
              <span>A dispute is open on this order. Our team is reviewing your case.</span>
            </div>
          )}
        </div>
      </div>

      {showDispute && (
        <ReportProblemModal
          order={order}
          open={showDispute}
          onClose={() => setShowDispute(false)}
          onSuccess={onTrackingAdded}
        />
      )}
    </div>
  );
}

// --- Main page -----------------------------------------------------------------
export default function Orders() {
  const { isAuthenticated } = useAuth();
  const { data: buyerOrders, refetch: refetchBuyer } = trpc.orders.myBuyerOrders.useQuery(undefined, { enabled: isAuthenticated });
  const { data: sellerOrders, refetch: refetchSeller } = trpc.orders.mySellerOrders.useQuery(undefined, { enabled: isAuthenticated });

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-[#0a1628] flex items-center justify-center">
        <div className="text-center space-y-4">
          <Package className="w-16 h-16 text-white/20 mx-auto" />
          <h2 className="text-2xl font-bold text-white">Sign In to View Orders</h2>
          <a href={getLoginUrl()} className="inline-block bg-[#C41E3A] hover:bg-[#a01830] text-white px-6 py-2 rounded-lg font-medium transition-colors">Sign In</a>
        </div>
      </div>
    );
  }

  const pendingBuyer = (buyerOrders ?? []).filter((o: any) => ["pending", "paid", "shipped"].includes(o.status)).length;
  const pendingSeller = (sellerOrders ?? []).filter((o: any) => o.status === "paid" && !o.trackingNumber).length;
  const disputedBuyer = (buyerOrders ?? []).filter((o: any) => o.status === "disputed").length;

  return (
    <div className="min-h-screen bg-[#0a1628] pb-20">
      {/* Header */}
      <div className="bg-[#0d1f3c] border-b border-white/10 py-4">
        <div className="max-w-4xl mx-auto px-4">
          <h1 className="text-2xl font-bold text-white flex items-center gap-2" style={{ fontFamily: "Oswald, sans-serif" }}>
            <Package className="w-6 h-6 text-[#C41E3A]" /> Orders
          </h1>
          <p className="text-white/50 text-sm">Track your purchases and manage your sales</p>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 py-6">
        {/* Escrow banner */}
        <div className="bg-green-500/10 border border-green-500/20 rounded-xl p-3 mb-6 flex items-center gap-3">
          <Shield className="w-5 h-5 text-green-400 flex-shrink-0" />
          <div className="text-xs text-green-400">
            <strong>SCO Escrow Protection:</strong> Payments are held securely until you confirm delivery. Funds auto-release 3 days after the carrier marks your package delivered.
          </div>
        </div>

        <Tabs defaultValue="buying">
          <TabsList className="bg-white/5 border border-white/10 mb-4">
            <TabsTrigger value="buying" className="data-[state=active]:bg-[#C41E3A] data-[state=active]:text-white text-white/60">
              Buying ({buyerOrders?.length ?? 0})
              {pendingBuyer > 0 && (
                <span className="ml-1 w-4 h-4 bg-yellow-500 text-black rounded-full text-xs flex items-center justify-center font-bold">{pendingBuyer}</span>
              )}
              {disputedBuyer > 0 && (
                <span className="ml-1 w-4 h-4 bg-red-500 text-white rounded-full text-xs flex items-center justify-center font-bold">{disputedBuyer}</span>
              )}
            </TabsTrigger>
            <TabsTrigger value="selling" className="data-[state=active]:bg-[#C41E3A] data-[state=active]:text-white text-white/60">
              Selling ({sellerOrders?.length ?? 0})
              {pendingSeller > 0 && (
                <span className="ml-1 w-4 h-4 bg-orange-500 text-black rounded-full text-xs flex items-center justify-center font-bold">{pendingSeller}</span>
              )}
            </TabsTrigger>
          </TabsList>

          <TabsContent value="buying">
            {!buyerOrders || buyerOrders.length === 0 ? (
              <div className="text-center py-16 text-white/30">
                <ShoppingCart className="w-12 h-12 mx-auto mb-3 text-white/10" />
                <p>No purchases yet.</p>
                <a href="/" className="text-[#C41E3A] hover:underline text-sm mt-1 block">Browse the marketplace →</a>
              </div>
            ) : (
              <div className="space-y-3">
                {buyerOrders.map((o: any) => (
                  <OrderCard key={o.id} order={o} isSeller={false} onTrackingAdded={refetchBuyer} />
                ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="selling">
            {!sellerOrders || sellerOrders.length === 0 ? (
              <div className="text-center py-16 text-white/30">
                <Package className="w-12 h-12 mx-auto mb-3 text-white/10" />
                <p>No sales yet.</p>
                <a href="/collection" className="text-[#C41E3A] hover:underline text-sm mt-1 block">List cards from your collection →</a>
              </div>
            ) : (
              <div className="space-y-3">
                {sellerOrders.map((o: any) => (
                  <OrderCard key={o.id} order={o} isSeller={true} onTrackingAdded={refetchSeller} />
                ))}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
