import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Award, ShoppingCart, Gavel, Trash2, Search, Copy, Coins, Camera, AlertCircle,
  CheckCircle2, Star, Zap, Crown, Trophy, CheckCircle, Upload, Plus, ImagePlus, Download,
  Tag, Printer, X, ChevronLeft, ChevronRight, Check, Eye, BarChart2,
  Package, Shield, Truck, DollarSign, XCircle, Heart, Palette,
  Users, Gift, TrendingUp, Share2, Twitter, Facebook, ExternalLink
} from "lucide-react";
import { useState, useRef } from "react";
import { LABEL_BACKGROUNDS, LABEL_BORDER_COLORS, buildPrintPage, type LabelBackground, type LabelBorderColor } from "@/components/SlabLabel";
import { toast } from "sonner";
import { Link } from "wouter";
import StockView from "@/components/StockView";
import { CardTimeline } from "@/components/CardTimeline";
import { useFavoriteIds, FavoriteButton } from "@/components/FavoriteButton";
import { SlabFrame } from "@/components/SlabFrame";

// ============================================================================
// INLINE ORDER CARD (used inside My Collection Orders tab)
// ============================================================================
const ORDER_STATUS: Record<string, { label: string; color: string; Icon: any }> = {
  pending:   { label: "Pending Payment",        color: "bg-yellow-500/20 text-yellow-400 border-yellow-500/30", Icon: DollarSign },
  paid:      { label: "Paid — Awaiting Shipment", color: "bg-blue-500/20 text-blue-400 border-blue-500/30",    Icon: DollarSign },
  shipped:   { label: "Shipped",                 color: "bg-purple-500/20 text-purple-400 border-purple-500/30", Icon: Truck },
  delivered: { label: "Delivered",               color: "bg-green-500/20 text-green-400 border-green-500/30",  Icon: CheckCircle },
  cancelled: { label: "Cancelled",               color: "bg-red-500/20 text-red-400 border-red-500/30",        Icon: XCircle },
  refunded:  { label: "Refunded",                color: "bg-gray-500/20 text-gray-400 border-gray-500/30",     Icon: XCircle },
};

function OrderCardInline({ order, isSeller, onTrackingAdded }: { order: any; isSeller: boolean; onTrackingAdded: () => void }) {
  const [tracking, setTracking] = useState("");
  const addTracking = trpc.orders.addTracking.useMutation({
    onSuccess: () => { toast.success("Tracking added!"); setTracking(""); onTrackingAdded(); },
    onError: (e) => toast.error(e.message),
  });
  const s = ORDER_STATUS[order.status] ?? ORDER_STATUS.pending;
  const { Icon } = s;
  const total = parseFloat(order.totalAmount ?? order.price ?? "0").toFixed(2);
  return (
    <div className="bg-[#0d1f3c] border border-white/10 rounded-xl p-4 hover:border-white/20 transition-all">
      <div className="flex items-start gap-4">
        <div className="w-10 h-[56px] rounded bg-white/10 flex-shrink-0 overflow-hidden">
          {order.cardImageUrl
            ? <img src={order.cardImageUrl} alt={order.cardTitle} className="w-full h-full object-contain" loading="lazy" decoding="async" />
            : <div className="w-full h-full flex items-center justify-center text-white/20 text-lg">🃏</div>}
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between gap-2 mb-1">
            <p className="font-semibold text-white text-sm truncate">{order.cardTitle ?? `Order #${order.id}`}</p>
            <p className="text-green-400 font-bold text-sm shrink-0">${total}</p>
          </div>
          <p className="text-xs text-white/50 mb-2">
            {isSeller ? `Buyer: ${order.buyerName ?? order.buyerEmail}` : `Seller: ${order.sellerName ?? order.sellerEmail}`}
            {order.createdAt ? ` · ${new Date(order.createdAt).toLocaleDateString()}` : ""}
          </p>
          <span className={`inline-flex items-center gap-1 text-[10px] px-2 py-0.5 rounded-full border font-medium ${s.color}`}>
            <Icon className="w-3 h-3" />{s.label}
          </span>
          {isSeller && order.status === "paid" && !order.trackingNumber && (
            <div className="mt-2 flex gap-2">
              <Input
                placeholder="Enter tracking number"
                value={tracking}
                onChange={(e) => setTracking(e.target.value)}
                className="h-7 text-xs"
              />
              <Button size="sm" className="h-7 text-xs bg-[#c41e3a] hover:bg-[#a01830] text-white px-3"
                onClick={() => addTracking.mutate({ orderId: order.id, trackingNumber: tracking })}
                disabled={!tracking || addTracking.isPending}>
                {addTracking.isPending ? "..." : "Add"}
              </Button>
            </div>
          )}
          {order.trackingNumber && (
            <p className="text-xs text-white/40 mt-1">Tracking: <span className="font-mono text-white/60">{order.trackingNumber}</span></p>
          )}
        </div>
      </div>
    </div>
  );
}

function OrdersTabContent({ buyerOrders, sellerOrders, refetchBuyer, refetchSeller }: {
  buyerOrders: any[] | undefined;
  sellerOrders: any[] | undefined;
  refetchBuyer: () => void;
  refetchSeller: () => void;
}) {
  const [orderSide, setOrderSide] = useState<"buying" | "selling">("buying");
  return (
    <div className="pb-10">
      <div className="bg-green-500/10 border border-green-500/20 rounded-xl p-3 mb-5 flex items-center gap-3">
        <Shield className="w-5 h-5 text-green-400 shrink-0" />
        <p className="text-xs text-green-400"><strong>SCO Escrow Protection:</strong> Payments are held securely until you confirm delivery. Funds auto-release 3 days after the carrier marks your package delivered.</p>
      </div>
      <div className="flex gap-2 mb-4">
        <button
          onClick={() => setOrderSide("buying")}
          className={`px-4 py-1.5 rounded-lg text-sm font-semibold transition-colors ${orderSide === "buying" ? "bg-[#c41e3a] text-white" : "bg-white/5 text-white/60 hover:bg-white/10"}`}>
          Buying ({buyerOrders?.length ?? 0})
        </button>
        <button
          onClick={() => setOrderSide("selling")}
          className={`px-4 py-1.5 rounded-lg text-sm font-semibold transition-colors ${orderSide === "selling" ? "bg-[#c41e3a] text-white" : "bg-white/5 text-white/60 hover:bg-white/10"}`}>
          Selling ({sellerOrders?.length ?? 0})
        </button>
      </div>
      {orderSide === "buying" && (
        !buyerOrders || buyerOrders.length === 0 ? (
          <div className="text-center py-16 text-white/30">
            <ShoppingCart className="w-12 h-12 mx-auto mb-3 text-white/10" />
            <p>No purchases yet.</p>
            <a href="/" className="text-[#c41e3a] hover:underline text-sm mt-1 block">Browse the marketplace →</a>
          </div>
        ) : (
          <div className="space-y-3">
            {buyerOrders.map((o: any) => <OrderCardInline key={o.id} order={o} isSeller={false} onTrackingAdded={refetchBuyer} />)}
          </div>
        )
      )}
      {orderSide === "selling" && (
        !sellerOrders || sellerOrders.length === 0 ? (
          <div className="text-center py-16 text-white/30">
            <Package className="w-12 h-12 mx-auto mb-3 text-white/10" />
            <p>No sales yet.</p>
          </div>
        ) : (
          <div className="space-y-3">
            {sellerOrders.map((o: any) => <OrderCardInline key={o.id} order={o} isSeller={true} onTrackingAdded={refetchSeller} />)}
          </div>
        )
      )}
    </div>
  );
}

const STATUS_CONFIG: Record<string, { label: string; color: string; icon: string | null }> = {
  auction: { label: "In Auction", color: "bg-orange-500 text-white", icon: "🔨" },
  marketplace: { label: "Listed", color: "bg-green-600 text-white", icon: "🏷️" },
  available: { label: "Available", color: "", icon: null }, // no badge for unlisted cards
};

const SPORTS = ["baseball", "basketball", "football", "hockey", "soccer", "other"] as const;

// Legacy kept for any remaining references
const LABEL_COLORS = LABEL_BACKGROUNDS.map(b => ({ value: b.value, label: b.label, hex: b.url }));

// ============================================================================
// COMP REFERENCES SECTION (shown inside CardDetailModal)
// ============================================================================
function CompRefsSection({ itemId }: { itemId: number }) {
  const { data: refs, refetch } = trpc.comps.getForItem.useQuery({ collectionItemId: itemId });
  const deleteRef = trpc.comps.delete.useMutation({ onSuccess: () => { toast.success("Comp removed"); refetch(); } });

  if (!refs || refs.length === 0) {
    return (
      <div className="bg-white/5 rounded-lg p-3 text-center">
        <p className="text-xs text-white/30">No saved comps yet</p>
        <p className="text-[10px] text-white/20 mt-0.5">Use the Comps panel to add eBay sale references</p>
      </div>
    );
  }

  return (
    <div className="bg-white/5 rounded-lg overflow-hidden">
      <div className="px-3 py-2 border-b border-white/10 flex items-center justify-between">
        <p className="text-xs font-semibold text-white/60 uppercase tracking-wide">Saved Comps ({refs.length})</p>
      </div>
      <div className="divide-y divide-white/5 max-h-40 overflow-y-auto">
        {refs.map((ref) => (
          <div key={ref.id} className="flex items-center gap-2 px-3 py-1.5">
            <div className="flex-1 min-w-0">
              <p className="text-xs text-white/70 truncate">{ref.title || "eBay sale"}</p>
              <p className="text-[10px] text-white/30">
                {ref.platform} · {ref.saleDate ? new Date(ref.saleDate).toLocaleDateString() : ""}
                {ref.condition ? ` · ${ref.condition}` : ""}
              </p>
            </div>
            <p className="text-sm font-bold text-green-400 shrink-0">${parseFloat(ref.salePrice).toFixed(2)}</p>
            <button
              onClick={() => deleteRef.mutate({ id: ref.id })}
              className="text-white/20 hover:text-red-400 transition-colors shrink-0"
              title="Remove comp">
              <X className="w-3 h-3" />
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}

// ============================================================================
// UPLOAD CARD MODAL
// ============================================================================
function UploadCardModal({ onSuccess }: { onSuccess: () => void }) {
  const [open, setOpen] = useState(false);
  const [frontPreview, setFrontPreview] = useState<string | null>(null);
  const [backPreview, setBackPreview] = useState<string | null>(null);
  const [frontBase64, setFrontBase64] = useState<string | null>(null);
  const [backBase64, setBackBase64] = useState<string | null>(null);
  const [frontFilename, setFrontFilename] = useState("front.jpg");
  const [backFilename, setBackFilename] = useState("back.jpg");
  const [form, setForm] = useState({
    cardTitle: "", playerName: "", year: "", setName: "", cardNumber: "",
    sport: "baseball" as typeof SPORTS[number], description: "", price: "",
  });
  const [uploading, setUploading] = useState(false);
  const frontRef = useRef<HTMLInputElement>(null);
  const backRef = useRef<HTMLInputElement>(null);

  const uploadImage = trpc.cards.uploadImage.useMutation();
  const addToCollection = trpc.collection.add.useMutation();

  const handleFile = (file: File, side: "front" | "back") => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const dataUrl = e.target?.result as string;
      const base64 = dataUrl.split(",")[1];
      if (side === "front") {
        setFrontPreview(dataUrl); setFrontBase64(base64); setFrontFilename(file.name);
      } else {
        setBackPreview(dataUrl); setBackBase64(base64); setBackFilename(file.name);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleSubmit = async () => {
    if (!form.cardTitle || !form.playerName) { toast.error("Card title and player name are required"); return; }
    setUploading(true);
    try {
      let frontUrl: string | undefined;
      let backUrl: string | undefined;
      if (frontBase64) {
        const res = await uploadImage.mutateAsync({ base64: frontBase64, filename: frontFilename, mimeType: "image/jpeg" });
        frontUrl = res.url;
      }
      if (backBase64) {
        const res = await uploadImage.mutateAsync({ base64: backBase64, filename: backFilename, mimeType: "image/jpeg" });
        backUrl = res.url;
      }
      await addToCollection.mutateAsync({
        cardTitle: form.cardTitle, playerName: form.playerName,
        year: form.year || undefined, setName: form.setName || undefined,
        cardNumber: form.cardNumber || undefined, sport: form.sport,
        frontImageUrl: frontUrl, backImageUrl: backUrl,
        description: form.description || undefined,
      });
      toast.success("Card added to your collection!");
      setOpen(false);
      setFrontPreview(null); setBackPreview(null); setFrontBase64(null); setBackBase64(null);
      setForm({ cardTitle: "", playerName: "", year: "", setName: "", cardNumber: "", sport: "baseball", description: "", price: "" });
      onSuccess();
    } catch (e: any) {
      toast.error(e.message || "Failed to add card");
    } finally {
      setUploading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button className="bg-blue-600 hover:bg-blue-700 text-white gap-2">
          <Upload className="w-4 h-4" />Upload Card
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Upload className="w-5 h-5 text-blue-500" />Upload Card to Collection
          </DialogTitle>
        </DialogHeader>
        <div className="space-y-4 pt-2">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label className="text-xs font-medium mb-1.5 block">Front Photo</Label>
              <div className="aspect-[3/4] border-2 border-dashed border-border rounded-lg flex flex-col items-center justify-center cursor-pointer hover:border-blue-500/50 hover:bg-blue-500/5 transition-all overflow-hidden"
                onClick={() => frontRef.current?.click()}>
                {frontPreview ? <img src={frontPreview} alt="Front" className="w-full h-full object-cover" /> : (
                  <><ImagePlus className="w-8 h-8 text-muted-foreground/40 mb-1" /><span className="text-xs text-muted-foreground">Click to upload</span></>
                )}
              </div>
              <input ref={frontRef} type="file" accept="image/*" className="hidden" onChange={(e) => e.target.files?.[0] && handleFile(e.target.files[0], "front")} />
            </div>
            <div>
              <Label className="text-xs font-medium mb-1.5 block">Back Photo</Label>
              <div className="aspect-[3/4] border-2 border-dashed border-border rounded-lg flex flex-col items-center justify-center cursor-pointer hover:border-blue-500/50 hover:bg-blue-500/5 transition-all overflow-hidden"
                onClick={() => backRef.current?.click()}>
                {backPreview ? <img src={backPreview} alt="Back" className="w-full h-full object-cover" /> : (
                  <><ImagePlus className="w-8 h-8 text-muted-foreground/40 mb-1" /><span className="text-xs text-muted-foreground">Click to upload</span></>
                )}
              </div>
              <input ref={backRef} type="file" accept="image/*" className="hidden" onChange={(e) => e.target.files?.[0] && handleFile(e.target.files[0], "back")} />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="col-span-2">
              <Label className="text-xs font-medium mb-1 block">Card Title *</Label>
              <Input placeholder="e.g. 2003 Topps Chrome LeBron James RC #111" value={form.cardTitle} onChange={(e) => setForm(f => ({ ...f, cardTitle: e.target.value }))} />
            </div>
            <div className="col-span-2">
              <Label className="text-xs font-medium mb-1 block">Player Name *</Label>
              <Input placeholder="e.g. LeBron James" value={form.playerName} onChange={(e) => setForm(f => ({ ...f, playerName: e.target.value }))} />
            </div>
            <div>
              <Label className="text-xs font-medium mb-1 block">Year</Label>
              <Input placeholder="2003" value={form.year} onChange={(e) => setForm(f => ({ ...f, year: e.target.value }))} />
            </div>
            <div>
              <Label className="text-xs font-medium mb-1 block">Card #</Label>
              <Input placeholder="#111" value={form.cardNumber} onChange={(e) => setForm(f => ({ ...f, cardNumber: e.target.value }))} />
            </div>
            <div className="col-span-2">
              <Label className="text-xs font-medium mb-1 block">Set Name</Label>
              <Input placeholder="e.g. Topps Chrome" value={form.setName} onChange={(e) => setForm(f => ({ ...f, setName: e.target.value }))} />
            </div>
            <div className="col-span-2">
              <Label className="text-xs font-medium mb-1 block">Sport</Label>
              <Select value={form.sport} onValueChange={(v: any) => setForm(f => ({ ...f, sport: v }))}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {SPORTS.map(s => <SelectItem key={s} value={s}>{s.charAt(0).toUpperCase() + s.slice(1)}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="col-span-2">
              <Label className="text-xs font-medium mb-1 block">Notes (optional)</Label>
              <Textarea placeholder="Any notes about this card..." value={form.description} onChange={(e) => setForm(f => ({ ...f, description: e.target.value }))} rows={2} />
            </div>
          </div>
          <div className="bg-blue-500/10 border border-blue-500/20 rounded-lg p-3 text-xs text-blue-300">
            <strong>Note:</strong> This card will be added to your private Collection. You can then choose to list it in the Arena, run an Auction, or keep it for trading.
          </div>
          <Button className="w-full bg-blue-600 hover:bg-blue-700 text-white" onClick={handleSubmit} disabled={uploading}>
            {uploading ? "Uploading..." : "Add to My Collection"}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

// ============================================================================
// EBAY IMPORT MODAL
// ============================================================================
// Step types for the eBay import flow
type ImportStep = "search" | "preview" | "importing" | "done";
interface ImportResult { title: string; success: boolean; error?: string; }

function EbayImportModal({ onSuccess }: { onSuccess: () => void }) {
  const [open, setOpen] = useState(false);
  const [step, setStep] = useState<ImportStep>("search");
  const [username, setUsername] = useState("");
  const [selected, setSelected] = useState<Set<string>>(new Set());
  // Progress tracking
  const [progress, setProgress] = useState(0);
  const [progressTotal, setProgressTotal] = useState(0);
  const [progressLabel, setProgressLabel] = useState("");
  const [results, setResults] = useState<ImportResult[]>([]);

  const listingsQuery = trpc.ebay.fetchSellerListings.useQuery(
    { sellerUsername: username },
    { enabled: false }
  );
  const importSingle = trpc.ebay.importSingle.useMutation();

  const handleClose = (isOpen: boolean) => {
    if (!isOpen && step !== "importing") {
      setOpen(false);
      // Reset state when closing
      setTimeout(() => {
        setStep("search");
        setUsername("");
        setSelected(new Set());
        setProgress(0);
        setProgressTotal(0);
        setResults([]);
      }, 300);
    } else if (isOpen) {
      setOpen(true);
    }
  };

  const handleSearch = async () => {
    if (!username.trim()) { toast.error("Enter an eBay username"); return; }
    setSelected(new Set());
    const result = await listingsQuery.refetch();
    if (result.data?.items?.length) {
      // Auto-select all by default
      setSelected(new Set(result.data.items.map((l: any) => l.ebayItemId as string)));
      setStep("preview");
    } else if (!result.isFetching) {
      setStep("preview"); // show "no results" state
    }
  };

  const toggleSelect = (itemId: string) => {
    setSelected(prev => {
      const next = new Set(prev);
      next.has(itemId) ? next.delete(itemId) : next.add(itemId);
      return next;
    });
  };

  const handleImport = async () => {
    const ebayItems = listingsQuery.data?.items || [];
    const toImport = ebayItems.filter((l: any) => selected.has(l.ebayItemId));
    if (toImport.length === 0) { toast.error("Select at least one card"); return; }

    setStep("importing");
    setProgress(0);
    setProgressTotal(toImport.length);
    setResults([]);

    const importResults: ImportResult[] = [];
    for (let i = 0; i < toImport.length; i++) {
      const item = toImport[i];
      setProgressLabel(`Importing "${item.title.slice(0, 40)}${item.title.length > 40 ? '...' : ''}"`);
      try {
        await importSingle.mutateAsync({
          ebayItemId: item.ebayItemId,
          title: item.title,
          price: item.price,
          imageUrl: item.imageUrl,
          condition: item.condition,
          itemUrl: item.itemUrl,
        });
        importResults.push({ title: item.title, success: true });
      } catch (e: any) {
        importResults.push({ title: item.title, success: false, error: e.message || "Failed" });
      }
      setProgress(i + 1);
    }

    setResults(importResults);
    setStep("done");
    onSuccess();
  };

  const listings = listingsQuery.data?.items || [];
  const successCount = results.filter(r => r.success).length;
  const failCount = results.filter(r => !r.success).length;
  const progressPct = progressTotal > 0 ? Math.round((progress / progressTotal) * 100) : 0;

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogTrigger asChild>
        <Button variant="outline" className="gap-2 border-orange-500/50 text-orange-400 hover:bg-orange-500/10">
          <Download className="w-4 h-4" />eBay Import
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Download className="w-5 h-5 text-orange-400" />
            {step === "search" && "Import from eBay"}
            {step === "preview" && `Review ${listings.length} Listings`}
            {step === "importing" && "Importing Cards..."}
            {step === "done" && "Import Complete"}
          </DialogTitle>
          {step === "preview" && (
            <p className="text-sm text-muted-foreground mt-1">
              Review the cards below. Uncheck any you don’t want, then click Import.
            </p>
          )}
        </DialogHeader>

        <div className="space-y-4 pt-2">

          {/* STEP 1: Search */}
          {step === "search" && (
            <>
              <div className="flex gap-2">
                <Input
                  placeholder="eBay seller username (e.g. weclose-4)"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && handleSearch()}
                />
                <Button onClick={handleSearch} disabled={listingsQuery.isFetching} className="shrink-0 bg-orange-500 hover:bg-orange-600 text-white">
                  {listingsQuery.isFetching ? "Searching..." : "Search"}
                </Button>
              </div>
              {listingsQuery.isFetching && (
                <div className="space-y-2">
                  {Array.from({ length: 4 }).map((_, i) => (
                    <div key={i} className="h-16 bg-muted rounded-lg animate-pulse" />
                  ))}
                </div>
              )}
              {!listingsQuery.isFetching && (
                <div className="text-center py-8 text-muted-foreground text-sm">
                  <Download className="w-10 h-10 mx-auto mb-3 text-muted-foreground/30" />
                  Enter your eBay seller username to fetch your active listings.<br />
                  <span className="text-xs mt-1 block">Cards will be imported to your private Collection — not auto-listed.</span>
                </div>
              )}
            </>
          )}

          {/* STEP 2: Preview & Select */}
          {step === "preview" && (
            <>
              {listings.length === 0 ? (
                <div className="text-center py-6 text-muted-foreground text-sm">
                  No active listings found for “{username}”
                  <br />
                  <button className="text-blue-400 hover:underline text-xs mt-2" onClick={() => setStep("search")}>
                    ← Try a different username
                  </button>
                </div>
              ) : (
                <>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">
                      <span className="font-semibold text-foreground">{selected.size}</span> of {listings.length} selected
                    </span>
                    <div className="flex gap-2">
                      <button className="text-xs text-blue-400 hover:underline"
                        onClick={() => setSelected(new Set(listings.map((l: any) => l.ebayItemId as string)))}>
                        Select All
                      </button>
                      <span className="text-muted-foreground text-xs">/</span>
                      <button className="text-xs text-muted-foreground hover:underline"
                        onClick={() => setSelected(new Set())}>
                        Clear
                      </button>
                    </div>
                  </div>

                  <div className="space-y-2 max-h-72 overflow-y-auto pr-1">
                    {listings.map((listing: any) => (
                      <div
                        key={listing.ebayItemId}
                        className={`flex items-center gap-3 p-2.5 rounded-lg border cursor-pointer transition-all ${
                          selected.has(listing.ebayItemId)
                            ? "border-orange-500 bg-orange-500/10"
                            : "border-border hover:border-border/80 opacity-60"
                        }`}
                        onClick={() => toggleSelect(listing.ebayItemId)}>
                        <div className={`w-5 h-5 rounded border-2 flex items-center justify-center shrink-0 transition-colors ${
                          selected.has(listing.ebayItemId) ? "bg-orange-500 border-orange-500" : "border-muted-foreground"
                        }`}>
                          {selected.has(listing.ebayItemId) && <Check className="w-3 h-3 text-white" />}
                        </div>
                        {listing.imageUrl && (
                          <img src={listing.imageUrl} alt={listing.title} className="w-10 h-14 object-contain rounded shadow-sm" loading="lazy" decoding="async" />
                        )}
                        <div className="flex-1 min-w-0">
                          <p className="text-xs font-medium line-clamp-2 leading-snug">{listing.title}</p>
                          <p className="text-xs text-green-500 font-bold mt-0.5">${listing.price}</p>
                          {listing.condition && <p className="text-[10px] text-muted-foreground">{listing.condition}</p>}
                        </div>
                      </div>
                    ))}
                  </div>

                  <div className="flex gap-2 pt-1">
                    <Button variant="outline" className="flex-1" onClick={() => setStep("search")}>
                      ← Back
                    </Button>
                    <Button
                      className="flex-[2] bg-orange-500 hover:bg-orange-600 text-white font-semibold"
                      onClick={handleImport}
                      disabled={selected.size === 0}>
                      Import {selected.size} Card{selected.size !== 1 ? "s" : ""} →
                    </Button>
                  </div>
                </>
              )}
            </>
          )}

          {/* STEP 3: Importing with progress bar */}
          {step === "importing" && (
            <div className="py-4 space-y-5">
              <div className="text-center">
                <div className="text-4xl font-bold text-orange-400 mb-1">{progress}<span className="text-xl text-muted-foreground">/{progressTotal}</span></div>
                <p className="text-sm text-muted-foreground">cards imported</p>
              </div>

              {/* Progress bar */}
              <div className="w-full bg-muted rounded-full h-3 overflow-hidden">
                <div
                  className="h-3 bg-orange-500 rounded-full transition-all duration-300 ease-out"
                  style={{ width: `${progressPct}%` }}
                />
              </div>
              <p className="text-xs text-center text-muted-foreground">{progressPct}% complete</p>

              {/* Current card label */}
              {progressLabel && (
                <div className="bg-muted/50 rounded-lg px-3 py-2 text-xs text-center text-muted-foreground truncate">
                  {progressLabel}
                </div>
              )}

              <p className="text-xs text-center text-muted-foreground/60">Please don’t close this window during import.</p>
            </div>
          )}

          {/* STEP 4: Done / Results Summary */}
          {step === "done" && (
            <div className="py-4 space-y-4">
              <div className="text-center">
                <div className="w-14 h-14 rounded-full bg-green-500/20 flex items-center justify-center mx-auto mb-3">
                  <Check className="w-7 h-7 text-green-500" />
                </div>
                <h3 className="text-lg font-bold">Import Complete!</h3>
                <p className="text-sm text-muted-foreground mt-1">
                  <span className="text-green-500 font-semibold">{successCount} card{successCount !== 1 ? "s" : ""}</span> added to your Collection
                  {failCount > 0 && <>, <span className="text-red-400 font-semibold">{failCount} failed</span></>}
                </p>
              </div>

              {/* Failed items */}
              {failCount > 0 && (
                <div className="bg-red-500/10 border border-red-500/20 rounded-lg p-3 space-y-1">
                  <p className="text-xs font-semibold text-red-400 mb-1">Failed imports:</p>
                  {results.filter(r => !r.success).map((r, i) => (
                    <p key={i} className="text-xs text-muted-foreground line-clamp-1">• {r.title}</p>
                  ))}
                </div>
              )}

              <div className="flex gap-2">
                <Button variant="outline" className="flex-1" onClick={() => handleClose(false)}>
                  Close
                </Button>
                <Button
                  className="flex-1 bg-orange-500 hover:bg-orange-600 text-white"
                  onClick={() => {
                    handleClose(false);
                    // Navigate to collection
                    window.location.href = "/collection";
                  }}>
                  View My Collection →
                </Button>
              </div>
            </div>
          )}

        </div>
      </DialogContent>
    </Dialog>
  );
}

// ============================================================================
// CARD DETAIL POPUP — 6 image slots (2 graded + 4 extra)
// ============================================================================
function CardDetailModal({ item, onClose, onUpdate }: {
  item: any;
  onClose: () => void;
  onUpdate: () => void;
}) {
  const [activeImg, setActiveImg] = useState(0);
  const [extraPreviews, setExtraPreviews] = useState<string[]>(item.extraImageUrls || []);
  const [uploading, setUploading] = useState(false);
  const extraRef = useRef<HTMLInputElement>(null);

  // Zoom / pan state
  const [zoom, setZoom] = useState(1);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState(false);
  const dragStart = useRef<{ mx: number; my: number; px: number; py: number } | null>(null);
  const viewerRef = useRef<HTMLDivElement>(null);
  // Touch pinch state
  const lastPinchDist = useRef<number | null>(null);

  const MIN_ZOOM = 1;
  const MAX_ZOOM = 5;

  const resetZoom = () => { setZoom(1); setPan({ x: 0, y: 0 }); };

  // Reset zoom whenever the active image changes
  const handleSetActiveImg = (idx: number) => { setActiveImg(idx); resetZoom(); };

  // Scroll-to-zoom
  const handleWheel = (e: React.WheelEvent) => {
    e.preventDefault();
    setZoom(z => {
      const next = Math.min(MAX_ZOOM, Math.max(MIN_ZOOM, z - e.deltaY * 0.005));
      if (next === MIN_ZOOM) setPan({ x: 0, y: 0 });
      return next;
    });
  };

  // Mouse drag-to-pan
  const handleMouseDown = (e: React.MouseEvent) => {
    if (zoom <= 1) return;
    e.preventDefault();
    setIsDragging(true);
    dragStart.current = { mx: e.clientX, my: e.clientY, px: pan.x, py: pan.y };
  };
  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging || !dragStart.current) return;
    setPan({
      x: dragStart.current.px + (e.clientX - dragStart.current.mx),
      y: dragStart.current.py + (e.clientY - dragStart.current.my),
    });
  };
  const handleMouseUp = () => { setIsDragging(false); dragStart.current = null; };

  // Double-click to reset
  const handleDoubleClick = () => resetZoom();

  // Touch pinch-to-zoom
  const getTouchDist = (touches: React.TouchList) =>
    Math.hypot(touches[0].clientX - touches[1].clientX, touches[0].clientY - touches[1].clientY);

  const handleTouchStart = (e: React.TouchEvent) => {
    if (e.touches.length === 2) {
      lastPinchDist.current = getTouchDist(e.touches);
    } else if (e.touches.length === 1 && zoom > 1) {
      dragStart.current = { mx: e.touches[0].clientX, my: e.touches[0].clientY, px: pan.x, py: pan.y };
    }
  };
  const handleTouchMove = (e: React.TouchEvent) => {
    if (e.touches.length === 2 && lastPinchDist.current !== null) {
      e.preventDefault();
      const dist = getTouchDist(e.touches);
      const scale = dist / lastPinchDist.current;
      lastPinchDist.current = dist;
      setZoom(z => Math.min(MAX_ZOOM, Math.max(MIN_ZOOM, z * scale)));
    } else if (e.touches.length === 1 && dragStart.current && zoom > 1) {
      e.preventDefault();
      setPan({
        x: dragStart.current.px + (e.touches[0].clientX - dragStart.current.mx),
        y: dragStart.current.py + (e.touches[0].clientY - dragStart.current.my),
      });
    }
  };
  const handleTouchEnd = () => {
    lastPinchDist.current = null;
    dragStart.current = null;
    if (zoom <= MIN_ZOOM) setPan({ x: 0, y: 0 });
  };

  const uploadImage = trpc.cards.uploadImage.useMutation();
  const updateCollection = trpc.collection.update.useMutation();

  // Label style state (initialized from saved item values)
  const [labelBg, setLabelBg] = useState<LabelBackground>((item.labelBg as LabelBackground) || "black-silk");
  const [labelBorder, setLabelBorder] = useState<LabelBorderColor>((item.labelBorder as LabelBorderColor) || "red");
  const [savingLabel, setSavingLabel] = useState(false);

  const handleSaveLabelStyle = async () => {
    setSavingLabel(true);
    try {
      await updateCollection.mutateAsync({ id: item.id, labelBg: labelBg as any, labelBorder: labelBorder as any });
      toast.success("Label style saved!");
    } catch (e: any) {
      toast.error(e.message || "Failed to save label style");
    } finally {
      setSavingLabel(false);
    }
  };

  const handlePrintSingleCard = () => {
    const w = window.open("", "_blank");
    if (!w) return;
    const labelData = [{
      playerName: item.playerName,
      cardCompany: item.setName?.split(" ")[0] || "",
      year: item.year ?? undefined,
      setName: item.setName ?? undefined,
      cardNumber: item.cardNumber ?? undefined,
      overallGrade: item.overallGrade ? parseFloat(item.overallGrade) : undefined,
      gradeLabel: item.gradeLabel ?? undefined,
      centering: item.centeringScore ?? undefined,
      corners: item.cornersScore ?? undefined,
      edges: item.edgesScore ?? undefined,
      surface: item.surfaceScore ?? undefined,
      certNumber: item.certNumber ?? undefined,
      cardId: item.id,
      background: labelBg,
      borderColor: labelBorder,
    }];
    const html = buildPrintPage(labelData, window.location.origin);
    w.document.write(html);
    w.document.close();
  };

  // All images: front, back, then up to 4 extras
  const allImages = [
    item.frontImageUrl,
    item.backImageUrl,
    ...extraPreviews,
  ].filter(Boolean) as string[];

  const maxExtras = 4;
  const canAddMore = extraPreviews.length < maxExtras;

  const handleExtraUpload = async (file: File) => {
    if (!canAddMore) { toast.error("Maximum 4 extra photos allowed"); return; }
    setUploading(true);
    try {
      const reader = new FileReader();
      reader.onload = async (e) => {
        const dataUrl = e.target?.result as string;
        const base64 = dataUrl.split(",")[1];
        const res = await uploadImage.mutateAsync({ base64, filename: file.name, mimeType: file.type || "image/jpeg" });
        const newExtras = [...extraPreviews, res.url];
        setExtraPreviews(newExtras);
        await updateCollection.mutateAsync({ id: item.id, extraImageUrls: newExtras });
        toast.success("Photo added!");
        onUpdate();
        setUploading(false);
      };
      reader.readAsDataURL(file);
    } catch (e: any) {
      toast.error(e.message || "Upload failed");
      setUploading(false);
    }
  };

  const handleRemoveExtra = async (idx: number) => {
    const newExtras = extraPreviews.filter((_, i) => i !== idx);
    setExtraPreviews(newExtras);
    await updateCollection.mutateAsync({ id: item.id, extraImageUrls: newExtras });
    toast.success("Photo removed");
    onUpdate();
    // Adjust active image index if needed
    if (activeImg >= newExtras.length + 2) setActiveImg(Math.max(0, activeImg - 1));
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4" onClick={onClose}>
      <div className="bg-[#0d1f3c] border border-white/10 rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto shadow-2xl" onClick={e => e.stopPropagation()}>
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-white/10">
          <div>
            <h2 className="font-bold text-white text-lg">{item.cardTitle}</h2>
            <p className="text-white/50 text-sm">{item.playerName} {item.year ? `· ${item.year}` : ""} {item.setName ? `· ${item.setName}` : ""}</p>
          </div>
          <button onClick={onClose} className="text-white/40 hover:text-white transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-4 grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Main image viewer */}
          <div>
            <div
              ref={viewerRef}
              className="aspect-[3/4] bg-[#0a1628] rounded-xl overflow-hidden relative mb-3 select-none"
              style={{ cursor: zoom > 1 ? (isDragging ? "grabbing" : "grab") : "zoom-in" }}
              onWheel={handleWheel}
              onMouseDown={handleMouseDown}
              onMouseMove={handleMouseMove}
              onMouseUp={handleMouseUp}
              onMouseLeave={handleMouseUp}
              onDoubleClick={handleDoubleClick}
              onTouchStart={handleTouchStart}
              onTouchMove={handleTouchMove}
              onTouchEnd={handleTouchEnd}
            >
              {allImages[activeImg] ? (
                <img
                  src={allImages[activeImg]}
                  alt={`Card image ${activeImg + 1}`}
                  draggable={false}
                  style={{
                    width: "100%",
                    height: "100%",
                    objectFit: "contain",
                    transform: `scale(${zoom}) translate(${pan.x / zoom}px, ${pan.y / zoom}px)`,
                    transformOrigin: "center center",
                    transition: isDragging ? "none" : "transform 0.15s ease",
                    pointerEvents: "none",
                  }}
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center">
                  <Award className="w-16 h-16 text-white/10" />
                </div>
              )}

              {/* Zoom controls */}
              <div className="absolute top-2 right-2 flex flex-col gap-1">
                <button
                  className="bg-black/60 hover:bg-black/80 text-white rounded-full w-7 h-7 flex items-center justify-center text-sm font-bold transition-all"
                  onClick={e => { e.stopPropagation(); setZoom(z => Math.min(MAX_ZOOM, z + 0.5)); }}
                  title="Zoom in">
                  +
                </button>
                <button
                  className="bg-black/60 hover:bg-black/80 text-white rounded-full w-7 h-7 flex items-center justify-center text-sm font-bold transition-all"
                  onClick={e => { e.stopPropagation(); setZoom(z => { const n = Math.max(MIN_ZOOM, z - 0.5); if (n === MIN_ZOOM) setPan({ x: 0, y: 0 }); return n; }); }}
                  title="Zoom out">
                  −
                </button>
                {zoom > 1 && (
                  <button
                    className="bg-[#c41e3a]/80 hover:bg-[#c41e3a] text-white rounded-full w-7 h-7 flex items-center justify-center text-[9px] font-bold transition-all"
                    onClick={e => { e.stopPropagation(); resetZoom(); }}
                    title="Reset zoom">
                    ↺
                  </button>
                )}
              </div>

              {/* Zoom level indicator */}
              {zoom > 1 && (
                <div className="absolute top-2 left-2 bg-black/60 text-white text-[10px] px-2 py-0.5 rounded-full font-mono">
                  {zoom.toFixed(1)}×
                </div>
              )}

              {/* Nav arrows (only when not zoomed) */}
              {allImages.length > 1 && zoom === 1 && (
                <>
                  <button
                    className="absolute left-2 top-1/2 -translate-y-1/2 bg-black/60 hover:bg-black/80 text-white rounded-full p-1 transition-all"
                    onClick={e => { e.stopPropagation(); handleSetActiveImg((activeImg - 1 + allImages.length) % allImages.length); }}>
                    <ChevronLeft className="w-4 h-4" />
                  </button>
                  <button
                    className="absolute right-2 top-1/2 -translate-y-1/2 bg-black/60 hover:bg-black/80 text-white rounded-full p-1 transition-all"
                    onClick={e => { e.stopPropagation(); handleSetActiveImg((activeImg + 1) % allImages.length); }}>
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </>
              )}

              {/* Image counter */}
              {allImages.length > 0 && (
                <div className="absolute bottom-2 right-2 bg-black/60 text-white text-[10px] px-2 py-0.5 rounded-full">
                  {activeImg + 1} / {allImages.length}
                </div>
              )}

              {/* Hint (only when not zoomed and image exists) */}
              {zoom === 1 && allImages[activeImg] && (
                <div className="absolute bottom-2 left-2 bg-black/40 text-white/50 text-[9px] px-2 py-0.5 rounded-full">
                  scroll / pinch to zoom
                </div>
              )}
            </div>

            {/* Thumbnail strip — 6 slots */}
            <div className="grid grid-cols-6 gap-1.5">
              {/* Slot 1: Front */}
              <div
                className={`aspect-[3/4] rounded-lg overflow-hidden cursor-pointer border-2 transition-all ${activeImg === 0 ? "border-[#c41e3a]" : "border-white/10 hover:border-white/30"}`}
                onClick={() => handleSetActiveImg(0)}>
                {item.frontImageUrl ? (
                  <img src={item.frontImageUrl} alt="Front" className="w-full h-full object-cover" />
                ) : (
                  <div className="w-full h-full bg-white/5 flex items-center justify-center">
                    <span className="text-[8px] text-white/30">Front</span>
                  </div>
                )}
              </div>
              {/* Slot 2: Back */}
              <div
                className={`aspect-[3/4] rounded-lg overflow-hidden cursor-pointer border-2 transition-all ${activeImg === 1 ? "border-[#c41e3a]" : "border-white/10 hover:border-white/30"}`}
                onClick={() => handleSetActiveImg(1)}>
                {item.backImageUrl ? (
                  <img src={item.backImageUrl} alt="Back" className="w-full h-full object-cover" />
                ) : (
                  <div className="w-full h-full bg-white/5 flex items-center justify-center">
                    <span className="text-[8px] text-white/30">Back</span>
                  </div>
                )}
              </div>
              {/* Slots 3-6: Extra photos */}
              {Array.from({ length: 4 }).map((_, i) => {
                const extraUrl = extraPreviews[i];
                const imgIndex = 2 + i;
                return (
                  <div key={i} className={`aspect-[3/4] rounded-lg overflow-hidden relative border-2 transition-all ${extraUrl && activeImg === imgIndex ? "border-[#c41e3a]" : "border-white/10 hover:border-white/30"}`}>
                    {extraUrl ? (
                      <>
                        <img src={extraUrl} alt={`Extra ${i + 1}`} className="w-full h-full object-cover cursor-pointer" onClick={() => handleSetActiveImg(imgIndex)} />
                        <button
                          className="absolute top-0.5 right-0.5 bg-black/70 text-white rounded-full p-0.5 hover:bg-red-600 transition-colors"
                          onClick={() => handleRemoveExtra(i)}>
                          <X className="w-2.5 h-2.5" />
                        </button>
                      </>
                    ) : canAddMore ? (
                      <div
                        className="w-full h-full bg-white/5 flex flex-col items-center justify-center cursor-pointer hover:bg-white/10 transition-colors"
                        onClick={() => extraRef.current?.click()}>
                        <Plus className="w-3 h-3 text-white/30" />
                        <span className="text-[7px] text-white/20 mt-0.5">Add</span>
                      </div>
                    ) : (
                      <div className="w-full h-full bg-white/5 flex items-center justify-center">
                        <span className="text-[7px] text-white/20">Full</span>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
            <input ref={extraRef} type="file" accept="image/*" className="hidden"
              onChange={(e) => e.target.files?.[0] && handleExtraUpload(e.target.files[0])} />
            {uploading && <p className="text-xs text-blue-400 mt-1 text-center">Uploading photo...</p>}
            <p className="text-[10px] text-white/30 text-center mt-1">
              {extraPreviews.length}/4 extra photos · Click + to add
            </p>
          </div>

          {/* Card details */}
          <div className="space-y-4">
            {/* Grade info */}
            {item.overallGrade && (
              <div className="bg-[#0a1628] rounded-xl p-4 border border-white/10">
                <p className="text-xs text-white/40 uppercase tracking-wider mb-3 font-semibold">SCG Grade</p>
                <div className="flex items-center gap-3 mb-3">
                  <div className="text-4xl font-black text-[#c41e3a]">{parseFloat(item.overallGrade).toFixed(1)}</div>
                  <div>
                    <p className="text-white font-bold">{item.gradeLabel}</p>
                    {item.certNumber && <p className="text-white/40 text-xs">Cert# {item.certNumber}</p>}
                  </div>
                </div>
                <div className="grid grid-cols-4 gap-2">
                  {[
                    { label: "Centering", val: item.centeringScore },
                    { label: "Corners", val: item.cornersScore },
                    { label: "Edges", val: item.edgesScore },
                    { label: "Surface", val: item.surfaceScore },
                  ].map(({ label, val }) => val ? (
                    <div key={label} className="text-center">
                      <div className="text-lg font-bold text-white">{val}</div>
                      <div className="text-[9px] text-white/40">{label}</div>
                    </div>
                  ) : null)}
                </div>
              </div>
            )}

            {/* Value estimate */}
            {item.estimatedValueLow && item.estimatedValueHigh && (
              <div className="bg-green-500/10 border border-green-500/20 rounded-xl p-3">
                <p className="text-xs text-green-400/60 mb-1">Estimated Value</p>
                <p className="text-xl font-bold text-green-400">
                  ${parseFloat(item.estimatedValueLow).toFixed(0)} – ${parseFloat(item.estimatedValueHigh).toFixed(0)}
                </p>
              </div>
            )}

            {/* Card metadata */}
            <div className="space-y-2 text-sm">
              {item.sport && (
                <div className="flex justify-between">
                  <span className="text-white/40">Sport</span>
                  <span className="text-white capitalize">{item.sport}</span>
                </div>
              )}
              {item.setName && (
                <div className="flex justify-between">
                  <span className="text-white/40">Set</span>
                  <span className="text-white">{item.setName}</span>
                </div>
              )}
              {item.cardNumber && (
                <div className="flex justify-between">
                  <span className="text-white/40">Card #</span>
                  <span className="text-white">{item.cardNumber}</span>
                </div>
              )}
            </div>

            {/* Description */}
            {item.description && (
              <div className="bg-white/5 rounded-lg p-3">
                <p className="text-xs text-white/40 mb-1">Notes</p>
                <p className="text-sm text-white/70">{item.description}</p>
              </div>
            )}

            {/* Image count info */}
            <div className="bg-blue-500/10 border border-blue-500/20 rounded-lg p-3 text-xs text-blue-300">
              <strong>Photos:</strong> {allImages.length}/6 uploaded
              {allImages.length < 6 && ` · ${6 - allImages.length} slot${6 - allImages.length !== 1 ? "s" : ""} remaining`}
            </div>

            {/* Label Style */}
            <div className="bg-[#0a1628] rounded-xl p-4 border border-white/10">
              <p className="text-xs text-white/40 uppercase tracking-wider mb-3 font-semibold">Label Style</p>
              <div className="space-y-3">
                <div>
                  <label className="text-xs text-white/50 mb-1 block">Background</label>
                  <Select value={labelBg} onValueChange={(v) => setLabelBg(v as LabelBackground)}>
                    <SelectTrigger className="h-8 text-xs bg-white/5 border-white/10 text-white"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {LABEL_BACKGROUNDS.map(bg => (
                        <SelectItem key={bg.value} value={bg.value} className="text-xs">{bg.label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <label className="text-xs text-white/50 mb-1 block">Border Color</label>
                  <Select value={labelBorder} onValueChange={(v) => setLabelBorder(v as LabelBorderColor)}>
                    <SelectTrigger className="h-8 text-xs bg-white/5 border-white/10 text-white"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {LABEL_BORDER_COLORS.map(bc => (
                        <SelectItem key={bc.value} value={bc.value} className="text-xs">{bc.label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="flex gap-2">
                  <Button
                    size="sm"
                    className="flex-1 h-8 text-xs bg-[#c41e3a] hover:bg-[#a01830] text-white"
                    onClick={handleSaveLabelStyle}
                    disabled={savingLabel}>
                    {savingLabel ? "Saving..." : "💾 Save Label Style"}
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    className="flex-1 h-8 text-xs border-white/20 text-white hover:bg-white/10"
                    onClick={handlePrintSingleCard}>
                    <Printer className="w-3 h-3 mr-1" /> Print Label
                  </Button>
                </div>
              </div>
            </div>

            {/* Saved Comp References */}
            <CompRefsSection itemId={item.id} />

            {/* Card Lifecycle Timeline */}
            <div className="bg-[#0a1628] rounded-xl p-4 border border-white/10">
              <CardTimeline collectionItemId={item.id} />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ============================================================================
// BULK ACTION TOOLBAR
// ============================================================================
function BulkActionBar({
  count,
  onClear,
  onSelectAll,
  onDelete,
  onListToArena,
  onPrint,
  onLabelColor,
  onPreview,
  bulkLabelColor,
  setBulkLabelColor,
  bulkBg,
  setBulkBg,
  bulkBorder,
  setBulkBorder,
}: {
  count: number;
  onClear: () => void;
  onSelectAll: () => void;
  onDelete: () => void;
  onListToArena: () => void;
  onPrint: () => void;
  onLabelColor: () => void;
  onPreview: () => void;
  bulkLabelColor: string;
  setBulkLabelColor: (v: string) => void;
  bulkBg: LabelBackground;
  setBulkBg: (v: LabelBackground) => void;
  bulkBorder: LabelBorderColor;
  setBulkBorder: (v: LabelBorderColor) => void;
}) {
  return (
    <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-[60] bg-white border border-gray-200 rounded-2xl shadow-2xl shadow-black/40 px-5 py-3 flex items-center gap-3 flex-wrap justify-center">
      {/* Selection count + controls */}
      <div className="flex items-center gap-2">
        {count === 0 ? (
          <span className="text-gray-500 text-sm font-medium">Click cards to select — or</span>
        ) : (
          <>
            <div className="w-7 h-7 bg-[#c41e3a] rounded-full flex items-center justify-center text-white text-xs font-bold shadow">{count}</div>
            <span className="text-gray-800 text-sm font-semibold">{count === 1 ? "card selected" : "cards selected"}</span>
          </>
        )}
        <button onClick={onSelectAll} className="text-xs text-white font-semibold bg-green-600 hover:bg-green-500 rounded-lg px-3 py-1.5 ml-1 transition-colors shadow-sm">
          Select All
        </button>
        <button onClick={onClear} className="text-gray-400 hover:text-gray-700 ml-1" title="Exit bulk mode">
          <X className="w-4 h-4" />
        </button>
      </div>

      <div className="w-px h-7 bg-gray-200" />

      {/* Action buttons */}
      <Button size="sm" className="bg-blue-600 hover:bg-blue-700 text-white gap-1.5 h-9 px-4 font-semibold shadow-sm disabled:opacity-40" onClick={onListToArena} disabled={count === 0}>
        <Tag className="w-3.5 h-3.5" />List to Marketplace
      </Button>

      <div className="w-px h-7 bg-gray-200" />

      {/* Label style pickers */}
      <div className="flex items-center gap-1.5 flex-wrap">
        <select
          value={bulkBg}
          onChange={e => setBulkBg(e.target.value as LabelBackground)}
          className="h-9 text-xs bg-white border border-gray-300 text-gray-700 rounded-lg px-2 cursor-pointer shadow-sm"
          title="Label background">
          {LABEL_BACKGROUNDS.map(b => <option key={b.value} value={b.value}>{b.label}</option>)}
        </select>
        <select
          value={bulkBorder}
          onChange={e => setBulkBorder(e.target.value as LabelBorderColor)}
          className="h-9 text-xs bg-white border border-gray-300 text-gray-700 rounded-lg px-2 cursor-pointer shadow-sm"
          title="Border color">
          {LABEL_BORDER_COLORS.map(b => (
            <option key={b.value} value={b.value}>{b.label} Border</option>
          ))}
        </select>
        <Button size="sm" variant="outline" className="border-gray-300 text-gray-700 hover:bg-gray-50 gap-1.5 h-9 shadow-sm" onClick={onPreview} title="Preview label style before applying">
          <Eye className="w-3.5 h-3.5" />Preview
        </Button>
        <Button size="sm" className="bg-yellow-500 hover:bg-yellow-400 text-black gap-1.5 h-9 font-bold shadow-sm disabled:opacity-40" onClick={onLabelColor} disabled={count === 0} title="Apply selected label style to all chosen cards">
          <Palette className="w-3.5 h-3.5" />Apply to {count > 0 ? count : ""} Card{count !== 1 ? "s" : ""}
        </Button>
        <Button size="sm" variant="outline" className="border-gray-300 text-gray-700 hover:bg-gray-100 gap-1.5 h-9 shadow-sm disabled:opacity-40" onClick={onPrint} disabled={count === 0}>
          <Printer className="w-3.5 h-3.5" />Print Labels
        </Button>
      </div>

      <div className="w-px h-7 bg-gray-200" />

      <Button size="sm" variant="ghost" className="text-red-500 hover:text-red-600 hover:bg-red-50 gap-1.5 h-9 font-semibold disabled:opacity-40" onClick={onDelete} disabled={count === 0}>
        <Trash2 className="w-3.5 h-3.5" />Delete
      </Button>
    </div>
  );
}

// ============================================================================
// MAIN COMPONENT
// ============================================================================
export default function MyCollection() {
  const { user, isAuthenticated, loading } = useAuth();
  const [activeTab, setActiveTab] = useState<"collection" | "orders" | "favorites" | "vault">("collection");
  const [importedSearch, setImportedSearch] = useState("");
  const [importedPage, setImportedPage] = useState(0);
  const IMPORTED_PAGE_SIZE = 50;
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCard, setSelectedCard] = useState<number | null>(null);
  const [listingPrice, setListingPrice] = useState("");
  const [isGraded, setIsGraded] = useState(true);
  const [auctionDuration, setAuctionDuration] = useState<"5" | "7" | "10">("5");
  const [auctionStartPrice, setAuctionStartPrice] = useState("");
  const [marketDialogOpen, setMarketDialogOpen] = useState(false);
  const [auctionDialogOpen, setAuctionDialogOpen] = useState(false);
  const [activeAuctionItem, setActiveAuctionItem] = useState<any>(null);
  const [marketPriceItem, setMarketPriceItem] = useState<any>(null);

  // Market price suggestion — fetched when a listing dialog opens
  const marketPriceQuery = trpc.grading.getMarketPrice.useQuery(
    {
      query: marketPriceItem ? `${marketPriceItem.playerName} ${marketPriceItem.year || ""} ${marketPriceItem.setName || ""}`.trim() : "",
      grade: marketPriceItem?.overallGrade ? parseFloat(marketPriceItem.overallGrade) : null,
    },
    { enabled: !!marketPriceItem, staleTime: 5 * 60 * 1000 }
  );

  // Bulk selection state
  const [bulkMode, setBulkMode] = useState(false);
  const [selectedIds, setSelectedIds] = useState<Set<number>>(new Set());
  const [bulkLabelColor, setBulkLabelColor] = useState("dark");
  const [bulkBg, setBulkBg] = useState<LabelBackground>("black-silk");
  const [bulkBorder, setBulkBorder] = useState<LabelBorderColor>("red");
  const [showLabelPreview, setShowLabelPreview] = useState(false);
  const [bulkArenaPrice, setBulkArenaPrice] = useState("");
  const [bulkArenaOpen, setBulkArenaOpen] = useState(false);
  // Per-card label style (used in single-card List in Arena dialog and per-card print)
  const [singleBg, setSingleBg] = useState<LabelBackground>("black-silk");
  const [singleBorder, setSingleBorder] = useState<LabelBorderColor>("red");

  // Card detail popup
  const [detailItem, setDetailItem] = useState<any>(null);
  // Stock view mode
  const [stockViewMode, setStockViewMode] = useState(false);
  // Pagination
  const [currentPage, setCurrentPage] = useState(1);
  const PAGE_SIZE = 40;

  const { data: collection, isLoading, refetch } = trpc.collection.list.useQuery(undefined, { enabled: isAuthenticated });
  const { data: myCards } = trpc.cards.myCards.useQuery(undefined, { enabled: isAuthenticated });
  const { data: myAuctions } = trpc.auctions.myAuctions.useQuery(undefined, { enabled: isAuthenticated });
  const { data: creditAccount } = trpc.credits.myAccount.useQuery(undefined, { enabled: isAuthenticated });
  const { data: affiliateData, refetch: refetchAffiliate } = trpc.affiliate.myAffiliate.useQuery(undefined, { enabled: isAuthenticated });
  const { data: myReferrals } = trpc.affiliate.myReferrals.useQuery(undefined, { enabled: isAuthenticated && !!affiliateData, refetchInterval: 30000 });
  const joinAffiliate = trpc.affiliate.joinAffiliate.useMutation({
    onSuccess: () => { toast.success("Welcome to the SCO Affiliate Program! 🎉"); refetchAffiliate(); },
    onError: (e) => toast.error(e.message),
  });
  const { data: buyerOrders, refetch: refetchBuyer } = trpc.orders.myBuyerOrders.useQuery(undefined, { enabled: isAuthenticated && activeTab === "orders" });
  const { data: sellerOrders, refetch: refetchSeller } = trpc.orders.mySellerOrders.useQuery(undefined, { enabled: isAuthenticated && activeTab === "orders" });
  const { data: favoriteCards } = trpc.favorites.myCards.useQuery(undefined, { enabled: isAuthenticated && activeTab === "favorites" });
  const { data: vaultItems, refetch: refetchVault } = trpc.vault.myVault.useQuery(undefined, { enabled: isAuthenticated && activeTab === "vault" });
  const vaultSendToMe = trpc.vault.requestShipToMe.useMutation({
    onSuccess: () => { toast.success("Ship-to-me request submitted! We'll contact you with shipping details."); refetchVault(); },
    onError: (e) => toast.error(e.message),
  });
  const vaultListCard = trpc.vault.listVaultCard.useMutation({
    onSuccess: () => { toast.success("Card listed on the Marketplace!"); refetchVault(); },
    onError: (e) => toast.error(e.message),
  });
  const vaultAuctionCard = trpc.vault.auctionVaultCard.useMutation({
    onSuccess: () => { toast.success("Card sent to Auction!"); refetchVault(); },
    onError: (e) => toast.error(e.message),
  });
  const vaultSellForCredits = trpc.vault.sellForCredits.useMutation({
    onSuccess: (data) => {
      toast.success(`⭐ ${data.creditsAwarded} credits added! (10% vault fee on $${data.cardValue.toFixed(2)})`);
      refetchVault();
    },
    onError: (e) => toast.error(e.message),
  });
  const [cardActionMenu, setCardActionMenu] = useState<number | null>(null);
  const [shipToMeDialogOpen, setShipToMeDialogOpen] = useState(false);
  const [shipToMeItem, setShipToMeItem] = useState<any>(null);
  const [shipAddress, setShipAddress] = useState({ name: "", address: "", city: "", state: "", zip: "", country: "US" });
  const favoriteIds = useFavoriteIds();
  const { data: importedCards, isLoading: importedLoading } = trpc.userCollection.list.useQuery(
    { limit: IMPORTED_PAGE_SIZE, offset: importedPage * IMPORTED_PAGE_SIZE },
    { enabled: false }
  );
  const { data: importedStats } = trpc.userCollection.stats.useQuery(undefined, { enabled: isAuthenticated });
  const { data: importedSearchResults } = trpc.userCollection.search.useQuery(
    { query: importedSearch },
    { enabled: isAuthenticated && importedSearch.length >= 2 }
  );

  const listToArena = trpc.collection.listToArena.useMutation();
  const createAuction = trpc.auctions.create.useMutation();
  const deleteItem = trpc.collection.delete.useMutation();
  const bulkDelete = trpc.collection.bulkDelete.useMutation();
  const bulkListToArena = trpc.collection.bulkListToArena.useMutation();
  const updateCollection = trpc.collection.update.useMutation();

  // Build status map
  const cardStatusMap = new Map<number, { type: "marketplace" | "auction"; id: number }>();
  myCards?.forEach((card) => {
    if (card.status === "active") cardStatusMap.set(card.id, { type: "marketplace", id: card.id });
  });
  myAuctions?.forEach((auction) => {
    if (auction.status === "active") cardStatusMap.set(auction.cardId, { type: "auction", id: auction.id });
  });

  const activeAuctionCount = myAuctions?.filter((a) => a.status === "active").length || 0;
  const auctionCreditMap: Record<string, number> = { "5": 3, "7": 5, "10": 8 };
  const auctionCreditCost = auctionCreditMap[auctionDuration] ?? parseInt(auctionDuration);

  const filteredCollection = collection?.filter((item) => {
    if (!searchQuery) return true;
    const q = searchQuery.toLowerCase();
    return item.cardTitle.toLowerCase().includes(q) || item.playerName.toLowerCase().includes(q) || item.setName?.toLowerCase().includes(q);
  });
  const totalPages = Math.ceil((filteredCollection?.length || 0) / PAGE_SIZE);
  const paginatedCollection = filteredCollection?.slice((currentPage - 1) * PAGE_SIZE, currentPage * PAGE_SIZE);

  const handleListToArena = async () => {
    if (!selectedCard || !listingPrice) { toast.error("Please enter a price"); return; }
    try {
      await listToArena.mutateAsync({ collectionId: selectedCard, price: listingPrice });
      toast.success("Card listed in the Arena!");
      setSelectedCard(null); setListingPrice(""); setMarketDialogOpen(false); refetch();
    } catch (e: any) { toast.error(e.message || "Failed to list card"); }
  };

  const handleListToAuction = async () => {
    if (!activeAuctionItem || !auctionStartPrice) { toast.error("Please enter a starting price"); return; }
    if (activeAuctionCount >= 100) { toast.error("Maximum 100 active auctions reached."); return; }
    if ((creditAccount?.credits || 0) < auctionCreditCost) {
      toast.error(`Not enough credits. You need ${auctionCreditCost} credits.`); return;
    }
    try {
      const card = await listToArena.mutateAsync({
        collectionId: activeAuctionItem.id, price: auctionStartPrice,
        description: `${activeAuctionItem.gradeLabel || ""} ${activeAuctionItem.overallGrade || ""}`.trim(),
      });
      await createAuction.mutateAsync({
        cardId: card.id, cardTitle: card.title, cardImageUrl: card.frontImageUrl || undefined,
        startingPrice: auctionStartPrice, durationDays: parseInt(auctionDuration),
        playerName: card.playerName, gradeInfo: card.aiGradeLabel ? `${card.aiGradeLabel} ${card.aiGrade}` : undefined,
      });
      toast.success(`Card listed for ${auctionDuration}-day auction! ${auctionCreditCost} credits used.`);
      setActiveAuctionItem(null); setAuctionStartPrice(""); setAuctionDialogOpen(false); refetch();
    } catch (e: any) { toast.error(e.message || "Failed to create auction"); }
  };

  const handleDelete = async (id: number) => {
    if (!confirm("Remove this card from your collection?")) return;
    try { await deleteItem.mutateAsync({ id }); toast.success("Card removed"); refetch(); }
    catch (e: any) { toast.error(e.message || "Failed to delete"); }
  };

  const copyAffiliateLink = () => {
    const link = `${window.location.origin}?ref=${affiliateData?.referralCode}`;
    navigator.clipboard.writeText(link);
    toast.success("Affiliate link copied!");
  };

  // Bulk handlers
  const toggleBulkSelect = (id: number) => {
    setSelectedIds(prev => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  };

  const handleBulkDelete = async () => {
    if (!confirm(`Delete ${selectedIds.size} card(s) from your collection?`)) return;
    try {
      await bulkDelete.mutateAsync({ ids: Array.from(selectedIds) });
      toast.success(`${selectedIds.size} card(s) deleted`);
      setSelectedIds(new Set()); setBulkMode(false); refetch();
    } catch (e: any) { toast.error(e.message || "Bulk delete failed"); }
  };

  const handleBulkListToArena = async () => {
    if (!bulkArenaPrice) { toast.error("Enter a price for all selected cards"); return; }
    try {
      const result = await bulkListToArena.mutateAsync({ ids: Array.from(selectedIds), price: bulkArenaPrice });
      toast.success(`${result.count} card(s) listed in the Arena!`);
      setSelectedIds(new Set()); setBulkMode(false); setBulkArenaOpen(false); setBulkArenaPrice(""); refetch();
    } catch (e: any) { toast.error(e.message || "Bulk list failed"); }
  };

  const handleBulkPrint = () => {
    const items = collection?.filter(c => selectedIds.has(c.id)) || [];
    const w = window.open("", "_blank");
    if (!w) return;
    const labelData = items.map(card => ({
      playerName: card.playerName,
      cardCompany: card.setName?.split(" ")[0] || "",
      year: card.year ?? undefined,
      setName: card.setName ?? undefined,
      cardNumber: card.cardNumber ?? undefined,
      overallGrade: card.overallGrade ? parseFloat(card.overallGrade) : undefined,
      gradeLabel: card.gradeLabel ?? undefined,
      centering: card.centeringScore ?? undefined,
      corners: card.cornersScore ?? undefined,
      edges: card.edgesScore ?? undefined,
      surface: card.surfaceScore ?? undefined,
      certNumber: card.certNumber ?? undefined,
      cardId: card.id,
      background: bulkBg,
      borderColor: bulkBorder,
    }));
    const html = buildPrintPage(labelData, window.location.origin);
    w.document.write(html);
    w.document.close();
  };

  const handleBulkLabelColor = async () => {
    if (selectedIds.size === 0) { toast.error("Select at least one card first"); return; }
    let updated = 0;
    for (const id of Array.from(selectedIds)) {
      await updateCollection.mutateAsync({ id, labelBg: bulkBg as any, labelBorder: bulkBorder as any });
      updated++;
    }
    toast.success(`✅ Label style applied to ${updated} card${updated !== 1 ? "s" : ""}`);
    setSelectedIds(new Set()); setBulkMode(false); refetch();
  };

  if (!isAuthenticated && !loading) {
    const plans = [
      { name: "Free",      price: 0,      credits: 10,   icon: Award,  color: "border-white/20",          iconColor: "text-white/50",  features: ["10 credits/month", "5 active listings", "Basic AI grading"] },
      { name: "Starter",   price: 9.99,   credits: 50,   icon: Star,   color: "border-blue-500/50",       iconColor: "text-blue-400",  features: ["50 credits/month", "25 active listings", "Priority support"] },
      { name: "Pro",       price: 24.99,  credits: 150,  icon: Zap,    color: "border-purple-500/50",     iconColor: "text-purple-400",features: ["150 credits/month", "Unlimited listings", "Analytics"] },
      { name: "Elite",     price: 59.99,  credits: 400,  icon: Crown,  color: "border-[#E8C547]/60",      iconColor: "text-[#E8C547]", features: ["400 credits/month", "Affiliate program", "Custom label colors"], popular: true },
      { name: "Franchise", price: 149.99, credits: 1000, icon: Trophy, color: "border-[#C41E3A]/60",      iconColor: "text-[#C41E3A]", features: ["1000 credits/month", "Dedicated support", "White-label options"] },
    ];
    return (
      <div className="min-h-screen bg-[#0a1628] pb-20">
        <div className="bg-[#0d1f3c] border-b border-white/10 py-10 text-center">
          <div className="inline-flex items-center gap-2 bg-[#C41E3A]/10 border border-[#C41E3A]/30 rounded-full px-4 py-1.5 mb-4">
            <Award className="w-4 h-4 text-[#C41E3A]" />
            <span className="text-sm font-semibold text-[#C41E3A] uppercase tracking-wider">My Collection</span>
          </div>
          <h1 className="text-4xl font-black text-white mb-3" style={{ fontFamily: "Oswald, sans-serif" }}>
            Your Cards. Your Collection.
          </h1>
          <p className="text-white/50 max-w-md mx-auto mb-8 text-sm">
            Sign up to upload, grade, and manage your cards. List them in the Arena, run live auctions, or trade with other collectors.
          </p>
          <a href={getLoginUrl("/collection")} className="inline-block bg-[#C41E3A] hover:bg-[#a01830] text-white font-bold px-8 py-3 rounded-xl text-lg transition-colors">
            Sign Up / Sign In Free
          </a>
          <p className="text-white/30 text-xs mt-3">Free plan included — no credit card required to start</p>
        </div>
        <div className="max-w-5xl mx-auto px-4 py-10">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-12">
            {[
              { icon: Upload,      label: "Upload Cards",        desc: "Add cards without grading" },
              { icon: Camera,      label: "AI Card Grading",     desc: "Grade any card in ~1 second" },
              { icon: ShoppingCart,label: "Arena",               desc: "Buy & sell with escrow protection" },
              { icon: Gavel,       label: "Live Auctions",       desc: "Run 5, 7, or 10-day auctions" },
            ].map(({ icon: Icon, label, desc }) => (
              <div key={label} className="bg-[#0d1f3c] border border-white/10 rounded-xl p-4 text-center">
                <Icon className="w-8 h-8 text-[#C41E3A] mx-auto mb-2" />
                <div className="font-bold text-white text-sm">{label}</div>
                <div className="text-xs text-white/40 mt-1">{desc}</div>
              </div>
            ))}
          </div>
          <h2 className="text-2xl font-black text-white text-center mb-6" style={{ fontFamily: "Oswald, sans-serif" }}>Choose Your Plan</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
            {plans.map(plan => {
              const Icon = plan.icon;
              return (
                <div key={plan.name} className={`relative border-2 rounded-2xl p-5 bg-[#0d1f3c] ${plan.color} ${'popular' in plan && plan.popular ? "ring-2 ring-[#E8C547]/40" : ""} transition-all hover:scale-[1.02]`}>
                  {'popular' in plan && plan.popular && (
                    <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-[#E8C547] text-black text-xs font-black px-3 py-0.5 rounded-full">Most Popular</div>
                  )}
                  <div className="flex items-center gap-2 mb-3">
                    <Icon className={`w-6 h-6 ${plan.iconColor}`} />
                    <span className="font-bold text-white text-lg">{plan.name}</span>
                  </div>
                  <div className="mb-1">
                    <span className="text-3xl font-black text-white">{plan.price === 0 ? "Free" : `$${plan.price}`}</span>
                    {plan.price > 0 && <span className="text-sm text-white/40">/mo</span>}
                  </div>
                  <div className={`text-sm font-semibold mb-4 ${plan.iconColor}`}>{plan.credits} credits/month</div>
                  <ul className="space-y-1.5 mb-5">
                    {plan.features.map(f => (
                      <li key={f} className="text-xs text-white/60 flex items-center gap-2">
                        <CheckCircle className="w-3.5 h-3.5 text-green-400 shrink-0" />{f}
                      </li>
                    ))}
                  </ul>
                  <a href={getLoginUrl("/collection")} className={`block w-full text-center py-2 rounded-lg text-sm font-bold transition-colors ${'popular' in plan && plan.popular ? "bg-[#E8C547] hover:bg-[#d4b040] text-black" : "bg-white/10 hover:bg-white/20 text-white"}`}>
                    {plan.price === 0 ? "Start Free" : `Get ${plan.name}`}
                  </a>
                </div>
              );
            })}
          </div>
          <p className="text-center text-white/30 text-xs">All plans include card uploads, AI grading, Arena access, and trade features. Upgrade or downgrade anytime.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen py-6 pb-20">
      <div className="container">

        {/* Top Stats Bar */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-6">
          <div className="bg-card border rounded-lg p-3 flex items-center gap-3">
            <Award className="w-8 h-8 text-[#c41e3a]" />
            <div>
              <p className="text-xs text-muted-foreground">Total Cards</p>
              <p className="text-xl font-bold">{collection?.length || 0}</p>
            </div>
          </div>
          <div className="bg-card border rounded-lg p-3 flex items-center gap-3">
            <Gavel className="w-8 h-8 text-orange-500" />
            <div>
              <p className="text-xs text-muted-foreground">Active Auctions</p>
              <p className="text-xl font-bold">{activeAuctionCount}<span className="text-xs text-muted-foreground">/10</span></p>
            </div>
          </div>
          <div className="bg-card border rounded-lg p-3 flex items-center gap-3">
            <Coins className="w-8 h-8 text-yellow-500" />
            <div>
              <p className="text-xs text-muted-foreground">Credits</p>
              <p className="text-xl font-bold">{creditAccount?.credits || 0}</p>
            </div>
          </div>
          <div className="bg-card border rounded-lg p-3 flex items-center gap-3">
            <ShoppingCart className="w-8 h-8 text-green-500" />
            <div>
              <p className="text-xs text-muted-foreground">Listed in Arena</p>
              <p className="text-xl font-bold">{myCards?.filter(c => c.status === "active").length || 0}</p>
            </div>
          </div>
        </div>

        {/* ── Affiliate Program ─────────────────────────────────────────── */}
        {affiliateData ? (
          /* Already an affiliate — show dashboard */
          <div className="mb-6 rounded-2xl overflow-hidden border border-[#E8C547]/30 bg-gradient-to-br from-[#1a2a0a] via-[#0d1f3c] to-[#0a1628]">
            <div className="bg-gradient-to-r from-[#E8C547]/20 to-[#c41e3a]/10 px-5 py-3 flex items-center gap-2 border-b border-white/10">
              <Gift className="w-4 h-4 text-[#E8C547]" />
              <span className="text-sm font-black text-[#E8C547] uppercase tracking-wider">SCO Affiliate Program</span>
              <span className="ml-auto text-[10px] bg-green-500/20 text-green-400 border border-green-500/30 rounded-full px-2 py-0.5 font-semibold">Active</span>
            </div>
            <div className="p-5">
              <div className="grid grid-cols-3 gap-3 mb-4">
                <div className="bg-white/5 rounded-xl p-3 text-center">
                  <p className="text-2xl font-black text-[#E8C547]">{affiliateData.totalReferrals ?? 0}</p>
                  <p className="text-[10px] text-white/40 uppercase tracking-wide mt-0.5">Referrals</p>
                </div>
                <div className="bg-white/5 rounded-xl p-3 text-center">
                  <p className="text-2xl font-black text-green-400">${parseFloat(affiliateData.totalEarnings || "0").toFixed(2)}</p>
                  <p className="text-[10px] text-white/40 uppercase tracking-wide mt-0.5">Total Earned</p>
                </div>
                <div className="bg-white/5 rounded-xl p-3 text-center">
                  <p className="text-2xl font-black text-blue-400">${parseFloat(affiliateData.pendingPayout || "0").toFixed(2)}</p>
                  <p className="text-[10px] text-white/40 uppercase tracking-wide mt-0.5">Pending Payout</p>
                </div>
              </div>
              <div className="bg-black/30 rounded-xl p-3 mb-3">
                <p className="text-[10px] text-white/40 uppercase tracking-wide mb-1">Your Referral Link</p>
                <div className="flex items-center gap-2">
                  <code className="flex-1 text-xs text-[#E8C547] font-mono truncate">{window.location.origin}?ref={affiliateData.referralCode}</code>
                  <Button size="sm" className="h-7 px-3 text-xs bg-[#E8C547] hover:bg-[#d4b03c] text-black font-bold shrink-0" onClick={copyAffiliateLink}>
                    <Copy className="w-3 h-3 mr-1" />Copy
                  </Button>
                </div>
              </div>
              <div className="flex gap-2 mb-4">
                <button
                  onClick={() => { const url = encodeURIComponent(`${window.location.origin}?ref=${affiliateData.referralCode}`); window.open(`https://twitter.com/intent/tweet?text=Join+me+on+SportCardsOnline+%E2%80%94+the+best+sports+card+marketplace!&url=${url}`, "_blank"); }}
                  className="flex-1 flex items-center justify-center gap-1.5 bg-[#1DA1F2]/10 hover:bg-[#1DA1F2]/20 border border-[#1DA1F2]/30 rounded-lg py-2 text-xs text-[#1DA1F2] font-semibold transition-colors">
                  <Twitter className="w-3.5 h-3.5" />Share on X
                </button>
                <button
                  onClick={() => { const url = encodeURIComponent(`${window.location.origin}?ref=${affiliateData.referralCode}`); window.open(`https://www.facebook.com/sharer/sharer.php?u=${url}`, "_blank"); }}
                  className="flex-1 flex items-center justify-center gap-1.5 bg-[#1877F2]/10 hover:bg-[#1877F2]/20 border border-[#1877F2]/30 rounded-lg py-2 text-xs text-[#1877F2] font-semibold transition-colors">
                  <Facebook className="w-3.5 h-3.5" />Share on Facebook
                </button>
              </div>

              {/* ── Referral Tracking ─────────────────────────────── */}
              <div className="border border-white/10 rounded-xl overflow-hidden">
                <div className="px-4 py-2.5 bg-white/5 border-b border-white/10 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Users className="w-3.5 h-3.5 text-[#E8C547]" />
                    <span className="text-xs font-bold text-white uppercase tracking-wide">Referred Friends</span>
                    <span className="text-[10px] bg-[#E8C547]/20 text-[#E8C547] rounded-full px-2 py-0.5 font-semibold">{myReferrals?.length ?? 0}</span>
                  </div>
                  <span className="text-[10px] text-white/30 flex items-center gap-1">
                    <span className="inline-block w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse" />
                    Live
                  </span>
                </div>
                {!myReferrals || myReferrals.length === 0 ? (
                  <div className="px-4 py-6 text-center">
                    <Users className="w-8 h-8 mx-auto mb-2 text-white/10" />
                    <p className="text-xs text-white/30">No referrals yet</p>
                    <p className="text-[10px] text-white/20 mt-0.5">Share your link above to start earning</p>
                  </div>
                ) : (
                  <div className="divide-y divide-white/5 max-h-56 overflow-y-auto">
                    {myReferrals.map((ref: any) => {
                      const statusConfig: Record<string, { label: string; color: string; dot: string }> = {
                        pending:   { label: "Signed Up",  color: "text-yellow-400 bg-yellow-400/10 border-yellow-400/30",  dot: "bg-yellow-400" },
                        paid:      { label: "Paid Out",   color: "text-green-400 bg-green-400/10 border-green-400/30",    dot: "bg-green-400" },
                        cancelled: { label: "Cancelled",  color: "text-red-400 bg-red-400/10 border-red-400/30",          dot: "bg-red-400" },
                      };
                      const s = statusConfig[ref.status] ?? statusConfig.pending;
                      const initials = (ref.referredName || ref.referredEmail || "?").slice(0, 2).toUpperCase();
                      const displayName = ref.referredName || ref.referredEmail?.split("@")[0] || "Unknown";
                      const commission = parseFloat(ref.commissionAmount || "0").toFixed(2);
                      return (
                        <div key={ref.id} className="flex items-center gap-3 px-4 py-3 hover:bg-white/3 transition-colors">
                          <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[#E8C547]/30 to-[#c41e3a]/30 border border-white/10 flex items-center justify-center shrink-0">
                            <span className="text-[10px] font-black text-white">{initials}</span>
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-semibold text-white truncate">{displayName}</p>
                            <p className="text-[10px] text-white/40">
                              Joined {ref.createdAt ? new Date(ref.createdAt).toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" }) : "—"}
                            </p>
                          </div>
                          <div className="flex items-center gap-2 shrink-0">
                            <span className={`text-[10px] px-2 py-0.5 rounded-full border font-semibold flex items-center gap-1 ${s.color}`}>
                              <span className={`w-1.5 h-1.5 rounded-full ${s.dot}`} />
                              {s.label}
                            </span>
                            <span className="text-sm font-black text-green-400">+${commission}</span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            </div>
          </div>
        ) : (
          /* Not yet an affiliate — prominent sign-up CTA */
          <div className="mb-6 rounded-2xl overflow-hidden border-2 border-[#E8C547]/50 bg-gradient-to-br from-[#1a1a0a] via-[#0d1f3c] to-[#0a1628] relative">

            <div className="relative p-6">
              <div className="flex flex-col sm:flex-row items-start sm:items-center gap-5">
                <div className="flex-shrink-0 w-14 h-14 rounded-2xl bg-[#E8C547]/20 border border-[#E8C547]/40 flex items-center justify-center">
                  <Gift className="w-7 h-7 text-[#E8C547]" />
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <h3 className="text-lg font-black text-white" style={{ fontFamily: "Oswald, sans-serif" }}>Join the SCO Affiliate Program</h3>
                    <span className="text-[10px] bg-[#E8C547]/20 text-[#E8C547] border border-[#E8C547]/40 rounded-full px-2 py-0.5 font-bold uppercase tracking-wide">Free to Join</span>
                  </div>
                  <p className="text-sm text-white/60 mb-3">Earn credits every time someone you refer signs up or buys cards. Share your link and get paid.</p>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 mb-4">
                    {[
                      { icon: Users, label: "Earn per referral", value: "100 credits" },
                      { icon: TrendingUp, label: "Tier 2 bonus", value: "25% extra" },
                      { icon: Share2, label: "Track in real-time", value: "Live stats" },
                    ].map(({ icon: Icon, label, value }) => (
                      <div key={label} className="bg-white/5 rounded-lg p-2.5 flex items-center gap-2">
                        <Icon className="w-4 h-4 text-[#E8C547] shrink-0" />
                        <div>
                          <p className="text-[11px] font-bold text-white">{value}</p>
                          <p className="text-[10px] text-white/40">{label}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
                <Button
                  onClick={() => joinAffiliate.mutate()}
                  disabled={joinAffiliate.isPending}
                  className="shrink-0 bg-[#E8C547] hover:bg-[#d4b03c] text-black font-black px-6 py-3 rounded-xl text-sm uppercase tracking-wide shadow-lg shadow-[#E8C547]/20">
                  {joinAffiliate.isPending ? (
                    <><span className="animate-spin mr-2">⟳</span>Joining...</>
                  ) : (
                    <><Gift className="w-4 h-4 mr-2" />Join Now — It's Free</>
                  )}
                </Button>
              </div>
            </div>
          </div>
        )}

        {/* Tab bar: Collection | Orders */}
        <div className="flex gap-1 mb-6 border-b border-white/10 pb-0">
          <button
            onClick={() => setActiveTab("collection")}
            className={`px-4 py-2 text-sm font-semibold rounded-t-lg transition-colors ${
              activeTab === "collection"
                ? "bg-[#c41e3a] text-white"
                : "text-white/50 hover:text-white hover:bg-white/5"
            }`}
          >
            <Award className="w-3.5 h-3.5 inline mr-1.5" />House Collection
          </button>
          <button
            onClick={() => setActiveTab("orders")}
            className={`px-4 py-2 text-sm font-semibold rounded-t-lg transition-colors flex items-center gap-1.5 ${
              activeTab === "orders"
                ? "bg-[#c41e3a] text-white"
                : "text-white/50 hover:text-white hover:bg-white/5"
            }`}
          >
            <Package className="w-3.5 h-3.5" />Orders
            {((buyerOrders?.filter((o: any) => ["pending","paid","shipped"].includes(o.status)).length || 0) +
              (sellerOrders?.filter((o: any) => o.status === "paid" && !o.trackingNumber).length || 0)) > 0 && (
              <span className="w-4 h-4 bg-yellow-500 text-black rounded-full text-[9px] flex items-center justify-center font-black">
                {(buyerOrders?.filter((o: any) => ["pending","paid","shipped"].includes(o.status)).length || 0) +
                  (sellerOrders?.filter((o: any) => o.status === "paid" && !o.trackingNumber).length || 0)}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveTab("favorites")}
            className={`px-4 py-2 text-sm font-semibold rounded-t-lg transition-colors flex items-center gap-1.5 ${
              activeTab === "favorites"
                ? "bg-red-600 text-white"
                : "text-white/50 hover:text-white hover:bg-white/5"
            }`}
          >
            <Heart className="w-3.5 h-3.5" />Favorites
            {favoriteIds.size > 0 && (
              <span className="ml-1 text-[10px] bg-red-500/30 text-red-300 px-1.5 py-0.5 rounded-full">
                {favoriteIds.size}
              </span>
            )}
          </button>
          <button
            onClick={() => setActiveTab("vault")}
            className={`px-4 py-2 text-sm font-semibold rounded-t-lg transition-colors flex items-center gap-1.5 ${
              activeTab === "vault"
                ? "bg-yellow-600 text-white"
                : "text-white/50 hover:text-white hover:bg-white/5"
            }`}
          >
            <Shield className="w-3.5 h-3.5" />The Vault
            {vaultItems && vaultItems.length > 0 && (
              <span className="ml-1 text-[10px] bg-yellow-500/30 text-yellow-300 px-1.5 py-0.5 rounded-full">
                {vaultItems.length}
              </span>
            )}
          </button>
        </div>

        {/* Orders Tab Content */}
        {activeTab === "orders" && (
          <OrdersTabContent
            buyerOrders={buyerOrders}
            sellerOrders={sellerOrders}
            refetchBuyer={refetchBuyer}
            refetchSeller={refetchSeller}
          />
        )}
        {/* Favorites Tab Content */}
        {activeTab === "favorites" && (
          <div className="pb-10">
            <div className="flex items-center gap-3 mb-6">
              <Heart className="w-6 h-6 text-red-500 fill-red-500" />
              <div>
                <h2 className="text-2xl font-bold text-white">My Favorites</h2>
                <p className="text-sm text-white/40">Cards you've hearted from the Marketplace & Auctions</p>
              </div>
            </div>
            {!favoriteCards || favoriteCards.length === 0 ? (
              <div className="text-center py-20 text-white/30">
                <Heart className="w-16 h-16 mx-auto mb-4 text-white/10" />
                <h3 className="text-xl font-semibold mb-2 text-white/50">No favorites yet</h3>
                <p className="text-sm mb-4">Tap the ❤️ on any card in the Marketplace or Auctions to save it here</p>
                <Link href="/marketplace">
                  <button className="bg-[#c41e3a] text-white px-6 py-2 rounded-lg text-sm font-semibold hover:bg-[#a01830] transition-colors">
                    Browse Marketplace
                  </button>
                </Link>
              </div>
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
                {favoriteCards.map((card: any) => (
                  <Link key={card.id} href={`/marketplace/${card.id}`}>
                    <div className="rounded-xl overflow-hidden hover:scale-[1.02] hover:shadow-xl transition-all cursor-pointer group h-full flex flex-col">
                      <div className="relative aspect-[3/4] overflow-hidden">
                        <SlabFrame
                          imageUrl={card.frontImageUrl}
                          altText={card.title}
                          labelColor={card.labelColor ?? "dark"}
                          grade={card.gradeScore || card.aiGrade}
                          gradeLabel={card.aiGradeLabel}
                          gradeCompany={card.gradeCompany}
                          playerName={card.playerName}
                          setName={card.setName}
                          year={card.year}
                        />
                        <div className="absolute top-1.5 right-1.5">
                          <FavoriteButton cardId={card.id} initialFavorited={true} />
                        </div>
                      </div>
                      <div className="p-2 bg-[#0d1f3c] border border-t-0 border-white/10 rounded-b-xl">
                        <h3 className="font-semibold text-xs text-white mb-0.5 line-clamp-2">{card.title}</h3>
                        <p className="text-xs text-white/40 mb-1">{card.playerName}</p>
                        <p className="text-sm font-black text-green-400">${parseFloat(card.price ?? "0").toFixed(2)}</p>
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Vault Tab Content */}
        {activeTab === "vault" && (
          <div className="pb-10">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-12 h-12 rounded-xl bg-yellow-600/20 flex items-center justify-center">
                <Shield className="w-6 h-6 text-yellow-400" />
              </div>
              <div>
                <h2 className="text-2xl font-bold text-white">The Vault</h2>
                <p className="text-sm text-white/40">Cards stored & shipped by SportCards Online — 100% guaranteed</p>
              </div>
            </div>
            <div className="mb-4 p-4 rounded-xl bg-yellow-900/20 border border-yellow-600/30 text-yellow-200 text-sm">
              <Shield className="w-4 h-4 inline mr-2 text-yellow-400" />
              <strong>SCO Vault Guarantee:</strong> Cards stored here are physically held at SportCards Online (Secured Location). For cards shipped directly from us — either through a house trade or a vaulted item we ship on your behalf — we guarantee authenticity and safe delivery to the buyer.
            </div>
            {/* Vault-for-Credits Promo Banner */}
            <div className="mb-6 p-4 rounded-xl bg-gradient-to-r from-yellow-900/30 via-yellow-800/20 to-yellow-900/30 border border-yellow-500/40">
              <div className="flex items-start gap-3">
                <div className="text-2xl">⭐</div>
                <div className="flex-1">
                  <h3 className="font-bold text-yellow-300 text-sm mb-1">Trade Your Vaulted Cards for Game Room Credits!</h3>
                  <p className="text-yellow-200/70 text-xs leading-relaxed">
                    Since your cards are already here with us, you can exchange them for player credits instantly. We apply a small 10% vault handling fee, and you receive 90% of the card’s value in credits. The card returns to the SCO House collection and is relisted at auction automatically.
                  </p>
                  <p className="text-yellow-400/60 text-[10px] mt-1.5">
                    📌 Only available for SCO-vaulted cards. Other sellers’ cards are not eligible since we don’t physically hold them.
                  </p>
                </div>
              </div>
            </div>
            {!vaultItems || vaultItems.length === 0 ? (
              <div className="text-center py-20 text-white/30">
                <Shield className="w-16 h-16 mx-auto mb-4 text-yellow-600/30" />
                <h3 className="text-xl font-semibold mb-2 text-white/50">Your Vault is empty</h3>
                <p className="text-sm mb-4">Cards won in the Game Room are automatically sent to The Vault</p>
                <Link href="/game-room">
                  <button className="bg-yellow-600 text-white px-6 py-2 rounded-lg text-sm font-semibold hover:bg-yellow-700 transition-colors">
                    Go to Game Room
                  </button>
                </Link>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                {vaultItems.map((item: any) => {
                  const statusLabels: Record<string, { label: string; color: string }> = {
                    vaulted: { label: "In Vault", color: "bg-yellow-600/20 text-yellow-300 border-yellow-600/30" },
                    vault_listed: { label: "Listed", color: "bg-green-600/20 text-green-300 border-green-600/30" },
                    vault_auction: { label: "In Auction", color: "bg-purple-600/20 text-purple-300 border-purple-600/30" },
                    vault_sold: { label: "Sold", color: "bg-blue-600/20 text-blue-300 border-blue-600/30" },
                    vault_shipped: { label: "Shipping to You", color: "bg-orange-600/20 text-orange-300 border-orange-600/30" },
                  };
                  const st = statusLabels[item.listingStatus] ?? { label: item.listingStatus, color: "bg-white/10 text-white/50 border-white/10" };
                  return (
                    <div key={item.id} className="rounded-xl overflow-hidden border border-yellow-600/20 bg-[#0d1f3c] relative group">
                      {/* Gold guarantee ribbon */}
                      <div className="absolute top-2 left-2 z-10 bg-yellow-500 text-black text-[9px] font-black px-2 py-0.5 rounded-full flex items-center gap-1">
                        <Shield className="w-2.5 h-2.5" />SCO VAULTED
                      </div>
                      <div className="relative aspect-[3/4] overflow-hidden">
                        <SlabFrame
                          imageUrl={item.frontImageUrl}
                          altText={item.cardTitle}
                          labelColor={item.labelColor ?? "dark"}
                          grade={item.gradeScore || item.overallGrade}
                          gradeLabel={item.gradeLabel}
                          gradeCompany={item.gradeCompany}
                          playerName={item.playerName}
                        />
                      </div>
                      <div className="p-3">
                        <h3 className="font-semibold text-sm text-white mb-0.5 line-clamp-2">{item.cardTitle}</h3>
                        <p className="text-xs text-white/40 mb-2">{item.playerName} · {item.sport}</p>
                        <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full border ${st.color}`}>{st.label}</span>
                        {item.lifecycleNote && (
                          <p className="text-[10px] text-white/30 mt-1.5 line-clamp-2">{item.lifecycleNote}</p>
                        )}
                        {/* Action buttons — only show for 'vaulted' status */}
                        {item.listingStatus === "vaulted" && (
                          <div className="mt-3 flex flex-wrap gap-1.5">
                            <button
                              onClick={() => {
                                const price = prompt("List price (USD):");
                                if (price) vaultListCard.mutate({ collectionId: item.id, price });
                              }}
                              className="flex-1 text-[10px] font-semibold bg-green-700/30 hover:bg-green-700/50 text-green-300 border border-green-700/40 rounded-lg py-1.5 px-2 transition-colors"
                            >
                              LIST
                            </button>
                            <button
                              onClick={() => {
                                const price = prompt("Starting auction price (USD):");
                                if (price) vaultAuctionCard.mutate({ collectionId: item.id, startingPrice: price });
                              }}
                              className="flex-1 text-[10px] font-semibold bg-purple-700/30 hover:bg-purple-700/50 text-purple-300 border border-purple-700/40 rounded-lg py-1.5 px-2 transition-colors"
                            >
                              AUCTION
                            </button>
                            <button
                              onClick={() => { setShipToMeItem(item); setShipToMeDialogOpen(true); }}
                              className="w-full text-[10px] font-semibold bg-orange-700/30 hover:bg-orange-700/50 text-orange-300 border border-orange-700/40 rounded-lg py-1.5 px-2 transition-colors"
                            >
                              SHIP TO ME
                            </button>
                            {/* SELL FOR CREDITS — 10% vault fee, card returns to SCO House */}
                            <button
                              onClick={() => {
                                const cardValue = parseFloat(item.estimatedValueHigh ?? item.estimatedValueLow ?? "0");
                                if (cardValue <= 0) {
                                  toast.error("This card has no estimated value set. Contact support.");
                                  return;
                                }
                                const credits = Math.floor(cardValue * 0.9);
                                if (!confirm(`Exchange "${item.cardTitle}" for ${credits} credits?\n\nCard value: $${cardValue.toFixed(2)}\nVault fee (10%): $${(cardValue * 0.1).toFixed(2)}\nYou receive: ${credits} credits\n\nThe card will return to SCO House and be listed at auction.`)) return;
                                vaultSellForCredits.mutate({ collectionId: item.id });
                              }}
                              disabled={vaultSellForCredits.isPending}
                              className="w-full text-[10px] font-semibold bg-yellow-700/30 hover:bg-yellow-700/50 text-yellow-300 border border-yellow-700/40 rounded-lg py-1.5 px-2 transition-colors disabled:opacity-50"
                            >
                              ⭐ SELL FOR CREDITS
                            </button>
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
            {/* Ship-to-Me Dialog */}
            {shipToMeDialogOpen && shipToMeItem && (
              <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4">
                <div className="bg-[#0d1f3c] border border-yellow-600/30 rounded-2xl p-6 w-full max-w-md">
                  <div className="flex items-center gap-2 mb-4">
                    <Truck className="w-5 h-5 text-yellow-400" />
                    <h3 className="text-lg font-bold text-white">Ship Card to Me</h3>
                  </div>
                  <p className="text-sm text-white/50 mb-4">We'll ship <strong className="text-white">{shipToMeItem.cardTitle}</strong> directly to your address. Shipping fee: <strong className="text-yellow-400">${parseFloat(shipToMeItem.shippingFee ?? "9.99").toFixed(2)}</strong></p>
                  <div className="space-y-2">
                    {["name","address","city","state","zip"].map(field => (
                      <Input key={field} placeholder={field.charAt(0).toUpperCase() + field.slice(1)} value={(shipAddress as any)[field]} onChange={e => setShipAddress(a => ({...a, [field]: e.target.value}))} className="bg-white/5 border-white/10 text-white placeholder:text-white/30" />
                    ))}
                  </div>
                  <div className="flex gap-2 mt-4">
                    <Button variant="outline" className="flex-1 border-white/20 text-white/60" onClick={() => setShipToMeDialogOpen(false)}>Cancel</Button>
                    <Button className="flex-1 bg-yellow-600 hover:bg-yellow-700 text-white" onClick={() => {
                      if (!shipAddress.name || !shipAddress.address || !shipAddress.city || !shipAddress.state || !shipAddress.zip) {
                        toast.error("Please fill in all address fields");
                        return;
                      }
                      vaultSendToMe.mutate({ collectionId: shipToMeItem.id, ...shipAddress });
                      setShipToMeDialogOpen(false);
                    }}>Confirm & Request Shipping</Button>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* My Cards Tab Content — only show when activeTab === 'collection' */}
        {activeTab === "collection" && (
        <>
        {/* Header with action buttons */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6">
          <div>
            <h1 className="text-3xl font-bold">House Collection</h1>
            <p className="text-muted-foreground text-sm">SCO House inventory — grade, price, list to Arena or Auction</p>
          </div>
          <div className="flex flex-wrap gap-2">
            {/* Stock View toggle */}
            <Button
              variant={stockViewMode ? "default" : "outline"}
              className={`gap-2 ${stockViewMode ? "bg-yellow-500 text-black border-yellow-500 hover:bg-yellow-400" : "border-white/20 text-white/70 hover:bg-white/10"}`}
              onClick={() => { setStockViewMode(m => !m); setBulkMode(false); }}>
              <BarChart2 className="w-4 h-4" />
              {stockViewMode ? "Grid View" : "Stock View"}
            </Button>
            {/* Bulk mode toggle */}
            {!stockViewMode && (
            <Button
              variant="default"
              className={`gap-2 ${bulkMode ? "bg-green-600 hover:bg-green-500 text-white border-green-600" : "bg-[#c41e3a] hover:bg-[#a01830] text-white border-[#c41e3a]"}`}
              onClick={() => { setBulkMode(b => !b); setSelectedIds(new Set()); }}>
              <Check className="w-4 h-4" />
              {bulkMode ? `Bulk (${selectedIds.size})` : "Bulk Select"}
            </Button>
            )}
            {/* eBay Import */}
            <EbayImportModal onSuccess={() => refetch()} />
            {/* Upload Card */}
            <UploadCardModal onSuccess={() => refetch()} />
            {/* Grade Cards */}
            <Button asChild className="bg-[#c41e3a] hover:bg-[#c41e3a]/90 text-white gap-2">
              <Link href="/grade"><Camera className="w-4 h-4" />Grade a Card</Link>
            </Button>
          </div>
        </div>

        {/* Search */}
        <div className="relative mb-6">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input placeholder="Search your collection by player, set, or title..." value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} className="pl-10" />
        </div>

        {/* Auction limit warning */}
        {activeAuctionCount >= 10 && (
          <div className="flex items-center gap-2 bg-orange-500/10 border border-orange-500/30 rounded-lg p-3 mb-4 text-orange-400 text-sm">
            <AlertCircle className="w-4 h-4 shrink-0" />
            You have reached the maximum of 100 active auctions. End an existing auction before creating a new one.
          </div>
        )}

        {/* Bulk mode hint */}
        {bulkMode && (
          <div className="flex items-center justify-between gap-2 bg-[#c41e3a]/10 border border-[#c41e3a]/30 rounded-lg p-3 mb-4">
            <div className="flex items-center gap-2 text-[#ff6b6b] text-sm">
              <Check className="w-4 h-4 shrink-0" />
              <span>Bulk mode ON — click cards to select. {selectedIds.size > 0 ? `${selectedIds.size} selected.` : ""}</span>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setSelectedIds(new Set((filteredCollection || []).map(c => c.id)))}
                className="text-xs text-white/70 hover:text-white bg-white/10 hover:bg-white/20 rounded px-2 py-1 transition-colors font-medium">
                Select All ({filteredCollection?.length || 0})
              </button>
              {selectedIds.size > 0 && (
                <button
                  onClick={() => setSelectedIds(new Set())}
                  className="text-xs text-white/50 hover:text-white bg-white/5 hover:bg-white/10 rounded px-2 py-1 transition-colors">
                  Clear
                </button>
              )}
            </div>
          </div>
        )}

        {/* Stock View */}
        {stockViewMode && !isLoading && (
          <StockView collection={filteredCollection || []} />
        )}

        {/* Card Grid */}
        {!stockViewMode && isLoading ? (
          <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-7 xl:grid-cols-8 2xl:grid-cols-10 gap-2">
            {Array.from({ length: 16 }).map((_, i) => (
              <Card key={i} className="animate-pulse"><CardContent className="p-1.5"><div className="aspect-[5/7] bg-muted rounded mb-1" /><div className="h-2.5 bg-muted rounded mb-1" /><div className="h-4 bg-muted rounded" /></CardContent></Card>
            ))}
          </div>
        ) : filteredCollection && filteredCollection.length > 0 ? (
          <>
          <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-7 xl:grid-cols-8 2xl:grid-cols-10 gap-2">
            {paginatedCollection!.map((item) => {
              const status = cardStatusMap.get(item.id);
              const statusKey = status?.type || "available";
              const statusCfg = STATUS_CONFIG[statusKey];
              const isSelected = selectedIds.has(item.id);
              const extraCount = (item.extraImageUrls as string[] | null)?.length || 0;
              const totalImages = (item.frontImageUrl ? 1 : 0) + (item.backImageUrl ? 1 : 0) + extraCount;

              return (
                <Card key={item.id} className={`group transition-all ${bulkMode ? "cursor-pointer" : "hover:border-primary/50 hover:shadow-md"} ${isSelected ? "ring-2 ring-green-500 border-green-500/70 shadow-[0_0_12px_3px_rgba(34,197,94,0.4)]" : ""}`}
                  onClick={bulkMode ? () => toggleBulkSelect(item.id) : undefined}>
                  <CardContent className="p-1.5">
                    {/* Card Image */}
                    <div className="aspect-[5/7] bg-muted rounded mb-1 overflow-hidden relative">
                      {item.frontImageUrl ? (
                        <img src={item.frontImageUrl} alt={item.cardTitle} className={`w-full h-full object-contain transition-transform duration-300 ${!bulkMode ? "group-hover:scale-105" : ""}`} loading="lazy" decoding="async" />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center bg-gradient-to-b from-muted to-muted/50">
                          <Award className="w-10 h-10 text-muted-foreground/30" />
                        </div>
                      )}

                      {/* LED indicator dot — shows label border color */}
                      {(() => {
                        const borderColorMap: Record<string, { bg: string; border: string; shadow: string }> = {
                          red:    { bg: "#c41e3a", border: "#e8192c", shadow: "rgba(196,30,58,0.7)" },
                          blue:   { bg: "#1d4ed8", border: "#3b82f6", shadow: "rgba(29,78,216,0.7)" },
                          orange: { bg: "#ea6c0a", border: "#f97316", shadow: "rgba(249,115,22,0.7)" },
                          black:  { bg: "#111827", border: "#374151", shadow: "rgba(17,24,39,0.7)" },
                          white:  { bg: "#e5e7eb", border: "#ffffff", shadow: "rgba(229,231,235,0.7)" },
                        };
                        const lc = (item.labelBorder as string) || "red";
                        const c = borderColorMap[lc] ?? borderColorMap.red;
                        return (
                          <div
                            className="absolute top-1.5 left-1.5 w-5 h-5 rounded-full border-2 flex items-center justify-center transition-all duration-200 shadow-[0_0_6px_2px_rgba(0,0,0,0.4)]"
                            style={bulkMode && isSelected
                              ? { background: "#4ade80", borderColor: "#86efac", boxShadow: "0 0 8px 3px rgba(74,222,128,0.6)" }
                              : bulkMode
                              ? { background: "#166534", borderColor: "#4ade80", boxShadow: "0 0 6px 2px rgba(74,222,128,0.3)" }
                              : { background: c.bg, borderColor: c.border, boxShadow: `0 0 8px 3px ${c.shadow}` }
                            }
                            title={bulkMode ? undefined : `Label color: ${lc}`}
                          >
                            {bulkMode && isSelected && <Check className="w-3 h-3 text-white" strokeWidth={3} />}
                          </div>
                        );
                      })()}

                      {/* Status badge for listed/auction cards (shown when bulk is OFF) */}
                      {!bulkMode && statusCfg.icon && (
                        <div className={`absolute top-1 right-1 text-[8px] font-bold px-1 py-0.5 rounded-full leading-none ${statusCfg.color}`}>
                          {statusCfg.icon}
                        </div>
                      )}

                      {/* Selected overlay */}
                      {bulkMode && isSelected && (
                        <div className="absolute inset-0 bg-[#c41e3a]/20" />
                      )}

                      {/* Grade Badge */}
                      {item.overallGrade && (
                        <div className="absolute bottom-1 right-1 bg-[#0a1628]/90 text-white text-[9px] font-bold px-1.5 py-0.5 rounded-full border border-white/20 leading-none">
                          {parseFloat(item.overallGrade).toFixed(1)}
                        </div>
                      )}

                      {/* Photo count badge */}
                      {totalImages > 1 && !bulkMode && (
                        <div className="absolute bottom-1 left-1 bg-black/60 text-white/70 text-[8px] px-1 py-0.5 rounded-full flex items-center gap-0.5 leading-none">
                          <Eye className="w-2 h-2" />{totalImages}
                        </div>
                      )}
                    </div>

                    {/* Card Info */}
                    <h3 className="font-semibold text-[10px] mb-0 line-clamp-1 leading-tight">{item.playerName || item.cardTitle}</h3>
                    {item.estimatedValueLow && (
                      <p className="text-[9px] font-medium text-green-500 leading-tight">
                        ${parseFloat(item.estimatedValueLow).toFixed(0)}–${parseFloat(item.estimatedValueHigh || item.estimatedValueLow).toFixed(0)}
                      </p>
                    )}

                    {/* Actions (hidden in bulk mode) — appear on hover */}
                    {!bulkMode && (
                      !status ? (
                        <div className="flex gap-0.5 mt-1 opacity-0 group-hover:opacity-100 transition-opacity">
                          {/* View Detail */}
                          <Button size="sm" variant="ghost" className="h-6 w-6 p-0 text-muted-foreground hover:text-blue-400" title="View Details"
                            onClick={() => setDetailItem(item)}>
                            <Eye className="w-2.5 h-2.5" />
                          </Button>
                          {/* Label Color quick-access */}
                          <Button size="sm" variant="ghost" className="h-6 w-6 p-0 text-muted-foreground hover:text-yellow-400" title="Change Label Color"
                            onClick={() => setDetailItem(item)}>
                            <Palette className="w-2.5 h-2.5" />
                          </Button>

                          {/* List in Arena */}
                          <Dialog open={marketDialogOpen && selectedCard === item.id} onOpenChange={(o) => { setMarketDialogOpen(o); if (o) setSelectedCard(item.id); }}>
                            <DialogTrigger asChild>
                              <Button size="sm" variant="outline" className="flex-1 text-[9px] h-6 px-0.5">
                                <ShoppingCart className="w-2.5 h-2.5" />
                              </Button>
                            </DialogTrigger>
                            <DialogContent className="max-w-sm">
                              <DialogHeader><DialogTitle>List in the Arena</DialogTitle></DialogHeader>
                              <div className="space-y-4 pt-2">
                                <p className="text-sm text-muted-foreground">{item.cardTitle} — {item.playerName}</p>
                                <div>
                                  <label className="text-sm font-medium mb-1.5 block">Your Price ($)</label>
                                  <Input type="number" step="0.01" placeholder="e.g. 49.99" value={listingPrice} onChange={(e) => setListingPrice(e.target.value)} />
                                  <p className="text-xs text-muted-foreground mt-1">Platform fee: 5% on sale. Payment held in escrow until shipped.</p>
                                </div>
                                <div className="space-y-3 border border-white/10 rounded-lg p-3 bg-white/5">
                                    <div className="flex items-center gap-2 mb-1">
                                      <Palette className="w-3.5 h-3.5 text-yellow-400" />
                                      <p className="text-xs font-semibold text-white/70 uppercase tracking-wide">SCG Label Style</p>
                                    </div>
                                    <div className="flex items-center gap-2">
                                      <input type="checkbox" id="graded-toggle" checked={isGraded} onChange={(e) => setIsGraded(e.target.checked)} className="rounded" />
                                      <label htmlFor="graded-toggle" className="text-xs text-white/60">Show graded label on listing</label>
                                    </div>
                                    <div>
                                      <label className="text-xs text-muted-foreground mb-1 block">Background</label>
                                      <Select value={singleBg} onValueChange={(v) => setSingleBg(v as LabelBackground)}>
                                        <SelectTrigger className="h-8 text-xs"><SelectValue /></SelectTrigger>
                                        <SelectContent>
                                          {LABEL_BACKGROUNDS.map(bg => (
                                            <SelectItem key={bg.value} value={bg.value} className="text-xs">{bg.label}</SelectItem>
                                          ))}
                                        </SelectContent>
                                      </Select>
                                    </div>
                                    <div>
                                      <label className="text-xs text-muted-foreground mb-1 block">Border Color</label>
                                      <Select value={singleBorder} onValueChange={(v) => setSingleBorder(v as LabelBorderColor)}>
                                        <SelectTrigger className="h-8 text-xs"><SelectValue /></SelectTrigger>
                                        <SelectContent>
                                          {LABEL_BORDER_COLORS.map(bc => (
                                            <SelectItem key={bc.value} value={bc.value} className="text-xs">
                                              <span className="flex items-center gap-2">
                                                <span className="w-3 h-3 rounded-full inline-block border border-white/20" style={{ background: bc.hex }} />
                                                {bc.label}
                                              </span>
                                            </SelectItem>
                                          ))}
                                        </SelectContent>
                                      </Select>
                                    </div>
                                  </div>
                                <Button className="w-full bg-[#c41e3a] hover:bg-[#c41e3a]/90 text-white" onClick={handleListToArena} disabled={listToArena.isPending}>
                                  {listToArena.isPending ? "Listing..." : "🏟️ List in Arena"}
                                </Button>
                              </div>
                            </DialogContent>
                          </Dialog>

                          {/* Auction */}
                          <Dialog open={auctionDialogOpen && activeAuctionItem?.id === item.id} onOpenChange={(o) => { setAuctionDialogOpen(o); if (o) setActiveAuctionItem(item); }}>
                            <DialogTrigger asChild>
                              <Button size="sm" variant="outline" className="flex-1 text-[9px] h-6 px-0.5" disabled={activeAuctionCount >= 10}>
                                <Gavel className="w-2.5 h-2.5" />
                              </Button>
                            </DialogTrigger>
                            <DialogContent className="max-w-sm">
                              <DialogHeader><DialogTitle>🔨 Create Auction</DialogTitle></DialogHeader>
                              <div className="space-y-4 pt-2">
                                <p className="text-sm text-muted-foreground">{item.cardTitle} — {item.playerName}</p>
                                <div>
                                  <label className="text-sm font-medium mb-1.5 block">Starting Bid ($)</label>
                                  <Input type="number" step="0.01" placeholder="e.g. 19.99" value={auctionStartPrice} onChange={(e) => setAuctionStartPrice(e.target.value)} />
                                </div>
                                <div className="bg-muted/50 rounded-lg p-3 text-sm space-y-1.5">
                                  <div className="flex justify-between items-center">
                                    <span className="text-muted-foreground">Duration</span>
                                    <span className="font-semibold text-orange-400">3 Days</span>
                                  </div>
                                  <div className="flex justify-between items-center">
                                    <span className="text-muted-foreground">Listing fee</span>
                                    <span className="font-semibold">1 credit</span>
                                  </div>
                                  <div className="flex justify-between items-center">
                                    <span className="text-muted-foreground">Platform fee on sale</span>
                                    <span className="font-semibold">10%</span>
                                  </div>
                                  <div className="flex justify-between items-center">
                                    <span className="text-muted-foreground">Renewal</span>
                                    <span className="font-semibold">1 credit / 3 days</span>
                                  </div>
                                  <div className="border-t border-white/10 pt-1.5 flex justify-between items-center">
                                    <span className="text-muted-foreground">Your credits</span>
                                    <span className={`font-bold ${(creditAccount?.credits || 0) < 1 ? "text-red-500" : "text-green-400"}`}>{creditAccount?.credits || 0}</span>
                                  </div>
                                  <div className="flex justify-between items-center">
                                    <span className="text-muted-foreground">Active auctions</span>
                                    <span className="font-medium">{activeAuctionCount}/10</span>
                                  </div>
                                </div>
                                {(creditAccount?.credits || 0) < 1 && (
                                  <div className="flex items-center gap-2 text-red-400 text-xs">
                                    <AlertCircle className="w-3.5 h-3.5" />Not enough credits. <Link href="/credits?from=/my-collection" className="underline">Buy more credits</Link>
                                  </div>
                                )}
                                <Button className="w-full bg-orange-500 hover:bg-orange-600 text-white" onClick={handleListToAuction} disabled={createAuction.isPending || (creditAccount?.credits || 0) < 1}>
                                  {createAuction.isPending ? "Creating..." : "Start 3-Day Auction — 1 Credit"}
                                </Button>
                              </div>
                            </DialogContent>
                          </Dialog>

                          <Button size="sm" variant="ghost" className="h-6 w-6 p-0 text-muted-foreground hover:text-red-500" onClick={() => handleDelete(item.id)}>
                            <Trash2 className="w-2.5 h-2.5" />
                          </Button>
                        </div>
                      ) : (
                        <div className="mt-1 opacity-0 group-hover:opacity-100 transition-opacity">
                          <div className="flex gap-0.5">
                            <Button size="sm" variant="ghost" className="h-6 w-6 p-0 text-muted-foreground hover:text-blue-400" title="View Details"
                              onClick={() => setDetailItem(item)}>
                              <Eye className="w-2.5 h-2.5" />
                            </Button>
                            <Button size="sm" variant="outline" className="flex-1 text-[9px] h-6 px-0.5" asChild>
                              <Link href={status.type === "auction" ? `/auctions/${status.id}` : `/arena/${status.id}`}>
                                ↗
                              </Link>
                            </Button>
                          </div>
                        </div>
                      )
                    )}
                  </CardContent>
                </Card>
              );
            })}
          </div>

          {/* Pagination */}
          {totalPages > 1 && (
            <div className="flex items-center justify-center gap-2 mt-6 flex-wrap">
              <button onClick={() => setCurrentPage(1)} disabled={currentPage === 1}
                className="px-3 py-1.5 text-xs rounded-lg border border-white/10 text-white/50 hover:text-white hover:border-white/30 disabled:opacity-30 disabled:cursor-not-allowed transition-all">
                «
              </button>
              <button onClick={() => setCurrentPage(p => Math.max(1, p - 1))} disabled={currentPage === 1}
                className="px-3 py-1.5 text-xs rounded-lg border border-white/10 text-white/50 hover:text-white hover:border-white/30 disabled:opacity-30 disabled:cursor-not-allowed transition-all">
                ‹ Prev
              </button>
              {Array.from({ length: Math.min(7, totalPages) }, (_, i) => {
                const start = Math.max(1, Math.min(currentPage - 3, totalPages - 6));
                const page = start + i;
                if (page > totalPages) return null;
                return (
                  <button key={page} onClick={() => setCurrentPage(page)}
                    className={`px-3 py-1.5 text-xs rounded-lg border transition-all ${
                      page === currentPage
                        ? "bg-[#c41e3a] border-[#c41e3a] text-white font-bold"
                        : "border-white/10 text-white/50 hover:text-white hover:border-white/30"
                    }`}>
                    {page}
                  </button>
                );
              })}
              <button onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))} disabled={currentPage === totalPages}
                className="px-3 py-1.5 text-xs rounded-lg border border-white/10 text-white/50 hover:text-white hover:border-white/30 disabled:opacity-30 disabled:cursor-not-allowed transition-all">
                Next ›
              </button>
              <button onClick={() => setCurrentPage(totalPages)} disabled={currentPage === totalPages}
                className="px-3 py-1.5 text-xs rounded-lg border border-white/10 text-white/50 hover:text-white hover:border-white/30 disabled:opacity-30 disabled:cursor-not-allowed transition-all">
                »
              </button>
              <span className="text-xs text-white/30 ml-2">
                {(currentPage - 1) * PAGE_SIZE + 1}–{Math.min(currentPage * PAGE_SIZE, filteredCollection?.length || 0)} of {filteredCollection?.length || 0} cards
              </span>
            </div>
          )}
          </>
        ) : myCards && myCards.length > 0 ? (
          <>
            {/* Marketplace inventory (cards table) — shown when no personal collection items */}
            <div className="mb-3 flex items-center gap-2">
              <span className="text-xs text-white/40 bg-white/5 border border-white/10 rounded px-2 py-1">House Inventory — {myCards.length} cards</span>
            </div>
            <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-7 xl:grid-cols-8 2xl:grid-cols-10 gap-2">
              {myCards.filter(card => {
                if (!searchQuery) return true;
                const q = searchQuery.toLowerCase();
                return (card.playerName || "").toLowerCase().includes(q) || (card.title || "").toLowerCase().includes(q) || (card.setName || "").toLowerCase().includes(q);
              }).map((card) => {
                const statusKey = card.status === "active" ? "marketplace" : card.status === "auction" ? "auction" : "available";
                const statusCfg = STATUS_CONFIG[statusKey];
                return (
                  <Card key={`mc-${card.id}`} className="group hover:border-primary/50 hover:shadow-md transition-all cursor-pointer"
                    onClick={() => window.location.href = `/card/${card.id}`}>
                    <CardContent className="p-1.5">
                      <div className="aspect-[5/7] bg-muted rounded mb-1 overflow-hidden relative">
                        {card.frontImageUrl ? (
                          <img src={card.frontImageUrl} alt={card.title} className="w-full h-full object-contain group-hover:scale-105 transition-transform duration-300" loading="lazy" decoding="async" />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center bg-gradient-to-b from-muted to-muted/50">
                            <Award className="w-10 h-10 text-muted-foreground/30" />
                          </div>
                        )}
                        {statusCfg.icon && (
                          <div className={`absolute top-1 right-1 text-[8px] font-bold px-1 py-0.5 rounded-full leading-none ${statusCfg.color}`}>
                            {statusCfg.icon}
                          </div>
                        )}
                        {card.aiGrade && (
                          <div className="absolute bottom-1 right-1 bg-[#0a1628]/90 text-white text-[9px] font-bold px-1.5 py-0.5 rounded-full border border-white/20 leading-none">
                            {parseFloat(String(card.aiGrade)).toFixed(1)}
                          </div>
                        )}
                      </div>
                      <h3 className="font-semibold text-[10px] mb-0 line-clamp-1 leading-tight">{card.playerName || card.title}</h3>
                      {card.price && (
                        <p className="text-[9px] font-medium text-green-500 leading-tight">${parseFloat(String(card.price)).toFixed(2)}</p>
                      )}
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </>
        ) : (
          <div className="text-center py-20">
            <Award className="w-20 h-20 text-muted-foreground/20 mx-auto mb-4" />
            <h3 className="text-2xl font-bold mb-2">Your collection is empty</h3>
            <p className="text-muted-foreground mb-6">Upload a card, import from eBay, or grade a card to add it here.</p>
            <div className="flex flex-wrap gap-3 justify-center">
              <UploadCardModal onSuccess={() => refetch()} />
              <Button asChild size="lg" className="bg-[#c41e3a] hover:bg-[#c41e3a]/90 text-white gap-2">
                <Link href="/grade"><Camera className="w-4 h-4" />Grade My First Card</Link>
              </Button>
            </div>
          </div>
        )}
        </>
        )}
      </div>

      {/* Bulk action toolbar — shows as soon as bulk mode is ON */}
      {bulkMode && (
        <>
          <BulkActionBar
            count={selectedIds.size}
            onClear={() => { setSelectedIds(new Set()); setBulkMode(false); }}
            onSelectAll={() => setSelectedIds(new Set((filteredCollection || []).map(c => c.id)))}
            onDelete={handleBulkDelete}
            onListToArena={() => setBulkArenaOpen(true)}
            onPrint={handleBulkPrint}
            onLabelColor={handleBulkLabelColor}
            onPreview={() => setShowLabelPreview(true)}
            bulkLabelColor={bulkLabelColor}
            setBulkLabelColor={setBulkLabelColor}
            bulkBg={bulkBg}
            setBulkBg={setBulkBg}
            bulkBorder={bulkBorder}
            setBulkBorder={setBulkBorder}
          />

          {/* Bulk Marketplace listing dialog */}
          <Dialog open={bulkArenaOpen} onOpenChange={setBulkArenaOpen}>
            <DialogContent className="max-w-sm">
              <DialogHeader><DialogTitle>List {selectedIds.size} Cards to Marketplace</DialogTitle></DialogHeader>
              <div className="space-y-4 pt-2">
                <p className="text-sm text-muted-foreground">Set a price for all {selectedIds.size} selected cards. You can update individual prices later from your collection.</p>
                <div>
                  <label className="text-sm font-medium mb-1.5 block">Price per card ($)</label>
                  <Input type="number" step="0.01" placeholder="e.g. 29.99" value={bulkArenaPrice} onChange={(e) => setBulkArenaPrice(e.target.value)} />
                </div>
                <Button className="w-full bg-blue-600 hover:bg-blue-700 text-white" onClick={handleBulkListToArena} disabled={bulkListToArena.isPending}>
                  {bulkListToArena.isPending ? "Listing..." : `🏷️ List ${selectedIds.size} Cards to Marketplace`}
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </>
      )}

      {/* Card Detail Popup */}
      {detailItem && (
        <CardDetailModal
          item={detailItem}
          onClose={() => setDetailItem(null)}
          onUpdate={() => { refetch(); }}
        />
      )}

      {/* Label Preview Modal */}
      {showLabelPreview && (
        <div className="fixed inset-0 z-[80] bg-black/70 flex items-center justify-center p-4" onClick={() => setShowLabelPreview(false)}>
          <div className="bg-white rounded-2xl shadow-2xl p-6 max-w-sm w-full" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-bold text-gray-900 flex items-center gap-2"><Palette className="w-5 h-5 text-[#c41e3a]" />Label Preview</h3>
              <button onClick={() => setShowLabelPreview(false)} className="text-gray-400 hover:text-gray-700"><X className="w-5 h-5" /></button>
            </div>
            <p className="text-sm text-gray-500 mb-4">This is how your label will look with the selected style. Click Apply to update all selected cards.</p>
            <div className="flex justify-center mb-5">
              <div className="w-48">
                <SlabFrame
                  imageUrl={(filteredCollection?.[0]?.frontImageUrl) ?? ""}
                  altText="Preview"
                  grade={parseFloat(filteredCollection?.[0]?.overallGrade ?? "9") || 9}
                  gradeLabel={filteredCollection?.[0]?.gradeLabel ?? "MINT"}
                  playerName={filteredCollection?.[0]?.playerName ?? "Player Name"}
                  certNumber={filteredCollection?.[0]?.certNumber ?? "SCG-00000"}
                  labelBg={bulkBg}
                  labelBorder={bulkBorder}
                  showScoLabel={true}
                  className="w-full"
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3 mb-4">
              <div>
                <div className="text-xs text-gray-500 mb-1.5 font-medium uppercase tracking-wide">Background</div>
                <select value={bulkBg} onChange={e => setBulkBg(e.target.value as LabelBackground)}
                  className="w-full h-9 text-sm bg-white border border-gray-300 text-gray-700 rounded-lg px-2 cursor-pointer">
                  {LABEL_BACKGROUNDS.map(b => <option key={b.value} value={b.value}>{b.label}</option>)}
                </select>
              </div>
              <div>
                <div className="text-xs text-gray-500 mb-1.5 font-medium uppercase tracking-wide">Border Color</div>
                <div className="flex gap-2 flex-wrap mt-1">
                  {LABEL_BORDER_COLORS.map(bc => (
                    <button key={bc.value} title={bc.label}
                      onClick={() => setBulkBorder(bc.value as LabelBorderColor)}
                      className={`w-8 h-8 rounded-full border-2 transition-all ${
                        bulkBorder === bc.value ? "border-gray-900 scale-110 shadow-md" : "border-gray-300 hover:border-gray-600"
                      }`}
                      style={{ backgroundColor: bc.hex }}
                    />
                  ))}
                </div>
              </div>
            </div>
            <div className="flex gap-2">
              <Button className="flex-1 bg-yellow-500 hover:bg-yellow-400 text-black font-bold" onClick={() => { handleBulkLabelColor(); setShowLabelPreview(false); }} disabled={selectedIds.size === 0}>
                <Palette className="w-4 h-4 mr-1.5" />Apply to {selectedIds.size} Card{selectedIds.size !== 1 ? "s" : ""}
              </Button>
              <Button variant="outline" onClick={() => setShowLabelPreview(false)}>Cancel</Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
