/**
 * CardProfile — The unified "card passport" page.
 *
 * Accessible at /card/:id from anywhere (House Collection, Auctions, Casino,
 * Marketplace, Trades). Shows the same card data to everyone; owner gets
 * additional admin actions.
 *
 * Layout:
 *   Left  — image gallery (front, back, extras) with slab frame
 *   Right — card details + owner actions / public actions
 */
import { useState, useEffect } from "react";
import { useRoute, Link, useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { SlabFrame } from "@/components/SlabFrame";
import { useCart } from "@/contexts/CartContext";
import { toast } from "sonner";
import {
  ArrowLeft, Award, ZoomIn, ShoppingCart, Check, Gavel, Dice5,
  Tag, Package, Pencil, Shield, ChevronLeft, ChevronRight,
  Share2, Link2, Twitter, Facebook, X as XIcon, ExternalLink,
  Clock, History, TrendingUp, Banknote, Zap, Trash2,
} from "lucide-react";
import { proxyImageUrl } from "@/lib/utils";

// ── Status config ─────────────────────────────────────────────────────────────
const STATUS_CFG: Record<string, { label: string; color: string }> = {
  bank:    { label: "In House",    color: "bg-indigo-500/20 text-indigo-300 border-indigo-500/30" },
  draft:   { label: "Draft",       color: "bg-gray-500/20 text-gray-400 border-gray-500/30" },
  active:  { label: "Listed",      color: "bg-green-500/20 text-green-400 border-green-500/30" },
  auction: { label: "In Auction",  color: "bg-orange-500/20 text-orange-400 border-orange-500/30" },
  casino:  { label: "At Casino",   color: "bg-yellow-500/20 text-yellow-300 border-yellow-500/30" },
  sold:    { label: "Sold",        color: "bg-blue-500/20 text-blue-400 border-blue-500/30" },
  traded:  { label: "Traded",      color: "bg-purple-500/20 text-purple-400 border-purple-500/30" },
};

// ── Fullscreen lightbox ───────────────────────────────────────────────────────
function Lightbox({ images, startIndex, onClose }: { images: string[]; startIndex: number; onClose: () => void }) {
  const [idx, setIdx] = useState(startIndex);
  useEffect(() => {
    const h = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
      if (e.key === "ArrowRight") setIdx(i => (i + 1) % images.length);
      if (e.key === "ArrowLeft") setIdx(i => (i - 1 + images.length) % images.length);
    };
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  }, [images.length, onClose]);
  return (
    <div className="fixed inset-0 z-[200] bg-black/95 flex items-center justify-center" onClick={onClose}>
      <button className="absolute top-4 right-4 text-white/70 hover:text-white" onClick={onClose}>
        <XIcon className="w-7 h-7" />
      </button>
      {images.length > 1 && (
        <button className="absolute left-4 top-1/2 -translate-y-1/2 text-white/70 hover:text-white"
          onClick={e => { e.stopPropagation(); setIdx(i => (i - 1 + images.length) % images.length); }}>
          <ChevronLeft className="w-10 h-10" />
        </button>
      )}
      <img src={images[idx]} alt="" className="max-w-[90vw] max-h-[90vh] object-contain"
        onClick={e => e.stopPropagation()} />
      {images.length > 1 && (
        <button className="absolute right-4 top-1/2 -translate-y-1/2 text-white/70 hover:text-white"
          onClick={e => { e.stopPropagation(); setIdx(i => (i + 1) % images.length); }}>
          <ChevronRight className="w-10 h-10" />
        </button>
      )}
      {images.length > 1 && (
        <div className="absolute bottom-6 flex gap-2">
          {images.map((_, i) => (
            <button key={i} onClick={e => { e.stopPropagation(); setIdx(i); }}
              className={`w-2 h-2 rounded-full transition-colors ${i === idx ? "bg-white" : "bg-white/30"}`} />
          ))}
        </div>
      )}
    </div>
  );
}

// ── Owner edit dialog ─────────────────────────────────────────────────────────
function OwnerEditDialog({ card, onDone }: { card: any; onDone: () => void }) {
  const [open, setOpen] = useState(false);
  const [price, setPrice] = useState(card.price ? parseFloat(card.price).toFixed(2) : "");
  const [status, setStatus] = useState(card.status ?? "bank");
  const [description, setDescription] = useState(card.description ?? "");
  const update = trpc.admin.adminUpdateCard.useMutation({
    onSuccess: () => { toast.success("Card updated"); setOpen(false); onDone(); },
    onError: (e: any) => toast.error(e.message),
  });
  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm" className="gap-2 border-white/20 text-white/70 hover:bg-white/10">
          <Pencil className="w-4 h-4" /> Edit Card
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-sm">
        <DialogHeader><DialogTitle>Edit Card</DialogTitle></DialogHeader>
        <div className="space-y-3 pt-1">
          <div>
            <label className="text-xs font-medium text-white/60 mb-1 block">Price ($)</label>
            <Input value={price} onChange={e => setPrice(e.target.value)} placeholder="e.g. 49.99" type="number" step="0.01" />
          </div>
          <div>
            <label className="text-xs font-medium text-white/60 mb-1 block">Status</label>
            <Select value={status} onValueChange={setStatus}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {Object.entries(STATUS_CFG).map(([v, c]) => (
                  <SelectItem key={v} value={v}>{c.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div>
            <label className="text-xs font-medium text-white/60 mb-1 block">Description</label>
            <textarea
              value={description}
              onChange={e => setDescription(e.target.value)}
              className="w-full rounded-md border border-white/20 bg-white/5 text-white text-sm p-2 resize-none h-20"
              placeholder="Card notes, condition details..."
            />
          </div>
          <Button className="w-full bg-[#c41e3a] hover:bg-[#a01830] text-white" disabled={update.isPending}
            onClick={() => update.mutate({ cardId: card.id, price: price || undefined, status })}>
            {update.isPending ? "Saving..." : "Save Changes"}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

// ── Owner auction dialog ──────────────────────────────────────────────────────
function OwnerAuctionDialog({ card, onDone }: { card: any; onDone: () => void }) {
  const [open, setOpen] = useState(false);
  const vaultPrice = card.price ? parseFloat(String(card.price)) : 0;
  const [startPrice, setStartPrice] = useState((vaultPrice * 0.70).toFixed(2));
  const [duration, setDuration] = useState(7);
  const createAuction = trpc.auctions.create.useMutation({
    onSuccess: () => { toast.success("Auction started!"); setOpen(false); onDone(); },
    onError: (e: any) => toast.error(e.message),
  });
  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm" className="gap-2 border-orange-500/40 text-orange-400 hover:bg-orange-500/10">
          <Gavel className="w-4 h-4" /> Send to Auction
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-sm">
        <DialogHeader><DialogTitle>Send to Auction</DialogTitle></DialogHeader>
        <div className="space-y-3 pt-1">
          <p className="text-sm text-muted-foreground">{card.playerName} — {card.title}</p>
          {vaultPrice > 0 && (
            <div className="bg-orange-500/10 border border-orange-500/20 rounded-lg p-3 text-xs">
              <p className="text-orange-300 font-semibold">House price: ${vaultPrice.toFixed(2)}</p>
              <p className="text-white/60 mt-0.5">Starting bid set at 70% = <span className="text-white font-bold">${(vaultPrice * 0.70).toFixed(2)}</span></p>
            </div>
          )}
          <div>
            <label className="text-xs font-medium text-white/60 mb-1 block">Starting Bid ($)</label>
            <Input value={startPrice} onChange={e => setStartPrice(e.target.value)} type="number" step="0.01" />
          </div>
          <div>
            <label className="text-xs font-medium text-white/60 mb-1 block">Duration</label>
            <Select value={String(duration)} onValueChange={v => setDuration(Number(v))}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="5">5 days (3 credits)</SelectItem>
                <SelectItem value="7">7 days (5 credits)</SelectItem>
                <SelectItem value="10">10 days (8 credits)</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <Button className="w-full bg-orange-600 hover:bg-orange-500 text-white" disabled={createAuction.isPending}
            onClick={() => createAuction.mutate({
              cardId: card.id,
              cardTitle: card.title,
              cardImageUrl: card.frontImageUrl ?? undefined,
              startingPrice: startPrice,
              durationDays: duration,
              playerName: card.playerName ?? undefined,
              gradeInfo: card.aiGrade ? `SCO AI Grade ${card.aiGrade}` : undefined,
            })}>
            {createAuction.isPending ? "Starting..." : "🔨 Start Auction"}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

// ── Main page ─────────────────────────────────────────────────────────────────
export default function CardProfile() {
  const [, params] = useRoute("/card/:id");
  const id = parseInt(params?.id || "0");
  const { isAuthenticated, user } = useAuth();
  const isAdmin = (user as any)?.role === "admin";
  const [, navigate] = useLocation();
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const deleteCardMutation = trpc.cards.delete.useMutation({
    onSuccess: () => { toast.success("Card deleted."); navigate("/marketplace"); },
    onError: (e: any) => toast.error(e.message || "Delete failed"),
  });

  const { data: card, isLoading, refetch } = trpc.cards.getById.useQuery({ id }, { enabled: id > 0 });
  const { addItem, removeItem, isInCart } = useCart();
  const createCheckout = trpc.orders.createCheckoutSession.useMutation();
  const updateStatus = trpc.admin.adminUpdateCard.useMutation({
    onSuccess: () => { toast.success("Status updated"); refetch(); },
    onError: (e: any) => toast.error(e.message),
  });

  const [activeImg, setActiveImg] = useState(0);
  const [lightboxOpen, setLightboxOpen] = useState(false);
  const [addedToCart, setAddedToCart] = useState(false);
  const [shareOpen, setShareOpen] = useState(false);

  useEffect(() => { setActiveImg(0); setAddedToCart(false); }, [id]);

  // Dynamic SEO: update document title + inject Product schema when card loads
  useEffect(() => {
    if (!card) return;
    const grade = card.aiGrade ? ` SCG ${card.aiGrade}` : "";
    const sport = card.sport ? ` ${card.sport}` : "";
    const pageTitle = `${card.playerName ?? card.title}${grade}${sport} Card | SportCardsOnline.com`;
    document.title = pageTitle;

    // Update meta description
    let metaDesc = document.querySelector('meta[name="description"]');
    if (!metaDesc) { metaDesc = document.createElement('meta'); metaDesc.setAttribute('name', 'description'); document.head.appendChild(metaDesc); }
    const priceStr = card.price ? `$${parseFloat(String(card.price)).toFixed(2)}` : 'Contact for price';
    metaDesc.setAttribute('content', `Buy ${card.title}${grade} — ${sport} sports card. ${priceStr}. ${card.description ?? 'BGS graded and raw cards available at SportCardsOnline.com.'}`);

    // Inject Product JSON-LD schema
    const schemaId = 'card-product-schema';
    let existing = document.getElementById(schemaId);
    if (!existing) { existing = document.createElement('script'); existing.id = schemaId; existing.setAttribute('type', 'application/ld+json'); document.head.appendChild(existing); }
    const schema: any = {
      '@context': 'https://schema.org',
      '@type': 'Product',
      name: card.title,
      description: card.description ?? `${card.playerName ?? ''} ${card.sport ?? ''} sports card${grade}`,
      url: `https://www.sportcardsonline.com/card/${card.id}`,
      brand: { '@type': 'Brand', name: 'SportCardsOnline.com' },
      category: card.sport ?? 'Sports Cards',
    };
    if (card.frontImageUrl) schema.image = [card.frontImageUrl];
    if (card.price) {
      schema.offers = {
        '@type': 'Offer',
        price: parseFloat(String(card.price)).toFixed(2),
        priceCurrency: 'USD',
        availability: card.status === 'active' ? 'https://schema.org/InStock' : 'https://schema.org/OutOfStock',
        url: `https://www.sportcardsonline.com/card/${card.id}`,
        seller: { '@type': 'Organization', name: 'SportCardsOnline.com' },
      };
    }
    if (card.aiGrade) schema.additionalProperty = [{ '@type': 'PropertyValue', name: 'Grade', value: String(card.aiGrade) }];
    existing.textContent = JSON.stringify(schema);

    // Cleanup on unmount
    return () => {
      document.title = 'SportCardsOnline.com — Buy, Sell, Trade & Grade Sports Cards';
      const s = document.getElementById(schemaId);
      if (s) s.remove();
    };
  }, [card]);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#0a0f1e] flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-[#c41e3a]/30 border-t-[#c41e3a] rounded-full animate-spin mx-auto mb-4" />
          <p className="text-white/40 text-sm">Loading card...</p>
        </div>
      </div>
    );
  }

  if (!card) {
    return (
      <div className="min-h-screen bg-[#0a0f1e] flex items-center justify-center">
        <div className="text-center">
          <Award className="w-20 h-20 text-white/10 mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-white mb-2">Card Not Found</h2>
          <p className="text-white/40 mb-6">This card may have been removed or the link is invalid.</p>
          <Button asChild variant="outline" className="border-white/20 text-white/70">
            <Link href="/">← Back to Home</Link>
          </Button>
        </div>
      </div>
    );
  }

  // Build image list: front, back, extras (proxy eBay images to avoid hotlink blocking)
  const images = [
    proxyImageUrl(card.frontImageUrl),
    proxyImageUrl(card.backImageUrl),
    ...((card.extraImageUrls as string[] | null) || []).map(proxyImageUrl),
  ].filter(Boolean) as string[];

  const statusCfg = STATUS_CFG[card.status ?? "draft"] ?? STATUS_CFG["draft"];
  const gradeDisplay = card.aiGrade ? String(card.aiGrade) : null;
  const price = card.price ? parseFloat(String(card.price)) : null;
  const inCart = isInCart(card.id);

  const handleAddToCart = () => {
    if (inCart) { removeItem(card.id); toast.success("Removed from cart"); return; }
    addItem({
      id: card.id,
      title: card.title,
      playerName: card.playerName,
      price: card.price || "0",
      frontImageUrl: card.frontImageUrl,
      sellerEmail: card.sellerEmail,
      storeName: card.storeName,
      aiGrade: card.aiGrade ? String(card.aiGrade) : undefined,
      aiGradeLabel: card.aiGradeLabel,
    });
    setAddedToCart(true);
    toast.success("Added to cart!");
  };

  const handleBuyNow = async () => {
    if (!isAuthenticated) { window.location.href = getLoginUrl(); return; }
    try {
      const { checkoutUrl } = await createCheckout.mutateAsync({
        cardId: card.id,
        cardTitle: card.title,
        price: card.price || "0",
        sellerEmail: card.sellerEmail,
        cardImageUrl: card.frontImageUrl ?? undefined,
        origin: window.location.origin,
      });
      window.open(checkoutUrl, "_blank");
      toast.info("Redirecting to checkout...");
    } catch (e: any) {
      toast.error(e.message || "Checkout failed");
    }
  };

  const shareUrl = window.location.href;
  const shareText = `Check out this card: ${card.playerName} — ${card.title}`;

  return (
    <div className="min-h-screen bg-[#0a0f1e] pb-16">
      {lightboxOpen && images.length > 0 && (
        <Lightbox images={images} startIndex={activeImg} onClose={() => setLightboxOpen(false)} />
      )}

      {/* ── Back nav ── */}
      <div className="border-b border-white/10 bg-[#0d1628]">
        <div className="max-w-6xl mx-auto px-4 py-3 flex items-center gap-3">
          <button onClick={() => window.history.back()}
            className="flex items-center gap-1.5 text-white/50 hover:text-white text-sm transition-colors">
            <ArrowLeft className="w-4 h-4" /> Back
          </button>
          <span className="text-white/20">/</span>
          <span className="text-white/50 text-sm truncate max-w-xs">{card.playerName}</span>
          <div className="ml-auto flex items-center gap-2">
            <Badge className={`text-xs border ${statusCfg.color}`}>{statusCfg.label}</Badge>
            {isAdmin && (
              <Badge className="text-xs bg-[#c41e3a]/20 text-[#c41e3a] border border-[#c41e3a]/30">
                <Shield className="w-3 h-3 mr-1" /> Owner
              </Badge>
            )}
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">

          {/* ── LEFT: Image gallery ── */}
          <div className="space-y-4">
            {/* Main image with slab frame */}
            <div className="relative aspect-[3/4] max-w-sm mx-auto cursor-pointer group"
              onClick={() => images.length > 0 && setLightboxOpen(true)}>
              <SlabFrame
                imageUrl={images[activeImg] ?? null}
                altText={card.title}
                labelColor={(card.labelColor as any) ?? "dark"}
                labelBg={(card as any).labelBg}
                labelBorder={(card as any).labelBorder}
                labelMode={(card as any).labelMode}
                grade={(card as any).gradeScore || gradeDisplay}
                gradeLabel={card.aiGradeLabel ?? null}
                gradeCompany={(card as any).gradeCompany}
                playerName={card.playerName}
                setName={card.setName}
                year={card.year}
                cardNumber={card.cardNumber}
                certNumber={card.certNumber}
                cardId={card.id}
                isBack={activeImg === 1}
              />
              {images.length > 0 && (
                <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                  <div className="bg-black/60 rounded-full p-3">
                    <ZoomIn className="w-6 h-6 text-white" />
                  </div>
                </div>
              )}
            </div>

            {/* Thumbnail strip */}
            {images.length > 1 && (
              <div className="flex gap-2 justify-center flex-wrap">
                {images.map((img, i) => (
                  <button key={i} onClick={() => setActiveImg(i)}
                    className={`w-14 h-20 rounded overflow-hidden border-2 transition-all ${
                      i === activeImg ? "border-[#c41e3a]" : "border-white/10 hover:border-white/30"
                    }`}>
                    <img src={img} alt="" className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            )}

            {/* Image labels */}
            {images.length >= 2 && (
              <div className="flex gap-2 justify-center text-xs text-white/30">
                <span className={activeImg === 0 ? "text-white/60" : ""}>Front</span>
                <span>·</span>
                <span className={activeImg === 1 ? "text-white/60" : ""}>Back</span>
                {images.length > 2 && <><span>·</span><span>{images.length - 2} more</span></>}
              </div>
            )}
          </div>

          {/* ── RIGHT: Card details + actions ── */}
          <div className="space-y-6">
            {/* Card identity */}
            <div>
              <h1 className="text-2xl font-bold text-white leading-tight mb-1" style={{ fontFamily: "Oswald, sans-serif" }}>
                {card.playerName}
              </h1>
              <p className="text-white/60 text-sm mb-3">{card.title}</p>
              <div className="flex flex-wrap gap-2">
                {card.year && <Badge variant="outline" className="text-xs border-white/20 text-white/50">{card.year}</Badge>}
                {card.sport && <Badge variant="outline" className="text-xs border-white/20 text-white/50 capitalize">{card.sport}</Badge>}
                {card.setName && <Badge variant="outline" className="text-xs border-white/20 text-white/50">{card.setName}</Badge>}
                {card.cardNumber && <Badge variant="outline" className="text-xs border-white/20 text-white/50">#{card.cardNumber}</Badge>}
                {card.category && <Badge variant="outline" className="text-xs border-white/20 text-white/50 capitalize">{card.category}</Badge>}
              </div>
            </div>

            {/* Grade panel */}
            {gradeDisplay && (
              <div className="bg-gradient-to-r from-[#c41e3a]/10 to-transparent border border-[#c41e3a]/20 rounded-xl p-4">
                <div className="flex items-center gap-4">
                  <div className="text-center">
                    <div className="text-4xl font-black text-[#c41e3a]" style={{ fontFamily: "Oswald, sans-serif" }}>
                      {gradeDisplay}
                    </div>
                    <div className="text-xs text-white/40 mt-0.5">SCO AI Grade</div>
                  </div>
                  <div className="flex-1 grid grid-cols-2 gap-2 text-xs">
                    {card.aiGradeLabel && <div><span className="text-white/40">Label: </span><span className="text-white/70">{card.aiGradeLabel}</span></div>}
                    {card.aiCentering && <div><span className="text-white/40">Centering: </span><span className="text-white/70">{card.aiCentering}</span></div>}
                    {card.aiCorners && <div><span className="text-white/40">Corners: </span><span className="text-white/70">{card.aiCorners}</span></div>}
                    {card.aiEdges && <div><span className="text-white/40">Edges: </span><span className="text-white/70">{card.aiEdges}</span></div>}
                    {card.aiSurface && <div><span className="text-white/40">Surface: </span><span className="text-white/70">{card.aiSurface}</span></div>}
                    {(card.certNumber || card.aiCertNumber) && (
                      <div className="col-span-2"><span className="text-white/40">Cert#: </span><span className="text-white/70 font-mono">{card.certNumber || card.aiCertNumber}</span></div>
                    )}
                  </div>
                </div>
              </div>
            )}

            {/* Price */}
            {price !== null && price > 0 && (
              <div className="flex items-baseline gap-2">
                <span className="text-3xl font-black text-white" style={{ fontFamily: "Oswald, sans-serif" }}>
                  ${price.toFixed(2)}
                </span>
                {card.buyNowPrice && parseFloat(String(card.buyNowPrice)) > price && (
                  <span className="text-sm text-white/40 line-through">${parseFloat(String(card.buyNowPrice)).toFixed(2)}</span>
                )}
              </div>
            )}

            {/* Description */}
            {card.description && (
              <p className="text-white/60 text-sm leading-relaxed border-l-2 border-white/10 pl-3">
                {card.description}
              </p>
            )}

            {/* ── PUBLIC ACTIONS (buy/cart) ── */}
            {card.status === "active" && price !== null && price > 0 && (
              <div className="space-y-2">
                <Button className="w-full bg-[#c41e3a] hover:bg-[#a01830] text-white font-bold h-12 text-base"
                  onClick={handleBuyNow} disabled={createCheckout.isPending}>
                  {createCheckout.isPending ? "Redirecting..." : `Buy Now — $${price.toFixed(2)}`}
                </Button>
                <Button variant="outline" className={`w-full h-11 gap-2 border-white/20 ${inCart ? "text-green-400 border-green-500/40" : "text-white/70"}`}
                  onClick={handleAddToCart}>
                  {inCart ? <><Check className="w-4 h-4" /> In Cart</> : <><ShoppingCart className="w-4 h-4" /> Add to Cart</>}
                </Button>
              </div>
            )}

            {card.status === "auction" && (
              <div className="bg-orange-500/10 border border-orange-500/30 rounded-xl p-4 text-center">
                <Gavel className="w-8 h-8 text-orange-400 mx-auto mb-2" />
                <p className="text-orange-300 font-semibold">This card is currently in auction</p>
                <Button asChild variant="outline" className="mt-3 border-orange-500/40 text-orange-400 hover:bg-orange-500/10">
                  <Link href="/auctions">View Live Auctions →</Link>
                </Button>
              </div>
            )}

            {card.status === "casino" && (
              <div className="bg-yellow-500/10 border border-yellow-500/30 rounded-xl p-4 text-center">
                <Dice5 className="w-8 h-8 text-yellow-400 mx-auto mb-2" />
                <p className="text-yellow-300 font-semibold">This card is in the Game Room</p>
                <Button asChild variant="outline" className="mt-3 border-yellow-500/40 text-yellow-400 hover:bg-yellow-500/10">
                  <Link href="/game-room">Visit Game Room →</Link>
                </Button>
              </div>
            )}

            {/* ── OWNER ACTIONS ── */}
            {isAdmin && (
              <div className="border border-white/10 rounded-xl p-4 space-y-3">
                <div className="flex items-center gap-2 mb-1">
                  <Shield className="w-4 h-4 text-[#c41e3a]" />
                  <span className="text-xs font-semibold text-white/50 uppercase tracking-wider">Owner Actions</span>
                </div>
                <div className="flex flex-wrap gap-2">
                  <OwnerEditDialog card={card} onDone={refetch} />
                  <OwnerAuctionDialog card={card} onDone={refetch} />
                  <Button variant="outline" size="sm"
                    className="gap-2 border-yellow-500/40 text-yellow-400 hover:bg-yellow-500/10"
                    onClick={() => { if (confirm("Send to Casino?")) updateStatus.mutate({ cardId: card.id, status: "casino" }); }}>
                    <Dice5 className="w-4 h-4" /> Casino
                  </Button>
                  <Button variant="outline" size="sm"
                    className="gap-2 border-green-500/40 text-green-400 hover:bg-green-500/10"
                    onClick={() => { if (confirm("List in Marketplace?")) updateStatus.mutate({ cardId: card.id, status: "active" }); }}>
                    <Tag className="w-4 h-4" /> List
                  </Button>
                  <Button variant="outline" size="sm"
                    className="gap-2 border-indigo-500/40 text-indigo-400 hover:bg-indigo-500/10"
                    onClick={() => { if (confirm("Move to House?")) updateStatus.mutate({ cardId: card.id, status: "bank" }); }}>
                    <Package className="w-4 h-4" /> House
                  </Button>
                  <Button variant="destructive" size="sm"
                    className="gap-2 bg-red-600/80 hover:bg-red-600 text-white border-0"
                    onClick={() => setShowDeleteConfirm(true)}>
                    <Trash2 className="w-4 h-4" /> Delete Card
                  </Button>
                </div>
              </div>
            )}

            {/* Share */}
            <div className="relative">
              <button onClick={() => setShareOpen(v => !v)}
                className="flex items-center gap-2 text-xs text-white/30 hover:text-white/60 transition-colors">
                <Share2 className="w-3.5 h-3.5" /> Share this card
              </button>
              {shareOpen && (
                <div className="absolute bottom-full mb-2 left-0 bg-[#1a2540] border border-white/10 rounded-lg p-3 flex gap-3 shadow-xl z-10">
                  <button onClick={() => { navigator.clipboard.writeText(shareUrl); toast.success("Link copied!"); setShareOpen(false); }}
                    className="flex items-center gap-1.5 text-xs text-white/60 hover:text-white transition-colors">
                    <Link2 className="w-4 h-4" /> Copy link
                  </button>
                  <a href={`https://twitter.com/intent/tweet?text=${encodeURIComponent(shareText)}&url=${encodeURIComponent(shareUrl)}`}
                    target="_blank" rel="noopener noreferrer"
                    className="flex items-center gap-1.5 text-xs text-white/60 hover:text-white transition-colors">
                    <Twitter className="w-4 h-4" /> Twitter
                  </a>
                  <a href={`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(shareUrl)}`}
                    target="_blank" rel="noopener noreferrer"
                    className="flex items-center gap-1.5 text-xs text-white/60 hover:text-white transition-colors">
                    <Facebook className="w-4 h-4" /> Facebook
                  </a>
                </div>
              )}
            </div>

            {/* Card meta */}
            <div className="border-t border-white/10 pt-4 grid grid-cols-2 gap-2 text-xs text-white/40">
              <div><span className="text-white/20">Card ID:</span> #{card.id}</div>
              {card.manufacturer && <div><span className="text-white/20">Maker:</span> {card.manufacturer}</div>}
              {card.condition && <div><span className="text-white/20">Condition:</span> <span className="capitalize">{card.condition}</span></div>}
              {card.gradeCompany && card.gradeCompany !== "none" && <div><span className="text-white/20">Grader:</span> {card.gradeCompany}</div>}
              {card.gradeScore && <div><span className="text-white/20">Grade:</span> {card.gradeScore}</div>}
              {card.storeName && <div><span className="text-white/20">Store:</span> {card.storeName}</div>}
              <div><span className="text-white/20">Added:</span> {new Date(card.createdAt).toLocaleDateString()}</div>
              {card.isVaulted && <div className="col-span-2 text-amber-400/70">★ SCO Vault Guaranteed</div>}
            </div>
          </div>
        </div>

        {/* ── CARD HISTORY TIMELINE ─────────────────────────────────────── */}
        <CardHistoryTimeline cardId={card.id} isOwner={isAdmin} />
      </div>

      {/* Admin Delete Confirmation Dialog */}
      <AlertDialog open={showDeleteConfirm} onOpenChange={setShowDeleteConfirm}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete this card?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete this card. This cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              className="bg-red-600 hover:bg-red-700 text-white"
              onClick={() => deleteCardMutation.mutate({ id: card.id })}
              disabled={deleteCardMutation.isPending}
            >
              {deleteCardMutation.isPending ? "Deleting..." : "Yes, Delete"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

// ── Card History Timeline Component ──────────────────────────────────────────
import React from "react";
const EVENT_CFG: Record<string, { icon: React.ReactNode; color: string; label: string }> = {
  added:           { icon: <Zap className="w-3.5 h-3.5" />,        color: "text-green-400 bg-green-500/10 border-green-500/20",    label: "Added" },
  imported:        { icon: <Zap className="w-3.5 h-3.5" />,        color: "text-green-400 bg-green-500/10 border-green-500/20",    label: "Imported" },
  listed:          { icon: <Tag className="w-3.5 h-3.5" />,         color: "text-blue-400 bg-blue-500/10 border-blue-500/20",       label: "Listed" },
  delisted:        { icon: <Tag className="w-3.5 h-3.5" />,         color: "text-gray-400 bg-gray-500/10 border-gray-500/20",       label: "Delisted" },
  auction_started: { icon: <Gavel className="w-3.5 h-3.5" />,      color: "text-orange-400 bg-orange-500/10 border-orange-500/20", label: "Auction Started" },
  auction_ended:   { icon: <Gavel className="w-3.5 h-3.5" />,      color: "text-gray-400 bg-gray-500/10 border-gray-500/20",       label: "Auction Ended" },
  auction_bid:     { icon: <Gavel className="w-3.5 h-3.5" />,      color: "text-yellow-400 bg-yellow-500/10 border-yellow-500/20", label: "Bid Received" },
  auction_won:     { icon: <Award className="w-3.5 h-3.5" />,      color: "text-yellow-400 bg-yellow-500/10 border-yellow-500/20", label: "Auction Won" },
  sold:            { icon: <Banknote className="w-3.5 h-3.5" />,   color: "text-emerald-400 bg-emerald-500/10 border-emerald-500/20", label: "Sold" },
  traded:          { icon: <TrendingUp className="w-3.5 h-3.5" />, color: "text-purple-400 bg-purple-500/10 border-purple-500/20", label: "Traded" },
  price_updated:   { icon: <Banknote className="w-3.5 h-3.5" />,   color: "text-cyan-400 bg-cyan-500/10 border-cyan-500/20",       label: "Price Updated" },
  vaulted:         { icon: <Shield className="w-3.5 h-3.5" />,     color: "text-indigo-400 bg-indigo-500/10 border-indigo-500/20", label: "Vaulted" },
  casino_assigned: { icon: <Dice5 className="w-3.5 h-3.5" />,      color: "text-pink-400 bg-pink-500/10 border-pink-500/20",       label: "Casino" },
  status_changed:  { icon: <History className="w-3.5 h-3.5" />,    color: "text-white/60 bg-white/5 border-white/10",              label: "Status Changed" },
  bulk_action:     { icon: <Package className="w-3.5 h-3.5" />,    color: "text-white/60 bg-white/5 border-white/10",              label: "Bulk Action" },
  note_added:      { icon: <Pencil className="w-3.5 h-3.5" />,     color: "text-white/40 bg-white/5 border-white/10",              label: "Note Added" },
  graded:          { icon: <Award className="w-3.5 h-3.5" />,      color: "text-amber-400 bg-amber-500/10 border-amber-500/20",    label: "Graded" },
};

// Dummy isOwner export to satisfy the reference above — the real isOwner is
// computed inside CardProfile() and passed as a prop to this component.
function CardHistoryTimeline({ cardId, isOwner }: { cardId: number; isOwner: boolean }) {
  const { data: history, isLoading } = trpc.admin.getCardHistory.useQuery(
    { cardId },
    { enabled: isOwner }
  );

  if (!isOwner) return null;

  return (
    <div className="mt-8 max-w-5xl mx-auto px-4 pb-16">
      <div className="flex items-center gap-2 mb-4">
        <History className="w-5 h-5 text-white/50" />
        <h2 className="text-base font-semibold text-white/70">Card History</h2>
        {history && history.length > 0 && (
          <span className="text-xs text-white/30 ml-1">({history.length} events)</span>
        )}
      </div>

      {isLoading && (
        <div className="space-y-3">
          {[1,2,3].map(i => (
            <div key={i} className="h-14 rounded-lg bg-white/5 animate-pulse" />
          ))}
        </div>
      )}

      {!isLoading && (!history || history.length === 0) && (
        <div className="text-center py-10 text-white/30 text-sm">
          <Clock className="w-8 h-8 mx-auto mb-2 opacity-30" />
          No history yet. Status changes, auction listings, and price updates will appear here.
        </div>
      )}

      {!isLoading && history && history.length > 0 && (
        <div className="relative">
          {/* Vertical connector line */}
          <div className="absolute left-[18px] top-0 bottom-0 w-px bg-white/10" />

          <div className="space-y-1">
            {history.map((event) => {
              const cfg: { icon: React.ReactNode; color: string; label: string } = EVENT_CFG[event.eventType] ?? {
                icon: <Clock className="w-3.5 h-3.5" />,
                color: "text-white/40 bg-white/5 border-white/10",
                label: event.eventType,
              };
              let meta: Record<string, unknown> | null = null;
              try { meta = event.metadata ? JSON.parse(event.metadata as string) : null; } catch { /* ignore */ }

              return (
                <div key={event.id} className="flex gap-3 items-start group">
                  {/* Icon dot */}
                  <div className={`relative z-10 flex-shrink-0 w-9 h-9 rounded-full border flex items-center justify-center mt-0.5 ${cfg.color}`}>
                    {cfg.icon}
                  </div>

                  {/* Content card */}
                  <div className={`flex-1 rounded-lg border px-3 py-2 mb-1 ${cfg.color}`}>
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-xs font-semibold">{cfg.label}</span>
                      <span className="text-[10px] text-white/30 flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        {new Date(event.createdAt).toLocaleString()}
                      </span>
                    </div>
                    {event.description && (
                      <p className="text-[11px] text-white/50 mt-0.5">{event.description}</p>
                    )}
                    {meta && meta.newStatus !== undefined && (
                      <p className="text-[10px] text-white/30 mt-0.5">{`→ ${meta.newStatus as string}`}</p>
                    )}
                    {event.userEmail && (
                      <p className="text-[10px] text-white/20 mt-0.5">by {event.userEmail}</p>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
