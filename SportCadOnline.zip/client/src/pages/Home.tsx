import { useAuth } from "@/_core/hooks/useAuth";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { getLoginUrl } from "@/const";
import { Link } from "wouter";
import { trpc } from "@/lib/trpc";
import { Clock, TrendingUp, ShoppingCart, Award, Camera, Gavel, ChevronRight, BarChart2, Tag, Sparkles, Dice6, Search, X, Filter, List, Grid3X3, Star, Flame, Users, Trophy, Rocket, Crown, Pencil, Trash2, Coins, PlusCircle, Zap } from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";
import { toast } from "sonner";
import { CompsPanel, ValuesPanel } from "@/components/CompsPanel";
import CardPopup from "@/components/CardPopup";
import { useFreerollCountdown } from "@/hooks/useFreerollCountdown";
import { SlabFrame } from "@/components/SlabFrame";
import { CardCarousel } from "@/components/CardCarousel";
import { GameTimesTicker } from "@/components/GameTimesTicker";

const LOGO_URL = "https://d2xsxph8kpxj0f.cloudfront.net/310519663482618714/HBSXFxHmEnEJMgVvzKnhpZ/logo_transparent_8c903811.png";

// ── Ticker with live freeroll countdown ──────────────────────────────────────
function PromoTicker() {
  const { countdown, isLive } = useFreerollCountdown();
  const items = [
    { icon: "🎰", text: "GRAND OPENING — SCO GAME ROOM" },
    { icon: "🃏", text: "Pack Rip Simulator — Win Graded Cards" },
    { icon: "🎡", text: "Spin the Wheel — Jackpot Prizes" },
    { icon: "♠️", text: "Poker Tables — Play for Real Cards" },
    {
      icon: "🏆",
      text: null, // rendered inline with live countdown
      isCountdown: true,
      countdown,
      isLive,
    },
    { icon: "⚡", text: "Caitlin Clark RC Mega Jackpot — 1,000 Credits" },
    { icon: "🔥", text: "Cooper Flagg RC Mini Jackpot — 500 Credits" },
    { icon: "🎁", text: "Free Games Available — No Credits Needed" },
    { icon: "💰", text: "Win Credits • Redeem for Real Sports Cards" },
    { icon: "🌟", text: "Wembanyama Prizm RC in the Prize Vault" },
  ];

  return (
    <section className="bg-gradient-to-r from-[#1a0a0e] via-[#0a1628] to-[#1a0a0e] border-y border-[#c41e3a]/30 py-2 overflow-hidden relative">
      <div className="absolute left-0 top-0 bottom-0 w-16 bg-gradient-to-r from-[#1a0a0e] to-transparent z-10 pointer-events-none" />
      <div className="absolute right-0 top-0 bottom-0 w-16 bg-gradient-to-l from-[#1a0a0e] to-transparent z-10 pointer-events-none" />
      <div className="flex whitespace-nowrap animate-[ticker_28s_linear_infinite]">
        {[...Array(2)].map((_, pass) => (
          <div key={pass} className="flex items-center gap-0 shrink-0">
            {items.map((item, i) => (
              <span key={i} className="inline-flex items-center gap-2 px-6">
                <span className="text-base">{item.icon}</span>
                {item.isCountdown ? (
                  <span className="inline-flex items-center gap-2" style={{ fontFamily: "Oswald, sans-serif" }}>
                    <span className="text-xs font-black tracking-widest text-yellow-400/90"
                      style={{ textShadow: "0 0 12px rgba(234,179,8,0.5)" }}>
                      Daily Freeroll Tournament —
                    </span>
                    {item.isLive ? (
                      <span className="bg-[#c41e3a] text-white text-[10px] font-black px-2 py-0.5 rounded animate-pulse tracking-widest">
                        🔴 LIVE NOW
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1">
                        <span className="text-white/50 text-[10px] font-bold tracking-wider">Starts in</span>
                        <span className="bg-black/60 border border-yellow-500/40 text-yellow-400 font-black text-xs px-2 py-0.5 rounded tracking-widest tabular-nums"
                          style={{ textShadow: "0 0 8px rgba(234,179,8,0.7)", minWidth: "6rem", textAlign: "center" }}>
                          {item.countdown}
                        </span>
                      </span>
                    )}
                  </span>
                ) : (
                  <span className="text-xs font-black tracking-widest text-yellow-400/90"
                    style={{ fontFamily: "Oswald, sans-serif", textShadow: "0 0 12px rgba(234,179,8,0.5)" }}>
                    {item.text}
                  </span>
                )}
                <span className="text-[#c41e3a]/60 font-black text-base mx-1">◆</span>
              </span>
            ))}
          </div>
        ))}
      </div>
    </section>
  );
}

function AuctionCountdown({ endsAt }: { endsAt: string | Date | null | undefined }) {
  const [timeLeft, setTimeLeft] = useState("");
  useEffect(() => {
    if (!endsAt) { setTimeLeft("—"); return; }
    const update = () => {
      const diff = new Date(endsAt).getTime() - Date.now();
      if (diff <= 0) { setTimeLeft("Ended"); return; }
      const d = Math.floor(diff / 86400000);
      const h = Math.floor((diff % 86400000) / 3600000);
      const m = Math.floor((diff % 3600000) / 60000);
      const s = Math.floor((diff % 60000) / 1000);
      setTimeLeft(d > 0 ? `${d}d ${h}h ${m}m` : `${h}h ${m}m ${s}s`);
    };
    update();
    const id = setInterval(update, 1000);
    return () => clearInterval(id);
  }, [endsAt]);
  return <span>{timeLeft}</span>;
}

// ── Up & Coming Section Component — 1 horizontal scroll row with arrow buttons ─
function UpAndComingSection({ onCardClick }: { onCardClick: (card: any, e: React.MouseEvent) => void }) {
  const { data: cards, isLoading } = trpc.cards.upAndComing.useQuery();
  const scrollRef = useRef<HTMLDivElement>(null);
  const scroll = (dir: 'left' | 'right') => {
    if (!scrollRef.current) return;
    scrollRef.current.scrollBy({ left: dir === 'right' ? 320 : -320, behavior: 'smooth' });
  };
  if (isLoading) return (
    <section style={{ backgroundColor: '#f0f0f0', padding: '28px 0' }}>
      <div className="container"><div className="h-8 w-48 bg-gray-300 rounded animate-pulse mb-4" /><div className="flex gap-4">{Array.from({length:6}).map((_,i)=><div key={i} className="w-36 shrink-0 aspect-[2/3] bg-gray-300 rounded-lg animate-pulse" />)}</div></div>
    </section>
  );
  if (!cards || cards.length === 0) return null;
  return (
    <section id="up-and-coming" style={{ backgroundColor: '#f0f0f0', padding: '28px 0' }}>
      <div className="container">
        <div className="flex items-center gap-2 mb-3">
          <Rocket className="w-5 h-5 text-[#c41e3a]" />
          <h2 className="text-xl font-black text-gray-900" style={{ fontFamily: 'Oswald, sans-serif' }}>UP &amp; COMING</h2>
          <span className="text-xs text-gray-500 ml-1">Our house picks — rookies, draft picks &amp; rising stars</span>
        </div>
        <div className="relative">
          {/* Left arrow */}
          <button onClick={() => scroll('left')} className="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-4 z-10 w-8 h-8 rounded-full bg-white border border-gray-300 shadow-md flex items-center justify-center hover:bg-gray-50 hover:border-[#c41e3a] transition-all">
            <ChevronRight className="w-4 h-4 text-gray-600 rotate-180" />
          </button>
          {/* Scrollable row */}
          <div ref={scrollRef} className="flex gap-3 overflow-x-auto pb-1" style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}>
            {cards.map((card: any) => (
              <div key={card.id} className="group cursor-pointer rounded-lg overflow-hidden border border-gray-200 bg-white hover:border-[#c41e3a] hover:shadow-md hover:shadow-[#c41e3a]/20 transition-all shrink-0" style={{ width: '140px' }} onClick={(e) => onCardClick(card, e)}>
                <div className="overflow-hidden" style={{ aspectRatio: '2/3' }}>
                  <SlabFrame imageUrl={card.frontImageUrl} altText={card.title} labelColor={(card.labelColor as any) ?? 'dark'} labelBg={(card as any).labelBg} labelBorder={(card as any).labelBorder} labelMode={(card as any).labelMode} grade={(card as any).gradeScore || card.aiGrade} gradeLabel={card.aiGradeLabel} gradeCompany={(card as any).gradeCompany} playerName={card.playerName} setName={card.setName} year={card.year} cardNumber={card.cardNumber} certNumber={card.certNumber} cardId={card.id} isNew={card.createdAt ? (Date.now() - new Date(card.createdAt).getTime() < 86_400_000) : false} />
                </div>
                <div className="p-2">
                  <p className="text-xs font-semibold text-gray-900 line-clamp-1 leading-tight">{card.playerName || card.title}</p>
                  <p className="text-[10px] text-gray-500 line-clamp-1">{card.year} {card.setName}</p>
                  <p className="text-sm font-bold text-[#c41e3a] mt-0.5">${parseFloat(card.price || '0').toFixed(2)}</p>
                </div>
              </div>
            ))}
          </div>
          {/* Right arrow */}
          <button onClick={() => scroll('right')} className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-4 z-10 w-8 h-8 rounded-full bg-white border border-gray-300 shadow-md flex items-center justify-center hover:bg-gray-50 hover:border-[#c41e3a] transition-all">
            <ChevronRight className="w-4 h-4 text-gray-600" />
          </button>
        </div>
      </div>
    </section>
  );
}

// ── Smart Rotation Section — 3rd row, sport-weighted, $500 cap, daily refresh ──
function SmartRotationSection({ onCardClick }: { onCardClick: (card: any, e: React.MouseEvent) => void }) {
  const [visitorKey] = useState(() => {
    try {
      let k = localStorage.getItem("sco_visitor_id");
      if (!k) { k = Math.random().toString(36).slice(2) + Date.now().toString(36); localStorage.setItem("sco_visitor_id", k); }
      return k;
    } catch { return "guest"; }
  });
  const { data: featured, isLoading } = trpc.cards.getFeatured.useQuery(
    { visitorKey },
    { staleTime: 5 * 60_000 }
  );
  const scrollRef = useRef<HTMLDivElement>(null);
  const scroll = (dir: 'left' | 'right') => {
    if (!scrollRef.current) return;
    scrollRef.current.scrollBy({ left: dir === 'right' ? 320 : -320, behavior: 'smooth' });
  };
  if (isLoading) return (
    <section style={{ backgroundColor: '#0a1628', padding: '28px 0', borderTop: '2px solid rgba(196,30,58,0.3)' }}>
      <div className="container">
        <div className="h-6 w-48 bg-white/10 rounded animate-pulse mb-4" />
        <div className="flex gap-3">{Array.from({length:8}).map((_,i)=><div key={i} className="w-[88px] shrink-0 aspect-[2/3] bg-white/5 rounded-lg animate-pulse" />)}</div>
      </div>
    </section>
  );
  if (!featured || featured.length === 0) return null;
  return (
    <section id="smart-rotation" style={{ backgroundColor: '#0a1628', padding: '28px 0', borderTop: '2px solid rgba(196,30,58,0.3)' }}>
      <div className="container">
        <div className="flex items-center gap-2 mb-3">
          <Zap className="w-5 h-5 text-[#E8C547]" />
          <h2 className="text-xl font-black text-white" style={{ fontFamily: 'Oswald, sans-serif' }}>TODAY'S PICKS</h2>
          <span className="text-xs text-white/30 ml-1">· Sport-weighted · $500 cap · Refreshes daily</span>
        </div>
        <div className="relative">
          <button onClick={() => scroll('left')} className="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-4 z-10 w-8 h-8 rounded-full bg-[#0d1f3c] border border-white/20 shadow-md flex items-center justify-center hover:border-[#c41e3a] transition-all">
            <ChevronRight className="w-4 h-4 text-white/60 rotate-180" />
          </button>
          <div ref={scrollRef} className="flex gap-4 overflow-x-auto pb-2" style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}>
            {featured.map((card: any) => {
              const isWnba = card.sport === 'basketball' && card.isMainStore &&
                ['caitlin clark','angel reese','paige bueckers',"a'ja wilson",'sabrina ionescu','kate martin','aziaha james','rickea jackson','breanna stewart','diana taurasi'].some(p => (card.playerName||'').toLowerCase().includes(p));
              return (
                <div key={card.id} className="group cursor-pointer shrink-0" style={{ width: '160px' }} onClick={(e) => onCardClick(card, e)}>
                  <div className="relative overflow-hidden rounded-xl border border-white/10 group-hover:border-[#c41e3a]/60 transition-all group-hover:shadow-lg group-hover:shadow-[#c41e3a]/20" style={{ aspectRatio: '2/3' }}>
                    <SlabFrame imageUrl={card.frontImageUrl} altText={card.title} labelColor={(card.labelColor as any) ?? 'dark'} labelBg={(card as any).labelBg} labelBorder={(card as any).labelBorder} labelMode={(card as any).labelMode} grade={(card as any).gradeScore || card.aiGrade} gradeLabel={card.aiGradeLabel} gradeCompany={(card as any).gradeCompany} playerName={card.playerName} setName={card.setName} year={card.year} cardNumber={card.cardNumber} certNumber={card.certNumber} cardId={card.id} isNew={card.createdAt ? (Date.now() - new Date(card.createdAt).getTime() < 86_400_000) : false} />
                    {isWnba && (
                      <div className="absolute top-0 left-0 right-0 text-white text-[9px] font-black text-center py-1 tracking-widest z-10" style={{ background: 'linear-gradient(90deg,#c41e3a,#ff6b35)' }}>WNBA ★ HOUSE</div>
                    )}
                  </div>
                  <div className="mt-2 px-0.5">
                    <p className="text-white font-black text-sm leading-tight line-clamp-1 group-hover:text-[#E8C547] transition-colors">{card.playerName || card.title}</p>
                    <div className="flex items-center justify-between mt-0.5">
                      <p className="text-[#c41e3a] font-black text-sm">${parseFloat(card.price||'0').toFixed(0)}</p>
                      <p className="text-white/30 text-[10px] uppercase tracking-wide">{card.sport}</p>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
          <button onClick={() => scroll('right')} className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-4 z-10 w-8 h-8 rounded-full bg-[#0d1f3c] border border-white/20 shadow-md flex items-center justify-center hover:border-[#c41e3a] transition-all">
            <ChevronRight className="w-4 h-4 text-white/60" />
          </button>
        </div>
      </div>
    </section>
  );
}

// ── Showcase Section Component — premium gold, matches Up & Coming card width ──
// LOCKED RULE: house cards only, isShowcaseCard=true, 5 rotate daily
const SHOWCASE_CARD_WIDTH = 140; // matches Up & Coming card width
function ShowcaseSection({ onCardClick }: { onCardClick: (card: any, e: React.MouseEvent) => void }) {
  const { data: cards, isLoading } = trpc.cards.showcase.useQuery();
  if (isLoading) return (
    <section style={{ backgroundColor: '#ffffff', padding: '48px 0' }}>
      <div className="container"><div className="h-8 w-48 bg-gray-200 rounded animate-pulse mb-4" /><div className="flex gap-6 justify-center">{Array.from({length:5}).map((_,i)=><div key={i} className="rounded-xl bg-gray-200 animate-pulse" style={{ width: SHOWCASE_CARD_WIDTH, aspectRatio: '2/3' }} />)}</div></div>
    </section>
  );
  if (!cards || cards.length === 0) return null;
  return (
    <section id="showcase" style={{ backgroundColor: '#ffffff', padding: '48px 0', borderTop: '2px solid #f5e27a' }}>
      <div className="container">
        {/* Header */}
        <div className="text-center mb-6">
          <div className="inline-flex items-center gap-2 mb-1">
            <Crown className="w-6 h-6 text-yellow-500" />
            <h2 className="text-2xl font-black text-gray-900 tracking-wide" style={{ fontFamily: 'Oswald, sans-serif', letterSpacing: '0.08em' }}>SHOWCASE</h2>
            <Crown className="w-6 h-6 text-yellow-500" />
          </div>
          <p className="text-xs text-gray-500">Premium house collection · Rotated daily · Ohtani · Clark · Messi · Gretzky · Trout · Jordan</p>
        </div>
        {/* Cards row — centered, same width as Up & Coming cards */}
        <div className="flex gap-6 justify-center flex-wrap">
          {cards.map((card: any) => (
            <div
              key={card.id}
              className="group cursor-pointer rounded-2xl overflow-hidden transition-all duration-300"
              style={{
                width: SHOWCASE_CARD_WIDTH,
                background: 'linear-gradient(145deg, #fffbeb, #ffffff)',
                border: '2px solid #d4a017',
                boxShadow: '0 4px 20px rgba(212,160,23,0.15)',
              }}
              onMouseEnter={e => { (e.currentTarget as HTMLElement).style.boxShadow = '0 8px 40px rgba(212,160,23,0.45)'; (e.currentTarget as HTMLElement).style.transform = 'translateY(-4px)'; }}
              onMouseLeave={e => { (e.currentTarget as HTMLElement).style.boxShadow = '0 4px 20px rgba(212,160,23,0.15)'; (e.currentTarget as HTMLElement).style.transform = ''; }}
              onClick={(e) => onCardClick(card, e)}
            >
              {/* Gold shimmer top bar */}
              <div style={{ height: '3px', background: 'linear-gradient(90deg, #b8860b, #ffd700, #b8860b)' }} />
              <div className="overflow-hidden" style={{ aspectRatio: '2/3' }}>
                <SlabFrame imageUrl={card.frontImageUrl} altText={card.title} labelColor={(card.labelColor as any) ?? 'dark'} labelBg={(card as any).labelBg} labelBorder={(card as any).labelBorder} labelMode={(card as any).labelMode} grade={(card as any).gradeScore || card.aiGrade} gradeLabel={card.aiGradeLabel} gradeCompany={(card as any).gradeCompany} playerName={card.playerName} setName={card.setName} year={card.year} cardNumber={card.cardNumber} certNumber={card.certNumber} cardId={card.id} />
              </div>
              <div className="p-2.5" style={{ background: 'linear-gradient(to bottom, #fffbeb, #fef9e7)' }}>
                <p className="text-xs font-bold text-gray-900 line-clamp-1 leading-tight">{card.playerName || card.title}</p>
                <p className="text-[10px] text-gray-500 line-clamp-1 mb-1">{card.year} {card.setName}</p>
                <div className="flex items-center justify-between">
                  <p className="text-sm font-black" style={{ color: '#b8860b' }}>${parseFloat(card.price || '0').toLocaleString('en-US', {minimumFractionDigits:0, maximumFractionDigits:0})}</p>
                  <span className="text-[8px] font-black px-1.5 py-0.5 rounded-full uppercase tracking-widest" style={{ background: 'linear-gradient(90deg, #b8860b, #ffd700)', color: '#fff' }}>★ SCO</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

export default function Home() {
  const { isAuthenticated, user } = useAuth();
  const isAdmin = user?.role === "admin";
  const { data: newsItems } = trpc.news.getTicker.useQuery();
  const { data: auctions, isLoading: auctionsLoading } = trpc.auctions.list.useQuery(undefined, {
    staleTime: 30_000,
    refetchOnWindowFocus: true,
    refetchOnMount: true,
  });
  // Marketplace filter state — declared early so the query can use them
  const [marketSearch, setMarketSearch] = useState("");
  const [marketSport, setMarketSport] = useState("All");
  const [marketView, setMarketView] = useState<"grid" | "list">("grid");
  const [marketSort, setMarketSort] = useState("price_desc");
  const MARKET_SPORTS = ["All", "Baseball", "Basketball", "Football", "Hockey", "Soccer", "Other"];
  // Debounced search to avoid hammering the server on every keystroke
  const [debouncedSearch, setDebouncedSearch] = useState("");
  useEffect(() => {
    const t = setTimeout(() => setDebouncedSearch(marketSearch), 400);
    return () => clearTimeout(t);
  }, [marketSearch]);
  const sportParam = marketSport !== "All" ? marketSport : undefined;
  const searchParam = debouncedSearch.trim() || undefined;
  const { data: cards, isFetching: cardsFetching, refetch: refetchCards } = trpc.cards.list.useQuery(
    { limit: 200, sport: sportParam, search: searchParam },
    { staleTime: 30_000 }
  );

  const tickerRef = useRef<HTMLDivElement>(null);
  const trackVisitMutation = trpc.affiliate.trackVisit.useMutation();

  // Card popup state
  const [popupCard, setPopupCard] = useState<any>(null);
  const [popupOpen, setPopupOpen] = useState(false);

  // Admin quick-edit state
  const [editCard, setEditCard] = useState<any>(null);
  const [editPrice, setEditPrice] = useState("");
  const [editPlayerName, setEditPlayerName] = useState("");
  const [editSetName, setEditSetName] = useState("");
  const [editYear, setEditYear] = useState("");
  const [editGrade, setEditGrade] = useState("");
  const [editSport, setEditSport] = useState("");
  const [editStatus, setEditStatus] = useState("");
  const [editCardNumber, setEditCardNumber] = useState("");
  const [editManufacturer, setEditManufacturer] = useState("");
  const [editDescription, setEditDescription] = useState("");
  const adminUpdateCard = trpc.admin.adminUpdateCardFull.useMutation({
    onSuccess: () => { toast.success("Card updated"); setEditCard(null); refetchCards(); },
    onError: (e: any) => toast.error(e.message),
  });
  const adminDeleteCard = trpc.admin.deleteCardAdmin.useMutation({
    onSuccess: () => { toast.success("Card deleted"); refetchCards(); },
    onError: (e: any) => toast.error(e.message),
  });

  // Handle ?ref= referral tracking on page load
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const refCode = params.get("ref");
    if (!refCode) return;
    let visitorCookie = localStorage.getItem("sco_visitor_id");
    if (!visitorCookie) {
      visitorCookie = Math.random().toString(36).slice(2) + Date.now().toString(36);
      localStorage.setItem("sco_visitor_id", visitorCookie);
    }
    localStorage.setItem("sco_ref_code", refCode);
    trackVisitMutation.mutate({ refCode, visitorCookie });
  }, []);

  // Sort auctions by soonest-ending first
  const activeAuctions = useMemo(() => {
    if (!auctions || auctions.length === 0) return [];
    return [...auctions]
      .sort((a, b) => new Date((a as any).endTime).getTime() - new Date((b as any).endTime).getTime())
      .slice(0, 50);
  }, [auctions]);

  // Sidebar search filter
  const [sidebarSearch, setSidebarSearch] = useState("");
  const filteredSidebarAuctions = useMemo(() => {
    if (!sidebarSearch.trim()) return activeAuctions;
    const q = sidebarSearch.toLowerCase();
    return activeAuctions.filter((a: any) =>
      (a.cardTitle || "").toLowerCase().includes(q) ||
      (a.playerName || "").toLowerCase().includes(q)
    );
  }, [activeAuctions, sidebarSearch]);

  // JS-based auto-scroll: pauses on hover, resumes on mouse leave
  const scrollContainerRef = useRef<HTMLDivElement>(null);
  const isHoveringRef = useRef(false);
  const animFrameRef = useRef<number>(0);
  const posRef = useRef(0);

  useEffect(() => {
    const container = scrollContainerRef.current;
    if (!container) return;
    posRef.current = 0;

    // Allow mouse wheel to scroll manually while hovering
    const onWheel = (e: WheelEvent) => {
      if (!isHoveringRef.current) return;
      e.preventDefault();
      posRef.current = Math.max(0, Math.min(posRef.current + e.deltaY * 0.5, container.scrollHeight / 2 - 1));
      container.scrollTop = posRef.current;
    };
    container.addEventListener("wheel", onWheel, { passive: false });

    const step = () => {
      if (!isHoveringRef.current) {
        // Auto-scroll at steady pace
        posRef.current += 0.4;
        if (posRef.current >= container.scrollHeight / 2) posRef.current = 0;
        container.scrollTop = posRef.current;
      }
      animFrameRef.current = requestAnimationFrame(step);
    };
    animFrameRef.current = requestAnimationFrame(step);
    return () => {
      cancelAnimationFrame(animFrameRef.current);
      container.removeEventListener("wheel", onWheel);
    };
  }, [activeAuctions]);
  const featuredCards = cards || [];

  // Comps / Values panel state (hero buttons)
  const [compsOpen, setCompsOpen] = useState(false);
  const [valuesOpen, setValuesOpen] = useState(false);

  // Paginate cards: 10 per page (2 rows of 5)
  const [page, setPage] = useState(0);
  const PAGE_SIZE = 10;
  const totalPages = Math.ceil(featuredCards.length / PAGE_SIZE);
  const pageCards = featuredCards.slice(page * PAGE_SIZE, (page + 1) * PAGE_SIZE);

  // Client-side sort only (server handles sport/search filtering)
  const filteredMarketCards = useMemo(() => {
    let result = featuredCards;
    if (marketSort === "price_asc") result = [...result].sort((a, b) => parseFloat(a.price || "0") - parseFloat(b.price || "0"));
    else if (marketSort === "price_desc") result = [...result].sort((a, b) => parseFloat(b.price || "0") - parseFloat(a.price || "0"));
    else if (marketSort === "newest") result = [...result].sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    return result;
  }, [featuredCards, marketSort]);
  const isSearching = marketSearch.trim().length > 0 || marketSport !== "All";
  const searchPageCards = isSearching ? filteredMarketCards : pageCards;

  const [promoDismissed, setPromoDismissed] = useState(false);
  const [listCardOpen, setListCardOpen] = useState(false);

  const openCardPopup = (card: any, e: React.MouseEvent) => {
    e.preventDefault();
    // Navigate to full card profile page
    window.location.href = `/card/${card.id}`;
  };
  const openQuickView = (card: any, e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setPopupCard(card);
    setPopupOpen(true);
  };

  return (
    <>
    <div className="min-h-screen pb-10" style={{ paddingBottom: "44px" }}>

      {/* -- SIGNUP ANNOUNCEMENT BANNER --------------------------------- */}
      {!isAuthenticated && !promoDismissed && (
        <div style={{ background: 'linear-gradient(90deg, #9aa0a8 0%, #d4d8de 20%, #eef0f3 50%, #d4d8de 80%, #9aa0a8 100%)', borderBottom: '1px solid #8a9099' }} className="py-2.5 px-4 relative">
          <div className="container flex items-center justify-between gap-4 flex-wrap">
            <div className="flex items-center gap-3">
              <span className="text-2xl">🎁</span>
              <div>
                <span className="font-black text-sm tracking-wide text-gray-900" style={{ fontFamily: "Oswald, sans-serif" }}>
                  NEW MEMBER OFFER — JOIN FREE &amp; GET 25 CREDITS INSTANTLY!
                </span>
                <span className="text-gray-600 text-xs ml-2">
                  Use credits to grade cards, list auctions &amp; explore the platform.
                </span>
              </div>
            </div>
            <div className="flex items-center gap-2 shrink-0">
              <Button asChild size="sm" className="bg-[#c41e3a] hover:bg-[#a01830] text-white font-black">
                <a href={getLoginUrl("/my-collection")}>⚡ Sign Up Free</a>
              </Button>
              <button onClick={() => setPromoDismissed(true)} className="text-gray-500 hover:text-gray-900 text-xl font-bold leading-none px-1" title="Dismiss">✕</button>
            </div>
          </div>
        </div>
      )}

      {/* -- HERO SECTION ----------------------------------------------- */}
      <section className="bg-gradient-to-br from-[#0a1628] via-[#0d1f3c] to-[#0a1628] border-b border-white/10 py-10" style={{ overflow: 'hidden', position: 'relative', zIndex: 1 }}>
        <div className="container">
          <div className="flex flex-col md:flex-row items-center gap-4 md:gap-6">
            {/* Logo */}
            <div className="shrink-0">
              <img src={LOGO_URL} alt="SportCardsOnline.com" className="w-48 md:w-64 h-auto" />
            </div>
            {/* Hero text */}
            <div className="flex-1 text-center md:text-left">
              <h1 className="text-4xl md:text-5xl font-black text-white leading-tight mb-3" style={{ fontFamily: "Oswald, sans-serif" }}>
                Buy, Sell &amp; <span className="text-[#c41e3a]">Grade</span> Sports Cards
              </h1>
              <p className="text-white/60 text-base mb-5 max-w-lg">
                AI-powered SCG grading, live auctions, secure escrow arena — the collector's platform built for you.
              </p>
              <div className="flex flex-nowrap gap-2 justify-center md:justify-start">
                <Button asChild size="sm" className="bg-[#c41e3a] hover:bg-[#c41e3a]/90 text-white font-bold gap-1.5 px-3 py-2.5 text-sm">
                  <Link href="/credits"><Coins className="w-3.5 h-3.5" />Buy Credits</Link>
                </Button>
                <Button asChild size="sm" className="bg-[#c41e3a] hover:bg-[#c41e3a]/90 text-white font-bold gap-1.5 px-3 py-2.5 text-sm">
                  <Link href="/grade"><Camera className="w-3.5 h-3.5" />Grade Your Cards</Link>
                </Button>
                <Button size="sm" onClick={() => setListCardOpen(true)} className="bg-white hover:bg-gray-100 text-[#c41e3a] font-bold gap-1.5 px-3 py-2.5 text-sm border border-white/80">
                  <PlusCircle className="w-3.5 h-3.5" />List Your Card
                </Button>
              </div>
            </div>


            {/* Shop Cards Ad Banner */}
            <div className="hidden xl:flex flex-col shrink-0 w-64">
              <Link href="/marketplace" className="group cursor-pointer">
              <div className="relative rounded-xl overflow-hidden border-2 border-[#c41e3a]/70 shadow-[0_0_30px_rgba(196,30,58,0.4)] hover:shadow-[0_0_55px_rgba(196,30,58,0.7)] transition-all duration-500" style={{ height: '220px' }}>
                {/* Box as full background */}
                <img
                  src="https://d2xsxph8kpxj0f.cloudfront.net/310519663482618714/HBSXFxHmEnEJMgVvzKnhpZ/prizm-wnba-box_0ca80d71.png"
                  alt="Panini Prizm WNBA Box"
                  className="absolute inset-0 w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-700"
                />
                {/* Dark gradient overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/30 to-black/20" />
                {/* Caitlin Clark card — vertically centered */}
                <img
                  src="https://d2xsxph8kpxj0f.cloudfront.net/310519663482618714/HBSXFxHmEnEJMgVvzKnhpZ/caitlin-clark-auto_ff5f6a76.jpg"
                  alt="Caitlin Clark Auto Card"
                  className="absolute right-2 w-auto rounded shadow-[0_4px_20px_rgba(0,0,0,0.8)] rotate-3 group-hover:rotate-1 group-hover:scale-105 transition-all duration-500 z-10" style={{ height: '90%', objectFit: 'contain', top: '50%', transform: 'translateY(-50%) rotate(3deg)' }}
                />
                {/* Bottom content */}
                <div className="absolute bottom-0 left-0 right-0 p-3 z-20">
                  <div className="flex items-center gap-2 mb-0.5">
                    <ShoppingCart className="w-4 h-4 text-[#c41e3a]" />
                    <span className="text-white font-black text-sm tracking-wide" style={{ fontFamily: "Oswald, sans-serif" }}>SHOP CARDS</span>
                  </div>
                  <p className="text-white/70 text-[10px] leading-tight">Rookies • BGS Slabs • Rare Pulls<br/>Thousands of cards available now.</p>
                </div>
              </div>
              </Link>
            </div>

          </div>
          {/* ── Why We Collect CTA ── */}
          <div className="flex flex-col items-center justify-center mt-8 pb-2">
            <Link href="/why-we-collect" className="group flex flex-col items-center gap-1.5 text-center">
              <span className="inline-flex items-center gap-2.5 bg-white/10 hover:bg-white/20 border border-white/30 hover:border-white/60 text-white font-black text-lg px-8 py-3.5 rounded-full shadow-lg hover:shadow-white/20 transition-all duration-300 tracking-wide" style={{ fontFamily: 'Oswald, sans-serif' }}>
                <span className="text-red-400 text-xl">♥</span> This is Why We Collect
              </span>
              <span className="text-white/50 text-xs italic group-hover:text-white/80 transition-colors duration-300">Based on a True Story by &ldquo;Chasing Cardboard&rdquo;</span>
            </Link>
          </div>
        </div>
      </section>

      {/* ── Kids Corner Hero Ad Banner ─────────────────────────────── */}
      <section className="hidden lg:block bg-gradient-to-r from-[#1a1a2e] via-[#16213e] to-[#0f3460] border-y-2 border-yellow-400/40 overflow-hidden relative">
        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-yellow-400/5 to-transparent animate-pulse pointer-events-none" />
        {/* Animated team color dots */}
        <div className="absolute top-2 left-[8%] w-3 h-3 rounded-full bg-red-600 opacity-70 animate-bounce" style={{animationDelay:'0s'}} />
        <div className="absolute top-3 left-[15%] w-2 h-2 rounded-full bg-yellow-400 opacity-70 animate-bounce" style={{animationDelay:'0.3s'}} />
        <div className="absolute bottom-2 left-[22%] w-3 h-3 rounded-full bg-green-500 opacity-70 animate-bounce" style={{animationDelay:'0.6s'}} />
        <div className="absolute top-2 right-[22%] w-2 h-2 rounded-full bg-blue-500 opacity-70 animate-bounce" style={{animationDelay:'0.9s'}} />
        <div className="absolute bottom-3 right-[15%] w-3 h-3 rounded-full bg-purple-500 opacity-70 animate-bounce" style={{animationDelay:'1.2s'}} />
        <div className="absolute top-3 right-[8%] w-2 h-2 rounded-full bg-orange-400 opacity-70 animate-bounce" style={{animationDelay:'1.5s'}} />
        <div className="container py-3">
          <div className="flex items-center justify-between gap-6">
            {/* Left: Badge + headline */}
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-1.5 bg-yellow-400 text-black text-[10px] font-black px-3 py-1.5 rounded-full uppercase tracking-widest shrink-0 shadow-lg shadow-yellow-400/40 animate-pulse">
                🏆 Kids Corner
              </div>
              <div>
                <p className="text-white font-black text-base leading-tight" style={{fontFamily:'Oswald, sans-serif', letterSpacing:'0.05em'}}>
                  BUILD YOUR COLLECTION — FREE FOR KIDS!
                </p>
                <p className="text-yellow-300/80 text-[11px] font-semibold">
                  Jordan • Clark • Ruth • Griffey • Bird • Magic • Kobe — Collect the Greatest Athletes of All Time
                </p>
              </div>
            </div>
            {/* Center: Team color pills */}
            <div className="hidden xl:flex items-center gap-2 shrink-0">
              {[
                { name: 'Bulls', bg: 'bg-red-700', emoji: '🏀' },
                { name: 'Lakers', bg: 'bg-yellow-500', emoji: '🏀' },
                { name: 'Celtics', bg: 'bg-green-700', emoji: '🏀' },
                { name: 'Yankees', bg: 'bg-gray-800', emoji: '⚾' },
                { name: 'Cubs', bg: 'bg-blue-700', emoji: '⚾' },
              ].map(t => (
                <span key={t.name} className={`${t.bg} text-white text-[10px] font-black px-2.5 py-1 rounded-full flex items-center gap-1 shadow-md`}>
                  {t.emoji} {t.name}
                </span>
              ))}
            </div>
            {/* Right: Info + CTA */}
            <div className="flex items-center gap-3 shrink-0">
              <div className="text-right hidden xl:block">
                <p className="text-white/60 text-[10px] font-semibold">Ages 6+ • 100% FREE to play</p>
                <p className="text-yellow-400 text-[10px] font-black">🎯 Daily Credits • Card Pulls • Trivia • GAME TIME</p>
              </div>
              <Link href="/kids-corner">
                <button className="bg-gradient-to-r from-yellow-400 to-orange-500 hover:from-yellow-300 hover:to-orange-400 text-black font-black text-sm px-5 py-2.5 rounded-full shadow-lg shadow-orange-500/40 hover:shadow-orange-500/60 transition-all hover:scale-105 whitespace-nowrap">
                  🚀 Enter Kids Corner
                </button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* -- Live Game Times Ticker (desktop only) -------------------- */}
      <div className="hidden lg:block"><GameTimesTicker /></div>
      {/* SEO keywords — hidden until SEO pass */}
      {/* Free Basketball Card Comps • Free Football Card Comps • Free Baseball Card Comps • Free Hockey Card Comps • Free Soccer Card Comps • Free UFC Card Comps • Free Wrestling Card Comps • Free Basketball Card Market Values • Free Football Card Market Values • Free Baseball Card Market Values • Free Hockey Card Market Values • Free Soccer Card Market Values • Free UFC Card Market Values • Free Wrestling Card Market Values • Sports Card Price Guide • PSA Card Values • Beckett Card Values • Sports Card Comp Lookup • Free Sports Card Grading Values • SCG Grading • SportCardsOnline.com */}


      {/* -- MAIN CONTENT + AUCTION SIDEBAR ----------------------------- */}
      <div style={{backgroundColor:'#ffffff', padding:'24px 0 32px'}}>
      <div className="container">
        <div className="flex gap-5">

          {/* -- LEFT: Marketplace Cards -------------------------------- */}
          <div className="flex-1 min-w-0">
            {/* ── eBay-style search bar ── */}
            <div className="mb-4">
              <div className="flex items-center gap-2 mb-3">
                <h2 className="text-xl font-bold flex items-center gap-2 shrink-0 text-gray-900" style={{ fontFamily: "Oswald, sans-serif" }}>
                  <ShoppingCart className="w-5 h-5 text-[#c41e3a]" />
                  Marketplace
                </h2>
                <div className="flex-1 relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400 pointer-events-none" />
                  <input
                    type="text"
                    placeholder="Search player, set, year..."
                    value={marketSearch}
                    onChange={e => { setMarketSearch(e.target.value); setPage(0); }}
                    className="w-full bg-white border border-gray-300 rounded-lg pl-9 pr-9 py-2 text-sm text-gray-900 placeholder-gray-400 focus:outline-none focus:border-[#c41e3a] focus:ring-1 focus:ring-[#c41e3a]/30 shadow-sm"
                  />
                  {marketSearch && (
                    <button onClick={() => setMarketSearch("")} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600">
                      <X className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </div>
              <div className="flex items-center gap-2 flex-wrap">
                <div className="flex gap-1 flex-wrap">
                  {MARKET_SPORTS.map(s => (
                    <button key={s} onClick={() => setMarketSport(s)}
                      className={`px-2.5 py-1 rounded-full text-[11px] font-semibold transition-colors border ${marketSport === s ? "bg-[#c41e3a] text-white border-[#c41e3a]" : "bg-white text-gray-600 border-gray-300 hover:border-[#c41e3a] hover:text-[#c41e3a]"}`}>
                      {s}
                    </button>
                  ))}
                </div>
                <div className="ml-auto flex items-center gap-1.5">
                  <select value={marketSort} onChange={e => setMarketSort(e.target.value)}
                    className="bg-white border border-gray-300 text-gray-700 text-[11px] rounded-lg px-2 py-1 focus:outline-none focus:border-[#c41e3a] shadow-sm">
                    <option value="price_desc">Price: High → Low</option>
                    <option value="price_asc">Price: Low → High</option>
                    <option value="newest">Newest First</option>
                  </select>
                  <button onClick={() => setMarketView("grid")} className={`p-1.5 rounded border ${marketView === "grid" ? "bg-[#c41e3a] text-white border-[#c41e3a]" : "text-gray-400 border-gray-300 hover:text-gray-700"}`}><Grid3X3 className="w-3.5 h-3.5" /></button>
                  <button onClick={() => setMarketView("list")} className={`p-1.5 rounded border ${marketView === "list" ? "bg-[#c41e3a] text-white border-[#c41e3a]" : "text-gray-400 border-gray-300 hover:text-gray-700"}`}><List className="w-3.5 h-3.5" /></button>
                </div>
              </div>
              {isSearching && (
                <div className="mt-2 flex items-center gap-2 text-xs text-gray-500">
                  <span>{filteredMarketCards.length} result{filteredMarketCards.length !== 1 ? "s" : ""}</span>
                  <button onClick={() => { setMarketSearch(""); setMarketSport("All"); }} className="text-[#c41e3a] hover:underline flex items-center gap-1"><X className="w-3 h-3" />Clear filters</button>
                </div>
              )}
            </div>

            {/* ── List view (eBay-style) ── */}
            {marketView === "list" && (
              <div className="space-y-2 mb-4">
                {searchPageCards.length > 0 ? searchPageCards.map((card) => (
                  <div key={card.id} className="group flex items-center gap-3 bg-white border border-gray-200 rounded-lg p-2.5 hover:border-[#c41e3a]/50 hover:shadow-sm cursor-pointer transition-all" onClick={(e) => openCardPopup(card, e)}>
                    <div className="w-12 h-16 shrink-0 rounded overflow-hidden bg-black/30">
                      <SlabFrame imageUrl={card.frontImageUrl} altText={card.title} labelColor={(card.labelColor as any) ?? 'dark'} labelBg={(card as any).labelBg} labelBorder={(card as any).labelBorder} labelMode={(card as any).labelMode} grade={card.aiGrade} gradeLabel={card.aiGradeLabel} playerName={card.playerName} setName={card.setName} year={card.year} cardNumber={card.cardNumber} certNumber={card.certNumber} cardId={card.id} sourceBadge={(card as any).source === 'ebay_import' ? 'E' : ((card as any).source === 'grading' ? 'G' : ((card as any).isMainStore ? 'H' : 'U'))} cardStatus={(card as any).status as any} isNew={card.createdAt ? (Date.now() - new Date(card.createdAt).getTime() < 86_400_000) : false} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-gray-900 font-semibold text-sm truncate">{card.playerName || card.title}</p>
                      <p className="text-gray-500 text-xs truncate">{[card.year, card.setName, card.cardNumber ? `#${card.cardNumber}` : ""].filter(Boolean).join(" · ")}</p>
                      <div className="flex items-center gap-2 mt-1">
                        {card.aiGradeLabel && <span className="text-[10px] bg-yellow-500/20 text-yellow-400 px-1.5 py-0.5 rounded font-bold">{card.aiGradeLabel} {card.aiGrade}</span>}
                        {card.sport && <span className="text-[10px] bg-white/10 text-white/50 px-1.5 py-0.5 rounded">{card.sport}</span>}
                      </div>
                    </div>
                    <div className="shrink-0 text-right flex flex-col items-end gap-1">
                      <p className="text-[#c41e3a] font-black text-base">${parseFloat(card.price || "0").toFixed(2)}</p>
                      {/* Source badge */}
                      {(card as any).source === 'ebay_import'
                        ? <span className="bg-blue-500/90 text-white text-[8px] font-bold px-1.5 py-0.5 rounded leading-none">E</span>
                        : (card as any).source === 'grading'
                          ? <span className="bg-purple-500/90 text-white text-[8px] font-bold px-1.5 py-0.5 rounded leading-none">G</span>
                          : (card as any).isMainStore
                            ? <span className="bg-amber-500/90 text-white text-[8px] font-black px-1.5 py-0.5 rounded leading-none">H</span>
                            : <span className="bg-emerald-500/90 text-white text-[8px] font-bold px-1.5 py-0.5 rounded leading-none">U</span>
                      }
                      {/* Admin actions */}
                      {isAdmin && (
                        <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                          <button
                            className="text-gray-400 hover:text-blue-600 transition-colors p-0.5"
                            title="Edit card"
                            onClick={(e) => {
                              e.stopPropagation();
                              setEditCard(card);
                              setEditPrice(card.price ? parseFloat(card.price).toFixed(2) : "");
                              setEditPlayerName((card as any).playerName || "");
                              setEditSetName((card as any).setName || "");
                              setEditYear((card as any).year || "");
                              setEditGrade((card as any).aiGrade || "");
                              setEditSport((card as any).sport || "");
                              setEditStatus((card as any).status || "active");
                              setEditCardNumber((card as any).cardNumber || "");
                              setEditManufacturer((card as any).manufacturer || "");
                              setEditDescription((card as any).description || "");
                            }}
                          >
                            <Pencil className="w-3.5 h-3.5" />
                          </button>
                          <button
                            className="text-gray-400 hover:text-red-600 transition-colors p-0.5"
                            title="Delete card"
                            onClick={(e) => {
                              e.stopPropagation();
                              if (confirm(`Delete "${(card as any).playerName || card.title}"? This cannot be undone.`)) {
                                adminDeleteCard.mutate({ cardId: card.id });
                              }
                            }}
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                )) : (
                  <div className="text-center py-12 text-white/40">
                    <Search className="w-10 h-10 mx-auto mb-2 opacity-30" />
                    <p className="text-sm">No cards match your search.</p>
                  </div>
                )}
              </div>
            )}

            {/* ── Grid view ── */}
            {marketView === "grid" && (
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-3 lg:gap-4">
                {searchPageCards.length > 0 ? searchPageCards.map((card) => (
                  <div
                    key={card.id}
                    className="group cursor-pointer rounded-lg overflow-hidden border border-gray-200 bg-white hover:border-[#c41e3a] hover:shadow-md hover:shadow-[#c41e3a]/20 transition-all relative"
                    onClick={(e) => openCardPopup(card, e)}
                  >
                    <div className="aspect-[2/3] overflow-hidden relative">
                      <SlabFrame
                        imageUrl={card.frontImageUrl}
                        altText={card.title}
                        labelColor={(card.labelColor as any) ?? "dark"}
                        labelBg={(card as any).labelBg}
                        labelBorder={(card as any).labelBorder}
                        labelMode={(card as any).labelMode}
                        grade={card.aiGrade}
                        gradeLabel={card.aiGradeLabel}
                        playerName={card.playerName}
                        setName={card.setName}
                        year={card.year}
                        cardNumber={card.cardNumber}
                        certNumber={card.certNumber}
                        cardId={card.id}
                        sourceBadge={(card as any).source === 'ebay_import' ? 'E' : ((card as any).source === 'grading' ? 'G' : ((card as any).isMainStore ? 'H' : 'U'))}
                        cardStatus={(card as any).status as any}
                        isNew={card.createdAt ? (Date.now() - new Date(card.createdAt).getTime() < 86_400_000) : false}
                      />
                      {/* Admin quick-action buttons — appear on hover */}
                      {isAdmin && (
                        <div className="absolute top-1 right-1 z-20 flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                          <button
                            className="bg-white/90 hover:bg-white text-gray-700 hover:text-blue-600 rounded p-1 shadow-sm transition-colors"
                            title="Edit card"
                            onClick={(e) => {
                              e.stopPropagation();
                              setEditCard(card);
                              setEditPrice(card.price ? parseFloat(card.price).toFixed(2) : "");
                              setEditPlayerName((card as any).playerName || "");
                              setEditSetName((card as any).setName || "");
                              setEditYear((card as any).year || "");
                              setEditGrade((card as any).aiGrade || "");
                              setEditSport((card as any).sport || "");
                              setEditStatus((card as any).status || "active");
                              setEditCardNumber((card as any).cardNumber || "");
                              setEditManufacturer((card as any).manufacturer || "");
                              setEditDescription((card as any).description || "");
                            }}
                          >
                            <Pencil className="w-3 h-3" />
                          </button>
                          <button
                            className="bg-white/90 hover:bg-white text-gray-700 hover:text-red-600 rounded p-1 shadow-sm transition-colors"
                            title="Delete card"
                            onClick={(e) => {
                              e.stopPropagation();
                              if (confirm(`Delete "${(card as any).playerName || card.title}"? This cannot be undone.`)) {
                                adminDeleteCard.mutate({ cardId: card.id });
                              }
                            }}
                          >
                            <Trash2 className="w-3 h-3" />
                          </button>
                        </div>
                      )}
                    </div>
                    <div className="p-2">
                      <p className="text-xs font-semibold text-gray-900 line-clamp-1 leading-tight">{(card as any).playerName || card.title}</p>
                      <p className="text-[10px] text-gray-500 line-clamp-1">{(card as any).year} {(card as any).setName}</p>
                      <div className="flex items-center justify-between mt-0.5">
                        <p className="text-sm font-bold text-[#c41e3a]">${parseFloat(card.price || "0").toFixed(2)}</p>
                        {(card as any).qty > 1 && (
                          <span className="text-[9px] bg-blue-100 text-blue-600 font-bold px-1 py-0.5 rounded leading-none">Qty {(card as any).qty}</span>
                        )}
                      </div>
                    </div>
                  </div>
                )) : (
                  <div className="col-span-full text-center py-12 text-gray-400">
                    <ShoppingCart className="w-10 h-10 mx-auto mb-2 opacity-30" />
                    <p className="text-sm">No cards listed yet. Be the first!</p>
                    {isAuthenticated && (
                      <Button asChild size="sm" className="mt-3 bg-[#c41e3a] hover:bg-[#c41e3a]/90 text-white">
                        <Link href="/grade">Grade &amp; List a Card</Link>
                      </Button>
                    )}
                  </div>
                )}
              </div>
            )}
            {/* Pagination — only in grid mode when not searching */}
            {marketView === "grid" && !isSearching && totalPages > 1 && (
              <div className="flex items-center justify-center gap-2 mt-4">
                <Button size="sm" variant="outline" disabled={page === 0} onClick={() => setPage(p => p - 1)} className="border-gray-300 text-gray-600 hover:bg-gray-100 text-xs h-7">Prev</Button>
                <span className="text-xs text-gray-500">Page {page + 1} of {totalPages}</span>
                <Button size="sm" variant="outline" disabled={page >= totalPages - 1} onClick={() => setPage(p => p + 1)} className="border-gray-300 text-gray-600 hover:bg-gray-100 text-xs h-7">Next</Button>
              </div>
            )}
          </div>

          {/* -- RIGHT: Live Auction Sidebar ---------------------------- */}
          <div className="hidden lg:flex flex-col w-64 xl:w-72 shrink-0">
            <div className="sticky top-16 bg-white rounded-xl border border-gray-200 shadow-sm p-3" style={{ maxHeight: "calc(100vh - 80px)", overflowY: "auto" }}>

              {/* Header */}
              <div className="flex items-center justify-between mb-2">
                <h2 className="text-base font-bold flex items-center gap-1.5 text-gray-900" style={{ fontFamily: "Oswald, sans-serif" }}>
                  <TrendingUp className="w-4 h-4 text-[#c41e3a]" />
                  Live Auctions
                </h2>
                <Button asChild variant="ghost" size="sm" className="text-[10px] text-gray-500 hover:text-gray-900 h-6 px-1.5">
                  <Link href="/auctions">View All</Link>
                </Button>
              </div>

              {/* ── Post Your Card CTA — TOP of sidebar ── */}
              <Button asChild size="sm" className="w-full mb-3 bg-[#c41e3a]/20 hover:bg-[#c41e3a] text-[#ff6b6b] hover:text-white border border-[#c41e3a]/30 text-xs transition-all">
                <Link href="/collection">
                  <Gavel className="w-3.5 h-3.5 mr-1.5" />Post Your Card to Auction
                </Link>
              </Button>

              {/* ── Search filter ── */}
              <div className="relative mb-2">
                <input
                  type="text"
                  placeholder="Search player..."
                  value={sidebarSearch}
                  onChange={e => setSidebarSearch(e.target.value)}
                  className="w-full bg-white border border-gray-300 rounded-lg px-2.5 py-1.5 text-xs text-gray-900 placeholder-gray-400 focus:outline-none focus:border-[#c41e3a] shadow-sm"
                />
                {sidebarSearch && (
                  <button onClick={() => setSidebarSearch("")} className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 text-xs">✕</button>
                )}
              </div>

              {/* ── Auto-scrolling auction list ── */}
              {auctionsLoading ? (
                <div className="flex flex-col gap-2">
                  {Array.from({ length: 4 }).map((_, i) => (
                    <div key={i} className="rounded-lg border border-white/10 bg-[#0d1f3c] p-2 flex gap-2 animate-pulse">
                      <div className="w-12 h-16 rounded bg-white/10 shrink-0" />
                      <div className="flex-1 space-y-1.5 py-1">
                        <div className="h-2.5 bg-white/10 rounded w-full" />
                        <div className="h-2 bg-white/10 rounded w-3/4" />
                        <div className="h-2 bg-white/10 rounded w-1/2" />
                      </div>
                    </div>
                  ))}
                </div>
              ) : filteredSidebarAuctions.length > 0 ? (
                /* JS-scrolled container — overflow-y scroll but hidden scrollbar */
                <div
                  ref={scrollContainerRef}
                  className="overflow-y-scroll"
                  style={{ maxHeight: "calc(100vh - 230px)", scrollbarWidth: "none" }}
                  onMouseEnter={() => { isHoveringRef.current = true; }}
                  onMouseLeave={() => { isHoveringRef.current = false; }}
                >
                  {/* Duplicated list for seamless infinite loop */}
                  <div className="flex flex-col gap-2">
                    {/* First copy */}
                    {filteredSidebarAuctions.map((auction: any) => (
                      <Link key={`a-${auction.id}`} href={`/auctions/${auction.id}`}>
                        <div className="group cursor-pointer rounded-lg border border-white/10 bg-[#0d1f3c] hover:border-[#c41e3a]/50 hover:shadow-sm hover:shadow-[#c41e3a]/20 transition-all p-2 flex gap-2">
                          <div className="w-12 h-16 rounded bg-[#0a1628] overflow-hidden shrink-0">
                            {auction.cardImageUrl ? (
                              <img src={auction.cardImageUrl} alt={auction.cardTitle} className="w-full h-full object-contain" loading="lazy" decoding="async" />
                            ) : (
                              <div className="w-full h-full flex items-center justify-center">
                                <Gavel className="w-4 h-4 text-white/20" />
                              </div>
                            )}
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="text-[11px] font-semibold text-white/90 line-clamp-2 leading-tight mb-1">{auction.cardTitle}</p>
                            <p className="text-[10px] text-white/50 mb-1">{auction.playerName}</p>
                            <div className="flex items-center justify-between">
                              <div>
                                <p className="text-[9px] text-white/40">{parseFloat(auction.currentBid || "0") > 0 ? "Current Bid" : "Min Bid"}</p>
                                <p className="text-xs font-bold text-[#c41e3a]">${parseFloat(parseFloat(auction.currentBid || "0") > 0 ? auction.currentBid! : auction.startingPrice || "0").toFixed(0)}</p>
                              </div>
                              <div className="text-right">
                                <p className="text-[9px] text-white/40 flex items-center gap-0.5 justify-end"><Clock className="w-2.5 h-2.5" /></p>
                                <p className="text-[10px] font-mono text-yellow-400"><AuctionCountdown endsAt={(auction as any).endTime} /></p>
                              </div>
                            </div>
                            <Badge variant="outline" className="text-[8px] mt-1 border-white/20 text-white/50 px-1 py-0">{auction.bidCount || 0} bids</Badge>
                          </div>
                        </div>
                      </Link>
                    ))}
                    {/* Duplicate copy for seamless loop */}
                    {filteredSidebarAuctions.map((auction: any) => (
                      <Link key={`b-${auction.id}`} href={`/auctions/${auction.id}`}>
                        <div className="group cursor-pointer rounded-lg border border-white/10 bg-[#0d1f3c] hover:border-[#c41e3a]/50 hover:shadow-sm hover:shadow-[#c41e3a]/20 transition-all p-2 flex gap-2">
                          <div className="w-12 h-16 rounded bg-[#0a1628] overflow-hidden shrink-0">
                            {auction.cardImageUrl ? (
                              <img src={auction.cardImageUrl} alt={auction.cardTitle} className="w-full h-full object-contain" loading="lazy" decoding="async" />
                            ) : (
                              <div className="w-full h-full flex items-center justify-center">
                                <Gavel className="w-4 h-4 text-white/20" />
                              </div>
                            )}
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="text-[11px] font-semibold text-white/90 line-clamp-2 leading-tight mb-1">{auction.cardTitle}</p>
                            <p className="text-[10px] text-white/50 mb-1">{auction.playerName}</p>
                            <div className="flex items-center justify-between">
                              <div>
                                <p className="text-[9px] text-white/40">{parseFloat(auction.currentBid || "0") > 0 ? "Current Bid" : "Min Bid"}</p>
                                <p className="text-xs font-bold text-[#c41e3a]">${parseFloat(parseFloat(auction.currentBid || "0") > 0 ? auction.currentBid! : auction.startingPrice || "0").toFixed(0)}</p>
                              </div>
                              <div className="text-right">
                                <p className="text-[9px] text-white/40 flex items-center gap-0.5 justify-end"><Clock className="w-2.5 h-2.5" /></p>
                                <p className="text-[10px] font-mono text-yellow-400"><AuctionCountdown endsAt={(auction as any).endTime} /></p>
                              </div>
                            </div>
                            <Badge variant="outline" className="text-[8px] mt-1 border-white/20 text-white/50 px-1 py-0">{auction.bidCount || 0} bids</Badge>
                          </div>
                        </div>
                      </Link>
                    ))}
                  </div>
                </div>
              ) : (
                <div className="text-center py-8 text-white/30">
                  <Gavel className="w-8 h-8 mx-auto mb-2 opacity-30" />
                  <p className="text-xs">No active auctions</p>
                </div>
              )}
            </div>
          </div>

        </div>
      </div>
      </div>

      {/* ── UP & COMING SECTION ─────────────────────────────────────── */}
      <UpAndComingSection onCardClick={openCardPopup} />

      {/* ── SMART ROTATION SECTION (3rd row) ────────────────────────── */}
      <SmartRotationSection onCardClick={openCardPopup} />

      {/* ── SHOWCASE SECTION ────────────────────────────────────────── */}
      <ShowcaseSection onCardClick={openCardPopup} />

      {/* -- CTA for non-authenticated ---------------------------------- */}
      {!isAuthenticated && (
        <section className="mt-10 py-10 bg-gradient-to-r from-[#c41e3a]/10 to-[#1a3a6b]/10 border-y border-white/10">
          <div className="container text-center">
            <h2 className="text-2xl font-black text-white mb-2" style={{ fontFamily: "Oswald, sans-serif" }}>
              Ready to Start Collecting?
            </h2>
            <p className="text-white/60 mb-5">Join thousands of collectors buying, selling, and grading sports cards.</p>
            <Button asChild size="lg" className="bg-[#c41e3a] hover:bg-[#c41e3a]/90 text-white font-bold">
              <a href={getLoginUrl()}>Get Started Free</a>
            </Button>
          </div>
        </section>
      )}

      {/* Comps / Values panels */}
      <CompsPanel open={compsOpen} onClose={() => setCompsOpen(false)} />
      <ValuesPanel open={valuesOpen} onClose={() => setValuesOpen(false)} />

    </div>

    {/* Card Popup */}
    <CardPopup
      card={popupCard}
      open={popupOpen}
      onClose={() => { setPopupOpen(false); setPopupCard(null); }}
    />

    {/* Admin Full-Edit Dialog */}
    {isAdmin && editCard && (
      <Dialog open={!!editCard} onOpenChange={(open) => { if (!open) setEditCard(null); }}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-sm font-bold text-[#c41e3a]">✏️ Edit Card — #{editCard.id}</DialogTitle>
          </DialogHeader>
          <div className="space-y-3 py-2">
            {/* Row 1: Player + Year */}
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-xs text-gray-500 mb-1 block font-medium">Player Name</label>
                <Input value={editPlayerName} onChange={(e) => setEditPlayerName(e.target.value)} placeholder="Player name" className="h-8 text-sm" />
              </div>
              <div>
                <label className="text-xs text-gray-500 mb-1 block font-medium">Year</label>
                <Input value={editYear} onChange={(e) => setEditYear(e.target.value)} placeholder="e.g. 2023" className="h-8 text-sm" />
              </div>
            </div>
            {/* Row 2: Set + Card # */}
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-xs text-gray-500 mb-1 block font-medium">Set Name</label>
                <Input value={editSetName} onChange={(e) => setEditSetName(e.target.value)} placeholder="e.g. Prizm" className="h-8 text-sm" />
              </div>
              <div>
                <label className="text-xs text-gray-500 mb-1 block font-medium">Card #</label>
                <Input value={editCardNumber} onChange={(e) => setEditCardNumber(e.target.value)} placeholder="e.g. 275" className="h-8 text-sm" />
              </div>
            </div>
            {/* Row 3: Manufacturer + Sport */}
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-xs text-gray-500 mb-1 block font-medium">Manufacturer</label>
                <Input value={editManufacturer} onChange={(e) => setEditManufacturer(e.target.value)} placeholder="e.g. Panini" className="h-8 text-sm" />
              </div>
              <div>
                <label className="text-xs text-gray-500 mb-1 block font-medium">Sport</label>
                <select value={editSport} onChange={(e) => setEditSport(e.target.value)} className="h-8 text-sm w-full border border-gray-200 rounded-md px-2 bg-white">
                  <option value="">-- Select --</option>
                  <option value="baseball">Baseball</option>
                  <option value="basketball">Basketball</option>
                  <option value="football">Football</option>
                  <option value="hockey">Hockey</option>
                  <option value="soccer">Soccer</option>
                  <option value="other">Other</option>
                </select>
              </div>
            </div>
            {/* Row 4: Grade + Status */}
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-xs text-gray-500 mb-1 block font-medium">Grade (SCO)</label>
                <select value={editGrade} onChange={(e) => setEditGrade(e.target.value)} className="h-8 text-sm w-full border border-gray-200 rounded-md px-2 bg-white">
                  <option value="">-- No grade --</option>
                  {["10","9.5","9","8.5","8","7.5","7","6.5","6","5.5","5","4.5","4","3.5","3","2","1.5","1"].map(g => (
                    <option key={g} value={g}>{g}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="text-xs text-gray-500 mb-1 block font-medium">Status</label>
                <select value={editStatus} onChange={(e) => setEditStatus(e.target.value)} className="h-8 text-sm w-full border border-gray-200 rounded-md px-2 bg-white">
                  <option value="active">Active</option>
                  <option value="draft">Draft</option>
                  <option value="sold">Sold</option>
                  <option value="auction">Auction</option>
                  <option value="traded">Traded</option>
                  <option value="casino">Casino</option>
                  <option value="bank">Bank</option>
                </select>
              </div>
            </div>
            {/* Row 5: Price */}
            <div>
              <label className="text-xs text-gray-500 mb-1 block font-medium">Price ($)</label>
              <Input value={editPrice} onChange={(e) => setEditPrice(e.target.value)} placeholder="0.00" className="h-8 text-sm" />
            </div>
            {/* Row 6: Description */}
            <div>
              <label className="text-xs text-gray-500 mb-1 block font-medium">Description</label>
              <textarea value={editDescription} onChange={(e) => setEditDescription(e.target.value)} placeholder="Card description..." className="w-full text-sm border border-gray-200 rounded-md px-3 py-2 resize-none h-16 focus:outline-none focus:ring-1 focus:ring-[#c41e3a]" />
            </div>
            {/* Action buttons */}
            <div className="flex gap-2 pt-1">
              <Button
                size="sm"
                className="flex-1 bg-[#c41e3a] hover:bg-[#c41e3a]/90 text-white"
                disabled={adminUpdateCard.isPending}
                onClick={() => {
                  adminUpdateCard.mutate({
                    cardId: editCard.id,
                    price: editPrice || undefined,
                    playerName: editPlayerName || undefined,
                    setName: editSetName || undefined,
                    year: editYear || undefined,
                    aiGrade: editGrade || undefined,
                    sport: (editSport as any) || undefined,
                    status: (editStatus as any) || undefined,
                    cardNumber: editCardNumber || undefined,
                    manufacturer: editManufacturer || undefined,
                    description: editDescription || undefined,
                  });
                }}
              >
                {adminUpdateCard.isPending ? "Saving…" : "💾 Save Changes"}
              </Button>
              <Button size="sm" variant="outline" onClick={() => setEditCard(null)}>Cancel</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    )}

    {/* List Your Card Modal */}
    <Dialog open={listCardOpen} onOpenChange={setListCardOpen}>
      <DialogContent className="max-w-lg bg-white">
        <DialogHeader>
          <DialogTitle className="text-xl font-black text-gray-900" style={{ fontFamily: 'Oswald, sans-serif' }}>
            🏷️ List Your Card on SportCardsOnline
          </DialogTitle>
        </DialogHeader>
        <div className="space-y-4 text-sm text-gray-700">
          <p className="text-gray-600">It’s free to register and list your cards. Here’s how to get started:</p>
          <ol className="space-y-3">
            <li className="flex gap-3">
              <span className="flex-shrink-0 w-7 h-7 rounded-full bg-[#c41e3a] text-white text-xs font-black flex items-center justify-center">1</span>
              <div><p className="font-semibold text-gray-900">Create a Free Account</p><p className="text-gray-500 text-xs mt-0.5">Sign up in seconds — no credit card needed.</p></div>
            </li>
            <li className="flex gap-3">
              <span className="flex-shrink-0 w-7 h-7 rounded-full bg-[#c41e3a] text-white text-xs font-black flex items-center justify-center">2</span>
              <div><p className="font-semibold text-gray-900">Import Your Card</p><p className="text-gray-500 text-xs mt-0.5">Import by .CSV upload, paste a URL, or grade it with our AI SCG tool — we pull all the details automatically.</p></div>
            </li>
            <li className="flex gap-3">
              <span className="flex-shrink-0 w-7 h-7 rounded-full bg-[#c41e3a] text-white text-xs font-black flex items-center justify-center">3</span>
              <div><p className="font-semibold text-gray-900">List It Your Way</p><p className="text-gray-500 text-xs mt-0.5">Post to the Marketplace, run a 3-day auction, save to your Collection, use for Gaming Room credits, or offer for trades.</p></div>
            </li>
            <li className="flex gap-3">
              <span className="flex-shrink-0 w-7 h-7 rounded-full bg-[#c41e3a] text-white text-xs font-black flex items-center justify-center">4</span>
              <div><p className="font-semibold text-gray-900">Secure Escrow &amp; Ship</p><p className="text-gray-500 text-xs mt-0.5">Buyer's funds are held in escrow. You sign a shipping agreement, get a tracking number, log it on the platform — we all track the card together. Payment releases on confirmed delivery.</p></div>
            </li>
            <li className="flex gap-3">
              <span className="flex-shrink-0 w-7 h-7 rounded-full bg-[#c41e3a] text-white text-xs font-black flex items-center justify-center">5</span>
              <div><p className="font-semibold text-gray-900">Get Paid — 90% Payout</p><p className="text-gray-500 text-xs mt-0.5">You keep 90% of the sale price. We handle the platform &amp; escrow.</p></div>
            </li>
          </ol>
          {/* Tutorial video link */}
          <div className="bg-gray-50 border border-gray-200 rounded-lg p-3 flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-red-600 flex items-center justify-center shrink-0">
              <svg className="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>
            </div>
            <div>
              <p className="font-semibold text-gray-900 text-xs">Watch: How to List Your First Card</p>
              <a href="https://www.youtube.com/@SportCardsOnline" target="_blank" rel="noopener noreferrer" className="text-[#c41e3a] text-xs hover:underline">youtube.com/@SportCardsOnline →</a>
            </div>
          </div>
          <div className="flex gap-2 pt-1">
            <Button asChild className="flex-1 bg-[#c41e3a] hover:bg-[#c41e3a]/90 text-white font-bold">
              <a href={getLoginUrl("/my-collection")}>⚡ Sign Up Free &amp; Start Listing</a>
            </Button>
            <Button variant="outline" onClick={() => setListCardOpen(false)}>Close</Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>

    <Footer />
    </>
  );
}
