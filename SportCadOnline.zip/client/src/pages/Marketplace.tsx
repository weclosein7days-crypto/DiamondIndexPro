import { trpc } from "@/lib/trpc";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Award, Search, X, ChevronDown, ChevronUp, ShieldCheck, Star, Zap, Trash2, CheckSquare, Square } from "lucide-react";
import { SlabFrame } from "@/components/SlabFrame";
import { FavoriteButton, useFavoriteIds } from "@/components/FavoriteButton";
import { useAuth } from "@/_core/hooks/useAuth";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import CardPopup from "@/components/CardPopup";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { toast } from "sonner";

const SPORTS = ["All", "Baseball", "Basketball", "Football", "Hockey", "Soccer", "Golf", "Other"];
const GRADES = ["All", "10", "9.5", "9", "8.5", "8", "7", "Raw"];
const PRICE_RANGES = [
  { label: "All Prices", min: 0, max: Infinity },
  { label: "Under $25", min: 0, max: 25 },
  { label: "$25 – $100", min: 25, max: 100 },
  { label: "$100 – $500", min: 100, max: 500 },
  { label: "$500+", min: 500, max: Infinity },
];
const SORT_OPTIONS = [
  { label: "Newly Listed", value: "newest" },
  { label: "Price: Low to High", value: "price_asc" },
  { label: "Price: High to Low", value: "price_desc" },
  { label: "Grade: High to Low", value: "grade_desc" },
];

/** Sport label + color for the featured strip badges */
const SPORT_BADGE: Record<string, { label: string; color: string }> = {
  basketball: { label: "🏀 Basketball", color: "bg-orange-500/20 text-orange-300 border-orange-500/30" },
  football:   { label: "🏈 Football",   color: "bg-green-500/20 text-green-300 border-green-500/30" },
  baseball:   { label: "⚾ Baseball",   color: "bg-blue-500/20 text-blue-300 border-blue-500/30" },
  hockey:     { label: "🏒 Hockey",     color: "bg-cyan-500/20 text-cyan-300 border-cyan-500/30" },
  soccer:     { label: "⚽ Soccer",     color: "bg-yellow-500/20 text-yellow-300 border-yellow-500/30" },
  golf:       { label: "⛳ Golf",       color: "bg-emerald-500/20 text-emerald-300 border-emerald-500/30" },
  other:      { label: "🃏 Other",      color: "bg-purple-500/20 text-purple-300 border-purple-500/30" },
};

/** Get or create a stable localStorage visitor key for personalization */
function getVisitorKey(): string {
  let key = localStorage.getItem("sco_visitor_id");
  if (!key) {
    key = Math.random().toString(36).slice(2) + Date.now().toString(36);
    localStorage.setItem("sco_visitor_id", key);
  }
  return key;
}

// ── Collapsible filter section ─────────────────────────────────────────────
function FilterSection({ title, children }: { title: string; children: React.ReactNode }) {
  const [open, setOpen] = useState(true);
  return (
    <div className="border-b border-white/10 pb-4 mb-4">
      <button
        onClick={() => setOpen(o => !o)}
        className="flex items-center justify-between w-full text-sm font-bold text-white/80 mb-3 hover:text-white transition-colors"
      >
        {title}
        {open ? <ChevronUp className="w-3.5 h-3.5 text-white/40" /> : <ChevronDown className="w-3.5 h-3.5 text-white/40" />}
      </button>
      {open && children}
    </div>
  );
}

// ── Featured Strip ─────────────────────────────────────────────────────────
function FeaturedStrip({ onCardClick }: { onCardClick: (card: any) => void }) {
  const [visitorKey] = useState(() => {
    try { return getVisitorKey(); } catch { return "guest"; }
  });
  const { data: featured, isLoading } = trpc.cards.getFeatured.useQuery(
    { visitorKey },
    { staleTime: 5 * 60_000 } // cache 5 min — changes daily anyway
  );

  if (isLoading) {
    return (
      <div className="mb-6 bg-[#0d1f3c] border border-white/10 rounded-2xl p-4">
        <div className="flex items-center gap-2 mb-3">
          <div className="w-4 h-4 rounded bg-white/10 animate-pulse" />
          <div className="h-4 w-32 rounded bg-white/10 animate-pulse" />
        </div>
        <div className="flex gap-3 overflow-x-auto pb-1">
          {Array.from({ length: 8 }).map((_, i) => (
            <div key={i} className="flex-shrink-0 w-20 animate-pulse">
              <div className="aspect-[2/3] rounded-lg bg-white/5 mb-1.5" />
              <div className="h-2.5 rounded bg-white/5 mb-1" />
              <div className="h-3 rounded bg-white/5 w-2/3" />
            </div>
          ))}
        </div>
      </div>
    );
  }

  if (!featured || featured.length === 0) return null;

  return (
    <div className="mb-6 bg-[#0d1f3c] border border-[#C41E3A]/20 rounded-2xl p-4">
      <div className="flex items-center gap-2 mb-3">
        <Zap className="w-4 h-4 text-[#E8C547]" />
        <h2 className="text-sm font-bold text-white" style={{ fontFamily: "Oswald, sans-serif" }}>
          Today's Picks
        </h2>
        <span className="text-[10px] text-white/30 ml-1">· Sport-weighted · $500 cap · Refreshes daily</span>
      </div>
      <div className="flex gap-4 overflow-x-auto pb-2 scrollbar-thin scrollbar-thumb-white/10 scrollbar-track-transparent">
        {featured.map(card => {
          const sportInfo = SPORT_BADGE[(card.sport ?? "other").toLowerCase()] ?? SPORT_BADGE.other;
          const isWnba = card.sport === "basketball" && (card as any).isMainStore;
          return (
            <div
              key={card.id}
              onClick={() => onCardClick(card)}
              className="flex-shrink-0 w-[160px] cursor-pointer group"
            >
              <div className="relative aspect-[2/3] rounded-xl overflow-hidden border border-white/10 group-hover:border-[#C41E3A]/60 transition-all group-hover:shadow-lg group-hover:shadow-[#c41e3a]/20">
                {card.frontImageUrl ? (
                  <img
                    src={card.frontImageUrl}
                    alt={card.title}
                    className="w-full h-full object-contain bg-[#0a0a0f]"
                  />
                ) : (
                  <div className="w-full h-full bg-[#0a1628] flex items-center justify-center">
                    <Award className="w-8 h-8 text-white/10" />
                  </div>
                )}
                {/* WNBA house badge */}
                {isWnba && (
                  <div className="absolute top-0 left-0 right-0 bg-gradient-to-r from-[#c41e3a] to-[#ff6b35] text-white text-[9px] font-black text-center py-1 tracking-widest">
                    WNBA ★ HOUSE
                  </div>
                )}
                {/* NEW badge — cards added in the last 24 hours */}
                {(card as any).createdAt && (Date.now() - new Date((card as any).createdAt).getTime() < 86_400_000) && (
                  <div className="absolute top-2 right-2 z-20 pointer-events-none">
                    <span
                      className="text-white font-black text-[9px] tracking-widest px-1.5 py-0.5 rounded"
                      style={{
                        fontFamily: "'Oswald', sans-serif",
                        background: 'linear-gradient(135deg, #15803d 0%, #22c55e 60%, #4ade80 100%)',
                        boxShadow: '0 0 10px rgba(34,197,94,0.9), 0 0 20px rgba(34,197,94,0.4)',
                        border: '1px solid rgba(255,255,255,0.4)',
                        letterSpacing: '1.8px',
                      }}
                    >NEW</span>
                  </div>
                )}
              </div>
              <div className="mt-2 px-0.5">
                <p className="text-white font-black text-sm leading-tight line-clamp-1 group-hover:text-[#E8C547] transition-colors">
                  {card.playerName || card.title}
                </p>
                <div className="flex items-center justify-between mt-0.5">
                  <p className="text-[#c41e3a] font-black text-sm">${parseFloat(card.price ?? "0").toFixed(0)}</p>
                  <span className={`text-[9px] px-1.5 py-0.5 rounded border ${sportInfo.color}`}>
                    {card.sport?.toUpperCase()}
                  </span>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

export default function Marketplace() {
  const { isAuthenticated, user } = useAuth();
  const isAdmin = user?.role === "admin";
  const [searchQuery, setSearchQuery] = useState("");
  const [sport, setSport] = useState("All");
  const [grade, setGrade] = useState("All");
  const [sort, setSort] = useState("newest");
  const [priceRange, setPriceRange] = useState(0);
  const [gradedOnly, setGradedOnly] = useState<"all" | "yes" | "no">("all");
  const [vaultedOnly, setVaultedOnly] = useState(false);
  const [selectedCard, setSelectedCard] = useState<any>(null);
  const [popupOpen, setPopupOpen] = useState(false);
  const [selectedIds, setSelectedIds] = useState<Set<number>>(new Set());
  const [showBulkDeleteConfirm, setShowBulkDeleteConfirm] = useState(false);

  // Stable visitor key for personalization
  const [visitorKey] = useState(() => {
    try { return getVisitorKey(); } catch { return "guest"; }
  });

  // Record search mutation for personalization
  const recordSearch = trpc.cards.recordSearch.useMutation();

  // Debounce search recording — fire 1s after user stops typing
  const searchDebounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  useEffect(() => {
    if (!searchQuery.trim() || searchQuery.trim().length < 3) return;
    if (searchDebounceRef.current) clearTimeout(searchDebounceRef.current);
    searchDebounceRef.current = setTimeout(() => {
      recordSearch.mutate({
        visitorKey,
        query: searchQuery.trim(),
        sport: sport !== "All" ? sport.toLowerCase() : undefined,
        playerName: searchQuery.trim(),
      });
    }, 1000);
    return () => {
      if (searchDebounceRef.current) clearTimeout(searchDebounceRef.current);
    };
  }, [searchQuery, sport]);

  const bulkDelete = trpc.cards.adminBulkDelete.useMutation({
    onSuccess: (data: any) => {
      toast.success(`Deleted ${data?.deleted ?? selectedIds.size} card${selectedIds.size !== 1 ? 's' : ''}`);
      setSelectedIds(new Set());
      setShowBulkDeleteConfirm(false);
      trpc.useUtils().cards.list.invalidate();
    },
    onError: () => toast.error("Failed to delete cards"),
  });

  const toggleSelect = (e: React.MouseEvent, id: number) => {
    e.stopPropagation();
    setSelectedIds(prev => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  };

  const selectAll = () => setSelectedIds(new Set(filteredCards.map(c => c.id)));
  const clearSelection = () => setSelectedIds(new Set());

  const sportParam = sport !== "All" ? sport : undefined;
  const { data: cards, isLoading } = trpc.cards.list.useQuery(
    { limit: 300, sport: sportParam },
    { staleTime: 30_000 }
  );
  const favoriteIds = useFavoriteIds();

  // Similar cards query
  const { data: similarCards } = trpc.interests.similarCards.useQuery(
    {
      playerName: selectedCard?.playerName ?? "",
      sport: selectedCard?.sport ?? undefined,
      price: selectedCard ? parseFloat(selectedCard.price ?? "0") : undefined,
      limit: 10,
    },
    { enabled: !!selectedCard }
  );

  const trackInterest = trpc.interests.track.useMutation();

  const openCard = useCallback((card: any) => {
    window.location.href = `/card/${card.id}`;
    if (isAuthenticated) {
      trackInterest.mutate({
        playerName: card.playerName,
        sport: card.sport ?? null,
        avgPrice: parseFloat(card.price ?? "0"),
      });
    }
  }, [isAuthenticated]);

  const openQuickView = useCallback((card: any, e: React.MouseEvent) => {
    e.stopPropagation();
    setSelectedCard(card);
    setPopupOpen(true);
    if (isAuthenticated) {
      trackInterest.mutate({
        playerName: card.playerName,
        sport: card.sport ?? null,
        avgPrice: parseFloat(card.price ?? "0"),
      });
    }
  }, [isAuthenticated]);

  useEffect(() => {
    const handler = (e: KeyboardEvent) => { if (e.key === "Escape") { setSelectedCard(null); setPopupOpen(false); } };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, []);

  const filteredCards = useMemo(() => {
    if (!cards) return [];
    let result = [...cards].sort((a, b) => {
      const aFav = favoriteIds.has(a.id) ? 0 : 1;
      const bFav = favoriteIds.has(b.id) ? 0 : 1;
      return aFav - bFav;
    });

    if (searchQuery.trim()) {
      const q = searchQuery.trim().toLowerCase();
      result = result.filter(c =>
        (c.playerName || "").toLowerCase().includes(q) ||
        (c.title || "").toLowerCase().includes(q) ||
        (c.setName || "").toLowerCase().includes(q)
      );
    }
    const pr = PRICE_RANGES[priceRange];
    if (pr.max !== Infinity || pr.min > 0) {
      result = result.filter(c => {
        const p = parseFloat(c.price ?? "0");
        return p >= pr.min && p <= pr.max;
      });
    }

    if (grade !== "All") {
      if (grade === "Raw") result = result.filter(c => !c.aiGrade);
      else result = result.filter(c => c.aiGrade === grade);
    }

    if (gradedOnly === "yes") result = result.filter(c => !!c.aiGrade);
    else if (gradedOnly === "no") result = result.filter(c => !c.aiGrade);

    if (vaultedOnly) result = result.filter(c => c.isVaulted);

    if (sort === "price_asc") result.sort((a, b) => parseFloat(a.price ?? "0") - parseFloat(b.price ?? "0"));
    else if (sort === "price_desc") result.sort((a, b) => parseFloat(b.price ?? "0") - parseFloat(a.price ?? "0"));
    else if (sort === "grade_desc") result.sort((a, b) => parseFloat(b.aiGrade ?? "0") - parseFloat(a.aiGrade ?? "0"));

    return result;
  }, [cards, searchQuery, sport, grade, sort, priceRange, gradedOnly, vaultedOnly, favoriteIds]);

  // Best selling = highest price cards (top 12)
  const bestSelling = useMemo(() => {
    if (!cards) return [];
    return [...cards]
      .sort((a, b) => parseFloat(b.price ?? "0") - parseFloat(a.price ?? "0"))
      .slice(0, 12);
  }, [cards]);

  const clearFilters = () => {
    setSport("All"); setGrade("All"); setPriceRange(0);
    setGradedOnly("all"); setVaultedOnly(false); setSearchQuery("");
  };

  const hasActiveFilters = sport !== "All" || grade !== "All" || priceRange > 0 || gradedOnly !== "all" || vaultedOnly;

  // Grade distribution for filter counts
  const gradeCounts = useMemo(() => {
    if (!cards) return {} as Record<string, number>;
    const counts: Record<string, number> = {};
    cards.forEach(c => {
      const g = c.aiGrade ?? "Raw";
      counts[g] = (counts[g] || 0) + 1;
    });
    return counts;
  }, [cards]);

  return (
    <>
    <div className="min-h-screen bg-[#0a1628]">
      {/* Header */}
      <div className="bg-[#0d1f3c] border-b border-white/10 py-4">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex flex-col sm:flex-row gap-3 items-start sm:items-center">
            <div>
              <h1 className="text-2xl font-bold text-white" style={{ fontFamily: "Oswald, sans-serif" }}>Marketplace</h1>
              <p className="text-white/50 text-sm">Buy premium sports cards from verified sellers</p>
            </div>
            <div className="flex-1 flex gap-2 sm:justify-end">
              <div className="relative flex-1 sm:max-w-md">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/30" />
                <Input
                  placeholder="Search player, set, card..."
                  value={searchQuery}
                  onChange={e => setSearchQuery(e.target.value)}
                  className="pl-10 bg-[#0a1628] border-white/10 text-white placeholder:text-white/30 h-9"
                />
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-6 flex gap-6">

        {/* ── LEFT FILTER SIDEBAR ── */}
        <aside className="hidden lg:block w-52 shrink-0">
          <div className="sticky top-4 space-y-0">
            {hasActiveFilters && (
              <button onClick={clearFilters} className="text-xs text-[#C41E3A] hover:underline flex items-center gap-1 mb-4">
                <X className="w-3 h-3" /> Clear all filters
              </button>
            )}

            <FilterSection title="Condition">
              <div className="space-y-2">
                {[
                  { key: "all", label: "All" },
                  { key: "yes", label: "Graded" },
                  { key: "no", label: "Ungraded / Raw" },
                ].map(opt => (
                  <label key={opt.key} className="flex items-center gap-2 cursor-pointer group">
                    <input
                      type="radio"
                      name="graded"
                      checked={gradedOnly === opt.key}
                      onChange={() => setGradedOnly(opt.key as "all" | "yes" | "no")}
                      className="accent-[#E8C547]"
                    />
                    <span className="text-xs text-white/70 group-hover:text-white transition-colors">{opt.label}</span>
                  </label>
                ))}
              </div>
            </FilterSection>

            <FilterSection title="Grade">
              <div className="space-y-1.5">
                {GRADES.filter(g => g !== "All").map(g => {
                  const count = g === "Raw" ? (gradeCounts["Raw"] || 0) : (gradeCounts[g] || 0);
                  return (
                    <label key={g} className="flex items-center gap-2 cursor-pointer group">
                      <input
                        type="checkbox"
                        checked={grade === g}
                        onChange={() => setGrade(grade === g ? "All" : g)}
                        className="accent-[#E8C547]"
                      />
                      <span className="text-xs text-white/70 group-hover:text-white transition-colors flex-1">{g}</span>
                      {count > 0 && <span className="text-[10px] text-white/30">({count})</span>}
                    </label>
                  );
                })}
              </div>
            </FilterSection>

            <FilterSection title="Sport">
              <div className="space-y-1.5">
                {SPORTS.filter(s => s !== "All").map(s => (
                  <label key={s} className="flex items-center gap-2 cursor-pointer group">
                    <input
                      type="checkbox"
                      checked={sport === s}
                      onChange={() => setSport(sport === s ? "All" : s)}
                      className="accent-[#E8C547]"
                    />
                    <span className="text-xs text-white/70 group-hover:text-white transition-colors">{s}</span>
                  </label>
                ))}
              </div>
            </FilterSection>

            <FilterSection title="Price Range">
              <div className="space-y-1.5">
                {PRICE_RANGES.map((pr, i) => (
                  <label key={pr.label} className="flex items-center gap-2 cursor-pointer group">
                    <input
                      type="radio"
                      name="price"
                      checked={priceRange === i}
                      onChange={() => setPriceRange(i)}
                      className="accent-[#E8C547]"
                    />
                    <span className="text-xs text-white/70 group-hover:text-white transition-colors">{pr.label}</span>
                  </label>
                ))}
              </div>
            </FilterSection>

            <FilterSection title="SCO Vault">
              <label className="flex items-center gap-2 cursor-pointer group">
                <input
                  type="checkbox"
                  checked={vaultedOnly}
                  onChange={() => setVaultedOnly(v => !v)}
                  className="accent-[#ffd700]"
                />
                <span className="text-xs text-white/70 group-hover:text-white transition-colors">SCO Vaulted Only</span>
              </label>
            </FilterSection>
          </div>
        </aside>

        {/* ── RIGHT CONTENT AREA ── */}
        <div className="flex-1 min-w-0">

          {/* ── TODAY'S PICKS FEATURED STRIP ── */}
          {!hasActiveFilters && !searchQuery.trim() && (
            <FeaturedStrip onCardClick={openCard} />
          )}

          {/* Sort bar */}
          <div className="flex items-center justify-between mb-4 gap-3">
            <p className="text-white/50 text-sm">
              <span className="text-white font-semibold">{filteredCards.length.toLocaleString()}</span> results
            </p>
            <div className="flex items-center gap-2">
              <span className="text-xs text-white/40 hidden sm:block">Sort:</span>
              <select
                value={sort}
                onChange={e => setSort(e.target.value)}
                className="bg-[#0d1f3c] border border-white/10 text-white text-xs rounded-lg px-2 py-1.5 focus:outline-none focus:border-white/30"
              >
                {SORT_OPTIONS.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
              </select>
            </div>
          </div>

          {/* ── ADMIN BULK SELECT BAR ── */}
          {isAdmin && filteredCards.length > 0 && (
            <div className="flex items-center gap-3 mb-3 px-1">
              <button
                onClick={selectedIds.size === filteredCards.length ? clearSelection : selectAll}
                className="flex items-center gap-1.5 text-xs text-white/50 hover:text-white transition-colors"
              >
                {selectedIds.size === filteredCards.length
                  ? <CheckSquare className="w-3.5 h-3.5 text-[#C41E3A]" />
                  : <Square className="w-3.5 h-3.5" />}
                {selectedIds.size === filteredCards.length ? "Deselect All" : "Select All"}
              </button>
              {selectedIds.size > 0 && (
                <span className="text-xs text-[#E8C547]">{selectedIds.size} selected</span>
              )}
            </div>
          )}

          {/* ── LIST VIEW ROWS ── */}
          {isLoading ? (
            <div className="space-y-3">
              {Array.from({ length: 8 }).map((_, i) => (
                <div key={i} className="bg-[#0d1f3c] border border-white/10 rounded-xl overflow-hidden animate-pulse flex gap-4 p-3">
                  <div className="w-28 h-40 bg-white/5 rounded-lg shrink-0" />
                  <div className="flex-1 space-y-3 py-2">
                    <div className="h-4 bg-white/5 rounded w-3/4" />
                    <div className="h-3 bg-white/5 rounded w-1/2" />
                    <div className="h-6 bg-white/5 rounded w-1/4" />
                  </div>
                </div>
              ))}
            </div>
          ) : filteredCards.length > 0 ? (
            <div className="space-y-2">
              {filteredCards.map(card => {
                const isSelected = selectedIds.has(card.id);
                return (
                <div
                  key={card.id}
                  onClick={() => !isAdmin || selectedIds.size === 0 ? openCard(card) : toggleSelect(null as any, card.id)}
                  className={`relative group bg-[#0d1f3c] border rounded-xl overflow-hidden hover:shadow-lg hover:shadow-black/30 transition-all cursor-pointer flex gap-0 ${
                    isSelected ? 'border-[#C41E3A] ring-1 ring-[#C41E3A]/40' : 'border-white/10 hover:border-white/25'
                  }`}
                >
                  {/* Admin checkbox */}
                  {isAdmin && (
                    <div
                      className="absolute top-2 left-2 z-30"
                      onClick={e => toggleSelect(e, card.id)}
                    >
                      <div className={`w-5 h-5 rounded border-2 flex items-center justify-center transition-all ${
                        isSelected
                          ? 'bg-[#C41E3A] border-[#C41E3A]'
                          : 'bg-black/50 border-white/30 opacity-0 group-hover:opacity-100'
                      }`}>
                        {isSelected && <span className="text-white text-[10px] font-black">✓</span>}
                      </div>
                    </div>
                  )}
                  {/* Card image */}
                  <div className="w-20 sm:w-24 shrink-0 relative">
                    <div className="aspect-[2/3] relative overflow-hidden">
                      <SlabFrame
                        imageUrl={card.frontImageUrl}
                        altText={card.title}
                        labelColor={(card.labelColor as any) ?? "dark"}
                        labelBg={(card as any).labelBg}
                        labelBorder={(card as any).labelBorder}
                        labelMode={(card as any).labelMode}
                        grade={(card as any).gradeScore || card.aiGrade}
                        gradeLabel={card.aiGradeLabel}
                        gradeCompany={(card as any).gradeCompany}
                        playerName={card.playerName}
                        setName={card.setName}
                        year={card.year}
                        cardNumber={card.cardNumber}
                        certNumber={card.certNumber}
                        cardId={card.id}
                        sourceBadge={(card as any).source === 'ebay_import' ? 'E' : ((card as any).source === 'grading' ? 'G' : ((card as any).isMainStore ? 'H' : 'U'))}
                        cardStatus={(card as any).status as any}
                        isNew={card.createdAt ? (Date.now() - new Date(card.createdAt).getTime() < 86_400_000) : false}
                      />
                      {card.isVaulted && (
                        <div className="absolute top-0 left-0 right-0 z-10 pointer-events-none">
                          <div className="bg-gradient-to-r from-[#b8860b] via-[#ffd700] to-[#b8860b] text-[#1a0a00] text-[8px] font-black text-center py-0.5 tracking-widest">
                            ★ SCO VAULT GUARANTEED ★
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                  {/* Quick View overlay — appears on row hover */}
                  <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-150 pointer-events-none z-20">
                    <div className="pointer-events-auto">
                      <Button
                        size="sm"
                        variant="outline"
                        className="bg-black/70 border-white/20 text-white text-[10px] h-7 px-2 backdrop-blur-sm hover:bg-black/90"
                        onClick={e => openQuickView(card, e)}
                      >
                        Quick View
                      </Button>
                    </div>
                  </div>
                  {/* Card details */}
                  <div className="flex-1 p-3 min-w-0">
                    <div className="flex items-start justify-between gap-2 mb-1">
                      <h3 className="text-sm font-bold text-white line-clamp-1 leading-tight">
                        {card.playerName || card.title}
                      </h3>
                      {isAdmin && (
                        <button
                          className="shrink-0 opacity-0 group-hover:opacity-100 transition-opacity"
                          onClick={e => { e.stopPropagation(); toggleSelect(e, card.id); }}
                        >
                        </button>
                      )}
                    </div>
                    <div className="flex flex-wrap items-center gap-2 mb-2">
                      {card.aiGrade ? (
                        <Badge className="bg-[#E8C547]/20 text-[#E8C547] border border-[#E8C547]/30 text-[10px] px-1.5 py-0">
                          SCO AI {card.aiGrade}{card.aiGradeLabel ? ` — ${card.aiGradeLabel}` : ""}
                        </Badge>
                      ) : (
                        <Badge className="bg-white/10 text-white/50 border border-white/10 text-[10px] px-1.5 py-0">
                          Raw / Ungraded
                        </Badge>
                      )}
                      {card.isVaulted && (
                        <Badge className="bg-[#ffd700]/20 text-[#ffd700] border border-[#ffd700]/30 text-[10px] px-1.5 py-0">
                          🏛 SCO Vaulted
                        </Badge>
                      )}
                      {card.sport && (
                        <span className="text-xs text-white/30">{card.sport}</span>
                      )}
                    </div>
                    {(card.setName || card.year) && (
                      <p className="text-xs text-white/40 mb-1 line-clamp-1">
                        {[card.year, card.setName, card.cardNumber ? `#${card.cardNumber}` : null].filter(Boolean).join(" · ")}
                      </p>
                    )}
                    {card.isVaulted && (
                      <p className="text-[10px] text-[#ffd700]/60 flex items-center gap-1 mt-1">
                        <ShieldCheck className="w-3 h-3" />
                        Authenticity &amp; shipping guaranteed by SCO
                      </p>
                    )}
                  </div>
                  {/* Admin-only market price reference */}
                  {isAdmin && (card as any).marketPrice && (
                    <div className="flex items-center gap-2 mb-1.5 px-2">
                      <span className="text-[9px] text-emerald-400/80 font-mono bg-emerald-400/10 px-1.5 py-0.5 rounded">
                        Mkt ${parseFloat((card as any).marketPrice).toFixed(0)}
                      </span>
                    </div>
                  )}
                  {/* Price + actions row */}
                  <div className="flex flex-col items-end justify-center gap-2 p-3 shrink-0">
                    <div className="text-right">
                      <p className={`text-base sm:text-lg font-black leading-none ${isAdmin && (card as any).isMainStore ? 'text-[#ffd700]' : 'text-white'}`}>
                        ${parseFloat(card.price ?? "0").toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                      </p>
                      <p className="text-[10px] text-white/30 mt-0.5">
                        {isAdmin ? ((card as any).isMainStore ? '🏠 House Card' : '📦 eBay Sourced') : 'Ships from seller'}
                      </p>
                    </div>
                    <div className="flex items-center gap-2 shrink-0">
                      <div onClick={e => e.stopPropagation()}>
                        <FavoriteButton cardId={card.id} initialFavorited={favoriteIds.has(card.id)} />
                      </div>
                      <Button
                        size="sm"
                        className="bg-[#C41E3A] hover:bg-[#a01830] text-white text-[10px] h-6 px-2 font-bold"
                        onClick={e => { e.stopPropagation(); openCard(card); }}
                      >
                        View Card
                      </Button>
                    </div>
                  </div>
                </div>
                );
              })}
            </div>
          ) : (
            <div className="text-center py-20 text-white/30">
              <Award className="w-16 h-16 mx-auto mb-4 text-white/10" />
              <h3 className="text-xl font-semibold mb-2 text-white/50">No cards found</h3>
              <p className="text-sm">Try adjusting your search or filters</p>
              {hasActiveFilters && (
                <button onClick={clearFilters} className="mt-3 text-[#C41E3A] hover:underline text-sm">
                  Clear all filters
                </button>
              )}
            </div>
          )}

          {/* ── BEST SELLING STRIP ── */}
          {bestSelling.length > 0 && (
            <div className="mt-10 pt-8 border-t border-white/10">
              <div className="flex items-center gap-2 mb-4">
                <Star className="w-5 h-5 text-[#E8C547]" />
                <h2 className="text-lg font-bold text-white" style={{ fontFamily: "Oswald, sans-serif" }}>
                  Best Selling Cards
                </h2>
              </div>
              <div className="flex gap-3 overflow-x-auto pb-3 scrollbar-thin scrollbar-thumb-white/10 scrollbar-track-transparent">
                {bestSelling.map(card => (
                  <div
                    key={card.id}
                    onClick={() => openCard(card)}
                    className="flex-shrink-0 w-24 cursor-pointer group"
                  >
                    <div className="relative aspect-[2/3] rounded-xl overflow-hidden mb-2 border border-white/10 group-hover:border-white/30 transition-colors">
                      {card.frontImageUrl ? (
                        <img
                          src={card.frontImageUrl}
                          alt={card.title}
                          className="w-full h-full object-contain bg-[#0a0a0f]"
                        />
                      ) : (
                        <div className="w-full h-full bg-[#0d1f3c] flex items-center justify-center">
                          <Award className="w-8 h-8 text-white/10" />
                        </div>
                      )}
                      {card.isVaulted && (
                        <div className="absolute top-0 left-0 right-0 bg-gradient-to-r from-[#b8860b] via-[#ffd700] to-[#b8860b] text-[#1a0a00] text-[7px] font-black text-center py-0.5 tracking-widest">
                          ★ SCO VAULTED ★
                        </div>
                      )}
                    </div>
                    <p className="text-xs text-white/70 line-clamp-2 leading-tight mb-0.5 group-hover:text-white transition-colors">
                      {card.title}
                    </p>
                    <p className="text-sm font-black text-white">
                      ${parseFloat(card.price ?? "0").toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>

    {/* Card Profile Popup */}
    <CardPopup
      card={selectedCard}
      open={popupOpen}
      onClose={() => { setPopupOpen(false); setSelectedCard(null); }}
    />

    {/* Admin Bulk Delete Floating Bar */}
    {isAdmin && selectedIds.size > 0 && (
      <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 flex items-center gap-3 bg-[#0d1f3c] border border-white/20 rounded-2xl shadow-2xl px-5 py-3">
        <span className="text-sm font-semibold text-white">{selectedIds.size} card{selectedIds.size !== 1 ? 's' : ''} selected</span>
        <button onClick={clearSelection} className="text-xs text-white/40 hover:text-white transition-colors">Clear</button>
        <Button
          size="sm"
          className="bg-[#C41E3A] hover:bg-[#a01830] text-white font-bold gap-1.5"
          onClick={() => setShowBulkDeleteConfirm(true)}
        >
          <Trash2 className="w-3.5 h-3.5" />
          Delete {selectedIds.size} Card{selectedIds.size !== 1 ? 's' : ''}
        </Button>
      </div>
    )}

    {/* Bulk Delete Confirmation */}
    <AlertDialog open={showBulkDeleteConfirm} onOpenChange={setShowBulkDeleteConfirm}>
      <AlertDialogContent className="bg-[#0d1f3c] border border-white/20 text-white">
        <AlertDialogHeader>
          <AlertDialogTitle>Delete {selectedIds.size} card{selectedIds.size !== 1 ? 's' : ''}?</AlertDialogTitle>
          <AlertDialogDescription className="text-white/60">
            This will permanently delete {selectedIds.size} card{selectedIds.size !== 1 ? 's' : ''} from the marketplace. This action cannot be undone.
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel className="bg-transparent border-white/20 text-white hover:bg-white/10">Cancel</AlertDialogCancel>
          <AlertDialogAction
            className="bg-[#C41E3A] hover:bg-[#a01830] text-white"
            onClick={() => bulkDelete.mutate({ ids: Array.from(selectedIds) })}
          >
            {bulkDelete.isPending ? "Deleting..." : "Yes, Delete All"}
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
    </>
  );
}
