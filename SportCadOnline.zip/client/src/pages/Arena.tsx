import { useState, useMemo } from "react";
import { trpc } from "@/lib/trpc";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Link } from "wouter";
import { Award, Search, SlidersHorizontal, X } from "lucide-react";

const SPORTS = ["All", "Baseball", "Basketball", "WNBA", "Football", "Hockey", "Soccer", "Golf", "Other"];
const SPORT_ICONS: Record<string, string> = {
  All: "🏆",
  Baseball: "⚾",
  Basketball: "🏀",
  WNBA: "🏀",
  Football: "🏈",
  Hockey: "🏒",
  Soccer: "⚽",
  Golf: "⛳",
  Other: "🃏",
};
const GRADES = ["All", "10", "9.5", "9", "8.5", "8", "7", "Raw"];
const PRICE_RANGES = [
  { label: "All Prices", min: 0, max: Infinity },
  { label: "Under $25", min: 0, max: 25 },
  { label: "$25 – $100", min: 25, max: 100 },
  { label: "$100 – $500", min: 100, max: 500 },
  { label: "$500+", min: 500, max: Infinity },
];
const SORT_OPTIONS = [
  { label: "Newest", value: "newest" },
  { label: "Price: Low to High", value: "price_asc" },
  { label: "Price: High to Low", value: "price_desc" },
  { label: "Grade: High to Low", value: "grade_desc" },
];

export default function Arena() {
  const [searchQuery, setSearchQuery] = useState("");
  const [sport, setSport] = useState("All");
  const [grade, setGrade] = useState("All");
  const [sort, setSort] = useState("newest");
  const [priceRange, setPriceRange] = useState(0); // index into PRICE_RANGES
  const [showFilters, setShowFilters] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const PAGE_SIZE = 40;

  const { data: cards, isLoading } = trpc.cards.list.useQuery({ limit: 1000 });

  const filteredCards = useMemo(() => {
    if (!cards) return [];
    let result = [...cards];

    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      result = result.filter(c =>
        c.title.toLowerCase().includes(q) ||
        c.playerName.toLowerCase().includes(q) ||
        c.setName?.toLowerCase().includes(q) ||
        c.year?.toString().includes(q) ||
        c.cardNumber?.toLowerCase().includes(q)
      );
    }

    const pr = PRICE_RANGES[priceRange];
    if (pr.max !== Infinity || pr.min > 0) {
      result = result.filter(c => {
        const p = parseFloat(c.price ?? "0");
        return p >= pr.min && p <= pr.max;
      });
    }

    if (sport !== "All") {
      result = result.filter(c => c.sport?.toLowerCase() === sport.toLowerCase());
    }

    if (grade !== "All") {
      if (grade === "Raw") {
        result = result.filter(c => !c.aiGrade);
      } else {
        result = result.filter(c => c.aiGrade === grade);
      }
    }

    if (sort === "price_asc") result.sort((a, b) => parseFloat(a.price ?? "0") - parseFloat(b.price ?? "0"));
    else if (sort === "price_desc") result.sort((a, b) => parseFloat(b.price ?? "0") - parseFloat(a.price ?? "0"));
    else if (sort === "grade_desc") result.sort((a, b) => parseFloat(b.aiGrade ?? "0") - parseFloat(a.aiGrade ?? "0"));

    return result;
  }, [cards, searchQuery, sport, grade, sort, priceRange]);

  const totalPages = Math.ceil(filteredCards.length / PAGE_SIZE);
  const paginatedCards = filteredCards.slice((currentPage - 1) * PAGE_SIZE, currentPage * PAGE_SIZE);

  const activeFilters = [
    sport !== "All" && sport,
    grade !== "All" && grade,
    priceRange > 0 && PRICE_RANGES[priceRange].label,
  ].filter(Boolean) as string[];

  return (
    <div className="min-h-screen bg-[#0a1628] pb-20">
      {/* Header */}
      <div className="bg-[#0d1f3c] border-b border-white/10 py-4">
        <div className="max-w-7xl mx-auto px-4">
          <h1 className="text-2xl font-bold text-white" style={{ fontFamily: "Oswald, sans-serif" }}>Arena</h1>
          <p className="text-white/50 text-sm">Buy premium sports cards from verified sellers</p>
        </div>
      </div>

      {/* Sport Quick-Filter Tabs */}
      <div className="bg-[#0a1628] border-b border-white/5">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex gap-1 overflow-x-auto py-2 scrollbar-hide">
            {SPORTS.map(s => (
              <button
                key={s}
                onClick={() => { setSport(s); setCurrentPage(1); }}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition-all ${
                  sport === s
                    ? "bg-[#C41E3A] text-white shadow-md shadow-[#C41E3A]/30"
                    : "bg-white/5 text-white/50 hover:bg-white/10 hover:text-white"
                }`}
              >
                <span>{SPORT_ICONS[s]}</span>
                {s}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-6">
        {/* Search + Filter Row */}
        <div className="flex flex-col sm:flex-row gap-3 mb-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/30" />
            <Input
              placeholder="Search by player, set, or card name..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="pl-10 bg-[#0d1f3c] border-white/10 text-white placeholder:text-white/30"
            />
          </div>
          <select
            value={sort}
            onChange={e => setSort(e.target.value)}
            className="bg-[#0d1f3c] border border-white/10 text-white text-sm rounded-lg px-3 py-2 focus:outline-none focus:border-white/30"
          >
            {SORT_OPTIONS.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
          </select>
          <Button
            variant="outline"
            className={`border-white/20 text-white hover:bg-white/10 gap-2 ${showFilters ? "bg-white/10" : ""}`}
            onClick={() => setShowFilters(f => !f)}
          >
            <SlidersHorizontal className="w-4 h-4" />
            Filters {activeFilters.length > 0 && <Badge className="bg-[#C41E3A] text-white text-xs ml-1">{activeFilters.length}</Badge>}
          </Button>
        </div>

        {/* Expandable Filter Panel */}
        {showFilters && (
          <div className="bg-[#0d1f3c] border border-white/10 rounded-xl p-4 mb-4 space-y-4">
            <div>
              <p className="text-xs font-bold text-white/40 uppercase tracking-wide mb-2">Sport</p>
              <div className="flex flex-wrap gap-2">
                {SPORTS.map(s => (
                  <button
                    key={s}
                    onClick={() => setSport(s)}
                    className={`px-3 py-1 rounded-full text-xs font-medium transition-colors ${sport === s ? "bg-[#C41E3A] text-white" : "bg-white/10 text-white/60 hover:bg-white/20"}`}
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>
            <div>
              <p className="text-xs font-bold text-white/40 uppercase tracking-wide mb-2">Grade</p>
              <div className="flex flex-wrap gap-2">
                {GRADES.map(g => (
                  <button
                    key={g}
                    onClick={() => setGrade(g)}
                    className={`px-3 py-1 rounded-full text-xs font-medium transition-colors ${grade === g ? "bg-[#E8C547] text-black" : "bg-white/10 text-white/60 hover:bg-white/20"}`}
                  >
                    {g}
                  </button>
                ))}
              </div>
            </div>
            <div>
              <p className="text-xs font-bold text-white/40 uppercase tracking-wide mb-2">Price Range</p>
              <div className="flex flex-wrap gap-2">
                {PRICE_RANGES.map((pr, i) => (
                  <button
                    key={pr.label}
                    onClick={() => setPriceRange(i)}
                    className={`px-3 py-1 rounded-full text-xs font-medium transition-colors ${priceRange === i ? "bg-green-600 text-white" : "bg-white/10 text-white/60 hover:bg-white/20"}`}
                  >
                    {pr.label}
                  </button>
                ))}
              </div>
            </div>
            {activeFilters.length > 0 && (
              <button onClick={() => { setSport("All"); setGrade("All"); setPriceRange(0); }} className="text-xs text-[#C41E3A] hover:underline flex items-center gap-1">
                <X className="w-3 h-3" /> Clear all filters
              </button>
            )}
          </div>
        )}

        {/* Active filter chips */}
        {activeFilters.length > 0 && !showFilters && (
          <div className="flex gap-2 mb-4 flex-wrap">
            {activeFilters.map(f => (
              <Badge key={f} className="bg-white/10 text-white border border-white/20 text-xs gap-1">
                {f}
                <button onClick={() => { if (f === sport) setSport("All"); else setGrade("All"); }} className="ml-1 hover:text-red-400">
                  <X className="w-2.5 h-2.5" />
                </button>
              </Badge>
            ))}
          </div>
        )}

        {/* Results count */}
        <p className="text-white/30 text-xs mb-4">{filteredCards.length} cards found</p>

        {/* Cards Grid */}
        {isLoading ? (
          <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-7 xl:grid-cols-8 2xl:grid-cols-10 gap-2">
            {Array.from({ length: 16 }).map((_, i) => (
              <div key={i} className="bg-[#0d1f3c] border border-white/10 rounded overflow-hidden animate-pulse">
                <div className="aspect-[5/7] bg-white/5" />
                <div className="p-1.5 space-y-1">
                  <div className="h-2 bg-white/5 rounded" />
                  <div className="h-3 bg-white/5 rounded w-2/3" />
                </div>
              </div>
            ))}
          </div>
        ) : filteredCards.length > 0 ? (
          <>
          <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-7 xl:grid-cols-8 2xl:grid-cols-10 gap-2">
            {paginatedCards.map(card => (
              <Link key={card.id} href={`/arena/${card.id}`}>
                <div className="bg-[#0d1f3c] border border-white/10 rounded overflow-hidden hover:border-white/30 hover:shadow-md hover:shadow-[#C41E3A]/10 transition-all cursor-pointer group h-full">
                  <div className="relative aspect-[5/7] bg-white/5 overflow-hidden">
                    {card.frontImageUrl ? (
                      <img src={card.frontImageUrl} alt={card.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center">
                        <Award className="w-6 h-6 text-white/10" />
                      </div>
                    )}
                    {card.aiGrade && (
                      <div className="absolute bottom-1 right-1 bg-[#E8C547] text-black text-[9px] font-black px-1 py-0.5 rounded leading-none">
                        {card.aiGrade}
                      </div>
                    )}
                    {(card as any).isDropship && (
                      <div className="absolute top-1 left-1 bg-blue-500/80 text-white text-[8px] font-bold px-1 py-0.5 rounded leading-none">
                        eBay
                      </div>
                    )}
                  </div>
                  <div className="p-1.5">
                    <h3 className="font-semibold text-[10px] text-white line-clamp-1 leading-tight">{card.playerName || card.title}</h3>
                    <div className="flex items-center gap-1 flex-wrap">
                      <p className="text-[10px] font-bold text-green-400">${parseFloat(card.price ?? "0").toFixed(2)}</p>
                      {(card as any).cardShippingFee && parseFloat((card as any).cardShippingFee) > 0 ? (
                        <p className="text-[9px] text-white/30">+${parseFloat((card as any).cardShippingFee).toFixed(2)} ship</p>
                      ) : (card as any).cardShippingFee === "0" || (card as any).cardShippingFee === "0.00" ? (
                        <p className="text-[9px] text-green-500/60">free ship</p>
                      ) : null}
                    </div>
                  </div>
                </div>
              </Link>
            ))}
          </div>

          {/* Pagination */}
          {totalPages > 1 && (
            <div className="flex items-center justify-center gap-2 mt-6 flex-wrap">
              <button onClick={() => setCurrentPage(1)} disabled={currentPage === 1}
                className="px-3 py-1.5 text-xs rounded-lg border border-white/10 text-white/50 hover:text-white hover:border-white/30 disabled:opacity-30 disabled:cursor-not-allowed transition-all">
                «
              </button>
              <button onClick={() => setCurrentPage(p => Math.max(1, p - 1))} disabled={currentPage === 1}
                className="px-3 py-1.5 text-xs rounded-lg border border-white/10 text-white/50 hover:text-white hover:border-white/30 disabled:opacity-30 disabled:cursor-not-allowed transition-all">
                ‹ Prev
              </button>
              {Array.from({ length: Math.min(7, totalPages) }, (_, i) => {
                const start = Math.max(1, Math.min(currentPage - 3, totalPages - 6));
                const page = start + i;
                if (page > totalPages) return null;
                return (
                  <button key={page} onClick={() => setCurrentPage(page)}
                    className={`px-3 py-1.5 text-xs rounded-lg border transition-all ${
                      page === currentPage
                        ? "bg-[#c41e3a] border-[#c41e3a] text-white font-bold"
                        : "border-white/10 text-white/50 hover:text-white hover:border-white/30"
                    }`}>
                    {page}
                  </button>
                );
              })}
              <button onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))} disabled={currentPage === totalPages}
                className="px-3 py-1.5 text-xs rounded-lg border border-white/10 text-white/50 hover:text-white hover:border-white/30 disabled:opacity-30 disabled:cursor-not-allowed transition-all">
                Next ›
              </button>
              <button onClick={() => setCurrentPage(totalPages)} disabled={currentPage === totalPages}
                className="px-3 py-1.5 text-xs rounded-lg border border-white/10 text-white/50 hover:text-white hover:border-white/30 disabled:opacity-30 disabled:cursor-not-allowed transition-all">
                »
              </button>
              <span className="text-xs text-white/30 ml-2">
                {(currentPage - 1) * PAGE_SIZE + 1}–{Math.min(currentPage * PAGE_SIZE, filteredCards.length)} of {filteredCards.length} cards
              </span>
            </div>
          )}
          </>
        ) : (
          <div className="text-center py-20 text-white/30">
            <Award className="w-16 h-16 mx-auto mb-4 text-white/10" />
            <h3 className="text-xl font-semibold mb-2 text-white/50">No cards found</h3>
            <p className="text-sm">Try adjusting your search or filters</p>
            {activeFilters.length > 0 && (
              <button onClick={() => { setSport("All"); setGrade("All"); setSearchQuery(""); }} className="mt-3 text-[#C41E3A] hover:underline text-sm">
                Clear all filters
              </button>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
