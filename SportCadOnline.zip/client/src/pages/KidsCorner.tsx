import { useState, useEffect, useRef, useCallback, useMemo } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import CardRacer from "./games/CardRacer";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { TriviaPopup } from "@/components/TriviaPopup";
import MascotCharacter, { CourtsideMascots, LevelUpCelebration, type MascotState } from "@/components/MascotCharacter";
import { Star, Trophy, Zap, Users, ChevronRight, Lock, CheckCircle2, Circle, Gamepad2, BookOpen, Gift, Crown, Heart, Search, ShoppingCart, X, Clock } from "lucide-react";
import KidsTradingCenter from "@/components/KidsTradingCenter";
import GameTime from "@/pages/games/GameTime";
import GoFish from "@/pages/games/GoFish";
import RockPaperScissors from "@/pages/games/RockPaperScissors";
import HeadsOrTails from "@/pages/games/HeadsOrTails";
import { HOUSE_CARDS, type HouseCard } from "@/data/houseCards";

// ─── Spin Wheel Segments (Sports-themed, balanced) ────────────────────────────
// Win segments: All-Star (10), TD (7), Field Goal (3), Free Throw (1)
// Multiplier: ×2 (multiplies NEXT spin)
// Lose segments: Timeout, Technical Foul, Foul, Injury (lose wager)
const SPIN_SEGMENTS = [
  { id: "allstar",     label: "ALL-STAR",     emoji: "⭐", type: "win"  as const, multiplier: 10, color: "#fbbf24", textColor: "#000000", desc: "10× your wager!" },
  { id: "timeout",     label: "TIMEOUT",      emoji: "⏱️", type: "lose" as const, multiplier: 0,  color: "#dc2626", textColor: "#ffffff", desc: "Lose your wager" },
  { id: "td",          label: "TOUCHDOWN!",   emoji: "🏈", type: "win"  as const, multiplier: 7,  color: "#16a34a", textColor: "#ffffff", desc: "7× your wager!" },
  { id: "foul",        label: "FOUL",         emoji: "🚫", type: "lose" as const, multiplier: 0,  color: "#b91c1c", textColor: "#ffffff", desc: "Lose your wager" },
  { id: "fieldgoal",   label: "FIELD GOAL",   emoji: "🏉", type: "win"  as const, multiplier: 3,  color: "#2563eb", textColor: "#ffffff", desc: "3× your wager!" },
  { id: "injury",      label: "INJURY",       emoji: "🤕", type: "lose" as const, multiplier: 0,  color: "#7c3aed", textColor: "#ffffff", desc: "Lose your wager" },
  { id: "freethrow",   label: "FREE THROW",   emoji: "🏀", type: "win"  as const, multiplier: 1,  color: "#0891b2", textColor: "#ffffff", desc: "Get your wager back" },
  { id: "techfoul",    label: "TECH FOUL",    emoji: "😤", type: "lose" as const, multiplier: 0,  color: "#9f1239", textColor: "#ffffff", desc: "Lose your wager" },
  { id: "x2",          label: "×2 NEXT SPIN", emoji: "🔥", type: "bonus" as const, multiplier: 2, color: "#f97316", textColor: "#000000", desc: "Next spin doubled!" },
  { id: "td2",         label: "TOUCHDOWN!",   emoji: "🏈", type: "win"  as const, multiplier: 7,  color: "#15803d", textColor: "#ffffff", desc: "7× your wager!" },
  { id: "timeout2",    label: "TIMEOUT",      emoji: "⏱️", type: "lose" as const, multiplier: 0,  color: "#ef4444", textColor: "#ffffff", desc: "Lose your wager" },
  { id: "fieldgoal2",  label: "FIELD GOAL",   emoji: "🏉", type: "win"  as const, multiplier: 3,  color: "#1d4ed8", textColor: "#ffffff", desc: "3× your wager!" },
] as const;
type SpinSeg = typeof SPIN_SEGMENTS[number];
const NUM_SEGS = SPIN_SEGMENTS.length;
const DEG_PER_SEG = 360 / NUM_SEGS;

// ─── Legend data (for card pull game) ─────────────────────────────────────────
const LEGENDS = [
  { name: "Michael Jordan",  team: "Bulls",    sport: "basketball", jersey: "23", primary: "#CE1141", secondary: "#000000", emoji: "🏀", era: "90s",   fact: "6× NBA Champion, 5× MVP, 6× Finals MVP" },
  { name: "Caitlin Clark",   team: "Fever",    sport: "basketball", jersey: "22", primary: "#002D62", secondary: "#FDBB30", emoji: "🏀", era: "2020s", fact: "All-time NCAA scoring leader, WNBA Rookie of the Year" },
  { name: "Babe Ruth",       team: "Yankees",  sport: "baseball",   jersey: "3",  primary: "#003087", secondary: "#E4002C", emoji: "⚾", era: "1920s", fact: "714 career home runs — a record that stood for 39 years!" },
  { name: "Ken Griffey Jr.", team: "Mariners", sport: "baseball",   jersey: "24", primary: "#005C5C", secondary: "#C4CED4", emoji: "⚾", era: "90s",   fact: "630 career home runs, 10× Gold Glove, 1997 AL MVP" },
  { name: "Larry Bird",      team: "Celtics",  sport: "basketball", jersey: "33", primary: "#007A33", secondary: "#BA9653", emoji: "🏀", era: "80s",   fact: "3× NBA Champion, 3× consecutive MVP awards" },
  { name: "Magic Johnson",   team: "Lakers",   sport: "basketball", jersey: "32", primary: "#552583", secondary: "#FDB927", emoji: "🏀", era: "80s",   fact: "5× NBA Champion, 3× MVP, 12× All-Star" },
  { name: "Kobe Bryant",     team: "Lakers",   sport: "basketball", jersey: "24", primary: "#552583", secondary: "#FDB927", emoji: "🏀", era: "2000s", fact: "5× NBA Champion, 1× MVP, 18× All-Star — Mamba Mentality" },
  { name: "Pete Rose",       team: "Reds",     sport: "baseball",   jersey: "14", primary: "#C6011F", secondary: "#000000", emoji: "⚾", era: "70s",   fact: "All-time MLB hits leader with 4,256 career hits" },
  { name: "Jose Canseco",    team: "A's",      sport: "baseball",   jersey: "33", primary: "#003831", secondary: "#EFB21E", emoji: "⚾", era: "80s",   fact: "First player ever with 40 HR AND 40 SB in one season" },
  { name: "Wayne Gretzky",   team: "Oilers",   sport: "hockey",     jersey: "99", primary: "#FF4C00", secondary: "#041E42", emoji: "🏒", era: "80s",   fact: "The Great One — holds 61 NHL records" },
  { name: "LeBron James",    team: "Lakers",   sport: "basketball", jersey: "23", primary: "#552583", secondary: "#FDB927", emoji: "🏀", era: "2010s", fact: "4× NBA Champion, all-time NBA scoring leader" },
  { name: "Serena Williams", team: "USA",      sport: "tennis",     jersey: "1",  primary: "#002868", secondary: "#BF0A30", emoji: "🎾", era: "2000s", fact: "23 Grand Slam singles titles — most in the Open Era" },
  { name: "Cooper Flagg",    team: "Celtics",  sport: "basketball", jersey: "2",  primary: "#007A33", secondary: "#BA9653", emoji: "🏀", era: "2020s", fact: "#1 NBA Draft Pick 2025 — most hyped prospect since LeBron" },
];

const RARITY = {
  legendary: { label: "LEGENDARY", color: "from-yellow-400 via-orange-500 to-red-600", stars: 5, emoji: "👑", credits: 50 },
  epic:      { label: "EPIC",      color: "from-purple-500 via-violet-600 to-indigo-700", stars: 4, emoji: "💎", credits: 25 },
  rare:      { label: "RARE",      color: "from-blue-400 via-cyan-500 to-teal-600", stars: 3, emoji: "⭐", credits: 15 },
  uncommon:  { label: "UNCOMMON",  color: "from-green-400 via-emerald-500 to-teal-600", stars: 2, emoji: "🌟", credits: 8 },
  common:    { label: "COMMON",    color: "from-gray-400 via-slate-500 to-gray-600", stars: 1, emoji: "✨", credits: 3 },
};
type Rarity = keyof typeof RARITY;

const CARD_POOL: Array<{ legend: typeof LEGENDS[0]; rarity: Rarity }> = [
  { legend: LEGENDS[0],  rarity: "legendary" },
  { legend: LEGENDS[1],  rarity: "legendary" },
  { legend: LEGENDS[2],  rarity: "legendary" },
  { legend: LEGENDS[3],  rarity: "epic" },
  { legend: LEGENDS[4],  rarity: "epic" },
  { legend: LEGENDS[5],  rarity: "epic" },
  { legend: LEGENDS[6],  rarity: "epic" },
  { legend: LEGENDS[7],  rarity: "rare" },
  { legend: LEGENDS[8],  rarity: "rare" },
  { legend: LEGENDS[9],  rarity: "rare" },
  { legend: LEGENDS[10], rarity: "uncommon" },
  { legend: LEGENDS[11], rarity: "common" },
  { legend: LEGENDS[12], rarity: "legendary" },
];

const LEVELS = [
  { id: "fr1",    label: "Freshman",    group: "college", cardsNeeded: 3,   referralsNeeded: 0,  emoji: "🎓", color: "from-blue-500 to-blue-700",      desc: "Just getting started!" },
  { id: "so1",    label: "Sophomore",   group: "college", cardsNeeded: 8,   referralsNeeded: 1,  emoji: "📚", color: "from-blue-600 to-indigo-700",    desc: "Learning the game!" },
  { id: "jr1",    label: "Junior",      group: "college", cardsNeeded: 15,  referralsNeeded: 2,  emoji: "🏅", color: "from-indigo-500 to-purple-700",  desc: "Rising star!" },
  { id: "sr1",    label: "Senior",      group: "college", cardsNeeded: 25,  referralsNeeded: 3,  emoji: "🎯", color: "from-purple-500 to-violet-700",  desc: "Draft eligible!" },
  { id: "rookie", label: "Rookie Pro",  group: "pro",     cardsNeeded: 35,  referralsNeeded: 4,  emoji: "🌟", color: "from-yellow-400 to-orange-500",  desc: "Welcome to the pros!" },
  { id: "yr1",    label: "1st Year Pro",group: "pro",     cardsNeeded: 45,  referralsNeeded: 5,  emoji: "🔥", color: "from-orange-500 to-red-600",     desc: "Prove yourself!" },
  { id: "yr2",    label: "2nd Year Pro",group: "pro",     cardsNeeded: 55,  referralsNeeded: 6,  emoji: "💪", color: "from-red-500 to-rose-700",       desc: "No more rookie mistakes!" },
  { id: "yr3",    label: "3rd Year Pro",group: "pro",     cardsNeeded: 65,  referralsNeeded: 7,  emoji: "⚡", color: "from-rose-500 to-pink-700",      desc: "Becoming a veteran!" },
  { id: "yr4",    label: "4th Year Pro",group: "pro",     cardsNeeded: 75,  referralsNeeded: 8,  emoji: "🎖️", color: "from-pink-500 to-fuchsia-700",   desc: "All-Star caliber!" },
  { id: "yr5",    label: "5th Year Pro",group: "pro",     cardsNeeded: 90,  referralsNeeded: 9,  emoji: "🏆", color: "from-fuchsia-500 to-purple-700", desc: "Championship contender!" },
  { id: "yr6",    label: "6th Year Pro",group: "pro",     cardsNeeded: 105, referralsNeeded: 10, emoji: "💎", color: "from-purple-500 to-violet-700",  desc: "Elite status!" },
  { id: "yr7",    label: "7th Year Pro",group: "pro",     cardsNeeded: 120, referralsNeeded: 11, emoji: "👑", color: "from-violet-500 to-indigo-700",  desc: "Legend in the making!" },
  { id: "yr8",    label: "8th Year Pro",group: "pro",     cardsNeeded: 140, referralsNeeded: 12, emoji: "🌠", color: "from-indigo-500 to-blue-700",    desc: "All-time great!" },
  { id: "yr9",    label: "9th Year Pro",group: "pro",     cardsNeeded: 160, referralsNeeded: 13, emoji: "🦅", color: "from-blue-500 to-cyan-700",      desc: "Hall of Fame watch!" },
  { id: "yr10",   label: "10th Year Pro",group: "pro",   cardsNeeded: 180, referralsNeeded: 14, emoji: "🚀", color: "from-cyan-500 to-teal-700",      desc: "A true icon!" },
  { id: "hof",    label: "Hall of Fame",group: "hof",    cardsNeeded: 200, referralsNeeded: 15, emoji: "🏛️", color: "from-yellow-300 via-amber-400 to-yellow-600", desc: "You made it!" },
];

const TRIVIA = [
  { q: "Michael Jordan wore #23 for which team?", choices: ["Lakers","Celtics","Bulls","Knicks"], answer: "Bulls", fact: "Jordan won 6 championships with the Chicago Bulls!", credits: 10 },
  { q: "Babe Ruth hit 714 career home runs for which team?", choices: ["Red Sox","Yankees","Cubs","Dodgers"], answer: "Yankees", fact: "Ruth was sold to the Yankees in 1920 — the famous 'Curse of the Bambino'!", credits: 10 },
  { q: "What number did Ken Griffey Jr. wear?", choices: ["24","3","32","23"], answer: "24", fact: "Griffey's 1989 Upper Deck rookie card is one of the most iconic ever made!", credits: 10 },
  { q: "Which team did Magic Johnson play for?", choices: ["Celtics","Bulls","Lakers","Pistons"], answer: "Lakers", fact: "Magic and Bird had one of the greatest rivalries in NBA history!", credits: 10 },
  { q: "Caitlin Clark broke the all-time NCAA scoring record. What sport?", choices: ["Soccer","Tennis","Basketball","Volleyball"], answer: "Basketball", fact: "Clark scored 3,951 points at Iowa — more than any player in NCAA history!", credits: 10 },
  { q: "What does RC mean on a sports card?", choices: ["Really Cool","Rookie Card","Red Color","Rare Collection"], answer: "Rookie Card", fact: "Rookie cards are usually the most valuable — it's the player's first official card!", credits: 10 },
  { q: "If a card is worth $50 and you trade it for two $30 cards, did you win or lose?", choices: ["Won $10","Lost $10","Broke even","Can't tell"], answer: "Won $10", fact: "Always add up both sides before trading! $30 + $30 = $60 > $50!", credits: 15 },
  { q: "Wayne Gretzky is known as 'The Great One' in which sport?", choices: ["Basketball","Baseball","Hockey","Football"], answer: "Hockey", fact: "Gretzky scored more assists alone than any other player's total points!", credits: 10 },
  { q: "Larry Bird played for which team?", choices: ["Lakers","Bulls","Celtics","76ers"], answer: "Celtics", fact: "Bird and Magic Johnson transformed the NBA in the 1980s!", credits: 10 },
  { q: "Kobe Bryant's nickname was the 'Mamba'. What number did he wear later in his career?", choices: ["8","23","24","32"], answer: "24", fact: "Kobe wore #8 early in his career and switched to #24 in 2006!", credits: 10 },
  { q: "A BGS 10 grade means what?", choices: ["It costs $10","It's Gem Mint — perfect!","It's broken","It needs cleaning"], answer: "It's Gem Mint — perfect!", fact: "BGS 10 is the highest Beckett grade — a perfect card can be worth 10× a BGS 9!", credits: 15 },
];

// ─── Helpers ──────────────────────────────────────────────────────────────────
function StarRating({ count }: { count: number }) {
  return (
    <div className="flex gap-0.5">
      {Array.from({ length: 5 }).map((_, i) => (
        <Star key={i} className={`w-3 h-3 ${i < count ? "text-yellow-400 fill-yellow-400" : "text-gray-600"}`} />
      ))}
    </div>
  );
}

// ─── Sports Spin Wheel ────────────────────────────────────────────────────────
function SportsSpinWheel({ credits, onResult }: {
  credits: number;
  onResult: (seg: SpinSeg, wager: number, nextMultiplier: boolean) => void;
}) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [spinning, setSpinning] = useState(false);
  const [wager, setWager] = useState(1);
  const [resultSeg, setResultSeg] = useState<SpinSeg | null>(null);
  const [angle, setAngle] = useState(0);
  const [hasX2, setHasX2] = useState(false);
  const animRef = useRef<number>(0);
  const startAngleRef = useRef(0);
  const targetAngleRef = useRef(0);
  const startTimeRef = useRef(0);
  const DURATION = 5000;

  const drawWheel = useCallback((currentAngle: number) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    const cx = canvas.width / 2;
    const cy = canvas.height / 2;
    const r = cx - 8;
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Outer ring glow
    ctx.save();
    ctx.shadowColor = "#fbbf24";
    ctx.shadowBlur = 12;
    ctx.beginPath(); ctx.arc(cx, cy, r + 4, 0, Math.PI * 2);
    ctx.strokeStyle = "#fbbf24"; ctx.lineWidth = 2; ctx.stroke();
    ctx.restore();

    SPIN_SEGMENTS.forEach((seg, i) => {
      const startA = (currentAngle + i * DEG_PER_SEG - 90) * (Math.PI / 180);
      const endA = startA + DEG_PER_SEG * (Math.PI / 180);
      ctx.beginPath(); ctx.moveTo(cx, cy); ctx.arc(cx, cy, r, startA, endA); ctx.closePath();
      ctx.fillStyle = seg.color; ctx.fill();
      ctx.strokeStyle = "rgba(0,0,0,0.3)"; ctx.lineWidth = 1.5; ctx.stroke();

      // Text on segment
      ctx.save();
      ctx.translate(cx, cy);
      ctx.rotate(startA + (DEG_PER_SEG / 2) * (Math.PI / 180));
      ctx.translate(r * 0.65, 0);
      ctx.rotate(Math.PI / 2);
      ctx.fillStyle = seg.textColor;
      ctx.font = "bold 11px sans-serif";
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      // Emoji
      ctx.font = "14px sans-serif";
      ctx.fillText(seg.emoji, 0, -10);
      // Label
      ctx.font = "bold 8px sans-serif";
      ctx.fillStyle = seg.textColor;
      const words = seg.label.split(" ");
      words.forEach((w, wi) => ctx.fillText(w, 0, 2 + wi * 9));
      ctx.restore();
    });

    // Center hub
    ctx.beginPath(); ctx.arc(cx, cy, 26, 0, Math.PI * 2);
    const grad = ctx.createRadialGradient(cx, cy, 0, cx, cy, 26);
    grad.addColorStop(0, "#1f2937"); grad.addColorStop(1, "#111827");
    ctx.fillStyle = grad; ctx.fill();
    ctx.strokeStyle = "#fbbf24"; ctx.lineWidth = 2.5; ctx.stroke();
    ctx.fillStyle = "#fbbf24"; ctx.font = "bold 9px sans-serif";
    ctx.textAlign = "center"; ctx.textBaseline = "middle";
    ctx.fillText("SCO", cx, cy - 4);
    ctx.fillText("SPIN", cx, cy + 5);
  }, []);

  useEffect(() => { drawWheel(angle); }, [angle, drawWheel]);

  const easeOut = (t: number) => 1 - Math.pow(1 - t, 4);

  const spin = () => {
    if (spinning) return;
    if (credits < wager) { toast.error(`Need ${wager} credits to wager!`); return; }
    const extraSpins = 5 + Math.floor(Math.random() * 5);
    const landingIdx = Math.floor(Math.random() * NUM_SEGS);
    const target = startAngleRef.current + extraSpins * 360 + landingIdx * DEG_PER_SEG + DEG_PER_SEG / 2;
    targetAngleRef.current = target;
    startAngleRef.current = angle;
    startTimeRef.current = performance.now();
    setSpinning(true); setResultSeg(null);

    const animate = (now: number) => {
      const elapsed = now - startTimeRef.current;
      const progress = Math.min(elapsed / DURATION, 1);
      const current = startAngleRef.current + (targetAngleRef.current - startAngleRef.current) * easeOut(progress);
      setAngle(current); drawWheel(current);
      if (progress < 1) { animRef.current = requestAnimationFrame(animate); }
      else {
        setSpinning(false);
        // The pointer is at the top (12 o'clock), segments start at -90deg offset
        const normalized = ((current % 360) + 360) % 360;
        const idx = Math.floor(((360 - normalized) % 360) / DEG_PER_SEG) % NUM_SEGS;
        const landed = SPIN_SEGMENTS[idx];
        setResultSeg(landed);
        const isBonus = landed.type === "bonus";
        onResult(landed, wager, isBonus);
        if (isBonus) setHasX2(true);
      }
    };
    animRef.current = requestAnimationFrame(animate);
  };
  useEffect(() => () => cancelAnimationFrame(animRef.current), []);

  const maxWager = Math.min(5, credits);

  return (
    <div className="flex flex-col items-center gap-4">
      {/* X2 active banner */}
      {hasX2 && (
        <div className="w-full rounded-2xl bg-orange-500/20 border-2 border-orange-400 p-2 text-center animate-pulse">
          <p className="text-orange-300 font-black text-sm">🔥 ×2 ACTIVE — Next spin winnings are DOUBLED!</p>
        </div>
      )}

      {/* Wager selector */}
      <div className="w-full">
        <p className="text-white/60 font-bold text-xs text-center mb-2 uppercase tracking-widest">Choose Your Wager</p>
        <div className="flex gap-2 justify-center">
          {[1, 2, 3, 4, 5].map(w => (
            <button key={w} onClick={() => { if (!spinning) setWager(w); }}
              disabled={w > credits}
              className={`w-10 h-10 rounded-xl font-black text-sm transition-all border-2 ${
                wager === w ? "bg-yellow-400 text-black border-yellow-300 scale-110 shadow-lg shadow-yellow-400/30"
                : w > credits ? "bg-white/5 text-white/20 border-white/10 cursor-not-allowed"
                : "bg-white/10 text-white border-white/20 hover:bg-white/20 hover:border-yellow-400/50"
              }`}>
              {w}
            </button>
          ))}
        </div>
        <p className="text-white/40 text-[10px] text-center mt-1">Credits wagered: {wager} · You have: {credits}</p>
      </div>

      {/* Wheel */}
      <div className="relative">
        {/* Pointer arrow */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1 z-10">
          <div className="w-0 h-0 border-l-[10px] border-r-[10px] border-t-[22px] border-l-transparent border-r-transparent border-t-yellow-400 drop-shadow-lg filter" />
        </div>
        <canvas ref={canvasRef} width={300} height={300} className="rounded-full shadow-2xl" style={{ border: "3px solid rgba(251,191,36,0.4)" }} />
      </div>

      {/* Spin button */}
      <button onClick={spin} disabled={spinning || credits < wager}
        className={`px-10 py-3 rounded-full font-black text-base uppercase tracking-widest transition-all shadow-xl ${
          spinning ? "bg-gray-700 text-gray-400 cursor-not-allowed"
          : credits < wager ? "bg-gray-700 text-gray-400 cursor-not-allowed"
          : "bg-gradient-to-r from-yellow-400 to-orange-500 text-black hover:scale-105 cursor-pointer shadow-orange-500/30"
        }`}>
        {spinning ? "🌀 Spinning..." : `🎯 SPIN! (${wager} credit${wager > 1 ? "s" : ""})`}
      </button>

      {/* Result */}
      {resultSeg && !spinning && (
        <div className={`rounded-2xl p-4 text-center border-2 w-full shadow-2xl`}
          style={{ background: `${resultSeg.color}22`, borderColor: resultSeg.color }}>
          <p className="text-white font-black text-2xl">{resultSeg.emoji} {resultSeg.label}</p>
          <p className="text-sm mt-1" style={{ color: resultSeg.type === "win" ? "#4ade80" : resultSeg.type === "bonus" ? "#fb923c" : "#f87171" }}>
            {resultSeg.type === "win" && `+${wager * resultSeg.multiplier * (hasX2 ? 2 : 1)} credits${hasX2 ? " (×2 BONUS!)" : ""}`}
            {resultSeg.type === "lose" && `Lost ${wager} credit${wager > 1 ? "s" : ""}`}
            {resultSeg.type === "bonus" && "Next spin winnings are DOUBLED! 🔥"}
          </p>
          <p className="text-white/50 text-xs mt-1">{resultSeg.desc}</p>
        </div>
      )}

      {/* Payout table */}
      <div className="w-full bg-white/5 rounded-2xl p-3 border border-white/10">
        <p className="text-white/40 font-black text-[10px] uppercase tracking-widest mb-2">Payout Table (×wager)</p>
        <div className="grid grid-cols-2 gap-1">
          {SPIN_SEGMENTS.filter((s, i, arr) => arr.findIndex(x => x.id === s.id) === i).map(seg => (
            <div key={seg.id} className="flex items-center gap-1.5 text-[10px]">
              <span>{seg.emoji}</span>
              <span className="text-white/60 truncate">{seg.label.split(" ")[0]}</span>
              <span className={`font-black ml-auto ${seg.type === "win" ? "text-green-400" : seg.type === "bonus" ? "text-orange-400" : "text-red-400"}`}>
                {seg.type === "win" ? `×${seg.multiplier}` : seg.type === "bonus" ? "×2 next" : "lose"}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ─── Card Reveal Modal ────────────────────────────────────────────────────────
type RealCard = {
  id: number;
  playerName: string | null;
  sport: string | null;
  frontImageUrl: string | null;
  gradeScore: string | null;
  gradeCompany: string | null;
  setName: string | null;
  year: string | null;
  source: string | null;
  rarity?: Rarity;
};
function CardReveal({ card, onClose }: { card: RealCard; onClose: () => void }) {
  const [flipped, setFlipped] = useState(false);
  const [imgError, setImgError] = useState(false);
  const rarity = card.rarity ?? "common";
  const r = RARITY[rarity];
  const sportEmoji = card.sport === "basketball" ? "🏀" : card.sport === "baseball" ? "⚾" :
    card.sport === "football" ? "🏈" : card.sport === "soccer" ? "⚽" :
    card.sport === "hockey" ? "🏒" : "🎴";
  useEffect(() => { const t = setTimeout(() => setFlipped(true), 400); return () => clearTimeout(t); }, []);
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-sm" onClick={onClose}>
      <div className="relative flex flex-col items-center gap-5" onClick={e => e.stopPropagation()}>
        {flipped && ["🌟","✨","🎉","⭐","💫","🎊","🏆","🔥"].map((e, i) => (
          <div key={i} className="absolute text-2xl animate-bounce pointer-events-none" style={{ top: `${5 + (i * 12) % 85}%`, left: `${(i * 13) % 90}%`, animationDelay: `${i * 0.1}s` }}>{e}</div>
        ))}
        <div className="relative w-52 h-72" style={{ perspective: "1000px" }}>
          <div className="w-full h-full" style={{ transformStyle: "preserve-3d", transform: flipped ? "rotateY(0deg)" : "rotateY(180deg)", transition: "transform 0.8s cubic-bezier(0.4,0,0.2,1)" }}>
            {/* Card front — real image */}
            <div className="absolute inset-0 rounded-3xl overflow-hidden shadow-2xl border-2"
              style={{ borderColor: rarity === "legendary" ? "#fbbf24" : rarity === "epic" ? "#a855f7" : rarity === "rare" ? "#3b82f6" : "#6b7280", backfaceVisibility: "hidden" }}>
              {card.frontImageUrl && !imgError ? (
                <img src={card.frontImageUrl} alt={card.playerName || "card"} className="w-full h-full object-cover" onError={() => setImgError(true)} />
              ) : (
                <div className="w-full h-full flex flex-col items-center justify-center gap-3" style={{ background: "linear-gradient(135deg, #1e3a5f, #0f2040)" }}>
                  <span className="text-6xl">{sportEmoji}</span>
                  <p className="text-white font-black text-base text-center px-3">{card.playerName || "Mystery Card"}</p>
                  <p className="text-white/60 text-xs">{card.year} {card.setName}</p>
                </div>
              )}
              {/* Rarity overlay badge */}
              <div className="absolute bottom-2 left-0 right-0 flex justify-center">
                <Badge className="bg-black/70 text-white border-white/20 font-black text-xs backdrop-blur-sm">{r.emoji} {r.label}</Badge>
              </div>
            </div>
            {/* Card back */}
            <div className="absolute inset-0 rounded-3xl bg-gradient-to-br from-[#1a1a2e] to-[#0f3460] flex items-center justify-center border-2 border-blue-500/40" style={{ backfaceVisibility: "hidden", transform: "rotateY(180deg)" }}>
              <div className="text-center"><div className="text-5xl mb-2">🏆</div><p className="text-yellow-400 font-black text-lg">SCO Kids</p></div>
            </div>
          </div>
        </div>
        {flipped && (
          <div className="text-center">
            {rarity === "legendary" && <p className="text-yellow-400 font-black text-2xl animate-bounce">👑 LEGENDARY PULL! 👑</p>}
            {rarity === "epic" && <p className="text-purple-400 font-black text-xl">💎 EPIC CARD!</p>}
            {rarity === "rare" && <p className="text-blue-400 font-black text-xl">⭐ RARE FIND!</p>}
            {(rarity === "uncommon" || rarity === "common") && <p className="text-green-400 font-black text-xl">Nice pull!</p>}
            {card.playerName && <p className="text-white font-black text-base mt-1">{card.playerName}</p>}
            {(card.year || card.setName) && <p className="text-white/50 text-xs mt-0.5">{[card.year, card.setName].filter(Boolean).join(" · ")}</p>}
            {card.gradeScore && <p className="text-yellow-400 text-xs mt-0.5">{card.gradeCompany} {card.gradeScore}</p>}
          </div>
        )}
        <Button onClick={onClose} className="bg-yellow-400 text-black font-black text-lg px-8 py-3 rounded-full hover:bg-yellow-300 shadow-xl">🎉 Add to My Collection!</Button>
      </div>
    </div>
  );
}

// ─── Kids Showcase ────────────────────────────────────────────────────────────
const SPORT_FILTERS = [
  { key: "all",      label: "All",      emoji: "🏆" },
  { key: "WNBA",     label: "WNBA",     emoji: "🏀" },
  { key: "NBA",      label: "NBA",      emoji: "🏀" },
  { key: "NFL",      label: "NFL",      emoji: "🏈" },
  { key: "Baseball", label: "Baseball", emoji: "⚾" },
  { key: "Soccer",   label: "Soccer",   emoji: "⚽" },
  { key: "Hockey",   label: "Hockey",   emoji: "🏒" },
];

function KidsShowcase({ credits, wishList, onAddToWishList, onRemoveFromWishList }: {
  credits: number;
  wishList: HouseCard[];
  onAddToWishList: (card: HouseCard) => void;
  onRemoveFromWishList: (cardId: string) => void;
}) {
  const [sportFilter, setSportFilter] = useState("all");
  const [search, setSearch] = useState("");
  const [selectedCard, setSelectedCard] = useState<HouseCard | null>(null);

  const filtered = useMemo(() => {
    return HOUSE_CARDS.filter(c => {
      const matchSport = sportFilter === "all" || c.sport === sportFilter;
      const matchSearch = !search || c.player.toLowerCase().includes(search.toLowerCase()) || c.name.toLowerCase().includes(search.toLowerCase());
      return matchSport && matchSearch;
    });
  }, [sportFilter, search]);

  const isWishlisted = (id: string) => wishList.some(w => w.id === id);

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div>
          <h2 className="text-white font-black text-xl" style={{ fontFamily: "Oswald, sans-serif" }}>🏪 CARD SHOWCASE</h2>
          <p className="text-white/40 text-xs mt-0.5">100 real house cards — add to your wish list!</p>
        </div>
        <div className="flex items-center gap-2">
          <Heart className="w-4 h-4 text-pink-400" />
          <span className="text-pink-400 font-black text-sm">{wishList.length}/5 wish list</span>
        </div>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/30" />
        <input
          className="w-full bg-white/10 border border-white/20 rounded-xl pl-9 pr-4 py-2.5 text-white placeholder-white/30 outline-none focus:border-yellow-400 text-sm"
          placeholder="Search player name..."
          value={search}
          onChange={e => setSearch(e.target.value)}
        />
      </div>

      {/* Sport filters */}
      <div className="flex gap-2 overflow-x-auto pb-1" style={{ scrollbarWidth: "none" }}>
        {SPORT_FILTERS.map(f => (
          <button key={f.key} onClick={() => setSportFilter(f.key)}
            className={`flex-shrink-0 flex items-center gap-1 px-3 py-1.5 rounded-full font-bold text-xs transition-all border ${
              sportFilter === f.key ? "bg-yellow-400 text-black border-yellow-300" : "bg-white/10 text-white/70 border-white/20 hover:bg-white/20"
            }`}>
            <span>{f.emoji}</span><span>{f.label}</span>
          </button>
        ))}
      </div>

      {/* Count */}
      <p className="text-white/40 text-xs">{filtered.length} card{filtered.length !== 1 ? "s" : ""} shown</p>

      {/* Card grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 max-h-[50vh] overflow-y-auto pr-1" style={{ scrollbarWidth: "thin", scrollbarColor: "rgba(255,255,255,0.1) transparent" }}>
        {filtered.map(card => {
          const wishlisted = isWishlisted(card.id);
          const imgSrc = card.cdnImageUrl || card.ebayImageUrl;
          return (
            <div key={card.id}
              className="relative rounded-2xl overflow-hidden border border-white/10 bg-white/5 hover:border-yellow-400/40 transition-all cursor-pointer group"
              onClick={() => setSelectedCard(card)}>
              {/* H badge */}
              <div className="absolute top-1.5 left-1.5 z-10 bg-yellow-400 text-black font-black text-[9px] rounded-full w-5 h-5 flex items-center justify-center shadow">H</div>
              {/* Wish list heart */}
              <button
                className={`absolute top-1.5 right-1.5 z-10 w-6 h-6 rounded-full flex items-center justify-center transition-all ${wishlisted ? "bg-pink-500 text-white" : "bg-black/50 text-white/50 hover:text-pink-400"}`}
                onClick={e => {
                  e.stopPropagation();
                  if (wishlisted) { onRemoveFromWishList(card.id); }
                  else if (wishList.length >= 5) { toast.error("Wish list is full! Remove a card first (max 5)."); }
                  else { onAddToWishList(card); toast.success(`❤️ Added ${card.player} to your wish list!`); }
                }}>
                <Heart className="w-3 h-3" fill={wishlisted ? "currentColor" : "none"} />
              </button>
              {/* Card image */}
              <div className="aspect-[3/4] bg-gray-900 overflow-hidden">
                <img src={imgSrc} alt={card.player} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  onError={e => { (e.target as HTMLImageElement).src = card.ebayImageUrl; }} />
              </div>
              {/* Info */}
              <div className="p-2">
                <p className="text-white font-black text-xs leading-tight truncate">{card.player}</p>
                <p className="text-white/40 text-[9px] truncate">{card.sport}</p>
                <p className="text-yellow-400 font-black text-[10px] mt-0.5">⚡ {card.creditCost} credits</p>
              </div>
            </div>
          );
        })}
      </div>

      {/* Card detail modal */}
      {selectedCard && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-sm p-4" onClick={() => setSelectedCard(null)}>
          <div className="relative bg-gradient-to-br from-[#0f0c29] to-[#1a1a3e] rounded-3xl border-2 border-yellow-400/30 p-5 max-w-sm w-full shadow-2xl" onClick={e => e.stopPropagation()}>
            <button onClick={() => setSelectedCard(null)} className="absolute top-3 right-3 w-7 h-7 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white/60 text-xs">✕</button>
            <div className="flex gap-4">
              <div className="w-28 flex-shrink-0 rounded-xl overflow-hidden border border-white/10">
                <img src={selectedCard.cdnImageUrl || selectedCard.ebayImageUrl} alt={selectedCard.player}
                  className="w-full h-auto object-cover"
                  onError={e => { (e.target as HTMLImageElement).src = selectedCard.ebayImageUrl; }} />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-1 mb-1">
                  <span className="bg-yellow-400 text-black font-black text-[9px] rounded-full w-4 h-4 flex items-center justify-center">H</span>
                  <span className="text-white/40 text-[10px]">House Card</span>
                </div>
                <p className="text-white font-black text-base leading-tight">{selectedCard.player}</p>
                <p className="text-white/50 text-xs mt-0.5">{selectedCard.sport}</p>
                <p className="text-white/30 text-[10px] mt-1 leading-tight line-clamp-2">{selectedCard.name}</p>
                <div className="mt-3 flex items-center gap-2">
                  <span className="text-yellow-400 font-black text-sm">⚡ {selectedCard.creditCost} credits</span>
                </div>
              </div>
            </div>
            <div className="mt-4 flex gap-2">
              {isWishlisted(selectedCard.id) ? (
                <Button onClick={() => { onRemoveFromWishList(selectedCard.id); setSelectedCard(null); toast.success("Removed from wish list"); }}
                  className="flex-1 bg-pink-500/20 text-pink-300 border border-pink-500/30 hover:bg-pink-500/30 font-black rounded-xl">
                  ❤️ Remove from Wish List
                </Button>
              ) : (
                <Button onClick={() => {
                  if (wishList.length >= 5) { toast.error("Wish list full! Max 5 cards."); return; }
                  onAddToWishList(selectedCard); setSelectedCard(null); toast.success(`❤️ Added to wish list!`);
                }}
                  className="flex-1 bg-pink-500 hover:bg-pink-400 text-white font-black rounded-xl">
                  ❤️ Add to Wish List
                </Button>
              )}
            </div>
            <p className="text-white/30 text-[10px] text-center mt-2">Ask a parent to get you this card! 🎁</p>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── Wish List Panel ──────────────────────────────────────────────────────────
function WishListPanel({ wishList, onRemove }: { wishList: HouseCard[]; onRemove: (id: string) => void }) {
  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <h2 className="text-white font-black text-xl" style={{ fontFamily: "Oswald, sans-serif" }}>❤️ MY WISH LIST</h2>
        <Badge className="bg-pink-500/20 text-pink-300 border-pink-500/30 font-black">{wishList.length}/5</Badge>
      </div>
      <p className="text-white/40 text-xs">Cards you want — your parents can see this! Max 5 cards.</p>

      {wishList.length === 0 ? (
        <div className="text-center py-12 bg-white/5 rounded-2xl border border-white/10">
          <div className="text-4xl mb-3">❤️</div>
          <p className="text-white/60 font-bold">No cards on your wish list yet!</p>
          <p className="text-white/30 text-sm mt-1">Browse the Card Showcase and tap the ❤️ to add cards</p>
        </div>
      ) : (
        <div className="space-y-3">
          {wishList.map((card, i) => (
            <div key={card.id} className="flex gap-3 bg-white/5 rounded-2xl border border-white/10 p-3 hover:border-pink-400/30 transition-all">
              <div className="w-16 flex-shrink-0 rounded-xl overflow-hidden border border-white/10">
                <img src={card.cdnImageUrl || card.ebayImageUrl} alt={card.player}
                  className="w-full h-auto object-cover"
                  onError={e => { (e.target as HTMLImageElement).src = card.ebayImageUrl; }} />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-1 mb-0.5">
                  <span className="text-pink-400 font-black text-xs">#{i + 1}</span>
                  <span className="bg-yellow-400 text-black font-black text-[8px] rounded-full w-3.5 h-3.5 flex items-center justify-center">H</span>
                </div>
                <p className="text-white font-black text-sm leading-tight truncate">{card.player}</p>
                <p className="text-white/40 text-[10px]">{card.sport}</p>
                <p className="text-white/30 text-[9px] mt-0.5 line-clamp-1">{card.name}</p>
                <p className="text-yellow-400 font-black text-xs mt-1">⚡ {card.creditCost} credits</p>
              </div>
              <button onClick={() => onRemove(card.id)} className="flex-shrink-0 w-7 h-7 rounded-full bg-white/10 hover:bg-red-500/20 hover:text-red-400 text-white/40 flex items-center justify-center transition-all">
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          ))}
          <div className="bg-indigo-500/10 border border-indigo-500/30 rounded-2xl p-3 text-center">
            <p className="text-indigo-300 font-bold text-sm">💜 Your parents can see this wish list!</p>
            <p className="text-white/40 text-xs mt-0.5">Ask them to check the Parents Corner</p>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── Level Up Tracker (Right Sidebar) ────────────────────────────────────────
function LevelTracker({ myCards, referrals, currentLevel, nextLevel }: {
  myCards: number; referrals: number;
  currentLevel: typeof LEVELS[0]; nextLevel: typeof LEVELS[0] | undefined;
}) {
  const tasks = nextLevel ? [
    { id: "cards", label: `Collect ${nextLevel.cardsNeeded} cards`, done: myCards >= nextLevel.cardsNeeded, current: myCards, goal: nextLevel.cardsNeeded, icon: "🎴" },
    ...(nextLevel.referralsNeeded > 0 ? [{ id: "refs", label: `Invite ${nextLevel.referralsNeeded} friend${nextLevel.referralsNeeded > 1 ? "s" : ""}`, done: referrals >= nextLevel.referralsNeeded, current: referrals, goal: nextLevel.referralsNeeded, icon: "👥" }] : []),
  ] : [];

  return (
    <div className="flex flex-col gap-3">
      {/* Current level badge */}
      <div className={`rounded-2xl p-3 bg-gradient-to-br ${currentLevel.color} text-center shadow-lg`}>
        <div className="text-3xl mb-1">{currentLevel.emoji}</div>
        <p className="text-white font-black text-sm leading-tight">{currentLevel.label}</p>
        <p className="text-white/70 text-[10px] mt-0.5">{currentLevel.desc}</p>
      </div>

      {/* Next level tasks */}
      {nextLevel ? (
        <div className="bg-white/5 border border-white/10 rounded-2xl p-3">
          <p className="text-yellow-400 font-black text-xs uppercase tracking-widest mb-2">Next: {nextLevel.emoji} {nextLevel.label}</p>
          <div className="space-y-2">
            {tasks.map(task => (
              <div key={task.id} className="flex items-start gap-2">
                {task.done
                  ? <CheckCircle2 className="w-4 h-4 text-green-400 flex-shrink-0 mt-0.5" />
                  : <Circle className="w-4 h-4 text-white/30 flex-shrink-0 mt-0.5" />}
                <div className="flex-1 min-w-0">
                  <p className={`text-xs font-bold leading-tight ${task.done ? "text-green-400 line-through" : "text-white/80"}`}>{task.icon} {task.label}</p>
                  {!task.done && (
                    <div className="mt-1 bg-white/10 rounded-full h-1.5 overflow-hidden">
                      <div className="h-full bg-yellow-400 rounded-full transition-all" style={{ width: `${Math.min(100, (task.current / task.goal) * 100)}%` }} />
                    </div>
                  )}
                  {!task.done && <p className="text-white/40 text-[10px] mt-0.5">{task.current} / {task.goal}</p>}
                </div>
              </div>
            ))}
          </div>
        </div>
      ) : (
        <div className="bg-yellow-400/10 border border-yellow-400/30 rounded-2xl p-3 text-center">
          <p className="text-yellow-400 font-black text-sm">🏛️ HALL OF FAME!</p>
          <p className="text-white/60 text-xs mt-1">You're a legend!</p>
        </div>
      )}

      {/* All levels mini-map */}
      <div className="bg-white/5 border border-white/10 rounded-2xl p-3">
        <p className="text-white/50 font-black text-[10px] uppercase tracking-widest mb-2">Your Journey</p>
        <div className="space-y-1">
          {LEVELS.map((lvl) => {
            const unlocked = myCards >= lvl.cardsNeeded && referrals >= lvl.referralsNeeded;
            const isCurrent = lvl.id === currentLevel.id;
            return (
              <div key={lvl.id} className={`flex items-center gap-2 rounded-lg px-2 py-1 transition-all ${isCurrent ? "bg-yellow-400/20 border border-yellow-400/40" : unlocked ? "opacity-60" : "opacity-30"}`}>
                <span className="text-sm">{lvl.emoji}</span>
                <span className={`text-[10px] font-bold flex-1 truncate ${isCurrent ? "text-yellow-400" : unlocked ? "text-green-400" : "text-white/50"}`}>{lvl.label}</span>
                {unlocked && !isCurrent && <CheckCircle2 className="w-3 h-3 text-green-400 flex-shrink-0" />}
                {isCurrent && <span className="text-yellow-400 text-[9px] font-black">YOU</span>}
                {!unlocked && !isCurrent && <Lock className="w-3 h-3 text-white/20 flex-shrink-0" />}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

// ─── Arcade Cabinet Card ──────────────────────────────────────────────────────
function ArcadeCabinet({ game, onPlay }: { game: { id: string; title: string; emoji: string; desc: string; color: string; credits: number; preview: string }; onPlay: () => void }) {
  const [hovered, setHovered] = useState(false);
  const accentMatch = game.color.match(/#([0-9a-fA-F]{6})/);
  const accent = accentMatch ? accentMatch[0] : "#fbbf24";
  return (
    <div
      className="relative cursor-pointer select-none"
      style={{
        transition: "transform 0.2s ease, filter 0.2s ease",
        transform: hovered ? "scale(1.07) translateY(-8px)" : "scale(1)",
        filter: hovered
          ? `drop-shadow(0 0 20px ${accent}bb) drop-shadow(0 10px 30px rgba(0,0,0,0.9))`
          : "drop-shadow(0 4px 16px rgba(0,0,0,0.7))",
      }}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      onClick={onPlay}
    >
      {/* Cabinet body */}
      <div style={{
        background: "linear-gradient(180deg, #111128 0%, #0d1b3e 60%, #0a1628 100%)",
        border: `2.5px solid ${hovered ? accent : "rgba(255,255,255,0.12)"}`,
        borderRadius: 14,
        overflow: "hidden",
        transition: "border-color 0.2s",
      }}>
        {/* Marquee light bar */}
        <div style={{
          height: 12,
          background: game.color,
          display: "flex",
          alignItems: "center",
          justifyContent: "space-around",
          padding: "0 6px",
        }}>
          {[0,1,2,3,4,5,6,7,8].map(i => (
            <div key={i} style={{
              width: 6, height: 6, borderRadius: "50%",
              background: "rgba(255,255,255,0.9)",
              boxShadow: "0 0 4px #fff",
              animation: `marqueeFlash ${0.35 + i * 0.08}s ease-in-out infinite alternate`,
            }} />
          ))}
        </div>
        {/* Title plate */}
        <div style={{
          background: "rgba(0,0,0,0.75)",
          borderBottom: `1px solid ${accent}55`,
          padding: "5px 8px",
          textAlign: "center",
        }}>
          <span style={{
            fontSize: 11, fontWeight: 900,
            color: hovered ? accent : "#ffffff",
            fontFamily: "'Oswald', sans-serif",
            letterSpacing: 2.5, textTransform: "uppercase",
            textShadow: hovered ? `0 0 14px ${accent}` : "0 1px 4px rgba(0,0,0,0.8)",
            transition: "color 0.2s, text-shadow 0.2s",
          }}>{game.title}</span>
        </div>
        {/* CRT screen */}
        <div style={{
          margin: "8px 10px",
          borderRadius: 8,
          overflow: "hidden",
          border: `2px solid ${accent}77`,
          background: "#000",
          aspectRatio: "4/3",
          position: "relative",
          boxShadow: `inset 0 0 24px rgba(0,0,0,0.9), 0 0 10px ${accent}55`,
        }}>
          {/* Scanlines */}
          <div style={{
            position: "absolute", inset: 0, zIndex: 3, pointerEvents: "none",
            backgroundImage: "repeating-linear-gradient(0deg, transparent, transparent 2px, rgba(0,0,0,0.22) 2px, rgba(0,0,0,0.22) 4px)",
          }} />
          {/* Screen content */}
          <div style={{
            position: "absolute", inset: 0, zIndex: 1,
            background: game.color,
            display: "flex", flexDirection: "column",
            alignItems: "center", justifyContent: "center", gap: 6,
          }}>
            {hovered ? (
              <>
                <div style={{ fontSize: 38, lineHeight: 1 }}>▶</div>
                <span style={{
                  fontSize: 9, fontWeight: 900, color: "#fff",
                  fontFamily: "'Courier New', monospace", letterSpacing: 2,
                  animation: "pulse 0.7s ease-in-out infinite alternate",
                }}>PRESS TO PLAY</span>
              </>
            ) : (
              <>
                <div style={{ fontSize: 42, lineHeight: 1 }}>{game.emoji}</div>
                <span style={{
                  fontSize: 8, fontWeight: 700, color: "rgba(255,255,255,0.75)",
                  fontFamily: "'Courier New', monospace", letterSpacing: 1.5,
                }}>{game.preview}</span>
              </>
            )}
          </div>
          {/* CRT vignette */}
          <div style={{
            position: "absolute", inset: 0, zIndex: 4, pointerEvents: "none",
            background: "radial-gradient(ellipse at center, transparent 55%, rgba(0,0,0,0.65) 100%)",
          }} />
        </div>
        {/* Bottom panel: coin slot + button */}
        <div style={{ padding: "6px 10px 12px", display: "flex", flexDirection: "column", alignItems: "center", gap: 7 }}>
          {/* Coin slot */}
          <div style={{
            width: 44, height: 5, borderRadius: 3,
            background: "rgba(0,0,0,0.85)",
            border: "1px solid rgba(255,255,255,0.18)",
            boxShadow: "inset 0 2px 4px rgba(0,0,0,0.9)",
          }} />
          {/* INSERT COIN button */}
          <div style={{
            background: hovered ? accent : "rgba(255,255,255,0.07)",
            border: `1.5px solid ${hovered ? accent : "rgba(255,255,255,0.18)"}`,
            borderRadius: 20, padding: "5px 16px",
            display: "flex", alignItems: "center", gap: 5,
            transition: "background 0.2s, border-color 0.2s, box-shadow 0.2s",
            boxShadow: hovered ? `0 0 14px ${accent}99` : "none",
          }}>
            <Zap style={{ width: 10, height: 10, color: hovered ? "#000" : "#fbbf24", flexShrink: 0 }} />
            <span style={{
              fontSize: 9, fontWeight: 900,
              color: hovered ? "#000" : "#fbbf24",
              fontFamily: "'Courier New', monospace",
              letterSpacing: 1.5, textTransform: "uppercase",
            }}>
              {game.credits === 0 ? "INSERT COIN" : `${game.credits} CREDITS`}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── Game Window Frame ────────────────────────────────────────────────────────
function GameWindow({ title, onClose, children, wide }: { title: string; onClose: () => void; children: React.ReactNode; wide?: boolean }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4" onClick={onClose}>
      <div
        className={`relative w-full ${wide ? "max-w-3xl" : "max-w-2xl"} flex flex-col rounded-3xl overflow-hidden shadow-2xl border-2 border-yellow-400/40`}
        style={{ background: "linear-gradient(160deg, #0f0c29, #1a1a3e, #0f3460)", height: "92vh" }}
        onClick={e => e.stopPropagation()}
      >
        <div className="flex items-center justify-between px-4 py-2 border-b border-white/10 bg-black/30 flex-shrink-0">
          <div className="flex items-center gap-2">
            <Gamepad2 className="w-4 h-4 text-yellow-400" />
            <span className="text-white font-black text-sm">{title}</span>
          </div>
          <button onClick={onClose} className="w-7 h-7 rounded-full bg-red-500/80 hover:bg-red-500 flex items-center justify-center text-white font-black text-xs transition-colors">✕</button>
        </div>
        <div className="flex-1 overflow-hidden" style={{ minHeight: 0 }}>
          {children}
        </div>
      </div>
    </div>
  );
}

// ─── Scoreboard ───────────────────────────────────────────────────────────────
function Scoreboard({ kidName, kidAvatar, credits, myCards, referrals, loginStreak, currentLevel, wishListCount, onExit }: {
  kidName: string; kidAvatar: string; credits: number; myCards: number; referrals: number; loginStreak: number; currentLevel: typeof LEVELS[0]; wishListCount: number; onExit?: () => void;
}) {
  return (
    <div className="bg-gradient-to-r from-[#0d0d1a] via-[#1a1a3e] to-[#0d0d1a] border-b-2 border-yellow-400/30">
      <div className="container py-3">
        <div className="flex items-center gap-4 flex-wrap">
          <div className="flex items-center gap-2.5 flex-shrink-0">
            <div className="relative">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-yellow-400/20 to-orange-500/20 border border-yellow-400/40 flex items-center justify-center text-xl">{kidAvatar}</div>
              <div className="absolute -bottom-1 -right-1 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-full w-5 h-5 flex items-center justify-center text-[9px] font-black text-black">{currentLevel.emoji}</div>
            </div>
            <div>
              <p className="text-white font-black text-sm leading-tight">{kidName}</p>
              <p className="text-yellow-400 text-[10px] font-bold">{currentLevel.label}</p>
            </div>
          </div>

          <div className="hidden sm:block w-px h-8 bg-white/10" />

          <div className="flex items-center gap-4 flex-wrap flex-1">
            {[
              { label: "Credits", value: credits, color: "text-yellow-400", icon: "⚡" },
              { label: "Cards",   value: myCards,  color: "text-blue-400",   icon: "🎴" },
              { label: "Friends", value: referrals, color: "text-green-400", icon: "👥" },
              { label: "Streak",  value: `${loginStreak}d`, color: "text-orange-400", icon: "🔥" },
              { label: "Wish",    value: `${wishListCount}/5`, color: "text-pink-400", icon: "❤️" },
            ].map(stat => (
              <div key={stat.label} className="text-center min-w-[50px]">
                <p className={`${stat.color} font-black text-lg leading-none`}>{stat.icon} {stat.value}</p>
                <p className="text-white/40 text-[9px] uppercase tracking-wider">{stat.label}</p>
              </div>
            ))}
          </div>

          <Link href="/kids-corner/parent" className="flex items-center gap-1.5 bg-indigo-600/80 hover:bg-indigo-600 border border-indigo-400/40 rounded-full px-3 py-1.5 transition-colors flex-shrink-0">
              <Crown className="w-3.5 h-3.5 text-indigo-200" />
              <span className="text-indigo-200 font-black text-xs">Parents Corner</span>
          </Link>
          {onExit && (
            <button
              onClick={onExit}
              className="flex items-center gap-1.5 bg-red-700/70 hover:bg-red-600 border border-red-400/40 rounded-full px-3 py-1.5 transition-all hover:scale-105 flex-shrink-0"
            >
              <span className="text-red-200 font-black text-xs">🚪 Exit</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

// ─── Login Screen ─────────────────────────────────────────────────────────────
function LoginScreen({ onLogin }: { onLogin: (name: string, avatar: string, sport: string, team: string) => void }) {
  const [mode, setMode] = useState<"welcome" | "login" | "signup">("welcome");
  const [name, setName] = useState("");
  const [avatar, setAvatar] = useState("🏆");
  const [sport, setSport] = useState("basketball");
  const [team, setTeam] = useState("");
  const [loginName, setLoginName] = useState("");

  const AVATARS = ["🏆","⭐","🔥","🦅","🐯","💎","🚀","🏀","⚾","🏈","🏒","⚽","🎯","🌟","👑","⚡"];
  const SPORTS = [{ s: "basketball", e: "🏀" }, { s: "baseball", e: "⚾" }, { s: "football", e: "🏈" }, { s: "hockey", e: "🏒" }, { s: "soccer", e: "⚽" }, { s: "tennis", e: "🎾" }];

  return (
    <div className="min-h-screen flex items-center justify-center p-4 relative overflow-hidden" style={{ background: "linear-gradient(135deg, #0a0a1a 0%, #1a0a2e 30%, #0a1a3e 70%, #0a0a1a 100%)" }}>
      {[...Array(12)].map((_, i) => (
        <div key={i} className="absolute rounded-full opacity-20 animate-pulse" style={{ width: 8 + (i % 4) * 6, height: 8 + (i % 4) * 6, background: ["#fbbf24","#f97316","#3b82f6","#8b5cf6"][i % 4], top: `${(i * 8) % 90}%`, left: `${(i * 9) % 90}%`, animationDelay: `${i * 0.3}s` }} />
      ))}

      <div className="relative z-10 w-full max-w-md">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-20 h-20 rounded-3xl bg-gradient-to-br from-yellow-400 to-orange-500 shadow-2xl shadow-orange-500/40 mb-4 text-4xl">🏆</div>
          <h1 className="text-white font-black text-4xl" style={{ fontFamily: "Oswald, sans-serif", textShadow: "0 0 30px rgba(251,191,36,0.5)" }}>KIDS CORNER</h1>
          <p className="text-yellow-400/80 font-bold text-sm mt-1 tracking-widest uppercase">Sports Cards Online</p>
        </div>

        {mode === "welcome" && (
          <div className="space-y-3">
            <button onClick={() => setMode("login")}
              className="w-full py-4 rounded-2xl font-black text-lg bg-gradient-to-r from-yellow-400 to-orange-500 text-black hover:scale-105 transition-all shadow-xl shadow-orange-500/30">
              🎮 I Already Have an Account
            </button>
            <button onClick={() => setMode("signup")}
              className="w-full py-4 rounded-2xl font-black text-lg bg-white/10 text-white border-2 border-white/20 hover:bg-white/20 hover:scale-105 transition-all">
              🚀 Create My Profile
            </button>
            <Link href="/kids-corner/parent" className="flex items-center justify-center gap-2 w-full py-3 rounded-2xl font-bold text-sm text-indigo-300 border border-indigo-500/30 hover:bg-indigo-500/10 transition-all">
                <Crown className="w-4 h-4" /> Parents — click here
            </Link>
          </div>
        )}

        {mode === "login" && (
          <div className="bg-white/5 backdrop-blur border border-white/10 rounded-3xl p-6 space-y-4">
            <h2 className="text-white font-black text-xl text-center">Welcome Back! 👋</h2>
            <div>
              <label className="text-white/70 font-bold text-sm block mb-1">Your Name</label>
              <input className="w-full bg-white/10 border border-white/20 rounded-xl px-4 py-3 text-white placeholder-white/30 outline-none focus:border-yellow-400 font-semibold"
                placeholder="Enter your name..." value={loginName} onChange={e => setLoginName(e.target.value)} />
            </div>
            <Button onClick={() => {
              if (!loginName.trim()) { toast.error("Enter your name!"); return; }
              const storedAvatar = localStorage.getItem(`kc_avatar_${loginName.toLowerCase().trim()}`) || "🏆";
              const storedSport = localStorage.getItem(`kc_sport_${loginName.toLowerCase().trim()}`) || "basketball";
              const storedTeam = localStorage.getItem(`kc_team_${loginName.toLowerCase().trim()}`) || "";
              onLogin(loginName.trim(), storedAvatar, storedSport, storedTeam);
            }} className="w-full bg-gradient-to-r from-yellow-400 to-orange-500 text-black font-black text-lg py-3 rounded-2xl hover:scale-105 transition-all">
              🎮 Let's Play!
            </Button>
            <button onClick={() => setMode("welcome")} className="w-full text-white/50 text-sm hover:text-white/80 transition-colors">← Back</button>
          </div>
        )}

        {mode === "signup" && (
          <div className="bg-white/5 backdrop-blur border border-white/10 rounded-3xl p-6 space-y-4">
            <h2 className="text-white font-black text-xl text-center">Create Your Profile 🚀</h2>
            <div>
              <label className="text-white/70 font-bold text-sm block mb-1">Your Name</label>
              <input className="w-full bg-white/10 border border-white/20 rounded-xl px-4 py-3 text-white placeholder-white/30 outline-none focus:border-yellow-400 font-semibold"
                placeholder="Enter your name..." value={name} onChange={e => setName(e.target.value)} />
            </div>
            <div>
              <label className="text-white/70 font-bold text-sm block mb-2">Pick Your Avatar</label>
              <div className="grid grid-cols-8 gap-1.5">
                {AVATARS.map(a => (
                  <button key={a} onClick={() => setAvatar(a)}
                    className={`text-xl w-9 h-9 rounded-xl transition-all border-2 ${avatar === a ? "bg-yellow-400/30 border-yellow-400 scale-110" : "bg-white/10 border-white/20 hover:bg-white/20"}`}>{a}</button>
                ))}
              </div>
            </div>
            <div>
              <label className="text-white/70 font-bold text-sm block mb-2">Favorite Sport</label>
              <div className="grid grid-cols-3 gap-2">
                {SPORTS.map(({ s, e }) => (
                  <button key={s} onClick={() => setSport(s)}
                    className={`py-2 rounded-xl font-bold text-xs transition-all border-2 ${sport === s ? "bg-yellow-400 text-black border-yellow-300" : "bg-white/10 text-white border-white/20 hover:bg-white/20"}`}>
                    {e} {s.charAt(0).toUpperCase() + s.slice(1)}
                  </button>
                ))}
              </div>
            </div>
            <div>
              <label className="text-white/70 font-bold text-sm block mb-1">Favorite Team <span className="text-white/30">(optional)</span></label>
              <input className="w-full bg-white/10 border border-white/20 rounded-xl px-4 py-2.5 text-white placeholder-white/30 outline-none focus:border-yellow-400 font-semibold"
                placeholder="Bulls, Lakers, Yankees..." value={team} onChange={e => setTeam(e.target.value)} />
            </div>
            <Button onClick={() => {
              if (!name.trim()) { toast.error("Enter your name first!"); return; }
              localStorage.setItem(`kc_avatar_${name.toLowerCase().trim()}`, avatar);
              localStorage.setItem(`kc_sport_${name.toLowerCase().trim()}`, sport);
              localStorage.setItem(`kc_team_${name.toLowerCase().trim()}`, team);
              onLogin(name.trim(), avatar, sport, team);
            }} className="w-full bg-gradient-to-r from-yellow-400 to-orange-500 text-black font-black text-lg py-3 rounded-2xl hover:scale-105 transition-all shadow-xl shadow-orange-500/30">
              🏆 Start My Journey!
            </Button>
            <button onClick={() => setMode("welcome")} className="w-full text-white/50 text-sm hover:text-white/80 transition-colors">← Back</button>
          </div>
        )}
      </div>
    </div>
  );
}

// ─── Main Component ───────────────────────────────────────────────────────────
export default function KidsCorner() {
  const { user } = useAuth();

  // ── Profile / Auth ──────────────────────────────────────────────────────────
  const [profileCreated, setProfileCreated] = useState(() => !!localStorage.getItem("kc_name"));
  const [kidName, setKidName] = useState(() => localStorage.getItem("kc_name") || "");
  const [kidAvatar, setKidAvatar] = useState(() => localStorage.getItem("kc_avatar") || "🏆");
  const [favSport, setFavSport] = useState(() => localStorage.getItem("kc_sport") || "basketball");
  const [favTeam, setFavTeam] = useState(() => localStorage.getItem("kc_team") || "");
  // DB-backed kid ID for trivia tracking (synced after login)
  const [kidDbId, setKidDbId] = useState<number>(() => parseInt(localStorage.getItem("kc_db_id") || "0", 10));
  const getOrCreateProfile = trpc.kids.getOrCreateProfile.useMutation();

  // ── Game state ──────────────────────────────────────────────────────────────
  const [credits, setCredits] = useState(() => parseInt(localStorage.getItem("kc_credits") || "25", 10));
  const [myCards, setMyCards] = useState<RealCard[]>(() => {
    try { return JSON.parse(localStorage.getItem("kc_cards") || "[]"); } catch { return []; }
  });
  // ── Real card pool from DB ────────────────────────────────────────────────────
  const { data: cardPoolData } = trpc.kids.getCardPool.useQuery({ limit: 150 });
  const realCardPool = useMemo<RealCard[]>(() => {
    if (!cardPoolData?.cards || cardPoolData.cards.length === 0) return [];
    const rarities: Rarity[] = ["legendary", "epic", "rare", "uncommon", "common"];
    const weights = [2, 5, 8, 15, 70];
    return cardPoolData.cards.map(c => {
      const roll = Math.random() * 100;
      let cum = 0; let rarity: Rarity = "common";
      for (let i = 0; i < weights.length; i++) { cum += weights[i]; if (roll < cum) { rarity = rarities[i]; break; } }
      return { ...c, rarity };
    });
  }, [cardPoolData]);
  const [referrals, setReferrals] = useState(() => parseInt(localStorage.getItem("kc_referrals") || "0", 10));
  const [loginStreak, setLoginStreak] = useState(() => parseInt(localStorage.getItem("kc_streak") || "0", 10));
  const [freePulls, setFreePulls] = useState(0);

  // ── Wish List ───────────────────────────────────────────────────────────────
  const [wishList, setWishList] = useState<HouseCard[]>(() => {
    try { return JSON.parse(localStorage.getItem("kc_wishlist") || "[]"); } catch { return []; }
  });

  // ── Spin wheel x2 multiplier ────────────────────────────────────────────────
  const [spinX2Active, setSpinX2Active] = useState(false);

  // ── Active game window ──────────────────────────────────────────────────────
  type GameId = "racer" | "pull" | "trivia" | "collection" | "showcase" | "wishlist" | "gametime" | "gofish" | "rps" | "headsortails" | "trade" | null;
  const [activeGame, setActiveGame] = useState<GameId>(null);

  // ── Session & daily bonus ────────────────────────────────────────────────────
  const [sessionId, setSessionId] = useState<number | null>(null);
  const [sessionStartTime] = useState(() => Date.now());
  const [remainingSeconds, setRemainingSeconds] = useState(3600);
  const [isTimedOut, setIsTimedOut] = useState(false);
  const startSessionMut = trpc.kids.startSession.useMutation();
  const endSessionMut = trpc.kids.endSession.useMutation();
  const claimDailyBonusMut = trpc.kids.claimDailyBonus.useMutation();
  const updateCreditsMut = trpc.kids.updateCredits.useMutation();

  // ── Mascot entrance/exit state ───────────────────────────────────────────────
  const [mascotEntered, setMascotEntered] = useState(false);
  const [exitMode, setExitMode] = useState(false);
  const [walkOffLeft, setWalkOffLeft] = useState(false);
  const [walkOffRight, setWalkOffRight] = useState(false);
  const [exitSpeechLeft, setExitSpeechLeft] = useState<string | undefined>(undefined);
  const [exitSpeechRight, setExitSpeechRight] = useState<string | undefined>(undefined);

  const handleExitKidsCorner = useCallback(() => {
    // Show mascots waving goodbye
    setMascotEntered(true);
    setExitMode(true);
    setExitSpeechLeft("👋 Bye! See you next time!");
    setExitSpeechRight("🌟 Great playing today!");
    // After 1.8s, slide both mascots off screen
    setTimeout(() => {
      setWalkOffLeft(true);
      setTimeout(() => setWalkOffRight(true), 200);
    }, 1800);
    // Navigate home after animation
    setTimeout(() => {
      window.location.href = "/";
    }, 3200);
  }, []);

    // ── Mascot state ─────────────────────────────────────────────────────────────
  const [mascotLeft, setMascotLeft] = useState<MascotState>("idle");
  const [mascotRight, setMascotRight] = useState<MascotState>("idle");
  const [mascotLeftSpeech, setMascotLeftSpeech] = useState<string | undefined>(undefined);
  const [mascotRightSpeech, setMascotRightSpeech] = useState<string | undefined>(undefined);
  const [showLevelUp, setShowLevelUp] = useState(false);
  const [levelUpName, setLevelUpName] = useState("");

  // Helper: trigger mascot reaction then return to idle
  const mascotReact = useCallback((left: MascotState, right: MascotState, lSpeech?: string, rSpeech?: string, durationMs = 3000) => {
    setMascotLeft(left); setMascotRight(right);
    setMascotLeftSpeech(lSpeech); setMascotRightSpeech(rSpeech);
    setTimeout(() => {
      setMascotLeft("idle"); setMascotRight("idle");
      setMascotLeftSpeech(undefined); setMascotRightSpeech(undefined);
    }, durationMs);
  }, []);

  // ── Modals ────────────────────────────────────────────────────────────────
  const [pulledCard, setPulledCard] = useState<RealCard | null>(null);

  // ── Trivia state ────────────────────────────────────────────────────────────
  const [triviaIdx, setTriviaIdx] = useState(0);
  const [triviaAnswered, setTriviaAnswered] = useState(false);
  const [triviaCorrect, setTriviaCorrect] = useState(false);

  // ── Persist to localStorage ─────────────────────────────────────────────────
  useEffect(() => { localStorage.setItem("kc_credits", String(credits)); }, [credits]);
  useEffect(() => { localStorage.setItem("kc_cards", JSON.stringify(myCards)); }, [myCards]);
  useEffect(() => { localStorage.setItem("kc_referrals", String(referrals)); }, [referrals]);
  useEffect(() => { localStorage.setItem("kc_streak", String(loginStreak)); }, [loginStreak]);
  useEffect(() => { localStorage.setItem("kc_wishlist", JSON.stringify(wishList)); }, [wishList]);

  // ── Login streak ────────────────────────────────────────────────────────────
  useEffect(() => {
    if (!profileCreated) return;
    const today = new Date().toISOString().slice(0, 10);
    const last = localStorage.getItem("kc_last_login");
    if (last !== today) {
      localStorage.setItem("kc_last_login", today);
      const yesterday = new Date(Date.now() - 86400000).toISOString().slice(0, 10);
      if (last === yesterday) {
        setLoginStreak(s => s + 1);
        toast.success(`🔥 Day ${loginStreak + 1} streak! Keep it up!`);
      } else if (!last) {
        setLoginStreak(1);
      } else {
        setLoginStreak(1);
      }
    }
  }, [profileCreated]);

  // ── Referral from URL ───────────────────────────────────────────────────────
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const ref = params.get("ref");
    if (ref && profileCreated) {
      setCredits(c => c + 50);
      toast.success("🎉 Welcome bonus! +50 credits for joining through a friend's link!");
      const url = new URL(window.location.href);
      url.searchParams.delete("ref");
      window.history.replaceState({}, "", url.toString());
    }
  }, [profileCreated]);

  // ── Computed ─────────────────────────────────────────────────────────────────
  const currentLevel = LEVELS.reduce((best, lvl) => {
    if (myCards.length >= lvl.cardsNeeded && referrals >= lvl.referralsNeeded) return lvl;
    return best;
  }, LEVELS[0]);
  const nextLevel = LEVELS[LEVELS.indexOf(currentLevel) + 1];

  // ── Handlers ─────────────────────────────────────────────────────────────────
  const handleLogin = (name: string, avatar: string, sport: string, team: string, birthdate?: string) => {
    setKidName(name); setKidAvatar(avatar); setFavSport(sport); setFavTeam(team);
    localStorage.setItem("kc_name", name);
    localStorage.setItem("kc_avatar", avatar);
    localStorage.setItem("kc_sport", sport);
    localStorage.setItem("kc_team", team);
    setProfileCreated(true);
    // Sync DB profile for trivia tracking
    const username = name.toLowerCase().replace(/[^a-z0-9]/g, "") + "_" + Math.random().toString(36).slice(2, 6);
    const storedUsername = localStorage.getItem("kc_username") || username;
    if (!localStorage.getItem("kc_username")) localStorage.setItem("kc_username", storedUsername);
    getOrCreateProfile.mutateAsync({
      username: storedUsername,
      displayName: name,
      birthdate: birthdate || localStorage.getItem("kc_birthdate") || "2012-01-01",
      avatarEmoji: avatar,
    }).then(res => {
      setKidDbId(res.id);
      localStorage.setItem("kc_db_id", String(res.id));
    }).catch(() => {/* non-critical */});
    const existing = JSON.parse(localStorage.getItem("kc_cards") || "[]");
    if (existing.length === 0) {
      // Give 2 starter cards from real pool if available
      const starters = realCardPool.slice(0, 2);
      if (starters.length > 0) {
        setMyCards(starters);
        toast.success(`Welcome to Kids Corner, ${name}! 🎉 You got 2 FREE starter cards!`);
      } else {
        toast.success(`Welcome to Kids Corner, ${name}! 🎉 Pull your first card to start your collection!`);
      }
    } else {
      toast.success(`Welcome back, ${name}! 🎮`);
    }
    // Trigger mascot entrance animation
    setTimeout(() => setMascotEntered(true), 300);
  };

  // ── Session start + daily bonus on login ────────────────────────────────────────────────────
  useEffect(() => {
    if (!profileCreated || !kidDbId) return;
    startSessionMut.mutateAsync({ kidId: kidDbId })
      .then(res => setSessionId(res.sessionId))
      .catch(() => {});
    claimDailyBonusMut.mutateAsync({ kidId: kidDbId })
      .then(res => {
        if (res.claimed) {
          setCredits(res.credits ?? credits);
          toast.success("🎁 Daily bonus! +25 credits added!");
        }
      }).catch(() => {});
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [profileCreated, kidDbId]);

  // ── Play timer countdown (1-hour limit) ────────────────────────────────────────────────────
  useEffect(() => {
    if (!profileCreated) return;
    const timer = setInterval(() => {
      const elapsed = Math.floor((Date.now() - sessionStartTime) / 1000);
      const remaining = Math.max(0, 3600 - elapsed);
      setRemainingSeconds(remaining);
      if (remaining === 0 && !isTimedOut) {
        setIsTimedOut(true);
        toast.error("⏰ Time's up! You've played for 1 hour today. Ask a parent for more time!", { duration: 10000 });
        mascotReact("sad", "sad", "Time's up, buddy! 😢", "Great playing today! See you tomorrow! 👋", 8000);
      }
    }, 1000);
    return () => clearInterval(timer);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [profileCreated, sessionStartTime, isTimedOut]);

  // ── End session on page unload ────────────────────────────────────────────────────────────────────────────────────────────────────────────
  useEffect(() => {
    if (!sessionId || !kidDbId) return;
    const handleUnload = () => {
      const dur = Math.floor((Date.now() - sessionStartTime) / 1000);
      navigator.sendBeacon("/api/trpc/kids.endSession", JSON.stringify({ sessionId, durationSeconds: dur }));
    };
    window.addEventListener("beforeunload", handleUnload);
    return () => window.removeEventListener("beforeunload", handleUnload);
  }, [sessionId, kidDbId, sessionStartTime]);

  const doCardPull = (forceLegendary = false) => {
    const cost = freePulls > 0 ? 0 : 10;
    if (cost > 0 && credits < 10) { toast.error("Need 10 credits to pull a card!"); return; }
    if (freePulls > 0) setFreePulls(f => f - 1); else setCredits(c => c - 10);
    // Mascots hype the pull
    mascotReact("hype", "hype", "OPEN IT! OPEN IT! 🤩", "This could be LEGENDARY! 🎴", 4000);
    const weights = forceLegendary ? [100, 0, 0, 0, 0] : [2, 5, 8, 15, 70];
    const rarities: Rarity[] = ["legendary", "epic", "rare", "uncommon", "common"];
    const roll = Math.random() * 100;
    let cum = 0; let chosen: Rarity = "common";
    for (let i = 0; i < weights.length; i++) { cum += weights[i]; if (roll < cum) { chosen = rarities[i]; break; } }
    // Use real cards from DB pool, fallback to CARD_POOL-based fake card
    let card: RealCard;
    if (realCardPool.length > 0) {
      const rarityPool = realCardPool.filter(c => c.rarity === chosen);
      const src = rarityPool.length > 0 ? rarityPool : realCardPool;
      card = { ...src[Math.floor(Math.random() * src.length)], rarity: chosen };
    } else {
      // Fallback: use CARD_POOL legend as a fake RealCard
      const fallbackPool = CARD_POOL.filter(c => c.rarity === chosen);
      const fb = fallbackPool[Math.floor(Math.random() * fallbackPool.length)];
      card = { id: -1, playerName: fb.legend.name, sport: fb.legend.sport, frontImageUrl: null, gradeScore: null, gradeCompany: null, setName: fb.legend.team, year: fb.legend.era, source: null, rarity: chosen };
    }
    setPulledCard(card); setMyCards(prev => [...prev, card]);
    // Mascot reaction based on rarity
    setTimeout(() => {
      if (chosen === "legendary" || chosen === "epic") {
        mascotReact("celebrate", "celebrate", "LEGENDARY PULL!! 🏆", "WE ARE NOT WORTHY! 🙏", 5000);
      } else {
        mascotReact("excited", "cheer", "Nice pull! 😎", "Add it to your collection!", 3000);
      }
    }, 800);
    toast.success(`🎴 You pulled a ${chosen.toUpperCase()} card!`);
  };

  const answerTrivia = (choice: string) => {
    if (triviaAnswered) return;
    const q = TRIVIA[triviaIdx];
    const correct = choice === q.answer;
    setTriviaAnswered(true); setTriviaCorrect(correct);
    if (correct) {
      setCredits(c => c + q.credits);
      toast.success(`✅ Correct! +${q.credits} credits!`);
      mascotReact("cheer", "excited", "CORRECT! 🧠", `+${q.credits} credits! ⚡`, 3000);
    } else {
      toast.error(`❌ Not quite! Answer: ${q.answer}`);
      mascotReact("sad", "sad", "Aww, so close!", "You'll get the next one! 💪", 3000);
    }
  };

  const handleSpinResult = (seg: SpinSeg, wager: number, isBonus: boolean) => {
    if (isBonus) {
      setSpinX2Active(true);
      toast.success("🔥 ×2 MULTIPLIER ACTIVE! Your next spin winnings are doubled!");
      mascotReact("excited", "hype", "🔥 ×2 NEXT SPIN!", "DOUBLE OR NOTHING! 🔥", 3500);
      return;
    }
    // Deduct wager first
    setCredits(c => c - wager);
    if (seg.type === "win") {
      const multiplier = spinX2Active ? seg.multiplier * 2 : seg.multiplier;
      const earned = wager * multiplier;
      setCredits(c => c + earned);
      toast.success(`${seg.emoji} ${seg.label}! +${earned} credits${spinX2Active ? " (×2 BONUS!)" : ""}!`);
      if (spinX2Active) setSpinX2Active(false);
      // Big win vs small win
      if (seg.multiplier >= 7) {
        mascotReact("celebrate", "celebrate", `${seg.emoji} ${seg.label}!!`, `+${earned} credits! 🏆`, 4000);
      } else {
        mascotReact("cheer", "excited", `${seg.emoji} Nice spin!`, `+${earned} credits! ⚡`, 3000);
      }
    } else if (seg.type === "lose") {
      toast.error(`${seg.emoji} ${seg.label}! Lost ${wager} credit${wager > 1 ? "s" : ""}.`);
      mascotReact("sad", "sad", `${seg.emoji} Ohhh nooo...`, "Shake it off! 💪", 3000);
    }
  };

  const addToWishList = (card: HouseCard) => {
    setWishList(prev => {
      if (prev.some(w => w.id === card.id)) return prev;
      if (prev.length >= 5) return prev;
      return [...prev, card];
    });
  };

  const removeFromWishList = (cardId: string) => {
    setWishList(prev => prev.filter(w => w.id !== cardId));
  };

  // ── Arcade games catalog ──────────────────────────────────────────────────────
  type GameEntry = { id: NonNullable<GameId>; title: string; emoji: string; desc: string; color: string; credits: number; preview: string };
  const GAMES: GameEntry[] = [
    { id: "racer",       title: "Card Racer",          emoji: "🏎️", desc: "Dodge obstacles, collect cards!",            color: "linear-gradient(135deg, #dc2626, #7f1d1d)", credits: 0,  preview: "Race!" },
    { id: "gametime",    title: "CARD BATTLE",          emoji: "🃏", desc: "Flip cards! Most cards in 8 min wins!",       color: "linear-gradient(135deg, #b45309, #78350f)", credits: 0,  preview: "CARD BATTLE" },
    { id: "pull",        title: "Card Pull",            emoji: "🎴", desc: "Pull a legendary card from the pack!",       color: "linear-gradient(135deg, #0369a1, #1e3a5f)", credits: 10, preview: "Card Pull" },
    { id: "gofish",      title: "Go Fish",              emoji: "🐟", desc: "3-handed Go Fish vs Maverick & Caitlin!",   color: "linear-gradient(135deg, #0e7490, #164e63)", credits: 0,  preview: "Go Fish" },
    { id: "rps",         title: "Rock Paper Scissors",  emoji: "✊", desc: "Throw down vs Maverick & Caitlin!",          color: "linear-gradient(135deg, #065f46, #064e3b)", credits: 0,  preview: "RPS" },
    { id: "headsortails",title: "Heads or Tails",       emoji: "🪙", desc: "Maverick or Caitlin flips — call it!",       color: "linear-gradient(135deg, #4c1d95, #2e1065)", credits: 0,  preview: "Flip It" },
    { id: "trivia",      title: "Sports Trivia",        emoji: "🧠", desc: "Answer questions, earn credits!",            color: "linear-gradient(135deg, #065f46, #064e3b)", credits: 0,  preview: "Trivia" },
    { id: "trade",       title: "Trade Center",         emoji: "🔄", desc: "Trade cards with Appie or Giffy!",           color: "linear-gradient(135deg, #9a3412, #431407)", credits: 0,  preview: "Trade" },
    { id: "showcase",    title: "Card Showcase",        emoji: "🏪", desc: "Browse 100 real house cards!",               color: "linear-gradient(135deg, #9a3412, #431407)", credits: 0,  preview: "Showcase" },
    { id: "wishlist",    title: "My Wish List",         emoji: "❤️",  desc: "Cards you want — parents can see!",         color: "linear-gradient(135deg, #9d174d, #500724)", credits: 0,  preview: "Wish List" },
    { id: "collection",  title: "My Collection",        emoji: "📦", desc: "View and manage your card collection!",     color: "linear-gradient(135deg, #92400e, #451a03)", credits: 0,  preview: "Collection" },
  ];

  // ── Login gate ────────────────────────────────────────────────────────────────
  if (!profileCreated) {
    return <LoginScreen onLogin={handleLogin} />;
  }

  // ── Main arcade layout ────────────────────────────────────────────────────────
  return (
    <div className="min-h-screen" style={{ background: "linear-gradient(160deg, #080818 0%, #0f0c29 40%, #0a1a3e 100%)" }}>

      {/* Mascot walk-on entrance + walk-off exit animation */}
      {mascotEntered && (
        <div className="fixed inset-0 z-40 pointer-events-none overflow-hidden">
          {/* Left mascot (Maverick / Appie) */}
          <div
            className="absolute bottom-0 left-0 transition-all duration-1000"
            style={{
              transform: walkOffLeft ? "translateX(-220%)" : "translateX(0)",
              opacity: walkOffLeft ? 0 : 1,
            }}
          >
            <MascotCharacter
              character="maverick"
              state={exitMode ? "cheer" : (mascotLeft !== "idle" ? mascotLeft : "idle")}
              size="lg"
              speech={exitMode ? exitSpeechLeft : mascotLeftSpeech}
            />
          </div>
          {/* Right mascot (Caitlin / Giffy) */}
          <div
            className="absolute bottom-0 right-0 transition-all duration-1000"
            style={{
              transform: walkOffRight ? "translateX(220%)" : "translateX(0)",
              opacity: walkOffRight ? 0 : 1,
            }}
          >
            <MascotCharacter
              character="caitlin"
              state={exitMode ? "cheer" : (mascotRight !== "idle" ? mascotRight : "idle")}
              size="lg"
              speech={exitMode ? exitSpeechRight : mascotRightSpeech}
            />
          </div>
        </div>
      )}
      {/* Walk-off goodbye overlay */}
      {exitMode && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center"
          style={{ background: "rgba(0,0,0,0)", animation: "kcFadeOverlay 0.8s ease-in 2s forwards", pointerEvents: "none" }}
        >
          <style>{`
            @keyframes kcFadeOverlay { from { background: rgba(0,0,0,0); } to { background: rgba(0,0,0,0.88); } }
            @keyframes kcFadeIn { from { opacity: 0; transform: scale(0.8); } to { opacity: 1; transform: scale(1); } }
          `}</style>
          <div style={{ opacity: 0, animation: "kcFadeIn 0.5s ease-out 2.4s forwards", textAlign: "center" }}>
            <div style={{ fontSize: 64, marginBottom: 12 }}>👋</div>
            <p style={{ color: "white", fontFamily: "Oswald, sans-serif", fontSize: 32, fontWeight: 900, letterSpacing: 2 }}>SEE YOU NEXT TIME!</p>
            <p style={{ color: "#fbbf24", fontWeight: 700, fontSize: 18, marginTop: 8 }}>{kidName} • {credits} Credits Saved ⚡</p>
          </div>
        </div>
      )}

      {/* Scoreboard header */}
      <Scoreboard
        kidName={kidName} kidAvatar={kidAvatar} credits={credits}
        myCards={myCards.length} referrals={referrals} loginStreak={loginStreak}
        currentLevel={currentLevel} wishListCount={wishList.length}
        onExit={handleExitKidsCorner}
      />
      {/* Play timer bar */}
      <div className="bg-black/60 border-b border-white/5 px-4 py-1.5 flex items-center gap-3">
        <Clock className="w-3.5 h-3.5 text-white/40" />
        <div className="flex-1 bg-white/10 rounded-full h-2 overflow-hidden">
          <div
            className="h-2 rounded-full transition-all duration-1000"
            style={{
              width: `${(remainingSeconds / 3600) * 100}%`,
              background: remainingSeconds > 1200 ? "linear-gradient(90deg, #22c55e, #16a34a)" : remainingSeconds > 300 ? "linear-gradient(90deg, #f59e0b, #d97706)" : "linear-gradient(90deg, #ef4444, #dc2626)"
            }}
          />
        </div>
        <span className="text-white/50 text-[10px] font-bold tabular-nums">
          {Math.floor(remainingSeconds / 60)}:{String(remainingSeconds % 60).padStart(2, "0")} left
        </span>
      </div>

      {/* Moto ticker */}
      <div className="bg-gradient-to-r from-yellow-500 via-orange-500 to-red-500 overflow-hidden" style={{ height: 32 }}>
        <div className="flex items-center h-full">
          <div className="flex-shrink-0 bg-black/40 px-3 h-full flex items-center">
            <span className="text-white font-black text-[10px] uppercase tracking-widest">🏆 SCO Kids</span>
          </div>
          <div className="flex items-center gap-8 px-4 animate-marquee whitespace-nowrap">
            {["🎯 Collect cards to level up!", "🔥 Daily login = bonus credits!", "👥 Invite friends for big rewards!", "🏆 Reach Hall of Fame for a FREE real card!", "⭐ BGS 10 = Gem Mint — the perfect card!", "🎰 Spin the wheel for big wins!", "📚 Answer trivia to earn credits!", "❤️ Add cards to your wish list — parents can see!", "🏪 Browse 100 real house cards in the showcase!"].map((msg, i) => (
              <span key={i} className="text-white font-bold text-xs">{msg}</span>
            ))}
          </div>
        </div>
      </div>

      {/* Main content: arcade + level tracker */}
      <div className="container py-6 max-w-6xl">
        <div className="flex gap-6">

          {/* ── Left: Arcade Room ── */}
          <div className="flex-1 min-w-0">
            {/* Welcome banner */}
            <div className="relative rounded-3xl overflow-hidden mb-6 p-6" style={{ background: "linear-gradient(135deg, #1a0a2e, #0f1a3e)" }}>
              <div className="absolute inset-0 opacity-5" style={{ backgroundImage: "repeating-linear-gradient(45deg, #fbbf24 0px, #fbbf24 1px, transparent 1px, transparent 10px)" }} />
              <div className="relative z-10 flex items-center justify-between flex-wrap gap-4">
                <div>
                  <p className="text-yellow-400/70 text-xs font-black uppercase tracking-widest">Welcome to the</p>
                  <h1 className="text-white font-black text-3xl leading-tight" style={{ fontFamily: "Oswald, sans-serif" }}>ARCADE ROOM</h1>
                  <p className="text-white/50 text-sm mt-1">Hover over a game to preview · Click to play</p>
                </div>
                <div className="flex items-center gap-3">
                  <div className="text-center bg-white/5 rounded-2xl px-4 py-2 border border-white/10">
                    <p className="text-yellow-400 font-black text-2xl leading-none">{credits}</p>
                    <p className="text-white/40 text-[10px] uppercase">Credits</p>
                  </div>
                  {spinX2Active && (
                    <div className="text-center bg-orange-500/10 rounded-2xl px-4 py-2 border border-orange-500/30 animate-pulse">
                      <p className="text-orange-400 font-black text-lg leading-none">×2</p>
                      <p className="text-white/40 text-[10px] uppercase">Active!</p>
                    </div>
                  )}
                  {freePulls > 0 && (
                    <div className="text-center bg-green-500/10 rounded-2xl px-4 py-2 border border-green-500/30">
                      <p className="text-green-400 font-black text-2xl leading-none">{freePulls}</p>
                      <p className="text-white/40 text-[10px] uppercase">Free Pulls</p>
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Arcade cabinet grid */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
              {GAMES.map(game => (
                <ArcadeCabinet key={game.id} game={game} onPlay={() => setActiveGame(game.id)} />
              ))}
            </div>

            {/* Wish list quick preview */}
            {wishList.length > 0 && (
              <div className="mt-6 bg-pink-500/5 border border-pink-500/20 rounded-3xl p-5">
                <div className="flex items-center justify-between mb-3">
                  <p className="text-white font-black text-base">❤️ My Wish List</p>
                  <button onClick={() => setActiveGame("wishlist")} className="text-pink-400 text-xs font-bold hover:text-pink-300 flex items-center gap-1">View All <ChevronRight className="w-3 h-3" /></button>
                </div>
                <div className="flex gap-2 overflow-x-auto pb-1" style={{ scrollbarWidth: "none" }}>
                  {wishList.map((card) => (
                    <div key={card.id} className="flex-shrink-0 w-14 rounded-xl overflow-hidden border border-pink-500/30 shadow-lg">
                      <img src={card.cdnImageUrl || card.ebayImageUrl} alt={card.player}
                        className="w-full h-20 object-cover"
                        onError={e => { (e.target as HTMLImageElement).src = card.ebayImageUrl; }} />
                    </div>
                  ))}
                  {wishList.length < 5 && (
                    <button onClick={() => setActiveGame("showcase")} className="flex-shrink-0 w-14 h-20 rounded-xl border-2 border-dashed border-pink-500/30 flex items-center justify-center text-pink-400/50 hover:border-pink-400/60 hover:text-pink-400 transition-all">
                      <span className="text-xl">+</span>
                    </button>
                  )}
                </div>
                <p className="text-white/30 text-[10px] mt-2">💜 Your parents can see this list in Parents Corner</p>
              </div>
            )}

            {/* My Cards mini-display */}
            {myCards.length > 0 && (
              <div className="mt-4 bg-white/5 border border-white/10 rounded-3xl p-5">
                <div className="flex items-center justify-between mb-3">
                  <p className="text-white font-black text-base">🎴 My Latest Cards</p>
                  <button onClick={() => setActiveGame("collection")} className="text-yellow-400 text-xs font-bold hover:text-yellow-300 flex items-center gap-1">View All <ChevronRight className="w-3 h-3" /></button>
                </div>
                <div className="flex gap-2 overflow-x-auto pb-1" style={{ scrollbarWidth: "none" }}>
                  {[...myCards].reverse().slice(0, 8).map((card, i) => {
                    const rarity = card.rarity ?? "common";
                    const sportEmoji = card.sport === "basketball" ? "🏀" : card.sport === "baseball" ? "⚾" : card.sport === "football" ? "🏈" : card.sport === "soccer" ? "⚽" : card.sport === "hockey" ? "🏒" : "🎴";
                    return (
                      <div key={i} className="flex-shrink-0 w-14 h-20 rounded-xl overflow-hidden border shadow-lg relative"
                        style={{ borderColor: rarity === "legendary" ? "#fbbf24" : rarity === "epic" ? "#a855f7" : rarity === "rare" ? "#3b82f6" : "rgba(255,255,255,0.15)" }}>
                        {card.frontImageUrl ? (
                          <img src={card.frontImageUrl} alt={card.playerName || "card"} className="w-full h-full object-cover" />
                        ) : (
                          <div className="w-full h-full flex flex-col items-center justify-center gap-0.5" style={{ background: "linear-gradient(135deg, #1e3a5f, #0f2040)" }}>
                            <span className="text-lg">{sportEmoji}</span>
                            <span className="text-white/60 text-[7px] text-center px-0.5 leading-tight">{(card.playerName || "?").split(" ").pop()}</span>
                          </div>
                        )}
                        <div className="absolute bottom-0.5 right-0.5 text-[9px]">{RARITY[rarity].emoji}</div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
          </div>

          {/* ── Right: Level Tracker (sticky) ── */}
          <div className="w-56 flex-shrink-0 hidden lg:block">
            <div className="sticky top-32">
              <p className="text-white/50 font-black text-[10px] uppercase tracking-widest mb-3 flex items-center gap-1"><Trophy className="w-3 h-3 text-yellow-400" /> Level Tracker</p>
              <LevelTracker myCards={myCards.length} referrals={referrals} currentLevel={currentLevel} nextLevel={nextLevel} />
            </div>
          </div>
        </div>
      </div>

      {/* ── Game Windows ── */}
      {activeGame === "racer" && (
        <GameWindow title="🏎️ Card Racer — Collect Cards, Dodge Obstacles!" onClose={() => setActiveGame(null)}>
          <CardRacer onCreditsEarned={(n) => { setCredits(c => c + n); if (n > 0) toast.success(`🏎️ Race done! +${n} credits!`); }} />
        </GameWindow>
      )}

      {activeGame === "pull" && (
        <GameWindow title="🎴 Card Pull" onClose={() => setActiveGame(null)}>
          <div className="flex flex-col items-center gap-5 py-4">
            <div className="text-center">
              <div className="text-6xl mb-3 animate-bounce">🎴</div>
              <h2 className="text-white font-black text-2xl" style={{ fontFamily: "Oswald, sans-serif" }}>CARD PULL</h2>
              <p className="text-white/60 text-sm mt-1">Pull a random card from the pack!</p>
            </div>
            <div className="flex items-center gap-4">
              <div className="text-center bg-white/5 rounded-2xl px-5 py-3 border border-white/10">
                <p className="text-yellow-400 font-black text-2xl">{credits}</p>
                <p className="text-white/40 text-xs">Credits</p>
              </div>
              {freePulls > 0 && (
                <div className="text-center bg-green-500/10 rounded-2xl px-5 py-3 border border-green-500/30">
                  <p className="text-green-400 font-black text-2xl">{freePulls}</p>
                  <p className="text-white/40 text-xs">Free Pulls</p>
                </div>
              )}
            </div>
            <div className="grid grid-cols-2 gap-3 w-full max-w-xs">
              <Button onClick={() => doCardPull(false)} disabled={credits < 10 && freePulls === 0}
                className="bg-gradient-to-r from-yellow-400 to-orange-500 text-black font-black py-4 rounded-2xl hover:scale-105 transition-all">
                {freePulls > 0 ? "🎴 Free Pull!" : "🎴 Pull (10 credits)"}
              </Button>
              <Button onClick={() => doCardPull(true)} disabled={credits < 50}
                className="bg-gradient-to-r from-yellow-300 via-amber-400 to-yellow-600 text-black font-black py-4 rounded-2xl hover:scale-105 transition-all">
                👑 Legendary (50 credits)
              </Button>
            </div>
            <div className="w-full max-w-xs space-y-2">
              {[{ r: "legendary", w: "2%", emoji: "👑" }, { r: "epic", w: "5%", emoji: "💎" }, { r: "rare", w: "8%", emoji: "⭐" }, { r: "uncommon", w: "15%", emoji: "🌟" }, { r: "common", w: "70%", emoji: "✨" }].map(row => (
                <div key={row.r} className="flex items-center gap-2">
                  <span className="text-sm w-5">{row.emoji}</span>
                  <span className="text-white/60 text-xs w-20 capitalize">{row.r}</span>
                  <div className="flex-1 bg-white/10 rounded-full h-2"><div className="h-2 rounded-full bg-gradient-to-r from-yellow-400 to-orange-500" style={{ width: row.w }} /></div>
                  <span className="text-white/40 text-xs w-8 text-right">{row.w}</span>
                </div>
              ))}
            </div>
          </div>
        </GameWindow>
      )}

      {activeGame === "trivia" && (
        <GameWindow title="🧠 Sports Trivia" onClose={() => setActiveGame(null)}>
          <div className="space-y-4 py-2">
            <div className="flex items-center justify-between">
              <Badge className="bg-blue-500/20 text-blue-300 border-blue-500/30 font-black">Question {triviaIdx + 1} of {TRIVIA.length}</Badge>
              <Badge className="bg-yellow-400/20 text-yellow-400 border-yellow-400/30 font-black">+{TRIVIA[triviaIdx].credits} credits</Badge>
            </div>
            <p className="text-white font-black text-xl leading-tight">{TRIVIA[triviaIdx].q}</p>
            <div className="grid grid-cols-2 gap-3">
              {TRIVIA[triviaIdx].choices.map(choice => (
                <button key={choice} onClick={() => answerTrivia(choice)} disabled={triviaAnswered}
                  className={`py-3 px-4 rounded-2xl font-bold text-sm transition-all border-2 ${triviaAnswered ? choice === TRIVIA[triviaIdx].answer ? "bg-green-500/30 border-green-400 text-green-300" : "bg-white/5 border-white/10 text-white/40" : "bg-white/10 border-white/20 text-white hover:bg-white/20 hover:border-white/40 hover:scale-105"}`}>
                  {choice}
                </button>
              ))}
            </div>
            {triviaAnswered && (
              <div className={`rounded-2xl p-4 border-2 ${triviaCorrect ? "bg-green-500/20 border-green-400/50" : "bg-red-500/20 border-red-400/50"}`}>
                <p className={`font-black text-lg ${triviaCorrect ? "text-green-400" : "text-red-400"}`}>{triviaCorrect ? `✅ Correct! +${TRIVIA[triviaIdx].credits} credits!` : "❌ Not quite!"}</p>
                <p className="text-white/70 text-sm mt-1 italic">💡 {TRIVIA[triviaIdx].fact}</p>
                <Button onClick={() => { setTriviaIdx(i => (i + 1) % TRIVIA.length); setTriviaAnswered(false); setTriviaCorrect(false); }} className="mt-3 bg-yellow-400 text-black font-black rounded-xl hover:bg-yellow-300">Next Question →</Button>
              </div>
            )}
          </div>
        </GameWindow>
      )}

      {activeGame === "showcase" && (
        <GameWindow title="🏪 Card Showcase — 100 Real House Cards" onClose={() => setActiveGame(null)} wide>
          <KidsShowcase
            credits={credits}
            wishList={wishList}
            onAddToWishList={addToWishList}
            onRemoveFromWishList={removeFromWishList}
          />
        </GameWindow>
      )}

      {activeGame === "wishlist" && (
        <GameWindow title="❤️ My Wish List" onClose={() => setActiveGame(null)}>
          <WishListPanel wishList={wishList} onRemove={removeFromWishList} />
        </GameWindow>
      )}

      {activeGame === "collection" && (
        <GameWindow title="📦 My Card Collection" onClose={() => setActiveGame(null)}>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <p className="text-white font-black text-lg">{kidName}'s Collection</p>
              <Badge className="bg-yellow-400/20 text-yellow-400 border-yellow-400/30 font-black">{myCards.length} cards</Badge>
            </div>
            {myCards.length === 0 ? (
              <div className="text-center py-12">
                <div className="text-5xl mb-3">📦</div>
                <p className="text-white/60 font-bold">No cards yet!</p>
                <p className="text-white/40 text-sm mt-1">Pull some cards to start your collection</p>
              </div>
            ) : (
              <div className="grid grid-cols-3 sm:grid-cols-4 gap-3">
                {myCards.map((card, i) => {
                  const rarity = card.rarity ?? "common";
                  const sportEmoji = card.sport === "basketball" ? "🏀" : card.sport === "baseball" ? "⚾" : card.sport === "football" ? "🏈" : card.sport === "soccer" ? "⚽" : card.sport === "hockey" ? "🏒" : "🎴";
                  return (
                    <div key={i} className="rounded-2xl overflow-hidden border shadow-lg relative" style={{ minHeight: 120, borderColor: rarity === "legendary" ? "#fbbf24" : rarity === "epic" ? "#a855f7" : rarity === "rare" ? "#3b82f6" : "rgba(255,255,255,0.15)" }}>
                      {card.frontImageUrl ? (
                        <img src={card.frontImageUrl} alt={card.playerName || "card"} className="w-full h-full object-cover" style={{ minHeight: 120 }} />
                      ) : (
                        <div className="w-full flex flex-col items-center justify-center gap-1 p-3" style={{ minHeight: 120, background: "linear-gradient(135deg, #1e3a5f, #0f2040)" }}>
                          <span className="text-3xl">{sportEmoji}</span>
                          <span className="text-white font-black text-[10px] text-center leading-tight">{card.playerName || "Mystery Card"}</span>
                          <span className="text-white/50 text-[9px]">{card.year || ""}</span>
                        </div>
                      )}
                      <div className="absolute bottom-1 right-1 text-sm">{RARITY[rarity].emoji}</div>
                      {rarity === "legendary" && <div className="absolute top-1 left-1 text-[9px] bg-yellow-400 text-black font-black rounded px-1">LEGEND</div>}
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </GameWindow>
      )}

      {/* CARD BATTLE */}
      {activeGame === "gametime" && (
        <GameWindow title="🃏 CARD BATTLE" onClose={() => setActiveGame(null)} wide>
          <GameTime
            kidCredits={credits}
            onCreditsChange={(delta) => setCredits(c => Math.max(0, c + delta))}
            onBack={() => setActiveGame(null)}
          />
        </GameWindow>
      )}

      {/* Go Fish */}
      {activeGame === "gofish" && (
        <GameWindow title="🐟 Go Fish" onClose={() => setActiveGame(null)} wide>
          <GoFish
            kidName={kidName}
            onEarnCredits={(amt) => { setCredits(c => c + amt); toast.success(`🐟 Go Fish win! +${amt} credits!`); }}
            onClose={() => setActiveGame(null)}
          />
        </GameWindow>
      )}

      {/* Rock Paper Scissors */}
      {activeGame === "rps" && (
        <GameWindow title="✊ Rock Paper Scissors" onClose={() => setActiveGame(null)}>
          <RockPaperScissors
            kidName={kidName}
            onEarnCredits={(amt) => { setCredits(c => c + amt); toast.success(`✊ RPS win! +${amt} credits!`); }}
            onClose={() => setActiveGame(null)}
          />
        </GameWindow>
      )}

      {/* Heads or Tails */}
      {activeGame === "headsortails" && (
        <GameWindow title="🪙 Heads or Tails" onClose={() => setActiveGame(null)}>
          <HeadsOrTails
            kidName={kidName}
            onEarnCredits={(amt) => { setCredits(c => c + amt); toast.success(`🪙 Coin flip win! +${amt} credits!`); }}
            onClose={() => setActiveGame(null)}
          />
        </GameWindow>
      )}

      {/* Trade Center */}
      {activeGame === "trade" && kidDbId > 0 && (
        <GameWindow title="🔄 Trade Center" onClose={() => setActiveGame(null)} wide>
          <KidsTradingCenter kidId={kidDbId} kidName={kidName} />
        </GameWindow>
      )}
      {activeGame === "trade" && kidDbId === 0 && (
        <GameWindow title="🔄 Trade Center" onClose={() => setActiveGame(null)}>
          <div className="text-center py-12">
            <div className="text-5xl mb-3">🔄</div>
            <p className="text-white font-black text-lg">Loading your profile...</p>
            <p className="text-white/50 text-sm mt-2">Please wait a moment and try again</p>
          </div>
        </GameWindow>
      )}

      {/* 1-hour timeout overlay */}
      {isTimedOut && (
        <div className="fixed inset-0 z-50 flex items-center justify-center" style={{ background: "rgba(0,0,0,0.92)" }}>
          <div className="text-center max-w-sm mx-4">
            <div className="text-8xl mb-4">⏰</div>
            <h2 className="text-white font-black text-3xl mb-2" style={{ fontFamily: "Oswald, sans-serif" }}>TIME'S UP!</h2>
            <p className="text-white/70 text-lg mb-2">You've played for 1 hour today, {kidName}!</p>
            <p className="text-white/50 text-sm mb-6">Ask a parent to grant you more time, or come back tomorrow for another 25 free credits!</p>
            <div className="flex gap-3 justify-center">
              <div className="text-center bg-white/5 rounded-2xl px-6 py-3 border border-white/10">
                <p className="text-yellow-400 font-black text-2xl">{credits}</p>
                <p className="text-white/40 text-xs">Credits saved</p>
              </div>
              <div className="text-center bg-white/5 rounded-2xl px-6 py-3 border border-white/10">
                <p className="text-blue-400 font-black text-2xl">{myCards.length}</p>
                <p className="text-white/40 text-xs">Cards collected</p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Card Reveal Modal */}
      {pulledCard && <CardReveal card={pulledCard} onClose={() => setPulledCard(null)} />}

      {/* Educational Trivia Pop-up (every 60 seconds) */}
      {kidDbId > 0 && (
        <TriviaPopup
          kidId={kidDbId}
          kidName={kidName}
          intervalSeconds={60}
          onCreditsEarned={(amt) => {
            setCredits(c => c + amt);
            toast.success(`🧠 Trivia bonus! +${amt} credits!`);
          }}
        />
      )}

      {/* Marquee CSS */}
      <style>{`
        @keyframes marquee { from { transform: translateX(0); } to { transform: translateX(-50%); } }
        .animate-marquee { animation: marquee 35s linear infinite; display: inline-flex; }
      `}</style>
    </div>
  );
}
