import { trpc } from "@/lib/trpc";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Label } from "@/components/ui/label";
import {
  LayoutDashboard, Users, ShoppingBag, Gavel, Package, Coins,
  Award, Trash2, Pencil, XCircle, TrendingUp, Link2, Shield, Tag, Dice5,
  ExternalLink, RefreshCw, CheckCircle, Clock, Truck, Download, Printer, PackagePlus, Layers, AlertTriangle
} from "lucide-react";
import { useState } from "react";
import { InlineEdit, InlineGradeEdit } from "@/components/InlineEdit";
import { toast } from "sonner";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { CardProfileDrawer } from "@/components/CardProfileDrawer";
import { CollectionItemDrawer } from "@/components/CollectionItemDrawer";
import { BestOfferSavingsChart } from "@/components/BestOfferSavingsChart";
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip as RechartsTooltip,
  ResponsiveContainer, Legend,
} from "recharts";
import { SlabFrame } from "@/components/SlabFrame";

// --- Reusable admin table wrapper ----------------------------------------------
function AdminTable({ headers, children }: { headers: string[]; children: React.ReactNode }) {
  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm">
        <thead>
          <tr className="border-b border-white/10">
            {headers.map(h => (
              <th key={h} className="text-left p-2 text-white/40 font-medium text-xs uppercase tracking-wide">{h}</th>
            ))}
          </tr>
        </thead>
        <tbody>{children}</tbody>
      </table>
    </div>
  );
}

function TR({ children, className = "", onClick }: { children: React.ReactNode; className?: string; onClick?: () => void }) {
  return <tr className={`border-b border-white/5 hover:bg-white/5 transition-colors ${className}`} onClick={onClick}>{children}</tr>;
}

function TD({ children, className = "", onClick }: { children: React.ReactNode; className?: string; onClick?: (e: React.MouseEvent) => void }) {
  return <td className={`p-2 text-white/80 ${className}`} onClick={onClick}>{children}</td>;
}

// --- Main component ------------------------------------------------------------
export default function Admin() {
  const { isAuthenticated, user } = useAuth();
  const [creditEmail, setCreditEmail] = useState("");
  const [creditAmount, setCreditAmount] = useState("");
  const [gradeCardId, setGradeCardId] = useState("");
  const [newGrade, setNewGrade] = useState("");
  const [templateName, setTemplateName] = useState("");
  const [templateSubject, setTemplateSubject] = useState("");
  const [templateBody, setTemplateBody] = useState("");

  const { data: stats } = trpc.admin.stats.useQuery(undefined, { enabled: isAuthenticated && user?.role === "admin" });
  const { data: inventorySummary } = trpc.admin.inventorySummary.useQuery(undefined, { enabled: isAuthenticated && user?.role === "admin" });
  const [inventoryDrillDown, setInventoryDrillDown] = useState<{ source: "house" | "ebay"; status: string } | null>(null);
  const { data: drillDownCards, isLoading: drillDownLoading } = trpc.admin.inventoryCardsByStatus.useQuery(
    inventoryDrillDown ?? { source: "house", status: "active" },
    { enabled: !!inventoryDrillDown && isAuthenticated && user?.role === "admin" }
  );
  const { data: users } = trpc.admin.listUsers.useQuery(undefined, { enabled: isAuthenticated && user?.role === "admin" });
  const [profileCardId, setProfileCardId] = useState<number | null>(null);
  const [profileCollectionId, setProfileCollectionId] = useState<number | null>(null);
  const [cardSourceFilter, setCardSourceFilter] = useState<"all" | "house" | "ebay">("all");
  const [cardSportFilter, setCardSportFilter] = useState<string>("all");
  const [cardSearchQuery, setCardSearchQuery] = useState("");
  const { data: cards, refetch: refetchCards } = trpc.admin.listAllCards.useQuery(
    { limit: 500, source: cardSourceFilter, sport: cardSportFilter !== "all" ? cardSportFilter : undefined, search: cardSearchQuery || undefined },
    { enabled: isAuthenticated && user?.role === "admin" }
  );
  const { data: collectionItems, refetch: refetchCollections } = trpc.admin.listAllCollections.useQuery({ limit: 200 }, { enabled: isAuthenticated && user?.role === "admin" });
  const { data: orders } = trpc.admin.listAllOrders.useQuery(undefined, { enabled: isAuthenticated && user?.role === "admin" });
  const { data: auctions } = trpc.admin.listAllAuctions.useQuery(undefined, { enabled: isAuthenticated && user?.role === "admin" });
  const { data: affiliates } = trpc.admin.listAffiliates.useQuery(undefined, { enabled: isAuthenticated && user?.role === "admin" });
  const { data: vaultedCards, refetch: refetchVault } = trpc.admin.listVaultedCards.useQuery(undefined, { enabled: isAuthenticated && user?.role === "admin" });
  const updateVaultStatus = trpc.admin.updateVaultStatus.useMutation({ onSuccess: () => { toast.success("Vault status updated"); refetchVault(); } });
  const { data: templates, refetch: refetchTemplates } = trpc.admin.listTemplates.useQuery(undefined, { enabled: isAuthenticated && user?.role === "admin" });

  const addCredits = trpc.admin.adminAddCredits.useMutation({ onSuccess: () => { toast.success("Credits added!"); setCreditEmail(""); setCreditAmount(""); } });
  const adjustGrade = trpc.admin.adjustGrade.useMutation({ onSuccess: () => { toast.success("Grade adjusted!"); setGradeCardId(""); setNewGrade(""); } });
  const deleteCard = trpc.admin.deleteCardAdmin.useMutation({ onSuccess: () => toast.success("Card deleted") });
  const adminUpdateCard = trpc.admin.adminUpdateCard.useMutation({
    onSuccess: () => toast.success("Updated!"),
    onError: (e) => toast.error(e.message),
  });
  const deleteCollectionItem = trpc.admin.deleteCollectionAdmin.useMutation({ onSuccess: () => { toast.success("Collection item deleted"); refetchCollections(); } });
  const adjustCollectionGrade = trpc.admin.adjustCollectionGrade.useMutation({ onSuccess: (d) => { toast.success(`Grade updated${d.autoPrice ? ` — SCP price: $${d.autoPrice}` : ""}`); refetchCollections(); } });
  const updateOrderStatus = trpc.admin.updateOrderStatus.useMutation({ onSuccess: () => toast.success("Status updated") });
  const updateOrderTracking = trpc.admin.adminUpdateOrderTracking.useMutation({ onSuccess: () => toast.success("Tracking saved") });
  const releaseFunds = trpc.admin.adminReleaseFunds.useMutation({ onSuccess: () => { toast.success("Funds released to seller"); } });
  const [labelModalOrder, setLabelModalOrder] = useState<{ id: number; buyerEmail: string; cardTitle: string; shippingAddress: string | null; totalAmount: string | null } | null>(null);
  const [batchResults, setBatchResults] = useState<null | { results: Array<{ orderId: number; cardTitle: string; success: boolean; trackingNumber?: string; labelUrl?: string; rate?: string; error?: string }>; succeeded: number; failed: number; total: number }>(null);
  const [showBatchResults, setShowBatchResults] = useState(false);
  const createLabel = trpc.admin.adminCreateShippingLabel.useMutation({
    onSuccess: (data) => {
      toast.success(`Label created! Tracking: ${data.trackingNumber} · Cost: $${data.rate}`);
      setLabelModalOrder(null);
    },
    onError: (e) => toast.error(`Label failed: ${e.message}`),
  });
  const batchCreateLabels = trpc.admin.adminBatchCreateLabels.useMutation({
    onSuccess: (data) => {
      setBatchResults(data);
      setShowBatchResults(true);
      if (data.succeeded > 0) toast.success(`${data.succeeded} label${data.succeeded !== 1 ? 's' : ''} created!`);
      if (data.failed > 0) toast.error(`${data.failed} order${data.failed !== 1 ? 's' : ''} failed — check results`);
      if (data.total === 0) toast.info('No pending orders without labels found.');
    },
    onError: (e) => toast.error(`Batch failed: ${e.message}`),
  });
  const cancelAuction = trpc.admin.cancelAuction.useMutation({ onSuccess: () => toast.success("Auction cancelled") });
  const updateRole = trpc.admin.setUserRole.useMutation({ onSuccess: () => toast.success("Role updated") });
  const upsertTemplate = trpc.admin.upsertTemplate.useMutation({ onSuccess: () => { toast.success("Template saved!"); setTemplateName(""); setTemplateSubject(""); setTemplateBody(""); refetchTemplates(); } });
  const deleteTemplate = trpc.admin.deleteTemplate.useMutation({ onSuccess: () => { toast.success("Deleted"); refetchTemplates(); } });

  if (!isAuthenticated || user?.role !== "admin") {
    return (
      <div className="min-h-screen bg-[#0a1628] flex items-center justify-center">
        <div className="text-center space-y-4">
          <Shield className="w-16 h-16 text-white/20 mx-auto" />
          <h2 className="text-2xl font-bold text-white">Admin Access Required</h2>
          <p className="text-white/50">This area is restricted to platform administrators.</p>
          {!isAuthenticated && (
            <a href={getLoginUrl()} className="inline-block bg-[#C41E3A] hover:bg-[#a01830] text-white px-6 py-2 rounded-lg font-medium transition-colors">Sign In</a>
          )}
        </div>
      </div>
    );
  }

  const statCards = [
    { label: "Users",              value: stats?.users ?? 0,                          icon: Users,      color: "text-blue-400" },
    { label: "House Collection",   value: stats?.cards ?? 0,                          icon: ShoppingBag,color: "text-green-400" },
    { label: "Active Auctions",    value: stats?.activeAuctions ?? 0,                 icon: Gavel,      color: "text-yellow-400" },
    { label: "Total Orders",       value: stats?.orders ?? 0,                         icon: Package,    color: "text-purple-400" },
    { label: "Platform Revenue",   value: `$${(stats?.totalRevenue ?? 0).toFixed(2)}`,icon: TrendingUp, color: "text-[#C41E3A]" },
    { label: "House",              value: stats?.cardsByStatus?.["bank"] ?? 0,        icon: Link2,      color: "text-indigo-400" },
    { label: "Listed/Marketplace", value: stats?.cardsByStatus?.["active"] ?? 0,      icon: Tag,        color: "text-emerald-400" },
    { label: "In Auction",         value: stats?.cardsByStatus?.["auction"] ?? 0,     icon: Gavel,      color: "text-orange-400" },
    { label: "Casino",             value: stats?.cardsByStatus?.["casino"] ?? 0,      icon: Dice5,      color: "text-yellow-400" },
    { label: "Sold",               value: stats?.cardsByStatus?.["sold"] ?? 0,        icon: Package,    color: "text-blue-400" },
  ];

  // Parse shipping address from stored JSON or plain string
  const parsedAddr = (() => {
    if (!labelModalOrder?.shippingAddress) return null;
    try { return JSON.parse(labelModalOrder.shippingAddress); } catch { return null; }
  })();

  return (
    <div className="min-h-screen bg-[#0a1628] pb-20">
      {/* Create Label Modal */}
      {labelModalOrder && (
        <CreateLabelModal
          order={labelModalOrder}
          parsedAddr={parsedAddr}
          onClose={() => setLabelModalOrder(null)}
          onSubmit={(fields) => createLabel.mutate({ orderId: labelModalOrder.id, ...fields })}
          isPending={createLabel.isPending}
        />
      )}
      {/* Batch Results Modal */}
      {showBatchResults && batchResults && (
        <Dialog open onOpenChange={() => setShowBatchResults(false)}>
          <DialogContent className="bg-[#0d1f3c] border border-white/10 text-white max-w-2xl max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="text-white flex items-center gap-2">
                <PackagePlus className="w-5 h-5 text-blue-400" />
                Batch Label Results
              </DialogTitle>
            </DialogHeader>
            <div className="grid grid-cols-3 gap-3 my-3">
              <div className="bg-green-500/10 border border-green-500/20 rounded-lg p-3 text-center">
                <div className="text-2xl font-black text-green-400">{batchResults.succeeded}</div>
                <div className="text-xs text-white/50">Labels Created</div>
              </div>
              <div className="bg-red-500/10 border border-red-500/20 rounded-lg p-3 text-center">
                <div className="text-2xl font-black text-red-400">{batchResults.failed}</div>
                <div className="text-xs text-white/50">Failed</div>
              </div>
              <div className="bg-white/5 border border-white/10 rounded-lg p-3 text-center">
                <div className="text-2xl font-black text-white">{batchResults.total}</div>
                <div className="text-xs text-white/50">Total Processed</div>
              </div>
            </div>
            <div className="space-y-1.5 max-h-80 overflow-y-auto">
              {batchResults.results.map(r => (
                <div key={r.orderId} className={`flex items-center justify-between p-2 rounded-lg text-xs border ${
                  r.success ? 'bg-green-500/5 border-green-500/20' : 'bg-red-500/5 border-red-500/20'
                }`}>
                  <div className="flex items-center gap-2">
                    {r.success
                      ? <CheckCircle className="w-3.5 h-3.5 text-green-400 shrink-0" />
                      : <XCircle className="w-3.5 h-3.5 text-red-400 shrink-0" />}
                    <span className="text-white/70">#{r.orderId}</span>
                    <span className="text-white/50 truncate max-w-[180px]">{r.cardTitle}</span>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    {r.success && r.trackingNumber && (
                      <span className="text-blue-300 font-mono">{r.trackingNumber}</span>
                    )}
                    {r.success && r.rate && (
                      <span className="text-green-400">${r.rate}</span>
                    )}
                    {r.success && r.labelUrl && (
                      <a href={r.labelUrl} target="_blank" rel="noreferrer"
                        className="text-blue-400 hover:text-blue-300 flex items-center gap-1">
                        <Download className="w-3 h-3" />PDF
                      </a>
                    )}
                    {!r.success && (
                      <span className="text-red-400">{r.error}</span>
                    )}
                  </div>
                </div>
              ))}
              {batchResults.total === 0 && (
                <p className="text-white/40 text-sm text-center py-4">No pending orders without labels were found.</p>
              )}
            </div>
            <DialogFooter>
              <Button onClick={() => setShowBatchResults(false)} className="bg-[#C41E3A] hover:bg-[#a01830] text-white">Done</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
      {/* Header */}
      <div className="bg-[#0d1f3c] border-b border-white/10 py-4">
        <div className="max-w-7xl mx-auto px-4 flex items-center gap-3">
          <LayoutDashboard className="w-6 h-6 text-[#C41E3A]" />
          <div>
            <h1 className="text-2xl font-bold text-white" style={{ fontFamily: "Oswald, sans-serif" }}>Admin Dashboard</h1>
            <p className="text-white/40 text-xs">SportsCardsOnline.com — Platform Management</p>
          </div>
          <div className="ml-auto">
            <Badge className="bg-[#C41E3A]/20 text-[#C41E3A] border border-[#C41E3A]/30">Admin</Badge>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-6">
        {/* Stats Row */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 mb-6">
          {statCards.map(({ label, value, icon: Icon, color }) => (
            <div key={label} className="bg-[#0d1f3c] border border-white/10 rounded-xl p-4 text-center">
              <Icon className={`w-5 h-5 mx-auto mb-2 ${color}`} />
              <div className="text-2xl font-black text-white">{value}</div>
              <div className="text-xs text-white/40">{label}</div>
            </div>
          ))}
        </div>

        {/* Inventory Summary Widget */}
        {inventorySummary && (
          <div className="bg-[#0d1f3c] border border-white/10 rounded-xl p-4 mb-6">
            <div className="flex items-center gap-2 mb-4">
              <ShoppingBag className="w-4 h-4 text-[#ffd700]" />
              <h3 className="text-sm font-bold text-white" style={{ fontFamily: "Oswald, sans-serif" }}>INVENTORY BREAKDOWN</h3>
              <span className="ml-auto text-xs text-white/30">{(inventorySummary.house.totalCount + inventorySummary.ebay.totalCount).toLocaleString()} total cards</span>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* House Cards */}
              <div className="bg-[#ffd700]/5 border border-[#ffd700]/20 rounded-lg p-4">
                <div className="flex items-center gap-2 mb-3">
                  <span className="bg-[#ffd700] text-[#0a1628] text-[9px] font-black px-1.5 py-0.5 rounded">SCO</span>
                  <span className="text-sm font-bold text-[#ffd700]">House Cards</span>
                </div>
                <div className="grid grid-cols-3 gap-3 mb-3">
                  <div className="text-center">
                    <div className="text-xl font-black text-white">{inventorySummary.house.totalCount.toLocaleString()}</div>
                    <div className="text-[10px] text-white/40">Total Cards</div>
                  </div>
                  <div className="text-center">
                    <div className="text-xl font-black text-[#ffd700]">${inventorySummary.house.totalValue.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 0 })}</div>
                    <div className="text-[10px] text-white/40">Total Value</div>
                  </div>
                  <div className="text-center">
                    <div className="text-xl font-black text-white">${inventorySummary.house.avgPrice.toFixed(2)}</div>
                    <div className="text-[10px] text-white/40">Avg Price</div>
                  </div>
                </div>
                <div className="space-y-1">
                  {Object.entries(inventorySummary.house.byStatus).sort((a,b) => b[1].count - a[1].count).map(([status, data]) => (
                    <div key={status}
                      className="flex items-center gap-2 cursor-pointer hover:bg-white/5 rounded px-1 py-0.5 transition-colors group"
                      onClick={() => setInventoryDrillDown({ source: "house", status })}
                    >
                      <div className="text-[10px] text-white/50 w-20 capitalize group-hover:text-[#ffd700] transition-colors">{status}</div>
                      <div className="flex-1 bg-white/5 rounded-full h-1.5">
                        <div className="bg-[#ffd700]/60 h-1.5 rounded-full group-hover:bg-[#ffd700] transition-colors" style={{ width: `${inventorySummary.house.totalCount > 0 ? (data.count / inventorySummary.house.totalCount) * 100 : 0}%` }} />
                      </div>
                      <div className="text-[10px] text-white/60 w-8 text-right">{data.count}</div>
                      <div className="text-[10px] text-white/40 w-16 text-right">${data.value.toFixed(0)}</div>
                      <span className="text-[9px] text-white/20 group-hover:text-[#ffd700]/60">›</span>
                    </div>
                  ))}
                </div>
              </div>
              {/* eBay Cards */}
              <div className="bg-blue-500/5 border border-blue-500/20 rounded-lg p-4">
                <div className="flex items-center gap-2 mb-3">
                  <span className="bg-blue-500/70 text-white text-[9px] font-bold px-1.5 py-0.5 rounded">eBay</span>
                  <span className="text-sm font-bold text-blue-400">eBay Imported</span>
                </div>
                <div className="grid grid-cols-3 gap-3 mb-3">
                  <div className="text-center">
                    <div className="text-xl font-black text-white">{inventorySummary.ebay.totalCount.toLocaleString()}</div>
                    <div className="text-[10px] text-white/40">Total Cards</div>
                  </div>
                  <div className="text-center">
                    <div className="text-xl font-black text-blue-400">${inventorySummary.ebay.totalValue.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 0 })}</div>
                    <div className="text-[10px] text-white/40">Total Value</div>
                  </div>
                  <div className="text-center">
                    <div className="text-xl font-black text-white">${inventorySummary.ebay.avgPrice.toFixed(2)}</div>
                    <div className="text-[10px] text-white/40">Avg Price</div>
                  </div>
                </div>
                <div className="space-y-1">
                  {Object.entries(inventorySummary.ebay.byStatus).sort((a,b) => b[1].count - a[1].count).map(([status, data]) => (
                    <div key={status}
                      className="flex items-center gap-2 cursor-pointer hover:bg-white/5 rounded px-1 py-0.5 transition-colors group"
                      onClick={() => setInventoryDrillDown({ source: "ebay", status })}
                    >
                      <div className="text-[10px] text-white/50 w-20 capitalize group-hover:text-blue-400 transition-colors">{status}</div>
                      <div className="flex-1 bg-white/5 rounded-full h-1.5">
                        <div className="bg-blue-400/60 h-1.5 rounded-full group-hover:bg-blue-400 transition-colors" style={{ width: `${inventorySummary.ebay.totalCount > 0 ? (data.count / inventorySummary.ebay.totalCount) * 100 : 0}%` }} />
                      </div>
                      <div className="text-[10px] text-white/60 w-8 text-right">{data.count}</div>
                      <div className="text-[10px] text-white/40 w-16 text-right">${data.value.toFixed(0)}</div>
                      <span className="text-[9px] text-white/20 group-hover:text-blue-400/60">›</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
            {/* Combined bar */}
            {(inventorySummary.house.totalCount + inventorySummary.ebay.totalCount) > 0 && (
              <div className="mt-4">
                <div className="flex justify-between text-[10px] text-white/40 mb-1">
                  <span>House {Math.round((inventorySummary.house.totalCount / (inventorySummary.house.totalCount + inventorySummary.ebay.totalCount)) * 100)}%</span>
                  <span>eBay {Math.round((inventorySummary.ebay.totalCount / (inventorySummary.house.totalCount + inventorySummary.ebay.totalCount)) * 100)}%</span>
                </div>
                <div className="flex h-2 rounded-full overflow-hidden">
                  <div className="bg-[#ffd700]/70" style={{ width: `${(inventorySummary.house.totalCount / (inventorySummary.house.totalCount + inventorySummary.ebay.totalCount)) * 100}%` }} />
                  <div className="bg-blue-400/70 flex-1" />
                </div>
              </div>
            )}
          </div>
        )}
        {/* Inventory Drill-Down Sheet */}
        <Sheet open={!!inventoryDrillDown} onOpenChange={(open) => { if (!open) setInventoryDrillDown(null); }}>
          <SheetContent side="right" className="w-full sm:max-w-2xl bg-[#0d1f3c] border-white/10 text-white overflow-y-auto">
            <SheetHeader className="mb-4">
              <SheetTitle className="text-white flex items-center gap-2">
                {inventoryDrillDown?.source === "house" ? (
                  <span className="bg-[#ffd700] text-[#0a1628] text-[9px] font-black px-1.5 py-0.5 rounded">SCO</span>
                ) : (
                  <span className="bg-blue-500/70 text-white text-[9px] font-bold px-1.5 py-0.5 rounded">eBay</span>
                )}
                <span className="capitalize">{inventoryDrillDown?.status}</span>
                <span className="text-white/40 font-normal text-sm">— {inventoryDrillDown?.source === "house" ? "House" : "eBay Imported"} Cards</span>
              </SheetTitle>
            </SheetHeader>
            {drillDownLoading ? (
              <div className="flex items-center justify-center py-12">
                <RefreshCw className="w-5 h-5 animate-spin text-white/40" />
                <span className="ml-2 text-white/40 text-sm">Loading cards...</span>
              </div>
            ) : !drillDownCards || drillDownCards.length === 0 ? (
              <div className="text-center py-12 text-white/30 text-sm">No cards found for this status.</div>
            ) : (
              <div className="space-y-2">
                <p className="text-xs text-white/30 mb-3">{drillDownCards.length} card{drillDownCards.length !== 1 ? "s" : ""}</p>
                {drillDownCards.map(card => (
                  <div key={card.id}
                    className="flex items-center gap-3 bg-white/5 hover:bg-white/10 rounded-lg p-3 cursor-pointer transition-colors"
                    onClick={() => { setProfileCardId(card.id); setInventoryDrillDown(null); }}
                  >
                    {card.frontImageUrl ? (
                      <img src={card.frontImageUrl} alt={card.title} className="w-10 h-14 object-cover rounded flex-shrink-0" />
                    ) : (
                      <div className="w-10 h-14 bg-white/10 rounded flex-shrink-0 flex items-center justify-center">
                        <ShoppingBag className="w-4 h-4 text-white/20" />
                      </div>
                    )}
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-semibold text-white truncate">{card.title}</div>
                      <div className="text-xs text-white/40">{card.playerName} · {card.year} {card.setName}</div>
                      <div className="flex items-center gap-2 mt-1">
                        {card.aiGrade && <span className="text-[10px] bg-white/10 px-1.5 py-0.5 rounded text-white/60">Grade {card.aiGrade}</span>}
                        {card.sport && <span className="text-[10px] text-white/30 capitalize">{card.sport}</span>}
                      </div>
                    </div>
                    <div className="text-right flex-shrink-0">
                      <div className={`text-sm font-bold ${inventoryDrillDown?.source === "house" ? "text-[#ffd700]" : "text-white"}`}>
                        ${parseFloat(card.price ?? "0").toFixed(2)}
                      </div>
                      {card.marketPrice && <div className="text-[10px] text-emerald-400">Mkt ${parseFloat(card.marketPrice).toFixed(2)}</div>}
                    </div>
                    <span className="text-white/20 text-sm">›</span>
                  </div>
                ))}
              </div>
            )}
          </SheetContent>
        </Sheet>
        {/* Best Offer Savings Chart Widget */}
        <div className="mb-6">
          <BestOfferSavingsChart />
        </div>
        {/* Tabs */}
        <Tabs defaultValue="cards">
          <TabsList className="bg-white/5 border border-white/10 mb-4 flex-wrap h-auto">
            {["cards","house-cards","ebay-cards","collection","vault","orders","disputes","trades","users","auctions","credits","affiliates","templates","fulfillment","best-offer","ebay-import","payouts","blog","settings"].map(t => (
              <TabsTrigger key={t} value={t} className={`data-[state=active]:text-white text-white/60 capitalize ${
                t === "house-cards" ? "data-[state=active]:bg-[#ffd700] data-[state=active]:text-[#0a1628]" :
                t === "ebay-cards" ? "data-[state=active]:bg-blue-600" :
                "data-[state=active]:bg-[#C41E3A]"
              }`}>{t === "house-cards" ? "🏠 House" : t === "ebay-cards" ? "📦 eBay" : t}</TabsTrigger>
            ))}
          </TabsList>

          {/* -- CARDS -- */}
          <TabsContent value="cards">
            <div className="bg-[#0d1f3c] border border-white/10 rounded-xl p-4">
              {/* Filter row 1: Grade adjust */}
              <div className="flex gap-3 mb-3 flex-wrap items-center">
                <Input placeholder="Card ID" value={gradeCardId} onChange={e => setGradeCardId(e.target.value)} className="w-24 h-8 text-xs bg-white/5 border-white/10 text-white placeholder:text-white/30" />
                <Input placeholder="New Grade (e.g. 9.5)" value={newGrade} onChange={e => setNewGrade(e.target.value)} className="w-36 h-8 text-xs bg-white/5 border-white/10 text-white placeholder:text-white/30" />
                <Button size="sm" onClick={() => { if (!gradeCardId || !newGrade) { toast.error("Enter card ID and grade"); return; } adjustGrade.mutate({ cardId: parseInt(gradeCardId), aiGrade: newGrade, aiGradeLabel: newGrade }); }} disabled={adjustGrade.isPending} className="h-8 text-xs bg-[#C41E3A] hover:bg-[#a01830]">
                  <Award className="w-3 h-3 mr-1" /> Adjust Grade
                </Button>
                <span className="text-white/20 text-xs ml-1">|</span>
                <span className="text-white/40 text-xs">{cards?.length ?? 0} cards loaded</span>
              </div>
              {/* Filter row 2: Search + Source + Sport */}
              <div className="flex gap-2 mb-4 flex-wrap items-center">
                <Input
                  placeholder="Search player, title, set..."
                  value={cardSearchQuery}
                  onChange={e => setCardSearchQuery(e.target.value)}
                  className="w-48 h-8 text-xs bg-white/5 border-white/10 text-white placeholder:text-white/30"
                />
                {/* Source filter */}
                <div className="flex items-center gap-1 bg-white/5 rounded-lg p-1">
                  {(["all", "house", "ebay"] as const).map(f => (
                    <button
                      key={f}
                      onClick={() => setCardSourceFilter(f)}
                      className={`text-xs px-2.5 py-1 rounded-md font-medium transition-colors ${
                        cardSourceFilter === f
                          ? f === "house" ? "bg-[#ffd700] text-[#0a1628]" : f === "ebay" ? "bg-blue-500 text-white" : "bg-white/20 text-white"
                          : "text-white/40 hover:text-white"
                      }`}
                    >
                      {f === "all" ? "All" : f === "house" ? "🏠 House" : "📦 eBay"}
                    </button>
                  ))}
                </div>
                {/* Sport filter */}
                <div className="flex items-center gap-1 bg-white/5 rounded-lg p-1">
                  {(["all", "baseball", "basketball", "football", "hockey", "soccer"] as const).map(s => (
                    <button
                      key={s}
                      onClick={() => setCardSportFilter(s)}
                      className={`text-xs px-2 py-1 rounded-md font-medium transition-colors capitalize ${
                        cardSportFilter === s ? "bg-[#C41E3A] text-white" : "text-white/40 hover:text-white"
                      }`}
                    >
                      {s === "all" ? "All Sports" : s}
                    </button>
                  ))}
                </div>
              </div>
              <AdminTable headers={["ID","Card","Seller","Price","Grade","Status",""]}>
                {cards?.map(card => (
                  <TR key={card.id}
                    className="cursor-pointer hover:bg-white/5 transition-colors"
                    onClick={() => setProfileCardId(card.id)}
                  >
                    <TD className="font-mono text-xs text-white/40">{card.id}</TD>
                    <TD>
                      <div className="flex items-center gap-2">
                        {card.frontImageUrl && <img src={card.frontImageUrl} alt="" className="w-7 h-9 object-cover rounded" />}
                        <div>
                          <div className="font-medium text-xs text-white line-clamp-1 flex items-center gap-1">
                            {card.title}
                            {card.isMainStore
                              ? <span className="shrink-0 bg-[#ffd700] text-[#0a1628] text-[7px] font-black px-1 py-0.5 rounded leading-none">SCO</span>
                              : <span className="shrink-0 bg-blue-500/70 text-white text-[7px] font-bold px-1 py-0.5 rounded leading-none">eBay</span>
                            }
                          </div>
                          <div className="text-xs text-white/40">{card.playerName}</div>
                        </div>
                      </div>
                    </TD>
                    <TD className="text-xs text-white/40">{card.sellerEmail}</TD>
                    <TD className="font-semibold text-green-400 text-xs">${parseFloat(card.price ?? "0").toFixed(2)}</TD>
                    <TD className="text-xs text-white/60">{card.aiGrade ? `SCG ${parseFloat(card.aiGrade).toFixed(1)}` : "Raw"}</TD>
                    <TD>
                      <Badge className={`text-xs capitalize ${
                        card.status === "active" ? "bg-green-500/20 text-green-400 border-green-500/30" :
                        card.status === "sold" ? "bg-blue-500/20 text-blue-400 border-blue-500/30" :
                        "bg-white/10 text-white/40 border-white/10"
                      }`}>{card.status}</Badge>
                    </TD>
                    <TD onClick={e => e.stopPropagation()}>
                      <Button size="sm" variant="ghost" className="text-red-400 h-7 px-2 hover:bg-red-500/10" onClick={() => { if (!confirm("Delete this card?")) return; deleteCard.mutate({ cardId: card.id }); }}>
                        <Trash2 className="w-3 h-3" />
                      </Button>
                    </TD>
                  </TR>
                ))}
              </AdminTable>
            </div>
            <CardProfileDrawer
              cardId={profileCardId}
              onClose={() => setProfileCardId(null)}
              onDeleted={() => { setProfileCardId(null); refetchCards(); }}
              onUpdated={() => refetchCards()}
            />
          </TabsContent>

          {/* -- HOUSE CARDS -- */}
          <TabsContent value="house-cards">
            <HouseCardsTab
              profileCardId={profileCardId}
              setProfileCardId={setProfileCardId}
              deleteCard={deleteCard}
              refetchCards={refetchCards}
              isAuthenticated={isAuthenticated}
              user={user}
            />
          </TabsContent>

          {/* -- EBAY CARDS -- */}
          <TabsContent value="ebay-cards">
            <EbayCardsTab
              profileCardId={profileCardId}
              setProfileCardId={setProfileCardId}
              deleteCard={deleteCard}
              refetchCards={refetchCards}
              isAuthenticated={isAuthenticated}
              user={user}
            />
          </TabsContent>

          {/* -- COLLECTION -- */}
          <TabsContent value="collection">
            <div className="bg-[#0d1f3c] border border-white/10 rounded-xl p-4">
              <p className="text-white/40 text-xs mb-3">{collectionItems?.length ?? 0} collection items — <span className="text-white/30">click any row or the Profile button to edit</span></p>
              <AdminTable headers={["ID","Owner","Card","Player","Grade","Sport","Est. Value","Actions"]}>
                {collectionItems?.map(item => (
                  <TR key={item.id}
                    className="cursor-pointer hover:bg-white/5 transition-colors"
                    onClick={() => setProfileCollectionId(item.id)}
                  >
                    <TD className="font-mono text-xs text-white/40">{item.id}</TD>
                    <TD className="text-xs text-white/40">{item.ownerEmail}</TD>
                    <TD className="text-xs font-medium text-white">{item.cardTitle}</TD>
                    <TD className="text-xs text-white/60">{item.playerName}</TD>
                    <TD>
                      <button
                        className="group"
                        title="Click to edit grade (auto-prices via SCP)"
                        onClick={() => {
                          const g = prompt("New grade (e.g. 9, 9.5, 10):", item.overallGrade ?? "");
                          if (!g) return;
                          adjustCollectionGrade.mutate({ collectionId: item.id, overallGrade: g });
                        }}
                      >
                        {item.overallGrade
                          ? <Badge className="bg-yellow-500/20 text-yellow-400 border-yellow-500/30 text-xs group-hover:bg-yellow-500/40 cursor-pointer">{parseFloat(item.overallGrade).toFixed(1)}</Badge>
                          : <span className="text-white/30 text-xs group-hover:text-white/60 cursor-pointer underline">+ grade</span>}
                      </button>
                    </TD>
                    <TD className="text-xs capitalize text-white/60">{item.sport}</TD>
                    <TD>
                      <button
                        className="text-xs text-green-400 hover:text-green-300 underline"
                        title="Click to override estimated value"
                        onClick={() => {
                          const v = prompt("Override estimated value ($):", item.estimatedValueLow ?? "");
                          if (!v) return;
                          adjustCollectionGrade.mutate({ collectionId: item.id, overallGrade: item.overallGrade ?? "0", estimatedValueLow: v, estimatedValueHigh: v });
                        }}
                      >
                        {item.estimatedValueLow ? `$${parseFloat(item.estimatedValueLow).toFixed(0)}–$${parseFloat(item.estimatedValueHigh ?? item.estimatedValueLow).toFixed(0)}` : <span className="text-white/30">—</span>}
                      </button>
                    </TD>
                    <TD onClick={e => e.stopPropagation()}>
                      <div className="flex items-center gap-1">
                        <Button size="sm" variant="ghost" className="text-blue-400 h-7 px-2 hover:bg-blue-500/10 text-xs" onClick={() => setProfileCollectionId(item.id)}>
                          <Pencil className="w-3 h-3" />
                        </Button>
                        <Button size="sm" variant="ghost" className="text-red-400 h-7 px-2 hover:bg-red-500/10" onClick={() => { if (!confirm(`Delete "${item.cardTitle}" from ${item.ownerEmail}?`)) return; deleteCollectionItem.mutate({ collectionId: item.id }); }}>
                          <Trash2 className="w-3 h-3" />
                        </Button>
                      </div>
                    </TD>
                  </TR>
                ))}
                {(!collectionItems || collectionItems.length === 0) && (
                  <tr><td colSpan={8} className="p-8 text-center text-white/30 text-sm">No collection items</td></tr>
                )}
              </AdminTable>
            </div>
            <CollectionItemDrawer
              collectionId={profileCollectionId}
              onClose={() => setProfileCollectionId(null)}
              onUpdated={() => refetchCollections()}
            />
          </TabsContent>

          {/* -- VAULT -- */}
          <TabsContent value="vault">
            <div className="bg-[#0d1f3c] border border-white/10 rounded-xl p-4">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-2 h-2 rounded-full bg-yellow-400" />
                <h3 className="text-white font-bold text-sm">SCO Vault — Cards in Storage ({vaultedCards?.length ?? 0})</h3>
              </div>
              <AdminTable headers={["ID","Owner","Card","Player","Grade","Est. Value","Vault Status","Source","Actions"]}>
                {vaultedCards?.map(item => (
                  <TR key={item.id}>
                    <TD className="font-mono text-xs text-white/40">{item.id}</TD>
                    <TD className="text-xs text-white/60">{item.ownerEmail}</TD>
                    <TD>
                      <div className="flex items-center gap-2">
                        {item.frontImageUrl && <img src={item.frontImageUrl} alt="" className="w-7 h-9 object-cover rounded" />}
                        <div>
                          <div className="font-medium text-xs text-white line-clamp-1">{item.cardTitle}</div>
                          <div className="text-xs text-white/40">{item.year} {item.setName}</div>
                        </div>
                      </div>
                    </TD>
                    <TD className="text-xs text-white/60">{item.playerName}</TD>
                    <TD>{item.overallGrade ? <Badge className="bg-yellow-500/20 text-yellow-400 border-yellow-500/30 text-xs">{item.overallGrade}</Badge> : <span className="text-white/30 text-xs">—</span>}</TD>
                    <TD className="text-xs text-green-400">{item.estimatedValueLow ? `$${parseFloat(item.estimatedValueLow).toFixed(0)}` : "—"}</TD>
                    <TD>
                      <Select
                        value={item.listingStatus}
                        onValueChange={(val) => updateVaultStatus.mutate({ collectionId: item.id, listingStatus: val as any })}
                      >
                        <SelectTrigger className="h-7 text-xs bg-white/5 border-white/10 text-white w-32">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {["vaulted","vault_listed","vault_auction","vault_sold","vault_shipped","none"].map(s => (
                            <SelectItem key={s} value={s} className="text-xs capitalize">{s.replace(/_/g, " ")}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </TD>
                    <TD className="text-xs text-white/40 capitalize">{item.vaultSource?.replace(/_/g, " ") ?? "—"}</TD>
                    <TD>
                      <Button size="sm" variant="ghost" className="text-white/40 h-7 px-2 hover:bg-white/10 text-xs"
                        onClick={() => window.open(`mailto:${item.ownerEmail}?subject=Your Vaulted Card: ${item.cardTitle}`, '_blank')}>
                        Email
                      </Button>
                    </TD>
                  </TR>
                ))}
                {(!vaultedCards || vaultedCards.length === 0) && (
                  <tr><td colSpan={9} className="p-8 text-center text-white/30 text-sm">No cards currently in the SCO Vault</td></tr>
                )}
              </AdminTable>
            </div>
          </TabsContent>

          {/* -- ORDERS -- */}
          <TabsContent value="orders">
            <div className="bg-[#0d1f3c] border border-white/10 rounded-xl p-4">
              <div className="flex items-center justify-between mb-3">
                <p className="text-xs text-white/30">Green row = delivered. Release Funds button appears only for third-party seller orders.</p>
                <div className="flex items-center gap-2 print:hidden">
                  <Button
                    size="sm"
                    onClick={() => batchCreateLabels.mutate()}
                    disabled={batchCreateLabels.isPending}
                    className="h-7 text-xs bg-blue-600 hover:bg-blue-700 text-white"
                  >
                    {batchCreateLabels.isPending
                      ? <><RefreshCw className="w-3 h-3 mr-1 animate-spin" />Creating Labels...</>
                      : <><PackagePlus className="w-3 h-3 mr-1" />Create All Labels</>}
                  </Button>
                <Button size="sm" variant="outline" className="h-7 text-xs border-white/10 text-white/60" onClick={() => {
                  const el = document.getElementById('orders-print-area');
                  if (!el) return;
                  const w = window.open('', '_blank')!;
                  w.document.write(`<html><head><title>Orders — SportCardsOnline</title><style>body{font-family:sans-serif;font-size:11px;color:#000;padding:20px}table{width:100%;border-collapse:collapse}th,td{border:1px solid #ccc;padding:6px 8px;text-align:left}th{background:#f0f0f0;font-weight:600}tr:nth-child(even){background:#f9f9f9}.green{color:#16a34a;font-weight:600}.red{color:#dc2626}h2{margin-bottom:4px}p{color:#666;font-size:10px;margin-bottom:12px}@media print{button{display:none}}</style></head><body>${el.innerHTML}</body></html>`);
                  w.document.close();
                  w.focus();
                  setTimeout(() => { w.print(); }, 400);
                }}>
                  <Printer className="w-3 h-3 mr-1" /> Print
                </Button>
                </div>
              </div>
              <div id="orders-print-area">
              <h2 style={{display:'none'}} className="print-title">Orders Report — SportCardsOnline.com</h2>
              <AdminTable headers={["ID","Card","Buyer","Seller","Amount","Status","Tracking","Actions"]}>
                {orders?.map(order => {
                  const isDelivered = order.status === "delivered" || order.status === "confirmed" || order.status === "completed";
                  const isDropship = (order as any).isDropshipOrder;
                  const fundsReleased = (order as any).fundsReleased;
                  const rowClass = isDelivered ? "bg-green-500/10 border-green-500/20" : "";
                  return (
                    <TR key={order.id} className={rowClass}>
                      <TD className="font-mono text-xs text-white/40">{order.id}</TD>
                      <TD className="text-xs">{(order as any).cardTitle ?? "—"}</TD>
                      <TD className="text-xs text-white/40">{(order as any).buyerEmail ?? "—"}</TD>
                      <TD className="text-xs text-white/40">{(order as any).sellerEmail ?? "—"}</TD>
                      <TD className="font-semibold text-green-400 text-xs">${parseFloat((order as any).totalAmount ?? "0").toFixed(2)}</TD>
                      <TD>
                        <Badge className={`text-xs capitalize ${
                          isDelivered ? "bg-green-500/20 text-green-400 border-green-500/30" :
                          order.status === "shipped" ? "bg-blue-500/20 text-blue-400 border-blue-500/30" :
                          "bg-white/10 text-white/60 border-white/10"
                        }`}>{order.status}</Badge>
                        {isDropship && <Badge className="ml-1 text-xs bg-orange-500/20 text-orange-400 border-orange-500/30">eBay</Badge>}
                      </TD>
                      <TD>
                        <div className="flex items-center gap-1">
                          <Input
                            defaultValue={(order as any).trackingNumber ?? ""}
                            placeholder="Tracking #"
                            className="h-6 w-28 text-xs bg-white/5 border-white/10 text-white placeholder:text-white/20"
                            onBlur={e => {
                              const val = e.target.value.trim();
                              if (val && val !== ((order as any).trackingNumber ?? "")) {
                                updateOrderTracking.mutate({ orderId: order.id, trackingNumber: val });
                              }
                            }}
                          />
                        </div>
                      </TD>
                      <TD>
                        <div className="flex items-center gap-1 flex-wrap">
                          <Select onValueChange={val => updateOrderStatus.mutate({ orderId: order.id, status: val as any })}>
                            <SelectTrigger className="h-6 w-24 text-xs bg-white/5 border-white/10 text-white"><SelectValue placeholder="Status" /></SelectTrigger>
                            <SelectContent className="bg-[#0d1f3c] border-white/10">
                              {["pending","paid","shipped","delivered","cancelled"].map(s => (
                                <SelectItem key={s} value={s} className="text-xs capitalize text-white hover:bg-white/10">{s}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          {isDelivered && !isDropship && !fundsReleased && (
                            <Button size="sm" variant="ghost"
                              className="h-6 text-xs text-emerald-400 hover:bg-emerald-500/10 px-2"
                              onClick={() => { if (!confirm("Release funds to seller?")) return; releaseFunds.mutate({ orderId: order.id }); }}
                              disabled={releaseFunds.isPending}
                            >
                              <CheckCircle className="w-3 h-3 mr-1" />Release
                            </Button>
                          )}
                          {fundsReleased && (
                            <span className="text-xs text-emerald-400 flex items-center gap-1">
                              <CheckCircle className="w-3 h-3" />Released
                            </span>
                          )}
                          {!isDropship && !(order as any).labelPurchased && (
                            <Button size="sm" variant="ghost"
                              className="h-6 text-xs text-blue-400 hover:bg-blue-500/10 px-2"
                              onClick={() => setLabelModalOrder({
                                id: order.id,
                                buyerEmail: (order as any).buyerEmail ?? "",
                                cardTitle: (order as any).cardTitle ?? "Sports Card",
                                shippingAddress: (order as any).shippingAddress ?? null,
                                totalAmount: (order as any).totalAmount ?? null,
                              })}
                            >
                              <PackagePlus className="w-3 h-3 mr-1" />Label
                            </Button>
                          )}
                          {(order as any).labelPurchased && (order as any).labelUrl && (
                            <a href={(order as any).labelUrl} target="_blank" rel="noreferrer"
                              className="text-xs text-blue-400 hover:text-blue-300 flex items-center gap-1">
                              <Download className="w-3 h-3" />Label
                            </a>
                          )}
                          {(order as any).labelPurchased && !(order as any).labelUrl && (
                            <span className="text-xs text-blue-400/60 flex items-center gap-1">
                              <CheckCircle className="w-3 h-3" />Labeled
                            </span>
                          )}
                        </div>
                      </TD>
                    </TR>
                  );
                })}
              </AdminTable>
              </div>
            </div>
          </TabsContent>
          {/* -- USERS -- */}
          <TabsContent value="users">
            <div className="bg-[#0d1f3c] border border-white/10 rounded-xl p-4">
              <AdminTable headers={["ID","Name","Email","Role","Joined","Actions"]}>
                {users?.map(u => (
                  <TR key={u.id}>
                    <TD className="font-mono text-xs text-white/40">{u.id}</TD>
                    <TD className="font-medium text-sm">{u.name ?? "—"}</TD>
                    <TD className="text-xs text-white/40">{u.email}</TD>
                    <TD><Badge className={`text-xs capitalize ${u.role === "admin" ? "bg-[#C41E3A]/20 text-[#C41E3A] border-[#C41E3A]/30" : "bg-white/10 text-white/40 border-white/10"}`}>{u.role}</Badge></TD>
                    <TD className="text-xs text-white/40">{new Date(u.createdAt).toLocaleDateString()}</TD>
                    <TD>
                      <Button size="sm" variant="outline" className="h-7 text-xs border-white/20 text-white hover:bg-white/10" onClick={() => { const newRole: "user" | "admin" = u.role === "admin" ? "user" : "admin"; updateRole.mutate({ userId: u.id, role: newRole }); }}>
                        {u.role === "admin" ? "Demote" : "Make Admin"}
                      </Button>
                    </TD>
                  </TR>
                ))}
              </AdminTable>
            </div>
          </TabsContent>

          {/* -- AUCTIONS -- */}
          <TabsContent value="auctions">
            <div className="bg-[#0d1f3c] border border-white/10 rounded-xl p-4">
              <AdminTable headers={["ID","Card","Seller","Current Bid","Ends","Status","Actions"]}>
                {auctions?.map(a => (
                  <TR key={a.id}>
                    <TD className="font-mono text-xs text-white/40">{a.id}</TD>
                    <TD className="text-xs">{a.cardTitle}</TD>
                    <TD className="text-xs text-white/40">{a.sellerEmail}</TD>
                    <TD className="font-semibold text-green-400 text-xs">${parseFloat(a.currentBid ?? "0").toFixed(2)}</TD>
                    <TD className="text-xs text-white/40">{new Date(a.endTime).toLocaleDateString()}</TD>
                    <TD><Badge className={`text-xs capitalize ${a.status === "active" ? "bg-green-500/20 text-green-400 border-green-500/30" : "bg-white/10 text-white/40 border-white/10"}`}>{a.status}</Badge></TD>
                    <TD>
                      {a.status === "active" && (
                        <Button size="sm" variant="ghost" className="text-red-400 h-7 text-xs hover:bg-red-500/10" onClick={() => { if (!confirm("Cancel this auction?")) return; cancelAuction.mutate({ auctionId: a.id }); }}>
                          <XCircle className="w-3 h-3 mr-1" />Cancel
                        </Button>
                      )}
                    </TD>
                  </TR>
                ))}
              </AdminTable>
            </div>
          </TabsContent>

          {/* -- CREDITS -- */}
          <TabsContent value="credits">
            <div className="bg-[#0d1f3c] border border-white/10 rounded-xl p-6 max-w-lg">
              <h3 className="text-white font-bold mb-4 flex items-center gap-2"><Coins className="w-4 h-4 text-[#E8C547]" /> Add Credits to User</h3>
              <div className="space-y-3">
                <Input placeholder="User email address" value={creditEmail} onChange={e => setCreditEmail(e.target.value)} className="bg-white/5 border-white/10 text-white placeholder:text-white/30" />
                <Input type="number" placeholder="Number of credits" value={creditAmount} onChange={e => setCreditAmount(e.target.value)} className="bg-white/5 border-white/10 text-white placeholder:text-white/30" />
                <Button onClick={() => { if (!creditEmail || !creditAmount) { toast.error("Enter email and amount"); return; } addCredits.mutate({ userEmail: creditEmail, amount: parseInt(creditAmount), reason: "Admin credit grant" }); }} disabled={addCredits.isPending} className="w-full bg-[#C41E3A] hover:bg-[#a01830]">
                  <Coins className="w-4 h-4 mr-2" /> Add Credits
                </Button>
              </div>
            </div>
          </TabsContent>

          {/* -- AFFILIATES -- */}
          <TabsContent value="affiliates">
            <div className="bg-[#0d1f3c] border border-white/10 rounded-xl p-4">
              <AdminTable headers={["User","Referral Code","Referrals","Earnings","Status"]}>
                {affiliates?.map(a => (
                  <TR key={a.id}>
                    <TD>{a.userName ?? a.userEmail}</TD>
                    <TD><span className="font-mono text-xs bg-white/10 px-2 py-0.5 rounded text-[#E8C547]">{a.referralCode}</span></TD>
                    <TD>{a.totalReferrals ?? 0}</TD>
                    <TD className="font-semibold text-green-400">${parseFloat(a.totalEarnings ?? "0").toFixed(2)}</TD>
                    <TD><Badge className={`text-xs capitalize ${a.status === "active" ? "bg-green-500/20 text-green-400 border-green-500/30" : "bg-white/10 text-white/40 border-white/10"}`}>{a.status}</Badge></TD>
                  </TR>
                ))}
                {(!affiliates || affiliates.length === 0) && (
                  <tr><td colSpan={5} className="p-8 text-center text-white/30 text-sm">No affiliates yet</td></tr>
                )}
              </AdminTable>
            </div>
          </TabsContent>

          {/* -- TEMPLATES -- */}
          <TabsContent value="templates">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="bg-[#0d1f3c] border border-white/10 rounded-xl p-4">
                <h3 className="text-white font-bold mb-4 flex items-center gap-2"><Pencil className="w-4 h-4 text-[#C41E3A]" /> Create / Edit Template</h3>
                <div className="space-y-3">
                  <Select onValueChange={val => { const t = templates?.find(t => t.name === val); if (t) { setTemplateName(t.name); setTemplateSubject(t.subject ?? ""); setTemplateBody(t.body ?? ""); } else setTemplateName(val); }}>
                    <SelectTrigger className="bg-white/5 border-white/10 text-white"><SelectValue placeholder="Select or create template" /></SelectTrigger>
                    <SelectContent className="bg-[#0d1f3c] border-white/10">
                      {["order_confirmation","auction_won","trade_accepted","card_shipped","payment_released","welcome"].map(t => (
                        <SelectItem key={t} value={t} className="text-white hover:bg-white/10">{t.replace(/_/g, " ").replace(/\b\w/g, c => c.toUpperCase())}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <Input placeholder="Template name/trigger" value={templateName} onChange={e => setTemplateName(e.target.value)} className="bg-white/5 border-white/10 text-white placeholder:text-white/30" />
                  <Input placeholder="Email subject" value={templateSubject} onChange={e => setTemplateSubject(e.target.value)} className="bg-white/5 border-white/10 text-white placeholder:text-white/30" />
                  <Textarea placeholder="Email body (use {{variable}} for dynamic content)" value={templateBody} onChange={e => setTemplateBody(e.target.value)} rows={6} className="bg-white/5 border-white/10 text-white placeholder:text-white/30 resize-none" />
                  <Button onClick={() => { if (!templateName || !templateSubject || !templateBody) { toast.error("Fill all fields"); return; } upsertTemplate.mutate({ name: templateName, subject: templateSubject, body: templateBody, trigger: "welcome" as any }); }} disabled={upsertTemplate.isPending} className="w-full bg-[#C41E3A] hover:bg-[#a01830]">Save Template</Button>
                </div>
              </div>
              <div>
                <h3 className="text-white font-bold mb-3">Saved Templates</h3>
                <div className="space-y-2">
                  {templates?.map(t => (
                    <div key={t.id} className="bg-[#0d1f3c] border border-white/10 rounded-lg p-3 flex items-center justify-between">
                      <div>
                        <div className="font-medium text-sm text-white capitalize">{t.name.replace(/_/g, " ")}</div>
                        <div className="text-xs text-white/40">{t.subject}</div>
                      </div>
                      <div className="flex gap-2">
                        <Button size="sm" variant="ghost" className="h-7 text-xs text-white/60 hover:bg-white/10" onClick={() => { setTemplateName(t.name); setTemplateSubject(t.subject ?? ""); setTemplateBody(t.body ?? ""); }}><Pencil className="w-3 h-3" /></Button>
                        <Button size="sm" variant="ghost" className="h-7 text-xs text-red-400 hover:bg-red-500/10" onClick={() => deleteTemplate.mutate({ id: t.id })}><Trash2 className="w-3 h-3" /></Button>
                      </div>
                    </div>
                  ))}
                  {(!templates || templates.length === 0) && <p className="text-white/30 text-sm">No templates yet.</p>}
                </div>
              </div>
            </div>
          </TabsContent>

          {/* -- TRADES -- */}
          <TabsContent value="trades">
            <TradesAdminTab isAdmin={isAuthenticated && user?.role === "admin"} />
          </TabsContent>

          {/* -- FULFILLMENT -- */}
          <TabsContent value="fulfillment">
            <DropshipFulfillmentTab isAdmin={isAuthenticated && user?.role === "admin"} />
          </TabsContent>

          {/* -- BEST OFFER QUEUE -- */}
          <TabsContent value="best-offer">
            <BestOfferQueueTab isAdmin={isAuthenticated && user?.role === "admin"} />
          </TabsContent>
          {/* -- EBAY IMPORT -- */}
          <TabsContent value="ebay-import">
            <EbayImportTab isAdmin={isAuthenticated && user?.role === "admin"} />
          </TabsContent>

          {/* -- SELLER PAYOUTS -- */}
          <TabsContent value="payouts">
            <SellerPayoutsTab />
          </TabsContent>
          <TabsContent value="disputes">
            <DisputesTab />
          </TabsContent>
          <TabsContent value="blog">
            <BlogManagementTab />
          </TabsContent>

          {/* -- SETTINGS -- */}
          <TabsContent value="settings">
            <LabelColorSettings />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}


// --- Disputes Tab -----------------------------------------------------------
function DisputesTab() {
  const [statusFilter, setStatusFilter] = useState<string>("open");
  const [resolutionNote, setResolutionNote] = useState<Record<number, string>>({});

  const { data: disputes, refetch } = trpc.disputes.listDisputes.useQuery({ status: statusFilter === "all" ? undefined : statusFilter });

  const updateStatus = trpc.disputes.updateDisputeStatus.useMutation({
    onSuccess: () => { toast.success("Dispute updated"); refetch(); },
    onError: (e) => toast.error(e.message),
  });

  const STATUS_COLORS: Record<string, string> = {
    open:        "bg-red-500/20 text-red-300 border-red-500/30",
    investigating: "bg-yellow-500/20 text-yellow-300 border-yellow-500/30",
    resolved:    "bg-green-500/20 text-green-300 border-green-500/30",
    closed:      "bg-gray-500/20 text-gray-300 border-gray-500/30",
  };

  const REASON_LABELS: Record<string, string> = {
    item_not_received:     "Item Not Received",
    item_not_as_described: "Item Not as Described",
    damaged_item:          "Item Arrived Damaged",
    wrong_item:            "Wrong Item Sent",
    other:                 "Other",
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-white font-semibold flex items-center gap-2">
          <AlertTriangle className="w-4 h-4 text-red-400" /> Dispute Management
        </h3>
        <div className="flex gap-2">
          {["all","open","investigating","resolved","closed"].map(s => (
            <button
              key={s}
              onClick={() => setStatusFilter(s)}
              className={`px-3 py-1 rounded-full text-xs font-medium transition-colors ${statusFilter === s ? "bg-[#C41E3A] text-white" : "bg-white/5 text-white/50 hover:bg-white/10"}`}
            >
              {s.charAt(0).toUpperCase() + s.slice(1)}
            </button>
          ))}
        </div>
      </div>

      {!disputes || disputes.length === 0 ? (
        <div className="text-center py-16 text-white/30">
          <Shield className="w-12 h-12 mx-auto mb-3 text-white/10" />
          <p>No disputes found.</p>
        </div>
      ) : (
        <div className="space-y-3">
          {disputes.map((d: any) => (
            <div key={d.id} className="bg-[#0d1f3c] border border-white/10 rounded-xl p-4 space-y-3">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <p className="text-white font-medium text-sm">Dispute #{d.id} — Order #{d.orderId}</p>
                  <p className="text-white/50 text-xs">{REASON_LABELS[d.reason] ?? d.reason}</p>
                  <p className="text-white/30 text-xs">{new Date(d.createdAt).toLocaleDateString()}</p>
                </div>
                <span className={`text-xs px-2 py-0.5 rounded-full border ${STATUS_COLORS[d.status] ?? "bg-white/10 text-white/50"}`}>
                  {d.status}
                </span>
              </div>

              <div className="bg-white/5 rounded-lg p-3 text-xs text-white/70 border border-white/5">
                <p className="font-medium text-white/50 mb-1">Buyer's Description:</p>
                <p>{d.description}</p>
              </div>

              {d.resolutionNote && (
                <div className="bg-green-500/10 rounded-lg p-3 text-xs text-green-300 border border-green-500/20">
                  <p className="font-medium mb-1">Resolution Note:</p>
                  <p>{d.resolutionNote}</p>
                </div>
              )}

              <div className="space-y-2">
                <textarea
                  value={resolutionNote[d.id] ?? ""}
                  onChange={(e) => setResolutionNote(prev => ({ ...prev, [d.id]: e.target.value }))}
                  placeholder="Add resolution note..."
                  className="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-xs text-white placeholder:text-white/30 resize-none h-16 outline-none focus:border-[#C41E3A]/50"
                />
                <div className="flex gap-2 flex-wrap">
                  {["investigating","resolved","closed"].map(newStatus => (
                    <button
                      key={newStatus}
                      onClick={() => updateStatus.mutate({ disputeId: d.id, status: newStatus as any, resolutionNote: resolutionNote[d.id] })}
                      disabled={d.status === newStatus || updateStatus.isPending}
                      className={`px-3 py-1 rounded-lg text-xs font-medium transition-colors disabled:opacity-40 ${
                        newStatus === "resolved" ? "bg-green-600 hover:bg-green-700 text-white" :
                        newStatus === "investigating" ? "bg-yellow-600 hover:bg-yellow-700 text-white" :
                        "bg-gray-600 hover:bg-gray-700 text-white"
                      }`}
                    >
                      Mark {newStatus.charAt(0).toUpperCase() + newStatus.slice(1)}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ─── Seller Payouts Tab ─────────────────────────────────────────────────────
function SellerPayoutsTab() {
  const [search, setSearch] = useState("");
  const [page, setPage] = useState(0);
  const PAGE_SIZE = 50;

  const { data, isLoading, refetch } = trpc.admin.listSellerPayouts.useQuery(
    { search: search || undefined, limit: PAGE_SIZE, offset: page * PAGE_SIZE },
    {}
  );

  const payouts = data?.payouts ?? [];
  const total = data?.total ?? 0;
  const totalAmount = data?.totalAmount ?? 0;
  const totalPages = Math.ceil(total / PAGE_SIZE);

  const handlePrint = () => {
    const el = document.getElementById('payouts-print-area');
    if (!el) return;
    const w = window.open('', '_blank')!;
    w.document.write(`<html><head><title>Seller Payouts — SportCardsOnline</title><style>body{font-family:sans-serif;font-size:11px;color:#000;padding:20px}table{width:100%;border-collapse:collapse}th,td{border:1px solid #ccc;padding:6px 8px;text-align:left}th{background:#f0f0f0;font-weight:600}tr:nth-child(even){background:#f9f9f9}.green{color:#16a34a;font-weight:600}.red{color:#dc2626}.bold{font-weight:700}h2{margin-bottom:4px}p{color:#666;font-size:10px;margin-bottom:12px}tfoot td{border-top:2px solid #333;font-weight:700;background:#f0f0f0}@media print{button{display:none}}</style></head><body>${el.innerHTML}</body></html>`);
    w.document.close();
    w.focus();
    setTimeout(() => { w.print(); }, 400);
  };

  return (
    <div className="bg-[#0d1f3c] border border-white/10 rounded-xl p-4">
      <div className="flex items-center justify-between mb-4 flex-wrap gap-3">
        <div>
          <h3 className="text-white font-bold text-lg">Seller Payouts</h3>
          <p className="text-white/40 text-xs">{total} payout{total !== 1 ? "s" : ""} · Total released: <span className="text-green-400 font-semibold">${totalAmount.toFixed(2)}</span></p>
        </div>
        <div className="flex gap-2">
          <Input
            placeholder="Search seller, card..."
            value={search}
            onChange={e => { setSearch(e.target.value); setPage(0); }}
            className="w-52 h-8 text-xs bg-white/5 border-white/10 text-white placeholder:text-white/30"
          />
          <Button size="sm" variant="outline" onClick={handlePrint} className="h-8 text-xs border-white/10 text-white/60">
            <Printer className="w-3 h-3 mr-1" /> Print
          </Button>
          <Button size="sm" variant="outline" onClick={() => refetch()} className="h-8 text-xs border-white/10 text-white/60">
            <RefreshCw className="w-3 h-3" />
          </Button>
        </div>
      </div>

      <div id="payouts-print-area">
        <h2 style={{fontSize:'16px',fontWeight:'bold',marginBottom:'2px'}}>Seller Payouts — SportCardsOnline.com</h2>
        <p style={{fontSize:'11px',color:'#666',marginBottom:'12px'}}>Printed: {new Date().toLocaleString()} · Total released: ${totalAmount.toFixed(2)} · {total} payout{total !== 1 ? 's' : ''}{search ? ` · Filter: "${search}"` : ''}</p>
      {isLoading ? (
        <div className="text-white/40 text-sm py-8 text-center">Loading payouts...</div>
      ) : payouts.length === 0 ? (
        <div className="text-white/40 text-sm py-8 text-center">No payouts found.</div>
      ) : (
        <AdminTable headers={["Order #", "Card", "Seller", "Buyer", "Sale Amount", "Platform Fee", "Net to Seller", "Tracking", "Delivered", "Released At", "Released By"]}>
          {payouts.map(p => {
            const sale = parseFloat(p.totalAmount ?? "0");
            const fee = parseFloat(p.platformFee ?? "0");
            const net = sale - fee;
            return (
              <TR key={p.id} className="bg-green-900/10">
                <TD><span className="text-white/50 text-xs">#{p.id}</span></TD>
                <TD><span className="text-white text-xs font-medium line-clamp-2 max-w-[180px]">{p.cardTitle}</span></TD>
                <TD><span className="text-blue-300 text-xs">{p.sellerEmail}</span></TD>
                <TD><span className="text-white/60 text-xs">{p.buyerEmail}</span></TD>
                <TD><span className="text-green-400 font-semibold text-xs">${sale.toFixed(2)}</span></TD>
                <TD><span className="text-red-400 text-xs">-${fee.toFixed(2)}</span></TD>
                <TD><span className="text-emerald-400 font-bold text-xs">${net.toFixed(2)}</span></TD>
                <TD>
                  {p.trackingNumber ? (
                    <span className="text-white/60 text-xs flex items-center gap-1">
                      <Truck className="w-3 h-3" /> {p.carrier ? `${p.carrier}: ` : ""}{p.trackingNumber}
                    </span>
                  ) : <span className="text-white/20 text-xs">—</span>}
                </TD>
                <TD>
                  {p.deliveredAt ? (
                    <span className="text-green-400 text-xs flex items-center gap-1">
                      <CheckCircle className="w-3 h-3" /> {new Date(p.deliveredAt).toLocaleDateString()}
                    </span>
                  ) : <span className="text-white/20 text-xs">—</span>}
                </TD>
                <TD>
                  <span className="text-white/70 text-xs">
                    {p.fundsReleasedAt ? new Date(p.fundsReleasedAt).toLocaleString() : "—"}
                  </span>
                </TD>
                <TD><span className="text-white/50 text-xs">{p.fundsReleasedBy ?? "—"}</span></TD>
              </TR>
            );
          })}
        </AdminTable>
      )}
      </div>

      {totalPages > 1 && (
        <div className="flex items-center justify-between mt-4">
          <span className="text-white/40 text-xs">Page {page + 1} of {totalPages} · {total} total</span>
          <div className="flex gap-2">
            <Button size="sm" variant="outline" onClick={() => setPage(p => Math.max(0, p - 1))} disabled={page === 0} className="h-7 text-xs border-white/10 text-white/60">Prev</Button>
            <Button size="sm" variant="outline" onClick={() => setPage(p => Math.min(totalPages - 1, p + 1))} disabled={page >= totalPages - 1} className="h-7 text-xs border-white/10 text-white/60">Next</Button>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── Trades Admin Tab ────────────────────────────────────────────────────────
function TradesAdminTab({ isAdmin }: { isAdmin: boolean }) {
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [editTradeId, setEditTradeId] = useState<number | null>(null);
  const [editInitTracking, setEditInitTracking] = useState("");
  const [editRecvTracking, setEditRecvTracking] = useState("");
  const [editStatus, setEditStatus] = useState("");

  const { data: trades, refetch } = trpc.admin.listAllTrades.useQuery(
    statusFilter !== "all" ? { status: statusFilter } : undefined,
    { enabled: isAdmin }
  );
  const updateTracking = trpc.admin.adminUpdateTradeTracking.useMutation({
    onSuccess: () => { toast.success("Trade updated!"); setEditTradeId(null); refetch(); },
    onError: () => toast.error("Update failed"),
  });

  const statusColors: Record<string, string> = {
    pending: "bg-yellow-500/20 text-yellow-300",
    accepted: "bg-blue-500/20 text-blue-300",
    agreed: "bg-yellow-600/20 text-yellow-300",
    fee_pending: "bg-orange-500/20 text-orange-300",
    paid_ready_to_ship: "bg-blue-500/20 text-blue-300",
    shipped: "bg-purple-500/20 text-purple-300",
    completed: "bg-green-700/30 text-green-200",
    rejected: "bg-red-500/20 text-red-300",
    cancelled: "bg-gray-500/20 text-gray-300",
    countered: "bg-orange-500/20 text-orange-300",
  };

  return (
    <div className="bg-[#0d1f3c] border border-white/10 rounded-xl p-4">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-white font-bold text-sm">All Trades ({trades?.length ?? 0})</h3>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-36 h-8 text-xs bg-white/5 border-white/10 text-white">
            <SelectValue placeholder="Filter status" />
          </SelectTrigger>
          <SelectContent>
            {["all","pending","accepted","agreed","fee_pending","paid_ready_to_ship","shipped","completed","rejected","cancelled","countered"].map(s => (
              <SelectItem key={s} value={s} className="text-xs capitalize">{s}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <AdminTable headers={["ID","Status","From","To","Offered","Requested","Init Fee","Recv Fee","Init Tracking","Recv Tracking","Date","Actions"]}>
        {trades?.map(trade => (
          <TR key={trade.id}>
            <TD className="font-mono text-xs">#{trade.id}</TD>
            <TD>
              <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${statusColors[trade.status] ?? "bg-white/10 text-white/60"}`}>
                {trade.status}
              </span>
            </TD>
            <TD className="text-xs max-w-[100px] truncate">{trade.initiatorName || trade.initiatorEmail}</TD>
            <TD className="text-xs max-w-[100px] truncate">{trade.receiverName || trade.receiverEmail}</TD>
            <TD className="text-xs text-white/60 max-w-[120px]">
              {(trade.offeredCardTitles as string[])?.slice(0,2).map((t,i) => <div key={i} className="truncate">{t}</div>)}
              {(trade.offeredCardTitles as string[])?.length > 2 && <div className="text-white/30">+{(trade.offeredCardTitles as string[]).length - 2} more</div>}
            </TD>
            <TD className="text-xs text-white/60 max-w-[120px]">
              {(trade.requestedCardTitles as string[])?.slice(0,2).map((t,i) => <div key={i} className="truncate">{t}</div>)}
              {(trade.requestedCardTitles as string[])?.length > 2 && <div className="text-white/30">+{(trade.requestedCardTitles as string[]).length - 2} more</div>}
            </TD>
            <TD className="text-xs">{trade.initiatorFeePaid ? <span className="text-green-400">✓ Paid</span> : <span className="text-red-400/60">Unpaid</span>}</TD>
            <TD className="text-xs">{trade.receiverFeePaid ? <span className="text-green-400">✓ Paid</span> : <span className="text-red-400/60">Unpaid</span>}</TD>
            <TD className="text-xs font-mono">{trade.initiatorTracking || <span className="text-white/30">—</span>}</TD>
            <TD className="text-xs font-mono">{trade.receiverTracking || <span className="text-white/30">—</span>}</TD>
            <TD className="text-xs text-white/40">{trade.createdAt ? new Date(trade.createdAt).toLocaleDateString() : "—"}</TD>
            <TD>
              <Button size="sm" variant="ghost" className="h-6 text-xs text-blue-400 hover:text-blue-300 px-2"
                onClick={() => { setEditTradeId(trade.id); setEditInitTracking(trade.initiatorTracking || ""); setEditRecvTracking(trade.receiverTracking || ""); setEditStatus(trade.status); }}>
                Edit
              </Button>
            </TD>
          </TR>
        ))}
      </AdminTable>

      {/* Edit dialog */}
      {editTradeId && (
        <div className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center" onClick={() => setEditTradeId(null)}>
          <div className="bg-[#0d1f3c] border border-white/20 rounded-xl p-6 w-full max-w-md space-y-4" onClick={e => e.stopPropagation()}>
            <h3 className="text-white font-bold">Edit Trade #{editTradeId}</h3>
            <div className="space-y-3">
              <div>
                <label className="text-xs text-white/50 mb-1 block">Initiator Tracking #</label>
                <Input value={editInitTracking} onChange={e => setEditInitTracking(e.target.value)}
                  placeholder="e.g. 9400111899223456789012"
                  className="bg-white/5 border-white/10 text-white text-sm" />
              </div>
              <div>
                <label className="text-xs text-white/50 mb-1 block">Receiver Tracking #</label>
                <Input value={editRecvTracking} onChange={e => setEditRecvTracking(e.target.value)}
                  placeholder="e.g. 9400111899223456789013"
                  className="bg-white/5 border-white/10 text-white text-sm" />
              </div>
              <div>
                <label className="text-xs text-white/50 mb-1 block">Status</label>
                <Select value={editStatus} onValueChange={setEditStatus}>
                  <SelectTrigger className="bg-white/5 border-white/10 text-white text-sm">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {["pending","accepted","agreed","fee_pending","paid_ready_to_ship","shipped","completed","rejected","cancelled","countered"].map(s => (
                      <SelectItem key={s} value={s} className="capitalize">{s}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="flex gap-2 justify-end pt-2">
              <Button variant="ghost" size="sm" onClick={() => setEditTradeId(null)} className="text-white/50">Cancel</Button>
              <Button size="sm" className="bg-[#C41E3A] hover:bg-[#a01830]"
                disabled={updateTracking.isPending}
                onClick={() => updateTracking.mutate({
                  tradeId: editTradeId,
                  initiatorTracking: editInitTracking || undefined,
                  receiverTracking: editRecvTracking || undefined,
                  status: editStatus as any,
                })}>
                {updateTracking.isPending ? "Saving..." : "Save Changes"}
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── Dropship Fulfillment Tab ────────────────────────────────────────────────
function DropshipFulfillmentTab({ isAdmin }: { isAdmin: boolean }) {
  const { data: orders, refetch } = trpc.admin.getDropshipOrders.useQuery({}, { enabled: isAdmin });
  const markFulfilled = trpc.admin.markDropshipFulfilled.useMutation({
    onSuccess: () => { toast.success("Order marked as fulfilled!"); refetch(); },
    onError: () => toast.error("Failed to update order"),
  });
  const attemptOffer = trpc.admin.attemptBestOffer.useMutation({
    onSuccess: (data: any) => {
      if (data.offerAccepted) {
        toast.success(`✅ Best Offer accepted! Saved $${data.savings.toFixed(2)}`);
      } else {
        toast.info(`Offer ${data.status} — proceeding at full price`);
      }
      refetch();
    },
    onError: (e: any) => toast.error(e.message || "Offer attempt failed"),
  });

  const statusColor = (s: string) => {
    if (s === "fulfilled") return "bg-green-500/20 text-green-400 border-green-500/30";
    if (s === "pending") return "bg-yellow-500/20 text-yellow-300 border-yellow-500/30";
    return "bg-white/10 text-white/40 border-white/10";
  };

  const offerBadge = (status: string | null) => {
    if (!status || status === "none") return null;
    const map: Record<string, string> = {
      pending: "bg-blue-500/20 text-blue-300 border-blue-500/30",
      accepted: "bg-green-500/20 text-green-400 border-green-500/30",
      declined: "bg-red-500/20 text-red-400 border-red-500/30",
      countered: "bg-orange-500/20 text-orange-300 border-orange-500/30",
      expired: "bg-gray-500/20 text-gray-400 border-gray-500/30",
      not_eligible: "bg-white/10 text-white/40 border-white/10",
      fallback_full_price: "bg-white/10 text-white/50 border-white/10",
    };
    const label: Record<string, string> = {
      pending: "Offer Pending",
      accepted: "Offer Accepted",
      declined: "Offer Declined",
      countered: "Counter Received",
      expired: "Offer Expired",
      not_eligible: "No Best Offer",
      fallback_full_price: "Full Price",
    };
    return <Badge className={`text-xs border ${map[status] || "bg-white/10 text-white/40"}`}>{label[status] || status}</Badge>;
  };

  return (
    <div className="bg-[#0d1f3c] border border-white/10 rounded-xl p-4">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-white font-bold text-sm flex items-center gap-2">
          <Truck className="w-4 h-4 text-[#C41E3A]" />
          eBay Dropship Fulfillment ({orders?.length ?? 0} orders)
        </h3>
        <Button size="sm" variant="ghost" onClick={() => refetch()} className="h-7 text-xs text-white/60 hover:bg-white/10">
          <RefreshCw className="w-3 h-3 mr-1" /> Refresh
        </Button>
      </div>

      {(!orders || orders.length === 0) ? (
        <div className="text-center py-12 text-white/30">
          <CheckCircle className="w-8 h-8 mx-auto mb-2 opacity-30" />
          <p className="text-sm">No pending dropship orders</p>
        </div>
      ) : (
        <div className="space-y-3">
          {orders.map((order: any) => (
            <div key={order.orderId} className="bg-white/5 border border-white/10 rounded-lg p-4">
              <div className="flex items-start justify-between gap-4">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-2 flex-wrap">
                    <Badge className={`text-xs ${order.dropshipFulfilledAt ? statusColor("fulfilled") : statusColor("pending")}`}>
                      {order.dropshipFulfilledAt ? "fulfilled" : "pending"}
                    </Badge>
                    {offerBadge(order.ebayOfferStatus)}
                    <span className="text-white/40 text-xs">Order #{order.orderId}</span>
                    <span className="text-white/40 text-xs">·</span>
                    <span className="text-white/40 text-xs">{new Date(order.createdAt).toLocaleDateString()}</span>
                  </div>

                  <div className="text-white font-medium text-sm mb-1 truncate">{order.cardTitle}</div>

                  <div className="grid grid-cols-2 gap-x-6 gap-y-1 text-xs mt-2">
                    <div>
                      <span className="text-white/40">Buyer: </span>
                      <span className="text-white/80">{order.buyerName || order.buyerEmail}</span>
                    </div>
                    <div>
                      <span className="text-white/40">Email: </span>
                      <span className="text-white/80">{order.buyerEmail}</span>
                    </div>
                    {order.shippingAddress && (
                      <div className="col-span-2">
                        <span className="text-white/40">Ship to: </span>
                        <span className="text-white/80">{order.shippingAddress}</span>
                      </div>
                    )}
                    <div>
                      <span className="text-white/40">Sale price: </span>
                      <span className="text-green-400 font-semibold">${parseFloat(order.totalAmount ?? "0").toFixed(2)}</span>
                    </div>
                    {order.cardSourcePrice && (
                      <div>
                        <span className="text-white/40">eBay source: </span>
                        <span className="text-white/80">${parseFloat(order.cardSourcePrice).toFixed(2)}</span>
                      </div>
                    )}
                    {order.ebayOfferAmount && (
                      <div>
                        <span className="text-white/40">Offer sent: </span>
                        <span className="text-blue-300">${parseFloat(order.ebayOfferAmount).toFixed(2)}</span>
                      </div>
                    )}
                    {order.ebayOfferSavings && parseFloat(order.ebayOfferSavings) > 0 && (
                      <div>
                        <span className="text-white/40">Savings: </span>
                        <span className="text-green-400 font-semibold">+${parseFloat(order.ebayOfferSavings).toFixed(2)}</span>
                      </div>
                    )}
                    {order.ebayOfferSentAt && (
                      <div className="col-span-2">
                        <span className="text-white/40">Offer sent: </span>
                        <span className="text-white/60">{new Date(order.ebayOfferSentAt).toLocaleString()}</span>
                      </div>
                    )}
                  </div>
                </div>

                <div className="flex flex-col gap-2 shrink-0">
                  {order.ebayFulfillmentLink && (
                    <a
                      href={order.ebayFulfillmentLink}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1 px-3 py-1.5 bg-[#E8C547] text-black text-xs font-bold rounded hover:bg-[#d4b23f] transition-colors"
                    >
                      <ExternalLink className="w-3 h-3" />
                      Buy on eBay
                    </a>
                  )}
                  {order.cardEbayItemId && (!order.ebayOfferStatus || order.ebayOfferStatus === "none" || order.ebayOfferStatus === "not_eligible" || order.ebayOfferStatus === "expired" || order.ebayOfferStatus === "fallback_full_price") && !order.dropshipFulfilledAt && (
                    <Button
                      size="sm"
                      onClick={() => attemptOffer.mutate({
                        orderId: order.orderId,
                        ebayItemId: order.cardEbayItemId,
                        askingPrice: parseFloat(order.cardSourcePrice || order.totalAmount || "0"),
                      })}
                      disabled={attemptOffer.isPending}
                      className="h-7 text-xs bg-blue-600 hover:bg-blue-700 text-white"
                    >
                      Try Best Offer
                    </Button>
                  )}
                  {!order.dropshipFulfilledAt && (
                    <Button
                      size="sm"
                      onClick={() => markFulfilled.mutate({ orderId: order.orderId })}
                      disabled={markFulfilled.isPending}
                      className="h-7 text-xs bg-green-600 hover:bg-green-700 text-white"
                    >
                      <CheckCircle className="w-3 h-3 mr-1" />
                      Mark Fulfilled
                    </Button>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// // ─── Best Offer Queue Tab ───────────────────────────────────────
function BestOfferQueueTab({ isAdmin }: { isAdmin: boolean }) {
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const { data: offers, refetch } = trpc.admin.getBestOfferQueue.useQuery(
    { status: statusFilter as any },
    { enabled: isAdmin }
  );
  const attemptOffer = trpc.admin.attemptBestOffer.useMutation({
    onSuccess: (data: any) => {
      if (data.offerAccepted) {
        toast.success(`✅ Offer accepted! Saved $${data.savings?.toFixed(2) ?? "0.00"}`);
      } else {
        toast.info(`Offer ${data.status}`);
      }
      refetch();
    },
    onError: (e: any) => toast.error(e.message || "Offer attempt failed"),
  });

  const offerStatusColors: Record<string, string> = {
    pending: "bg-blue-500/20 text-blue-300 border-blue-500/30",
    accepted: "bg-green-500/20 text-green-400 border-green-500/30",
    declined: "bg-red-500/20 text-red-400 border-red-500/30",
    countered: "bg-orange-500/20 text-orange-300 border-orange-500/30",
    expired: "bg-gray-500/20 text-gray-400 border-gray-500/30",
    not_eligible: "bg-white/10 text-white/40 border-white/10",
    fallback_full_price: "bg-white/10 text-white/50 border-white/10",
  };
  const offerStatusLabels: Record<string, string> = {
    pending: "Pending",
    accepted: "Accepted",
    declined: "Declined",
    countered: "Counter",
    expired: "Expired",
    not_eligible: "Not Eligible",
    fallback_full_price: "Full Price",
  };

  const totalSavings = (offers || []).reduce((sum: number, o: any) => {
    return sum + (o.ebayOfferSavings ? parseFloat(o.ebayOfferSavings) : 0);
  }, 0);
  const acceptedCount = (offers || []).filter((o: any) => o.ebayOfferStatus === "accepted").length;

  return (
    <div className="bg-[#0d1f3c] border border-white/10 rounded-xl p-4">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-white font-bold text-sm flex items-center gap-2">
          <span className="text-lg">🏷️</span>
          Best Offer Queue ({offers?.length ?? 0} offers)
        </h3>
        <Button size="sm" variant="ghost" onClick={() => refetch()} className="h-7 text-xs text-white/60 hover:bg-white/10">
          <RefreshCw className="w-3 h-3 mr-1" /> Refresh
        </Button>
      </div>

      {/* Summary stats */}
      <div className="grid grid-cols-3 gap-3 mb-4">
        <div className="bg-green-500/10 border border-green-500/20 rounded-lg p-3 text-center">
          <div className="text-green-400 font-bold text-lg">{acceptedCount}</div>
          <div className="text-white/40 text-xs">Accepted</div>
        </div>
        <div className="bg-blue-500/10 border border-blue-500/20 rounded-lg p-3 text-center">
          <div className="text-blue-300 font-bold text-lg">{(offers || []).filter((o: any) => o.ebayOfferStatus === "pending").length}</div>
          <div className="text-white/40 text-xs">Pending</div>
        </div>
        <div className="bg-[#E8C547]/10 border border-[#E8C547]/20 rounded-lg p-3 text-center">
          <div className="text-[#E8C547] font-bold text-lg">${totalSavings.toFixed(2)}</div>
          <div className="text-white/40 text-xs">Total Savings</div>
        </div>
      </div>

      {/* Filter */}
      <div className="flex gap-2 mb-4 flex-wrap">
        {["all", "accepted", "pending", "declined", "countered", "expired", "not_eligible", "fallback_full_price"].map(s => (
          <button
            key={s}
            onClick={() => setStatusFilter(s)}
            className={`px-2 py-1 text-xs rounded border transition-colors ${
              statusFilter === s
                ? "bg-[#C41E3A] text-white border-[#C41E3A]"
                : "bg-white/5 text-white/50 border-white/10 hover:bg-white/10"
            }`}
          >
            {s === "all" ? "All" : offerStatusLabels[s] || s}
          </button>
        ))}
      </div>

      {(!offers || offers.length === 0) ? (
        <div className="text-center py-12 text-white/30">
          <p className="text-sm">No offers found</p>
          <p className="text-xs mt-1">Best Offer attempts will appear here after dropship orders are placed</p>
        </div>
      ) : (
        <div className="space-y-3">
          {offers.map((offer: any) => (
            <div key={offer.orderId} className="bg-white/5 border border-white/10 rounded-lg p-4">
              <div className="flex items-start justify-between gap-4">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-2 flex-wrap">
                    <Badge className={`text-xs border ${offerStatusColors[offer.ebayOfferStatus] || "bg-white/10 text-white/40"}`}>
                      {offerStatusLabels[offer.ebayOfferStatus] || offer.ebayOfferStatus}
                    </Badge>
                    <span className="text-white/40 text-xs">Order #{offer.orderId}</span>
                    <span className="text-white/40 text-xs">·</span>
                    <span className="text-white/40 text-xs">{offer.ticketNumber}</span>
                  </div>
                  <div className="text-white font-medium text-sm mb-1 truncate">{offer.cardTitle}</div>
                  <div className="grid grid-cols-2 gap-x-6 gap-y-1 text-xs mt-2">
                    <div><span className="text-white/40">Buyer: </span><span className="text-white/80">{offer.buyerEmail}</span></div>
                    <div><span className="text-white/40">Sale: </span><span className="text-green-400">${parseFloat(offer.totalAmount || "0").toFixed(2)}</span></div>
                    {offer.cardSourcePrice && (
                      <div><span className="text-white/40">eBay ask: </span><span className="text-white/80">${parseFloat(offer.cardSourcePrice).toFixed(2)}</span></div>
                    )}
                    {offer.ebayOfferAmount && (
                      <div><span className="text-white/40">Offer sent: </span><span className="text-blue-300">${parseFloat(offer.ebayOfferAmount).toFixed(2)}</span></div>
                    )}
                    {offer.ebayOfferSavings && parseFloat(offer.ebayOfferSavings) > 0 && (
                      <div><span className="text-white/40">Savings: </span><span className="text-green-400 font-semibold">+${parseFloat(offer.ebayOfferSavings).toFixed(2)}</span></div>
                    )}
                    {offer.ebayOfferSentAt && (
                      <div className="col-span-2"><span className="text-white/40">Sent: </span><span className="text-white/60">{new Date(offer.ebayOfferSentAt).toLocaleString()}</span></div>
                    )}
                    {offer.ebayOfferRespondedAt && (
                      <div className="col-span-2"><span className="text-white/40">Responded: </span><span className="text-white/60">{new Date(offer.ebayOfferRespondedAt).toLocaleString()}</span></div>
                    )}
                  </div>
                </div>
                <div className="flex flex-col gap-2 shrink-0">
                  {offer.ebayFulfillmentLink && (
                    <a href={offer.ebayFulfillmentLink} target="_blank" rel="noopener noreferrer"
                      className="inline-flex items-center gap-1 px-3 py-1.5 bg-[#E8C547] text-black text-xs font-bold rounded hover:bg-[#d4b23f] transition-colors">
                      <ExternalLink className="w-3 h-3" /> Buy on eBay
                    </a>
                  )}
                  {offer.cardEbayItemId && (offer.ebayOfferStatus === "declined" || offer.ebayOfferStatus === "expired" || offer.ebayOfferStatus === "countered") && !offer.dropshipFulfilledAt && (
                    <Button size="sm"
                      onClick={() => attemptOffer.mutate({
                        orderId: offer.orderId,
                        ebayItemId: offer.cardEbayItemId,
                        askingPrice: parseFloat(offer.cardSourcePrice || offer.totalAmount || "0"),
                      })}
                      disabled={attemptOffer.isPending}
                      className="h-7 text-xs bg-blue-600 hover:bg-blue-700 text-white">
                      Retry Offer
                    </Button>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ─── eBay Import Tab ─────────────────────────────────────────────
function EbayImportTab({ isAdmin }: { isAdmin: boolean }) {
  const [sport, setSport] = useState<string>("all");
  const [limit, setLimit] = useState("20");
  const [isRunning, setIsRunning] = useState(false);
  const [result, setResult] = useState<{ imported: number; skipped: number; errors: string[] } | null>(null);
  const [isChecking, setIsChecking] = useState(false);
  const [checkResult, setCheckResult] = useState<{ checked: number; deleted: number; stillActive: number; deletedTitles: string[] } | null>(null);
  const [isDedupRunning, setIsDedupRunning] = useState(false);
  const [dedupResult, setDedupResult] = useState<{ mergedGroups: number; deletedCards: number; mergedTitles: string[] } | null>(null);

  const { data: lastRun } = trpc.admin.getLastAvailabilityRun.useQuery(undefined, { refetchInterval: 10000 });
  const runAvailabilityCheck = trpc.admin.runAvailabilityCheck.useMutation({
    onMutate: () => { setIsChecking(true); setCheckResult(null); },
    onSuccess: (data) => {
      setIsChecking(false);
      setCheckResult(data);
      if (data.deleted > 0) {
        toast.success(`Removed ${data.deleted} unavailable card${data.deleted !== 1 ? 's' : ''} from marketplace`);
      } else if (data.checked === 0) {
        toast.info("No eBay dropship cards found to check.");
      } else {
        toast.success(`All ${data.checked} eBay cards are still available!`);
      }
    },
    onError: (e: { message?: string }) => { setIsChecking(false); toast.error(e.message || "Availability check failed"); },
  });

  const runDedup = trpc.admin.deduplicateCards.useMutation({
    onMutate: () => { setIsDedupRunning(true); setDedupResult(null); },
    onSuccess: (data) => {
      setIsDedupRunning(false);
      setDedupResult(data);
      if (data.mergedGroups > 0) {
        toast.success(`Merged ${data.mergedGroups} duplicate group${data.mergedGroups !== 1 ? 's' : ''}, removed ${data.deletedCards} duplicate card${data.deletedCards !== 1 ? 's' : ''}`);
      } else {
        toast.success('No duplicates found — inventory is clean!');
      }
    },
    onError: (e: { message?: string }) => { setIsDedupRunning(false); toast.error(e.message || 'Dedup failed'); },
  });

  const runImport = trpc.admin.importEbayCards.useMutation({
    onMutate: () => { setIsRunning(true); setResult(null); },
    onSuccess: (data: { imported: number; skipped: number; errors: string[] }) => { setIsRunning(false); setResult(data); toast.success(`Imported ${data.imported} cards!`); },
    onError: (e: { message?: string }) => { setIsRunning(false); toast.error(e.message || "Import failed"); },
  });

  const sports = ["all", "basketball", "wnba", "football", "baseball", "hockey", "soccer", "golf"];

  return (
    <div className="bg-[#0d1f3c] border border-white/10 rounded-xl p-4">
      <div className="flex items-center gap-2 mb-4">
        <Download className="w-4 h-4 text-[#C41E3A]" />
        <h3 className="text-white font-bold text-sm">eBay Dropship Import</h3>
      </div>

      <p className="text-white/50 text-xs mb-4">
        Imports top trending cards from eBay across all sports. Cards are marked up 20% and listed with their eBay shipping cost.
        PSA/BGS/SGC graded cards keep their grade label. Duplicates are skipped automatically.
      </p>

      <div className="flex gap-3 mb-4 flex-wrap">
        <Select value={sport} onValueChange={setSport}>
          <SelectTrigger className="w-36 h-8 text-xs bg-white/5 border-white/10 text-white">
            <SelectValue placeholder="Sport" />
          </SelectTrigger>
          <SelectContent className="bg-[#0d1f3c] border-white/10">
            {sports.map(s => (
              <SelectItem key={s} value={s} className="text-white hover:bg-white/10 capitalize">{s === "all" ? "All Sports" : s}</SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Input
          type="number"
          placeholder="Cards per player"
          value={limit}
          onChange={e => setLimit(e.target.value)}
          className="w-36 h-8 text-xs bg-white/5 border-white/10 text-white placeholder:text-white/30"
          min="5"
          max="50"
        />

        <Button
          onClick={() => runImport.mutate({ sport: sport === "all" ? undefined : sport, cardsPerPlayer: parseInt(limit) || 3 })}
          disabled={isRunning || !isAdmin}
          className="h-8 text-xs bg-[#C41E3A] hover:bg-[#a01830] text-white"
        >
          {isRunning ? (
            <><RefreshCw className="w-3 h-3 mr-1 animate-spin" /> Importing...</>
          ) : (
            <><Download className="w-3 h-3 mr-1" /> Run Import</>
          )}
        </Button>
        <Button
          onClick={() => runAvailabilityCheck.mutate()}
          disabled={isChecking || !isAdmin}
          className="h-8 text-xs bg-emerald-600 hover:bg-emerald-700 text-white"
          title="Verify all eBay cards are still listed and remove unavailable ones"
        >
          {isChecking ? (
            <><RefreshCw className="w-3 h-3 mr-1 animate-spin" /> Checking...</>
          ) : (
            <><CheckCircle className="w-3 h-3 mr-1" /> Availability</>
          )}
        </Button>
        <Button
          onClick={() => runDedup.mutate()}
          disabled={isDedupRunning || !isAdmin}
          className="h-8 text-xs bg-purple-600 hover:bg-purple-700 text-white"
          title="Merge duplicate eBay cards into single listings with qty, using highest price"
        >
          {isDedupRunning ? (
            <><RefreshCw className="w-3 h-3 mr-1 animate-spin" /> Merging...</>
          ) : (
            <><Layers className="w-3 h-3 mr-1" /> Dedup Cards</>
          )}
        </Button>
      </div>

      {checkResult && (
        <div className="grid grid-cols-3 gap-3 mt-4">
          <div className="bg-blue-500/10 border border-blue-500/20 rounded-lg p-3 text-center">
            <div className="text-2xl font-black text-blue-400">{checkResult.checked}</div>
            <div className="text-xs text-white/40">Checked</div>
          </div>
          <div className="bg-green-500/10 border border-green-500/20 rounded-lg p-3 text-center">
            <div className="text-2xl font-black text-green-400">{checkResult.stillActive}</div>
            <div className="text-xs text-white/40">Still Active</div>
          </div>
          <div className="bg-red-500/10 border border-red-500/20 rounded-lg p-3 text-center">
            <div className="text-2xl font-black text-red-400">{checkResult.deleted}</div>
            <div className="text-xs text-white/40">Removed</div>
          </div>
          {checkResult.deletedTitles.length > 0 && (
            <div className="col-span-3 bg-red-500/5 border border-red-500/20 rounded-lg p-3">
              <p className="text-red-400 text-xs font-semibold mb-2">Removed listings:</p>
              <ul className="space-y-1">
                {checkResult.deletedTitles.slice(0, 10).map((t, i) => (
                  <li key={i} className="text-white/50 text-xs truncate">• {t}</li>
                ))}
                {checkResult.deletedTitles.length > 10 && (
                  <li className="text-white/30 text-xs">...and {checkResult.deletedTitles.length - 10} more</li>
                )}
              </ul>
            </div>
          )}
        </div>
      )}

      {dedupResult && (
        <div className="grid grid-cols-2 gap-3 mt-4">
          <div className="bg-purple-500/10 border border-purple-500/20 rounded-lg p-3 text-center">
            <div className="text-2xl font-black text-purple-400">{dedupResult.mergedGroups}</div>
            <div className="text-xs text-white/40">Groups Merged</div>
          </div>
          <div className="bg-red-500/10 border border-red-500/20 rounded-lg p-3 text-center">
            <div className="text-2xl font-black text-red-400">{dedupResult.deletedCards}</div>
            <div className="text-xs text-white/40">Duplicates Removed</div>
          </div>
          {dedupResult.mergedTitles.length > 0 && (
            <div className="col-span-2 bg-purple-500/5 border border-purple-500/20 rounded-lg p-3">
              <p className="text-purple-400 text-xs font-semibold mb-2">Merged listings:</p>
              <ul className="space-y-1">
                {dedupResult.mergedTitles.slice(0, 10).map((t, i) => (
                  <li key={i} className="text-white/50 text-xs truncate">• {t}</li>
                ))}
                {dedupResult.mergedTitles.length > 10 && (
                  <li className="text-white/30 text-xs">...and {dedupResult.mergedTitles.length - 10} more</li>
                )}
              </ul>
            </div>
          )}
        </div>
      )}

      {result && (
        <div className="grid grid-cols-3 gap-3 mt-4">
          <div className="bg-green-500/10 border border-green-500/20 rounded-lg p-3 text-center">
            <div className="text-2xl font-black text-green-400">{result.imported}</div>
            <div className="text-xs text-white/40">Imported</div>
          </div>
          <div className="bg-white/5 border border-white/10 rounded-lg p-3 text-center">
            <div className="text-2xl font-black text-white/60">{result.skipped}</div>
            <div className="text-xs text-white/40">Skipped (dupes)</div>
          </div>
          <div className="bg-red-500/10 border border-red-500/20 rounded-lg p-3 text-center">
            <div className="text-2xl font-black text-red-400">{result.errors.length}</div>
            <div className="text-xs text-white/40">Errors</div>
          </div>
        </div>
      )}

      <div className="mt-4 p-3 bg-[#E8C547]/10 border border-[#E8C547]/20 rounded-lg">
        <p className="text-[#E8C547] text-xs font-semibold mb-1">💡 Tip: Schedule Daily Imports</p>
        <p className="text-white/50 text-xs">
          Run this daily to keep your inventory fresh. Cards that sell on eBay are automatically delisted when a buyer attempts checkout.
        </p>
      </div>
    </div>
  );
}

// ─── Create Shipping Label Modal ─────────────────────────────────────────────
interface CreateLabelModalProps {
  order: { id: number; buyerEmail: string; cardTitle: string; shippingAddress: string | null; totalAmount: string | null };
  parsedAddr: Record<string, string> | null;
  onClose: () => void;
  onSubmit: (fields: {
    toName: string; toStreet1: string; toStreet2?: string;
    toCity: string; toState: string; toZip: string; toCountry: string;
    toPhone?: string; toEmail?: string;
    weightOz?: number; insuredValue?: number;
  }) => void;
  isPending: boolean;
}

function CreateLabelModal({ order, parsedAddr, onClose, onSubmit, isPending }: CreateLabelModalProps) {
  const [toName, setToName] = useState(parsedAddr?.name ?? "");
  const [toStreet1, setToStreet1] = useState(parsedAddr?.street1 ?? parsedAddr?.address1 ?? "");
  const [toStreet2, setToStreet2] = useState(parsedAddr?.street2 ?? parsedAddr?.address2 ?? "");
  const [toCity, setToCity] = useState(parsedAddr?.city ?? "");
  const [toState, setToState] = useState(parsedAddr?.state ?? "");
  const [toZip, setToZip] = useState(parsedAddr?.zip ?? parsedAddr?.postal_code ?? "");
  const [toCountry, setToCountry] = useState(parsedAddr?.country ?? "US");
  const [toPhone, setToPhone] = useState(parsedAddr?.phone ?? "");
  const [toEmail, setToEmail] = useState(order.buyerEmail ?? "");
  const [weightOz, setWeightOz] = useState("2");
  const [insuredValue, setInsuredValue] = useState(order.totalAmount ? parseFloat(order.totalAmount).toFixed(2) : "");

  const handleSubmit = () => {
    if (!toName || !toStreet1 || !toCity || !toState || !toZip) {
      return;
    }
    onSubmit({
      toName, toStreet1, toStreet2: toStreet2 || undefined,
      toCity, toState, toZip, toCountry,
      toPhone: toPhone || undefined, toEmail: toEmail || undefined,
      weightOz: parseFloat(weightOz) || 2,
      insuredValue: insuredValue ? parseFloat(insuredValue) : undefined,
    });
  };

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent className="bg-[#0d1f3c] border border-white/10 text-white max-w-lg">
        <DialogHeader>
          <DialogTitle className="text-white flex items-center gap-2">
            <PackagePlus className="w-5 h-5 text-blue-400" />
            Create Shipping Label — Order #{order.id}
          </DialogTitle>
          <p className="text-white/50 text-xs mt-1">{order.cardTitle}</p>
        </DialogHeader>

        <div className="space-y-3 py-2">
          <div className="grid grid-cols-2 gap-3">
            <div className="col-span-2">
              <Label className="text-xs text-white/60 mb-1 block">Recipient Name *</Label>
              <Input value={toName} onChange={e => setToName(e.target.value)} placeholder="John Smith"
                className="h-8 text-xs bg-white/5 border-white/10 text-white placeholder:text-white/20" />
            </div>
            <div className="col-span-2">
              <Label className="text-xs text-white/60 mb-1 block">Street Address *</Label>
              <Input value={toStreet1} onChange={e => setToStreet1(e.target.value)} placeholder="123 Main St"
                className="h-8 text-xs bg-white/5 border-white/10 text-white placeholder:text-white/20" />
            </div>
            <div className="col-span-2">
              <Label className="text-xs text-white/60 mb-1 block">Apt / Suite</Label>
              <Input value={toStreet2} onChange={e => setToStreet2(e.target.value)} placeholder="Apt 4B"
                className="h-8 text-xs bg-white/5 border-white/10 text-white placeholder:text-white/20" />
            </div>
            <div>
              <Label className="text-xs text-white/60 mb-1 block">City *</Label>
              <Input value={toCity} onChange={e => setToCity(e.target.value)} placeholder="Columbus"
                className="h-8 text-xs bg-white/5 border-white/10 text-white placeholder:text-white/20" />
            </div>
            <div>
              <Label className="text-xs text-white/60 mb-1 block">State *</Label>
              <Input value={toState} onChange={e => setToState(e.target.value)} placeholder="OH" maxLength={2}
                className="h-8 text-xs bg-white/5 border-white/10 text-white placeholder:text-white/20" />
            </div>
            <div>
              <Label className="text-xs text-white/60 mb-1 block">ZIP *</Label>
              <Input value={toZip} onChange={e => setToZip(e.target.value)} placeholder="43215"
                className="h-8 text-xs bg-white/5 border-white/10 text-white placeholder:text-white/20" />
            </div>
            <div>
              <Label className="text-xs text-white/60 mb-1 block">Country</Label>
              <Input value={toCountry} onChange={e => setToCountry(e.target.value)} placeholder="US" maxLength={2}
                className="h-8 text-xs bg-white/5 border-white/10 text-white placeholder:text-white/20" />
            </div>
            <div>
              <Label className="text-xs text-white/60 mb-1 block">Phone</Label>
              <Input value={toPhone} onChange={e => setToPhone(e.target.value)} placeholder="6145551234"
                className="h-8 text-xs bg-white/5 border-white/10 text-white placeholder:text-white/20" />
            </div>
            <div>
              <Label className="text-xs text-white/60 mb-1 block">Email</Label>
              <Input value={toEmail} onChange={e => setToEmail(e.target.value)} placeholder="buyer@email.com"
                className="h-8 text-xs bg-white/5 border-white/10 text-white placeholder:text-white/20" />
            </div>
          </div>

          <div className="border-t border-white/10 pt-3 grid grid-cols-2 gap-3">
            <div>
              <Label className="text-xs text-white/60 mb-1 block">Weight (oz)</Label>
              <Input value={weightOz} onChange={e => setWeightOz(e.target.value)} type="number" min="0.5" step="0.5"
                className="h-8 text-xs bg-white/5 border-white/10 text-white"
                placeholder="2 oz (default: card + bubble mailer)" />
              <p className="text-white/30 text-xs mt-1">Default: 2 oz (card + toploader + bubble mailer)</p>
            </div>
            <div>
              <Label className="text-xs text-white/60 mb-1 block">Insured Value ($)</Label>
              <Input value={insuredValue} onChange={e => setInsuredValue(e.target.value)} type="number" min="0" step="0.01"
                className="h-8 text-xs bg-white/5 border-white/10 text-white" placeholder="0.00" />
            </div>
          </div>

          <div className="bg-blue-500/10 border border-blue-500/20 rounded-lg p-2">
            <p className="text-blue-300 text-xs">Parcel: 6.5" × 4.5" × 0.5" bubble mailer · USPS First Class / Ground Advantage · Cheapest rate selected automatically</p>
          </div>
        </div>

        <DialogFooter className="gap-2">
          <Button variant="ghost" onClick={onClose} className="text-white/60 hover:bg-white/10">Cancel</Button>
          <Button
            onClick={handleSubmit}
            disabled={isPending || !toName || !toStreet1 || !toCity || !toState || !toZip}
            className="bg-blue-600 hover:bg-blue-700 text-white"
          >
            {isPending ? (
              <><RefreshCw className="w-4 h-4 mr-2 animate-spin" />Creating Label...</>
            ) : (
              <><PackagePlus className="w-4 h-4 mr-2" />Create & Purchase Label</>
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ─── Blog Management Tab ─────────────────────────────────────────────────────
function BlogManagementTab() {
  const utils = trpc.useUtils();
  const [topic, setTopic] = useState("");
  const [sport, setSport] = useState<string | undefined>(undefined);
  const [generatingVideo, setGeneratingVideo] = useState<number | null>(null);
  const [publishingYt, setPublishingYt] = useState<number | null>(null);
  const [previewTagsPost, setPreviewTagsPost] = useState<{ id: number; title: string; youtubeAutoTags: string | null; youtubeAutoLinks: string | null } | null>(null);

  const { data: posts, isLoading, refetch } = trpc.admin.listBlogPosts.useQuery({ limit: 50 });

  const generateMutation = trpc.admin.generateBlogPost.useMutation({
    onSuccess: () => {
      toast.success("Blog post generated successfully!");
      setTopic("");
      setSport(undefined);
      refetch();
    },
    onError: (e) => toast.error(`Generation failed: ${e.message}`),
  });

  const generateVideoMutation = trpc.admin.generateBlogVideo.useMutation({
    onSuccess: (_, vars) => {
      toast.success("Video generated and uploaded to S3!");
      setGeneratingVideo(null);
      refetch();
    },
    onError: (e, vars) => {
      toast.error(`Video failed: ${e.message}`);
      setGeneratingVideo(null);
    },
  });

  const publishYtMutation = trpc.admin.publishBlogVideoToYouTube.useMutation({
    onSuccess: (data) => {
      toast.success(`Published to YouTube! ${data.youtubeUrl}`);
      setPublishingYt(null);
      refetch();
    },
    onError: (e, vars) => {
      toast.error(`YouTube upload failed: ${e.message}`);
      setPublishingYt(null);
    },
  });

  const deleteMutation = trpc.admin.deleteBlogPost.useMutation({
    onSuccess: () => { toast.success("Post deleted"); refetch(); },
    onError: (e) => toast.error(e.message),
  });

  const statusColor = (s: string | null) => {
    if (!s || s === "none") return "text-white/30";
    if (s === "published") return "text-green-400";
    if (s === "generating") return "text-yellow-400 animate-pulse";
    if (s === "ready") return "text-blue-400";
    if (s === "error") return "text-red-400";
    return "text-white/50";
  };

  return (
    <div className="bg-[#0d1f3c] border border-white/10 rounded-xl p-4 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h2 className="text-white font-bold text-lg">Blog Management</h2>
          <p className="text-white/40 text-xs mt-0.5">
            Daily posts auto-generate at 7:00 AM · Videos upload to S3 · YouTube upload requires OAuth credentials
          </p>
        </div>
        <Button
          size="sm"
          onClick={() => refetch()}
          variant="outline"
          className="border-white/20 text-white/60 hover:bg-white/10 text-xs"
        >
          <RefreshCw className="w-3.5 h-3.5 mr-1.5" /> Refresh
        </Button>
      </div>

      {/* Manual generation form */}
      <div className="bg-white/5 border border-white/10 rounded-xl p-4">
        <h3 className="text-white/80 font-semibold text-sm mb-3">Generate Post Manually</h3>
        <div className="flex gap-3 flex-wrap">
          <Input
            value={topic}
            onChange={(e) => setTopic(e.target.value)}
            placeholder="Optional topic (e.g. 'Shohei Ohtani rookie cards')"
            className="flex-1 min-w-48 h-8 text-xs bg-white/5 border-white/10 text-white placeholder:text-white/20"
          />
          <Select value={sport ?? "__none"} onValueChange={(v) => setSport(v === "__none" ? undefined : v)}>
            <SelectTrigger className="w-36 h-8 text-xs bg-white/5 border-white/10 text-white">
              <SelectValue placeholder="Sport" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="__none">Any Sport</SelectItem>
              <SelectItem value="baseball">Baseball</SelectItem>
              <SelectItem value="basketball">Basketball</SelectItem>
              <SelectItem value="football">Football</SelectItem>
              <SelectItem value="hockey">Hockey</SelectItem>
            </SelectContent>
          </Select>
          <Button
            size="sm"
            onClick={() => generateMutation.mutate({ topic: topic || undefined, sport: sport || undefined })}
            disabled={generateMutation.isPending}
            className="bg-[#C41E3A] hover:bg-[#a01830] text-white text-xs h-8"
          >
            {generateMutation.isPending ? (
              <><RefreshCw className="w-3.5 h-3.5 mr-1.5 animate-spin" />Generating...</>
            ) : (
              "Generate Post"
            )}
          </Button>
        </div>
        <p className="text-white/30 text-xs mt-2">
          Fetches trending sports card news from Google News, generates a 700–900 word SEO post, and creates a cover image.
        </p>
      </div>

      {/* YouTube setup notice */}
      <div className="bg-yellow-500/10 border border-yellow-500/20 rounded-xl p-4">
        <h3 className="text-yellow-300 font-semibold text-sm mb-1">YouTube Auto-Upload Setup</h3>
        <p className="text-yellow-200/60 text-xs leading-relaxed">
          To enable automatic YouTube uploads, add these secrets in <strong>Settings → Secrets</strong>:
          <br />• <code className="bg-white/10 px-1 rounded">YOUTUBE_CLIENT_ID</code> — from Google Cloud Console OAuth 2.0 credentials
          <br />• <code className="bg-white/10 px-1 rounded">YOUTUBE_CLIENT_SECRET</code> — from Google Cloud Console
          <br />• <code className="bg-white/10 px-1 rounded">YOUTUBE_REFRESH_TOKEN</code> — obtained via OAuth 2.0 flow
          <br /><br />
          Once configured, videos will auto-upload daily at 7 AM. You can also manually trigger uploads below.
        </p>
      </div>

      {/* Posts table */}
      {isLoading ? (
        <div className="text-white/40 text-sm text-center py-8">Loading posts...</div>
      ) : !posts || posts.length === 0 ? (
        <div className="text-white/40 text-sm text-center py-8">
          No blog posts yet. Generate your first post above or wait for the 7 AM cron job.
        </div>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead>
              <tr className="border-b border-white/10 text-white/40 text-left">
                <th className="pb-2 pr-3 font-medium w-8">#</th>
                <th className="pb-2 pr-3 font-medium">Title</th>
                <th className="pb-2 pr-3 font-medium w-20">Sport</th>
                <th className="pb-2 pr-3 font-medium w-24">Status</th>
                <th className="pb-2 pr-3 font-medium w-24">Video</th>
                <th className="pb-2 pr-3 font-medium w-24">YouTube</th>
                <th className="pb-2 pr-3 font-medium w-28">Published</th>
                <th className="pb-2 font-medium w-32">Actions</th>
              </tr>
            </thead>
            <tbody>
              {posts.map((post) => (
                <tr key={post.id} className="border-b border-white/5 hover:bg-white/5 transition-colors">
                  <td className="py-2 pr-3 text-white/30">{post.id}</td>
                  <td className="py-2 pr-3">
                    <div className="flex items-start gap-2">
                      {post.coverImageUrl && (
                        <img src={post.coverImageUrl} alt="" className="w-10 h-7 object-cover rounded shrink-0 opacity-80" />
                      )}
                      <div>
                        <a
                          href={`/blog/${post.slug}`}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-white hover:text-[#C41E3A] font-medium line-clamp-1 transition-colors"
                        >
                          {post.title}
                        </a>
                        <p className="text-white/30 text-xs line-clamp-1 mt-0.5">{post.excerpt}</p>
                      </div>
                    </div>
                  </td>
                  <td className="py-2 pr-3 text-white/50 capitalize">{post.sport ?? "—"}</td>
                  <td className="py-2 pr-3">
                    <span className={`capitalize font-medium ${post.status === "published" ? "text-green-400" : "text-yellow-400"}`}>
                      {post.status}
                    </span>
                  </td>
                  <td className="py-2 pr-3">
                    <span className={`capitalize font-medium ${statusColor(post.videoStatus)}`}>
                      {post.videoStatus ?? "none"}
                    </span>
                    {post.videoUrl && (
                      <a href={post.videoUrl} target="_blank" rel="noopener noreferrer" className="ml-1 text-blue-400 hover:text-blue-300">
                        <ExternalLink className="w-3 h-3 inline" />
                      </a>
                    )}
                  </td>
                  <td className="py-2 pr-3">
                    {post.youtubeVideoId ? (
                      <a
                        href={`https://www.youtube.com/watch?v=${post.youtubeVideoId}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-red-400 hover:text-red-300 flex items-center gap-1"
                      >
                        <ExternalLink className="w-3 h-3" /> View
                      </a>
                    ) : (
                      <span className="text-white/20">—</span>
                    )}
                  </td>
                  <td className="py-2 pr-3 text-white/40">
                    {post.publishedAt ? new Date(post.publishedAt).toLocaleDateString() : "—"}
                  </td>
                  <td className="py-2">
                    <div className="flex items-center gap-1.5 flex-wrap">
                      {/* Generate video */}
                      {(!post.videoStatus || post.videoStatus === "none" || post.videoStatus === "error") && (
                        <Button
                          size="sm"
                          variant="outline"
                          className="h-6 px-2 text-xs border-blue-500/30 text-blue-400 hover:bg-blue-500/10"
                          disabled={generatingVideo === post.id}
                          onClick={() => {
                            setGeneratingVideo(post.id);
                            generateVideoMutation.mutate({ postId: post.id });
                          }}
                        >
                          {generatingVideo === post.id ? (
                            <RefreshCw className="w-3 h-3 animate-spin" />
                          ) : (
                            "Video"
                          )}
                        </Button>
                      )}
                      {/* Upload to YouTube */}
                      {post.videoStatus === "ready" && !post.youtubeVideoId && (
                        <Button
                          size="sm"
                          variant="outline"
                          className="h-6 px-2 text-xs border-red-500/30 text-red-400 hover:bg-red-500/10"
                          disabled={publishingYt === post.id}
                          onClick={() => {
                            setPublishingYt(post.id);
                            publishYtMutation.mutate({ postId: post.id });
                          }}
                        >
                          {publishingYt === post.id ? (
                            <RefreshCw className="w-3 h-3 animate-spin" />
                          ) : (
                            "YouTube"
                          )}
                        </Button>
                      )}
                      {/* Show auto-tags preview after YouTube publish */}
                      {post.youtubeVideoId && post.youtubeAutoTags && (() => {
                        try {
                          const tags: string[] = JSON.parse(post.youtubeAutoTags);
                          return (
                            <div className="mt-1 flex flex-wrap gap-1">
                              {tags.slice(0, 5).map((tag, i) => (
                                <span key={i} className="px-1.5 py-0.5 rounded text-[10px] bg-red-500/10 text-red-300 border border-red-500/20">
                                  #{tag.replace(/\s+/g, '')}
                                </span>
                              ))}
                              {tags.length > 5 && (
                                <span className="text-[10px] text-white/30">+{tags.length - 5} more</span>
                              )}
                            </div>
                          );
                        } catch { return null; }
                      })()}
                      {/* Preview Tags */}
                      {post.videoStatus === "ready" && (
                        <Button
                          size="sm"
                          variant="outline"
                          className="h-6 px-2 text-xs border-yellow-500/30 text-yellow-400 hover:bg-yellow-500/10"
                          onClick={() => setPreviewTagsPost({ id: post.id, title: post.title, youtubeAutoTags: post.youtubeAutoTags ?? null, youtubeAutoLinks: post.youtubeAutoLinks ?? null })}
                        >
                          🏷️ Tags
                        </Button>
                      )}
                      {/* Delete */}
                      <Button
                        size="sm"
                        variant="ghost"
                        className="h-6 px-2 text-xs text-red-400/60 hover:text-red-400 hover:bg-red-500/10"
                        onClick={() => {
                          if (confirm(`Delete "${post.title}"?`)) {
                            deleteMutation.mutate({ postId: post.id });
                          }
                        }}
                      >
                        <Trash2 className="w-3 h-3" />
                      </Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      {/* Preview Tags Modal */}
      {previewTagsPost && (
        <Dialog open onOpenChange={() => setPreviewTagsPost(null)}>
          <DialogContent className="bg-[#0d1f3c] border border-white/10 text-white max-w-2xl max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="text-white flex items-center gap-2">
                🏷️ YouTube Tags Preview
              </DialogTitle>
              <p className="text-white/50 text-sm mt-1 line-clamp-2">{previewTagsPost.title}</p>
            </DialogHeader>
            <div className="space-y-5 mt-2">
              {/* Tags */}
              <div>
                <h4 className="text-white/70 text-xs font-semibold uppercase tracking-wider mb-2">Auto-Generated Tags ({(() => { try { return JSON.parse(previewTagsPost.youtubeAutoTags ?? '[]').length; } catch { return 0; } })()})</h4>
                {previewTagsPost.youtubeAutoTags ? (
                  <div className="flex flex-wrap gap-1.5">
                    {(() => { try { return JSON.parse(previewTagsPost.youtubeAutoTags) as string[]; } catch { return []; } })().map((tag: string, i: number) => (
                      <span key={i} className="px-2 py-1 rounded-full text-xs bg-red-500/15 text-red-300 border border-red-500/25">#{tag.replace(/\s+/g, '')}</span>
                    ))}
                  </div>
                ) : (
                  <p className="text-white/30 text-sm italic">No tags generated yet. Generate a video first.</p>
                )}
              </div>
              {/* Authoritative Links */}
              <div>
                <h4 className="text-white/70 text-xs font-semibold uppercase tracking-wider mb-2">Authoritative Links in Description</h4>
                {previewTagsPost.youtubeAutoLinks ? (
                  <div className="space-y-1">
                    {(() => { try { return JSON.parse(previewTagsPost.youtubeAutoLinks) as { label: string; url: string }[]; } catch { return []; } })().map((link: { label: string; url: string }, i: number) => (
                      <div key={i} className="flex items-center gap-2 text-sm">
                        <span className="w-2 h-2 rounded-full bg-blue-400 shrink-0" />
                        <span className="text-white/80 font-medium">{link.label}</span>
                        <span className="text-white/30 text-xs truncate">{link.url}</span>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-white/30 text-sm italic">No links generated yet.</p>
                )}
              </div>
            </div>
            <DialogFooter className="mt-4">
              <Button variant="outline" className="border-white/20 text-white/70" onClick={() => setPreviewTagsPost(null)}>Close</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}

// --- Label Color Settings ---------------------------------------------------
const BORDER_OPTIONS: { value: string; label: string; hex: string }[] = [
  { value: "red",    label: "Crimson Red",   hex: "#c41e3a" },
  { value: "blue",   label: "Royal Blue",    hex: "#1d4ed8" },
  { value: "black",  label: "Matte Black",   hex: "#333333" },
  { value: "white",  label: "Pearl White",   hex: "#ffffff" },
  { value: "orange", label: "Flame Orange",  hex: "#f97316" },
];

function LabelColorSettings() {
  const { data: settings, refetch } = trpc.admin.getPlatformSettings.useQuery();
  const [selected, setSelected] = useState<string | null>(null);
  const update = trpc.admin.updatePlatformSettings.useMutation({
    onSuccess: () => { toast.success("Label color updated!"); refetch(); },
    onError: (e) => toast.error(e.message),
  });

  const current = selected ?? settings?.labelBorderColor ?? "red";

  return (
    <div className="bg-[#0d1f3c] border border-white/10 rounded-xl p-6 max-w-2xl">
      <h3 className="text-white font-bold text-lg mb-1 flex items-center gap-2">
        <Award className="w-5 h-5 text-[#C41E3A]" /> SCG Label Border Color
      </h3>
      <p className="text-white/50 text-sm mb-6">
        Choose the default border color for all SCG-graded card slabs on the platform.
        This affects how new graded cards display their label accent color.
      </p>

      <div className="flex flex-col lg:flex-row gap-8 items-start">
        {/* Color picker */}
        <div className="flex-1 space-y-3">
          {BORDER_OPTIONS.map(opt => (
            <button
              key={opt.value}
              onClick={() => setSelected(opt.value)}
              className={`w-full flex items-center gap-3 p-3 rounded-lg border transition-all ${
                current === opt.value
                  ? "border-white/40 bg-white/10"
                  : "border-white/10 bg-white/5 hover:bg-white/10"
              }`}
            >
              <span
                className="w-6 h-6 rounded-full border-2 border-white/20 shrink-0"
                style={{ backgroundColor: opt.hex }}
              />
              <span className="text-white text-sm font-medium">{opt.label}</span>
              {current === opt.value && (
                <span className="ml-auto text-xs text-[#C41E3A] font-bold">SELECTED</span>
              )}
              {settings?.labelBorderColor === opt.value && !selected && (
                <span className="ml-auto text-xs text-green-400 font-bold">ACTIVE</span>
              )}
            </button>
          ))}

          <Button
            className="w-full bg-[#C41E3A] hover:bg-[#a01830] mt-2"
            disabled={update.isPending || !selected || selected === settings?.labelBorderColor}
            onClick={() => selected && update.mutate({ labelBorderColor: selected as any })}
          >
            {update.isPending ? "Saving..." : "Save Label Color"}
          </Button>
        </div>

        {/* Live preview */}
        <div className="shrink-0 flex flex-col items-center gap-2">
          <p className="text-white/40 text-xs uppercase tracking-widest mb-1">Live Preview</p>
          <div style={{ width: 160 }}>
            <SlabFrame
              playerName="CAITLIN CLARK"
              year="2024"
              setName="Panini Prizm WNBA"
              grade="10"
              gradeLabel="GEM MINT"
              labelBorder={current}
              labelBg="white-silk"
              labelMode="with_label"
              imageUrl="https://d2xsxph8kpxj0f.cloudfront.net/310519663482618714/HBSXFxHmEnEJMgVvzKnhpZ/caitlin-clark-auto_ff5f6a76.jpg"
            />
          </div>
          <p className="text-white/30 text-xs mt-1">
            {BORDER_OPTIONS.find(o => o.value === current)?.label ?? current}
          </p>
        </div>
      </div>
    </div>
  );
}

// ─── House Cards Tab ──────────────────────────────────────────────────────────
function HouseCardsTab({ profileCardId, setProfileCardId, deleteCard, refetchCards, isAuthenticated, user }: {
  profileCardId: number | null;
  setProfileCardId: (id: number | null) => void;
  deleteCard: ReturnType<typeof trpc.admin.deleteCardAdmin.useMutation>;
  refetchCards: () => void;
  isAuthenticated: boolean;
  user: { role?: string } | null | undefined;
}) {
  const [search, setSearch] = useState("");
  const [sport, setSport] = useState("all");
  const [statusFilter, setStatusFilter] = useState("all");
  const { data: cards, refetch } = trpc.admin.listAllCards.useQuery(
    { limit: 1000, source: "house", sport: sport !== "all" ? sport : undefined, search: search || undefined },
    { enabled: isAuthenticated && user?.role === "admin" }
  );
  const filtered = statusFilter === "all" ? cards : cards?.filter(c => c.status === statusFilter);
  return (
    <div className="bg-[#0d1f3c] border border-white/10 rounded-xl p-4">
      <div className="flex items-center gap-2 mb-4 flex-wrap">
        <span className="text-[#ffd700] font-bold text-sm">🏠 House Inventory</span>
        <span className="text-white/30 text-xs">({filtered?.length ?? 0} cards)</span>
        <Input placeholder="Search player, title, set..." value={search} onChange={e => setSearch(e.target.value)} className="w-48 h-8 text-xs bg-white/5 border-white/10 text-white placeholder:text-white/30 ml-2" />
        <div className="flex items-center gap-1 bg-white/5 rounded-lg p-1">
          {(["all","active","sold","auction","pending"] as const).map(s => (
            <button key={s} onClick={() => setStatusFilter(s)} className={`text-xs px-2.5 py-1 rounded-md font-medium transition-colors capitalize ${statusFilter === s ? "bg-[#ffd700] text-[#0a1628]" : "text-white/40 hover:text-white"}`}>{s}</button>
          ))}
        </div>
        <div className="flex items-center gap-1 bg-white/5 rounded-lg p-1">
          {(["all","baseball","basketball","football","hockey","soccer"] as const).map(s => (
            <button key={s} onClick={() => setSport(s)} className={`text-xs px-2 py-1 rounded-md font-medium transition-colors capitalize ${sport === s ? "bg-[#C41E3A] text-white" : "text-white/40 hover:text-white"}`}>{s === "all" ? "All Sports" : s}</button>
          ))}
        </div>
      </div>
      <AdminTable headers={["ID","Card","Player","Sport","Price","Grade","Status",""]}>
        {filtered?.map(card => (
          <TR key={card.id} className="cursor-pointer" onClick={() => setProfileCardId(card.id)}>
            <TD className="font-mono text-xs text-white/40">{card.id}</TD>
            <TD>
              <div className="flex items-center gap-2">
                {card.frontImageUrl && <img src={card.frontImageUrl} alt="" className="w-7 h-9 object-cover rounded" />}
                <div className="font-medium text-xs text-white line-clamp-1">{card.title}</div>
              </div>
            </TD>
            <TD className="text-xs text-white/60">{card.playerName}</TD>
            <TD className="text-xs text-white/40 capitalize">{card.sport}</TD>
            <TD className="font-semibold text-green-400 text-xs">${parseFloat(card.price ?? "0").toFixed(2)}</TD>
            <TD className="text-xs text-white/60">{card.aiGrade ? `SCG ${parseFloat(card.aiGrade).toFixed(1)}` : "Raw"}</TD>
            <TD>
              <Badge className={`text-xs capitalize ${card.status === "active" ? "bg-green-500/20 text-green-400 border-green-500/30" : card.status === "sold" ? "bg-blue-500/20 text-blue-400 border-blue-500/30" : "bg-white/10 text-white/40 border-white/10"}`}>{card.status}</Badge>
            </TD>
            <TD onClick={e => e.stopPropagation()}>
              <Button size="sm" variant="ghost" className="text-red-400 h-7 px-2 hover:bg-red-500/10" onClick={() => { if (!confirm("Delete this card?")) return; deleteCard.mutate({ cardId: card.id }, { onSuccess: () => refetch() }); }}>
                <Trash2 className="w-3 h-3" />
              </Button>
            </TD>
          </TR>
        ))}
      </AdminTable>
      <CardProfileDrawer cardId={profileCardId} onClose={() => setProfileCardId(null)} onDeleted={() => { setProfileCardId(null); refetch(); }} onUpdated={() => refetch()} />
    </div>
  );
}

// ─── eBay Cards Tab ───────────────────────────────────────────────────────────
function EbayCardsTab({ profileCardId, setProfileCardId, deleteCard, refetchCards, isAuthenticated, user }: {
  profileCardId: number | null;
  setProfileCardId: (id: number | null) => void;
  deleteCard: ReturnType<typeof trpc.admin.deleteCardAdmin.useMutation>;
  refetchCards: () => void;
  isAuthenticated: boolean;
  user: { role?: string } | null | undefined;
}) {
  const [search, setSearch] = useState("");
  const [sport, setSport] = useState("all");
  const [statusFilter, setStatusFilter] = useState("all");
  const { data: cards, refetch } = trpc.admin.listAllCards.useQuery(
    { limit: 1000, source: "ebay", sport: sport !== "all" ? sport : undefined, search: search || undefined },
    { enabled: isAuthenticated && user?.role === "admin" }
  );
  const filtered = statusFilter === "all" ? cards : cards?.filter(c => c.status === statusFilter);
  return (
    <div className="bg-[#0d1f3c] border border-white/10 rounded-xl p-4">
      <div className="flex items-center gap-2 mb-4 flex-wrap">
        <span className="text-blue-400 font-bold text-sm">📦 eBay Imported Cards</span>
        <span className="text-white/30 text-xs">({filtered?.length ?? 0} cards)</span>
        <Input placeholder="Search player, title, set..." value={search} onChange={e => setSearch(e.target.value)} className="w-48 h-8 text-xs bg-white/5 border-white/10 text-white placeholder:text-white/30 ml-2" />
        <div className="flex items-center gap-1 bg-white/5 rounded-lg p-1">
          {(["all","active","sold","auction","pending"] as const).map(s => (
            <button key={s} onClick={() => setStatusFilter(s)} className={`text-xs px-2.5 py-1 rounded-md font-medium transition-colors capitalize ${statusFilter === s ? "bg-blue-500 text-white" : "text-white/40 hover:text-white"}`}>{s}</button>
          ))}
        </div>
        <div className="flex items-center gap-1 bg-white/5 rounded-lg p-1">
          {(["all","baseball","basketball","football","hockey","soccer"] as const).map(s => (
            <button key={s} onClick={() => setSport(s)} className={`text-xs px-2 py-1 rounded-md font-medium transition-colors capitalize ${sport === s ? "bg-[#C41E3A] text-white" : "text-white/40 hover:text-white"}`}>{s === "all" ? "All Sports" : s}</button>
          ))}
        </div>
      </div>
      <AdminTable headers={["ID","Card","Player","Sport","Price","Source Price","eBay ID","Status",""]}>
        {filtered?.map(card => (
          <TR key={card.id} className="cursor-pointer" onClick={() => setProfileCardId(card.id)}>
            <TD className="font-mono text-xs text-white/40">{card.id}</TD>
            <TD>
              <div className="flex items-center gap-2">
                {card.frontImageUrl && <img src={card.frontImageUrl} alt="" className="w-7 h-9 object-cover rounded" />}
                <div className="font-medium text-xs text-white line-clamp-1">{card.title}</div>
              </div>
            </TD>
            <TD className="text-xs text-white/60">{card.playerName}</TD>
            <TD className="text-xs text-white/40 capitalize">{card.sport}</TD>
            <TD className="font-semibold text-green-400 text-xs">${parseFloat(card.price ?? "0").toFixed(2)}</TD>
            <TD className="text-xs text-white/40">{card.sourcePrice ? `$${parseFloat(card.sourcePrice).toFixed(2)}` : "—"}</TD>
            <TD className="text-xs text-blue-400 font-mono">{card.ebayItemId ?? "—"}</TD>
            <TD>
              <Badge className={`text-xs capitalize ${card.status === "active" ? "bg-green-500/20 text-green-400 border-green-500/30" : card.status === "sold" ? "bg-blue-500/20 text-blue-400 border-blue-500/30" : "bg-white/10 text-white/40 border-white/10"}`}>{card.status}</Badge>
            </TD>
            <TD onClick={e => e.stopPropagation()}>
              <Button size="sm" variant="ghost" className="text-red-400 h-7 px-2 hover:bg-red-500/10" onClick={() => { if (!confirm("Delete this card?")) return; deleteCard.mutate({ cardId: card.id }, { onSuccess: () => refetch() }); }}>
                <Trash2 className="w-3 h-3" />
              </Button>
            </TD>
          </TR>
        ))}
      </AdminTable>
      <CardProfileDrawer cardId={profileCardId} onClose={() => setProfileCardId(null)} onDeleted={() => { setProfileCardId(null); refetch(); }} onUpdated={() => refetch()} />
    </div>
  );
}
