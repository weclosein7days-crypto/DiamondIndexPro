import { useState, useEffect } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { useGameAudio } from "@/hooks/useGameAudio";

// ─── Types ────────────────────────────────────────────────────────────────────
type Card = { suit: string; value: string };
type Phase = "betting" | "playing" | "dealer" | "result";

// ─── Card Display ─────────────────────────────────────────────────────────────
const SUIT_COLORS: Record<string, string> = { "♠": "#1f2937", "♣": "#1f2937", "♥": "#dc2626", "♦": "#dc2626" };

function PlayingCard({ card, hidden = false, small = false }: { card: Card; hidden?: boolean; small?: boolean }) {
  const size = small ? "w-10 h-14" : "w-16 h-24";
  const textSize = small ? "text-xs" : "text-sm";
  const suitSize = small ? "text-lg" : "text-2xl";

  if (hidden) {
    return (
      <div className={`${size} rounded-lg border-2 border-gray-600 bg-gradient-to-br from-blue-900 to-blue-950 flex items-center justify-center shadow-lg`}>
        <div className="text-blue-600 text-2xl">🂠</div>
      </div>
    );
  }

  const color = SUIT_COLORS[card.suit] || "#1f2937";
  const isRed = card.suit === "♥" || card.suit === "♦";

  return (
    <div className={`${size} rounded-lg border-2 border-gray-300 bg-white flex flex-col items-center justify-between p-1 shadow-lg`}>
      <div className={`${textSize} font-black leading-none`} style={{ color }}>{card.value}</div>
      <div className={`${suitSize} leading-none`} style={{ color }}>{card.suit}</div>
      <div className={`${textSize} font-black leading-none rotate-180`} style={{ color }}>{card.value}</div>
    </div>
  );
}

function HandDisplay({ hand, hidden = false, label, value }: {
  hand: Card[];
  hidden?: boolean;
  label: string;
  value?: number | null;
}) {
  return (
    <div className="flex flex-col items-center gap-2">
      <div className="flex items-center gap-2">
        <span className="text-white/60 text-sm font-semibold">{label}</span>
        {value != null && (
          <span className={`text-sm font-black px-2 py-0.5 rounded-full
            ${value > 21 ? "bg-red-700 text-white" : value === 21 ? "bg-yellow-500 text-black" : "bg-white/20 text-white"}`}>
            {value > 21 ? "BUST" : value}
          </span>
        )}
      </div>
      <div className="flex gap-1 flex-wrap justify-center">
        {hand.map((card, i) => (
          <PlayingCard key={i} card={card} hidden={hidden && i === 1} />
        ))}
      </div>
    </div>
  );
}

// ─── Result Banner ────────────────────────────────────────────────────────────
function ResultBanner({ outcome, winnings }: { outcome: string; winnings: number }) {
  const configs: Record<string, { label: string; cls: string; emoji: string }> = {
    blackjack: { label: "BLACKJACK! 🃏", cls: "bg-yellow-500 text-black", emoji: "🎉" },
    win: { label: "YOU WIN!", cls: "bg-green-600 text-white", emoji: "✅" },
    push: { label: "PUSH — TIE", cls: "bg-blue-600 text-white", emoji: "🤝" },
    bust: { label: "BUST!", cls: "bg-red-700 text-white", emoji: "💥" },
    lose: { label: "DEALER WINS", cls: "bg-red-800 text-white", emoji: "😔" },
  };
  const cfg = configs[outcome] || { label: outcome.toUpperCase(), cls: "bg-gray-700 text-white", emoji: "🃏" };

  return (
    <div className={`${cfg.cls} rounded-2xl px-8 py-4 text-center shadow-2xl border-2 border-white/20`}>
      <div className="text-3xl font-black mb-1">{cfg.emoji} {cfg.label}</div>
      {winnings > 0 && <div className="text-lg font-bold">+{winnings} credits</div>}
      {winnings < 0 && <div className="text-lg font-bold">{winnings} credits</div>}
      {winnings === 0 && <div className="text-sm opacity-70">Bet returned</div>}
    </div>
  );
}

// ─── Main Component ───────────────────────────────────────────────────────────
export default function Blackjack() {
  const { isAuthenticated } = useAuth();
  const { data: account, refetch: refetchAccount } = trpc.credits.myAccount.useQuery(
    undefined, { enabled: isAuthenticated }
  );
  const playBlackjack = trpc.game.playBlackjack.useMutation();

  const [bet, setBet] = useState(5);
  const [lastBet, setLastBet] = useState(5);
  const [phase, setPhase] = useState<Phase>("betting");
  const [playerHand, setPlayerHand] = useState<Card[]>([]);
  const [dealerHand, setDealerHand] = useState<Card[]>([]);
  const [deck, setDeck] = useState<Card[]>([]);
  const [playerVal, setPlayerVal] = useState<number | null>(null);
  const [dealerVal, setDealerVal] = useState<number | null>(null);
  const [outcome, setOutcome] = useState<string | null>(null);
  const [winnings, setWinnings] = useState<number | null>(null);
  const [doubled, setDoubled] = useState(false);
  const [loading, setLoading] = useState(false);

  const MAX_BET = 10;
  const credits = account?.credits ?? 0;
  const audio = useGameAudio();

  const deal = async () => {
    if (!isAuthenticated) { toast.error("Please log in to play"); return; }
    if (bet > credits) { toast.error("Not enough credits"); return; }
    setLoading(true);
    try {
      audio.playChip();
      const res = await playBlackjack.mutateAsync({ bet, action: "deal" });
      // Deal sounds: two cards for player, one for dealer
      audio.playDeal();
      setTimeout(() => audio.playDeal(), 120);
      setTimeout(() => audio.playDeal(), 240);
      setPlayerHand(res.playerHand as Card[]);
      setDealerHand(res.dealerHand as Card[]);
      setDeck(res.deck as Card[]);
      setPlayerVal(res.playerVal);
      setDealerVal(null);
      setDoubled(false);
      if (res.phase === "result") {
        setDealerVal(res.dealerVal ?? null);
        setOutcome(res.outcome ?? null);
        setWinnings(res.winnings ?? null);
        setLastBet(bet);
        setPhase("result");
        refetchAccount();
        // Natural blackjack on deal
        if ((res.outcome === "win" || res.outcome === "blackjack") && (res.winnings ?? 0) > bet) {
          setTimeout(() => audio.playBlackjack(), 300);
        } else if (res.outcome === "bust") {
          setTimeout(() => audio.playLose(), 300);
        } else if (res.outcome === "push") {
          setTimeout(() => audio.playPush(), 300);
        } else if ((res.winnings ?? 0) > 0) {
          setTimeout(() => audio.playWin(), 300);
        }
      } else {
        setPhase("playing");
        setOutcome(null);
        setWinnings(null);
      }
    } catch (e: unknown) {
      toast.error((e as Error).message || "Deal failed");
    }
    setLoading(false);
  };

  const act = async (action: "hit" | "stand" | "double") => {
    setLoading(true);
    try {
      if (action === "hit") audio.playDeal();
      else if (action === "stand") audio.playCheck();
      else if (action === "double") { audio.playChip(); audio.playDeal(); }
      const res = await playBlackjack.mutateAsync({
        bet,
        action,
        gameState: { playerHand, dealerHand, deck, phase, doubled: action === "double" ? true : doubled },
      });
      setPlayerHand(res.playerHand as Card[]);
      setDealerHand(res.dealerHand as Card[]);
      setDeck(res.deck as Card[]);
      setPlayerVal(res.playerVal);
      if (action === "double") setDoubled(true);
      if (res.phase === "result") {
        setDealerVal(res.dealerVal ?? null);
        setOutcome(res.outcome ?? null);
        setWinnings(res.winnings ?? null);
        setLastBet(bet);
        setPhase("result");
        refetchAccount();
        // Result sounds
        const w = res.winnings ?? 0;
        const o = res.outcome ?? "";
        setTimeout(() => {
          if (o === "bust") audio.playLose();
          else if (o === "push") audio.playPush();
          else if (w > 0 && w > bet * 1.4) audio.playBlackjack(); // 3:2 payout
          else if (w > 0) audio.playWin();
          else audio.playLose();
        }, 400);
      }
    } catch (e: unknown) {
      toast.error((e as Error).message || "Action failed");
    }
    setLoading(false);
  };

  const reset = () => {
    setPhase("betting");
    setPlayerHand([]);
    setDealerHand([]);
    setDeck([]);
    setPlayerVal(null);
    setDealerVal(null);
    setOutcome(null);
    setWinnings(null);
    setDoubled(false);
  };

  const canDouble = phase === "playing" && playerHand.length === 2 && bet <= credits;

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#0a1f0a] via-[#0d1a0d] to-[#050d05] text-white">
      {/* Header */}
      <div className="border-b border-green-900/50 bg-black/40 px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Link href="/game-room" className="text-yellow-400 hover:text-yellow-300 text-sm">← Game Room</Link>
          <span className="text-white/30">|</span>
          <h1 className="text-xl font-black text-yellow-400 tracking-wider">🃏 BLACKJACK</h1>
          <span className="text-white/30 text-xs">Dealer stands on 17 · Natural pays 3:2</span>
        </div>
        <div className="flex items-center gap-3">
          <div className="hidden sm:flex items-center gap-1.5 bg-red-600/80 border border-red-400/60 rounded-lg px-3 py-1 animate-pulse">
            <span className="text-white text-xs font-black">🎰 FREE PLAY 4 NOW — No Prizes</span>
          </div>
          <div className="flex items-center gap-2 bg-black/60 border border-yellow-700/40 rounded-lg px-3 py-1.5">
            <span className="text-yellow-400 text-sm font-bold">💰 {credits.toLocaleString()} credits</span>
          </div>
        </div>
      </div>

      {/* Table */}
      <div className="max-w-2xl mx-auto p-6 flex flex-col items-center gap-8">
        {/* Dealer area */}
        <div className="w-full bg-gradient-to-b from-green-900/40 to-green-950/40 border border-green-800/30 rounded-2xl p-6 flex flex-col items-center gap-4">
          <HandDisplay
            hand={dealerHand}
            hidden={phase === "playing"}
            label="Dealer"
            value={phase !== "playing" ? dealerVal : (dealerHand[0] ? (
              dealerHand[0].value === "A" ? 11 :
              ["J","Q","K"].includes(dealerHand[0].value) ? 10 :
              parseInt(dealerHand[0].value)
            ) : null)}
          />

          {/* Felt center */}
          <div className="text-green-700/40 text-xs font-semibold tracking-widest uppercase">
            ♠ SportCardsOnline.com ♠
          </div>

          <HandDisplay
            hand={playerHand}
            label="You"
            value={playerVal}
          />
        </div>

        {/* Result banner */}
        {phase === "result" && outcome && winnings != null && (
          <ResultBanner outcome={outcome} winnings={winnings} />
        )}

        {/* Controls */}
        <div className="w-full flex flex-col gap-4">
          {phase === "betting" && (
            <>
              <div>
                <p className="text-yellow-300/70 text-xs mb-2 font-semibold uppercase tracking-wider">Bet Amount (max {MAX_BET} credits)</p>
                <div className="flex gap-2 flex-wrap">
                  {[1, 2, 5, 10].filter(v => v <= Math.min(MAX_BET, credits)).map(v => (
                    <button key={v} onClick={() => setBet(v)}
                      className={`w-14 h-14 rounded-full font-black text-sm border-2 transition-all
                        ${bet === v ? "bg-yellow-500 border-yellow-300 text-black scale-110 shadow-[0_0_15px_rgba(255,215,0,0.5)]" : "bg-yellow-900/40 border-yellow-700/50 text-yellow-300 hover:scale-105"}`}>
                      {v}
                    </button>
                  ))}
                </div>
                <p className="text-white/30 text-xs mt-2">Current bet: <span className="text-yellow-400 font-bold">{bet} credit{bet !== 1 ? "s" : ""}</span></p>
              </div>
              <Button onClick={deal} disabled={loading || !isAuthenticated || bet > credits}
                className="w-full bg-yellow-500 hover:bg-yellow-400 text-black font-black text-xl h-14 shadow-[0_0_20px_rgba(255,215,0,0.3)]">
                {loading ? "Dealing..." : "🃏 DEAL"}
              </Button>
              {!isAuthenticated && (
                <p className="text-center text-yellow-400/70 text-sm">
                  <Link href="/api/oauth/login" className="underline">Log in</Link> to play for real credits
                </p>
              )}
            </>
          )}

          {phase === "playing" && (
            <div className="flex gap-3">
              <Button onClick={() => act("hit")} disabled={loading}
                className="flex-1 bg-green-600 hover:bg-green-500 text-white font-black text-lg h-12">
                {loading ? "..." : "HIT"}
              </Button>
              <Button onClick={() => act("stand")} disabled={loading}
                className="flex-1 bg-red-700 hover:bg-red-600 text-white font-black text-lg h-12">
                {loading ? "..." : "STAND"}
              </Button>
              {canDouble && (
                <Button onClick={() => act("double")} disabled={loading}
                  className="flex-1 bg-blue-700 hover:bg-blue-600 text-white font-black text-lg h-12">
                  {loading ? "..." : "DOUBLE"}
                </Button>
              )}
            </div>
          )}

          {phase === "result" && (
            <div className="flex gap-2">
              <Button onClick={() => { setBet(lastBet); reset(); }}
                className="flex-1 bg-blue-600 hover:bg-blue-500 text-white font-black text-lg h-14"
                disabled={lastBet > credits}>
                🔁 Repeat ({lastBet}cr)
              </Button>
              <Button onClick={reset}
                className="flex-1 bg-yellow-500 hover:bg-yellow-400 text-black font-black text-lg h-14">
                🔄 New Hand
              </Button>
            </div>
          )}
        </div>

        {/* Rules reminder */}
        <div className="text-white/20 text-xs text-center space-y-0.5">
          <p>Dealer stands on all 17s · Natural blackjack pays 3:2 · Double down on first two cards</p>
          <p>Max bet {MAX_BET} credits · 0.5% house edge</p>
        </div>
      </div>
    </div>
  );
}
