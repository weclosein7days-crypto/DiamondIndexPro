import { Link, useParams } from "wouter";
import { useEffect, useRef } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { CalendarDays, Clock, ChevronLeft, Youtube, ExternalLink, Newspaper, Tag } from "lucide-react";
import { Streamdown } from "streamdown";

function formatDate(d: Date | string | null) {
  if (!d) return "";
  return new Date(d).toLocaleDateString("en-US", { month: "long", day: "numeric", year: "numeric" });
}

function readingTime(content: string) {
  const words = content.split(/\s+/).length;
  return Math.max(1, Math.round(words / 200));
}

export default function BlogPost() {
  const { slug } = useParams<{ slug: string }>();

  const { data: post, isLoading, error } = trpc.blog.getPost.useQuery(
    { slug: slug ?? "" },
    { enabled: !!slug, staleTime: 60_000 }
  );

  const { data: relatedPosts } = trpc.blog.listPosts.useQuery(
    { limit: 4 },
    { staleTime: 60_000 }
  );

  const trackView = trpc.blog.trackView.useMutation();
  const trackClick = trpc.blog.trackClick.useMutation();
  const viewTracked = useRef(false);

  useEffect(() => {
    if (post && !viewTracked.current) {
      viewTracked.current = true;
      trackView.mutate({ postId: post.id, referrer: document.referrer || undefined });
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [post?.id]);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#060d1f] flex items-center justify-center">
        <div className="text-center">
          <div className="w-12 h-12 border-2 border-[#C41E3A] border-t-transparent rounded-full animate-spin mx-auto mb-4" />
          <p className="text-white/40">Loading article...</p>
        </div>
      </div>
    );
  }

  if (error || !post) {
    return (
      <div className="min-h-screen bg-[#060d1f] flex items-center justify-center">
        <div className="text-center">
          <Newspaper className="w-16 h-16 text-white/20 mx-auto mb-4" />
          <h1 className="text-2xl font-bold text-white mb-2">Post Not Found</h1>
          <p className="text-white/40 mb-6">This article doesn't exist or has been removed.</p>
          <Link href="/blog">
            <Button variant="outline" className="border-white/20 text-white hover:bg-white/10">
              <ChevronLeft className="w-4 h-4 mr-2" /> Back to Blog
            </Button>
          </Link>
        </div>
      </div>
    );
  }

  const tags = post.tags ? JSON.parse(post.tags) as string[] : [];
  const related = relatedPosts?.filter(p => p.id !== post.id).slice(0, 3) ?? [];

  return (
    <div className="min-h-screen bg-[#060d1f]">
      {/* Hero */}
      <div className="relative overflow-hidden bg-gradient-to-b from-[#0d1f3c] to-[#060d1f]">
        {post.coverImageUrl && (
          <div className="absolute inset-0">
            <img src={post.coverImageUrl} alt={post.title} className="w-full h-full object-cover opacity-20" />
            <div className="absolute inset-0 bg-gradient-to-b from-[#0d1f3c]/80 via-[#060d1f]/90 to-[#060d1f]" />
          </div>
        )}
        <div className="container max-w-4xl py-12 relative">
          <Link href="/blog">
            <button className="flex items-center gap-2 text-white/50 hover:text-white text-sm mb-8 transition-colors">
              <ChevronLeft className="w-4 h-4" /> Back to Blog
            </button>
          </Link>

          {/* Sport badge */}
          {post.sport && (
            <span className="inline-block text-xs font-medium px-3 py-1 rounded-full border border-[#C41E3A]/30 bg-[#C41E3A]/10 text-[#C41E3A] capitalize mb-4">
              {post.sport}
            </span>
          )}

          <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white leading-tight mb-6">
            {post.title}
          </h1>

          {post.excerpt && (
            <p className="text-white/60 text-lg leading-relaxed mb-6 max-w-3xl">
              {post.excerpt}
            </p>
          )}

          <div className="flex flex-wrap items-center gap-4 text-white/40 text-sm">
            <span className="flex items-center gap-1.5">
              <CalendarDays className="w-4 h-4" />
              {formatDate(post.publishedAt)}
            </span>
            <span className="flex items-center gap-1.5">
              <Clock className="w-4 h-4" />
              {readingTime(post.content)} min read
            </span>
            <span className="text-white/20">·</span>
            <span className="text-white/40">SportsCardsOnline.com</span>
          </div>
        </div>
      </div>

      {/* Main content */}
      <div className="container max-w-4xl pb-16">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Article body */}
          <div className="lg:col-span-2">
            {/* YouTube embed */}
            {post.youtubeVideoId && (
              <div className="mb-8 rounded-2xl overflow-hidden border border-white/10">
                <div className="bg-[#0d1f3c] px-4 py-3 flex items-center gap-2 border-b border-white/10">
                  <Youtube className="w-4 h-4 text-red-500" />
                  <span className="text-white/70 text-sm font-medium">Watch on YouTube</span>
                  <a
                    href={`https://www.youtube.com/watch?v=${post.youtubeVideoId}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="ml-auto flex items-center gap-1 text-xs text-white/40 hover:text-white/70 transition-colors"
                  >
                    Open <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
                <div className="aspect-video">
                  <iframe
                    src={`https://www.youtube.com/embed/${post.youtubeVideoId}`}
                    title={post.title}
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowFullScreen
                    className="w-full h-full"
                  />
                </div>
              </div>
            )}

            {/* Blog content */}
            <div className="prose prose-invert prose-lg max-w-none
              prose-headings:text-white prose-headings:font-bold
              prose-h2:text-2xl prose-h2:mt-8 prose-h2:mb-4 prose-h2:text-white
              prose-h3:text-xl prose-h3:mt-6 prose-h3:mb-3 prose-h3:text-white/90
              prose-p:text-white/70 prose-p:leading-relaxed prose-p:mb-4
              prose-strong:text-white prose-strong:font-semibold
              prose-a:text-[#C41E3A] prose-a:no-underline hover:prose-a:underline
              prose-ul:text-white/70 prose-ol:text-white/70
              prose-li:mb-1
              prose-blockquote:border-l-[#C41E3A] prose-blockquote:text-white/60
              prose-code:text-[#C41E3A] prose-code:bg-white/5 prose-code:px-1 prose-code:rounded
            ">
              <Streamdown>{post.content}</Streamdown>
            </div>

            {/* Tags */}
            {tags.length > 0 && (
              <div className="mt-8 pt-8 border-t border-white/10">
                <div className="flex items-center gap-2 flex-wrap">
                  <Tag className="w-4 h-4 text-white/30" />
                  {tags.map((tag: string) => (
                    <span key={tag} className="text-xs px-3 py-1 rounded-full bg-white/5 border border-white/10 text-white/50 hover:text-white/70 hover:bg-white/10 transition-colors cursor-default">
                      #{tag}
                    </span>
                  ))}
                </div>
              </div>
            )}

            {/* CTA */}
            <div className="mt-10 p-6 bg-gradient-to-br from-[#C41E3A]/10 to-[#0d1f3c] border border-[#C41E3A]/20 rounded-2xl">
              <h3 className="text-white font-bold text-lg mb-2">Ready to Buy or Sell Cards?</h3>
              <p className="text-white/60 text-sm mb-4">
                Browse thousands of graded and raw sports cards on SportsCardsOnline.com. Free card valuations, no sign-up required.
              </p>
              <div className="flex gap-3 flex-wrap">
                <Link href="/">
                  <Button className="bg-[#C41E3A] hover:bg-[#a01830] text-white text-sm">
                    Shop the Marketplace
                  </Button>
                </Link>
                <Link href="/grade">
                  <Button variant="outline" className="border-white/20 text-white hover:bg-white/10 text-sm">
                    Grade Your Cards
                  </Button>
                </Link>
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* YouTube CTA if no embed */}
            {!post.youtubeVideoId && post.youtubeUrl && (
              <div className="bg-[#0d1f3c] border border-white/10 rounded-xl p-4">
                <div className="flex items-center gap-2 mb-3">
                  <Youtube className="w-5 h-5 text-red-500" />
                  <span className="text-white font-semibold text-sm">Watch on YouTube</span>
                </div>
                <a
                  href={post.youtubeUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="block"
                >
                  <Button className="w-full bg-red-600 hover:bg-red-700 text-white text-sm">
                    Watch Video <ExternalLink className="w-3.5 h-3.5 ml-2" />
                  </Button>
                </a>
              </div>
            )}

            {/* Related posts */}
            {related.length > 0 && (
              <div className="bg-[#0d1f3c] border border-white/10 rounded-xl p-4">
                <h3 className="text-white font-semibold text-sm mb-4 flex items-center gap-2">
                  <Newspaper className="w-4 h-4 text-[#C41E3A]" />
                  More Articles
                </h3>
                <div className="space-y-4">
                  {related.map((p) => (
                    <Link key={p.id} href={`/blog/${p.slug}`}>
                      <div className="group cursor-pointer">
                        {p.coverImageUrl && (
                          <div className="h-28 rounded-lg overflow-hidden mb-2">
                            <img
                              src={p.coverImageUrl}
                              alt={p.title}
                              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                            />
                          </div>
                        )}
                        <p className="text-white/80 text-xs font-medium leading-snug group-hover:text-[#C41E3A] transition-colors line-clamp-2">
                          {p.title}
                        </p>
                        <p className="text-white/30 text-xs mt-1">
                          {formatDate(p.publishedAt)}
                        </p>
                      </div>
                    </Link>
                  ))}
                </div>
                <Link href="/blog">
                  <Button variant="ghost" size="sm" className="w-full mt-4 text-white/50 hover:text-white hover:bg-white/10 text-xs">
                    View All Articles
                  </Button>
                </Link>
              </div>
            )}

            {/* Subscribe box */}
            <div className="bg-gradient-to-br from-[#C41E3A]/10 to-[#0d1f3c] border border-[#C41E3A]/20 rounded-xl p-4">
              <Youtube className="w-8 h-8 text-red-500 mb-3" />
              <h3 className="text-white font-semibold text-sm mb-2">Daily Card Videos</h3>
              <p className="text-white/50 text-xs mb-3">
                New videos every morning on trending cards, rookie breakouts, and market moves.
              </p>
              <a
                href="https://www.youtube.com/@SportCardsOnline"
                target="_blank"
                rel="noopener noreferrer"
              >
                <Button className="w-full bg-red-600 hover:bg-red-700 text-white text-xs">
                  Subscribe on YouTube
                </Button>
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
