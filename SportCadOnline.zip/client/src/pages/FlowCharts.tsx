import { useState } from "react";

// ─── Color palette ────────────────────────────────────────────────────────────
const C = {
  bg: "#07111f",
  panel: "#0d1f3c",
  panelBorder: "rgba(255,255,255,0.08)",
  red: "#C41E3A",
  redLight: "#e8294a",
  gold: "#E8C547",
  blue: "#1d4ed8",
  blueLight: "#3b82f6",
  green: "#16a34a",
  greenLight: "#22c55e",
  purple: "#7c3aed",
  purpleLight: "#a78bfa",
  orange: "#ea580c",
  orangeLight: "#fb923c",
  teal: "#0d9488",
  tealLight: "#2dd4bf",
  white: "#ffffff",
  muted: "rgba(255,255,255,0.45)",
  mutedBg: "rgba(255,255,255,0.05)",
};

// ─── Reusable components ──────────────────────────────────────────────────────
function SectionHeader({ emoji, title, subtitle, color }: { emoji: string; title: string; subtitle: string; color: string }) {
  return (
    <div style={{ marginBottom: 32 }}>
      <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 8 }}>
        <span style={{ fontSize: 28 }}>{emoji}</span>
        <h2 style={{ margin: 0, fontSize: 26, fontWeight: 900, color: C.white, fontFamily: "Oswald, sans-serif", letterSpacing: 1 }}>{title}</h2>
        <div style={{ flex: 1, height: 2, background: `linear-gradient(90deg, ${color}, transparent)`, marginLeft: 8 }} />
      </div>
      <p style={{ margin: 0, color: C.muted, fontSize: 14, paddingLeft: 40 }}>{subtitle}</p>
    </div>
  );
}

function FlowStep({ num, label, detail, color, icon, last }: { num: number; label: string; detail?: string; color: string; icon?: string; last?: boolean }) {
  return (
    <div style={{ display: "flex", gap: 0, alignItems: "stretch" }}>
      <div style={{ display: "flex", flexDirection: "column", alignItems: "center", width: 40, flexShrink: 0 }}>
        <div style={{
          width: 36, height: 36, borderRadius: "50%", background: color, display: "flex", alignItems: "center", justifyContent: "center",
          fontWeight: 900, fontSize: 14, color: C.white, flexShrink: 0, boxShadow: `0 0 12px ${color}55`,
        }}>{icon || num}</div>
        {!last && <div style={{ width: 2, flex: 1, background: `linear-gradient(${color}, ${color}33)`, minHeight: 24, margin: "4px 0" }} />}
      </div>
      <div style={{ paddingLeft: 14, paddingBottom: last ? 0 : 20, flex: 1 }}>
        <div style={{ fontWeight: 700, color: C.white, fontSize: 14, lineHeight: 1.3 }}>{label}</div>
        {detail && <div style={{ color: C.muted, fontSize: 12, marginTop: 4, lineHeight: 1.5 }}>{detail}</div>}
      </div>
    </div>
  );
}

function RuleTag({ text, color }: { text: string; color: string }) {
  return (
    <span style={{
      display: "inline-block", background: `${color}22`, border: `1px solid ${color}55`,
      color, borderRadius: 6, padding: "2px 10px", fontSize: 12, fontWeight: 600, marginRight: 6, marginBottom: 6,
    }}>{text}</span>
  );
}

function RevenueCard({ label, value, note, color }: { label: string; value: string; note?: string; color: string }) {
  return (
    <div style={{
      background: `linear-gradient(135deg, ${color}18, ${color}08)`,
      border: `1px solid ${color}44`,
      borderRadius: 12, padding: "16px 20px", flex: 1, minWidth: 140,
    }}>
      <div style={{ color: C.muted, fontSize: 11, fontWeight: 700, textTransform: "uppercase", letterSpacing: 1, marginBottom: 6 }}>{label}</div>
      <div style={{ color, fontSize: 22, fontWeight: 900, fontFamily: "Oswald, sans-serif" }}>{value}</div>
      {note && <div style={{ color: C.muted, fontSize: 11, marginTop: 4 }}>{note}</div>}
    </div>
  );
}

function Card({ children, style }: { children: React.ReactNode; style?: React.CSSProperties }) {
  return (
    <div style={{
      background: C.panel, border: `1px solid ${C.panelBorder}`, borderRadius: 16,
      padding: "24px 28px", marginBottom: 24, ...style,
    }}>
      {children}
    </div>
  );
}

function DecisionBox({ question, yes, no, color }: { question: string; yes: string; no: string; color: string }) {
  return (
    <div style={{ display: "flex", flexDirection: "column", alignItems: "center", margin: "16px 0" }}>
      <div style={{
        background: `${color}22`, border: `2px solid ${color}`, borderRadius: 8, padding: "10px 20px",
        color: C.white, fontWeight: 700, fontSize: 13, textAlign: "center", maxWidth: 260,
        transform: "rotate(-1deg)",
      }}>◆ {question}</div>
      <div style={{ display: "flex", gap: 32, marginTop: 12 }}>
        <div style={{ textAlign: "center" }}>
          <div style={{ color: C.green, fontSize: 11, fontWeight: 700, marginBottom: 4 }}>YES ↓</div>
          <div style={{ background: `${C.green}22`, border: `1px solid ${C.green}55`, borderRadius: 6, padding: "6px 14px", color: C.greenLight, fontSize: 12 }}>{yes}</div>
        </div>
        <div style={{ textAlign: "center" }}>
          <div style={{ color: C.red, fontSize: 11, fontWeight: 700, marginBottom: 4 }}>NO ↓</div>
          <div style={{ background: `${C.red}22`, border: `1px solid ${C.red}55`, borderRadius: 6, padding: "6px 14px", color: "#f87171", fontSize: 12 }}>{no}</div>
        </div>
      </div>
    </div>
  );
}

// ─── Sections ─────────────────────────────────────────────────────────────────

function PurchaseFlow() {
  return (
    <div id="purchase">
      <SectionHeader emoji="🛒" title="MARKETPLACE PURCHASE FLOW" subtitle="Single card buy-now from the Arena — House cards and seller cards" color={C.blue} />
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20 }}>
        <Card>
          <div style={{ fontWeight: 800, color: C.blueLight, fontSize: 15, marginBottom: 16, textTransform: "uppercase", letterSpacing: 1 }}>Step-by-Step Flow</div>
          <FlowStep num={1} color={C.blue} label="Buyer finds card in Marketplace" detail="Cards show price, grade, seller, sport. eBay cards show 'e' badge." />
          <FlowStep num={2} color={C.blue} label="eBay card? → Availability check" detail="System pings eBay API before checkout. If sold on eBay → card auto-deleted, buyer blocked." />
          <FlowStep num={3} color={C.blue} label="Buyer clicks Buy Now → Stripe Checkout" detail="Opens in new tab. Promo codes allowed. Buyer sees card price + shipping line item." />
          <FlowStep num={4} color={C.blue} label="Stripe processes payment" detail="Webhook fires checkout.session.completed. Order created, card marked 'sold'." />
          <FlowStep num={5} color={C.blue} label="Card added to buyer's Collection" detail="Buyer gets confirmation email with ticket number. Seller gets ship-within-48h email." />
          <FlowStep num={6} color={C.blue} label="Seller ships → enters tracking" detail="Seller marks 'label created' with tracking number in Orders page." />
          <FlowStep num={7} color={C.blue} label="Delivery confirmed → funds released" detail="Auto-release 14 days after purchase, or buyer confirms delivery." last />
        </Card>
        <div>
          <Card>
            <div style={{ fontWeight: 800, color: C.blueLight, fontSize: 15, marginBottom: 16, textTransform: "uppercase", letterSpacing: 1 }}>Shipping Tiers (LOCKED)</div>
            <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 13 }}>
              <thead>
                <tr style={{ borderBottom: `1px solid ${C.panelBorder}` }}>
                  <th style={{ textAlign: "left", color: C.muted, fontWeight: 600, padding: "6px 0" }}>Card Price</th>
                  <th style={{ textAlign: "left", color: C.muted, fontWeight: 600, padding: "6px 0" }}>Fee</th>
                  <th style={{ textAlign: "left", color: C.muted, fontWeight: 600, padding: "6px 0" }}>Service</th>
                </tr>
              </thead>
              <tbody>
                {[
                  ["Under $100", "$4.50", "USPS Ground Advantage ($100 insured)"],
                  ["$100 – $499", "$7.00", "USPS Ground Advantage (declared value)"],
                  ["$500+", "$14.95", "USPS Priority Mail (full declared value)"],
                  ["eBay Dropship", "FREE", "eBay seller ships directly to buyer"],
                ].map(([price, fee, svc], i) => (
                  <tr key={i} style={{ borderBottom: `1px solid ${C.panelBorder}` }}>
                    <td style={{ padding: "8px 0", color: C.white, fontWeight: 600 }}>{price}</td>
                    <td style={{ padding: "8px 0", color: C.gold, fontWeight: 700 }}>{fee}</td>
                    <td style={{ padding: "8px 0", color: C.muted, fontSize: 12 }}>{svc}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </Card>
          <Card>
            <div style={{ fontWeight: 800, color: C.blueLight, fontSize: 15, marginBottom: 16, textTransform: "uppercase", letterSpacing: 1 }}>Revenue on Each Sale</div>
            <div style={{ display: "flex", gap: 12, flexWrap: "wrap" }}>
              <RevenueCard label="Platform Fee" value="10%" note="Min $1.50 per transaction" color={C.green} />
              <RevenueCard label="Seller Gets" value="90%" note="Of sale price" color={C.blue} />
              <RevenueCard label="Shipping" value="$4.50–$14.95" note="Collected at checkout" color={C.orange} />
            </div>
            <div style={{ marginTop: 16, color: C.muted, fontSize: 12 }}>
              ⚠️ <strong style={{ color: C.white }}>Note:</strong> The 5% fee in <code>orders.create</code> and the 10% fee in the Stripe webhook are inconsistent — the webhook (10%) is what actually runs on payment. Recommend aligning both to 10%.
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}

function CartFlow() {
  return (
    <div id="cart">
      <SectionHeader emoji="🛍️" title="CART / MULTI-CARD CHECKOUT" subtitle="Buy multiple cards in one Stripe session" color={C.teal} />
      <Card>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 24 }}>
          <div>
            <div style={{ fontWeight: 800, color: C.tealLight, fontSize: 15, marginBottom: 16, textTransform: "uppercase", letterSpacing: 1 }}>Cart Flow</div>
            <FlowStep num={1} color={C.teal} label="Buyer adds cards to cart (heart icon)" detail="Cart stored in localStorage. No reservation — cards can sell while in cart." />
            <FlowStep num={2} color={C.teal} label="Buyer opens Cart → reviews items" detail="Cart shows all cards with prices. No per-item shipping in cart checkout." />
            <FlowStep num={3} color={C.teal} label="Checkout → Stripe session with all items" detail="All cards as separate line items. No shipping line item added (gap — needs fix)." />
            <FlowStep num={4} color={C.teal} label="Webhook: cart_purchase" detail="Creates one order per card. Each card marked sold. Buyer gets one confirmation email." last />
          </div>
          <div>
            <div style={{ fontWeight: 800, color: C.tealLight, fontSize: 15, marginBottom: 16, textTransform: "uppercase", letterSpacing: 1 }}>Known Gaps</div>
            {[
              ["⚠️ No shipping fee in cart checkout", "Cart session doesn't add a shipping line item. Shipping is only charged on single-card buy-now."],
              ["⚠️ No eBay availability check", "Cart doesn't pre-check eBay cards before checkout. A card could sell on eBay between add-to-cart and payment."],
              ["⚠️ No cart reservation", "Cards aren't locked while in cart. Two buyers could checkout the same card simultaneously."],
            ].map(([title, desc], i) => (
              <div key={i} style={{ background: `${C.orange}11`, border: `1px solid ${C.orange}33`, borderRadius: 8, padding: "10px 14px", marginBottom: 10 }}>
                <div style={{ color: C.orangeLight, fontWeight: 700, fontSize: 13 }}>{title}</div>
                <div style={{ color: C.muted, fontSize: 12, marginTop: 4 }}>{desc}</div>
              </div>
            ))}
          </div>
        </div>
      </Card>
    </div>
  );
}

function EbayFlow() {
  return (
    <div id="ebay">
      <SectionHeader emoji="🏷️" title="EBAY DROPSHIP FLOW" subtitle="Admin imports eBay listings → SCO sells at markup → eBay seller ships to buyer" color={C.gold} />
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20 }}>
        <Card>
          <div style={{ fontWeight: 800, color: C.gold, fontSize: 15, marginBottom: 16, textTransform: "uppercase", letterSpacing: 1 }}>Import → List → Sell</div>
          <FlowStep num={1} color={C.gold} label="Admin enters eBay seller username" detail="Back Office → eBay Import. Only FREE SHIPPING listings are fetched (locked rule)." />
          <FlowStep num={2} color={C.gold} label="Admin selects cards → Import" detail="Cards saved to SCO database with ebayItemId, isDropship=true. Admin sets SCO price (markup)." />
          <FlowStep num={3} color={C.gold} label="Card appears in Marketplace with 'e' badge" detail="Buyers see it as a normal card. eBay origin is transparent to buyer." />
          <FlowStep num={4} color={C.gold} label="Buyer clicks Buy Now" detail="System checks eBay availability FIRST. If sold → auto-delete card, block checkout." />
          <FlowStep num={5} color={C.gold} label="Stripe checkout → payment captured" detail="Shipping = $0 (eBay seller ships). Webhook fires, order created with ebayItemId." />
          <FlowStep num={6} color={C.gold} label="Best Offer attempt (async, non-blocking)" detail="System tries to buy at 10% below asking. Polls every 2 min for up to 30 min." />
          <FlowStep num={7} color={C.gold} label="Admin fulfills in Back Office" detail="Admin sees dropship orders. Clicks 'Buy on eBay' link. Marks fulfilled." last />
        </Card>
        <div>
          <Card>
            <div style={{ fontWeight: 800, color: C.gold, fontSize: 15, marginBottom: 16, textTransform: "uppercase", letterSpacing: 1 }}>Best Offer Logic</div>
            <DecisionBox
              question="Does eBay listing support Best Offer?"
              yes="Submit offer at 90% of asking price"
              no="Fall back to full price immediately"
              color={C.gold}
            />
            <DecisionBox
              question="Offer accepted within 30 min?"
              yes="Record savings, proceed with purchase"
              no="Fall back to full price (declined/expired)"
              color={C.orange}
            />
            <div style={{ color: C.muted, fontSize: 12, marginTop: 8 }}>
              Offer status tracked: <code style={{ color: C.gold }}>pending → accepted | declined | countered | expired | not_eligible | fallback_full_price</code>
            </div>
          </Card>
          <Card>
            <div style={{ fontWeight: 800, color: C.gold, fontSize: 15, marginBottom: 16, textTransform: "uppercase", letterSpacing: 1 }}>Revenue on eBay Deals</div>
            <div style={{ color: C.muted, fontSize: 13, marginBottom: 12 }}>
              SCO earns the <strong style={{ color: C.white }}>spread</strong> between eBay cost and SCO list price. No platform fee is paid to a seller (SCO is the seller).
            </div>
            <div style={{ display: "flex", gap: 12, flexWrap: "wrap" }}>
              <RevenueCard label="SCO Revenue" value="Markup %" note="Admin sets SCO price above eBay cost" color={C.gold} />
              <RevenueCard label="Best Offer Savings" value="Up to 10%" note="If eBay seller accepts offer" color={C.green} />
              <RevenueCard label="Shipping Cost" value="$0" note="eBay seller ships free (import rule)" color={C.teal} />
            </div>
            <div style={{ marginTop: 16 }}>
              <div style={{ color: C.muted, fontSize: 12 }}>
                <strong style={{ color: C.white }}>Example:</strong> eBay card lists at $50. Admin imports and lists at $65 on SCO. Best Offer accepted at $45. SCO profit = $65 − $45 = <strong style={{ color: C.gold }}>$20 (31% margin)</strong>.
              </div>
            </div>
          </Card>
          <Card>
            <div style={{ fontWeight: 800, color: C.gold, fontSize: 15, marginBottom: 12, textTransform: "uppercase", letterSpacing: 1 }}>Rules (Locked)</div>
            <RuleTag text="FREE SHIPPING only" color={C.gold} />
            <RuleTag text="Availability checked at checkout" color={C.orange} />
            <RuleTag text="Auto-deleted if sold on eBay" color={C.red} />
            <RuleTag text="Cron: checks every 4 hours" color={C.blue} />
            <RuleTag text="Best Offer: 10% discount attempt" color={C.green} />
            <RuleTag text="Poll: every 2 min, max 30 min" color={C.purple} />
          </Card>
        </div>
      </div>
    </div>
  );
}

function TradeFlow() {
  return (
    <div id="trade">
      <SectionHeader emoji="🤝" title="CARD TRADE FLOW" subtitle="Peer-to-peer card swaps with escrow, digital agreements, and physical shipping through SCO" color={C.purple} />
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20 }}>
        <Card>
          <div style={{ fontWeight: 800, color: C.purpleLight, fontSize: 15, marginBottom: 16, textTransform: "uppercase", letterSpacing: 1 }}>Trade Lifecycle</div>
          <FlowStep num={1} color={C.purple} label="Initiator selects cards to offer + request" detail="Browse other user's collection. Pick cards you'll send and cards you want back." />
          <FlowStep num={2} color={C.purple} label="Trade offer sent" detail="System message sent to both parties. Email sent to receiver. Admin notified." />
          <FlowStep num={3} color={C.purple} label="Receiver: Accept / Reject / Counter" detail="Counter offer creates a revision record. Roles flip — initiator must respond to counter." />
          <FlowStep num={4} color={C.purple} label="Both parties click 'Agree to Trade'" detail="Each party enters shipping address + phone. Both must agree for status → 'agreed'." />
          <FlowStep num={5} color={C.purple} label="Cards locked as 'in_trade'" detail="All involved collection items locked. Removed from marketplace. Can't be sold." />
          <FlowStep num={6} color={C.purple} label="Each party pays $10 escrow fee" detail="Stripe checkout per party. $20 total collected. Fee confirms commitment." />
          <FlowStep num={7} color={C.purple} label="Both ship cards to SCO" detail="Cards shipped to SCO Secured Location. Trade ID written on package." />
          <FlowStep num={8} color={C.purple} label="Both submit tracking numbers" detail="When both tracking numbers submitted → status 'both_shipped'." />
          <FlowStep num={9} color={C.purple} label="SCO receives, inspects, re-ships" detail="SCO verifies cards match trade agreement. Ships each party's new cards." last />
        </Card>
        <div>
          <Card>
            <div style={{ fontWeight: 800, color: C.purpleLight, fontSize: 15, marginBottom: 16, textTransform: "uppercase", letterSpacing: 1 }}>Revenue on Trades</div>
            <div style={{ display: "flex", gap: 12, flexWrap: "wrap", marginBottom: 12 }}>
              <RevenueCard label="Per Party Fee" value="$10" note="Both must pay to proceed" color={C.purple} />
              <RevenueCard label="Total per Trade" value="$20" note="$10 × 2 parties" color={C.gold} />
              <RevenueCard label="Re-ship Cost" value="Admin" note="SCO pays outbound shipping" color={C.orange} />
            </div>
            <div style={{ color: C.muted, fontSize: 12 }}>
              Net revenue per trade ≈ $20 minus SCO's outbound shipping cost (2 packages). At $4.50/pkg → <strong style={{ color: C.white }}>~$11 net per trade</strong>.
            </div>
          </Card>
          <Card>
            <div style={{ fontWeight: 800, color: C.purpleLight, fontSize: 15, marginBottom: 16, textTransform: "uppercase", letterSpacing: 1 }}>Trade Rules</div>
            <RuleTag text="Both must agree digitally" color={C.purple} />
            <RuleTag text="$10 fee per party (Stripe)" color={C.gold} />
            <RuleTag text="Cards locked in 'in_trade' status" color={C.orange} />
            <RuleTag text="Ship to SCO — not directly" color={C.red} />
            <RuleTag text="Trade ID on package required" color={C.blue} />
            <RuleTag text="Counter offers tracked in revisions table" color={C.teal} />
            <RuleTag text="Agreement printable from /trades" color={C.green} />
            <div style={{ marginTop: 16, color: C.muted, fontSize: 12 }}>
              <strong style={{ color: C.white }}>Messages:</strong> Trade system auto-sends contract message to both parties' inboxes when offer is created, and a next-steps message when both agree. Agreement PDF available at /trades → View Agreement.
            </div>
          </Card>
          <Card>
            <div style={{ fontWeight: 800, color: C.purpleLight, fontSize: 15, marginBottom: 12, textTransform: "uppercase", letterSpacing: 1 }}>Status Progression</div>
            {[
              ["pending", C.muted, "Offer sent, awaiting receiver response"],
              ["countered", C.orange, "Counter offer made, awaiting response"],
              ["accepted", C.blueLight, "Receiver accepted, awaiting both agreements"],
              ["agreed", C.purple, "Both agreed digitally, awaiting fees + shipping"],
              ["both_shipped", C.teal, "Both tracking numbers submitted"],
              ["completed", C.green, "SCO shipped to both parties"],
              ["rejected / cancelled", C.red, "Trade ended"],
            ].map(([status, color, desc]) => (
              <div key={status} style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 8 }}>
                <span style={{ background: `${color}22`, border: `1px solid ${color}55`, color, borderRadius: 4, padding: "2px 8px", fontSize: 11, fontWeight: 700, minWidth: 90, textAlign: "center" }}>{status}</span>
                <span style={{ color: C.muted, fontSize: 12 }}>{desc}</span>
              </div>
            ))}
          </Card>
        </div>
      </div>
    </div>
  );
}

function AuctionFlow() {
  return (
    <div id="auction">
      <SectionHeader emoji="🔨" title="AUCTION FLOW" subtitle="Live timed auctions with credit-based listing and 5% platform fee on winning bid" color={C.red} />
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20 }}>
        <Card>
          <div style={{ fontWeight: 800, color: C.red, fontSize: 15, marginBottom: 16, textTransform: "uppercase", letterSpacing: 1 }}>Auction Lifecycle</div>
          <FlowStep num={1} color={C.red} label="Seller lists card for auction" detail="From My Collection → List in Arena → Auction tab. Costs 1 credit. Duration: 3 days." />
          <FlowStep num={2} color={C.red} label="Bidders place bids" detail="Minimum bid = starting price. Each subsequent bid must be ≥ current + 5% (min $1 increment)." />
          <FlowStep num={3} color={C.red} label="Auction ends (3 days)" detail="Highest bidder wins. If no bids → auction ends with no winner." />
          <FlowStep num={4} color={C.red} label="Winner pays via Stripe" detail="Winner directed to checkout. Winning bid amount charged." />
          <FlowStep num={5} color={C.red} label="Platform fee deducted" detail="5% fee (min $1.50) taken from sale. Seller receives 95%." />
          <FlowStep num={6} color={C.red} label="Seller ships, buyer receives" detail="Same escrow/shipping flow as marketplace purchase." last />
        </Card>
        <div>
          <Card>
            <div style={{ fontWeight: 800, color: C.red, fontSize: 15, marginBottom: 16, textTransform: "uppercase", letterSpacing: 1 }}>Revenue on Auctions</div>
            <div style={{ display: "flex", gap: 12, flexWrap: "wrap", marginBottom: 12 }}>
              <RevenueCard label="Listing Fee" value="1 Credit" note="Per 3-day auction" color={C.red} />
              <RevenueCard label="Renewal Fee" value="1 Credit" note="Extend 3 more days" color={C.orange} />
              <RevenueCard label="Platform Fee" value="5%" note="Min $1.50 on winning bid" color={C.gold} />
            </div>
          </Card>
          <Card>
            <div style={{ fontWeight: 800, color: C.red, fontSize: 15, marginBottom: 16, textTransform: "uppercase", letterSpacing: 1 }}>Auction Rules</div>
            <RuleTag text="1 credit to list (3 days)" color={C.red} />
            <RuleTag text="Max 10 active auctions per seller" color={C.orange} />
            <RuleTag text="Max 100 active auctions (collection page)" color={C.orange} />
            <RuleTag text="Sellers cannot bid on own auction" color={C.red} />
            <RuleTag text="Min bid increment: 5% or $1 (whichever higher)" color={C.blue} />
            <RuleTag text="Renew ended auction: 1 credit" color={C.purple} />
            <RuleTag text="5% platform fee (min $1.50)" color={C.gold} />
            <div style={{ marginTop: 16, color: C.muted, fontSize: 12 }}>
              <strong style={{ color: C.white }}>From My Collection:</strong> Listing to auction costs 3 credits (5-day), 5 credits (7-day), or 8 credits (10-day) per the collection page UI — but the server always charges 1 credit for a 3-day auction. <span style={{ color: C.orangeLight }}>⚠️ Frontend/backend mismatch — needs alignment.</span>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}

function LabelsFlow() {
  return (
    <div id="labels">
      <SectionHeader emoji="🏷️" title="LABEL PRINTING SYSTEM" subtitle="Custom SCO slab labels — per-card or bulk print from My Collection" color={C.teal} />
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20 }}>
        <Card>
          <div style={{ fontWeight: 800, color: C.tealLight, fontSize: 15, marginBottom: 16, textTransform: "uppercase", letterSpacing: 1 }}>How Labels Work</div>
          <FlowStep num={1} color={C.teal} label="User opens a card in My Collection" detail="Click any card → Card Detail panel opens on the right." />
          <FlowStep num={2} color={C.teal} label="Choose label background + border color" detail="Background: White Silk, Black Silk, Red Silk. Border: White, Orange, Red, Blue, Black." />
          <FlowStep num={3} color={C.teal} label="Click 'Save Label Style'" detail="Style saved to database per card. Persists across sessions." />
          <FlowStep num={4} color={C.teal} label="Click 'Print Label'" detail="Opens new browser tab with print-ready HTML. Uses window.print()." />
          <FlowStep num={5} color={C.teal} label="Bulk print: select cards → Print Labels" detail="Select multiple cards with checkboxes. All selected cards print on one sheet." last />
        </Card>
        <div>
          <Card>
            <div style={{ fontWeight: 800, color: C.tealLight, fontSize: 15, marginBottom: 16, textTransform: "uppercase", letterSpacing: 1 }}>Label Customization Options</div>
            <div style={{ marginBottom: 16 }}>
              <div style={{ color: C.muted, fontSize: 12, fontWeight: 700, textTransform: "uppercase", letterSpacing: 1, marginBottom: 8 }}>Backgrounds (3 options)</div>
              <div style={{ display: "flex", gap: 8 }}>
                {[
                  { name: "White Silk", bg: "#f8f8f8", text: "#111", border: "#ccc" },
                  { name: "Black Silk", bg: "#1a1a1a", text: "#fff", border: "#444" },
                  { name: "Red Silk", bg: "#8b0000", text: "#fff", border: "#c00" },
                ].map(({ name, bg, text, border }) => (
                  <div key={name} style={{ background: bg, border: `2px solid ${border}`, borderRadius: 6, padding: "8px 12px", color: text, fontSize: 12, fontWeight: 700 }}>{name}</div>
                ))}
              </div>
            </div>
            <div>
              <div style={{ color: C.muted, fontSize: 12, fontWeight: 700, textTransform: "uppercase", letterSpacing: 1, marginBottom: 8 }}>Border Colors (5 options)</div>
              <div style={{ display: "flex", gap: 8 }}>
                {[
                  { name: "White", hex: "#ffffff" },
                  { name: "Orange", hex: "#f97316" },
                  { name: "Red", hex: "#c41e3a" },
                  { name: "Blue", hex: "#1d4ed8" },
                  { name: "Black", hex: "#000000" },
                ].map(({ name, hex }) => (
                  <div key={name} style={{ background: hex, borderRadius: 4, padding: "4px 10px", color: hex === "#ffffff" || hex === "#f97316" ? "#000" : "#fff", fontSize: 11, fontWeight: 700 }}>{name}</div>
                ))}
              </div>
            </div>
          </Card>
          <Card>
            <div style={{ fontWeight: 800, color: C.tealLight, fontSize: 15, marginBottom: 16, textTransform: "uppercase", letterSpacing: 1 }}>Label Contains</div>
            {[
              "Player name (large, prominent)",
              "Card company / manufacturer",
              "Year + Set name + Card number",
              "Overall grade (large number)",
              "Grade label (e.g. GEM MINT)",
              "Sub-grades: Centering, Corners, Edges, Surface",
              "SCO cert number",
              "QR code linking to card verification page",
            ].map((item, i) => (
              <div key={i} style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 6 }}>
                <div style={{ width: 6, height: 6, borderRadius: "50%", background: C.teal, flexShrink: 0 }} />
                <span style={{ color: C.muted, fontSize: 13 }}>{item}</span>
              </div>
            ))}
          </Card>
          <Card>
            <div style={{ fontWeight: 800, color: C.tealLight, fontSize: 15, marginBottom: 12, textTransform: "uppercase", letterSpacing: 1 }}>Print Limits & Rules</div>
            <RuleTag text="No hard print limit currently" color={C.teal} />
            <RuleTag text="Bulk: select any number of cards" color={C.blue} />
            <RuleTag text="Single: 1 card per print action" color={C.green} />
            <RuleTag text="Opens new browser tab (window.open)" color={C.muted} />
            <div style={{ marginTop: 12, color: C.muted, fontSize: 12 }}>
              <strong style={{ color: C.orangeLight }}>⚠️ Gap:</strong> No credit cost for printing. No limit on how many labels a user can print. Consider adding a credit-per-print model or subscription-gated bulk printing to generate revenue.
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}

function GradingFlow() {
  return (
    <div id="grading">
      <SectionHeader emoji="🔬" title="AI CARD GRADING FLOW" subtitle="2-credit AI grading using photo analysis — produces grade, sub-grades, cert number, and market value" color={C.green} />
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20 }}>
        <Card>
          <div style={{ fontWeight: 800, color: C.greenLight, fontSize: 15, marginBottom: 16, textTransform: "uppercase", letterSpacing: 1 }}>Grading Steps</div>
          <FlowStep num={1} color={C.green} label="User uploads front + back photos" detail="From GradeCards page or My Collection. Photos uploaded to S3." />
          <FlowStep num={2} color={C.green} label="Credit check: need 2 credits" detail="If insufficient → FORBIDDEN error. Free plan starts with 25 credits." />
          <FlowStep num={3} color={C.green} label="AI analyzes card images" detail="LLM vision model grades centering, corners, edges, surface. Returns structured JSON." />
          <FlowStep num={4} color={C.green} label="2 credits deducted" detail="Credits deducted after successful grade. Cert number generated." />
          <FlowStep num={5} color={C.green} label="Market price fetched" detail="eBay sold comps + SCP + Beckett data averaged. Grade multiplier applied." />
          <FlowStep num={6} color={C.green} label="Results saved to collection" detail="Grade, sub-grades, cert number, estimated value saved to collection item." last />
        </Card>
        <div>
          <Card>
            <div style={{ fontWeight: 800, color: C.greenLight, fontSize: 15, marginBottom: 16, textTransform: "uppercase", letterSpacing: 1 }}>Grade Scale</div>
            <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 12 }}>
              <thead>
                <tr style={{ borderBottom: `1px solid ${C.panelBorder}` }}>
                  <th style={{ textAlign: "left", color: C.muted, fontWeight: 600, padding: "4px 0" }}>Grade</th>
                  <th style={{ textAlign: "left", color: C.muted, fontWeight: 600, padding: "4px 0" }}>Label</th>
                </tr>
              </thead>
              <tbody>
                {[
                  ["10", "Gem Mint"],["9.5", "Mint+"],["9", "Mint"],["8.5", "NM-MT+"],
                  ["8", "NM-MT"],["7.5", "NM+"],["7", "Near Mint"],["6", "EX-MT"],
                  ["5", "Excellent"],["4", "Very Good"],["3", "Good"],["2", "Fair"],["1", "Poor"],
                ].map(([g, l]) => (
                  <tr key={g} style={{ borderBottom: `1px solid ${C.panelBorder}` }}>
                    <td style={{ padding: "5px 0", color: parseFloat(g) >= 9 ? C.gold : parseFloat(g) >= 7 ? C.greenLight : C.muted, fontWeight: 700 }}>{g}</td>
                    <td style={{ padding: "5px 0", color: C.muted }}>{l}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </Card>
          <Card>
            <div style={{ fontWeight: 800, color: C.greenLight, fontSize: 15, marginBottom: 16, textTransform: "uppercase", letterSpacing: 1 }}>Revenue on Grading</div>
            <div style={{ display: "flex", gap: 12, flexWrap: "wrap" }}>
              <RevenueCard label="Cost per Grade" value="2 Credits" note="Deducted on success" color={C.green} />
              <RevenueCard label="Credit Value" value="$0.10" note="At $10/100 credits" color={C.gold} />
              <RevenueCard label="Revenue per Grade" value="~$0.20" note="At base credit price" color={C.teal} />
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}

function CreditsFlow() {
  return (
    <div id="credits">
      <SectionHeader emoji="💎" title="CREDITS SYSTEM" subtitle="In-platform currency used for grading, auctions, and features. Purchased via Stripe." color={C.gold} />
      <Card>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 24 }}>
          <div>
            <div style={{ fontWeight: 800, color: C.gold, fontSize: 15, marginBottom: 16, textTransform: "uppercase", letterSpacing: 1 }}>Credit Packages</div>
            <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 13 }}>
              <thead>
                <tr style={{ borderBottom: `1px solid ${C.panelBorder}` }}>
                  <th style={{ textAlign: "left", color: C.muted, fontWeight: 600, padding: "6px 0" }}>Package</th>
                  <th style={{ textAlign: "left", color: C.muted, fontWeight: 600, padding: "6px 0" }}>Price</th>
                  <th style={{ textAlign: "left", color: C.muted, fontWeight: 600, padding: "6px 0" }}>Bonus</th>
                  <th style={{ textAlign: "left", color: C.muted, fontWeight: 600, padding: "6px 0" }}>$/Credit</th>
                </tr>
              </thead>
              <tbody>
                {[
                  ["25 Credits", "$25.00", "—", "$1.00"],
                  ["50 Credits", "$50.00", "—", "$1.00"],
                  ["100 Credits", "$100.00", "—", "$1.00"],
                  ["250 Credits", "$250.00", "+6 bonus", "$0.98"],
                  ["500 Credits", "$500.00", "+25 bonus", "$0.95"],
                  ["1,000 Credits", "$1,000.00", "+100 bonus", "$0.91"],
                ].map(([pkg, price, bonus, rate], i) => (
                  <tr key={i} style={{ borderBottom: `1px solid ${C.panelBorder}` }}>
                    <td style={{ padding: "8px 0", color: C.white, fontWeight: 600 }}>{pkg}</td>
                    <td style={{ padding: "8px 0", color: C.gold, fontWeight: 700 }}>{price}</td>
                    <td style={{ padding: "8px 0", color: C.greenLight }}>{bonus}</td>
                    <td style={{ padding: "8px 0", color: C.muted }}>{rate}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div>
            <div style={{ fontWeight: 800, color: C.gold, fontSize: 15, marginBottom: 16, textTransform: "uppercase", letterSpacing: 1 }}>Where Credits Are Used</div>
            {[
              ["AI Card Grading", "2 credits per card", C.green],
              ["Auction Listing", "1 credit per 3-day auction", C.red],
              ["Auction Renewal", "1 credit per 3-day extension", C.orange],
              ["Vault Exchange Fee", "10% of card value (in credits)", C.purple],
              ["New Account Bonus", "25 free credits on signup", C.teal],
            ].map(([action, cost, color]) => (
              <div key={action} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "10px 0", borderBottom: `1px solid ${C.panelBorder}` }}>
                <span style={{ color: C.white, fontSize: 13, fontWeight: 600 }}>{action}</span>
                <span style={{ color, fontSize: 12, fontWeight: 700, background: `${color}22`, borderRadius: 4, padding: "2px 8px" }}>{cost}</span>
              </div>
            ))}
            <div style={{ marginTop: 16 }}>
              <div style={{ fontWeight: 800, color: C.gold, fontSize: 14, marginBottom: 10, textTransform: "uppercase", letterSpacing: 1 }}>Subscription Plans (UI)</div>
              {[
                ["Free", "$0", "10 credits/mo", "5 listings"],
                ["Starter", "$9.99/mo", "50 credits/mo", "25 listings"],
                ["Pro", "$24.99/mo", "150 credits/mo", "Unlimited"],
                ["Elite", "$59.99/mo", "400 credits/mo", "Affiliate + custom labels"],
                ["Franchise", "$149.99/mo", "1,000 credits/mo", "White-label options"],
              ].map(([plan, price, credits, feature]) => (
                <div key={plan} style={{ display: "flex", gap: 8, alignItems: "center", marginBottom: 6 }}>
                  <span style={{ color: C.gold, fontWeight: 700, fontSize: 12, minWidth: 70 }}>{plan}</span>
                  <span style={{ color: C.muted, fontSize: 11 }}>{price}</span>
                  <span style={{ color: C.greenLight, fontSize: 11 }}>· {credits}</span>
                  <span style={{ color: C.muted, fontSize: 11 }}>· {feature}</span>
                </div>
              ))}
              <div style={{ color: C.orangeLight, fontSize: 11, marginTop: 8 }}>⚠️ Subscription billing not yet wired to backend — plans shown in UI only.</div>
            </div>
          </div>
        </div>
      </Card>
    </div>
  );
}

function VaultFlow() {
  return (
    <div id="vault">
      <SectionHeader emoji="🏦" title="SCO VAULT FLOW" subtitle="Physical card storage at SCO facility — list, ship, or exchange for credits" color={C.purple} />
      <Card>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 24 }}>
          <div>
            <div style={{ fontWeight: 800, color: C.purpleLight, fontSize: 15, marginBottom: 16, textTransform: "uppercase", letterSpacing: 1 }}>Vault Lifecycle</div>
            <FlowStep num={1} color={C.purple} label="User sends card to SCO for vaulting" detail="Card shipped to SCO. Admin marks as 'vaulted' in system." />
            <FlowStep num={2} color={C.purple} label="Card appears in user's Vault tab" detail="Status: vaulted. Card held physically at SCO facility." />
            <FlowStep num={3} color={C.purple} label="User chooses: List / Ship / Sell for Credits" detail="Three options available from Vault page." last />
            <div style={{ marginTop: 20 }}>
              <div style={{ fontWeight: 700, color: C.purpleLight, fontSize: 13, marginBottom: 12 }}>Option A: List on Marketplace</div>
              <FlowStep num={1} color={C.blue} label="Card listed with 'SCO Vaulted & Guaranteed' badge" detail="Price set by user. Card enters marketplace with vault authenticity." />
              <FlowStep num={2} color={C.blue} label="Sold → SCO ships from vault" detail="SCO ships directly to buyer. No seller action needed." last />
            </div>
            <div style={{ marginTop: 20 }}>
              <div style={{ fontWeight: 700, color: C.purpleLight, fontSize: 13, marginBottom: 12 }}>Option B: Ship to Me</div>
              <FlowStep num={1} color={C.teal} label="User requests return shipment" detail="Admin notified. SCO ships card back to user's address." last />
            </div>
            <div style={{ marginTop: 20 }}>
              <div style={{ fontWeight: 700, color: C.purpleLight, fontSize: 13, marginBottom: 12 }}>Option C: Sell for Credits</div>
              <FlowStep num={1} color={C.gold} label="User gets 90% of estimated value as credits" detail="10% vault fee retained by SCO. Credits added instantly." />
              <FlowStep num={2} color={C.gold} label="Card returns to House inventory" detail="Auto-listed at auction: 75% min bid / 125% buy-now." last />
            </div>
          </div>
          <div>
            <Card style={{ marginBottom: 16 }}>
              <div style={{ fontWeight: 800, color: C.purpleLight, fontSize: 15, marginBottom: 16, textTransform: "uppercase", letterSpacing: 1 }}>Revenue on Vault</div>
              <div style={{ display: "flex", gap: 12, flexWrap: "wrap" }}>
                <RevenueCard label="Vault Fee (credits)" value="10%" note="Of card estimated value" color={C.purple} />
                <RevenueCard label="Marketplace Sale" value="10%" note="Platform fee on vault sale" color={C.blue} />
                <RevenueCard label="Re-auction" value="5%" note="Fee if House re-auctions card" color={C.gold} />
              </div>
            </Card>
            <Card>
              <div style={{ fontWeight: 800, color: C.purpleLight, fontSize: 15, marginBottom: 12, textTransform: "uppercase", letterSpacing: 1 }}>Vault Statuses</div>
              {[
                ["vaulted", C.purple, "Held at SCO, not listed"],
                ["vault_listed", C.blue, "Listed on marketplace"],
                ["vault_auction", C.red, "In active auction"],
                ["vault_sold", C.green, "Sold or exchanged for credits"],
                ["vault_shipped", C.teal, "Shipped back to owner"],
              ].map(([status, color, desc]) => (
                <div key={status} style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 8 }}>
                  <span style={{ background: `${color}22`, border: `1px solid ${color}55`, color, borderRadius: 4, padding: "2px 8px", fontSize: 11, fontWeight: 700, minWidth: 100, textAlign: "center" }}>{status}</span>
                  <span style={{ color: C.muted, fontSize: 12 }}>{desc}</span>
                </div>
              ))}
            </Card>
          </div>
        </div>
      </Card>
    </div>
  );
}

function RevenueMatrix() {
  return (
    <div id="revenue">
      <SectionHeader emoji="💰" title="REVENUE MATRIX" subtitle="Every dollar SCO makes — by flow, action, and percentage" color={C.gold} />
      <Card>
        <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 13 }}>
          <thead>
            <tr style={{ borderBottom: `2px solid ${C.gold}44` }}>
              <th style={{ textAlign: "left", color: C.gold, fontWeight: 700, padding: "10px 12px" }}>Revenue Source</th>
              <th style={{ textAlign: "left", color: C.gold, fontWeight: 700, padding: "10px 12px" }}>Amount</th>
              <th style={{ textAlign: "left", color: C.gold, fontWeight: 700, padding: "10px 12px" }}>Trigger</th>
              <th style={{ textAlign: "left", color: C.gold, fontWeight: 700, padding: "10px 12px" }}>Notes</th>
            </tr>
          </thead>
          <tbody>
            {[
              ["Marketplace Sale Fee", "10% of sale price", "Buyer pays via Stripe", "Min $1.50. Webhook charges 10%; orders.create charges 5% — inconsistency."],
              ["Shipping (House cards)", "$4.50 / $7.00 / $14.95", "Added to Stripe checkout", "Tiered by card price. eBay cards = $0."],
              ["Auction Listing", "1 credit ($1.00)", "Seller lists auction", "3-day listing. Max 10 active per seller."],
              ["Auction Renewal", "1 credit ($1.00)", "Seller renews ended auction", "Extends 3 more days."],
              ["Auction Sale Fee", "5% of winning bid", "Auction winner pays", "Min $1.50."],
              ["Trade Escrow Fee", "$10 per party ($20/trade)", "Both parties pay after agreement", "Net ~$11 after SCO shipping costs."],
              ["AI Grading", "2 credits ($2.00)", "Per card graded", "Credits purchased at $1.00/credit base."],
              ["Credit Sales", "$25–$1,000", "User buys credit package", "Bulk discounts at 250/500/1000 tiers."],
              ["Vault Exchange Fee", "10% of card value", "User sells vaulted card for credits", "Card returns to House, re-auctioned."],
              ["eBay Markup", "Admin-set spread", "eBay card sold on SCO", "SCO buys at eBay price, sells at markup. Best Offer saves up to 10%."],
              ["Subscriptions (planned)", "$9.99–$149.99/mo", "Monthly subscription", "⚠️ Not yet wired to backend."],
            ].map(([source, amount, trigger, notes], i) => (
              <tr key={i} style={{ borderBottom: `1px solid ${C.panelBorder}`, background: i % 2 === 0 ? "transparent" : `${C.white}03` }}>
                <td style={{ padding: "10px 12px", color: C.white, fontWeight: 600 }}>{source}</td>
                <td style={{ padding: "10px 12px", color: C.gold, fontWeight: 700 }}>{amount}</td>
                <td style={{ padding: "10px 12px", color: C.muted }}>{trigger}</td>
                <td style={{ padding: "10px 12px", color: C.muted, fontSize: 11 }}>{notes}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>
    </div>
  );
}

function GapsAndFixes() {
  return (
    <div id="gaps">
      <SectionHeader emoji="⚠️" title="GAPS & ITEMS TO CONFIRM" subtitle="Known inconsistencies, missing rules, and open questions for your review" color={C.orange} />
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20 }}>
        <Card>
          <div style={{ fontWeight: 800, color: C.orangeLight, fontSize: 15, marginBottom: 16, textTransform: "uppercase", letterSpacing: 1 }}>Backend Inconsistencies</div>
          {[
            ["Platform fee: 5% vs 10%", "orders.create procedure uses 5% fee. Stripe webhook uses 10%. Webhook runs on actual payment — so 10% is what's charged. Recommend aligning both to 10%."],
            ["Auction credit cost: 1 vs 3/5/8", "Server charges 1 credit for any auction. My Collection UI shows 3 credits (5-day), 5 credits (7-day), 8 credits (10-day). Server always creates 3-day auctions regardless of UI selection."],
            ["Cart checkout: no shipping fee", "Single card checkout adds shipping. Cart checkout does not. Buyers who use cart avoid shipping charges."],
            ["Cart: no eBay availability check", "Single card checkout checks eBay availability before Stripe. Cart checkout does not."],
          ].map(([title, desc], i) => (
            <div key={i} style={{ background: `${C.orange}11`, border: `1px solid ${C.orange}33`, borderRadius: 8, padding: "12px 14px", marginBottom: 12 }}>
              <div style={{ color: C.orangeLight, fontWeight: 700, fontSize: 13, marginBottom: 4 }}>{title}</div>
              <div style={{ color: C.muted, fontSize: 12 }}>{desc}</div>
            </div>
          ))}
        </Card>
        <Card>
          <div style={{ fontWeight: 800, color: C.orangeLight, fontSize: 15, marginBottom: 16, textTransform: "uppercase", letterSpacing: 1 }}>Missing Rules / Open Questions</div>
          {[
            ["Label print limits", "No credit cost or limit on label printing. Is this intentional? Could be a revenue opportunity (e.g., 1 credit per bulk print, or subscription-gated)."],
            ["Subscription billing", "5 subscription tiers shown in UI ($0–$149.99/mo) but no Stripe subscription wired. Monthly credit grants not automated."],
            ["Trade: who pays re-ship?", "After SCO receives both trade packages, SCO ships to each party. Who pays outbound shipping? Currently no charge to users for re-ship."],
            ["Vault storage fee", "No monthly storage fee for vaulted cards. Is SCO charging for physical storage? If not, this is a cost center."],
            ["Auction winner payment", "After auction ends, how does winner pay? The flow shows 'directed to checkout' but the actual checkout trigger for auction winners is not fully wired."],
            ["eBay markup rule", "No enforced minimum markup on eBay imports. Admin can import at eBay price with $0 profit. Should there be a minimum markup rule?"],
          ].map(([title, desc], i) => (
            <div key={i} style={{ background: `${C.blue}11`, border: `1px solid ${C.blue}33`, borderRadius: 8, padding: "12px 14px", marginBottom: 12 }}>
              <div style={{ color: C.blueLight, fontWeight: 700, fontSize: 13, marginBottom: 4 }}>❓ {title}</div>
              <div style={{ color: C.muted, fontSize: 12 }}>{desc}</div>
            </div>
          ))}
        </Card>
      </div>
    </div>
  );
}

// ─── Email + Messaging Flow ─────────────────────────────────────────────────
function EmailMessagingFlow() {
  const flows = [
    {
      id: "purchase",
      emoji: "🛒",
      title: "PURCHASE FLOW — Email & Messaging Timeline",
      color: C.blue,
      steps: [
        { trigger: "Buyer clicks Buy Now & pays", email: "✉️ Buyer: Order Confirmation (order details, ticket #, what happens next)", msg: "💬 Order thread created — system message: 'Payment received. Awaiting seller to ship.'", who: "Buyer", auto: true },
        { trigger: "Buyer pays (seller card)", email: "✉️ Seller: New Order Received (card title, buyer name, price, ship-by deadline)", msg: "💬 System message to seller: 'You have a new order. Ship within 48 hours.'", who: "Seller", auto: true },
        { trigger: "Seller purchases shipping label", email: "—", msg: "💬 System message: 'Seller created shipping label. Tracking: [#].'", who: "Seller action", auto: false },
        { trigger: "Seller enters tracking number", email: "✉️ Buyer: Tracking Added (tracking #, carrier, confirm receipt instructions)", msg: "💬 System message: 'Your card has shipped. Tracking: [#]. Please confirm receipt when it arrives.'", who: "Seller action", auto: true },
        { trigger: "23 hours after auto-release time", email: "✉️ Buyer: Auto-Release Warning — 1 hour left to confirm or funds release automatically", msg: "💬 System message: 'Reminder: Confirm receipt or funds auto-release in 1 hour.'", who: "System (cron)", auto: true },
        { trigger: "Buyer confirms receipt", email: "✉️ Buyer: Transaction Complete | ✉️ Seller: Funds Released (payout amount)", msg: "💬 System message: 'Buyer confirmed receipt. Funds released to seller. Ticket complete.'", who: "Buyer action", auto: true },
        { trigger: "24 hrs after delivery — no buyer response", email: "✉️ Buyer: Funds Auto-Released | ✉️ Seller: Funds Released | ✉️ Admin: Auto-Release Fired", msg: "💬 System message: 'Funds auto-released to seller (24hr timer expired). Ticket closed.'", who: "System (cron)", auto: true },
      ],
    },
    {
      id: "trade",
      emoji: "🤝",
      title: "TRADE FLOW — Email & Messaging Timeline",
      color: C.purple,
      steps: [
        { trigger: "User sends trade offer", email: "✉️ Receiver: Trade Offer Received (cards offered, cards requested, value comparison)", msg: "💬 Trade thread created — system message: 'Trade offer received from [name].'", who: "Initiator action", auto: true },
        { trigger: "Receiver sends counter offer", email: "✉️ Initiator: Counter Offer Received (revised terms)", msg: "💬 System message: 'Counter offer submitted. Review and respond.'", who: "Receiver action", auto: true },
        { trigger: "Both parties accept terms", email: "✉️ Both: Trade Accepted — Fee Due ($X each, payment link)", msg: "💬 System message: 'Both parties agreed. Pay the trade fee to proceed.'", who: "System", auto: true },
        { trigger: "Both fees paid", email: "✉️ Both: Ship Your Card — Instructions (ship to SCO address, include ticket #)", msg: "💬 System message: 'Fees received. Ship your card to SCO within 5 days.'", who: "System", auto: true },
        { trigger: "SCO receives a package", email: "✉️ Sender: Card Received at SCO (condition noted, awaiting other party)", msg: "💬 System message: 'SCO received [name]'s card. Awaiting the other package.'", who: "Admin action", auto: true },
        { trigger: "Both cards received at SCO", email: "✉️ Both: Trade Complete — Card Shipped to You (tracking #)", msg: "💬 System message: 'Both cards received. SCO is shipping your card today.'", who: "Admin action", auto: true },
      ],
    },
    {
      id: "auction",
      emoji: "🔨",
      title: "AUCTION FLOW — Email & Messaging Timeline",
      color: C.red,
      steps: [
        { trigger: "Auction ends — winner determined", email: "✉️ Winner: Auction Won (card, winning bid, checkout link)", msg: "💬 System message to winner: 'Congratulations! You won. Complete checkout to claim your card.'", who: "System (cron)", auto: true },
        { trigger: "Auction ends — seller notified", email: "✉️ Seller: Auction Ended (winning bid, winner name, next steps)", msg: "💬 System message to seller: 'Your auction ended. Buyer is completing checkout.'", who: "System (cron)", auto: true },
        { trigger: "Winner completes payment", email: "✉️ Buyer: Order Confirmation | ✉️ Seller: New Order Received", msg: "💬 Order thread created — same flow as Purchase from this point.", who: "System", auto: true },
      ],
    },
    {
      id: "dispute",
      emoji: "⚖️",
      title: "DISPUTE FLOW — Email & Messaging Timeline",
      color: C.orange,
      steps: [
        { trigger: "Buyer or seller opens a dispute", email: "✉️ Both parties: Dispute Opened (reason, ticket #, expected resolution time)", msg: "💬 System message: 'A dispute has been opened on this order. SCO team will review within 24 hours.'", who: "User action", auto: true },
        { trigger: "Admin resolves dispute", email: "✉️ Both parties: Dispute Resolved (outcome, next steps, any refund/release details)", msg: "💬 System message: 'Dispute resolved by SCO team. [Outcome details].'", who: "Admin action", auto: true },
      ],
    },
  ];

  return (
    <div id="comms">
      <SectionHeader emoji="📧" title="EMAIL + MESSAGING COMMUNICATION FLOWS" subtitle="Every automated touchpoint — what triggers it, who gets it, and what channel it uses" color={C.teal} />

      {/* Legend */}
      <div style={{ display: "flex", gap: 16, marginBottom: 32, flexWrap: "wrap" }}>
        {[
          { color: C.blueLight, label: "✉️ Email (auto-sent)" },
          { color: C.greenLight, label: "💬 In-App Message (order thread)" },
          { color: C.gold, label: "⚡ Auto (system/cron)" },
          { color: C.muted, label: "👤 Triggered by user action" },
        ].map(({ color, label }) => (
          <div key={label} style={{ display: "flex", alignItems: "center", gap: 8, background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)", borderRadius: 8, padding: "6px 14px" }}>
            <div style={{ width: 10, height: 10, borderRadius: "50%", background: color }} />
            <span style={{ color: C.muted, fontSize: 12 }}>{label}</span>
          </div>
        ))}
      </div>

      {flows.map((flow) => (
        <div key={flow.id} style={{ marginBottom: 48 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 20 }}>
            <span style={{ fontSize: 22 }}>{flow.emoji}</span>
            <h3 style={{ margin: 0, color: flow.color, fontFamily: "Oswald, sans-serif", fontSize: 16, letterSpacing: 1 }}>{flow.title}</h3>
          </div>

          {/* Header row */}
          <div style={{ display: "grid", gridTemplateColumns: "200px 1fr 1fr 100px", gap: 8, padding: "8px 12px", background: "rgba(255,255,255,0.04)", borderRadius: 8, marginBottom: 4 }}>
            {["TRIGGER", "EMAIL SENT", "IN-APP MESSAGE", "WHO / AUTO"].map((h) => (
              <div key={h} style={{ color: C.muted, fontSize: 11, fontWeight: 700, letterSpacing: 1 }}>{h}</div>
            ))}
          </div>

          {flow.steps.map((step, i) => (
            <div
              key={i}
              style={{
                display: "grid",
                gridTemplateColumns: "200px 1fr 1fr 100px",
                gap: 8,
                padding: "12px",
                background: i % 2 === 0 ? "rgba(255,255,255,0.02)" : "transparent",
                borderRadius: 8,
                borderLeft: `3px solid ${flow.color}44`,
                marginBottom: 2,
              }}
            >
              <div style={{ color: C.white, fontSize: 12, fontWeight: 600 }}>{step.trigger}</div>
              <div style={{ color: C.blueLight, fontSize: 12 }}>{step.email}</div>
              <div style={{ color: C.greenLight, fontSize: 12 }}>{step.msg}</div>
              <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
                <span style={{ color: C.muted, fontSize: 11 }}>{step.who}</span>
                {step.auto && (
                  <span style={{ background: `${C.gold}22`, color: C.gold, fontSize: 10, fontWeight: 700, borderRadius: 4, padding: "2px 6px", width: "fit-content" }}>⚡ AUTO</span>
                )}
              </div>
            </div>
          ))}
        </div>
      ))}

      {/* Template inventory */}
      <div style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.08)", borderRadius: 12, padding: 24, marginTop: 16 }}>
        <div style={{ fontWeight: 800, color: C.tealLight, fontSize: 15, marginBottom: 16, textTransform: "uppercase", letterSpacing: 1 }}>📋 Full Template Inventory (20 Templates)</div>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }}>
          {[
            ["welcome", "Welcome", "New user registration", C.blue],
            ["orderPlaced", "Order Confirmation", "Buyer pays", C.blue],
            ["sellerNewOrder", "Seller: New Order", "Buyer pays (seller card)", C.blue],
            ["buyerTrackingAdded", "Tracking Added", "Seller enters tracking #", C.blue],
            ["buyerAutoReleaseWarning", "Auto-Release Warning", "1 hr before auto-release", C.orange],
            ["fundsReleasedBuyer", "Funds Released (Buyer)", "Buyer confirms or auto-release", C.green],
            ["fundsReleasedSeller", "Funds Released (Seller)", "Buyer confirms or auto-release", C.green],
            ["adminAutoRelease", "Admin: Auto-Release Fired", "Cron fires auto-release", C.orange],
            ["sellerShipReminder", "Ship Reminder", "24 hrs before ship deadline", C.orange],
            ["auctionWon", "Auction Won", "Auction ends", C.red],
            ["auctionEnded", "Auction Ended (Seller)", "Auction ends", C.red],
            ["tradeOffered", "Trade Offer Received", "Trade offer sent", C.purple],
            ["tradeCounterOffer", "Counter Offer Received", "Counter sent", C.purple],
            ["tradeBothAgreed", "Trade Agreed — Fee Due", "Both accept terms", C.purple],
            ["tradeFeePaid", "Ship Your Card", "Both fees paid", C.purple],
            ["tradeCardReceived", "Card Received at SCO", "Admin marks received", C.purple],
            ["tradeCompleted", "Trade Complete", "Both cards shipped", C.purple],
            ["disputeOpened", "Dispute Opened", "User opens dispute", C.orange],
            ["disputeResolved", "Dispute Resolved", "Admin resolves", C.orange],
            ["graded", "Grading Complete", "AI grading finishes", C.green],
          ].map(([key, name, trigger, color]) => (
            <div key={key} style={{ display: "flex", alignItems: "center", gap: 10, padding: "8px 12px", background: `${color}11`, border: `1px solid ${color}33`, borderRadius: 8 }}>
              <div style={{ width: 8, height: 8, borderRadius: "50%", background: color as string, flexShrink: 0 }} />
              <div>
                <div style={{ color: C.white, fontSize: 12, fontWeight: 700 }}>{name as string}</div>
                <div style={{ color: C.muted, fontSize: 11 }}>Trigger: {trigger as string}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ─── Nav ──────────────────────────────────────────────────────────────────────
const NAV = [
  { id: "purchase", label: "Purchase", emoji: "🛒" },
  { id: "cart", label: "Cart", emoji: "🛍️" },
  { id: "ebay", label: "eBay", emoji: "🏷️" },
  { id: "trade", label: "Trades", emoji: "🤝" },
  { id: "auction", label: "Auctions", emoji: "🔨" },
  { id: "labels", label: "Labels", emoji: "🏷️" },
  { id: "grading", label: "Grading", emoji: "🔬" },
  { id: "credits", label: "Credits", emoji: "💎" },
  { id: "vault", label: "Vault", emoji: "🏦" },
  { id: "revenue", label: "Revenue", emoji: "💰" },
  { id: "gaps", label: "Gaps", emoji: "⚠️" },
  { id: "comms", label: "Comms", emoji: "📧" },
];

export default function FlowCharts() {
  const [active, setActive] = useState("purchase");

  const scrollTo = (id: string) => {
    setActive(id);
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  return (
    <div style={{ minHeight: "100vh", background: C.bg, fontFamily: "Inter, system-ui, sans-serif" }}>
      {/* Header */}
      <div style={{ background: `linear-gradient(135deg, #0d1f3c, #1a0a20)`, borderBottom: `1px solid ${C.panelBorder}`, padding: "24px 32px", position: "sticky", top: 0, zIndex: 100 }}>
        <div style={{ maxWidth: 1400, margin: "0 auto" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 16, marginBottom: 16 }}>
            <div style={{ background: C.red, borderRadius: 10, padding: "8px 14px", fontWeight: 900, color: C.white, fontSize: 18, fontFamily: "Oswald, sans-serif", letterSpacing: 2 }}>SCO</div>
            <div>
              <h1 style={{ margin: 0, color: C.white, fontSize: 22, fontWeight: 900, fontFamily: "Oswald, sans-serif" }}>SPORTCARDSONLINE — BUSINESS FLOW AUDIT</h1>
              <p style={{ margin: 0, color: C.muted, fontSize: 12 }}>Complete flow documentation · Rules · Revenue model · Gaps</p>
            </div>
          </div>
          <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
            {NAV.map(({ id, label, emoji }) => (
              <button
                key={id}
                onClick={() => scrollTo(id)}
                style={{
                  background: active === id ? C.red : C.mutedBg,
                  border: `1px solid ${active === id ? C.red : C.panelBorder}`,
                  color: active === id ? C.white : C.muted,
                  borderRadius: 8, padding: "5px 12px", fontSize: 12, fontWeight: 600,
                  cursor: "pointer", transition: "all 0.15s",
                }}
              >{emoji} {label}</button>
            ))}
          </div>
        </div>
      </div>

      {/* Content */}
      <div style={{ maxWidth: 1400, margin: "0 auto", padding: "40px 32px" }}>
        <PurchaseFlow />
        <CartFlow />
        <EbayFlow />
        <TradeFlow />
        <AuctionFlow />
        <LabelsFlow />
        <GradingFlow />
        <CreditsFlow />
        <VaultFlow />
        <RevenueMatrix />
        <GapsAndFixes />
        <EmailMessagingFlow />
      </div>
    </div>
  );
}
