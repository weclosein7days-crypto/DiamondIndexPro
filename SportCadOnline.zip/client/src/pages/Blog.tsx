import { useState } from "react";
import { Link } from "wouter";
import { trpc } from "@/lib/trpc";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { CalendarDays, Clock, ChevronRight, Newspaper, Youtube } from "lucide-react";

function SportBadge({ sport }: { sport: string | null }) {
  if (!sport) return null;
  const colorMap: Record<string, string> = {
    baseball: "bg-blue-600/20 text-blue-300 border-blue-500/30",
    basketball: "bg-orange-600/20 text-orange-300 border-orange-500/30",
    football: "bg-green-600/20 text-green-300 border-green-500/30",
    hockey: "bg-cyan-600/20 text-cyan-300 border-cyan-500/30",
    soccer: "bg-yellow-600/20 text-yellow-300 border-yellow-500/30",
  };
  const cls = colorMap[sport.toLowerCase()] ?? "bg-white/10 text-white/60 border-white/20";
  return (
    <span className={`text-xs font-medium px-2 py-0.5 rounded-full border capitalize ${cls}`}>
      {sport}
    </span>
  );
}

function readingTime(content: string) {
  const words = content.split(/\s+/).length;
  return Math.max(1, Math.round(words / 200));
}

function formatDate(d: Date | string | null) {
  if (!d) return "";
  return new Date(d).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
}

export default function Blog() {
  const [offset, setOffset] = useState(0);
  const LIMIT = 12;

  const { data: posts, isLoading } = trpc.blog.listPosts.useQuery(
    { limit: LIMIT, offset },
    { staleTime: 60_000 }
  );

  return (
    <div className="min-h-screen bg-[#060d1f]">
      {/* Hero */}
      <div className="relative overflow-hidden bg-gradient-to-br from-[#0d1f3c] via-[#0a1628] to-[#060d1f] border-b border-white/10">
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiNmZmZmZmYiIGZpbGwtb3BhY2l0eT0iMC4wMyI+PHBhdGggZD0iTTM2IDM0djZoNnYtNmgtNnptNiA2djZoNnYtNmgtNnptLTEyIDBoNnY2aC02di02em0xMiAwaDZ2NmgtNnYtNnoiLz48L2c+PC9nPjwvc3ZnPg==')] opacity-40" />
        <div className="container max-w-6xl py-16 relative">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 rounded-xl bg-[#C41E3A]/20 border border-[#C41E3A]/30 flex items-center justify-center">
              <Newspaper className="w-5 h-5 text-[#C41E3A]" />
            </div>
            <span className="text-[#C41E3A] font-semibold text-sm tracking-widest uppercase">SCO Blog</span>
          </div>
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-4 leading-tight">
            Sports Card News &amp; Insights
          </h1>
          <p className="text-white/60 text-lg max-w-2xl">
            Daily articles on trending players, rookie breakouts, card values, auction results, and everything happening in the hobby — powered by AI and curated for collectors.
          </p>
        </div>
      </div>

      {/* Posts Grid */}
      <div className="container max-w-6xl py-12">
        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {Array.from({ length: 6 }).map((_, i) => (
              <div key={i} className="bg-white/5 rounded-2xl overflow-hidden animate-pulse">
                <div className="h-48 bg-white/10" />
                <div className="p-5 space-y-3">
                  <div className="h-4 bg-white/10 rounded w-1/3" />
                  <div className="h-6 bg-white/10 rounded w-full" />
                  <div className="h-4 bg-white/10 rounded w-4/5" />
                </div>
              </div>
            ))}
          </div>
        ) : !posts || posts.length === 0 ? (
          <div className="text-center py-24">
            <Newspaper className="w-16 h-16 text-white/20 mx-auto mb-4" />
            <h2 className="text-2xl font-bold text-white mb-2">No posts yet</h2>
            <p className="text-white/40 mb-6">The daily blog pipeline will publish its first post tomorrow at 7 AM.</p>
            <Link href="/">
              <Button variant="outline" className="border-white/20 text-white hover:bg-white/10">
                Back to Marketplace
              </Button>
            </Link>
          </div>
        ) : (
          <>
            {/* Featured post (first) */}
            {offset === 0 && posts[0] && (
              <Link href={`/blog/${posts[0].slug}`}>
                <div className="group mb-8 bg-gradient-to-br from-[#0d1f3c] to-[#0a1628] border border-white/10 rounded-2xl overflow-hidden hover:border-[#C41E3A]/40 transition-all duration-300 cursor-pointer">
                  <div className="md:flex">
                    {posts[0].coverImageUrl ? (
                      <div className="md:w-2/5 h-64 md:h-auto overflow-hidden">
                        <img
                          src={posts[0].coverImageUrl}
                          alt={posts[0].title}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                        />
                      </div>
                    ) : (
                      <div className="md:w-2/5 h-64 md:h-auto bg-gradient-to-br from-[#C41E3A]/20 to-[#0d1f3c] flex items-center justify-center">
                        <Newspaper className="w-20 h-20 text-[#C41E3A]/30" />
                      </div>
                    )}
                    <div className="flex-1 p-8 flex flex-col justify-between">
                      <div>
                        <div className="flex items-center gap-3 mb-3">
                          <Badge className="bg-[#C41E3A]/20 text-[#C41E3A] border-[#C41E3A]/30 text-xs">Featured</Badge>
                          <SportBadge sport={posts[0].sport} />
                          {posts[0].youtubeVideoId && (
                            <span className="flex items-center gap-1 text-xs text-red-400">
                              <Youtube className="w-3.5 h-3.5" /> Video
                            </span>
                          )}
                        </div>
                        <h2 className="text-2xl font-bold text-white mb-3 group-hover:text-[#C41E3A] transition-colors leading-snug">
                          {posts[0].title}
                        </h2>
                        <p className="text-white/60 text-sm leading-relaxed line-clamp-3">
                          {posts[0].excerpt}
                        </p>
                      </div>
                      <div className="flex items-center gap-4 mt-6 text-white/40 text-xs">
                        <span className="flex items-center gap-1.5">
                          <CalendarDays className="w-3.5 h-3.5" />
                          {formatDate(posts[0].publishedAt)}
                        </span>
                        <span className="flex items-center gap-1.5">
                          <Clock className="w-3.5 h-3.5" />
                          {readingTime(posts[0].content)} min read
                        </span>
                        <span className="ml-auto flex items-center gap-1 text-[#C41E3A] font-medium text-sm group-hover:gap-2 transition-all">
                          Read More <ChevronRight className="w-4 h-4" />
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </Link>
            )}

            {/* Grid of remaining posts */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {(offset === 0 ? posts.slice(1) : posts).map((post) => (
                <Link key={post.id} href={`/blog/${post.slug}`}>
                  <div className="group bg-[#0d1f3c] border border-white/10 rounded-2xl overflow-hidden hover:border-[#C41E3A]/40 transition-all duration-300 cursor-pointer h-full flex flex-col">
                    {post.coverImageUrl ? (
                      <div className="h-48 overflow-hidden">
                        <img
                          src={post.coverImageUrl}
                          alt={post.title}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                        />
                      </div>
                    ) : (
                      <div className="h-48 bg-gradient-to-br from-[#C41E3A]/10 to-[#0a1628] flex items-center justify-center">
                        <Newspaper className="w-12 h-12 text-[#C41E3A]/20" />
                      </div>
                    )}
                    <div className="p-5 flex flex-col flex-1">
                      <div className="flex items-center gap-2 mb-3">
                        <SportBadge sport={post.sport} />
                        {post.youtubeVideoId && (
                          <span className="flex items-center gap-1 text-xs text-red-400">
                            <Youtube className="w-3 h-3" /> Video
                          </span>
                        )}
                      </div>
                      <h3 className="text-base font-semibold text-white mb-2 group-hover:text-[#C41E3A] transition-colors leading-snug line-clamp-2 flex-1">
                        {post.title}
                      </h3>
                      <p className="text-white/50 text-xs leading-relaxed line-clamp-2 mb-4">
                        {post.excerpt}
                      </p>
                      <div className="flex items-center gap-3 text-white/30 text-xs mt-auto">
                        <span className="flex items-center gap-1">
                          <CalendarDays className="w-3 h-3" />
                          {formatDate(post.publishedAt)}
                        </span>
                        <span className="flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          {readingTime(post.content)} min
                        </span>
                      </div>
                    </div>
                  </div>
                </Link>
              ))}
            </div>

            {/* Pagination */}
            <div className="flex justify-center gap-3 mt-10">
              {offset > 0 && (
                <Button
                  variant="outline"
                  onClick={() => setOffset(Math.max(0, offset - LIMIT))}
                  className="border-white/20 text-white hover:bg-white/10"
                >
                  Previous
                </Button>
              )}
              {posts.length === LIMIT && (
                <Button
                  variant="outline"
                  onClick={() => setOffset(offset + LIMIT)}
                  className="border-white/20 text-white hover:bg-white/10"
                >
                  Load More
                </Button>
              )}
            </div>
          </>
        )}
      </div>

      {/* CTA */}
      <div className="border-t border-white/10 bg-gradient-to-br from-[#0d1f3c] to-[#060d1f]">
        <div className="container max-w-6xl py-16 text-center">
          <h2 className="text-2xl font-bold text-white mb-3">Ready to Buy or Sell Cards?</h2>
          <p className="text-white/50 mb-6">Browse thousands of graded and raw sports cards on SportsCardsOnline.com</p>
          <Link href="/">
            <Button className="bg-[#C41E3A] hover:bg-[#a01830] text-white px-8">
              Shop the Marketplace
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
}
