import { useState, useCallback } from "react";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { Search, Package, Truck, Star, ShoppingCart, ExternalLink, Loader2, AlertCircle } from "lucide-react";

interface SearchResult {
  ebayItemId: string;
  title: string;
  ebayPrice: number;
  shippingCost: number;
  freeShipping: boolean;
  ourPrice: number;
  suggestedOffer: number;
  imageUrl: string | null;
  ebayUrl: string;
  gradeCompany: string;
  grade: string | null;
  acceptsOffers: boolean;
  seller: string;
}

const GRADE_COMPANY_OPTIONS = [
  { value: "any", label: "Any Grader" },
  { value: "BGS", label: "BGS (Beckett)" },
  { value: "PSA", label: "PSA" },
  { value: "SGC", label: "SGC" },
  { value: "CGC", label: "CGC" },
];

const GRADE_OPTIONS = [
  { value: "", label: "Any Grade" },
  { value: "10", label: "10 (Gem Mint / Black Label)" },
  { value: "9.5", label: "9.5" },
  { value: "9", label: "9 (Mint)" },
  { value: "8.5", label: "8.5" },
  { value: "8", label: "8 (Near Mint)" },
];

const COMPANY_COLORS: Record<string, string> = {
  BGS: "bg-blue-900 text-blue-100 border-yellow-500",
  PSA: "bg-red-900 text-red-100 border-red-400",
  SGC: "bg-slate-700 text-slate-100 border-slate-400",
  CGC: "bg-purple-900 text-purple-100 border-purple-400",
  Unknown: "bg-zinc-700 text-zinc-100 border-zinc-500",
};

export default function LiveCardSearch() {
  const { user } = useAuth();
  const [query, setQuery] = useState("");
  const [gradeCompany, setGradeCompany] = useState<"any" | "PSA" | "BGS" | "SGC" | "CGC">("any");
  const [minGrade, setMinGrade] = useState("");
  const [searchQuery, setSearchQuery] = useState<string | null>(null);
  const [selectedCard, setSelectedCard] = useState<SearchResult | null>(null);
  const [showPurchaseDialog, setShowPurchaseDialog] = useState(false);
  const [shippingForm, setShippingForm] = useState({
    name: user?.name || "",
    address: "",
    city: "",
    state: "",
    zip: "",
  });

  // Live search query — only fires when user submits
  const searchResult = trpc.liveSearch.search.useQuery(
    {
      query: searchQuery || "",
      gradeCompany,
      minGrade: minGrade || undefined,
      limit: 20,
    },
    {
      enabled: !!searchQuery && searchQuery.length >= 2,
      staleTime: 30_000,
    }
  );

  const purchaseMutation = trpc.liveSearch.purchase.useMutation({
    onSuccess: (data) => {
      toast.success(`Order #${data.orderId} confirmed. We'll contact you once your card ships.`);
      setShowPurchaseDialog(false);
      setSelectedCard(null);
    },
    onError: (err) => {
      toast.error(`Purchase Failed: ${err.message}`);
    },
  });

  const handleSearch = useCallback(() => {
    if (query.trim().length < 2) {
      toast.error("Type a player name, card name, or set.");
      return;
    }
    setSearchQuery(query.trim());
  }, [query, toast]);

  const handleBuy = (card: SearchResult) => {
    if (!user) {
      toast.error("Please sign in to purchase cards.");
      return;
    }
    setSelectedCard(card);
    setShippingForm(f => ({ ...f, name: user.name || "" }));
    setShowPurchaseDialog(true);
  };

  const handleConfirmPurchase = () => {
    if (!selectedCard) return;
    if (!shippingForm.name || !shippingForm.address || !shippingForm.city || !shippingForm.state || !shippingForm.zip) {
      toast.error("All shipping fields are required.");
      return;
    }
    purchaseMutation.mutate({
      ...selectedCard,
      shippingName: shippingForm.name,
      shippingAddress: shippingForm.address,
      shippingCity: shippingForm.city,
      shippingState: shippingForm.state,
      shippingZip: shippingForm.zip,
    });
  };

  const results: SearchResult[] = (searchResult.data?.results as SearchResult[]) || [];

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Header */}
      <div className="bg-gradient-to-r from-zinc-900 via-zinc-800 to-zinc-900 border-b border-zinc-700 px-4 py-8">
        <div className="max-w-5xl mx-auto">
          <div className="flex items-center gap-3 mb-2">
            <Search className="w-7 h-7 text-yellow-400" />
            <h1 className="text-3xl font-bold text-white">Find Any Card</h1>
          </div>
          <p className="text-zinc-400 mb-6">
            Search the entire eBay graded card market. We source it, mark it up 10%, and handle fulfillment.
            Free shipping is always passed through. Minimum order: <span className="text-yellow-400 font-semibold">$12.00</span>.
          </p>

          {/* Search Bar */}
          <div className="flex flex-col sm:flex-row gap-3">
            <Input
              className="flex-1 bg-zinc-800 border-zinc-600 text-white placeholder:text-zinc-500 text-base h-12"
              placeholder='e.g. "LeBron James" or "Mike Trout 2011 Topps Update"'
              value={query}
              onChange={e => setQuery(e.target.value)}
              onKeyDown={e => e.key === "Enter" && handleSearch()}
            />
            <Select value={gradeCompany} onValueChange={v => setGradeCompany(v as any)}>
              <SelectTrigger className="w-full sm:w-44 bg-zinc-800 border-zinc-600 text-white h-12">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {GRADE_COMPANY_OPTIONS.map(o => (
                  <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={minGrade} onValueChange={setMinGrade}>
              <SelectTrigger className="w-full sm:w-44 bg-zinc-800 border-zinc-600 text-white h-12">
                <SelectValue placeholder="Any Grade" />
              </SelectTrigger>
              <SelectContent>
                {GRADE_OPTIONS.map(o => (
                  <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Button
              onClick={handleSearch}
              disabled={searchResult.isFetching}
              className="h-12 px-6 bg-yellow-500 hover:bg-yellow-400 text-black font-bold"
            >
              {searchResult.isFetching ? <Loader2 className="w-5 h-5 animate-spin" /> : <Search className="w-5 h-5" />}
              <span className="ml-2">Search</span>
            </Button>
          </div>
        </div>
      </div>

      {/* Results */}
      <div className="max-w-5xl mx-auto px-4 py-8">
        {/* Loading */}
        {searchResult.isFetching && (
          <div className="flex flex-col items-center justify-center py-20 gap-4">
            <Loader2 className="w-10 h-10 animate-spin text-yellow-400" />
            <p className="text-zinc-400">Searching eBay live market...</p>
          </div>
        )}

        {/* Error */}
        {searchResult.isError && !searchResult.isFetching && (
          <div className="flex items-center gap-3 p-4 bg-red-950 border border-red-800 rounded-lg">
            <AlertCircle className="w-5 h-5 text-red-400 shrink-0" />
            <p className="text-red-300">Search failed. Please try again.</p>
          </div>
        )}

        {/* Empty */}
        {searchResult.isSuccess && results.length === 0 && !searchResult.isFetching && (
          <div className="text-center py-20">
            <Package className="w-12 h-12 text-zinc-600 mx-auto mb-4" />
            <p className="text-zinc-400 text-lg">No graded cards found above $12 for this search.</p>
            <p className="text-zinc-500 text-sm mt-2">Try a different player name, grade, or grading company.</p>
          </div>
        )}

        {/* Results Grid */}
        {results.length > 0 && !searchResult.isFetching && (
          <>
            <div className="flex items-center justify-between mb-4">
              <p className="text-zinc-400 text-sm">
                Showing <span className="text-white font-semibold">{results.length}</span> cards from live eBay market
              </p>
              <Badge variant="outline" className="text-yellow-400 border-yellow-600">
                All prices include 10% service fee
              </Badge>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {results.map((card) => (
                <Card key={card.ebayItemId} className="bg-zinc-900 border-zinc-700 hover:border-zinc-500 transition-colors overflow-hidden">
                  {/* Card Image */}
                  <div className="relative aspect-[3/4] bg-zinc-800 overflow-hidden">
                    {card.imageUrl ? (
                      <img
                        src={card.imageUrl}
                        alt={card.title}
                        className="w-full h-full object-contain p-2"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center">
                        <Package className="w-12 h-12 text-zinc-600" />
                      </div>
                    )}
                    {/* Grade Badge */}
                    {card.grade && (
                      <div className={`absolute top-2 right-2 px-2 py-1 rounded text-xs font-bold border ${COMPANY_COLORS[card.gradeCompany] || COMPANY_COLORS.Unknown}`}>
                        {card.gradeCompany} {card.grade}
                      </div>
                    )}
                    {/* Accepts Offers Badge */}
                    {card.acceptsOffers && (
                      <div className="absolute top-2 left-2 px-2 py-1 rounded text-xs font-bold bg-green-900 text-green-300 border border-green-600">
                        Best Offer
                      </div>
                    )}
                  </div>

                  <CardContent className="p-3">
                    {/* Title */}
                    <p className="text-white text-sm font-medium line-clamp-2 mb-2 leading-tight">
                      {card.title}
                    </p>

                    {/* Shipping */}
                    <div className="flex items-center gap-1 mb-3">
                      <Truck className="w-3 h-3 text-zinc-400" />
                      {card.freeShipping ? (
                        <span className="text-green-400 text-xs font-semibold">FREE Shipping</span>
                      ) : (
                        <span className="text-zinc-400 text-xs">+${card.shippingCost.toFixed(2)} shipping included</span>
                      )}
                    </div>

                    {/* Price */}
                    <div className="flex items-end justify-between mb-3">
                      <div>
                        <p className="text-yellow-400 text-xl font-bold">${card.ourPrice.toFixed(2)}</p>
                        <p className="text-zinc-500 text-xs">eBay: ${card.ebayPrice.toFixed(2)}{!card.freeShipping && ` + $${card.shippingCost.toFixed(2)} ship`}</p>
                      </div>
                      <a
                        href={card.ebayUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-zinc-500 hover:text-zinc-300 transition-colors"
                        title="View on eBay"
                      >
                        <ExternalLink className="w-4 h-4" />
                      </a>
                    </div>

                    {/* Buy Button */}
                    <Button
                      onClick={() => handleBuy(card)}
                      className="w-full bg-yellow-500 hover:bg-yellow-400 text-black font-bold text-sm"
                    >
                      <ShoppingCart className="w-4 h-4 mr-1" />
                      Order This Card
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </>
        )}

        {/* No search yet */}
        {!searchQuery && !searchResult.isFetching && (
          <div className="text-center py-20">
            <Star className="w-12 h-12 text-zinc-600 mx-auto mb-4" />
            <p className="text-zinc-400 text-lg font-medium">Search any graded card</p>
            <p className="text-zinc-500 text-sm mt-2 max-w-md mx-auto">
              Type a player name above and we'll search the entire eBay graded card market in real-time.
              We source it, you get it — all grades, all companies, all sports.
            </p>
            <div className="flex flex-wrap justify-center gap-2 mt-6">
              {["LeBron James BGS 9.5", "Mike Trout PSA 10", "Patrick Mahomes SGC 9", "Caitlin Clark BGS 10"].map(s => (
                <button
                  key={s}
                  onClick={() => { setQuery(s); setSearchQuery(s); }}
                  className="px-3 py-1.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 text-sm rounded-full border border-zinc-700 transition-colors"
                >
                  {s}
                </button>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Purchase Dialog */}
      <Dialog open={showPurchaseDialog} onOpenChange={setShowPurchaseDialog}>
        <DialogContent className="bg-zinc-900 border-zinc-700 text-white max-w-md">
          <DialogHeader>
            <DialogTitle className="text-white">Complete Your Order</DialogTitle>
          </DialogHeader>

          {selectedCard && (
            <div className="space-y-4">
              {/* Card Summary */}
              <div className="bg-zinc-800 rounded-lg p-3">
                <p className="text-sm text-zinc-300 line-clamp-2 mb-2">{selectedCard.title}</p>
                <div className="flex justify-between items-center">
                  <span className="text-zinc-400 text-sm">
                    {selectedCard.freeShipping ? "Free Shipping" : `+$${selectedCard.shippingCost.toFixed(2)} shipping`}
                  </span>
                  <span className="text-yellow-400 font-bold text-lg">${selectedCard.ourPrice.toFixed(2)}</span>
                </div>
              </div>

              {/* Shipping Address */}
              <div className="space-y-3">
                <Label className="text-zinc-300 font-semibold">Ship To</Label>
                <Input
                  placeholder="Full Name"
                  value={shippingForm.name}
                  onChange={e => setShippingForm(f => ({ ...f, name: e.target.value }))}
                  className="bg-zinc-800 border-zinc-600 text-white"
                />
                <Input
                  placeholder="Street Address"
                  value={shippingForm.address}
                  onChange={e => setShippingForm(f => ({ ...f, address: e.target.value }))}
                  className="bg-zinc-800 border-zinc-600 text-white"
                />
                <div className="grid grid-cols-3 gap-2">
                  <Input
                    placeholder="City"
                    value={shippingForm.city}
                    onChange={e => setShippingForm(f => ({ ...f, city: e.target.value }))}
                    className="bg-zinc-800 border-zinc-600 text-white col-span-1"
                  />
                  <Input
                    placeholder="State"
                    value={shippingForm.state}
                    onChange={e => setShippingForm(f => ({ ...f, state: e.target.value }))}
                    className="bg-zinc-800 border-zinc-600 text-white"
                    maxLength={2}
                  />
                  <Input
                    placeholder="ZIP"
                    value={shippingForm.zip}
                    onChange={e => setShippingForm(f => ({ ...f, zip: e.target.value }))}
                    className="bg-zinc-800 border-zinc-600 text-white"
                  />
                </div>
              </div>

              {/* Note */}
              <p className="text-zinc-500 text-xs">
                By placing this order you agree to pay <span className="text-yellow-400 font-semibold">${selectedCard.ourPrice.toFixed(2)}</span>.
                We'll source your card from eBay and ship it directly to you. Estimated delivery: 5–10 business days.
              </p>
            </div>
          )}

          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setShowPurchaseDialog(false)} className="border-zinc-600">
              Cancel
            </Button>
            <Button
              onClick={handleConfirmPurchase}
              disabled={purchaseMutation.isPending}
              className="bg-yellow-500 hover:bg-yellow-400 text-black font-bold"
            >
              {purchaseMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}
              Confirm Order — ${selectedCard?.ourPrice.toFixed(2)}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
