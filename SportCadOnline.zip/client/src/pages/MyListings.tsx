import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Gavel, Package, Truck, CheckCircle2, Clock, DollarSign,
  AlertCircle, Lock, Unlock, TrendingUp, ArrowRight, ExternalLink,
  ListPlus, ShoppingBag, BarChart2, Eye
} from "lucide-react";
import { toast } from "sonner";
import { Link } from "wouter";

// ── Escrow status badge ───────────────────────────────────────────────────────
function EscrowBadge({ order }: { order: any }) {
  if (order.fundsReleased) {
    return (
      <span className="inline-flex items-center gap-1 text-[11px] font-bold px-2 py-0.5 rounded-full bg-green-500/15 text-green-400 border border-green-500/30">
        <Unlock className="w-3 h-3" /> Funds Released
      </span>
    );
  }
  if (order.status === "delivered" || order.status === "confirmed") {
    return (
      <span className="inline-flex items-center gap-1 text-[11px] font-bold px-2 py-0.5 rounded-full bg-blue-500/15 text-blue-400 border border-blue-500/30">
        <CheckCircle2 className="w-3 h-3" /> Delivered — Release Ready
      </span>
    );
  }
  if (order.status === "shipped") {
    return (
      <span className="inline-flex items-center gap-1 text-[11px] font-bold px-2 py-0.5 rounded-full bg-yellow-500/15 text-yellow-400 border border-yellow-500/30">
        <Truck className="w-3 h-3" /> In Transit
      </span>
    );
  }
  if (order.status === "label_created") {
    return (
      <span className="inline-flex items-center gap-1 text-[11px] font-bold px-2 py-0.5 rounded-full bg-orange-500/15 text-orange-400 border border-orange-500/30">
        <Package className="w-3 h-3" /> Label Created
      </span>
    );
  }
  return (
    <span className="inline-flex items-center gap-1 text-[11px] font-bold px-2 py-0.5 rounded-full bg-purple-500/15 text-purple-400 border border-purple-500/30">
      <Lock className="w-3 h-3" /> Funds Held
    </span>
  );
}

// ── Auction status badge ──────────────────────────────────────────────────────
function AuctionBadge({ auction }: { auction: any }) {
  const colors: Record<string, string> = {
    active: "bg-green-500/15 text-green-400 border-green-500/30",
    ended: "bg-gray-500/15 text-gray-400 border-gray-500/30",
    sold: "bg-blue-500/15 text-blue-400 border-blue-500/30",
    cancelled: "bg-red-500/15 text-red-400 border-red-500/30",
  };
  const cls = colors[auction.status] ?? colors.ended;
  return (
    <span className={`inline-flex items-center gap-1 text-[11px] font-bold px-2 py-0.5 rounded-full border ${cls}`}>
      <Gavel className="w-3 h-3" />
      {auction.status.charAt(0).toUpperCase() + auction.status.slice(1)}
    </span>
  );
}

// ── Sold Order Card ───────────────────────────────────────────────────────────
function SoldOrderCard({ order, onRefresh }: { order: any; onRefresh: () => void }) {
  const [tracking, setTracking] = useState(order.trackingNumber || "");
  const [carrier, setCarrier] = useState<string>(order.shippingMethod || "usps_first_class");
  const [showTracking, setShowTracking] = useState(false);

  const addTracking = trpc.orders.addTracking.useMutation({
    onSuccess: () => { toast.success("Tracking number saved! Buyer has been notified."); onRefresh(); setShowTracking(false); },
    onError: (e) => toast.error(e.message),
  });

  // Only admin can release escrow — sellers see status only
  const payout = parseFloat(order.sellerPayout || order.price || "0");
  const total = parseFloat(order.totalAmount || order.price || "0");
  const fee = parseFloat(order.platformFee || "0");

  return (
    <Card className="bg-[#0d1b2e] border border-white/10 overflow-hidden">
      <CardContent className="p-0">
        <div className="flex gap-0">
          {/* Card image */}
          {order.cardImageUrl && (
            <div className="w-20 shrink-0 bg-black/30">
              <img src={order.cardImageUrl} alt={order.cardTitle} className="w-full h-full object-contain" />
            </div>
          )}
          <div className="flex-1 p-4 min-w-0">
            {/* Header row */}
            <div className="flex items-start justify-between gap-2 mb-2">
              <div className="min-w-0">
                <p className="text-white font-bold text-sm truncate">{order.cardTitle || "Card"}</p>
                <p className="text-white/40 text-[11px]">Order #{order.id} · {new Date(order.createdAt).toLocaleDateString()}</p>
                <p className="text-white/50 text-[11px] mt-0.5">Buyer: {order.buyerName || order.buyerEmail}</p>
              </div>
              <EscrowBadge order={order} />
            </div>

            {/* Fee breakdown */}
            <div className="grid grid-cols-3 gap-2 my-3">
              <div className="bg-white/5 rounded-lg p-2 text-center">
                <div className="text-white font-bold text-sm">${total.toFixed(2)}</div>
                <div className="text-white/40 text-[10px]">Sale Price</div>
              </div>
              <div className="bg-white/5 rounded-lg p-2 text-center">
                <div className="text-red-400 font-bold text-sm">-${fee.toFixed(2)}</div>
                <div className="text-white/40 text-[10px]">Platform (10%)</div>
              </div>
              <div className="bg-white/5 rounded-lg p-2 text-center">
                <div className="text-green-400 font-bold text-sm">${payout.toFixed(2)}</div>
                <div className="text-white/40 text-[10px]">Your Payout</div>
              </div>
            </div>

            {/* Tracking section */}
            {order.trackingNumber ? (
              <div className="flex items-center gap-2 bg-white/5 rounded-lg px-3 py-2 mb-3">
                <Truck className="w-3.5 h-3.5 text-blue-400 shrink-0" />
                <span className="text-white/70 text-[12px]">Tracking: <span className="text-white font-mono font-bold">{order.trackingNumber}</span></span>
                <button onClick={() => setShowTracking(!showTracking)} className="ml-auto text-white/40 hover:text-white/70 text-[11px]">Edit</button>
              </div>
            ) : (
              <button
                onClick={() => setShowTracking(!showTracking)}
                className="flex items-center gap-1.5 text-[12px] text-yellow-400 hover:text-yellow-300 mb-3 font-semibold"
              >
                <AlertCircle className="w-3.5 h-3.5" />
                Add tracking number to release funds
              </button>
            )}

            {showTracking && (
              <div className="flex gap-2 mb-3">
                <Select value={carrier} onValueChange={setCarrier}>
                  <SelectTrigger className="w-36 h-8 text-[12px] bg-white/5 border-white/20 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="usps_first_class">USPS First Class</SelectItem>
                    <SelectItem value="usps_priority">USPS Priority</SelectItem>
                    <SelectItem value="ups_ground">UPS Ground</SelectItem>
                    <SelectItem value="ups_2day">UPS 2-Day</SelectItem>
                    <SelectItem value="ups_next_day">UPS Next Day</SelectItem>
                  </SelectContent>
                </Select>
                <Input
                  value={tracking}
                  onChange={(e) => setTracking(e.target.value)}
                  placeholder="Tracking number"
                  className="flex-1 h-8 text-[12px] bg-white/5 border-white/20 text-white placeholder:text-white/30"
                />
                <Button
                  size="sm"
                  className="h-8 bg-blue-600 hover:bg-blue-500 text-white text-[12px] px-3"
                  disabled={!tracking.trim() || addTracking.isPending}
                  onClick={() => addTracking.mutate({ orderId: order.id, trackingNumber: tracking.trim(), shippingMethod: carrier as any })}
                >
                  Save
                </Button>
              </div>
            )}

            {/* Action buttons */}
            <div className="flex gap-2 items-center">
              {!order.fundsReleased && (
                <span className="text-[11px] text-white/40 flex items-center gap-1">
                  <Lock className="w-3 h-3 text-yellow-400/60" />
                  Funds held — released by SCO after delivery confirmed
                </span>
              )}
              <Button asChild variant="outline" size="sm" className="h-7 border-white/20 text-white/60 hover:bg-white/10 text-[11px] gap-1 ml-auto">
                <Link href={`/orders/${order.id}`}>
                  <Eye className="w-3 h-3" /> View Order
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

// ── Active Auction Card ───────────────────────────────────────────────────────
function ActiveAuctionCard({ auction }: { auction: any }) {
  const endTime = new Date(auction.endTime);
  const now = new Date();
  const msLeft = endTime.getTime() - now.getTime();
  const hoursLeft = Math.max(0, Math.floor(msLeft / 3600000));
  const minutesLeft = Math.max(0, Math.floor((msLeft % 3600000) / 60000));
  const isEnding = hoursLeft < 6 && msLeft > 0;
  const isExpired = msLeft <= 0;

  return (
    <Card className="bg-[#0d1b2e] border border-white/10 overflow-hidden">
      <CardContent className="p-0">
        <div className="flex gap-0">
          {auction.cardImageUrl && (
            <div className="w-20 shrink-0 bg-black/30">
              <img src={auction.cardImageUrl} alt={auction.cardTitle} className="w-full h-full object-contain" />
            </div>
          )}
          <div className="flex-1 p-4 min-w-0">
            <div className="flex items-start justify-between gap-2 mb-2">
              <div className="min-w-0">
                <p className="text-white font-bold text-sm truncate">{auction.cardTitle}</p>
                <p className="text-white/40 text-[11px]">Auction #{auction.id} · {auction.playerName}</p>
              </div>
              <AuctionBadge auction={auction} />
            </div>

            <div className="grid grid-cols-3 gap-2 my-3">
              <div className="bg-white/5 rounded-lg p-2 text-center">
                <div className="text-white font-bold text-sm">${parseFloat(auction.startingPrice || "0").toFixed(2)}</div>
                <div className="text-white/40 text-[10px]">Start Price</div>
              </div>
              <div className="bg-white/5 rounded-lg p-2 text-center">
                <div className="text-green-400 font-bold text-sm">
                  {parseFloat(auction.currentBid || "0") > 0 ? `$${parseFloat(auction.currentBid).toFixed(2)}` : "No bids"}
                </div>
                <div className="text-white/40 text-[10px]">Current Bid</div>
              </div>
              <div className="bg-white/5 rounded-lg p-2 text-center">
                <div className={`font-bold text-sm ${isEnding ? "text-red-400" : isExpired ? "text-gray-400" : "text-yellow-400"}`}>
                  {isExpired ? "Ended" : `${hoursLeft}h ${minutesLeft}m`}
                </div>
                <div className="text-white/40 text-[10px]">Time Left</div>
              </div>
            </div>

            {auction.bidCount > 0 && (
              <p className="text-white/50 text-[11px] mb-2">
                {auction.bidCount} bid{auction.bidCount !== 1 ? "s" : ""} · High bidder: {auction.highestBidderName || auction.highestBidderEmail || "—"}
              </p>
            )}

            <Button asChild variant="outline" size="sm" className="h-7 border-white/20 text-white/60 hover:bg-white/10 text-[11px] gap-1">
              <Link href={`/auctions/${auction.id}`}>
                <ExternalLink className="w-3 h-3" /> View Auction
              </Link>
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

// ── Main Page ─────────────────────────────────────────────────────────────────
export default function MyListings() {
  const { isAuthenticated, loading } = useAuth();
  const [activeTab, setActiveTab] = useState("auctions");

  const { data: myAuctions, isLoading: auctionsLoading, refetch: refetchAuctions } = trpc.auctions.myAuctions.useQuery(undefined, { enabled: isAuthenticated });
  const { data: mySales, isLoading: salesLoading, refetch: refetchSales } = trpc.orders.mySales.useQuery(undefined, { enabled: isAuthenticated });

  if (loading) {
    return (
      <div className="min-h-screen bg-[#060f1a] flex items-center justify-center">
        <div className="w-8 h-8 border-2 border-[#c41e3a] border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-[#060f1a] flex flex-col items-center justify-center gap-4 text-white">
        <ListPlus className="w-12 h-12 text-white/20" />
        <h2 className="text-xl font-bold">Sign in to view your listings</h2>
        <Button asChild className="bg-[#c41e3a] hover:bg-[#c41e3a]/90 text-white">
          <a href={getLoginUrl("/my-listings")}>Sign In</a>
        </Button>
      </div>
    );
  }

  const activeAuctions = (myAuctions || []).filter((a: any) => a.status === "active");
  const endedAuctions = (myAuctions || []).filter((a: any) => a.status !== "active");
  const pendingSales = (mySales || []).filter((o: any) => !o.fundsReleased && o.status !== "cancelled" && o.status !== "refunded");
  const completedSales = (mySales || []).filter((o: any) => o.fundsReleased || o.status === "completed");

  // Summary stats
  const totalEarned = completedSales.reduce((sum: number, o: any) => sum + parseFloat(o.sellerPayout || o.price || "0"), 0);
  const pendingEscrow = pendingSales.reduce((sum: number, o: any) => sum + parseFloat(o.sellerPayout || o.price || "0"), 0);

  return (
    <div className="min-h-screen bg-[#060f1a] text-white">
      {/* Header */}
      <div className="bg-gradient-to-r from-[#0d1b2e] to-[#060f1a] border-b border-white/10 px-4 py-6">
        <div className="max-w-4xl mx-auto">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 rounded-xl bg-[#c41e3a]/20 border border-[#c41e3a]/30 flex items-center justify-center">
              <ListPlus className="w-5 h-5 text-[#c41e3a]" />
            </div>
            <div>
              <h1 className="text-xl font-black text-white">My Listings</h1>
              <p className="text-white/40 text-sm">Manage your auctions, track shipments, and release escrow</p>
            </div>
          </div>

          {/* Stats bar */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {[
              { icon: Gavel, label: "Active Auctions", value: activeAuctions.length, color: "#34A853" },
              { icon: Package, label: "Pending Shipments", value: pendingSales.filter((o: any) => !o.trackingNumber).length, color: "#FBBC05" },
              { icon: Lock, label: "Escrow Held", value: `$${pendingEscrow.toFixed(2)}`, color: "#4285F4" },
              { icon: DollarSign, label: "Total Earned", value: `$${totalEarned.toFixed(2)}`, color: "#34A853" },
            ].map((stat) => (
              <div key={stat.label} className="bg-white/5 rounded-xl p-3 border border-white/10">
                <div className="flex items-center gap-2 mb-1">
                  <stat.icon className="w-3.5 h-3.5" style={{ color: stat.color }} />
                  <span className="text-white/40 text-[11px]">{stat.label}</span>
                </div>
                <div className="text-lg font-black text-white">{stat.value}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="max-w-4xl mx-auto px-4 py-6">
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="bg-white/5 border border-white/10 mb-6">
            <TabsTrigger value="auctions" className="data-[state=active]:bg-[#c41e3a] data-[state=active]:text-white text-white/60 gap-1.5">
              <Gavel className="w-3.5 h-3.5" />
              Auctions
              {activeAuctions.length > 0 && (
                <span className="bg-green-500 text-white text-[10px] font-black px-1.5 py-0.5 rounded-full ml-1">{activeAuctions.length}</span>
              )}
            </TabsTrigger>
            <TabsTrigger value="sales" className="data-[state=active]:bg-[#c41e3a] data-[state=active]:text-white text-white/60 gap-1.5">
              <ShoppingBag className="w-3.5 h-3.5" />
              Sales & Escrow
              {pendingSales.length > 0 && (
                <span className="bg-yellow-500 text-black text-[10px] font-black px-1.5 py-0.5 rounded-full ml-1">{pendingSales.length}</span>
              )}
            </TabsTrigger>
            <TabsTrigger value="history" className="data-[state=active]:bg-[#c41e3a] data-[state=active]:text-white text-white/60 gap-1.5">
              <BarChart2 className="w-3.5 h-3.5" />
              History
            </TabsTrigger>
          </TabsList>

          {/* ── Auctions Tab ── */}
          <TabsContent value="auctions">
            {auctionsLoading ? (
              <div className="flex justify-center py-12"><div className="w-6 h-6 border-2 border-[#c41e3a] border-t-transparent rounded-full animate-spin" /></div>
            ) : (
              <>
                {activeAuctions.length > 0 && (
                  <div className="mb-6">
                    <h3 className="text-white/60 text-xs font-bold uppercase tracking-wider mb-3 flex items-center gap-1.5">
                      <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse" /> Active ({activeAuctions.length})
                    </h3>
                    <div className="space-y-3">
                      {activeAuctions.map((a: any) => <ActiveAuctionCard key={a.id} auction={a} />)}
                    </div>
                  </div>
                )}
                {endedAuctions.length > 0 && (
                  <div>
                    <h3 className="text-white/40 text-xs font-bold uppercase tracking-wider mb-3">Ended ({endedAuctions.length})</h3>
                    <div className="space-y-3">
                      {endedAuctions.map((a: any) => <ActiveAuctionCard key={a.id} auction={a} />)}
                    </div>
                  </div>
                )}
                {(myAuctions || []).length === 0 && (
                  <div className="text-center py-16 text-white/30">
                    <Gavel className="w-10 h-10 mx-auto mb-3 opacity-30" />
                    <p className="font-semibold">No auctions yet</p>
                    <p className="text-sm mt-1">List a card from My Collection to start an auction</p>
                    <Button asChild className="mt-4 bg-[#c41e3a] hover:bg-[#c41e3a]/90 text-white gap-2">
                      <Link href="/my-collection"><ArrowRight className="w-4 h-4" /> Go to My Collection</Link>
                    </Button>
                  </div>
                )}
              </>
            )}
          </TabsContent>

          {/* ── Sales & Escrow Tab ── */}
          <TabsContent value="sales">
            {salesLoading ? (
              <div className="flex justify-center py-12"><div className="w-6 h-6 border-2 border-[#c41e3a] border-t-transparent rounded-full animate-spin" /></div>
            ) : (
              <>
                {pendingSales.length > 0 && (
                  <div className="mb-6">
                    <h3 className="text-white/60 text-xs font-bold uppercase tracking-wider mb-3 flex items-center gap-1.5">
                      <Lock className="w-3 h-3 text-yellow-400" /> Pending Escrow ({pendingSales.length})
                    </h3>
                    <div className="space-y-3">
                      {pendingSales.map((o: any) => <SoldOrderCard key={o.id} order={o} onRefresh={refetchSales} />)}
                    </div>
                  </div>
                )}
                {pendingSales.length === 0 && (
                  <div className="text-center py-16 text-white/30">
                    <CheckCircle2 className="w-10 h-10 mx-auto mb-3 opacity-30" />
                    <p className="font-semibold">No pending sales</p>
                    <p className="text-sm mt-1">All escrow funds have been released</p>
                  </div>
                )}
              </>
            )}
          </TabsContent>

          {/* ── History Tab ── */}
          <TabsContent value="history">
            {salesLoading ? (
              <div className="flex justify-center py-12"><div className="w-6 h-6 border-2 border-[#c41e3a] border-t-transparent rounded-full animate-spin" /></div>
            ) : completedSales.length > 0 ? (
              <div className="space-y-3">
                <h3 className="text-white/40 text-xs font-bold uppercase tracking-wider mb-3 flex items-center gap-1.5">
                  <TrendingUp className="w-3 h-3 text-green-400" /> Completed Sales ({completedSales.length}) · Total Earned: ${totalEarned.toFixed(2)}
                </h3>
                {completedSales.map((o: any) => <SoldOrderCard key={o.id} order={o} onRefresh={refetchSales} />)}
              </div>
            ) : (
              <div className="text-center py-16 text-white/30">
                <BarChart2 className="w-10 h-10 mx-auto mb-3 opacity-30" />
                <p className="font-semibold">No completed sales yet</p>
                <p className="text-sm mt-1">Completed sales will appear here after escrow is released</p>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
