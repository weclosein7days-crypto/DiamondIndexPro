import { useState, useMemo } from "react";
import { Link } from "wouter";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import {
  AreaChart, Area, BarChart, Bar, PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend,
} from "recharts";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Eye, MousePointerClick, FileText, Video, Youtube,
  TrendingUp, Calendar, BarChart2, RefreshCw, ExternalLink,
  ArrowUpRight, Clock, Newspaper, Users, Globe, Search,
  Share2, Link2, Percent,
} from "lucide-react";

const SPORT_COLORS: Record<string, string> = {
  baseball: "#ef4444",
  basketball: "#f97316",
  football: "#22c55e",
  hockey: "#3b82f6",
  soccer: "#a855f7",
  other: "#6b7280",
};

const SPORT_LABELS: Record<string, string> = {
  baseball: "⚾ Baseball",
  basketball: "🏀 Basketball",
  football: "🏈 Football",
  hockey: "🏒 Hockey",
  soccer: "⚽ Soccer",
  other: "🎯 Other",
};

function KpiCard({
  icon: Icon,
  label,
  value,
  sub,
  color = "text-primary",
}: {
  icon: React.ElementType;
  label: string;
  value: string | number;
  sub?: string;
  color?: string;
}) {
  return (
    <Card className="bg-card border-border">
      <CardContent className="pt-5 pb-4">
        <div className="flex items-start justify-between">
          <div>
            <p className="text-xs text-muted-foreground uppercase tracking-wide font-medium mb-1">{label}</p>
            <p className={`text-3xl font-bold ${color}`}>{value}</p>
            {sub && <p className="text-xs text-muted-foreground mt-1">{sub}</p>}
          </div>
          <div className={`p-2 rounded-lg bg-muted ${color}`}>
            <Icon className="h-5 w-5" />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

function SportBadge({ sport }: { sport?: string | null }) {
  if (!sport) return null;
  const colors: Record<string, string> = {
    baseball: "bg-red-500/20 text-red-400 border-red-500/30",
    basketball: "bg-orange-500/20 text-orange-400 border-orange-500/30",
    football: "bg-green-500/20 text-green-400 border-green-500/30",
    hockey: "bg-blue-500/20 text-blue-400 border-blue-500/30",
    soccer: "bg-purple-500/20 text-purple-400 border-purple-500/30",
    other: "bg-gray-500/20 text-gray-400 border-gray-500/30",
  };
  const label = SPORT_LABELS[sport] ?? sport;
  return (
    <span className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-medium border ${colors[sport] ?? colors.other}`}>
      {label}
    </span>
  );
}

function VideoStatusBadge({ status }: { status?: string | null }) {
  if (!status || status === "none") return <span className="text-xs text-muted-foreground">—</span>;
  const map: Record<string, { label: string; cls: string }> = {
    pending: { label: "Pending", cls: "bg-yellow-500/20 text-yellow-400" },
    generating: { label: "Generating", cls: "bg-blue-500/20 text-blue-400" },
    ready: { label: "Ready", cls: "bg-green-500/20 text-green-400" },
    uploading: { label: "Uploading", cls: "bg-purple-500/20 text-purple-400" },
    published: { label: "Published", cls: "bg-emerald-500/20 text-emerald-400" },
    error: { label: "Error", cls: "bg-red-500/20 text-red-400" },
  };
  const { label, cls } = map[status] ?? { label: status, cls: "bg-gray-500/20 text-gray-400" };
  return <span className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-medium ${cls}`}>{label}</span>;
}

// Fill in missing dates in the trend data
function fillDailyTrend(raw: Array<{ date: string; views: number; clicks: number }>) {
  if (!raw.length) {
    // Generate empty 30-day range
    const result = [];
    for (let i = 29; i >= 0; i--) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      result.push({ date: d.toISOString().slice(0, 10), views: 0, clicks: 0 });
    }
    return result;
  }
  const map = new Map(raw.map((r) => [r.date, r]));
  const result = [];
  for (let i = 29; i >= 0; i--) {
    const d = new Date();
    d.setDate(d.getDate() - i);
    const key = d.toISOString().slice(0, 10);
    result.push(map.get(key) ?? { date: key, views: 0, clicks: 0 });
  }
  return result;
}

export default function ContentDashboard() {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState<"overview" | "posts" | "pipeline" | "audience">("overview");

  const { data, isLoading, refetch, isFetching } = trpc.blog.getContentDashboard.useQuery(undefined, {
    staleTime: 60_000,
    enabled: !!user,
  });

  const { data: audienceData, isLoading: audienceLoading } = trpc.blog.getAudienceMetrics.useQuery(undefined, {
    staleTime: 60_000,
    enabled: !!user && activeTab === "audience",
  });

  if (!user) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Card className="max-w-md w-full mx-4">
          <CardContent className="pt-8 pb-8 text-center">
            <Newspaper className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <h2 className="text-xl font-bold mb-2">Content Dashboard</h2>
            <p className="text-muted-foreground mb-4">Sign in to view your content performance metrics.</p>
            <Link href="/">
              <Button>Go to Home</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  const totals = (data?.totals ?? {}) as Record<string, number>;
  const sportBreakdown = (data?.sportBreakdown ?? []) as Array<{ sport: string; count: number; views: number }>;
  const topPosts = (data?.topPosts ?? []) as Array<{
    id: number; title: string; slug: string; sport: string;
    view_count: number; click_count: number; youtubeVideoId: string | null;
    coverImageUrl: string | null; publishedAt: string | null; videoStatus: string;
  }>;
  const dailyTrend = fillDailyTrend(
    (data?.dailyTrend ?? []) as Array<{ date: string; views: number; clicks: number }>
  );
  const recentPosts = (data?.recentPosts ?? []) as Array<{
    id: number; title: string; slug: string; sport: string;
    status: string; videoStatus: string; youtubeVideoId: string | null;
    view_count: number; click_count: number; publishedAt: string | null; createdAt: string;
  }>;

  const pieData = sportBreakdown.map((s) => ({
    name: SPORT_LABELS[s.sport] ?? s.sport,
    value: Number(s.count),
    views: Number(s.views),
    color: SPORT_COLORS[s.sport] ?? "#6b7280",
  }));

  const totalViewsNum = Number(totals.totalViews ?? 0);
  const totalClicksNum = Number(totals.totalClicks ?? 0);
  const ctr = totalViewsNum > 0 ? ((totalClicksNum / totalViewsNum) * 100).toFixed(1) : "0.0";

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Header */}
      <div className="border-b border-border bg-card/50">
        <div className="max-w-7xl mx-auto px-4 py-5 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-primary/10 rounded-lg">
              <BarChart2 className="h-6 w-6 text-primary" />
            </div>
            <div>
              <h1 className="text-xl font-bold">Content Performance</h1>
              <p className="text-xs text-muted-foreground">Track your blog posts, videos &amp; YouTube reach</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" onClick={() => refetch()} disabled={isFetching}>
              <RefreshCw className={`h-4 w-4 mr-1 ${isFetching ? "animate-spin" : ""}`} />
              Refresh
            </Button>
            <Link href="/blog">
              <Button variant="outline" size="sm">
                <ExternalLink className="h-4 w-4 mr-1" />
                View Blog
              </Button>
            </Link>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-6 space-y-6">
        {/* Tab nav */}
        <div className="flex gap-1 bg-muted p-1 rounded-lg w-fit">
          {(["overview", "posts", "pipeline", "audience"] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-4 py-1.5 rounded-md text-sm font-medium transition-colors capitalize ${
                activeTab === tab
                  ? "bg-background text-foreground shadow-sm"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              {tab}
            </button>
          ))}
        </div>

        {isLoading ? (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {Array.from({ length: 8 }).map((_, i) => (
              <Card key={i} className="animate-pulse">
                <CardContent className="pt-5 pb-4 h-24 bg-muted/30 rounded-lg" />
              </Card>
            ))}
          </div>
        ) : (
          <>
            {/* ── OVERVIEW TAB ── */}
            {activeTab === "overview" && (
              <div className="space-y-6">
                {/* KPI row */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <KpiCard
                    icon={Eye}
                    label="Total Views"
                    value={totalViewsNum.toLocaleString()}
                    sub={`${Number(totals.postsThisMonth ?? 0)} posts this month`}
                    color="text-blue-400"
                  />
                  <KpiCard
                    icon={MousePointerClick}
                    label="Total Clicks"
                    value={totalClicksNum.toLocaleString()}
                    sub={`CTR ${ctr}%`}
                    color="text-green-400"
                  />
                  <KpiCard
                    icon={FileText}
                    label="Published Posts"
                    value={Number(totals.publishedPosts ?? 0)}
                    sub={`${Number(totals.totalPosts ?? 0)} total`}
                    color="text-orange-400"
                  />
                  <KpiCard
                    icon={Youtube}
                    label="On YouTube"
                    value={Number(totals.postsOnYouTube ?? 0)}
                    sub={`${Number(totals.postsWithVideo ?? 0)} with video`}
                    color="text-red-400"
                  />
                </div>

                {/* Secondary KPIs */}
                <div className="grid grid-cols-3 gap-4">
                  <KpiCard
                    icon={Calendar}
                    label="Posts Today"
                    value={Number(totals.postsToday ?? 0)}
                    color="text-purple-400"
                  />
                  <KpiCard
                    icon={TrendingUp}
                    label="Posts This Week"
                    value={Number(totals.postsThisWeek ?? 0)}
                    color="text-cyan-400"
                  />
                  <KpiCard
                    icon={ArrowUpRight}
                    label="Posts This Month"
                    value={Number(totals.postsThisMonth ?? 0)}
                    color="text-yellow-400"
                  />
                </div>

                {/* Views trend chart */}
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-base flex items-center gap-2">
                      <TrendingUp className="h-4 w-4 text-primary" />
                      Views &amp; Clicks — Last 30 Days
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={220}>
                      <AreaChart data={dailyTrend} margin={{ top: 4, right: 8, left: 0, bottom: 0 }}>
                        <defs>
                          <linearGradient id="viewsGrad" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3} />
                            <stop offset="95%" stopColor="#3b82f6" stopOpacity={0} />
                          </linearGradient>
                          <linearGradient id="clicksGrad" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="#22c55e" stopOpacity={0.3} />
                            <stop offset="95%" stopColor="#22c55e" stopOpacity={0} />
                          </linearGradient>
                        </defs>
                        <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                        <XAxis
                          dataKey="date"
                          tick={{ fontSize: 10, fill: "#94a3b8" }}
                          tickFormatter={(v) => v.slice(5)}
                          interval={4}
                        />
                        <YAxis tick={{ fontSize: 10, fill: "#94a3b8" }} />
                        <Tooltip
                          contentStyle={{ background: "#1e293b", border: "1px solid #334155", borderRadius: 8 }}
                          labelStyle={{ color: "#e2e8f0", fontSize: 12 }}
                          itemStyle={{ fontSize: 12 }}
                        />
                        <Legend wrapperStyle={{ fontSize: 12 }} />
                        <Area type="monotone" dataKey="views" stroke="#3b82f6" fill="url(#viewsGrad)" strokeWidth={2} name="Views" />
                        <Area type="monotone" dataKey="clicks" stroke="#22c55e" fill="url(#clicksGrad)" strokeWidth={2} name="Clicks" />
                      </AreaChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>

                {/* Sport breakdown */}
                <div className="grid md:grid-cols-2 gap-4">
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-base flex items-center gap-2">
                        <BarChart2 className="h-4 w-4 text-primary" />
                        Posts by Sport
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      {pieData.length === 0 ? (
                        <p className="text-sm text-muted-foreground text-center py-8">No posts yet.</p>
                      ) : (
                        <ResponsiveContainer width="100%" height={200}>
                          <BarChart data={pieData} layout="vertical" margin={{ left: 8, right: 16 }}>
                            <CartesianGrid strokeDasharray="3 3" stroke="#334155" horizontal={false} />
                            <XAxis type="number" tick={{ fontSize: 10, fill: "#94a3b8" }} />
                            <YAxis dataKey="name" type="category" tick={{ fontSize: 10, fill: "#94a3b8" }} width={90} />
                            <Tooltip
                              contentStyle={{ background: "#1e293b", border: "1px solid #334155", borderRadius: 8 }}
                              itemStyle={{ fontSize: 12 }}
                            />
                            <Bar dataKey="value" name="Posts" radius={[0, 4, 4, 0]}>
                              {pieData.map((entry, i) => (
                                <Cell key={i} fill={entry.color} />
                              ))}
                            </Bar>
                          </BarChart>
                        </ResponsiveContainer>
                      )}
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-base flex items-center gap-2">
                        <Eye className="h-4 w-4 text-primary" />
                        Views by Sport
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      {pieData.length === 0 ? (
                        <p className="text-sm text-muted-foreground text-center py-8">No data yet.</p>
                      ) : (
                        <ResponsiveContainer width="100%" height={200}>
                          <PieChart>
                            <Pie
                              data={pieData}
                              dataKey="views"
                              nameKey="name"
                              cx="50%"
                              cy="50%"
                              outerRadius={80}
                              label={({ name, percent }) =>
                                percent > 0.05 ? `${name.split(" ")[1] ?? name} ${(percent * 100).toFixed(0)}%` : ""
                              }
                              labelLine={false}
                            >
                              {pieData.map((entry, i) => (
                                <Cell key={i} fill={entry.color} />
                              ))}
                            </Pie>
                            <Tooltip
                              contentStyle={{ background: "#1e293b", border: "1px solid #334155", borderRadius: 8 }}
                              itemStyle={{ fontSize: 12 }}
                            />
                          </PieChart>
                        </ResponsiveContainer>
                      )}
                    </CardContent>
                  </Card>
                </div>
              </div>
            )}

            {/* ── POSTS TAB ── */}
            {activeTab === "posts" && (
              <div className="space-y-4">
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-base flex items-center gap-2">
                      <TrendingUp className="h-4 w-4 text-primary" />
                      Top Posts by Views
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="p-0">
                    {topPosts.length === 0 ? (
                      <p className="text-sm text-muted-foreground text-center py-10">
                        No published posts yet. Generate your first post in the Admin panel.
                      </p>
                    ) : (
                      <div className="overflow-x-auto">
                        <table className="w-full text-sm">
                          <thead>
                            <tr className="border-b border-border text-xs text-muted-foreground">
                              <th className="text-left px-4 py-3 font-medium">#</th>
                              <th className="text-left px-4 py-3 font-medium">Title</th>
                              <th className="text-left px-4 py-3 font-medium">Sport</th>
                              <th className="text-right px-4 py-3 font-medium">Views</th>
                              <th className="text-right px-4 py-3 font-medium">Clicks</th>
                              <th className="text-left px-4 py-3 font-medium">Video</th>
                              <th className="text-left px-4 py-3 font-medium">Published</th>
                              <th className="text-left px-4 py-3 font-medium">Links</th>
                            </tr>
                          </thead>
                          <tbody>
                            {topPosts.map((post, i) => (
                              <tr key={post.id} className="border-b border-border/50 hover:bg-muted/30 transition-colors">
                                <td className="px-4 py-3 text-muted-foreground font-mono">{i + 1}</td>
                                <td className="px-4 py-3 max-w-xs">
                                  <p className="font-medium truncate" title={post.title}>{post.title}</p>
                                </td>
                                <td className="px-4 py-3">
                                  <SportBadge sport={post.sport} />
                                </td>
                                <td className="px-4 py-3 text-right font-mono text-blue-400">
                                  {Number(post.view_count).toLocaleString()}
                                </td>
                                <td className="px-4 py-3 text-right font-mono text-green-400">
                                  {Number(post.click_count).toLocaleString()}
                                </td>
                                <td className="px-4 py-3">
                                  <VideoStatusBadge status={post.videoStatus} />
                                </td>
                                <td className="px-4 py-3 text-xs text-muted-foreground">
                                  {post.publishedAt
                                    ? new Date(post.publishedAt).toLocaleDateString()
                                    : "—"}
                                </td>
                                <td className="px-4 py-3">
                                  <div className="flex items-center gap-2">
                                    <Link href={`/blog/${post.slug}`}>
                                      <Button variant="ghost" size="sm" className="h-6 px-2 text-xs">
                                        <ExternalLink className="h-3 w-3" />
                                      </Button>
                                    </Link>
                                    {post.youtubeVideoId && (
                                      <a
                                        href={`https://youtube.com/watch?v=${post.youtubeVideoId}`}
                                        target="_blank"
                                        rel="noopener noreferrer"
                                      >
                                        <Button variant="ghost" size="sm" className="h-6 px-2 text-xs text-red-400">
                                          <Youtube className="h-3 w-3" />
                                        </Button>
                                      </a>
                                    )}
                                  </div>
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>
            )}

            {/* ── AUDIENCE TAB ── */}
            {activeTab === "audience" && (
              <AudienceTab data={audienceData} isLoading={audienceLoading} />
            )}

            {/* ── PIPELINE TAB ── */}
            {activeTab === "pipeline" && (
              <div className="space-y-4">
                {/* Pipeline health summary */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <KpiCard
                    icon={FileText}
                    label="Total Posts"
                    value={Number(totals.totalPosts ?? 0)}
                    color="text-foreground"
                  />
                  <KpiCard
                    icon={Newspaper}
                    label="Published"
                    value={Number(totals.publishedPosts ?? 0)}
                    sub={`${Number(totals.totalPosts ?? 0) - Number(totals.publishedPosts ?? 0)} drafts`}
                    color="text-green-400"
                  />
                  <KpiCard
                    icon={Video}
                    label="Videos Ready"
                    value={Number(totals.postsWithVideo ?? 0)}
                    color="text-blue-400"
                  />
                  <KpiCard
                    icon={Youtube}
                    label="On YouTube"
                    value={Number(totals.postsOnYouTube ?? 0)}
                    color="text-red-400"
                  />
                </div>

                {/* Recent posts table */}
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-base flex items-center gap-2">
                      <Clock className="h-4 w-4 text-primary" />
                      Recent Posts — Pipeline Status
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="p-0">
                    {recentPosts.length === 0 ? (
                      <p className="text-sm text-muted-foreground text-center py-10">
                        No posts yet. Use the Admin panel to generate your first post.
                      </p>
                    ) : (
                      <div className="overflow-x-auto">
                        <table className="w-full text-sm">
                          <thead>
                            <tr className="border-b border-border text-xs text-muted-foreground">
                              <th className="text-left px-4 py-3 font-medium">Title</th>
                              <th className="text-left px-4 py-3 font-medium">Sport</th>
                              <th className="text-left px-4 py-3 font-medium">Status</th>
                              <th className="text-left px-4 py-3 font-medium">Video</th>
                              <th className="text-right px-4 py-3 font-medium">Views</th>
                              <th className="text-left px-4 py-3 font-medium">Created</th>
                              <th className="text-left px-4 py-3 font-medium">Actions</th>
                            </tr>
                          </thead>
                          <tbody>
                            {recentPosts.map((post) => (
                              <tr key={post.id} className="border-b border-border/50 hover:bg-muted/30 transition-colors">
                                <td className="px-4 py-3 max-w-xs">
                                  <p className="font-medium truncate" title={post.title}>{post.title}</p>
                                </td>
                                <td className="px-4 py-3">
                                  <SportBadge sport={post.sport} />
                                </td>
                                <td className="px-4 py-3">
                                  <Badge
                                    variant={post.status === "published" ? "default" : "secondary"}
                                    className="text-xs capitalize"
                                  >
                                    {post.status}
                                  </Badge>
                                </td>
                                <td className="px-4 py-3">
                                  <VideoStatusBadge status={post.videoStatus} />
                                </td>
                                <td className="px-4 py-3 text-right font-mono text-blue-400">
                                  {Number(post.view_count).toLocaleString()}
                                </td>
                                <td className="px-4 py-3 text-xs text-muted-foreground">
                                  {new Date(post.createdAt).toLocaleDateString()}
                                </td>
                                <td className="px-4 py-3">
                                  <div className="flex items-center gap-2">
                                    {post.status === "published" && (
                                      <Link href={`/blog/${post.slug}`}>
                                        <Button variant="ghost" size="sm" className="h-6 px-2 text-xs">
                                          <ExternalLink className="h-3 w-3" />
                                        </Button>
                                      </Link>
                                    )}
                                    {post.youtubeVideoId && (
                                      <a
                                        href={`https://youtube.com/watch?v=${post.youtubeVideoId}`}
                                        target="_blank"
                                        rel="noopener noreferrer"
                                      >
                                        <Button variant="ghost" size="sm" className="h-6 px-2 text-xs text-red-400">
                                          <Youtube className="h-3 w-3" />
                                        </Button>
                                      </a>
                                    )}
                                  </div>
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    )}
                  </CardContent>
                </Card>

                {/* Pipeline guidance */}
                <Card className="border-primary/20 bg-primary/5">
                  <CardContent className="pt-5 pb-4">
                    <h3 className="font-semibold mb-2 flex items-center gap-2">
                      <TrendingUp className="h-4 w-4 text-primary" />
                      Content Pipeline Guide
                    </h3>
                    <div className="grid md:grid-cols-3 gap-4 text-sm text-muted-foreground">
                      <div>
                        <p className="font-medium text-foreground mb-1">Step 1 — Generate Post</p>
                        <p>Admin panel → Blog tab → Generate Post. AI fetches trending sports news and writes a 700–900 word SEO article.</p>
                      </div>
                      <div>
                        <p className="font-medium text-foreground mb-1">Step 2 — Create Video</p>
                        <p>Click "Generate Video" on any post. Python + ffmpeg creates a narrated slideshow with cover image and TTS audio.</p>
                      </div>
                      <div>
                        <p className="font-medium text-foreground mb-1">Step 3 — Publish to YouTube</p>
                        <p>Click "Upload to YouTube" once the video is ready. Requires YouTube OAuth credentials in server environment.</p>
                      </div>
                    </div>
                    <div className="mt-3 pt-3 border-t border-border/50">
                      <p className="text-xs text-muted-foreground">
                        <strong className="text-foreground">Auto-pilot:</strong> The daily cron job runs at 7:00 AM and automatically generates a post, creates a video, and uploads to YouTube — no manual action needed.
                      </p>
                    </div>
                  </CardContent>
                </Card>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}

// ─── Audience Tab Component ───────────────────────────────────────────────────

const SOURCE_COLORS: Record<string, string> = {
  Direct: "#3b82f6",
  Search: "#22c55e",
  Social: "#f97316",
  Internal: "#a855f7",
  Other: "#6b7280",
};

const SOURCE_ICONS: Record<string, React.ElementType> = {
  Direct: Link2,
  Search: Search,
  Social: Share2,
  Internal: Globe,
  Other: Globe,
};

type AudienceData = {
  referralSources: Array<{ source: string; views: number; clicks: number }>;
  topReferrers: Array<{ domain: string; views: number }>;
  sportViews: Array<{ sport: string; views: number; clicks: number; posts: number }>;
  engagementRate: number;
  totalViews: number;
  totalClicks: number;
  avgViewsPerPost: number;
  postsWithViews: number;
};

function AudienceTab({ data, isLoading }: { data?: AudienceData; isLoading: boolean }) {
  const referralSources = (data?.referralSources ?? []) as AudienceData["referralSources"];
  const topReferrers = (data?.topReferrers ?? []) as AudienceData["topReferrers"];
  const sportViews = (data?.sportViews ?? []) as AudienceData["sportViews"];
  const engagementRate = Number(data?.engagementRate ?? 0);
  const totalViews = Number(data?.totalViews ?? 0);
  const totalClicks = Number(data?.totalClicks ?? 0);
  const avgViewsPerPost = Number(data?.avgViewsPerPost ?? 0);
  const postsWithViews = Number(data?.postsWithViews ?? 0);

  // Pie data for referral sources
  const sourcePieData = referralSources
    .filter((s) => s.views > 0)
    .map((s) => ({
      name: s.source,
      value: Number(s.views),
      clicks: Number(s.clicks),
      color: SOURCE_COLORS[s.source] ?? "#6b7280",
    }));

  // Sport views bar data
  const sportBarData = sportViews.map((s) => ({
    name: SPORT_LABELS[s.sport] ?? s.sport,
    views: Number(s.views),
    clicks: Number(s.clicks),
    color: SPORT_COLORS[s.sport] ?? "#6b7280",
  }));

  // Estimate new vs returning: posts with 0 views = new audience potential
  const returningEstimate = postsWithViews > 0 ? Math.round((postsWithViews / Math.max(1, postsWithViews + 2)) * 100) : 0;
  const newEstimate = 100 - returningEstimate;

  const newVsReturning = [
    { name: "Returning", value: returningEstimate, color: "#3b82f6" },
    { name: "New", value: newEstimate, color: "#22c55e" },
  ];

  if (isLoading) {
    return (
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {Array.from({ length: 8 }).map((_, i) => (
          <Card key={i} className="animate-pulse">
            <CardContent className="pt-5 pb-4 h-24 bg-muted/30 rounded-lg" />
          </Card>
        ))}
      </div>
    );
  }

  const hasData = totalViews > 0;

  return (
    <div className="space-y-6">
      {/* KPI row */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <KpiCard
          icon={Eye}
          label="Total Views"
          value={totalViews.toLocaleString()}
          sub="all time"
          color="text-blue-400"
        />
        <KpiCard
          icon={Percent}
          label="Engagement Rate"
          value={`${engagementRate}%`}
          sub="clicks ÷ views"
          color="text-green-400"
        />
        <KpiCard
          icon={BarChart2}
          label="Avg Views / Post"
          value={avgViewsPerPost.toLocaleString()}
          sub="published posts"
          color="text-orange-400"
        />
        <KpiCard
          icon={Users}
          label="Posts with Views"
          value={postsWithViews}
          sub={`${totalClicks.toLocaleString()} total clicks`}
          color="text-purple-400"
        />
      </div>

      {/* Referral source + new vs returning */}
      <div className="grid md:grid-cols-2 gap-4">
        {/* Referral source breakdown */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base flex items-center gap-2">
              <Share2 className="h-4 w-4 text-primary" />
              Traffic Sources
            </CardTitle>
          </CardHeader>
          <CardContent>
            {!hasData || sourcePieData.length === 0 ? (
              <div className="text-center py-10">
                <Globe className="h-10 w-10 text-muted-foreground mx-auto mb-3" />
                <p className="text-sm text-muted-foreground">No traffic data yet.</p>
                <p className="text-xs text-muted-foreground mt-1">Views will appear here once readers visit your blog posts.</p>
              </div>
            ) : (
              <div className="space-y-4">
                <ResponsiveContainer width="100%" height={180}>
                  <PieChart>
                    <Pie
                      data={sourcePieData}
                      dataKey="value"
                      nameKey="name"
                      cx="50%"
                      cy="50%"
                      outerRadius={70}
                      innerRadius={35}
                      label={({ name, percent }) =>
                        percent > 0.05 ? `${name} ${(percent * 100).toFixed(0)}%` : ""
                      }
                      labelLine={false}
                    >
                      {sourcePieData.map((entry, i) => (
                        <Cell key={i} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip
                      contentStyle={{ background: "#1e293b", border: "1px solid #334155", borderRadius: 8 }}
                      formatter={(value: number, name: string) => [`${value.toLocaleString()} views`, name]}
                      itemStyle={{ fontSize: 12 }}
                    />
                  </PieChart>
                </ResponsiveContainer>
                {/* Legend with click rates */}
                <div className="space-y-2">
                  {sourcePieData.map((s) => {
                    const SourceIcon = SOURCE_ICONS[s.name] ?? Globe;
                    const pct = totalViews > 0 ? ((s.value / totalViews) * 100).toFixed(1) : "0";
                    const ctr = s.value > 0 ? ((s.clicks / s.value) * 100).toFixed(1) : "0";
                    return (
                      <div key={s.name} className="flex items-center justify-between text-sm">
                        <div className="flex items-center gap-2">
                          <div className="w-2.5 h-2.5 rounded-full shrink-0" style={{ background: s.color }} />
                          <SourceIcon className="h-3.5 w-3.5 text-muted-foreground" />
                          <span className="font-medium">{s.name}</span>
                        </div>
                        <div className="flex items-center gap-3 text-xs text-muted-foreground">
                          <span className="font-mono">{s.value.toLocaleString()} views</span>
                          <span className="text-muted-foreground/60">{pct}%</span>
                          <span className="text-green-400">CTR {ctr}%</span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* New vs Returning estimate */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base flex items-center gap-2">
              <Users className="h-4 w-4 text-primary" />
              Audience Composition
            </CardTitle>
          </CardHeader>
          <CardContent>
            {!hasData ? (
              <div className="text-center py-10">
                <Users className="h-10 w-10 text-muted-foreground mx-auto mb-3" />
                <p className="text-sm text-muted-foreground">No audience data yet.</p>
              </div>
            ) : (
              <div className="space-y-4">
                <ResponsiveContainer width="100%" height={160}>
                  <PieChart>
                    <Pie
                      data={newVsReturning}
                      dataKey="value"
                      nameKey="name"
                      cx="50%"
                      cy="50%"
                      outerRadius={65}
                      innerRadius={30}
                      label={({ name, value }) => `${name} ${value}%`}
                      labelLine={false}
                    >
                      {newVsReturning.map((entry, i) => (
                        <Cell key={i} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip
                      contentStyle={{ background: "#1e293b", border: "1px solid #334155", borderRadius: 8 }}
                      formatter={(value: number, name: string) => [`${value}%`, name]}
                      itemStyle={{ fontSize: 12 }}
                    />
                  </PieChart>
                </ResponsiveContainer>
                <div className="space-y-3 text-sm">
                  {newVsReturning.map((s) => (
                    <div key={s.name} className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="w-2.5 h-2.5 rounded-full" style={{ background: s.color }} />
                        <span className="font-medium">{s.name} Visitors</span>
                      </div>
                      <span className="font-mono text-muted-foreground">{s.value}%</span>
                    </div>
                  ))}
                </div>
                <p className="text-xs text-muted-foreground border-t border-border/50 pt-3">
                  Estimated from posts with engagement vs. total published posts. Actual session data requires a dedicated analytics integration.
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Sport interest + top referrers */}
      <div className="grid md:grid-cols-2 gap-4">
        {/* Sport interest bar chart */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base flex items-center gap-2">
              <TrendingUp className="h-4 w-4 text-primary" />
              Audience Interest by Sport
            </CardTitle>
          </CardHeader>
          <CardContent>
            {sportBarData.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-8">No sport data yet.</p>
            ) : (
              <ResponsiveContainer width="100%" height={200}>
                <BarChart data={sportBarData} layout="vertical" margin={{ left: 8, right: 16 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#334155" horizontal={false} />
                  <XAxis type="number" tick={{ fontSize: 10, fill: "#94a3b8" }} />
                  <YAxis dataKey="name" type="category" tick={{ fontSize: 10, fill: "#94a3b8" }} width={95} />
                  <Tooltip
                    contentStyle={{ background: "#1e293b", border: "1px solid #334155", borderRadius: 8 }}
                    itemStyle={{ fontSize: 12 }}
                  />
                  <Bar dataKey="views" name="Views" radius={[0, 4, 4, 0]}>
                    {sportBarData.map((entry, i) => (
                      <Cell key={i} fill={entry.color} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            )}
          </CardContent>
        </Card>

        {/* Top referrer domains */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base flex items-center gap-2">
              <Globe className="h-4 w-4 text-primary" />
              Top Referrer Domains
            </CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            {topReferrers.length === 0 ? (
              <div className="text-center py-10 px-4">
                <Link2 className="h-10 w-10 text-muted-foreground mx-auto mb-3" />
                <p className="text-sm text-muted-foreground">No external referrers yet.</p>
                <p className="text-xs text-muted-foreground mt-1">Referrer domains appear when visitors arrive from external links.</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-border text-xs text-muted-foreground">
                      <th className="text-left px-4 py-3 font-medium">#</th>
                      <th className="text-left px-4 py-3 font-medium">Domain</th>
                      <th className="text-right px-4 py-3 font-medium">Views</th>
                      <th className="text-right px-4 py-3 font-medium">Share</th>
                    </tr>
                  </thead>
                  <tbody>
                    {topReferrers.map((r, i) => {
                      const share = totalViews > 0 ? ((r.views / totalViews) * 100).toFixed(1) : "0";
                      return (
                        <tr key={r.domain} className="border-b border-border/50 hover:bg-muted/30 transition-colors">
                          <td className="px-4 py-2.5 text-muted-foreground font-mono text-xs">{i + 1}</td>
                          <td className="px-4 py-2.5">
                            <div className="flex items-center gap-2">
                              <Globe className="h-3.5 w-3.5 text-muted-foreground shrink-0" />
                              <span className="font-medium truncate max-w-[160px]" title={r.domain}>{r.domain}</span>
                            </div>
                          </td>
                          <td className="px-4 py-2.5 text-right font-mono text-blue-400">
                            {Number(r.views).toLocaleString()}
                          </td>
                          <td className="px-4 py-2.5 text-right">
                            <div className="flex items-center justify-end gap-1.5">
                              <div className="w-16 h-1.5 bg-muted rounded-full overflow-hidden">
                                <div
                                  className="h-full bg-blue-400 rounded-full"
                                  style={{ width: `${Math.min(100, parseFloat(share))}%` }}
                                />
                              </div>
                              <span className="text-xs text-muted-foreground font-mono w-10 text-right">{share}%</span>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Engagement breakdown by source */}
      {sourcePieData.length > 0 && (
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base flex items-center gap-2">
              <MousePointerClick className="h-4 w-4 text-primary" />
              Click-Through Rate by Traffic Source
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={180}>
              <BarChart data={sourcePieData} margin={{ top: 4, right: 16, left: 0, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                <XAxis dataKey="name" tick={{ fontSize: 11, fill: "#94a3b8" }} />
                <YAxis tick={{ fontSize: 10, fill: "#94a3b8" }} unit="%" domain={[0, 100]} />
                <Tooltip
                  contentStyle={{ background: "#1e293b", border: "1px solid #334155", borderRadius: 8 }}
                  formatter={(value: number) => [`${value.toFixed(1)}%`, "CTR"]}
                  itemStyle={{ fontSize: 12 }}
                />
                <Bar
                  dataKey={(d) => d.value > 0 ? parseFloat(((d.clicks / d.value) * 100).toFixed(1)) : 0}
                  name="CTR"
                  radius={[4, 4, 0, 0]}
                >
                  {sourcePieData.map((entry, i) => (
                    <Cell key={i} fill={entry.color} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
            <p className="text-xs text-muted-foreground mt-2">
              CTR = clicks ÷ views per traffic source. Higher CTR indicates more engaged visitors from that channel.
            </p>
          </CardContent>
        </Card>
      )}

      {/* Data note */}
      <Card className="border-yellow-500/20 bg-yellow-500/5">
        <CardContent className="pt-4 pb-4">
          <p className="text-xs text-muted-foreground">
            <strong className="text-foreground">About this data:</strong> Views and clicks are tracked server-side when visitors read blog posts on this platform. Referrer data comes from the HTTP <code className="bg-muted px-1 rounded">Referer</code> header captured at read time. Traffic source classification uses domain pattern matching (Google/Bing = Search, Facebook/Twitter = Social, etc.). New vs. returning estimates are approximated from post engagement ratios — for precise session analytics, consider integrating a dedicated tool such as Plausible or Google Analytics.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
