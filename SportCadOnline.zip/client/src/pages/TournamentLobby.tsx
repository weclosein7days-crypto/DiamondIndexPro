import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import {
  TOURNAMENT_CONFIGS,
  calcTournamentPrizes,
  TOKENS_PER_CREDIT,
  type TournamentConfig,
} from "@/lib/gameEconomy";
import {
  Trophy, Users, Coins, ChevronRight, ArrowLeft,
  Crown, Medal, Award, Zap, Lock,
} from "lucide-react";

// ─── Payout badge colours ─────────────────────────────────────────────────────
const PLACE_STYLES = [
  "bg-yellow-500/20 border-yellow-500/50 text-yellow-400",   // 1st
  "bg-gray-400/20  border-gray-400/50  text-gray-300",       // 2nd
  "bg-amber-700/20 border-amber-700/50 text-amber-500",      // 3rd
];
const PLACE_ICONS = [Crown, Medal, Award];

// ─── Tier accent colours ──────────────────────────────────────────────────────
function tierColor(buyIn: number) {
  if (buyIn >= 100) return { border: "#a855f7", glow: "rgba(168,85,247,0.3)", badge: "bg-purple-500/20 text-purple-300 border-purple-500/40" };
  if (buyIn >= 50)  return { border: "#f59e0b", glow: "rgba(245,158,11,0.3)",  badge: "bg-yellow-500/20 text-yellow-300 border-yellow-500/40" };
  if (buyIn >= 35)  return { border: "#ef4444", glow: "rgba(239,68,68,0.3)",   badge: "bg-red-500/20 text-red-300 border-red-500/40" };
  if (buyIn >= 10)  return { border: "#3b82f6", glow: "rgba(59,130,246,0.3)",  badge: "bg-blue-500/20 text-blue-300 border-blue-500/40" };
  return              { border: "#22c55e", glow: "rgba(34,197,94,0.3)",         badge: "bg-green-500/20 text-green-300 border-green-500/40" };
}

// ─── Simulated seat fill (replace with real data when multiplayer is live) ────
function useFakeSeats(configId: string) {
  const [seats] = useState(() => Math.floor(Math.random() * 4)); // 0-3 filled
  return seats;
}

// ─── Single tournament card ───────────────────────────────────────────────────
function TournamentCard({ config, userCredits, onRegister }: {
  config: TournamentConfig;
  userCredits: number;
  onRegister: (config: TournamentConfig) => void;
}) {
  const filledSeats = useFakeSeats(config.id);
  const totalSeats = config.maxSeats;
  const colors = tierColor(config.buyInCredits);
  const canAfford = userCredits >= config.buyInCredits;
  const prizes = calcTournamentPrizes(config, totalSeats); // show full-table prizes

  return (
    <div
      className="relative rounded-xl border overflow-hidden transition-all duration-300 hover:scale-[1.02]"
      style={{
        borderColor: colors.border,
        boxShadow: `0 0 18px ${colors.glow}`,
        background: "linear-gradient(135deg, #0d1f3c 0%, #060e1a 100%)",
      }}
    >
      {/* Variant badge */}
      {config.variant && (
        <div className="absolute top-2 right-2">
          <Badge className="text-[9px] font-black tracking-widest bg-white/10 text-white/50 border-white/20">
            TABLE {config.variant}
          </Badge>
        </div>
      )}

      {/* Header */}
      <div className="p-4 pb-2">
        <div className="flex items-start gap-3">
          <div className="w-10 h-10 rounded-lg flex items-center justify-center text-xl shrink-0"
            style={{ background: `${colors.glow}`, border: `1px solid ${colors.border}` }}>
            {config.buyInCredits >= 100 ? "👑" : config.buyInCredits >= 50 ? "🔥" : config.buyInCredits >= 35 ? "⚡" : config.buyInCredits >= 10 ? "🃏" : "🎯"}
          </div>
          <div className="flex-1 min-w-0">
            <h3 className="font-black text-white text-sm leading-tight" style={{ fontFamily: "Oswald, sans-serif" }}>
              {config.name}
            </h3>
            <div className="flex items-center gap-2 mt-1 flex-wrap">
              <Badge className={`text-[10px] font-bold border ${colors.badge}`}>
                {config.buyInCredits} CR buy-in
              </Badge>
              <Badge className="text-[10px] bg-white/10 text-white/60 border-white/20">
                {config.startingChips.toLocaleString()} chips
              </Badge>
              <Badge className="text-[10px] bg-white/10 text-white/60 border-white/20">
                {config.prizeType === "card" ? "🏆 Card Prize" : config.prizeType === "mixed" ? "🎴 Card + Credits" : "💰 Credits"}
              </Badge>
            </div>
          </div>
        </div>
      </div>

      {/* Seat progress */}
      <div className="px-4 py-2">
        <div className="flex items-center justify-between text-xs text-white/50 mb-1">
          <span className="flex items-center gap-1"><Users className="w-3 h-3" /> Seats</span>
          <span className="font-bold text-white/70">{filledSeats} / {totalSeats} filled</span>
        </div>
        <div className="h-1.5 rounded-full bg-white/10 overflow-hidden">
          <div
            className="h-full rounded-full transition-all"
            style={{ width: `${(filledSeats / totalSeats) * 100}%`, background: colors.border }}
          />
        </div>
        {filledSeats >= config.minSeats && (
          <p className="text-[10px] text-green-400 mt-1 font-bold">✓ Enough players — starts soon!</p>
        )}
      </div>

      {/* Payout table */}
      <div className="px-4 pb-3">
        <p className="text-[10px] text-white/40 font-bold uppercase tracking-widest mb-2">Prize Pool (full table)</p>
        <div className="space-y-1">
          {prizes.places.map((p, i) => {
            const Icon = PLACE_ICONS[i] ?? Award;
            return (
              <div key={p.place} className={`flex items-center justify-between rounded-md px-2 py-1 border text-xs ${PLACE_STYLES[i] ?? PLACE_STYLES[2]}`}>
                <span className="flex items-center gap-1.5 font-bold">
                  <Icon className="w-3 h-3" />
                  {p.place === 1 ? "1st Place" : p.place === 2 ? "2nd Place" : "3rd Place"}
                </span>
                <span className="font-black tabular-nums">
                  {config.prizeType === "card" || config.prizeType === "mixed"
                    ? p.place === 1 ? `Card (~${p.credits} CR value)` : `${p.credits} CR`
                    : `${p.credits} CR`}
                </span>
              </div>
            );
          })}
        </div>
        <p className="text-[10px] text-white/30 mt-1.5">House: {prizes.houseCut} CR (5% rake)</p>
      </div>

      {/* Register button */}
      <div className="px-4 pb-4">
        {canAfford ? (
          <Button
            className="w-full font-black text-sm gap-2"
            style={{ background: colors.border, color: "#fff" }}
            onClick={() => onRegister(config)}
          >
            <Zap className="w-4 h-4" />
            Register — {config.buyInCredits} Credits
          </Button>
        ) : (
          <Button
            className="w-full font-black text-sm gap-2 opacity-60"
            variant="outline"
            disabled
          >
            <Lock className="w-4 h-4" />
            Need {config.buyInCredits - userCredits} more credits
          </Button>
        )}
      </div>
    </div>
  );
}

// ─── Main Page ────────────────────────────────────────────────────────────────
export default function TournamentLobby() {
  const { isAuthenticated, user } = useAuth();
  const [, navigate] = useLocation();
  const [filter, setFilter] = useState<"all" | "affordable">("all");

  const { data: creditData } = trpc.credits.myAccount.useQuery(undefined, {
    enabled: isAuthenticated,
  });
  const userCredits = creditData?.credits ?? 0;

  const registerMutation = trpc.game.registerTournament.useMutation({
    onSuccess: (data: { success: boolean; minSeats: number; name: string }) => {
      toast.success(`Registered for ${data.name}! Starts when ${data.minSeats} seats fill.`);
    },
    onError: (err: { message: string }) => {
      toast.error(err.message);
    },
  });

  const handleRegister = (config: TournamentConfig) => {
    if (!isAuthenticated) {
      window.location.href = getLoginUrl("/game-room/tournaments");
      return;
    }
    registerMutation.mutate({ tournamentConfigId: config.id });
  };

  const displayed = TOURNAMENT_CONFIGS.filter(c =>
    filter === "affordable" ? userCredits >= c.buyInCredits : true
  );

  return (
    <div className="min-h-screen bg-[#060e1a]" style={{ fontFamily: "Oswald, sans-serif" }}>
      {/* Header */}
      <div className="bg-gradient-to-r from-[#1a0a0e] via-[#0a1628] to-[#1a0a0e] border-b border-[#c41e3a]/30 px-4 py-4">
        <div className="max-w-5xl mx-auto flex items-center gap-4">
          <Button asChild variant="ghost" size="sm" className="text-white/60 hover:text-white gap-1">
            <Link href="/game-room"><ArrowLeft className="w-4 h-4" /> Game Room</Link>
          </Button>
          <div className="flex-1">
            <h1 className="text-2xl font-black text-white tracking-widest">🏆 TOURNAMENT LOBBY</h1>
            <p className="text-white/50 text-xs tracking-wider">Buy in · Play AI opponents · Final table in 20 min · Win 5× your buy-in</p>
          </div>
          {isAuthenticated && (
            <div className="flex items-center gap-1.5 bg-black/40 border border-yellow-500/30 rounded-lg px-3 py-1.5">
              <Coins className="w-4 h-4 text-yellow-400" />
              <span className="text-yellow-400 font-black text-sm">{userCredits.toLocaleString()} CR</span>
            </div>
          )}
        </div>
      </div>

      {/* Filter bar */}
      <div className="max-w-5xl mx-auto px-4 pt-5 pb-2 flex items-center gap-3">
        <span className="text-white/40 text-xs font-bold uppercase tracking-widest">Show:</span>
        {(["all", "affordable"] as const).map(f => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={`text-xs font-black px-3 py-1 rounded-full border transition-all ${
              filter === f
                ? "bg-[#c41e3a] border-[#c41e3a] text-white"
                : "border-white/20 text-white/50 hover:border-white/40 hover:text-white/80"
            }`}
          >
            {f === "all" ? "All Tournaments" : "I Can Afford"}
          </button>
        ))}
        <span className="ml-auto text-white/30 text-xs">{displayed.length} tables available</span>
      </div>

      {/* Tournament grid */}
      <div className="max-w-5xl mx-auto px-4 pb-10">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 mt-3">
          {displayed.map(config => (
            <TournamentCard
              key={config.id}
              config={config}
              userCredits={userCredits}
              onRegister={handleRegister}
            />
          ))}
        </div>

        {/* How it works */}
        <div className="mt-10 rounded-xl border border-white/10 bg-[#0d1f3c]/60 p-6">
          <h2 className="text-lg font-black text-white mb-4 tracking-widest">HOW TOURNAMENTS WORK</h2>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-sm text-white/70">
            <div>
              <p className="text-yellow-400 font-black mb-1">1. Register</p>
              <p>Pay the buy-in in credits. You get starting chips and are seated immediately. AI opponents fill any empty seats so the tournament always runs.</p>
            </div>
            <div>
              <p className="text-yellow-400 font-black mb-1">2. Play</p>
              <p>Texas Hold’em. Blinds escalate every 10 hands. If a real player joins mid-tournament, they sit at the same table. After 20 minutes it’s the Final Table — play it out to the end.</p>
            </div>
            <div>
              <p className="text-yellow-400 font-black mb-1">3. Win</p>
              <p>Prize pool = buy-in × seats × <span className="text-yellow-400 font-black">5×</span>. Top finishers win credits or a real card from the Prize Vault. 5% house rake applies.</p>
            </div>
          </div>
          <p className="text-white/30 text-xs mt-4">
            * Prize cards are physical cards shipped to your address. Card prizes are awarded at 50% of prize pool value for 1st place.
            Tournaments with card prizes require a minimum of {TOURNAMENT_CONFIGS.find(c => c.prizeType === "card")?.minSeats ?? 4} registered players.
          </p>
        </div>
      </div>
    </div>
  );
}
