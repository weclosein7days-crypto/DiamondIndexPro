import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import QuickDepositModal from "@/components/QuickDepositModal";
import { Badge } from "@/components/ui/badge";
import { Coins, Sparkles, Zap, Trophy, Star, Gift, Dice6, Flame, Crown, ChevronRight, Lock, Clock, CheckCircle } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import NavBar from "@/components/NavBar";
import Footer from "@/components/Footer";
import { toast } from "sonner";
import { Link } from "wouter";
import { GameTimesTicker } from "@/components/GameTimesTicker";
import { CardWinModal, type CardPrize } from "@/components/CardWinModal";

const GAME_ROOM_BG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663482618714/HBSXFxHmEnEJMgVvzKnhpZ/game-room-banner-bRCmiodsb9mq6DcR9BYAXK.webp";
const LOGO_URL = "https://d2xsxph8kpxj0f.cloudfront.net/310519663482618714/HBSXFxHmEnEJMgVvzKnhpZ/logo_transparent_8c903811.png";

// ─── Prize Showcase Data ─────────────────────────────────────────────────────
const SHOWCASE_PRIZES = [
  {
    tier: "MEGA JACKPOT",
    name: "Caitlin Clark",
    detail: "2024 Panini Prizm RC BGS 10",
    value: "$1,200+",
    credits: "1,000 credits",
    color: "from-yellow-400 to-amber-600",
    glow: "shadow-yellow-500/60",
    border: "border-yellow-500",
    badge: "bg-yellow-500 text-black",
    icon: "💎",
    pulse: true,
  },
  {
    tier: "MINI JACKPOT",
    name: "Cooper Flagg",
    detail: "2024 Topps Chrome RC BGS 10",
    value: "$500+",
    credits: "500 credits",
    color: "from-purple-500 to-purple-800",
    glow: "shadow-purple-500/50",
    border: "border-purple-500",
    badge: "bg-purple-500 text-white",
    icon: "🏆",
    pulse: true,
  },
  {
    tier: "FEATURED CARD",
    name: "Victor Wembanyama",
    detail: "2023 Panini Prizm RC BGS 9",
    value: "$250+",
    credits: "250 credits",
    color: "from-blue-500 to-blue-800",
    glow: "shadow-blue-500/40",
    border: "border-blue-500",
    badge: "bg-blue-500 text-white",
    icon: "⭐",
    pulse: false,
  },
  {
    tier: "DAILY PRIZE",
    name: "Luka Doncic",
    detail: "2018 Panini Prizm RC BGS 9",
    value: "$75+",
    credits: "Free Freeroll",
    color: "from-green-500 to-green-800",
    glow: "shadow-green-500/30",
    border: "border-green-500",
    badge: "bg-green-500 text-white",
    icon: "🎁",
    pulse: false,
  },
];

// ─── Games ───────────────────────────────────────────────────────────────────
const GAMES = [
  {
    id: "blackjack",
    title: "BLACKJACK 21",
    desc: "Dealer stands on 17. Natural pays 3:2. Double down and split.",
    screenEmoji: "🃏",
    cost: "1–10 credits",
    free: false,
    hot: true,
    cabinetColor: "linear-gradient(160deg, #1a1a2e 0%, #0d0d1a 100%)",
    marqueeColor: "#a78bfa",
    glowColor: "rgba(167,139,250,0.4)",
    screenBg: "from-purple-950 to-black",
    href: "/game-room/blackjack",
  },
  {
    id: "roulette",
    title: "ROULETTE",
    desc: "Double-zero wheel. Bet on numbers, colors, or ranges.",
    screenEmoji: "🎡",
    cost: "0.5–5 credits",
    free: false,
    hot: true,
    cabinetColor: "linear-gradient(160deg, #1a0a0a 0%, #0d0505 100%)",
    marqueeColor: "#f87171",
    glowColor: "rgba(248,113,113,0.4)",
    screenBg: "from-red-950 to-black",
    href: "/game-room/roulette",
  },
  {
    id: "poker",
    title: "TEXAS HOLD'EM",
    desc: "Multi-player poker. Blinds, raises, all-in. Win credits and card prizes.",
    screenEmoji: "♠️",
    cost: "25–1,000 credits",
    free: false,
    hot: true,
    cabinetColor: "linear-gradient(160deg, #0a1a0a 0%, #050d05 100%)",
    marqueeColor: "#4ade80",
    glowColor: "rgba(74,222,128,0.4)",
    screenBg: "from-green-950 to-black",
    href: "/game-room/poker",
  },
  {
    id: "house-poker",
    title: "HOUSE POKER",
    desc: "Head-to-head vs the SCO dealer. Best 5-card hand wins.",
    screenEmoji: "🏠",
    cost: "10–500 credits",
    free: false,
    hot: false,
    cabinetColor: "linear-gradient(160deg, #0a0a1a 0%, #05050d 100%)",
    marqueeColor: "#60a5fa",
    glowColor: "rgba(96,165,250,0.4)",
    screenBg: "from-blue-950 to-black",
    href: "/game-room/poker",
    comingSoon: true,
  },
  {
    id: "tournaments",
    title: "TOURNAMENTS",
    desc: "Buy in $1–$20. AI opponents always ready. Final table in 20 min.",
    screenEmoji: "🏆",
    cost: "1–20 credits",
    free: false,
    hot: true,
    cabinetColor: "linear-gradient(160deg, #1a1200 0%, #0d0900 100%)",
    marqueeColor: "#fbbf24",
    glowColor: "rgba(251,191,36,0.4)",
    screenBg: "from-yellow-950 to-black",
    href: "/game-room/tournaments",
  },
];

// ─── Daily Free Cards Component ─────────────────────────────────────────────
function DailyFreeCards() {
  const { isAuthenticated } = useAuth();
  const { data: status, refetch: refetchStatus } = trpc.game.getFreeCardStatus.useQuery(
    undefined,
    { enabled: isAuthenticated, refetchInterval: 30000 }
  );
  const claimFreeCard = trpc.game.claimFreeCard.useMutation();
  const [winCard, setWinCard] = useState<any>(null);
  const [claiming, setClaiming] = useState(false);
  const [countdown, setCountdown] = useState<string>("");

  // Live countdown timer
  useEffect(() => {
    if (!status?.nextPlayAt) { setCountdown(""); return; }
    const update = () => {
      const now = Date.now();
      const target = new Date(status.nextPlayAt!).getTime();
      const diff = target - now;
      if (diff <= 0) { setCountdown(""); refetchStatus(); return; }
      const mins = Math.floor(diff / 60000);
      const secs = Math.floor((diff % 60000) / 1000);
      setCountdown(`${mins}:${secs.toString().padStart(2, "0")}`);
    };
    update();
    const t = setInterval(update, 1000);
    return () => clearInterval(t);
  }, [status?.nextPlayAt]);

  const handleClaim = async () => {
    if (!isAuthenticated) { window.location.href = getLoginUrl("/game-room"); return; }
    setClaiming(true);
    try {
      const res = await claimFreeCard.mutateAsync();
      setWinCard(res.card);
      toast.success(`🎁 You won: ${res.card.playerName} ${res.card.year || ""}!`);
      refetchStatus();
    } catch (err: any) {
      toast.error(err.message || "Could not claim free card.");
    } finally {
      setClaiming(false);
    }
  };

  const playsLeft = status ? status.maxPerDay - status.playsToday : 2;
  const canPlay = status?.canPlay ?? false;

  return (
    <div className="mb-10">
      <div className="flex items-center gap-2 mb-4">
        <Gift className="w-5 h-5 text-green-400" />
        <h2 className="text-2xl font-black text-white" style={{ fontFamily: "Oswald, sans-serif" }}>
          DAILY FREE CARDS
        </h2>
        <div className="flex-1 h-px bg-white/10" />
        <span className="text-white/30 text-xs">2 free cards per day · $1–$10 value</span>
      </div>

      <div className="bg-gradient-to-r from-green-900/40 to-emerald-900/30 border border-green-500/30 rounded-2xl p-6">
        <div className="flex flex-col md:flex-row items-center gap-6">
          {/* Left: Card preview or placeholder */}
          <div className="relative shrink-0">
            <div className="w-28 h-40 rounded-xl border-2 border-green-500/50 bg-gradient-to-b from-green-800/40 to-black/60 flex items-center justify-center shadow-[0_0_20px_rgba(34,197,94,0.3)]">
              {winCard?.frontImageUrl ? (
                <img src={winCard.frontImageUrl} alt={winCard.playerName} className="w-full h-full object-contain rounded-xl" />
              ) : (
                <div className="text-center">
                  <div className="text-4xl mb-1">🎁</div>
                  <div className="text-green-400 text-[10px] font-bold">FREE CARD</div>
                </div>
              )}
            </div>
            {/* Plays remaining dots */}
            <div className="flex gap-1.5 justify-center mt-2">
              {[0, 1].map(i => (
                <div key={i} className={`w-2.5 h-2.5 rounded-full border-2 ${
                  i < playsLeft ? "bg-green-400 border-green-400" : "bg-transparent border-white/20"
                }`} />
              ))}
            </div>
            <div className="text-center text-white/40 text-[10px] mt-1">{playsLeft}/2 left today</div>
          </div>

          {/* Right: Info + CTA */}
          <div className="flex-1 text-center md:text-left">
            {winCard ? (
              <>
                <div className="text-green-400 font-black text-xl mb-1">You won!</div>
                <div className="text-white font-bold text-lg">{winCard.playerName}</div>
                <div className="text-white/50 text-sm">{winCard.year} · ${parseFloat(winCard.price || "0").toFixed(2)} value</div>
                <div className="text-white/30 text-xs mt-1">Added to your collection</div>
                {playsLeft > 0 && canPlay && (
                  <Button
                    className="mt-4 bg-green-600 hover:bg-green-500 text-white font-black gap-2"
                    onClick={handleClaim}
                    disabled={claiming}
                  >
                    <Gift className="w-4 h-4" /> Claim Another Free Card
                  </Button>
                )}
              </>
            ) : (
              <>
                <div className="text-white font-black text-xl mb-1">Get a Free Card Every Day!</div>
                <div className="text-white/60 text-sm mb-3">
                  Claim up to 2 free sports cards daily from our house inventory.
                  Cards are valued $1–$10 and go straight to your collection.
                </div>
                <div className="flex flex-wrap gap-2 mb-4">
                  <div className="flex items-center gap-1.5 bg-black/30 rounded-full px-3 py-1">
                    <CheckCircle className="w-3.5 h-3.5 text-green-400" />
                    <span className="text-white/70 text-xs">No credits needed</span>
                  </div>
                  <div className="flex items-center gap-1.5 bg-black/30 rounded-full px-3 py-1">
                    <CheckCircle className="w-3.5 h-3.5 text-green-400" />
                    <span className="text-white/70 text-xs">Real cards, real value</span>
                  </div>
                  <div className="flex items-center gap-1.5 bg-black/30 rounded-full px-3 py-1">
                    <Clock className="w-3.5 h-3.5 text-yellow-400" />
                    <span className="text-white/70 text-xs">30-min cooldown</span>
                  </div>
                </div>

                {!isAuthenticated ? (
                  <Button asChild className="bg-green-600 hover:bg-green-500 text-white font-black gap-2">
                    <a href={getLoginUrl("/game-room")}><Gift className="w-4 h-4" /> Sign In to Claim Free Card</a>
                  </Button>
                ) : playsLeft === 0 ? (
                  <div className="inline-flex items-center gap-2 bg-white/5 border border-white/10 rounded-xl px-4 py-2">
                    <CheckCircle className="w-4 h-4 text-green-400" />
                    <span className="text-white/60 text-sm">Both free cards claimed today. Come back tomorrow!</span>
                  </div>
                ) : !canPlay && countdown ? (
                  <div className="inline-flex items-center gap-2 bg-yellow-500/10 border border-yellow-500/30 rounded-xl px-4 py-2">
                    <Clock className="w-4 h-4 text-yellow-400" />
                    <span className="text-yellow-300 text-sm font-bold">Next card in {countdown}</span>
                  </div>
                ) : (
                  <Button
                    className="bg-green-600 hover:bg-green-500 text-white font-black gap-2 shadow-[0_0_20px_rgba(34,197,94,0.4)]"
                    onClick={handleClaim}
                    disabled={claiming || !canPlay}
                  >
                    {claiming ? (
                      <><Sparkles className="w-4 h-4 animate-spin" /> Claiming...</>
                    ) : (
                      <><Gift className="w-4 h-4" /> Claim Free Card</>  
                    )}
                  </Button>
                )}
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── Pack Rip Mini Game ───────────────────────────────────────────────────────
type PackType = "standard" | "premium" | "elite";

function PackRipGame() {
  const { isAuthenticated } = useAuth();
  const { data: account, refetch: refetchAccount } = trpc.credits.myAccount.useQuery(undefined, { enabled: isAuthenticated });
  const playPackRip = trpc.game.playPackRip.useMutation();

  const [packType, setPackType] = useState<PackType>("standard");
  const [lastPackType, setLastPackType] = useState<PackType>("standard");
  const [result, setResult] = useState<any>(null);
  const [animating, setAnimating] = useState(false);
  const [revealed, setRevealed] = useState(false);
  const [winModalOpen, setWinModalOpen] = useState(false);
  const [winPrize, setWinPrize] = useState<CardPrize | null>(null);

  const PACK_COSTS: Record<PackType, number> = { standard: 5, premium: 15, elite: 30 };
  const PACK_LABELS: Record<PackType, string> = { standard: "Standard Pack", premium: "Premium Pack", elite: "Elite Pack" };
  const PACK_COLORS: Record<PackType, string> = {
    standard: "from-blue-600 to-blue-800 border-blue-500",
    premium: "from-purple-600 to-purple-800 border-purple-500",
    elite: "from-yellow-500 to-amber-700 border-yellow-400",
  };

  const handleRip = async () => {
    if (!isAuthenticated) { window.location.href = getLoginUrl("/game-room"); return; }
    if (animating) return;
    setAnimating(true);
    setRevealed(false);
    setResult(null);
    try {
      const res = await playPackRip.mutateAsync({ packType });
      setLastPackType(packType);
      setTimeout(() => {
        setResult(res);
        setAnimating(false);
        setTimeout(() => setRevealed(true), 300);
        refetchAccount();
        // If a real card was won, open the CardWinModal
        if (res.prizeCard && (res.outcome === "jackpot" || res.outcome === "mini_jackpot" || res.outcome === "card_prize")) {
          setTimeout(() => {
            setWinPrize({
              id: res.prizeCard!.id,
              playerName: res.prizeCard!.playerName,
              year: res.prizeCard!.year,
              setName: res.prizeCard!.setName,
              gradeScore: res.prizeCard!.gradeScore ?? null,
              gradeCompany: res.prizeCard!.gradeCompany ?? null,
              frontImageUrl: res.prizeCard!.frontImageUrl ?? null,
              price: res.prizeCard!.price,
            });
            setWinModalOpen(true);
          }, 800);
        } else if (res.creditsWon > 0) {
          toast.success(`${res.emoji} ${res.label} — +${res.creditsWon} credits!`);
        }
      }, 1800);
    } catch (err: any) {
      toast.error(err.message || "Failed to rip pack.");
      setAnimating(false);
    }
  };

  return (
    <div className="bg-black/60 border border-white/10 rounded-2xl p-6">
      <div className="flex items-center gap-2 mb-4">
        <span className="text-2xl">📦</span>
        <h3 className="text-white font-black text-lg" style={{ fontFamily: "Oswald, sans-serif" }}>PACK RIP SIMULATOR</h3>
        <Badge className="bg-orange-500 text-white text-[10px]">HOT</Badge>
      </div>

      {/* Pack type selector */}
      <div className="grid grid-cols-3 gap-2 mb-4">
        {(["standard", "premium", "elite"] as PackType[]).map((type) => (
          <button
            key={type}
            onClick={() => setPackType(type)}
            className={`rounded-xl border-2 p-3 text-center transition-all ${
              packType === type
                ? `bg-gradient-to-b ${PACK_COLORS[type]} text-white shadow-lg scale-105`
                : "border-white/10 bg-white/5 text-white/50 hover:border-white/30"
            }`}
          >
            <div className="font-black text-sm capitalize">{type}</div>
            <div className="text-xs opacity-70">{PACK_COSTS[type]} credits</div>
          </button>
        ))}
      </div>

      {/* Pack visual */}
      <div className="flex justify-center mb-4">
        <div
          className={`relative w-32 h-44 rounded-xl border-2 bg-gradient-to-b ${PACK_COLORS[packType]} flex items-center justify-center cursor-pointer transition-all duration-300 ${
            animating ? "animate-bounce" : "hover:scale-105"
          } ${revealed && result ? "opacity-0 scale-90" : "opacity-100"}`}
          onClick={handleRip}
        >
          <div className="text-center">
            <div className="text-4xl mb-2">📦</div>
            <div className="text-white font-black text-xs uppercase tracking-wide">{PACK_LABELS[packType]}</div>
            <div className="text-white/60 text-[10px] mt-1">{PACK_COSTS[packType]} credits</div>
          </div>
          {animating && (
            <div className="absolute inset-0 rounded-xl bg-white/20 animate-pulse" />
          )}
        </div>
      </div>

      {/* Result reveal */}
      {result && revealed && (
        <div className={`text-center p-4 rounded-xl border transition-all duration-500 ${
          result.outcome === "jackpot" ? "border-yellow-500 bg-yellow-500/10 shadow-[0_0_30px_rgba(234,179,8,0.4)]" :
          result.outcome === "mini_jackpot" ? "border-purple-500 bg-purple-500/10" :
          result.outcome === "card_prize" ? "border-blue-500 bg-blue-500/10" :
          result.creditsWon > 0 ? "border-green-500/40 bg-green-500/5" :
          "border-white/10 bg-white/5"
        }`}>
          <div className="text-3xl mb-1">{result.emoji}</div>
          <div className="text-white font-black text-lg">{result.label}</div>
          <div className="text-white/60 text-sm mt-1">
            {result.card.name} — {result.card.year} {result.card.set}
            {result.card.grade && <span className="ml-1 text-yellow-400">BGS {result.card.grade}</span>}
          </div>
          {result.creditsWon > 0 && (
            <div className="text-green-400 font-bold mt-2">+{result.creditsWon} credits added!</div>
          )}
          <div className="text-white/40 text-xs mt-2">Balance: {result.newBalance} credits</div>
        </div>
      )}

      {/* Rip button */}
      <div className="flex gap-2 mt-4">
        {result && revealed && !animating && (
          <Button
            className="flex-1 bg-blue-600 hover:bg-blue-500 text-white font-black text-sm h-12"
            onClick={() => { setPackType(lastPackType); handleRip(); }}
            disabled={animating || (account?.credits ?? 0) < PACK_COSTS[lastPackType]}
          >
            🔁 Repeat ({PACK_COSTS[lastPackType]}cr)
          </Button>
        )}
        <Button
          className="flex-1 bg-orange-600 hover:bg-orange-500 text-white font-black text-base h-12"
          onClick={handleRip}
          disabled={animating}
        >
          {animating ? (
            <span className="flex items-center gap-2"><Sparkles className="w-4 h-4 animate-spin" /> Ripping Pack...</span>
          ) : (
            <span className="flex items-center gap-2">📦 Rip Pack — {PACK_COSTS[packType]} Credits</span>
          )}
        </Button>
      </div>

      {isAuthenticated && account && (
        <p className="text-center text-white/30 text-xs mt-2">Balance: {account.credits} credits</p>
      )}

      {/* Card Win Modal — shown when a real house card is won */}
      <CardWinModal
        open={winModalOpen}
        prize={winPrize}
        outcomeLabel={result?.label}
        outcomeType={result?.outcome}
        onClose={() => { setWinModalOpen(false); setWinPrize(null); }}
        onClaimed={(credits, msg) => {
          refetchAccount();
          if (credits > 0) toast.success(`+${credits} credits added!`);
          else toast.success(msg);
        }}
      />
    </div>
  );
}

// ─── Main Game Room Page ──────────────────────────────────────────────────────
export default function GameRoom() {
  const { isAuthenticated } = useAuth();
  const { data: prizeVault } = trpc.game.getPrizeVault.useQuery();
  const { data: account } = trpc.credits.myAccount.useQuery(undefined, { enabled: isAuthenticated });

  const [activeShowcase, setActiveShowcase] = useState(0);
  const [depositOpen, setDepositOpen] = useState(false);

  // Auto-rotate showcase
  useEffect(() => {
    const timer = setInterval(() => setActiveShowcase(i => (i + 1) % SHOWCASE_PRIZES.length), 3500);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="min-h-screen bg-[#050a0f] flex flex-col">
      <NavBar />

      {/* ── Hero Banner ──────────────────────────────────────────────────── */}
      <div className="relative w-full overflow-hidden" style={{ minHeight: "340px" }}>
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{ backgroundImage: `url(${GAME_ROOM_BG})` }}
        />
        <div className="absolute inset-0 bg-gradient-to-b from-black/70 via-black/50 to-[#050a0f]" />

        <div className="relative z-10 flex flex-col items-center justify-center text-center px-4 pt-16 pb-8">
          {/* FREE PLAY banner */}
          <div className="inline-flex items-center gap-3 bg-red-600/90 border-2 border-red-400 rounded-2xl px-6 py-3 mb-5 shadow-[0_0_30px_rgba(239,68,68,0.6)] animate-pulse">
            <span className="text-white text-xl">🎰</span>
            <div className="text-center">
              <div className="text-white font-black text-xl uppercase tracking-widest" style={{ fontFamily: "Oswald, sans-serif" }}>FREE PLAY 4 NOW</div>
              <div className="text-red-200 text-xs font-bold tracking-wide">⚠️ NO PRIZES — Credits not deducted during free play mode</div>
            </div>
            <span className="text-white text-xl">🎰</span>
          </div>
          <h1 className="text-5xl md:text-7xl font-black text-white mb-3 drop-shadow-lg" style={{ fontFamily: "Oswald, sans-serif" }}>
            SCO <span className="text-yellow-400">GAME ROOM</span>
          </h1>
          <p className="text-white/70 text-lg max-w-xl mb-6">
            Play poker, rip packs, spin the wheel — real prizes coming soon!
            All games are in free play mode while we get things set up.
          </p>
          <div className="flex flex-wrap gap-3 justify-center">
            {isAuthenticated ? (
              <>
                <div className="flex items-center gap-2 bg-black/50 border border-yellow-500/30 rounded-full px-4 py-2">
                  <Coins className="w-4 h-4 text-yellow-400" />
                  <span className="text-yellow-400 font-black">{account?.credits ?? 0}</span>
                  <span className="text-white/50 text-sm">credits</span>
                </div>
                {(account as any)?.loyaltyStatus?.tier && (account as any).loyaltyStatus.tier !== 'bronze' && (
                  <Link href="/loyalty">
                    <div className="flex items-center gap-1.5 bg-black/50 border border-white/20 rounded-full px-3 py-2 cursor-pointer hover:border-yellow-500/50 transition-colors">
                      <span className="text-base">
                        {(account as any).loyaltyStatus.tier === 'silver' ? '🥈' :
                         (account as any).loyaltyStatus.tier === 'gold' ? '🥇' :
                         (account as any).loyaltyStatus.tier === 'platinum' ? '💎' : '💠'}
                      </span>
                      <span className="text-xs font-bold capitalize text-white/80">{(account as any).loyaltyStatus.tier}</span>
                    </div>
                  </Link>
                )}
                <Button
                  className="bg-yellow-500 hover:bg-yellow-400 text-black font-black gap-2"
                  onClick={() => setDepositOpen(true)}
                >
                  <Zap className="w-4 h-4" /> Quick Deposit
                </Button>
              </>
            ) : (
              <>
                <Button asChild className="bg-yellow-500 hover:bg-yellow-400 text-black font-black gap-2">
                  <a href={getLoginUrl("/game-room")}><Sparkles className="w-4 h-4" /> Sign In to Play</a>
                </Button>
                <Button asChild variant="outline" className="border-white/20 text-white hover:bg-white/10 gap-2">
                  <Link href="/credits?from=/game-room"><Coins className="w-4 h-4" /> Buy Credits</Link>
                </Button>
              </>
            )}
          </div>
        </div>
      </div>

      <div className="flex-1 px-4 pb-16 max-w-6xl mx-auto w-full">

        {/* ── Prize Showcase ──────────────────────────────────────────────── */}
        <div className="mb-12">
          <div className="flex items-center gap-2 mb-4">
            <Trophy className="w-5 h-5 text-yellow-400" />
            <h2 className="text-2xl font-black text-white" style={{ fontFamily: "Oswald, sans-serif" }}>
              PRIZE SHOWCASE
            </h2>
            <div className="flex-1 h-px bg-white/10" />
            <span className="text-white/30 text-xs">Win these real cards</span>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {SHOWCASE_PRIZES.map((prize, i) => (
              <div
                key={prize.tier}
                className={`relative rounded-2xl border-2 overflow-hidden transition-all duration-500 cursor-pointer
                  ${i === activeShowcase ? `${prize.border} shadow-xl ${prize.glow}` : "border-white/10"}
                  ${prize.pulse && i === activeShowcase ? "scale-105" : "scale-100"}`}
                onClick={() => setActiveShowcase(i)}
              >
                {/* Gradient background */}
                <div className={`absolute inset-0 bg-gradient-to-b ${prize.color} opacity-20`} />

                <div className="relative p-4 text-center">
                  {/* Tier badge */}
                  <div className={`inline-flex items-center gap-1 ${prize.badge} text-[9px] font-black px-2 py-0.5 rounded-full uppercase tracking-widest mb-2`}>
                    {prize.tier === "MEGA JACKPOT" && <Crown className="w-2.5 h-2.5" />}
                    {prize.tier}
                  </div>

                  {/* Card placeholder */}
                  <div className={`w-16 h-22 mx-auto mb-3 rounded-lg border-2 ${prize.border} bg-gradient-to-b ${prize.color} opacity-80 flex items-center justify-center`}
                    style={{ height: "88px" }}>
                    <span className="text-3xl">{prize.icon}</span>
                  </div>

                  <p className="text-white font-black text-sm leading-tight">{prize.name}</p>
                  <p className="text-white/50 text-[10px] mt-0.5">{prize.detail}</p>
                  <p className="text-yellow-400 font-black text-base mt-2">{prize.value}</p>
                  <p className="text-white/30 text-[10px]">{prize.credits}</p>

                  {/* Pulsing live indicator */}
                  {prize.pulse && (
                    <div className="flex items-center justify-center gap-1 mt-2">
                      <div className="w-1.5 h-1.5 rounded-full bg-red-500 animate-pulse" />
                      <span className="text-red-400 text-[9px] font-bold uppercase">Live Prize</span>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* ── Daily Free Cards ─────────────────────────────────────────────── */}
        <DailyFreeCards />

        {/* ── Games Grid + Pack Rip ────────────────────────────────────────── */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">

          {/* Left: Arcade Cabinet Games */}
          <div className="lg:col-span-2">
            <div className="flex items-center gap-2 mb-5">
              <Dice6 className="w-5 h-5 text-yellow-400 animate-pulse" />
              <h2 className="text-2xl font-black text-white tracking-widest" style={{ fontFamily: "Oswald, sans-serif", textShadow: "0 0 20px rgba(250,204,21,0.5)" }}>ARCADE GAMES</h2>
              <div className="flex-1 h-px bg-gradient-to-r from-yellow-500/40 to-transparent" />
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
              {GAMES.map((game) => (
                <div
                  key={game.id}
                  className={`relative group transition-all duration-300 ${game.comingSoon ? "opacity-50" : "hover:-translate-y-1 cursor-pointer"}`}
                >
                  <div
                    className="relative rounded-xl overflow-hidden"
                    style={{
                      background: game.cabinetColor,
                      boxShadow: game.comingSoon ? "none" : `0 0 18px ${game.glowColor}, 0 4px 24px rgba(0,0,0,0.8)`,
                      border: `2px solid ${game.marqueeColor}44`,
                    }}
                  >
                    {/* Marquee light bar top */}
                    <div
                      className="h-2 w-full"
                      style={{
                        background: `linear-gradient(90deg, transparent, ${game.marqueeColor}, transparent)`,
                        animation: game.comingSoon ? "none" : "marqueeFlash 1.8s ease-in-out infinite",
                      }}
                    />
                    {/* CRT Screen */}
                    <div
                      className={`relative mx-2 mt-1 mb-0 rounded-lg overflow-hidden bg-gradient-to-b ${game.screenBg}`}
                      style={{ aspectRatio: "4/3", boxShadow: `inset 0 0 20px rgba(0,0,0,0.8)` }}
                    >
                      <div className="absolute inset-0 pointer-events-none" style={{
                        backgroundImage: "repeating-linear-gradient(0deg, transparent, transparent 2px, rgba(0,0,0,0.15) 2px, rgba(0,0,0,0.15) 4px)",
                        zIndex: 2,
                      }} />
                      <div className="absolute inset-0 flex flex-col items-center justify-center gap-1 z-10">
                        <span className="text-4xl drop-shadow-lg" style={{ filter: `drop-shadow(0 0 8px ${game.marqueeColor})` }}>{game.screenEmoji}</span>
                        <span
                          className="text-[9px] font-black tracking-widest px-2 text-center leading-tight"
                          style={{ color: game.marqueeColor, textShadow: `0 0 8px ${game.marqueeColor}`, fontFamily: "'Courier New', monospace" }}
                        >{game.title}</span>
                        {game.hot && !game.comingSoon && (
                          <span className="text-[7px] font-black bg-red-500 text-white px-1.5 py-0.5 rounded-full animate-pulse tracking-widest">HOT</span>
                        )}
                        {game.comingSoon && (
                          <span className="text-[7px] font-black bg-white/10 text-white/60 px-1.5 py-0.5 rounded-full tracking-widest">COMING SOON</span>
                        )}
                      </div>
                      <div className="absolute top-1 left-1 w-1/3 h-1/4 rounded-full bg-white/5 blur-sm pointer-events-none" />
                    </div>
                    {/* Cabinet body */}
                    <div className="px-2 pt-2 pb-3 text-center">
                      <p className="text-[8px] font-bold mb-1.5" style={{ color: game.free ? "#4ade80" : "#fbbf24", fontFamily: "'Courier New', monospace" }}>
                        {game.cost}
                      </p>
                      {!game.comingSoon ? (
                        <Link href={game.href}>
                          <button
                            className="w-full rounded-lg text-[9px] font-black tracking-widest py-1.5 transition-all duration-150 active:scale-95"
                            style={{
                              background: `linear-gradient(135deg, ${game.marqueeColor}cc, ${game.marqueeColor}88)`,
                              color: "#000",
                              boxShadow: `0 2px 8px ${game.glowColor}`,
                              border: `1px solid ${game.marqueeColor}`,
                              fontFamily: "'Courier New', monospace",
                            }}
                          >
                            INSERT COIN
                          </button>
                        </Link>
                      ) : (
                        <div
                          className="w-full rounded-lg text-[9px] font-black tracking-widest py-1.5 text-center"
                          style={{ background: "rgba(255,255,255,0.05)", color: "rgba(255,255,255,0.3)", fontFamily: "'Courier New', monospace" }}
                        >
                          LOCKED
                        </div>
                      )}
                    </div>
                    {/* Marquee light bar bottom */}
                    <div
                      className="h-1.5 w-full"
                      style={{
                        background: `linear-gradient(90deg, transparent, ${game.marqueeColor}88, transparent)`,
                        animation: game.comingSoon ? "none" : "marqueeFlash 1.8s ease-in-out infinite 0.9s",
                      }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>
          {/* Right: Pack Rip game */}
          <div className="lg:col-span-1">
            <div className="flex items-center gap-2 mb-4">
              <Flame className="w-5 h-5 text-orange-400" />
              <h2 className="text-2xl font-black text-white" style={{ fontFamily: "Oswald, sans-serif" }}>QUICK PLAY</h2>
            </div>
            <PackRipGame />

            {/* Credits CTA */}
            <div className="mt-4 bg-gradient-to-br from-yellow-950/40 to-black/60 border border-yellow-500/30 rounded-2xl p-4 text-center">
              <Coins className="w-8 h-8 text-yellow-400 mx-auto mb-2" />
              <p className="text-white font-bold text-sm mb-1">Need more credits?</p>
              <p className="text-white/40 text-xs mb-3">$1.00 = 1 credit. Bulk bonuses available.</p>
              <Button asChild className="w-full bg-yellow-500 hover:bg-yellow-400 text-black font-black text-sm h-9">
                <Link href="/credits?from=/game-room">Visit the Credit Window →</Link>
              </Button>
            </div>
          </div>
        </div>

        {/* ── How It Works ─────────────────────────────────────────────────── */}
        <div className="mt-12 bg-white/5 border border-white/10 rounded-2xl p-6">
          <h2 className="text-xl font-black text-white mb-4 text-center" style={{ fontFamily: "Oswald, sans-serif" }}>
            HOW THE GAME ROOM WORKS
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            {[
              { step: "1", icon: "🆓", title: "Sign Up Free", desc: "Create your free account and get 25 starter credits" },
              { step: "2", icon: "🎰", title: "Play Games", desc: "Use credits to play pack rips, spin the wheel, or poker" },
              { step: "3", icon: "🏆", title: "Win Prizes", desc: "Land jackpots to win real physical sports cards" },
              { step: "4", icon: "📦", title: "Claim Your Card", desc: "Winners receive their card shipped directly to them" },
            ].map((item) => (
              <div key={item.step} className="text-center">
                <div className="w-10 h-10 rounded-full bg-yellow-500/20 border border-yellow-500/40 flex items-center justify-center mx-auto mb-2">
                  <span className="text-yellow-400 font-black text-sm">{item.step}</span>
                </div>
                <div className="text-2xl mb-1">{item.icon}</div>
                <p className="text-white font-bold text-sm">{item.title}</p>
                <p className="text-white/40 text-xs mt-1">{item.desc}</p>
              </div>
            ))}
          </div>
          <p className="text-center text-white/20 text-xs mt-4">
            Credits are virtual currency with no cash value. Prizes are physical sports cards. No gambling license required.
          </p>
        </div>
      </div>

      {/* Game Times Today Ticker — Game Room only */}
      <div className="sticky bottom-0 left-0 right-0 z-[110] pb-[0px]">
        <GameTimesTicker />
      </div>

      <Footer />

      {/* Quick Deposit Modal */}
      <QuickDepositModal
        open={depositOpen}
        onClose={() => setDepositOpen(false)}
        currentCredits={account?.credits ?? 0}
        returnPath="/game-room"
      />
    </div>
  );
}
