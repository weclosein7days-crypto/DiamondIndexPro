import { trpc } from "@/lib/trpc";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Link, useLocation } from "wouter";
import CardPopup from "@/components/CardPopup";
import { useAuth } from "@/_core/hooks/useAuth";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { toast } from "sonner";
import {
  Clock, Award, Gavel, TrendingUp, Plus, SlidersHorizontal,
  ChevronDown, X, ArrowUpDown, Flame, Star, Zap, Circle,
  Trash2, CheckSquare, Square
} from "lucide-react";
import { SlabFrame } from "@/components/SlabFrame";
import { FavoriteButton } from "@/components/FavoriteButton";
import { useEffect, useState, useMemo, useCallback } from "react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuLabel,
  DropdownMenuRadioGroup,
  DropdownMenuRadioItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

// ── Types ──────────────────────────────────────────────────────────────────
type SortKey =
  | "endTime_asc"
  | "endTime_desc"
  | "bid_high"
  | "bid_low"
  | "rarity_high"
  | "rarity_low";

type FilterKey = "all" | "ending_soon" | "has_bids" | "no_bids" | "buy_now";

// ── Rarity helpers ─────────────────────────────────────────────────────────
function getRarityTier(startingPrice: number): {
  label: string;
  color: string;
  bg: string;
  border: string;
  icon: React.ReactNode;
  rank: number;
} {
  if (startingPrice >= 500)
    return {
      label: "Legendary",
      color: "text-yellow-300",
      bg: "bg-yellow-500/20",
      border: "border-yellow-500/50",
      icon: <Flame className="w-2.5 h-2.5" />,
      rank: 4,
    };
  if (startingPrice >= 100)
    return {
      label: "Rare",
      color: "text-purple-300",
      bg: "bg-purple-500/20",
      border: "border-purple-500/50",
      icon: <Star className="w-2.5 h-2.5" />,
      rank: 3,
    };
  if (startingPrice >= 50)
    return {
      label: "Uncommon",
      color: "text-blue-300",
      bg: "bg-blue-500/20",
      border: "border-blue-500/50",
      icon: <Zap className="w-2.5 h-2.5" />,
      rank: 2,
    };
  return {
    label: "Common",
    color: "text-slate-400",
    bg: "bg-slate-500/10",
    border: "border-slate-500/30",
    icon: <Circle className="w-2.5 h-2.5" />,
    rank: 1,
  };
}

// ── Countdown ──────────────────────────────────────────────────────────────
function TimeLeft({ endTime }: { endTime: Date }) {
  const [timeLeft, setTimeLeft] = useState("");
  const [urgent, setUrgent] = useState(false);
  useEffect(() => {
    const update = () => {
      const diff = new Date(endTime).getTime() - Date.now();
      if (diff <= 0) { setTimeLeft("Ended"); setUrgent(false); return; }
      const d = Math.floor(diff / 86400000);
      const h = Math.floor((diff % 86400000) / 3600000);
      const m = Math.floor((diff % 3600000) / 60000);
      const s = Math.floor((diff % 60000) / 1000);
      setUrgent(diff < 3600000); // < 1 hour = urgent
      setTimeLeft(d > 0 ? `${d}d ${h}h` : `${h}h ${m}m ${s}s`);
    };
    update();
    const i = setInterval(update, 1000);
    return () => clearInterval(i);
  }, [endTime]);
  return (
    <span className={`font-mono ${urgent ? "text-red-400 animate-pulse" : ""}`}>
      {timeLeft}
    </span>
  );
}

// ── Sort label map ─────────────────────────────────────────────────────────
const SORT_LABELS: Record<SortKey, string> = {
  endTime_asc: "Ending Soonest",
  endTime_desc: "Ending Latest",
  bid_high: "Highest Bid",
  bid_low: "Lowest Bid",
  rarity_high: "Rarity: High → Low",
  rarity_low: "Rarity: Low → High",
};

const FILTER_LABELS: Record<FilterKey, string> = {
  all: "All Auctions",
  ending_soon: "Ending Soon (<24h)",
  has_bids: "Has Bids",
  no_bids: "No Bids Yet",
  buy_now: "Buy Now Available",
};

const PAGE_SIZE = 40;

// ── Main Component ─────────────────────────────────────────────────────────
export default function Auctions() {
  const [location, setLocation] = useLocation();
  const { user } = useAuth();
  const isAdmin = (user as any)?.role === "admin";

  // Admin bulk-select state
  const [selectedIds, setSelectedIds] = useState<Set<number>>(new Set());
  const [showBulkDeleteConfirm, setShowBulkDeleteConfirm] = useState(false);
  const utils = trpc.useUtils();
  const bulkDelete = trpc.auctions.adminBulkDelete.useMutation({
    onSuccess: (data) => {
      toast.success(`Deleted ${data.deleted} auction${data.deleted !== 1 ? 's' : ''}`);
      setSelectedIds(new Set());
      utils.auctions.list.invalidate();
    },
    onError: (e: any) => toast.error(e.message || "Bulk delete failed"),
  });

  const toggleSelect = (id: number, e: React.MouseEvent) => {
    e.stopPropagation();
    setSelectedIds(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  };

  // Parse URL params for persistent state
  const urlParams = useMemo(() => new URLSearchParams(location.includes("?") ? location.split("?")[1] : ""), [location]);
  const [sort, setSort] = useState<SortKey>((urlParams.get("sort") as SortKey) || "endTime_asc");
  const [filter, setFilter] = useState<FilterKey>((urlParams.get("filter") as FilterKey) || "all");
  const [rarityFilter, setRarityFilter] = useState<string>(urlParams.get("rarity") || "all");
  const [currentPage, setCurrentPage] = useState(1);

  const { data: auctions, isLoading } = trpc.auctions.list.useQuery();
  const [selectedAuction, setSelectedAuction] = useState<typeof enriched[0] | null>(null);

  // Sync URL params when sort/filter changes
  const updateUrl = useCallback((newSort: SortKey, newFilter: FilterKey, newRarity: string) => {
    const params = new URLSearchParams();
    if (newSort !== "endTime_asc") params.set("sort", newSort);
    if (newFilter !== "all") params.set("filter", newFilter);
    if (newRarity !== "all") params.set("rarity", newRarity);
    const qs = params.toString();
    setLocation(qs ? `/auctions?${qs}` : "/auctions", { replace: true });
  }, [setLocation]);

  const handleSort = (val: SortKey) => { setSort(val); setCurrentPage(1); updateUrl(val, filter, rarityFilter); };
  const handleFilter = (val: FilterKey) => { setFilter(val); setCurrentPage(1); updateUrl(sort, val, rarityFilter); };
  const handleRarity = (val: string) => { setRarityFilter(val); setCurrentPage(1); updateUrl(sort, filter, val); };
  const clearAll = () => { setSort("endTime_asc"); setFilter("all"); setRarityFilter("all"); setCurrentPage(1); setLocation("/auctions", { replace: true }); };

  // Compute rarity-enriched auctions
  const enriched = useMemo(() => {
    if (!auctions) return [];
    return auctions.map((a) => ({
      ...a,
      _price: parseFloat(a.startingPrice || "0"),
      _bid: parseFloat(a.currentBid ?? "0"),
      _rarity: getRarityTier(parseFloat(a.startingPrice || "0")),
      _endsAt: new Date(a.endTime).getTime(),
    }));
  }, [auctions]);

  // Apply filters
  const filtered = useMemo(() => {
    let list = enriched;
    const now = Date.now();

    if (filter === "ending_soon") list = list.filter((a) => a._endsAt - now < 86400000 && a._endsAt > now);
    else if (filter === "has_bids") list = list.filter((a) => (a.bidCount ?? 0) > 0);
    else if (filter === "no_bids") list = list.filter((a) => (a.bidCount ?? 0) === 0);
    else if (filter === "buy_now") list = list.filter((a) => a.buyNowPrice && parseFloat(a.buyNowPrice) > 0);

    if (rarityFilter !== "all") list = list.filter((a) => a._rarity.label === rarityFilter);

    return list;
  }, [enriched, filter, rarityFilter]);

  // Apply sort
  const sorted = useMemo(() => {
    const list = [...filtered];
    switch (sort) {
      case "endTime_asc":  return list.sort((a, b) => a._endsAt - b._endsAt);
      case "endTime_desc": return list.sort((a, b) => b._endsAt - a._endsAt);
      case "bid_high":     return list.sort((a, b) => (b._bid || b._price) - (a._bid || a._price));
      case "bid_low":      return list.sort((a, b) => (a._bid || a._price) - (b._bid || b._price));
      case "rarity_high":  return list.sort((a, b) => b._rarity.rank - a._rarity.rank);
      case "rarity_low":   return list.sort((a, b) => a._rarity.rank - b._rarity.rank);
      default: return list;
    }
  }, [filtered, sort]);

  const totalPages = Math.ceil(sorted.length / PAGE_SIZE);
  const paginatedAuctions = sorted.slice((currentPage - 1) * PAGE_SIZE, currentPage * PAGE_SIZE);

  // Count active filters
  const activeFilterCount = [
    sort !== "endTime_asc",
    filter !== "all",
    rarityFilter !== "all",
  ].filter(Boolean).length;

  // Rarity distribution for filter pills
  const rarityDistribution = useMemo(() => {
    if (!enriched.length) return {};
    const counts: Record<string, number> = {};
    enriched.forEach((a) => {
      counts[a._rarity.label] = (counts[a._rarity.label] || 0) + 1;
    });
    return counts;
  }, [enriched]);

  return (
    <div className="min-h-screen py-6">
      <div className="container">

        {/* ── Header ── */}
        <div className="mb-5">
          <h1 className="text-3xl font-bold mb-1 flex items-center gap-3">
            <Gavel className="w-8 h-8 text-secondary" />
            Live Auctions
          </h1>
          <p className="text-muted-foreground text-sm">Bid on premium cards. Auctions last 5, 7, or 10 days.</p>
        </div>

        {/* ── Post Your Card CTA ── */}
        <div className="mb-5 rounded-xl border border-secondary/30 bg-gradient-to-r from-secondary/10 via-secondary/5 to-transparent p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-full bg-secondary/20 flex items-center justify-center shrink-0 mt-0.5">
              <TrendingUp className="w-5 h-5 text-secondary" />
            </div>
            <div>
              <h2 className="font-bold text-base text-foreground">Sell Your Cards at Auction</h2>
              <p className="text-muted-foreground text-sm">List cards from your collection and let bidders compete. Set your starting price and watch the bids roll in.</p>
            </div>
          </div>
          <Button asChild className="shrink-0 gap-2">
            <Link href="/my-collection">
              <Plus className="w-4 h-4" />
              Post Your Card
            </Link>
          </Button>
        </div>

        {/* ── Filter & Sort Toolbar ── */}
        <div className="mb-4 flex flex-wrap items-center gap-2">

          {/* Sort dropdown */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="sm" className="gap-1.5 h-8 text-xs border-border/60 bg-card hover:bg-muted">
                <ArrowUpDown className="w-3.5 h-3.5" />
                {SORT_LABELS[sort]}
                <ChevronDown className="w-3 h-3 opacity-60" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="start" className="w-52">
              <DropdownMenuLabel className="text-xs text-muted-foreground">Sort By</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuRadioGroup value={sort} onValueChange={(v) => handleSort(v as SortKey)}>
                <DropdownMenuRadioItem value="endTime_asc" className="text-xs">⏱ Ending Soonest</DropdownMenuRadioItem>
                <DropdownMenuRadioItem value="endTime_desc" className="text-xs">⏳ Ending Latest</DropdownMenuRadioItem>
                <DropdownMenuSeparator />
                <DropdownMenuRadioItem value="bid_high" className="text-xs">💰 Highest Bid First</DropdownMenuRadioItem>
                <DropdownMenuRadioItem value="bid_low" className="text-xs">💸 Lowest Bid First</DropdownMenuRadioItem>
                <DropdownMenuSeparator />
                <DropdownMenuRadioItem value="rarity_high" className="text-xs">🔥 Rarity: High → Low</DropdownMenuRadioItem>
                <DropdownMenuRadioItem value="rarity_low" className="text-xs">⭐ Rarity: Low → High</DropdownMenuRadioItem>
              </DropdownMenuRadioGroup>
            </DropdownMenuContent>
          </DropdownMenu>

          {/* Status filter dropdown */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="sm" className={`gap-1.5 h-8 text-xs border-border/60 bg-card hover:bg-muted ${filter !== "all" ? "border-secondary/60 text-secondary" : ""}`}>
                <SlidersHorizontal className="w-3.5 h-3.5" />
                {FILTER_LABELS[filter]}
                <ChevronDown className="w-3 h-3 opacity-60" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="start" className="w-52">
              <DropdownMenuLabel className="text-xs text-muted-foreground">Filter By Status</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuRadioGroup value={filter} onValueChange={(v) => handleFilter(v as FilterKey)}>
                <DropdownMenuRadioItem value="all" className="text-xs">🎯 All Auctions</DropdownMenuRadioItem>
                <DropdownMenuRadioItem value="ending_soon" className="text-xs">🔴 Ending Soon (&lt;24h)</DropdownMenuRadioItem>
                <DropdownMenuRadioItem value="has_bids" className="text-xs">🏆 Has Bids</DropdownMenuRadioItem>
                <DropdownMenuRadioItem value="no_bids" className="text-xs">🆕 No Bids Yet</DropdownMenuRadioItem>
                <DropdownMenuRadioItem value="buy_now" className="text-xs">⚡ Buy Now Available</DropdownMenuRadioItem>
              </DropdownMenuRadioGroup>
            </DropdownMenuContent>
          </DropdownMenu>

          {/* Rarity filter pills */}
          <div className="flex items-center gap-1.5 flex-wrap">
            {(["all", "Legendary", "Rare", "Uncommon", "Common"] as const).map((r) => {
              const isActive = rarityFilter === r;
              const count = r === "all" ? enriched.length : (rarityDistribution[r] || 0);
              const tier = r !== "all" ? getRarityTier(r === "Legendary" ? 999 : r === "Rare" ? 200 : r === "Uncommon" ? 75 : 10) : null;
              return (
                <button
                  key={r}
                  onClick={() => handleRarity(r)}
                  className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-semibold border transition-all ${
                    isActive
                      ? tier
                        ? `${tier.bg} ${tier.border} ${tier.color}`
                        : "bg-secondary/20 border-secondary/60 text-secondary"
                      : "bg-card border-border/40 text-muted-foreground hover:border-border hover:text-foreground"
                  }`}
                >
                  {tier && <span className={tier.color}>{tier.icon}</span>}
                  {r === "all" ? "All" : r}
                  <span className="opacity-60 ml-0.5">({count})</span>
                </button>
              );
            })}
          </div>

          {/* Clear all filters */}
          {activeFilterCount > 0 && (
            <Button
              variant="ghost"
              size="sm"
              onClick={clearAll}
              className="h-8 text-xs text-muted-foreground hover:text-foreground gap-1 ml-auto"
            >
              <X className="w-3.5 h-3.5" />
              Clear ({activeFilterCount})
            </Button>
          )}
        </div>

        {/* ── Rarity Legend ── */}
        <div className="mb-4 flex flex-wrap items-center gap-3 text-[10px] text-muted-foreground">
          <span className="font-semibold text-muted-foreground/70">Rarity:</span>
          {[
            { label: "Legendary", price: "≥$500", tier: getRarityTier(999) },
            { label: "Rare", price: "$100–$499", tier: getRarityTier(200) },
            { label: "Uncommon", price: "$50–$99", tier: getRarityTier(75) },
            { label: "Common", price: "<$50", tier: getRarityTier(10) },
          ].map(({ label, price, tier }) => (
            <span key={label} className={`flex items-center gap-1 ${tier.color}`}>
              {tier.icon}
              <span className="font-semibold">{label}</span>
              <span className="opacity-60">{price}</span>
            </span>
          ))}
        </div>

        {/* ── Results count + Admin Select All ── */}
        {!isLoading && (
          <div className="flex items-center justify-between mb-3">
            <p className="text-muted-foreground text-xs">
              {sorted.length} auction{sorted.length !== 1 ? "s" : ""}
              {(filter !== "all" || rarityFilter !== "all") && auctions && (
                <span className="text-muted-foreground/60"> (filtered from {auctions.length} total)</span>
              )}
            </p>
            {isAdmin && sorted.length > 0 && (
              <button
                onClick={() => {
                  if (selectedIds.size === paginatedAuctions.length) {
                    setSelectedIds(new Set());
                  } else {
                    setSelectedIds(new Set(paginatedAuctions.map(a => a.id)));
                  }
                }}
                className="flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground transition-colors"
              >
                {selectedIds.size === paginatedAuctions.length && paginatedAuctions.length > 0
                  ? <CheckSquare className="w-3.5 h-3.5 text-red-400" />
                  : <Square className="w-3.5 h-3.5" />
                }
                {selectedIds.size === paginatedAuctions.length && paginatedAuctions.length > 0 ? "Deselect All" : "Select All"}
              </button>
            )}
          </div>
        )}

        {/* ── Grid ── */}
        {isLoading ? (
          <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-7 xl:grid-cols-8 2xl:grid-cols-10 gap-2">
            {Array.from({ length: 16 }).map((_, i) => (
              <div key={i} className="bg-card border border-border rounded overflow-hidden animate-pulse">
                <div className="aspect-[5/7] bg-muted" />
                <div className="p-1.5 space-y-1">
                  <div className="h-2 bg-muted rounded" />
                  <div className="h-3 bg-muted rounded w-2/3" />
                </div>
              </div>
            ))}
          </div>
        ) : sorted.length > 0 ? (
          <>
            <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-7 xl:grid-cols-8 2xl:grid-cols-10 gap-2">
              {paginatedAuctions.map((auction) => {
                const rarity = auction._rarity;
                const displayPrice = auction._bid > 0 ? auction._bid : auction._price;
                const isEndingSoon = auction._endsAt - Date.now() < 3600000 * 24;
                const isSelected = selectedIds.has(auction.id);
                return (
                  <div
                    key={auction.id}
                    onClick={() => isAdmin && selectedIds.size > 0 ? toggleSelect(auction.id, { stopPropagation: () => {} } as any) : setSelectedAuction(auction)}
                    className="cursor-pointer relative"
                  >
                    {/* Admin checkbox overlay */}
                    {isAdmin && (
                      <button
                        onClick={(e) => toggleSelect(auction.id, e)}
                        className={`absolute top-1 left-1 z-20 transition-opacity ${
                          isSelected || selectedIds.size > 0 ? "opacity-100" : "opacity-0 group-hover:opacity-100"
                        }`}
                      >
                        {isSelected
                          ? <CheckSquare className="w-4 h-4 text-red-400 drop-shadow" />
                          : <Square className="w-4 h-4 text-white/70 drop-shadow" />
                        }
                      </button>
                    )}
                    <div className={`group bg-card border rounded overflow-hidden hover:shadow-md transition-all cursor-pointer h-full ${
                      rarity.label === "Legendary"
                        ? "border-yellow-500/40 hover:border-yellow-500/70 hover:shadow-yellow-500/10"
                        : rarity.label === "Rare"
                        ? "border-purple-500/30 hover:border-purple-500/60 hover:shadow-purple-500/10"
                        : rarity.label === "Uncommon"
                        ? "border-blue-500/20 hover:border-blue-500/50 hover:shadow-blue-500/10"
                        : "border-border hover:border-secondary/60 hover:shadow-secondary/10"
                    }`}>
                      {/* Card image */}
                      <div className="relative aspect-[5/7] overflow-hidden">
                        <SlabFrame
                          imageUrl={auction.cardImageUrl ?? (auction as any).frontImageUrl}
                          altText={auction.cardTitle}
                          labelColor="dark"
                          grade={(auction as any).gradeScore || (auction.gradeInfo ? auction.gradeInfo.split(' ')[0] : null)}
                          gradeLabel={auction.gradeInfo || null}
                          gradeCompany={(auction as any).gradeCompany}
                          playerName={auction.cardTitle}
                          cardId={auction.cardId}
                        />

                        {/* SCO VAULTED ribbon */}
                        {auction.isVaulted && (
                          <div className="absolute top-0 left-0 right-0 z-10 pointer-events-none">
                            <div className="bg-gradient-to-r from-[#b8860b] via-[#ffd700] to-[#b8860b] text-[#1a0a00] text-[8px] font-black text-center py-0.5 tracking-widest shadow-md">
                              ★ SCO VAULT GUARANTEED ★
                            </div>
                          </div>
                        )}
                        {auction.isVaulted && (
                          <div className="absolute bottom-1 left-1 z-10 pointer-events-none">
                            <div className="flex items-center gap-0.5 bg-gradient-to-r from-[#b8860b] to-[#ffd700] text-[#1a0a00] text-[7px] font-black px-1.5 py-0.5 rounded-sm shadow-lg">
                              <span>🏛</span>
                              <span>SCO VAULTED</span>
                            </div>
                          </div>
                        )}

                        {/* Grade badge */}
                        {auction.gradeInfo && (
                          <div className="absolute bottom-1 right-1 bg-[#E8C547] text-black text-[8px] font-black px-1 py-0.5 rounded leading-none">
                            {auction.gradeInfo}
                          </div>
                        )}

                        {/* Time left badge */}
                        <div className={`absolute top-1 left-1 text-[8px] font-mono px-1 py-0.5 rounded leading-none flex items-center gap-0.5 ${
                          isEndingSoon ? "bg-red-900/80 text-red-300" : "bg-black/70 text-orange-400"
                        }`}>
                          <Clock className="w-2 h-2" />
                          <TimeLeft endTime={auction.endTime} />
                        </div>

                        {/* Rarity badge */}
                        <div className={`absolute top-1 right-1 text-[7px] font-bold px-1 py-0.5 rounded leading-none flex items-center gap-0.5 ${rarity.bg} ${rarity.color} border ${rarity.border}`}>
                          {rarity.icon}
                          {rarity.label === "Legendary" ? "LEG" : rarity.label === "Uncommon" ? "UNC" : rarity.label.slice(0, 3).toUpperCase()}
                        </div>

                        {/* Heart / Favorite button */}
                        {auction.cardId && (
                          <div className="absolute top-6 right-1">
                            <FavoriteButton cardId={auction.cardId} size="sm" />
                          </div>
                        )}

                        {/* Buy Now badge */}
                        {auction.buyNowPrice && parseFloat(auction.buyNowPrice) > 0 && (
                          <div className="absolute bottom-1 left-1 bg-green-900/80 text-green-300 text-[7px] font-bold px-1 py-0.5 rounded leading-none">
                            BUY NOW
                          </div>
                        )}
                      </div>

                      {/* Info */}
                      <div className="p-1.5">
                        <h3 className="font-semibold text-[10px] line-clamp-1 leading-tight mb-0.5">
                          {auction.playerName || auction.cardTitle}
                        </h3>
                        <div className="flex items-center justify-between">
                          <p className="text-[10px] font-bold text-secondary">
                            ${displayPrice.toFixed(2)}
                          </p>
                          <span className="text-[8px] text-muted-foreground">
                            {auction.bidCount || 0} bid{auction.bidCount !== 1 ? "s" : ""}
                          </span>
                        </div>
                      </div>
                    </div>
                    {/* Selected highlight ring */}
                    {isAdmin && isSelected && (
                      <div className="absolute inset-0 ring-2 ring-red-500/70 rounded pointer-events-none" />
                    )}
                  </div>
                );
              })}
            </div>

            {/* Pagination */}
            {totalPages > 1 && (
              <div className="flex items-center justify-center gap-2 mt-6 flex-wrap">
                <button
                  onClick={() => setCurrentPage(1)}
                  disabled={currentPage === 1}
                  className="px-3 py-1.5 text-xs rounded-lg border border-border text-muted-foreground hover:text-foreground hover:border-border/60 disabled:opacity-30 disabled:cursor-not-allowed transition-all"
                >
                  «
                </button>
                <button
                  onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                  disabled={currentPage === 1}
                  className="px-3 py-1.5 text-xs rounded-lg border border-border text-muted-foreground hover:text-foreground hover:border-border/60 disabled:opacity-30 disabled:cursor-not-allowed transition-all"
                >
                  ‹ Prev
                </button>
                {Array.from({ length: Math.min(7, totalPages) }, (_, i) => {
                  const start = Math.max(1, Math.min(currentPage - 3, totalPages - 6));
                  const page = start + i;
                  if (page > totalPages) return null;
                  return (
                    <button
                      key={page}
                      onClick={() => setCurrentPage(page)}
                      className={`px-3 py-1.5 text-xs rounded-lg border transition-all ${
                        page === currentPage
                          ? "bg-secondary border-secondary text-secondary-foreground font-bold"
                          : "border-border text-muted-foreground hover:text-foreground hover:border-border/60"
                      }`}
                    >
                      {page}
                    </button>
                  );
                })}
                <button
                  onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
                  disabled={currentPage === totalPages}
                  className="px-3 py-1.5 text-xs rounded-lg border border-border text-muted-foreground hover:text-foreground hover:border-border/60 disabled:opacity-30 disabled:cursor-not-allowed transition-all"
                >
                  Next ›
                </button>
                <button
                  onClick={() => setCurrentPage(totalPages)}
                  disabled={currentPage === totalPages}
                  className="px-3 py-1.5 text-xs rounded-lg border border-border text-muted-foreground hover:text-foreground hover:border-border/60 disabled:opacity-30 disabled:cursor-not-allowed transition-all"
                >
                  »
                </button>
                <span className="text-xs text-muted-foreground ml-2">
                  {(currentPage - 1) * PAGE_SIZE + 1}–{Math.min(currentPage * PAGE_SIZE, sorted.length)} of {sorted.length}
                </span>
              </div>
            )}
          </>
        ) : (
          <div className="text-center py-16">
            <SlidersHorizontal className="w-12 h-12 text-muted-foreground/30 mx-auto mb-3" />
            <h3 className="text-lg font-semibold mb-1">No auctions match your filters</h3>
            <p className="text-muted-foreground text-sm mb-4">Try adjusting the sort or filter options above.</p>
            <Button variant="outline" size="sm" onClick={clearAll}>
              <X className="w-3.5 h-3.5 mr-1.5" />
              Clear All Filters
            </Button>
          </div>
        )}
      </div>

      {/* Admin Floating Bulk Action Bar */}
      {isAdmin && selectedIds.size > 0 && (
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 flex items-center gap-3 bg-[#1a0a00] border border-red-600/60 rounded-xl px-5 py-3 shadow-2xl shadow-red-900/30">
          <span className="text-sm font-semibold text-white">
            {selectedIds.size} selected
          </span>
          <Button
            variant="outline"
            size="sm"
            className="text-xs border-white/20 text-white/60 hover:bg-white/10"
            onClick={() => setSelectedIds(new Set())}
          >
            <X className="w-3.5 h-3.5 mr-1" /> Clear
          </Button>
          <Button
            size="sm"
            className="gap-1.5 bg-red-600 hover:bg-red-700 text-white text-xs"
            onClick={() => setShowBulkDeleteConfirm(true)}
            disabled={bulkDelete.isPending}
          >
            <Trash2 className="w-3.5 h-3.5" />
            Delete {selectedIds.size} Card{selectedIds.size !== 1 ? 's' : ''}
          </Button>
        </div>
      )}

      {/* Bulk Delete Confirmation */}
      <AlertDialog open={showBulkDeleteConfirm} onOpenChange={setShowBulkDeleteConfirm}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete {selectedIds.size} auction{selectedIds.size !== 1 ? 's' : ''}?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete {selectedIds.size} card{selectedIds.size !== 1 ? 's' : ''} and cancel their auctions. This cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              className="bg-red-600 hover:bg-red-700 text-white"
              onClick={() => bulkDelete.mutate({ auctionIds: Array.from(selectedIds) })}
              disabled={bulkDelete.isPending}
            >
              {bulkDelete.isPending ? "Deleting..." : "Yes, Delete All"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Card Popup — same as marketplace */}
      {selectedAuction && (
        <CardPopup
          open={!!selectedAuction}
          onClose={() => setSelectedAuction(null)}
          card={{
            id: selectedAuction.cardId,
            title: selectedAuction.cardTitle,
            playerName: selectedAuction.playerName || selectedAuction.cardTitle,
            price: selectedAuction.buyNowPrice ?? selectedAuction.startingPrice,
            frontImageUrl: selectedAuction.cardImageUrl ?? selectedAuction.frontImageUrl,
            backImageUrl: selectedAuction.backImageUrl ?? null,
            extraImageUrls: selectedAuction.extraImageUrls ?? null,
            labelColor: selectedAuction.labelColor ?? "dark",
            sellerEmail: selectedAuction.sellerEmail,
            storeName: selectedAuction.storeName ?? null,
            year: selectedAuction.year ?? null,
            setName: selectedAuction.setName ?? null,
            cardNumber: selectedAuction.cardNumber ?? null,
            sport: selectedAuction.sport ?? null,
            description: selectedAuction.description ?? null,
            aiGrade: selectedAuction.aiGrade ?? null,
            aiGradeLabel: selectedAuction.aiGradeLabel ?? null,
            aiCentering: selectedAuction.aiCentering ?? null,
            aiCorners: selectedAuction.aiCorners ?? null,
            aiEdges: selectedAuction.aiEdges ?? null,
            aiSurface: selectedAuction.aiSurface ?? null,
            aiCertNumber: selectedAuction.aiCertNumber ?? null,
            certNumber: selectedAuction.certNumber ?? null,
            isVaulted: selectedAuction.isVaulted ?? false,
          }}
        />
      )}
    </div>
  );
}
