import { useState, useEffect, useCallback } from "react";
import { useLocation } from "wouter";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { useCart } from "@/contexts/CartContext";

const COUNTER_BG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663482618714/HBSXFxHmEnEJMgVvzKnhpZ/credit-room-bg_402bc0b7.png";

// ─── Credit packages ──────────────────────────────────────────────────────────
const CHIP_PACKAGES = [
  { id: "25",   credits: 25,   price: 25,   bonus: 0,   label: "$25",   chipColor: "from-gray-200 to-gray-400",    ring: "ring-gray-300",   textColor: "text-gray-800" },
  { id: "50",   credits: 50,   price: 50,   bonus: 0,   label: "$50",   chipColor: "from-red-500 to-red-700",      ring: "ring-red-400",    textColor: "text-white"   },
  { id: "100",  credits: 100,  price: 100,  bonus: 0,   label: "$100",  chipColor: "from-blue-500 to-blue-700",    ring: "ring-blue-400",   textColor: "text-white"   },
  { id: "250",  credits: 256,  price: 250,  bonus: 6,   label: "$250",  chipColor: "from-green-500 to-green-700",  ring: "ring-green-400",  textColor: "text-white"   },
  { id: "500",  credits: 525,  price: 500,  bonus: 25,  label: "$500",  chipColor: "from-yellow-400 to-yellow-600",ring: "ring-yellow-300", textColor: "text-gray-900"},
  { id: "1000", credits: 1100, price: 1000, bonus: 100, label: "$1000", chipColor: "from-purple-600 to-purple-900",ring: "ring-purple-400", textColor: "text-white"   },
];

type Phase = "approach" | "counter" | "selecting" | "bill" | "pushing" | "leaving";
type Mode = "credits" | "checkout";

// ─── Casino chip button ───────────────────────────────────────────────────────
function CasinoChip({ pkg, onClick, disabled, selected }: {
  pkg: typeof CHIP_PACKAGES[0]; onClick: () => void; disabled: boolean; selected: boolean;
}) {
  return (
    <button onClick={onClick} disabled={disabled}
      className={`group relative flex flex-col items-center gap-2 transition-all duration-300
        ${selected ? "scale-125 -translate-y-4 z-10" : "hover:scale-110 hover:-translate-y-2"}
        disabled:opacity-40 disabled:cursor-not-allowed`}>
      <div className={`relative w-20 h-20 rounded-full bg-gradient-to-b ${pkg.chipColor}
        border-4 border-white/25 shadow-[0_8px_24px_rgba(0,0,0,0.7)] flex items-center justify-center
        ${selected ? `ring-4 ${pkg.ring} ring-offset-2 ring-offset-black/50 shadow-[0_0_30px_rgba(255,255,255,0.35)]` : ""}
        transition-all duration-300`}>
        <div className="absolute inset-1.5 rounded-full border-2 border-white/20" />
        {[0,60,120,180,240,300].map(deg => (
          <div key={deg} className="absolute inset-0 rounded-full overflow-hidden pointer-events-none" style={{ transform: `rotate(${deg}deg)` }}>
            <div className="absolute top-0 left-1/2 -translate-x-1/2 w-3 h-3.5 bg-white/25 rounded-b" />
          </div>
        ))}
        <div className={`relative z-10 text-center leading-tight ${pkg.textColor}`}>
          <div className="font-black text-lg drop-shadow">{pkg.label}</div>
          <div className="text-[10px] opacity-80">{pkg.credits} cr</div>
        </div>
      </div>
      {pkg.bonus > 0 && (
        <span className="bg-yellow-400 text-black text-[9px] font-black px-2 py-0.5 rounded-full shadow">
          +{pkg.bonus} FREE
        </span>
      )}
    </button>
  );
}

// ─── Chip push animation ──────────────────────────────────────────────────────
function ChipPush({ pkg, onDone }: { pkg: typeof CHIP_PACKAGES[0]; onDone: () => void }) {
  const [step, setStep] = useState(0);
  useEffect(() => {
    const t1 = setTimeout(() => setStep(1), 300);
    const t2 = setTimeout(() => setStep(2), 1400);
    const t3 = setTimeout(onDone, 2000);
    return () => { clearTimeout(t1); clearTimeout(t2); clearTimeout(t3); };
  }, [onDone]);
  const chipCount = Math.min(3 + Math.ceil(pkg.credits / 150), 9);
  return (
    <div className="absolute inset-0 flex items-end justify-center pb-28 pointer-events-none z-40">
      <div className={`flex gap-1.5 transition-all duration-700 ease-out
        ${step === 0 ? "translate-y-0 opacity-100" : step === 1 ? "translate-y-20 opacity-100 scale-110" : "translate-y-40 opacity-0"}`}>
        {Array.from({ length: chipCount }).map((_, i) => (
          <div key={i} className={`w-14 h-14 rounded-full bg-gradient-to-b ${pkg.chipColor} border-4 border-white/25 shadow-2xl flex items-center justify-center`}
            style={{ transform: `translateY(${i * -3}px)` }}>
            <div className={`font-black text-xs ${pkg.textColor} drop-shadow`}>{pkg.label}</div>
          </div>
        ))}
      </div>
      {step === 1 && (
        <div className="absolute bottom-52 text-yellow-400 font-black text-2xl drop-shadow-lg animate-bounce"
          style={{ fontFamily: "Oswald, sans-serif", textShadow: "0 0 20px rgba(234,179,8,0.9)" }}>
          🎰 Chips collected!
        </div>
      )}
    </div>
  );
}

// ─── Card push animation (for checkout) ──────────────────────────────────────
function CardPush({ cards, onDone }: { cards: { title: string; imageUrl?: string | null }[]; onDone: () => void }) {
  const [step, setStep] = useState(0);
  useEffect(() => {
    const t1 = setTimeout(() => setStep(1), 400);
    const t2 = setTimeout(() => setStep(2), 1600);
    const t3 = setTimeout(onDone, 2200);
    return () => { clearTimeout(t1); clearTimeout(t2); clearTimeout(t3); };
  }, [onDone]);
  return (
    <div className="absolute inset-0 flex items-end justify-center pb-24 pointer-events-none z-40">
      <div className={`flex gap-3 transition-all duration-800 ease-out
        ${step === 0 ? "translate-y-0 opacity-100" : step === 1 ? "translate-y-24 opacity-100 scale-105" : "translate-y-48 opacity-0"}`}>
        {cards.slice(0, 5).map((card, i) => (
          <div key={i} className="w-16 h-24 rounded-lg bg-gradient-to-b from-[#1a0a2e] to-[#0d1b3e] border-2 border-yellow-500/40 shadow-2xl overflow-hidden flex flex-col"
            style={{ transform: `rotate(${(i - Math.floor(cards.length / 2)) * 4}deg) translateY(${i * -2}px)` }}>
            {card.imageUrl
              ? <img src={card.imageUrl} alt={card.title} className="w-full h-full object-cover" />
              : <div className="w-full h-full flex items-center justify-center p-1">
                  <span className="text-yellow-500/60 font-black text-[8px] text-center leading-tight">{card.title}</span>
                </div>
            }
          </div>
        ))}
      </div>
      {step === 1 && (
        <div className="absolute bottom-52 text-yellow-400 font-black text-2xl drop-shadow-lg animate-bounce"
          style={{ fontFamily: "Oswald, sans-serif", textShadow: "0 0 20px rgba(234,179,8,0.9)" }}>
          🃏 Cards are yours!
        </div>
      )}
    </div>
  );
}

// ─── Bill / Invoice popup ─────────────────────────────────────────────────────
function BillPopup({ items, total, onPay, onCancel, paying }: {
  items: { title: string; playerName: string; price: string; imageUrl?: string | null }[];
  total: number;
  onPay: () => void;
  onCancel: () => void;
  paying: boolean;
}) {
  const fee = total * 0.1;
  const grandTotal = total + fee;
  return (
    <div className="absolute inset-0 flex items-center justify-center z-50 px-4">
      {/* Receipt paper */}
      <div className="bg-[#fdf8f0] text-gray-900 rounded-2xl shadow-[0_0_60px_rgba(0,0,0,0.8),0_0_120px_rgba(234,179,8,0.2)] max-w-sm w-full overflow-hidden border-4 border-yellow-500/30"
        style={{ fontFamily: "Courier New, monospace" }}>
        {/* Header */}
        <div className="bg-gradient-to-r from-[#0a1628] to-[#1a2a4a] text-white px-5 py-4 text-center">
          <div className="text-yellow-400 font-black text-xl tracking-widest" style={{ fontFamily: "Oswald, sans-serif" }}>SCO CASHIER</div>
          <div className="text-white/50 text-xs tracking-widest">SPORT CARDS ONLINE</div>
          <div className="text-white/30 text-[10px] mt-1">{new Date().toLocaleString()}</div>
        </div>
        {/* Divider */}
        <div className="border-t-2 border-dashed border-gray-300 mx-4 my-2" />
        {/* Items */}
        <div className="px-5 space-y-2 max-h-48 overflow-y-auto">
          {items.map((item, i) => (
            <div key={i} className="flex items-center gap-2">
              {item.imageUrl && (
                <img src={item.imageUrl} alt={item.title} className="w-8 h-11 object-cover rounded border border-gray-200 shrink-0" />
              )}
              <div className="flex-1 min-w-0">
                <p className="text-xs font-bold truncate">{item.playerName}</p>
                <p className="text-[10px] text-gray-500 truncate">{item.title}</p>
              </div>
              <span className="text-sm font-black shrink-0">${parseFloat(item.price).toFixed(2)}</span>
            </div>
          ))}
        </div>
        {/* Divider */}
        <div className="border-t-2 border-dashed border-gray-300 mx-4 my-2" />
        {/* Totals */}
        <div className="px-5 pb-2 space-y-1">
          <div className="flex justify-between text-sm">
            <span className="text-gray-600">Subtotal</span>
            <span className="font-bold">${total.toFixed(2)}</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-gray-600">Platform fee (10%)</span>
            <span className="font-bold">${fee.toFixed(2)}</span>
          </div>
          <div className="border-t border-gray-300 pt-1 flex justify-between text-base font-black">
            <span>TOTAL DUE</span>
            <span className="text-[#c41e3a]">${grandTotal.toFixed(2)}</span>
          </div>
        </div>
        {/* Divider */}
        <div className="border-t-2 border-dashed border-gray-300 mx-4 my-2" />
        {/* Actions */}
        <div className="px-5 pb-5 space-y-2">
          <button onClick={onPay} disabled={paying}
            className="w-full bg-[#c41e3a] hover:bg-[#c41e3a]/90 text-white font-black py-3 rounded-xl text-base transition-all disabled:opacity-50 shadow-lg"
            style={{ fontFamily: "Oswald, sans-serif" }}>
            {paying ? "Processing..." : `💳 PAY $${grandTotal.toFixed(2)}`}
          </button>
          <button onClick={onCancel}
            className="w-full text-gray-400 hover:text-gray-600 text-sm py-1 transition-colors">
            Cancel — go back
          </button>
          <p className="text-[9px] text-gray-400 text-center">Payment held in escrow until cards are shipped</p>
        </div>
      </div>
    </div>
  );
}

// ─── Main page ────────────────────────────────────────────────────────────────
export default function CreditRoom() {
  const [, navigate] = useLocation();
  const { isAuthenticated, user } = useAuth();
  const { data: account } = trpc.credits.myAccount.useQuery(undefined, { enabled: isAuthenticated });
  const { items: cartItems, clearCart } = useCart();
  const buyCredits = trpc.credits.buyCredits.useMutation({
    onError: () => toast.error("Checkout failed. Please try again."),
  });
  const createOrder = trpc.orders.create.useMutation();

  // Detect mode and returnPath from URL params
  const params = new URLSearchParams(window.location.search);
  const mode: Mode = params.get("checkout") === "cart" ? "checkout" : "credits";
  // Where to redirect after a successful credit purchase (e.g. /game-room, /marketplace)
  const returnPath = params.get("from") || "/game-room";

  const [phase, setPhase] = useState<Phase>("approach");
  const [tellerLine, setTellerLine] = useState(0);
  const [displayedText, setDisplayedText] = useState("");
  const [selectedPkg, setSelectedPkg] = useState<typeof CHIP_PACKAGES[0] | null>(null);
  const [paying, setPaying] = useState(false);

  // Teller lines differ by mode
  const tellerLines = mode === "checkout"
    ? [
        `Welcome back${user?.name ? `, ${user.name.split(" ")[0]}` : ""}! 👋`,
        "I've got your cards right here.",
        `That'll be $${(cartItems.reduce((s, i) => s + parseFloat(i.price || "0"), 0) * 1.1).toFixed(2)} total.`,
      ]
    : [
        `Welcome to the SCO Cash Window${user?.name ? `, ${user.name.split(" ")[0]}` : ""}! 👋`,
        "How are you today?",
        "How many credits would you like?",
      ];

  // Zoom-in approach
  useEffect(() => {
    const t = setTimeout(() => setPhase("counter"), 1100);
    return () => clearTimeout(t);
  }, []);

  // Typewriter effect
  useEffect(() => {
    if (phase !== "counter" && phase !== "selecting") return;
    const line = tellerLines[tellerLine] ?? "";
    let i = 0;
    setDisplayedText("");
    const iv = setInterval(() => {
      i++;
      setDisplayedText(line.slice(0, i));
      if (i >= line.length) {
        clearInterval(iv);
        if (tellerLine < tellerLines.length - 1) {
          setTimeout(() => setTellerLine(l => l + 1), 800);
        } else {
          setTimeout(() => setPhase("selecting"), 400);
        }
      }
    }, 30);
    return () => clearInterval(iv);
  }, [tellerLine, phase]);

  // When selecting phase starts in checkout mode, jump straight to bill
  useEffect(() => {
    if (phase === "selecting" && mode === "checkout") {
      setPhase("bill");
    }
  }, [phase, mode]);

  const handleChipClick = useCallback((pkg: typeof CHIP_PACKAGES[0]) => {
    if (!isAuthenticated) { window.location.href = getLoginUrl("/credits"); return; }
    setSelectedPkg(pkg);
    setPhase("pushing");
  }, [isAuthenticated]);

  const handleChipPushDone = useCallback(async () => {
    if (!selectedPkg) return;
    setPhase("leaving");
    try {
      const result = await buyCredits.mutateAsync({
        packageId: selectedPkg.id as "25" | "50" | "100" | "250" | "500" | "1000",
        origin: window.location.origin,
        returnPath,
      });
      if (result?.url) {
        toast.info("Redirecting to secure checkout...");
        // Navigate in same tab so Stripe can redirect back with success param
        window.location.href = result.url;
        return;
      }
    } catch { /* handled by mutation */ }
    setTimeout(() => navigate(returnPath), 500);
  }, [selectedPkg, buyCredits, navigate, returnPath]);

  const handlePayBill = useCallback(async () => {
    if (!isAuthenticated || cartItems.length === 0) return;
    setPaying(true);
    let successCount = 0;
    for (const item of cartItems) {
      try {
        await createOrder.mutateAsync({
          cardId: item.id,
          cardTitle: item.title,
          cardImageUrl: item.frontImageUrl || undefined,
          sellerEmail: item.sellerEmail,
          sellerStoreName: item.storeName || undefined,
          price: item.price,
        });
        successCount++;
      } catch (e: any) {
        toast.error(`Failed to order ${item.playerName}: ${e.message}`);
      }
    }
    setPaying(false);
    if (successCount > 0) {
      clearCart();
      setPhase("pushing"); // card push animation
    }
  }, [isAuthenticated, cartItems, createOrder, clearCart]);

  const handleCardPushDone = useCallback(() => {
    setPhase("leaving");
    toast.success("🎉 Orders placed! Check your collection.");
    setTimeout(() => navigate("/game-room"), 600);
  }, [navigate]);

  // Handle success/cancel params — redirect back to where user came from
  useEffect(() => {
    const p = new URLSearchParams(window.location.search);
    const from = p.get("from") || "/game-room";
    if (p.get("success")) {
      const creditsAdded = p.get("credits");
      toast.success(
        `🎉 ${creditsAdded ? creditsAdded + " credits" : "Credits"} added to your account! Go spend them!`,
        { duration: 4000 }
      );
      // Redirect back to where they came from after a short delay
      setTimeout(() => navigate(from), 2000);
    } else if (p.get("cancelled")) {
      toast.info("Purchase cancelled. Come back anytime!");
      window.history.replaceState({}, "", "/credits");
    }
  }, [navigate]);

  const checkoutCards = cartItems.map(i => ({ title: i.title, playerName: i.playerName, price: i.price, imageUrl: i.frontImageUrl }));
  const cartTotal = cartItems.reduce((s, i) => s + parseFloat(i.price || "0"), 0);

  return (
    <div className="fixed inset-0 overflow-hidden bg-black select-none" style={{ fontFamily: "Oswald, sans-serif" }}>

      {/* Background */}
      <div className="absolute inset-0 bg-cover bg-bottom"
        style={{
          backgroundImage: `url(${COUNTER_BG})`,
          transform: phase === "approach" ? "scale(1.35) translateY(6%)" : "scale(1) translateY(0)",
          transition: "transform 1.1s cubic-bezier(0.22,1,0.36,1)",
          filter: phase === "leaving" ? "brightness(0)" : "brightness(0.8)",
          transitionProperty: "transform, filter",
          transitionDuration: phase === "leaving" ? "0.6s, 0.6s" : "1.1s, 0.4s",
        }} />
      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-black/50 pointer-events-none" />

      {/* SCO logo */}
      <div className={`absolute top-6 left-1/2 -translate-x-1/2 text-center transition-all duration-1000
        ${phase === "approach" ? "opacity-0 scale-50" : "opacity-100 scale-100"}`}>
        <div className="text-yellow-400 font-black text-4xl tracking-[0.35em]"
          style={{ textShadow: "0 0 30px rgba(234,179,8,0.9), 0 0 70px rgba(234,179,8,0.4)" }}>SCO</div>
        <div className="text-white/30 text-[10px] tracking-[0.4em] uppercase mt-0.5">Sport Cards Online</div>
      </div>

      {/* ── THE VAULT door ── */}
      {(phase === "counter" || phase === "selecting" || phase === "bill") && (
        <div
          className={`absolute right-6 bottom-[18%] z-10 cursor-pointer group transition-all duration-700
            ${phase === "counter" ? "opacity-0 translate-x-8" : "opacity-100 translate-x-0"}`}
          onClick={() => navigate("/vault")}
          title="Visit The Vault"
        >
          {/* Vault door SVG */}
          <svg width="140" height="170" viewBox="0 0 140 170" fill="none" xmlns="http://www.w3.org/2000/svg"
            className="drop-shadow-[0_0_30px_rgba(234,179,8,0.6)] group-hover:drop-shadow-[0_0_50px_rgba(234,179,8,0.9)] transition-all duration-300">
            {/* Wall surround */}
            <rect x="2" y="2" width="136" height="166" rx="6" fill="#1a1008" stroke="#7c5a1a" strokeWidth="3"/>
            {/* Vault door body */}
            <rect x="10" y="10" width="120" height="150" rx="4" fill="url(#vaultGrad)" stroke="#c8922a" strokeWidth="2.5"/>
            {/* Corner bolts */}
            {[[20,20],[120,20],[20,150],[120,150]].map(([cx,cy],i) => (
              <g key={i}>
                <circle cx={cx} cy={cy} r="7" fill="#8a6520" stroke="#e0a830" strokeWidth="1.5"/>
                <circle cx={cx} cy={cy} r="3" fill="#f0c040"/>
              </g>
            ))}
            {/* Center circle frame */}
            <circle cx="70" cy="85" r="38" fill="#111" stroke="#c8922a" strokeWidth="3"/>
            <circle cx="70" cy="85" r="30" fill="url(#dialGrad)" stroke="#e0a830" strokeWidth="2"/>
            {/* Dial notches */}
            {Array.from({length:12}).map((_,i) => {
              const angle = (i * 30 - 90) * Math.PI / 180;
              const r1 = 24, r2 = 28;
              return <line key={i}
                x1={70 + r1*Math.cos(angle)} y1={85 + r1*Math.sin(angle)}
                x2={70 + r2*Math.cos(angle)} y2={85 + r2*Math.sin(angle)}
                stroke="#f0c040" strokeWidth={i % 3 === 0 ? 2 : 1} strokeLinecap="round"/>
            })}
            {/* Dial pointer */}
            <line x1="70" y1="85" x2="70" y2="62" stroke="#ff4444" strokeWidth="2.5" strokeLinecap="round"/>
            <circle cx="70" cy="85" r="4" fill="#e0a830" stroke="#f0c040" strokeWidth="1"/>
            {/* Handle bar */}
            <rect x="100" y="78" width="16" height="14" rx="3" fill="#c8922a" stroke="#e0a830" strokeWidth="1.5"/>
            <rect x="103" y="82" width="10" height="6" rx="1.5" fill="#8a6520"/>
            {/* Gradient defs */}
            <defs>
              <linearGradient id="vaultGrad" x1="0" y1="0" x2="1" y2="1">
                <stop offset="0%" stopColor="#4a3010"/>
                <stop offset="50%" stopColor="#7c5a1a"/>
                <stop offset="100%" stopColor="#3a2408"/>
              </linearGradient>
              <radialGradient id="dialGrad" cx="40%" cy="35%">
                <stop offset="0%" stopColor="#6a4a18"/>
                <stop offset="100%" stopColor="#2a1a06"/>
              </radialGradient>
            </defs>
          </svg>
          {/* THE VAULT sign */}
          <div className="mt-2 text-center">
            <div className="bg-black/80 border border-yellow-500/50 rounded px-3 py-1 inline-block"
              style={{ boxShadow: "0 0 12px rgba(234,179,8,0.4)" }}>
              <span className="text-yellow-400 font-black text-sm tracking-[0.25em] uppercase"
                style={{ textShadow: "0 0 10px rgba(234,179,8,0.8)" }}>THE VAULT</span>
            </div>
            <div className="text-white/40 text-[9px] tracking-widest mt-1 uppercase">Click to enter</div>
          </div>
        </div>
      )}

      {/* ── Cards on counter (checkout mode) ── */}
      {mode === "checkout" && (phase === "counter" || phase === "selecting" || phase === "bill") && cartItems.length > 0 && (
        <div className="absolute bottom-[45%] left-1/2 -translate-x-1/2 flex gap-3 z-10">
          {cartItems.slice(0, 5).map((item, i) => (
            <div key={item.id}
              className="w-14 h-20 rounded-lg border-2 border-yellow-500/40 shadow-2xl overflow-hidden bg-[#1a0a2e] transition-all duration-700"
              style={{ transform: `rotate(${(i - Math.floor(cartItems.length / 2)) * 5}deg) translateY(${Math.abs(i - Math.floor(cartItems.length / 2)) * 4}px)` }}>
              {item.frontImageUrl
                ? <img src={item.frontImageUrl} alt={item.title} className="w-full h-full object-cover" />
                : <div className="w-full h-full flex items-center justify-center p-1">
                    <span className="text-yellow-500/60 font-black text-[7px] text-center leading-tight">{item.playerName}</span>
                  </div>
              }
            </div>
          ))}
        </div>
      )}

      {/* Teller dialogue */}
      {(phase === "counter" || phase === "selecting") && (
        <div className="absolute top-[38%] left-1/2 -translate-x-1/2 -translate-y-1/2 w-full max-w-md px-6 z-20">
          <div className="bg-black/75 backdrop-blur-sm border border-yellow-500/30 rounded-2xl px-6 py-4 shadow-[0_0_40px_rgba(234,179,8,0.15)] text-center">
            <p className="text-white text-xl font-bold min-h-[2rem]">
              {displayedText}
              {displayedText.length < (tellerLines[tellerLine] ?? "").length && (
                <span className="inline-block w-0.5 h-5 bg-yellow-400 ml-0.5 animate-pulse align-middle" />
              )}
            </p>
          </div>
          <div className="w-4 h-4 bg-black/75 border-r border-b border-yellow-500/30 rotate-45 mx-auto -mt-2" />
        </div>
      )}

      {/* Approach text */}
      {phase === "approach" && (
        <div className="absolute inset-0 flex items-center justify-center">
          <p className="text-white/50 text-xl tracking-widest animate-pulse font-bold">
            Approaching the cashier...
          </p>
        </div>
      )}

      {/* ── Credit chip packages ── */}
      {mode === "credits" && (phase === "selecting" || phase === "pushing") && (
        <div className={`absolute bottom-0 left-0 right-0 pb-10 transition-all duration-600
          ${phase === "selecting" ? "translate-y-0 opacity-100" : "opacity-50 pointer-events-none"}`}
          style={{ background: "linear-gradient(to top, rgba(0,0,0,0.92) 55%, transparent)" }}>
          <p className="text-center text-yellow-400/60 text-xs tracking-[0.3em] uppercase font-bold mb-5">
            ↑ Choose your chips ↑
          </p>
          <div className="flex justify-center gap-5 flex-wrap px-4">
            {CHIP_PACKAGES.map(pkg => (
              <CasinoChip key={pkg.id} pkg={pkg} onClick={() => handleChipClick(pkg)}
                disabled={phase === "pushing"} selected={selectedPkg?.id === pkg.id} />
            ))}
          </div>
          {isAuthenticated && account && (
            <p className="text-center text-white/25 text-xs mt-5">
              Balance: <span className="text-yellow-400 font-bold">{account.credits} credits</span>
            </p>
          )}
          {!isAuthenticated && (
            <p className="text-center text-white/40 text-sm mt-5">
              <a href={getLoginUrl("/credits")} className="text-yellow-400 underline font-bold">Sign in</a> to purchase credits
            </p>
          )}
        </div>
      )}

      {/* ── Bill popup (checkout mode) ── */}
      {phase === "bill" && mode === "checkout" && (
        <BillPopup
          items={checkoutCards}
          total={cartTotal}
          onPay={handlePayBill}
          onCancel={() => navigate(-1 as any)}
          paying={paying}
        />
      )}

      {/* ── Chip push (credit mode) ── */}
      {phase === "pushing" && mode === "credits" && selectedPkg && (
        <ChipPush pkg={selectedPkg} onDone={handleChipPushDone} />
      )}

      {/* ── Card push (checkout mode) ── */}
      {phase === "pushing" && mode === "checkout" && (
        <CardPush cards={checkoutCards} onDone={handleCardPushDone} />
      )}

      {/* Leaving overlay */}
      {phase === "leaving" && (
        <div className="absolute inset-0 bg-black/90 flex items-center justify-center z-50">
          <p className="text-yellow-400 font-black text-2xl tracking-widest animate-pulse">
            {mode === "checkout" ? "🃏 Heading to your collection..." : "🎰 Entering the Game Room..."}
          </p>
        </div>
      )}

      {/* Back button */}
      {phase !== "approach" && phase !== "leaving" && (
        <button onClick={() => navigate(-1 as any)}
          className="absolute top-4 left-4 text-white/30 hover:text-white text-sm z-30 transition-colors font-bold tracking-wide">
          ← Back
        </button>
      )}
    </div>
  );
}
