import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Link } from "wouter";
import { toast } from "sonner";
import {
  LayoutDashboard, Package, Gavel, ArrowLeftRight, MessageSquare,
  Star, Copy, CheckCircle, TrendingUp, Coins, Award, ShoppingBag,
  Clock, ChevronRight, AlertCircle, Printer
} from "lucide-react";

function StatusBadge({ status }: { status: string }) {
  const map: Record<string, string> = {
    active:    "bg-green-500/20 text-green-400 border-green-500/30",
    auction:   "bg-yellow-500/20 text-yellow-400 border-yellow-500/30",
    sold:      "bg-blue-500/20 text-blue-400 border-blue-500/30",
    pending:   "bg-orange-500/20 text-orange-400 border-orange-500/30",
    shipped:   "bg-purple-500/20 text-purple-400 border-purple-500/30",
    delivered: "bg-green-500/20 text-green-400 border-green-500/30",
    cancelled: "bg-red-500/20 text-red-400 border-red-500/30",
  };
  return (
    <span className={`text-xs px-2 py-0.5 rounded-full border font-medium capitalize ${map[status] ?? "bg-white/10 text-white/40 border-white/10"}`}>
      {status}
    </span>
  );
}

export default function Dashboard() {
  const { isAuthenticated, user } = useAuth();
  const [copied, setCopied] = useState(false);

  const { data: collection } = trpc.collection.list.useQuery(undefined, { enabled: isAuthenticated });
  const { data: buyerOrders } = trpc.orders.myBuyerOrders.useQuery(undefined, { enabled: isAuthenticated });
  const { data: sellerOrders } = trpc.orders.mySellerOrders.useQuery(undefined, { enabled: isAuthenticated });
  const { data: trades } = trpc.trades.myReceivedTrades.useQuery(undefined, { enabled: isAuthenticated });
  const { data: credits } = trpc.credits.myAccount.useQuery(undefined, { enabled: isAuthenticated });
  const { data: affiliate } = trpc.affiliate.myAffiliate.useQuery(undefined, { enabled: isAuthenticated });
  const { data: conversations } = trpc.messages.myConversations.useQuery(undefined, { enabled: isAuthenticated });

  const pendingOrders = sellerOrders?.filter((o: any) => o.status === "paid") ?? [];
  const pendingTrades = trades?.filter((t: any) => t.status === "pending") ?? [];
  const activeListings = collection?.filter((c: any) => c.listingStatus === "active" || c.listingStatus === "auction") ?? [];

  const copyReferralCode = () => {
    if (affiliate?.referralCode) {
      navigator.clipboard.writeText(`https://sportsCardsonline.com?ref=${affiliate.referralCode}`);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
      toast.success("Referral link copied!");
    }
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-[#0a1628] flex items-center justify-center">
        <div className="text-center space-y-4">
          <LayoutDashboard className="w-16 h-16 text-white/20 mx-auto" />
          <h2 className="text-2xl font-bold text-white">Sign In Required</h2>
          <p className="text-white/50">Access your dashboard to manage your cards, orders, and trades.</p>
          <a href={getLoginUrl()} className="inline-block bg-[#C41E3A] hover:bg-[#a01830] text-white px-6 py-2 rounded-lg font-medium transition-colors">Sign In</a>
        </div>
      </div>
    );
  }

  const statCards = [
    { label: "Cards in Collection", value: collection?.length ?? 0,  icon: Award,      color: "text-blue-400",   href: "/collection" },
    { label: "Active Listings",     value: activeListings.length,     icon: ShoppingBag,color: "text-green-400",  href: "/collection" },
    { label: "Pending Orders",      value: pendingOrders.length,      icon: Package,    color: "text-yellow-400", href: "/orders" },
    { label: "Credits",             value: credits?.credits ?? 0,     icon: Coins,      color: "text-purple-400", href: "/credits" },
  ];

  return (
    <div className="min-h-screen bg-[#0a1628] pb-20">
      {/* Header */}
      <div className="bg-[#0d1f3c] border-b border-white/10 py-4">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h1 className="text-2xl font-black text-white" style={{ fontFamily: "Oswald, sans-serif" }}>
              Welcome back, {user?.name?.split(" ")[0] ?? "Collector"}!
            </h1>
            <div className="flex items-center gap-2 mt-0.5">
              <img src="https://d2xsxph8kpxj0f.cloudfront.net/310519663482618714/HBSXFxHmEnEJMgVvzKnhpZ/logo_white_border_bb86c840.png" alt="SportsCardsOnline.com" className="h-5 w-auto opacity-80" />
              <span className="text-white/40 text-xs">Dashboard</span>
            </div>
          </div>
          <div className="flex gap-2 flex-wrap">
            <Button size="sm" className="bg-[#C41E3A] hover:bg-[#a01830] text-white" asChild>
              <Link href="/grade-cards"><Award className="w-4 h-4 mr-1" />Grade Cards</Link>
            </Button>
            <Button size="sm" variant="outline" className="border-white/20 text-white hover:bg-white/10" asChild>
              <Link href="/collection"><ShoppingBag className="w-4 h-4 mr-1" />My Collection</Link>
            </Button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-6 space-y-6">
        {/* Affiliate Banner */}
        {affiliate && (
          <div className="bg-[#E8C547]/10 border border-[#E8C547]/30 rounded-xl p-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <Star className="w-8 h-8 text-[#E8C547] shrink-0" />
                <div>
                  <div className="font-bold text-sm text-white">Your Affiliate Code</div>
                  <div className="flex items-center gap-2">
                    <code className="text-lg font-mono font-black text-[#E8C547]">{affiliate.referralCode}</code>
                    <button onClick={copyReferralCode} className="p-1 rounded hover:bg-white/10 transition-colors">
                      {copied ? <CheckCircle className="w-4 h-4 text-green-400" /> : <Copy className="w-4 h-4 text-white/50" />}
                    </button>
                  </div>
                </div>
              </div>
              <div className="flex gap-6 text-center">
                <div>
                  <div className="text-xl font-black text-green-400">${parseFloat(affiliate.totalEarnings ?? "0").toFixed(2)}</div>
                  <div className="text-xs text-white/40">Total Earned</div>
                </div>
                <div>
                  <div className="text-xl font-black text-blue-400">{affiliate.totalReferrals ?? 0}</div>
                  <div className="text-xs text-white/40">Referrals</div>
                </div>
                <div>
                  <div className="text-xl font-black text-[#E8C547]">${parseFloat(affiliate.pendingPayout ?? "0").toFixed(2)}</div>
                  <div className="text-xs text-white/40">Pending</div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Stats Row */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {statCards.map(({ label, value, icon: Icon, color, href }) => (
            <Link href={href} key={label}>
              <div className="bg-[#0d1f3c] border border-white/10 rounded-xl p-4 cursor-pointer hover:border-white/25 transition-colors group">
                <div className="flex items-center justify-between mb-2">
                  <Icon className={`w-5 h-5 ${color}`} />
                  <ChevronRight className="w-4 h-4 text-white/20 group-hover:text-white/50 transition-colors" />
                </div>
                <div className="text-2xl font-black text-white">{value}</div>
                <div className="text-xs text-white/40">{label}</div>
              </div>
            </Link>
          ))}
        </div>

        {/* Action Required Banner */}
        {(pendingOrders.length > 0 || pendingTrades.length > 0) && (
          <div className="bg-yellow-500/10 border border-yellow-500/30 rounded-xl p-4">
            <div className="flex items-center gap-2 mb-3">
              <AlertCircle className="w-5 h-5 text-yellow-400" />
              <span className="font-bold text-white text-sm">Action Required</span>
            </div>
            <div className="space-y-2">
              {pendingOrders.map((order: any) => (
                <div key={order.id} className="flex items-center justify-between p-2 rounded-lg bg-white/5">
                  <div className="flex items-center gap-2">
                    <Package className="w-4 h-4 text-yellow-400 shrink-0" />
                    <span className="text-sm text-white">Ship order #{order.id} — <strong>{order.cardTitle}</strong></span>
                  </div>
                  <Button size="sm" variant="outline" className="h-7 text-xs border-white/20 text-white hover:bg-white/10" asChild>
                    <Link href="/orders">Add Tracking</Link>
                  </Button>
                </div>
              ))}
              {pendingTrades.map((trade: any) => (
                <div key={trade.id} className="flex items-center justify-between p-2 rounded-lg bg-white/5">
                  <div className="flex items-center gap-2">
                    <ArrowLeftRight className="w-4 h-4 text-blue-400 shrink-0" />
                    <span className="text-sm text-white">Trade offer from <strong>{trade.initiatorEmail}</strong></span>
                  </div>
                  <Button size="sm" variant="outline" className="h-7 text-xs border-white/20 text-white hover:bg-white/10" asChild>
                    <Link href="/trades">Review</Link>
                  </Button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Tabs */}
        <Tabs defaultValue="collection">
          <TabsList className="bg-white/5 border border-white/10 mb-4">
            <TabsTrigger value="collection" className="data-[state=active]:bg-[#C41E3A] data-[state=active]:text-white text-white/60">My Cards</TabsTrigger>
            <TabsTrigger value="orders" className="data-[state=active]:bg-[#C41E3A] data-[state=active]:text-white text-white/60">Orders</TabsTrigger>
            <TabsTrigger value="trades" className="data-[state=active]:bg-[#C41E3A] data-[state=active]:text-white text-white/60">Trades</TabsTrigger>
            <TabsTrigger value="messages" className="data-[state=active]:bg-[#C41E3A] data-[state=active]:text-white text-white/60">Messages</TabsTrigger>
          </TabsList>

          {/* COLLECTION TAB */}
          <TabsContent value="collection">
            <div className="flex justify-between items-center mb-3">
              <h3 className="font-semibold text-white">Recent Cards</h3>
              <Button size="sm" variant="outline" className="border-white/20 text-white hover:bg-white/10 text-xs" asChild>
                <Link href="/collection">View All</Link>
              </Button>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3">
              {collection?.slice(0, 10).map((item: any) => (
                <div key={item.id} className="bg-[#0d1f3c] border border-white/10 rounded-xl overflow-hidden hover:border-white/25 transition-colors group cursor-pointer">
                  <div className="relative aspect-[2.5/3.5] bg-white/5 overflow-hidden">
                    {item.frontImageUrl ? (
                      <img src={item.frontImageUrl} alt={item.playerName ?? ""} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center text-white/20"><Award className="w-8 h-8" /></div>
                    )}
                    {item.overallGrade && (
                      <div className="absolute top-1 right-1 bg-[#C41E3A] text-white text-xs font-black px-1.5 py-0.5 rounded">
                        {item.overallGrade}
                      </div>
                    )}
                    {item.listingStatus && item.listingStatus !== "collection" && (
                      <div className="absolute bottom-0 left-0 right-0 bg-black/70 text-center py-1">
                        <StatusBadge status={item.listingStatus === "active" ? "Market" : item.listingStatus === "auction" ? "Auction" : item.listingStatus} />
                      </div>
                    )}
                  </div>
                  <div className="p-2">
                    <div className="text-xs font-semibold line-clamp-1 text-white">{item.playerName ?? "Unknown"}</div>
                    <div className="text-xs text-white/40">{item.year} {item.setName}</div>
                    <div className="flex items-center justify-between mt-1">
                      <span className="text-xs text-white/30">{item.gradeLabel ?? "Raw"}</span>
                      <Printer className="w-3 h-3 text-white/20" />
                    </div>
                  </div>
                </div>
              ))}
              {(!collection || collection.length === 0) && (
                <div className="col-span-full text-center py-12 text-white/30">
                  <Award className="w-12 h-12 mx-auto mb-3 text-white/10" />
                  <p className="mb-3">No cards graded yet</p>
                  <Button className="bg-[#C41E3A] hover:bg-[#a01830] text-white" asChild>
                    <Link href="/grade-cards">Grade Your First Card</Link>
                  </Button>
                </div>
              )}
            </div>
          </TabsContent>

          {/* ORDERS TAB */}
          <TabsContent value="orders">
            <div className="flex justify-between items-center mb-3">
              <h3 className="font-semibold text-white">Recent Orders</h3>
              <Button size="sm" variant="outline" className="border-white/20 text-white hover:bg-white/10 text-xs" asChild>
                <Link href="/orders">View All</Link>
              </Button>
            </div>
            <div className="space-y-2">
              {[...(buyerOrders ?? []), ...(sellerOrders ?? [])].slice(0, 8).map((order: any) => (
                <div key={order.id} className="bg-[#0d1f3c] border border-white/10 rounded-xl p-3 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Package className="w-5 h-5 text-white/30 shrink-0" />
                    <div>
                      <div className="font-medium text-sm text-white">{order.cardTitle}</div>
                      <div className="text-xs text-white/40">
                        {buyerOrders?.find((o: any) => o.id === order.id) ? "Purchased from" : "Sold to"} {buyerOrders?.find((o: any) => o.id === order.id) ? order.sellerEmail : order.buyerEmail}
                      </div>
                      {order.trackingNumber && <div className="text-xs font-mono text-blue-400">Track: {order.trackingNumber}</div>}
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-bold text-green-400 text-sm">${parseFloat(order.totalAmount ?? "0").toFixed(2)}</div>
                    <StatusBadge status={order.status} />
                  </div>
                </div>
              ))}
              {(!buyerOrders?.length && !sellerOrders?.length) && (
                <div className="text-center py-12 text-white/30">
                  <Package className="w-12 h-12 mx-auto mb-3 text-white/10" />
                  <p>No orders yet</p>
                </div>
              )}
            </div>
          </TabsContent>

          {/* TRADES TAB */}
          <TabsContent value="trades">
            <div className="flex justify-between items-center mb-3">
              <h3 className="font-semibold text-white">Trade Offers</h3>
              <Button size="sm" variant="outline" className="border-white/20 text-white hover:bg-white/10 text-xs" asChild>
                <Link href="/trades">View All</Link>
              </Button>
            </div>
            <div className="space-y-2">
              {trades?.slice(0, 8).map((trade: any) => (
                <div key={trade.id} className="bg-[#0d1f3c] border border-white/10 rounded-xl p-3 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <ArrowLeftRight className="w-5 h-5 text-white/30 shrink-0" />
                    <div>
                      <div className="font-medium text-sm text-white">Trade from {trade.initiatorEmail}</div>
                      <div className="text-xs text-white/40">{trade.message ?? "No message"}</div>
                      <div className="text-xs text-white/20 flex items-center gap-1">
                        <Clock className="w-3 h-3" />{new Date(trade.createdAt).toLocaleDateString()}
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <StatusBadge status={trade.status} />
                    {trade.status === "pending" && (
                      <Button size="sm" className="h-7 text-xs bg-[#C41E3A] hover:bg-[#a01830] text-white" asChild>
                        <Link href="/trades">Review</Link>
                      </Button>
                    )}
                  </div>
                </div>
              ))}
              {(!trades || trades.length === 0) && (
                <div className="text-center py-12 text-white/30">
                  <ArrowLeftRight className="w-12 h-12 mx-auto mb-3 text-white/10" />
                  <p>No trade offers yet</p>
                </div>
              )}
            </div>
          </TabsContent>

          {/* MESSAGES TAB */}
          <TabsContent value="messages">
            <div className="flex justify-between items-center mb-3">
              <h3 className="font-semibold text-white">Recent Messages</h3>
              <Button size="sm" variant="outline" className="border-white/20 text-white hover:bg-white/10 text-xs" asChild>
                <Link href="/messages">View All</Link>
              </Button>
            </div>
            <div className="space-y-2">
              {conversations?.slice(0, 8).map((conv: any) => (
                <Link href={`/messages?conv=${conv.conversationId}`} key={conv.conversationId}>
                  <div className="bg-[#0d1f3c] border border-white/10 rounded-xl p-3 flex items-center justify-between hover:border-white/25 transition-colors cursor-pointer">
                    <div className="flex items-center gap-3">
                      <div className="w-9 h-9 rounded-full bg-[#C41E3A]/20 flex items-center justify-center text-[#C41E3A] font-bold text-sm shrink-0">
                        {(conv.otherName ?? conv.otherEmail ?? "?")[0].toUpperCase()}
                      </div>
                      <div>
                        <div className="font-medium text-sm text-white">{conv.otherName ?? conv.otherEmail}</div>
                        <div className="text-xs text-white/40 line-clamp-1">{conv.lastMessage}</div>
                      </div>
                    </div>
                    <div className="text-xs text-white/20">{new Date(conv.lastMessageTime).toLocaleDateString()}</div>
                  </div>
                </Link>
              ))}
              {(!conversations || conversations.length === 0) && (
                <div className="text-center py-12 text-white/30">
                  <MessageSquare className="w-12 h-12 mx-auto mb-3 text-white/10" />
                  <p>No messages yet</p>
                </div>
              )}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
