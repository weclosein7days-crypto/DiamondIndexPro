import { useRoute, Link, useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/_core/hooks/useAuth";
import { Clock, Award, ArrowLeft, Gavel, Zap, RefreshCw, Trash2 } from "lucide-react";
import { useState, useEffect } from "react";
import { toast } from "sonner";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

function TimeLeft({ endTime }: { endTime: Date }) {
  const [timeLeft, setTimeLeft] = useState("");
  useEffect(() => {
    const update = () => {
      const diff = new Date(endTime).getTime() - Date.now();
      if (diff <= 0) { setTimeLeft("Ended"); return; }
      const d = Math.floor(diff / 86400000);
      const h = Math.floor((diff % 86400000) / 3600000);
      const m = Math.floor((diff % 3600000) / 60000);
      const s = Math.floor((diff % 60000) / 1000);
      setTimeLeft(d > 0 ? `${d}d ${h}h ${m}m` : `${h}h ${m}m ${s}s`);
    };
    update();
    const i = setInterval(update, 1000);
    return () => clearInterval(i);
  }, [endTime]);
  return <span className="font-mono">{timeLeft}</span>;
}

export default function AuctionDetail() {
  const [, params] = useRoute("/auctions/:id");
  const [, navigate] = useLocation();
  const id = parseInt(params?.id || "0");
  const { isAuthenticated, user } = useAuth();
  const isAdmin = (user as any)?.role === "admin";
  const { data: auction, isLoading, refetch } = trpc.auctions.getById.useQuery({ id });
  const { data: bids } = trpc.auctions.getBids.useQuery({ auctionId: id });
  const placeBid = trpc.auctions.placeBid.useMutation();
  const adminDelete = trpc.auctions.adminDelete.useMutation({
    onSuccess: () => {
      toast.success("Auction and card deleted.");
      navigate("/auctions");
    },
    onError: (e) => toast.error(e.message || "Delete failed"),
  });
  const [bidAmount, setBidAmount] = useState("");
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);

  const currentBidNum = parseFloat(auction?.currentBid || "0");
  const currentBid = currentBidNum > 0 ? currentBidNum : parseFloat(auction?.startingPrice || "0");
  const startingPrice = parseFloat(auction?.startingPrice || "0");
  const minBid = currentBidNum > 0 ? currentBidNum + Math.max(1, currentBidNum * 0.05) : startingPrice;
  const buyNowPrice = auction?.buyNowPrice ? parseFloat(auction.buyNowPrice) : null;
  const autoRenew = (auction as any)?.autoRenew;

  const handleBuyNow = async () => {
    if (!buyNowPrice) return;
    const confirmed = window.confirm(`Buy Now for $${buyNowPrice.toFixed(2)}? This will immediately end the auction.`);
    if (!confirmed) return;
    try {
      await placeBid.mutateAsync({ auctionId: id, bidAmount: buyNowPrice.toFixed(2) });
      toast.success(`Purchased for $${buyNowPrice.toFixed(2)}!`);
      refetch();
    } catch (e: any) {
      toast.error(e.message || "Failed to complete purchase");
    }
  };

  const handlePlaceBid = async () => {
    if (!bidAmount || parseFloat(bidAmount) < minBid) {
      toast.error(`Minimum bid is $${minBid.toFixed(2)}`);
      return;
    }
    try {
      await placeBid.mutateAsync({ auctionId: id, bidAmount });
      toast.success("Bid placed successfully!");
      setBidAmount("");
      refetch();
    } catch (e: any) {
      toast.error(e.message || "Failed to place bid");
    }
  };

  if (isLoading) return <div className="container py-8"><div className="animate-pulse h-96 bg-muted rounded-lg" /></div>;
  if (!auction) return <div className="container py-8 text-center"><p>Auction not found</p></div>;

  return (
    <div className="min-h-screen py-8">
      <div className="container max-w-5xl">
        <div className="flex items-center justify-between mb-6">
          <Link href="/auctions">
            <Button variant="ghost" className="gap-2"><ArrowLeft className="w-4 h-4" />Back to Auctions</Button>
          </Link>
          {/* Admin-only Delete button */}
          {isAdmin && (
            <Button
              variant="destructive"
              size="sm"
              className="gap-2 bg-red-600 hover:bg-red-700"
              onClick={() => setShowDeleteConfirm(true)}
            >
              <Trash2 className="w-4 h-4" />
              Delete Card
            </Button>
          )}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="space-y-4">
            <div className="aspect-[3/4] bg-muted rounded-xl overflow-hidden">
              {((auction as any).frontImageUrl ?? auction.cardImageUrl) ? (
                <img src={((auction as any).frontImageUrl ?? auction.cardImageUrl)!} alt={auction.cardTitle} className="w-full h-full object-cover" />
              ) : (
                <div className="w-full h-full flex items-center justify-center"><Award className="w-16 h-16 text-muted-foreground/50" /></div>
              )}
            </div>
            {(auction as any).backImageUrl && (
              <div className="aspect-[3/4] bg-muted rounded-xl overflow-hidden">
                <img src={(auction as any).backImageUrl} alt={`${auction.cardTitle} (back)`} className="w-full h-full object-cover" />
              </div>
            )}
            {auction.cardId && (
              <a href={`/card/${auction.cardId}`}
                className="flex items-center justify-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors py-2">
                View Full Card Profile →
              </a>
            )}
          </div>
          <div>
            <Badge variant="secondary" className="mb-2">Live Auction</Badge>
            <h1 className="text-3xl font-bold mb-2">{auction.cardTitle}</h1>
            {auction.playerName && <p className="text-xl text-muted-foreground mb-4">{auction.playerName}</p>}
            {auction.gradeInfo && <Badge variant="outline" className="mb-4">{auction.gradeInfo}</Badge>}
            
            <Card className="mb-4 border-secondary/30">
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm text-muted-foreground">{parseFloat(auction?.currentBid || "0") > 0 ? "Current Bid" : "Starting Bid"}</span>
                  <Badge variant="secondary">{auction.bidCount || 0} bids</Badge>
                </div>
                <div className="text-5xl font-black text-secondary mb-3">${currentBid.toFixed(2)}</div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground flex items-center gap-1"><Clock className="w-4 h-4" />Time Left</span>
                  <span className="font-semibold text-orange-400"><TimeLeft endTime={auction.endTime} /></span>
                </div>
              </CardContent>
            </Card>

            {isAuthenticated && auction.status === "active" ? (
              <div className="space-y-3">
                <div>
                  <label className="text-sm font-medium mb-2 block">Your Bid (min: ${minBid.toFixed(2)})</label>
                  <Input
                    type="number"
                    step="0.01"
                    min={minBid}
                    placeholder={`$${minBid.toFixed(2)}`}
                    value={bidAmount}
                    onChange={(e) => setBidAmount(e.target.value)}
                  />
                </div>
                <Button size="lg" className="w-full gap-2" onClick={handlePlaceBid} disabled={placeBid.isPending}>
                  <Gavel className="w-5 h-5" />
                  {placeBid.isPending ? "Placing Bid..." : "Place Bid"}
                </Button>
                {buyNowPrice && (
                  <Button size="lg" variant="outline" className="w-full gap-2 border-yellow-500/50 text-yellow-400 hover:bg-yellow-500/10" onClick={handleBuyNow} disabled={placeBid.isPending}>
                    <Zap className="w-5 h-5" />
                    Buy Now — ${buyNowPrice.toFixed(2)}
                  </Button>
                )}
              </div>
            ) : !isAuthenticated ? (
              <Button size="lg" className="w-full" asChild>
                <a href="/api/oauth/login">Sign In to Bid</a>
              </Button>
            ) : (
              <p className="text-center text-muted-foreground py-4">This auction has ended</p>
            )}

            <div className="mt-6 space-y-2 text-sm text-muted-foreground">
              <p>Seller: {auction.storeName || auction.sellerEmail}</p>
              <p>Duration: {auction.durationDays} days</p>
              <p>Min Bid (Reserve): ${parseFloat(auction.startingPrice).toFixed(2)}</p>
              {buyNowPrice && <p>Buy Now Price: ${buyNowPrice.toFixed(2)}</p>}
              {autoRenew && (
                <p className="flex items-center gap-1 text-green-400/80">
                  <RefreshCw className="w-3 h-3" /> Auto-renews if reserve not met
                </p>
              )}
            </div>

            {bids && bids.length > 0 && (
              <div className="mt-6">
                <h3 className="font-semibold mb-3">Bid History</h3>
                <div className="space-y-2 max-h-64 overflow-y-auto">
                  {bids.map((bid) => (
                    <div key={bid.id} className="flex items-center justify-between text-sm p-2 bg-muted/50 rounded">
                      <span>{bid.bidderName || "Anonymous"}</span>
                      <span className="font-semibold">${parseFloat(bid.bidAmount).toFixed(2)}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Admin Delete Confirmation Dialog */}
      <AlertDialog open={showDeleteConfirm} onOpenChange={setShowDeleteConfirm}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete this card and auction?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete <strong>{auction.cardTitle}</strong> and cancel its auction. This cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              className="bg-red-600 hover:bg-red-700 text-white"
              onClick={() => adminDelete.mutate({ auctionId: id })}
              disabled={adminDelete.isPending}
            >
              {adminDelete.isPending ? "Deleting..." : "Yes, Delete"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
