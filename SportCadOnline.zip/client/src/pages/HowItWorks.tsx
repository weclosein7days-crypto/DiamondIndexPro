import { Link } from "wouter";
import { ShoppingCart, Camera, Gavel, Shield, Star, ArrowRight, CheckCircle, Coins, Package, Award } from "lucide-react";
import { Button } from "@/components/ui/button";

const steps = [
  {
    icon: ShoppingCart,
    color: "#c41e3a",
    step: "01",
    title: "Browse & Discover",
    description:
      "Explore thousands of graded sports cards across Basketball, Football, Baseball, Hockey, Soccer, and more. Use smart filters to find exactly what you're looking for — by player, sport, grade, or price.",
  },
  {
    icon: Coins,
    color: "#e8c547",
    step: "02",
    title: "Buy Credits",
    description:
      "CardVault uses a credit system for purchases. Credits never expire, and every purchase earns you loyalty points toward exclusive rewards. Top up any amount — no minimums.",
  },
  {
    icon: Camera,
    color: "#3b82f6",
    step: "03",
    title: "Grade Your Cards (AI-Powered)",
    description:
      "Submit your cards for SCO AI grading. Our system analyses centering, corners, edges, and surface to produce a grade in minutes — not weeks. Physical grading submission is also available.",
  },
  {
    icon: Gavel,
    color: "#8b5cf6",
    step: "04",
    title: "Bid at Live Auctions",
    description:
      "Join live timed auctions for rare and high-value cards. Set a max bid and let the system bid for you, or watch the action in real time. Every auction is secured by our escrow system.",
  },
  {
    icon: Package,
    color: "#10b981",
    step: "05",
    title: "Secure Checkout & Shipping",
    description:
      "All purchases are protected by our buyer guarantee. Cards are shipped in rigid card savers, bubble mailers, and tracked packaging. You'll receive email updates at every stage.",
  },
  {
    icon: Award,
    color: "#f97316",
    step: "06",
    title: "Build Your Collection",
    description:
      "Track every card you own in your personal vault. View estimated values, set price alerts, and trade directly with other collectors in the Trade Depot.",
  },
];

const faqs = [
  {
    q: "What is a graded card?",
    a: "A graded card has been professionally evaluated for condition and sealed in a tamper-evident case with a numeric grade (1–10). Higher grades mean better condition and typically higher value.",
  },
  {
    q: "How does the credit system work?",
    a: "Credits are the in-platform currency. 1 credit = $1 USD. You purchase credits via Stripe, then use them to buy cards, enter auctions, or submit grading orders. Credits never expire.",
  },
  {
    q: "Is my payment information secure?",
    a: "Yes. All payments are processed by Stripe, a PCI-DSS Level 1 certified payment provider. CardVault never stores your card number or CVV.",
  },
  {
    q: "How long does shipping take?",
    a: "Most orders ship within 1–2 business days. Domestic delivery typically takes 3–5 business days via tracked mail. International shipping is available on request.",
  },
  {
    q: "Can I sell my own cards?",
    a: "Yes — create a free account and list your cards directly. You can set a fixed price or put them up for auction. A small platform fee applies on completed sales.",
  },
  {
    q: "What sports are supported?",
    a: "Basketball (NBA & WNBA), Football (NFL), Baseball (MLB), Hockey (NHL), Soccer, and a growing Other category covering wrestling, golf, tennis, and more.",
  },
];

export default function HowItWorks() {
  return (
    <div className="min-h-screen bg-white">
      {/* Hero */}
      <section className="bg-[#0a0f1e] text-white py-16 px-4">
        <div className="max-w-4xl mx-auto text-center">
          <p className="text-[#e8c547] font-bold text-sm tracking-widest uppercase mb-3">CardVault Platform Guide</p>
          <h1 className="text-4xl sm:text-5xl font-black mb-4 leading-tight">
            How CardVault Works
          </h1>
          <p className="text-white/70 text-lg max-w-2xl mx-auto mb-8">
            Buy, sell, grade, and trade sports cards — all in one place. Here's everything you need to know to get started.
          </p>
          <div className="flex flex-wrap gap-3 justify-center">
            <Link href="/">
              <Button className="bg-[#c41e3a] hover:bg-[#a01830] text-white font-bold px-6">
                <ShoppingCart className="w-4 h-4 mr-2" />
                Shop Cards
              </Button>
            </Link>
            <Link href="/grade">
              <Button variant="outline" className="border-white/30 text-white hover:bg-white/10 font-bold px-6">
                <Camera className="w-4 h-4 mr-2" />
                Grade a Card
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Steps */}
      <section className="py-16 px-4 bg-gray-50">
        <div className="max-w-5xl mx-auto">
          <h2 className="text-2xl font-black text-gray-900 text-center mb-12">Step-by-Step Guide</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {steps.map(({ icon: Icon, color, step, title, description }) => (
              <div key={step} className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6 hover:shadow-md transition-shadow">
                <div className="flex items-center gap-3 mb-4">
                  <div
                    className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0"
                    style={{ background: `${color}18` }}
                  >
                    <Icon className="w-5 h-5" style={{ color }} />
                  </div>
                  <span className="text-xs font-black tracking-widest text-gray-300">STEP {step}</span>
                </div>
                <h3 className="text-base font-black text-gray-900 mb-2">{title}</h3>
                <p className="text-sm text-gray-500 leading-relaxed">{description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Trust bar */}
      <section className="py-10 px-4 bg-[#0a0f1e]">
        <div className="max-w-4xl mx-auto grid grid-cols-2 sm:grid-cols-4 gap-6 text-center">
          {[
            { label: "Cards Listed", value: "10,000+" },
            { label: "Graded by SCO AI", value: "5,000+" },
            { label: "Happy Collectors", value: "2,500+" },
            { label: "Sports Covered", value: "6" },
          ].map(({ label, value }) => (
            <div key={label}>
              <p className="text-2xl font-black text-[#e8c547]">{value}</p>
              <p className="text-white/60 text-xs mt-1">{label}</p>
            </div>
          ))}
        </div>
      </section>

      {/* FAQ */}
      <section className="py-16 px-4 bg-white">
        <div className="max-w-3xl mx-auto">
          <h2 className="text-2xl font-black text-gray-900 text-center mb-10">Frequently Asked Questions</h2>
          <div className="space-y-4">
            {faqs.map(({ q, a }) => (
              <div key={q} className="border border-gray-100 rounded-xl p-5 hover:border-[#c41e3a]/30 transition-colors">
                <div className="flex items-start gap-3">
                  <CheckCircle className="w-5 h-5 text-[#c41e3a] shrink-0 mt-0.5" />
                  <div>
                    <p className="font-bold text-gray-900 mb-1">{q}</p>
                    <p className="text-sm text-gray-500 leading-relaxed">{a}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-14 px-4 bg-gradient-to-br from-[#c41e3a] to-[#8b0000] text-white text-center">
        <h2 className="text-3xl font-black mb-3">Ready to start collecting?</h2>
        <p className="text-white/80 mb-8 max-w-xl mx-auto">
          Join thousands of collectors buying, selling, and grading sports cards on CardVault.
        </p>
        <Link href="/">
          <Button className="bg-white text-[#c41e3a] hover:bg-gray-100 font-black px-8 py-3 text-base">
            Browse the Marketplace
            <ArrowRight className="w-4 h-4 ml-2" />
          </Button>
        </Link>
      </section>
    </div>
  );
}
