import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import PrizeClaimForm from "@/components/PrizeClaimForm";
import { Trophy, Search, Star, Zap, Gem, ChevronRight, Coins } from "lucide-react";
import type { PrizeVault } from "../../../drizzle/schema";
import { toast } from "sonner";

const TIER_LABELS = [
  { key: "100", label: "100% of Balance", desc: "Best card you can afford", color: "#fbbf24", icon: <Gem className="w-4 h-4" /> },
  { key: "50",  label: "50% of Balance",  desc: "Mid-range picks",          color: "#10b981", icon: <Star className="w-4 h-4" /> },
  { key: "25",  label: "25% of Balance",  desc: "Budget options",           color: "#3b82f6", icon: <Zap className="w-4 h-4" /> },
  { key: "10",  label: "10% of Balance",  desc: "Small wins",               color: "#8b5cf6", icon: <Coins className="w-4 h-4" /> },
];

export default function PrizeShowcase() {
  const { isAuthenticated } = useAuth();
  const [search, setSearch] = useState("");
  const [activeTier, setActiveTier] = useState<string | null>(null);
  const [claimPrize, setClaimPrize] = useState<null | {
    cardTitle: string; cardValue: number; prizeVaultId: number;
  }>(null);

  const { data: creditData } = trpc.credits.myAccount.useQuery(undefined, {
    enabled: isAuthenticated,
  });
  const userCredits = creditData?.credits ?? 0;

  const { data: vaultCards = [], isLoading } = trpc.game.getPrizeVault.useQuery();

  // Filter by search
  const filtered = vaultCards.filter(c =>
    !search || c.cardTitle.toLowerCase().includes(search.toLowerCase())
  );

  // Group by credit tier relative to user balance
  // Each tier shows ALL cards affordable at that percentage of balance
  // Sorted by credit cost descending so most expensive cards appear first
  const grouped = TIER_LABELS.map(tier => {
    const pct = parseInt(tier.key) / 100;
    const maxCredits = Math.max(Math.floor(userCredits * pct), 1);
    const cards = filtered
      .filter(c => c.creditCost <= maxCredits)
      .sort((a, b) => b.creditCost - a.creditCost);
    return { ...tier, maxCredits, cards };
  });

  // All cards sorted high to low for search results
  const allSorted = [...filtered].sort((a, b) => b.creditCost - a.creditCost);

  const handleRedeem = (card: PrizeVault) => {
    if (!isAuthenticated) {
      window.location.href = getLoginUrl("/game-room/showcase");
      return;
    }
    if (userCredits < card.creditCost) {
      toast.error(`You need ${card.creditCost} credits. You have ${userCredits}.`);
      return;
    }
    setClaimPrize({ cardTitle: card.cardTitle, cardValue: parseFloat(String(card.estimatedValue)) || 0, prizeVaultId: card.id });
  };

  return (
    <div className="min-h-screen bg-[#050d1a] text-white" style={{ fontFamily: "Oswald, sans-serif" }}>
      {/* Header */}
      <div className="relative overflow-hidden bg-gradient-to-b from-[#0d1f3c] to-[#050d1a] pt-12 pb-8 px-4">
        <div className="absolute inset-0 opacity-10"
          style={{ backgroundImage: "repeating-linear-gradient(45deg, #fbbf24 0, #fbbf24 1px, transparent 0, transparent 50%)", backgroundSize: "20px 20px" }} />
        <div className="relative max-w-6xl mx-auto text-center">
          <div className="flex items-center justify-center gap-3 mb-3">
            <Trophy className="w-8 h-8 text-yellow-400" />
            <h1 className="text-4xl font-black text-yellow-400 tracking-wider">PRIZE SHOWCASE</h1>
            <Trophy className="w-8 h-8 text-yellow-400" />
          </div>
          <p className="text-white/60 text-sm mb-4">Redeem your credits for real sports cards — shipped to your door for $2.50</p>
          {isAuthenticated && (
            <div className="inline-flex items-center gap-2 bg-yellow-500/20 border border-yellow-500/40 rounded-full px-4 py-1.5 text-yellow-300 text-sm font-bold">
              <Coins className="w-4 h-4" />
              Your Balance: {userCredits.toLocaleString()} Credits
            </div>
          )}
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-4 pb-16">
        {/* Search */}
        <div className="relative mb-8 max-w-md mx-auto">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/40" />
          <Input
            placeholder="Search cards..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="pl-9 bg-white/5 border-white/10 text-white placeholder:text-white/30 focus:border-yellow-500/50"
          />
        </div>

        {/* Tier filter buttons */}
        {isAuthenticated && (
          <div className="flex flex-wrap gap-2 justify-center mb-8">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setActiveTier(null)}
              className={`border-white/20 text-white/70 hover:text-white ${!activeTier ? "bg-white/10 border-white/40 text-white" : ""}`}
            >
              All Cards
            </Button>
            {TIER_LABELS.map(tier => (
              <Button
                key={tier.key}
                variant="outline"
                size="sm"
                onClick={() => setActiveTier(activeTier === tier.key ? null : tier.key)}
                className={`gap-1 border-white/20 text-white/70 hover:text-white transition-all ${activeTier === tier.key ? "bg-white/10 border-white/40 text-white" : ""}`}
                style={activeTier === tier.key ? { borderColor: tier.color, color: tier.color } : {}}
              >
                {tier.icon} {tier.label}
              </Button>
            ))}
          </div>
        )}

        {isLoading ? (
          <div className="text-center text-white/40 py-20">Loading showcase...</div>
        ) : search ? (
          /* Search results — all sorted high to low */
          <div>
            <h2 className="text-lg font-black text-white/60 mb-4 tracking-wider">
              SEARCH RESULTS ({allSorted.length})
            </h2>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
              {allSorted.map(card => (
                <ShowcaseCard key={card.id} card={card} userCredits={userCredits} onRedeem={handleRedeem} />
              ))}
            </div>
          </div>
        ) : activeTier ? (
          /* Single tier view */
          (() => {
            const tier = grouped.find(t => t.key === activeTier)!;
            return (
              <div>
                <div className="flex items-center gap-2 mb-4">
                  <span style={{ color: tier.color }}>{tier.icon}</span>
                  <h2 className="text-lg font-black tracking-wider" style={{ color: tier.color }}>
                    {tier.label.toUpperCase()}
                  </h2>
                  <span className="text-white/40 text-sm">— up to {tier.maxCredits} credits</span>
                </div>
                {tier.cards.length === 0 ? (
                  <div className="text-center text-white/30 py-12 border border-white/10 rounded-xl">
                    No cards in this range right now. Check back soon!
                  </div>
                ) : (
                  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
                    {tier.cards.map(card => (
                      <ShowcaseCard key={card.id} card={card} userCredits={userCredits} onRedeem={handleRedeem} />
                    ))}
                  </div>
                )}
              </div>
            );
          })()
        ) : (
          /* Default: all tiers stacked */
          <div className="space-y-10">
            {grouped.map(tier => (
              <div key={tier.key}>
                {/* Tier header */}
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-2">
                    <span style={{ color: tier.color }}>{tier.icon}</span>
                    <h2 className="text-xl font-black tracking-wider" style={{ color: tier.color }}>
                      {tier.label.toUpperCase()}
                    </h2>
                    <span className="text-white/40 text-sm hidden sm:inline">— {tier.desc}</span>
                    {isAuthenticated && (
                      <Badge className="text-xs ml-1" style={{ background: `${tier.color}22`, color: tier.color, border: `1px solid ${tier.color}44` }}>
                        up to {tier.maxCredits} credits
                      </Badge>
                    )}
                  </div>
                  <button
                    onClick={() => setActiveTier(tier.key)}
                    className="text-xs text-white/40 hover:text-white flex items-center gap-1 transition-colors"
                  >
                    See all <ChevronRight className="w-3 h-3" />
                  </button>
                </div>

                {/* Horizontal scroll showcase */}
                <div className="flex gap-4 overflow-x-auto pb-2 scrollbar-thin scrollbar-thumb-white/10">
                  {(isAuthenticated ? tier.cards : allSorted.slice(0, 8)).length === 0 ? (
                    <div className="text-white/20 text-sm py-8 px-4">No cards in this range yet.</div>
                  ) : (
                    (isAuthenticated ? tier.cards : allSorted.slice(0, 8)).slice(0, 10).map(card => (
                      <div key={card.id} className="shrink-0 w-40">
                        <ShowcaseCard card={card} userCredits={userCredits} onRedeem={handleRedeem} />
                      </div>
                    ))
                  )}
                </div>

                {/* Divider */}
                <div className="mt-6 h-px bg-gradient-to-r from-transparent via-white/10 to-transparent" />
              </div>
            ))}
          </div>
        )}

        {/* Not logged in CTA */}
        {!isAuthenticated && (
          <div className="mt-12 text-center border border-yellow-500/30 rounded-2xl p-8 bg-yellow-500/5">
            <Trophy className="w-12 h-12 text-yellow-400 mx-auto mb-3" />
            <h3 className="text-xl font-black text-yellow-400 mb-2">Sign In to Redeem Cards</h3>
            <p className="text-white/50 text-sm mb-4">Create a free account, earn credits by playing games, and redeem them for real sports cards.</p>
            <Button
              onClick={() => window.location.href = getLoginUrl("/game-room/showcase")}
              className="bg-yellow-500 hover:bg-yellow-400 text-black font-black"
            >
              Sign In / Create Account
            </Button>
          </div>
        )}
      </div>

      {/* Prize Claim Modal */}
      {claimPrize && (
        <PrizeClaimForm
          open={!!claimPrize}
          onClose={() => setClaimPrize(null)}
          prize={{
            cardTitle: claimPrize.cardTitle,
            cardValue: claimPrize.cardValue,
            prizeVaultId: claimPrize.prizeVaultId,
            claimType: "showcase_redeem",
          }}
        />
      )}
    </div>
  );
}

// ─── ShowcaseCard ────────────────────────────────────────────────────────────
function ShowcaseCard({
  card,
  userCredits,
  onRedeem,
}: {
  card: PrizeVault;
  userCredits: number;
  onRedeem: (card: PrizeVault) => void;
}) {
  const cost = card.creditCost;
  const canAfford = userCredits >= cost;

  const tierColor: Record<string, string> = {
    mega_jackpot: "#fbbf24",
    mini_jackpot: "#f97316",
    featured: "#10b981",
    standard: "#3b82f6",
  };
  const color = tierColor[card.tier] ?? "#3b82f6";

  return (
    <div
      className="group relative rounded-xl overflow-hidden border transition-all duration-200 cursor-pointer"
      style={{ borderColor: `${color}44`, background: `linear-gradient(135deg, #0d1f3c, #050d1a)` }}
      onClick={() => onRedeem(card)}
    >
      {/* Card image or placeholder */}
      <div className="aspect-[3/4] relative overflow-hidden bg-black/40">
        {card.frontImageUrl ? (
          <img src={card.frontImageUrl} alt={card.cardTitle} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" />
        ) : (
          <div className="w-full h-full flex items-center justify-center">
            <Trophy className="w-8 h-8 opacity-20" style={{ color }} />
          </div>
        )}
        {/* Tier badge */}
        <div className="absolute top-1.5 left-1.5">
          <Badge className="text-[10px] px-1.5 py-0.5 font-black" style={{ background: `${color}33`, color, border: `1px solid ${color}55` }}>
            {card.tier.replace("_", " ").toUpperCase()}
          </Badge>
        </div>
      </div>

      {/* Info */}
      <div className="p-2">
        <p className="text-white text-xs font-bold leading-tight line-clamp-2 mb-1">{card.cardTitle}</p>
        <div className="flex items-center justify-between">
          <span className="text-xs font-black" style={{ color }}>{cost.toLocaleString()} cr</span>
          {canAfford ? (
            <span className="text-[10px] text-green-400 font-bold">✓ Afford</span>
          ) : (
            <span className="text-[10px] text-white/30">Need more</span>
          )}
        </div>
      </div>

      {/* Hover overlay */}
      <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-200 flex items-center justify-center"
        style={{ background: `${color}22` }}>
        <span className="text-xs font-black text-white bg-black/60 px-3 py-1.5 rounded-full">REDEEM</span>
      </div>
    </div>
  );
}
