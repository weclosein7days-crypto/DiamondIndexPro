import { useState, useEffect, useCallback, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Badge } from "@/components/ui/badge";
import { Link } from "wouter";
import { ArrowLeft, Volume2, VolumeX, RotateCcw } from "lucide-react";
import { toast } from "sonner";
import { useGameAudio } from "@/hooks/useGameAudio";
import {
  type Card, type GameState, type Player, type PlayerAction,
  initGame, dealHands, evaluateHand, aiDecide, determineWinners, createDeck,
} from "@/lib/pokerEngine";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";

// ─── Playing Card ─────────────────────────────────────────────────────────────
const SUIT_COLORS: Record<string, string> = {
  "♠": "text-gray-900", "♣": "text-gray-900", "♥": "text-red-600", "♦": "text-red-600",
};

function PlayingCard({ card, size = "md", delay = 0 }: { card: Card | null; size?: "xs" | "sm" | "md"; delay?: number }) {
  const [visible, setVisible] = useState(false);
  useEffect(() => { const t = setTimeout(() => setVisible(true), delay); return () => clearTimeout(t); }, [delay]);

  const sizes = { xs: "w-7 h-10 text-[8px]", sm: "w-9 h-12 text-[10px]", md: "w-11 h-16 text-xs" };

  if (!card) return <div className={`${sizes[size]} rounded-lg bg-white/5 border border-white/10 border-dashed`} />;

  const suitColor = SUIT_COLORS[card.suit] || "text-gray-900";

  return (
    <div className={`${sizes[size]} relative transition-all duration-500 ${visible ? "opacity-100 translate-y-0" : "opacity-0 -translate-y-4"}`}
      style={{ perspective: "600px" }}>
      <div className="w-full h-full" style={{ transformStyle: "preserve-3d", transition: "transform 0.4s ease",
        transform: card.faceUp ? "rotateY(0deg)" : "rotateY(180deg)" }}>
        {/* Front */}
        <div className="absolute inset-0 rounded-lg bg-white border border-gray-200 shadow-lg flex flex-col justify-between p-0.5"
          style={{ backfaceVisibility: "hidden" }}>
          <div className={`font-black leading-none ${suitColor}`}>{card.rank}<div className="text-[8px]">{card.suit}</div></div>
          <div className={`text-center font-black ${suitColor} ${size === "xs" ? "text-sm" : size === "sm" ? "text-xl" : "text-3xl"}`}>{card.suit}</div>
          <div className={`font-black leading-none rotate-180 self-end ${suitColor}`}>{card.rank}<div className="text-[8px]">{card.suit}</div></div>
        </div>
        {/* Back */}
        <div className="absolute inset-0 rounded-lg shadow-lg overflow-hidden" style={{ backfaceVisibility: "hidden", transform: "rotateY(180deg)" }}>
          <div className="w-full h-full bg-gradient-to-br from-[#1a0a2e] to-[#0d1b3e] flex items-center justify-center">
            <div className="w-[85%] h-[85%] rounded border-2 border-yellow-500/40 flex items-center justify-center">
              <span className="text-yellow-500/60 font-black text-[9px] tracking-widest rotate-45">SCO</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── Chip Stack ───────────────────────────────────────────────────────────────
function ChipStack({ amount }: { amount: number }) {
  if (amount <= 0) return null;
  const colors = ["bg-red-500", "bg-blue-500", "bg-green-500", "bg-gray-900", "bg-purple-500"];
  const count = Math.min(Math.ceil(amount / 20), 5);
  return (
    <div className="flex items-end gap-0.5">
      {Array.from({ length: count }).map((_, i) => (
        <div key={i} className={`${colors[i % colors.length]} rounded-full border border-white/30 shadow`} style={{ width: 12, height: 3 }} />
      ))}
      <span className="text-yellow-400 font-black text-[10px] ml-1">{amount}</span>
    </div>
  );
}

// ─── Player Seat ──────────────────────────────────────────────────────────────
function PlayerSeat({ player, isActive, dealDelay }: { player: Player; isActive: boolean; dealDelay: number }) {
  return (
    <div className={`flex flex-col items-center gap-1 transition-all duration-300 ${player.folded ? "opacity-40" : ""}`}>
      <div className={`relative w-12 h-12 rounded-full flex items-center justify-center text-2xl border-2 transition-all duration-300
        ${isActive ? "border-yellow-400 shadow-[0_0_15px_rgba(234,179,8,0.6)] scale-110" : "border-white/20"}
        ${player.isWinner ? "border-green-400 shadow-[0_0_20px_rgba(74,222,128,0.7)]" : ""}
        bg-gradient-to-b from-gray-800 to-gray-900`}>
        {player.avatar}
        {player.isDealer && (
          <div className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-white text-black text-[9px] font-black flex items-center justify-center">D</div>
        )}
        {isActive && <div className="absolute inset-0 rounded-full border-2 border-yellow-400 animate-ping opacity-30" />}
      </div>
      <div className="text-center">
        <p className={`text-[10px] font-bold truncate max-w-[72px] ${player.isHuman ? "text-yellow-400" : "text-white/80"}`}>{player.name}</p>
        <ChipStack amount={player.chips} />
      </div>
      <div className="flex gap-0.5">
        {player.holeCards.length > 0
          ? player.holeCards.map((c, i) => <PlayingCard key={i} card={c} size="xs" delay={dealDelay + i * 150} />)
          : <><div className="w-8 h-11 rounded-lg bg-white/5 border border-white/10" /><div className="w-8 h-11 rounded-lg bg-white/5 border border-white/10" /></>
        }
      </div>
      {player.lastAction && (
        <Badge className={`text-[9px] px-1.5 py-0 ${
          player.lastAction === "fold" ? "bg-red-900/60 text-red-300" :
          player.lastAction === "raise" ? "bg-yellow-600/60 text-yellow-200" :
          player.lastAction === "call" ? "bg-blue-600/60 text-blue-200" : "bg-white/10 text-white/60"}`}>
          {player.lastAction}
        </Badge>
      )}
      {player.handResult && (
        <div className={`text-[9px] font-bold px-1.5 py-0.5 rounded ${player.isWinner ? "bg-green-500/20 text-green-400" : "bg-white/5 text-white/40"}`}>
          {player.handResult.rank}
        </div>
      )}
      {player.bet > 0 && (
        <div className="flex items-center gap-0.5">
          <div className="w-3 h-3 rounded-full bg-red-500 border border-white/30" />
          <span className="text-yellow-300 text-[10px] font-bold">{player.bet}</span>
        </div>
      )}
    </div>
  );
}

// ─── Action Timer ─────────────────────────────────────────────────
function ActionTimer({ timeLeft, total = 20 }: { timeLeft: number; total?: number }) {
  const radius = 22;
  const circ = 2 * Math.PI * radius;
  const pct = Math.max(0, timeLeft / total);
  const dash = circ * pct;
  const color = timeLeft <= 5 ? '#ef4444' : timeLeft <= 10 ? '#f97316' : '#22c55e';
  return (
    <div className="flex flex-col items-center gap-1">
      <svg width="56" height="56" viewBox="0 0 56 56">
        <circle cx="28" cy="28" r={radius} fill="none" stroke="#1f2937" strokeWidth="5" />
        <circle cx="28" cy="28" r={radius} fill="none" stroke={color} strokeWidth="5"
          strokeDasharray={`${dash} ${circ}`} strokeLinecap="round"
          transform="rotate(-90 28 28)" style={{ transition: 'stroke-dasharray 0.9s linear, stroke 0.3s' }} />
        <text x="28" y="33" textAnchor="middle" fill={color} fontSize="14" fontWeight="bold">{timeLeft}</text>
      </svg>
      {timeLeft <= 10 && (
        <span className="text-xs font-bold animate-pulse" style={{ color }}>
          {timeLeft <= 5 ? (timeLeft === 0 ? 'FOLDED!' : '⚠️ AUTO-FOLD!') : '⏰ ACT NOW!'}
        </span>
      )}
    </div>
  );
}

// ─── Buy-In Modal ─────────────────────────────────────────────────────────────
function BuyInModal({ onStart, maxCredits }: { onStart: (amount: number) => void; maxCredits: number }) {
  const [buyIn, setBuyIn] = useState(Math.min(100, maxCredits));
  const options = [25, 50, 100, 250, 500].filter(v => v <= maxCredits);
  if (options.length === 0) options.push(25);

  return (
    <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
      <div className="bg-gradient-to-b from-[#1a2a1a] to-[#0d1a0d] border-2 border-green-700/50 rounded-2xl p-8 max-w-sm w-full text-center shadow-[0_0_60px_rgba(0,100,0,0.4)]">
        <div className="text-5xl mb-3">🃏</div>
        <h2 className="text-2xl font-black text-white mb-1" style={{ fontFamily: "Oswald, sans-serif" }}>TEXAS HOLD'EM</h2>
        <p className="text-white/50 text-sm mb-6">vs AI opponents · Select your buy-in</p>
        <div className="grid grid-cols-3 gap-2 mb-4">
          {options.map(opt => (
            <button key={opt} onClick={() => setBuyIn(opt)}
              className={`rounded-xl py-2 text-sm font-bold border transition-all ${buyIn === opt
                ? "bg-green-600 border-green-400 text-white shadow-lg scale-105"
                : "bg-white/5 border-white/10 text-white/70 hover:border-white/30"}`}>
              {opt} cr
            </button>
          ))}
        </div>
        <p className="text-white/30 text-xs mb-4">Blinds: {Math.max(1, Math.floor(buyIn / 20))} / {Math.max(2, Math.floor(buyIn / 10))} credits</p>
        {maxCredits < 25 && (
          <p className="text-red-400 text-xs mb-3">You need at least 25 credits to play. <Link href="/credits?from=/poker" className="underline text-yellow-400">Buy Credits →</Link></p>
        )}
        <Button onClick={() => onStart(buyIn)} disabled={maxCredits < 25}
          className="w-full bg-green-600 hover:bg-green-500 text-white font-black text-lg h-12">
          🃏 Deal Me In
        </Button>
        <p className="text-white/20 text-xs mt-3">Free to play · Credits used for real prize games</p>
      </div>
    </div>
  );
}

// ─── Seat Positions (oval table, 5 players) ───────────────────────────────────
const SEAT_POSITIONS = [
  { style: { bottom: "2%", left: "50%", transform: "translateX(-50%)" } },  // human bottom
  { style: { top: "50%", left: "2%", transform: "translateY(-50%)" } },      // AI left
  { style: { top: "8%", left: "20%" } },                                      // AI top-left
  { style: { top: "8%", right: "20%" } },                                     // AI top-right
  { style: { top: "50%", right: "2%", transform: "translateY(-50%)" } },     // AI right
];

// ─── Main Component ───────────────────────────────────────────────────────────
export default function PokerTable() {
  const { isAuthenticated, user } = useAuth();
  const { data: account } = trpc.credits.myAccount.useQuery(undefined, { enabled: isAuthenticated });

  const [gameState, setGameState] = useState<GameState | null>(null);
  const [showBuyIn, setShowBuyIn] = useState(true);
  const [raiseAmount, setRaiseAmount] = useState(0);
  const [muted, setMuted] = useState(false);
  const [processing, setProcessing] = useState(false);
  // handId increments on every new hand to force AI effect re-fire even when currentPlayerIndex is the same
  const [handId, setHandId] = useState(0);
  // skipTimer: counts up while it's an AI's turn; shows Skip button after 20s
  const [aiStuckSeconds, setAiStuckSeconds] = useState(0);
  const aiStuckRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const audio = useGameAudio();
  const aiTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  // Refs to always have fresh values inside callbacks
  const gameStateRef = useRef<GameState | null>(null);
  const mutedRef = useRef(false);
  const processingRef = useRef(false);
  useEffect(() => { gameStateRef.current = gameState; }, [gameState]);
  useEffect(() => { mutedRef.current = muted; }, [muted]);
  useEffect(() => { processingRef.current = processing; }, [processing]);

  const humanPlayer = gameState?.players.find(p => p.isHuman);
  const isHumanTurn = gameState?.phase === "playing" &&
    gameState.players[gameState.currentPlayerIndex]?.isHuman &&
    !humanPlayer?.folded;

  // ─── Action Timer (20s countdown, auto-fold at 0) ──────────────────────────
  const ACTION_SECONDS = 20;
  const [actionTimer, setActionTimer] = useState<number>(ACTION_SECONDS);
  const actionTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // Start/reset timer whenever it becomes the human's turn
  useEffect(() => {
    if (actionTimerRef.current) clearInterval(actionTimerRef.current);
    if (!isHumanTurn) { setActionTimer(ACTION_SECONDS); return; }
    setActionTimer(ACTION_SECONDS);
    actionTimerRef.current = setInterval(() => {
      setActionTimer(prev => {
        if (prev <= 1) {
          clearInterval(actionTimerRef.current!);
          // Auto-fold when timer hits 0
          processAction("fold");
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => { if (actionTimerRef.current) clearInterval(actionTimerRef.current); };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isHumanTurn, gameState?.currentPlayerIndex]);

  const callAmount = gameState
    ? Math.max(0, Math.max(...gameState.players.map(p => p.bet)) - (humanPlayer?.bet ?? 0))
    : 0;

  const startGame = useCallback((buyIn: number) => {
    const sb = Math.max(1, Math.floor(buyIn / 20));
    const state = initGame(user?.name || "You", buyIn, sb, 4);
    const dealt = dealHands(state);
    setGameState(dealt);
    setShowBuyIn(false);
    setRaiseAmount(dealt.bigBlind * 2);
    if (!muted) {
      // Deal sounds for 2 hole cards per player (4 players = 8 cards)
      for (let i = 0; i < 8; i++) setTimeout(() => audio.playDeal(), i * 80);
    }
  }, [user, muted, audio]);

  // Core game state transition — pure function, works on prev state
  const applyAction = useCallback((prev: GameState, action: PlayerAction, amount = 0): GameState => {
    const players = prev.players.map(p => ({ ...p }));
    const idx = prev.currentPlayerIndex;
    const player = players[idx];
    let pot = prev.pot;
    const log = [...prev.actionLog];
    const isMuted = mutedRef.current;

    if (action === "fold") {
      player.folded = true; player.lastAction = "fold";
      log.push(`${player.name} folds`);
      if (!isMuted && player.isHuman) audio.playFold();
    } else if (action === "check") {
      player.lastAction = "check"; log.push(`${player.name} checks`);
      if (!isMuted && player.isHuman) audio.playCheck();
    } else if (action === "call") {
      const maxBetNow = Math.max(...players.map(p => p.bet));
      const toCall = Math.min(Math.max(0, maxBetNow - player.bet), player.chips);
      player.chips -= toCall; player.bet += toCall; player.totalBet += toCall; pot += toCall;
      player.lastAction = "call"; log.push(`${player.name} calls ${toCall}`);
      if (!isMuted && player.isHuman) audio.playChip();
    } else if (action === "raise") {
      const raiseTotal = Math.min(amount, player.chips);
      player.chips -= raiseTotal; player.bet += raiseTotal; player.totalBet += raiseTotal; pot += raiseTotal;
      player.lastAction = "raise"; log.push(`${player.name} raises to ${player.bet}`);
      if (!isMuted && player.isHuman) audio.playRaise();
    }

    const activePlayers = players.filter(p => !p.folded && !p.isAllIn);
    const maxBet = Math.max(...players.map(p => p.bet));
    const allCalled = activePlayers.every(p => p.bet === maxBet || p.chips === 0);
    const onlyOne = players.filter(p => !p.folded).length === 1;

    if (onlyOne) {
      const winner = players.find(p => !p.folded)!;
      winner.chips += pot; winner.isWinner = true;
      log.push(`${winner.name} wins ${pot} chips!`);
      if (!isMuted) {
        if (winner.isHuman) setTimeout(() => audio.playPotWin(), 200);
        else setTimeout(() => audio.playLose(), 200);
      }
      return { ...prev, players, pot, actionLog: log, phase: "showdown", winners: [winner.id] };
    }

    let nextIdx = (idx + 1) % players.length;
    let safety = 0;
    while ((players[nextIdx].folded || players[nextIdx].isAllIn) && safety < players.length) {
      nextIdx = (nextIdx + 1) % players.length; safety++;
    }

    if (allCalled) {
      const rounds: GameState["round"][] = ["preflop", "flop", "turn", "river", "showdown"];
      const rIdx = rounds.indexOf(prev.round);
      const nextRound = rounds[rIdx + 1];
      const resetPlayers = players.map(p => ({ ...p, bet: 0, lastAction: undefined as PlayerAction | undefined }));
      if (nextRound === "showdown") {
        const result = determineWinners({ ...prev, players: resetPlayers, pot, actionLog: log, round: "showdown" });
        if (!isMuted) {
          const humanWon = result.winners.includes("human");
          setTimeout(() => humanWon ? audio.playPotWin() : audio.playLose(), 400);
        }
        return result;
      }
      const deck = [...prev.deck];
      const newCommunity = [...prev.communityCards];
      if (!isMuted) {
        const cardCount = nextRound === "flop" ? 3 : 1;
        for (let i = 0; i < cardCount; i++) setTimeout(() => audio.playDeal(), i * 100);
      }
      if (nextRound === "flop") {
        newCommunity.push({ rank: deck.pop()!.rank, suit: deck.pop()!.suit, faceUp: true });
        newCommunity.push({ rank: deck.pop()!.rank, suit: deck.pop()!.suit, faceUp: true });
        newCommunity.push({ rank: deck.pop()!.rank, suit: deck.pop()!.suit, faceUp: true });
      } else {
        newCommunity.push({ rank: deck.pop()!.rank, suit: deck.pop()!.suit, faceUp: true });
      }
      const firstActive = (prev.dealerIndex + 1) % players.length;
      return { ...prev, players: resetPlayers, communityCards: newCommunity, deck, pot, round: nextRound,
        currentPlayerIndex: firstActive, actionLog: log, lastRaiseAmount: prev.bigBlind, minRaise: prev.bigBlind };
    }
    return { ...prev, players, pot, currentPlayerIndex: nextIdx, actionLog: log };
  }, [audio]);

  // Human action — guarded by processing lock
  const processAction = useCallback((action: PlayerAction, amount = 0) => {
    if (processingRef.current) return;
    processingRef.current = true;
    setProcessing(true);
    setGameState(prev => prev ? applyAction(prev, action, amount) : prev);
    setTimeout(() => { processingRef.current = false; setProcessing(false); }, 150);
  }, [applyAction]);

  // AI stuck timer — starts when it's an AI's turn, resets when turn changes
  const isAiTurn = !!(gameState?.phase === "playing" &&
    gameState.players[gameState.currentPlayerIndex] &&
    !gameState.players[gameState.currentPlayerIndex].isHuman &&
    !gameState.players[gameState.currentPlayerIndex].folded);

  useEffect(() => {
    if (aiStuckRef.current) clearInterval(aiStuckRef.current);
    setAiStuckSeconds(0);
    if (!isAiTurn) return;
    aiStuckRef.current = setInterval(() => {
      setAiStuckSeconds(s => s + 1);
    }, 1000);
    return () => { if (aiStuckRef.current) clearInterval(aiStuckRef.current); };
  }, [isAiTurn, gameState?.currentPlayerIndex, handId]);

  // Force-skip a stuck AI player (fold them and advance)
  const skipAiPlayer = useCallback(() => {
    setAiStuckSeconds(0);
    if (aiTimerRef.current) clearTimeout(aiTimerRef.current);
    setGameState(prev => {
      if (!prev || prev.phase !== "playing") return prev;
      return applyAction(prev, "fold", 0);
    });
  }, [applyAction]);

  // AI turns — uses refs to avoid stale closures, bypasses processing lock
  useEffect(() => {
    if (!gameState || gameState.phase !== "playing") return;
    const cur = gameState.players[gameState.currentPlayerIndex];
    if (!cur || cur.isHuman || cur.folded) return;
    if (aiTimerRef.current) clearTimeout(aiTimerRef.current);
    aiTimerRef.current = setTimeout(() => {
      const gs = gameStateRef.current;
      if (!gs || gs.phase !== "playing") return;
      const aiPlayer = gs.players[gs.currentPlayerIndex];
      if (!aiPlayer || aiPlayer.isHuman || aiPlayer.folded) return;
      const maxBet = Math.max(...gs.players.map(p => p.bet));
      const toCall = Math.max(0, maxBet - aiPlayer.bet);
      const decision = aiDecide(aiPlayer, gs, toCall);
      // AI bypasses processing lock — uses setGameState functional update directly
      setGameState(prev => prev && prev.phase === "playing" ? applyAction(prev, decision.action, decision.amount) : prev);
    }, 600 + Math.random() * 700);
    return () => { if (aiTimerRef.current) clearTimeout(aiTimerRef.current); };
  // handId ensures the effect re-fires on every new hand even if currentPlayerIndex is the same
  }, [gameState?.currentPlayerIndex, gameState?.phase, gameState?.round, handId, applyAction]);

  const newHand = useCallback(() => {
    if (!gameState) return;
    const alive = gameState.players.filter(p => p.chips > 0);
    if (alive.length < 2) { toast.info("Game over!"); setShowBuyIn(true); setGameState(null); return; }
    const newDealerIdx = (gameState.dealerIndex + 1) % gameState.players.length;
    const reset: GameState = {
      ...gameState, deck: createDeck(), dealerIndex: newDealerIdx,
      players: gameState.players.map((p, i) => ({
        ...p, isDealer: i === newDealerIdx, holeCards: [], bet: 0, totalBet: 0,
        folded: false, isAllIn: false, lastAction: undefined, handResult: undefined, isWinner: false, isTurn: false,
      })),
      communityCards: [], pot: 0, round: "preflop", phase: "waiting", winners: [], actionLog: [],
    };
    const dealt = dealHands(reset);
    setGameState(dealt);
    setRaiseAmount(dealt.bigBlind * 2);
    setHandId(h => h + 1); // force AI effect re-fire on new hand
    setAiStuckSeconds(0);
    if (aiTimerRef.current) clearTimeout(aiTimerRef.current);
  }, [gameState]);

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-[#0a1a0a] flex items-center justify-center">
        <div className="text-center p-8">
          <div className="text-6xl mb-4">🃏</div>
          <h2 className="text-2xl font-black text-white mb-2">Sign In to Play Poker</h2>
          <p className="text-white/50 mb-4">You need an account to play for credits.</p>
          <Button asChild className="bg-green-600 hover:bg-green-500 text-white font-black">
            <a href={getLoginUrl("/game-room/poker")}>Sign In</a>
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="h-screen bg-[#050a05] flex flex-col overflow-hidden" style={{ fontFamily: "'Oswald', sans-serif" }}>
      {/* Top bar */}
      <div className="flex items-center justify-between px-4 py-2 bg-black/60 border-b border-white/5 z-20 flex-shrink-0">
        <Button asChild variant="ghost" size="sm" className="text-white/60 hover:text-white gap-1.5">
          <Link href="/game-room"><ArrowLeft className="w-4 h-4" /> Game Room</Link>
        </Button>
        <div className="flex items-center gap-3">
          <div className="hidden sm:flex items-center gap-1.5 bg-red-600/80 border border-red-400/60 rounded-lg px-3 py-1 animate-pulse">
            <span className="text-white text-xs font-black">🎰 FREE PLAY 4 NOW — No Prizes</span>
          </div>
          <span className="text-yellow-400 font-black text-sm">🪙 {account?.credits ?? 0} credits</span>
          {gameState && (
            <Badge className="bg-green-800/60 text-green-300 text-xs">
              {gameState.round.toUpperCase()} · POT: {gameState.pot}
            </Badge>
          )}
        </div>
        <div className="flex items-center gap-2">
          <button onClick={() => setMuted(m => !m)} className="text-white/40 hover:text-white">
            {muted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
          </button>
          {gameState?.phase === "showdown" && (
            <Button size="sm" onClick={newHand} className="bg-green-700 hover:bg-green-600 text-white font-bold gap-1">
              <RotateCcw className="w-3 h-3" /> New Hand
            </Button>
          )}
        </div>
      </div>

      {/* Table area */}
      <div className="flex-1 flex items-center justify-center px-3 py-1 relative min-h-0">
        <div className="relative w-full max-w-2xl" style={{ aspectRatio: "16/9" }}>
          {/* Outer wood rim */}
          <div className="absolute inset-0 rounded-[50%] bg-gradient-to-b from-amber-700 to-amber-950 shadow-[0_0_80px_rgba(0,0,0,0.9)]" />
          {/* Rail */}
          <div className="absolute inset-[2.5%] rounded-[50%] bg-gradient-to-b from-amber-600 to-amber-900" />
          {/* Felt */}
          <div className="absolute inset-[5%] rounded-[50%] flex items-center justify-center overflow-hidden"
            style={{ background: "radial-gradient(ellipse at center, #1d6b30 0%, #0f3d1a 60%, #0a2d12 100%)", boxShadow: "inset 0 0 60px rgba(0,0,0,0.6)" }}>
            {/* Felt texture */}
            <div className="absolute inset-0 rounded-[50%] opacity-[0.06]"
              style={{ backgroundImage: "repeating-linear-gradient(45deg,transparent,transparent 2px,rgba(255,255,255,0.1) 2px,rgba(255,255,255,0.1) 4px)" }} />
            {/* Center content */}
            <div className="relative z-10 flex flex-col items-center gap-3 w-full px-8">
              {/* Watermark */}
              <div className="absolute text-white/[0.04] font-black text-5xl tracking-widest select-none pointer-events-none">SCO</div>
              {/* Community cards */}
              <div className="flex gap-1.5 justify-center">
                {Array.from({ length: 5 }).map((_, i) => (
                  <PlayingCard key={i} card={gameState?.communityCards[i] ?? null} size="sm" />
                ))}
              </div>
              {/* Pot */}
              {gameState && gameState.pot > 0 && (
                <div className="flex items-center gap-2 bg-black/50 rounded-full px-4 py-1.5 border border-yellow-500/20">
                  <div className="flex gap-0.5">
                    {["bg-red-500","bg-blue-500","bg-green-500"].map((c,i) => (
                      <div key={i} className={`w-3 h-3 rounded-full ${c} border border-white/30`} />
                    ))}
                  </div>
                  <span className="text-yellow-400 font-black text-sm">POT: {gameState.pot}</span>
                </div>
              )}
              {/* Round dots */}
              {gameState && (
                <div className="flex gap-2">
                  {(["preflop","flop","turn","river"] as const).map((r, ri) => {
                    const rounds = ["preflop","flop","turn","river"];
                    const cur = rounds.indexOf(gameState.round);
                    return (
                      <div key={r} className={`w-2 h-2 rounded-full transition-all ${
                        gameState.round === r ? "bg-yellow-400 scale-125" : cur > ri ? "bg-green-500" : "bg-white/20"}`} />
                    );
                  })}
                </div>
              )}
            </div>
          </div>

          {/* Player seats */}
          {gameState?.players.map((player, i) => (
            <div key={player.id} className="absolute z-20" style={SEAT_POSITIONS[i]?.style}>
              <PlayerSeat player={player} isActive={gameState.currentPlayerIndex === i && gameState.phase === "playing"} dealDelay={i * 200} />
            </div>
          ))}
        </div>

        {/* Action log */}
        {gameState && (
          <div className="absolute right-2 top-2 w-44 max-h-52 overflow-y-auto bg-black/60 border border-white/10 rounded-xl p-2 z-10">
            <p className="text-white/30 text-[9px] font-bold uppercase mb-1">Action Log</p>
            {[...gameState.actionLog].reverse().slice(0, 12).map((log, i) => (
              <p key={i} className="text-white/50 text-[9px] leading-relaxed border-b border-white/5 py-0.5">{log}</p>
            ))}
          </div>
        )}
      </div>

      {/* Controls */}
      {gameState?.phase === "playing" && (
        <div className="bg-black/80 border-t border-white/10 px-4 py-2 flex-shrink-0">
          {isHumanTurn ? (
            <div className="max-w-lg mx-auto">
              <div className="flex items-center gap-2 flex-wrap justify-center">
                {/* Inline timer */}
                <div className="flex items-center gap-1 bg-black/60 rounded-lg px-2 py-1 border border-white/10">
                  <svg width="28" height="28" viewBox="0 0 56 56">
                    <circle cx="28" cy="28" r="22" fill="none" stroke="#1f2937" strokeWidth="5" />
                    <circle cx="28" cy="28" r="22" fill="none"
                      stroke={actionTimer <= 5 ? '#ef4444' : actionTimer <= 10 ? '#f97316' : '#22c55e'}
                      strokeWidth="5"
                      strokeDasharray={`${(2 * Math.PI * 22) * Math.max(0, actionTimer / ACTION_SECONDS)} ${2 * Math.PI * 22}`}
                      strokeLinecap="round" transform="rotate(-90 28 28)"
                      style={{ transition: 'stroke-dasharray 0.9s linear, stroke 0.3s' }} />
                    <text x="28" y="33" textAnchor="middle"
                      fill={actionTimer <= 5 ? '#ef4444' : actionTimer <= 10 ? '#f97316' : '#22c55e'}
                      fontSize="16" fontWeight="bold">{actionTimer}</text>
                  </svg>
                </div>
                <Button onClick={() => processAction("fold")} disabled={processing}
                  className="bg-red-700 hover:bg-red-600 text-white font-black px-5 h-9">Fold</Button>
                {callAmount === 0
                  ? <Button onClick={() => processAction("check")} disabled={processing}
                      className="bg-blue-700 hover:bg-blue-600 text-white font-black px-5 h-9">Check</Button>
                  : <Button onClick={() => processAction("call", callAmount)} disabled={processing}
                      className="bg-blue-700 hover:bg-blue-600 text-white font-black px-5 h-9">Call {callAmount}</Button>
                }
                <div className="flex items-center gap-1.5 bg-white/5 rounded-xl px-2 py-1 border border-white/10">
                  <span className="text-white/50 text-xs">Raise:</span>
                  <Slider min={gameState.bigBlind} max={humanPlayer?.chips ?? gameState.bigBlind}
                    step={gameState.bigBlind} value={[raiseAmount]}
                    onValueChange={([v]) => setRaiseAmount(v)} className="w-20" />
                  <span className="text-yellow-400 font-black text-xs w-8 text-right">{raiseAmount}</span>
                  <Button onClick={() => processAction("raise", raiseAmount)} disabled={processing}
                    className="bg-yellow-600 hover:bg-yellow-500 text-black font-black px-2 h-8 text-xs">Raise</Button>
                </div>
                <Button onClick={() => processAction("raise", humanPlayer?.chips ?? 0)} disabled={processing}
                  className="bg-gradient-to-r from-orange-600 to-red-600 hover:from-orange-500 hover:to-red-500 text-white font-black px-3 h-9 text-sm">
                  All-In 🔥
                </Button>
                {humanPlayer && (() => {
                  const r = evaluateHand(humanPlayer.holeCards, gameState.communityCards);
                  return (r.rank !== "High Card" || gameState.communityCards.length > 0)
                    ? <span className="text-white/40 text-xs">Hand: <span className="text-yellow-400 font-bold">{r.rank}</span></span>
                    : null;
                })()}
              </div>
            </div>
          ) : (
            <div className="flex items-center justify-center gap-3 py-1">
              <p className="text-white/40 text-sm">
                {gameState.players[gameState.currentPlayerIndex]?.name} is thinking...
              </p>
              {aiStuckSeconds >= 20 && (
                <Button
                  onClick={skipAiPlayer}
                  size="sm"
                  className="bg-orange-600 hover:bg-orange-500 text-white font-black text-xs px-3 h-7 animate-pulse"
                >
                  ⏭ Skip Player ({aiStuckSeconds}s)
                </Button>
              )}
            </div>
          )}
        </div>
      )}

      {/* Showdown overlay */}
      {gameState?.phase === "showdown" && (
        <div className="fixed bottom-24 left-1/2 -translate-x-1/2 z-30 bg-black/90 border border-yellow-500/40 rounded-2xl px-6 py-4 text-center shadow-[0_0_40px_rgba(234,179,8,0.3)] w-72">
          <div className="text-3xl mb-1">{gameState.winners.includes("human") ? "🎉" : "😔"}</div>
          <h3 className="text-white font-black text-lg mb-1">
            {gameState.winners.includes("human") ? "You Win!" : "Better luck next time!"}
          </h3>
          {gameState.players.filter(p => p.isWinner).map(w => (
            <p key={w.id} className="text-yellow-400 text-sm">{w.name}: {w.handResult?.rank}</p>
          ))}
          <div className="flex gap-2 mt-3 justify-center">
            <Button onClick={newHand} className="bg-green-600 hover:bg-green-500 text-white font-black gap-1">
              <RotateCcw className="w-3 h-3" /> Next Hand
            </Button>
            <Button asChild variant="outline" className="border-white/20 text-white/70 hover:bg-white/10">
              <Link href="/game-room">Exit</Link>
            </Button>
          </div>
        </div>
      )}

      {showBuyIn && <BuyInModal onStart={startGame} maxCredits={account?.credits ?? 500} />}
    </div>
  );
}
