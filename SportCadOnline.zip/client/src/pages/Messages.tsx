import { useState, useEffect, useRef } from "react";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { MessageSquare, Send } from "lucide-react";
import { toast } from "sonner";

export default function Messages() {
  const { isAuthenticated, user } = useAuth();
  const [activeConversation, setActiveConversation] = useState<string | null>(null);
  const [newMessage, setNewMessage] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const { data: conversations } = trpc.messages.myConversations.useQuery(undefined, { enabled: isAuthenticated });
  const { data: messages, refetch } = trpc.messages.getConversation.useQuery(
    { conversationId: activeConversation! },
    { enabled: !!activeConversation, refetchInterval: 5000 }
  );
  const sendMessage = trpc.messages.send.useMutation({
    onSuccess: () => { setNewMessage(""); refetch(); },
    onError: (e) => toast.error(e.message),
  });

  useEffect(() => { messagesEndRef.current?.scrollIntoView({ behavior: "smooth" }); }, [messages]);

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-[#0a1628] flex items-center justify-center">
        <div className="text-center space-y-4">
          <MessageSquare className="w-16 h-16 text-white/20 mx-auto" />
          <h2 className="text-2xl font-bold text-white">Sign In to View Messages</h2>
          <a href={getLoginUrl()} className="inline-block bg-[#C41E3A] hover:bg-[#a01830] text-white px-6 py-2 rounded-lg font-medium transition-colors">Sign In</a>
        </div>
      </div>
    );
  }

  const handleSend = () => {
    if (!newMessage.trim() || !activeConversation) return;
    const conv = conversations?.find(c => c.conversationId === activeConversation);
    if (!conv) return;
    sendMessage.mutate({ conversationId: activeConversation, receiverEmail: conv.otherEmail, messageText: newMessage.trim() });
  };

  const activeConv = conversations?.find(c => c.conversationId === activeConversation);

  return (
    <div className="min-h-screen bg-[#0a1628] pb-20">
      {/* Header */}
      <div className="bg-[#0d1f3c] border-b border-white/10 py-4">
        <div className="max-w-5xl mx-auto px-4">
          <h1 className="text-2xl font-bold text-white flex items-center gap-2" style={{ fontFamily: "Oswald, sans-serif" }}>
            <MessageSquare className="w-6 h-6 text-[#C41E3A]" /> Messages
          </h1>
          <p className="text-white/50 text-sm">Trade negotiations, buyer/seller communication</p>
        </div>
      </div>

      <div className="max-w-5xl mx-auto px-4 py-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4" style={{ height: 580 }}>
          {/* Conversation list */}
          <div className="bg-[#0d1f3c] border border-white/10 rounded-xl overflow-hidden flex flex-col">
            <div className="p-3 border-b border-white/10 text-xs font-bold text-white/60 uppercase tracking-wide">
              Conversations ({conversations?.length ?? 0})
            </div>
            <div className="flex-1 overflow-y-auto">
              {!conversations || conversations.length === 0 ? (
                <div className="p-6 text-center text-white/30 text-sm">
                  <MessageSquare className="w-8 h-8 mx-auto mb-2 text-white/10" />
                  <p>No messages yet.</p>
                  <p className="text-xs mt-1">Start a trade to open a conversation.</p>
                </div>
              ) : conversations.map(conv => (
                <button
                  key={conv.conversationId}
                  onClick={() => setActiveConversation(conv.conversationId)}
                  className={`w-full text-left p-3 border-b border-white/5 hover:bg-white/5 transition-colors ${
                    activeConversation === conv.conversationId
                      ? "bg-[#C41E3A]/10 border-l-2 border-l-[#C41E3A]"
                      : ""
                  }`}
                >
                  <div className="flex items-center gap-2 mb-1">
                    <div className="w-7 h-7 rounded-full bg-[#C41E3A]/20 flex items-center justify-center text-xs text-[#C41E3A] font-bold flex-shrink-0">
                      {(conv.otherName ?? conv.otherEmail ?? "?")[0].toUpperCase()}
                    </div>
                    <div className="font-medium text-sm text-white truncate">{conv.otherName ?? conv.otherEmail}</div>
                  </div>
                  <div className="text-xs text-white/40 truncate pl-9">{conv.lastMessage}</div>
                  <div className="text-xs text-white/20 pl-9">{new Date(conv.lastMessageTime).toLocaleDateString()}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Message thread */}
          <div className="md:col-span-2 bg-[#0d1f3c] border border-white/10 rounded-xl flex flex-col overflow-hidden">
            {activeConversation ? (
              <>
                {/* Thread header */}
                <div className="p-3 border-b border-white/10 flex items-center gap-3 bg-white/5">
                  <div className="w-8 h-8 rounded-full bg-[#C41E3A]/20 flex items-center justify-center text-sm text-[#C41E3A] font-bold">
                    {(activeConv?.otherName ?? activeConv?.otherEmail ?? "?")[0].toUpperCase()}
                  </div>
                  <div>
                    <p className="font-semibold text-sm text-white">{activeConv?.otherName ?? activeConv?.otherEmail}</p>
                    <p className="text-xs text-white/40">{activeConv?.otherEmail}</p>
                  </div>
                </div>

                {/* Messages */}
                <div className="flex-1 overflow-y-auto p-4 space-y-3">
                  {messages?.map(msg => {
                    const isMe = msg.senderEmail === user?.email;
                    return (
                      <div key={msg.id} className={`flex ${isMe ? "justify-end" : "justify-start"}`}>
                        <div className={`max-w-[75%] rounded-2xl px-4 py-2 text-sm ${
                          isMe
                            ? "bg-[#C41E3A] text-white rounded-br-sm"
                            : "bg-white/10 text-white rounded-bl-sm"
                        }`}>
                          <p>{msg.messageText}</p>
                          <p className={`text-xs mt-1 ${isMe ? "text-white/60" : "text-white/40"}`}>
                            {new Date(msg.createdAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                          </p>
                        </div>
                      </div>
                    );
                  })}
                  <div ref={messagesEndRef} />
                </div>

                {/* Input */}
                <div className="p-3 border-t border-white/10 flex gap-2">
                  <Input
                    value={newMessage}
                    onChange={e => setNewMessage(e.target.value)}
                    placeholder="Type a message..."
                    onKeyDown={e => e.key === "Enter" && handleSend()}
                    className="bg-white/5 border-white/10 text-white placeholder:text-white/30"
                  />
                  <Button onClick={handleSend} disabled={sendMessage.isPending || !newMessage.trim()} className="bg-[#C41E3A] hover:bg-[#a01830]">
                    <Send className="w-4 h-4" />
                  </Button>
                </div>
              </>
            ) : (
              <div className="flex-1 flex items-center justify-center">
                <div className="text-center text-white/30">
                  <MessageSquare className="w-12 h-12 mx-auto mb-3 text-white/10" />
                  <p>Select a conversation to start messaging</p>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
