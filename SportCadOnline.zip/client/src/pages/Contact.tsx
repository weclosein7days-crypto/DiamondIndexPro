import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { toast } from "sonner";
import { Mail, MessageSquare, MapPin, CheckCircle2, ChevronDown, AlertCircle } from "lucide-react";

const FAQ_ITEMS = [
  {
    q: "How does card grading work?",
    a: "Our AI-powered SCG grading system analyzes your card photos for centering, corners, edges, and surface quality. Simply photograph your card using our Grade Cards tool and receive an instant grade from 1-10.",
  },
  {
    q: "How long does shipping take?",
    a: "Most orders ship within 3 business days of purchase. Once shipped, delivery typically takes 3-7 business days depending on your location and the shipping method selected.",
  },
  {
    q: "Is my payment protected?",
    a: "Yes. All payments are held in SCO Escrow until you confirm receipt of your card. Funds are only released to the seller after you confirm delivery.",
  },
  {
    q: "How does the referral program work?",
    a: "Share your unique referral link. When someone signs up and subscribes to a plan, you earn 100% of their plan value in credits. You also earn 25% of plan value for second-level referrals.",
  },
];

const MESSAGE_MAX = 2000;

function FieldError({ msg }: { msg?: string }) {
  if (!msg) return null;
  return (
    <p className="flex items-center gap-1 text-xs mt-1" style={{ color: "#f87171" }}>
      <AlertCircle className="w-3 h-3 flex-shrink-0" />
      {msg}
    </p>
  );
}

export default function Contact() {
  const [form, setForm] = useState({ name: "", email: "", subject: "", message: "" });
  const [touched, setTouched] = useState({ name: false, email: false, subject: false, message: false });
  const [submitted, setSubmitted] = useState(false);
  const [openFaq, setOpenFaq] = useState<number | null>(null);

  // Validation helpers
  const errors = {
    name: touched.name && !form.name.trim() ? "Name is required." : undefined,
    email: !touched.email ? undefined : !form.email.trim() ? "Email is required." : !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email) ? "Enter a valid email address." : undefined,
    subject: touched.subject && !form.subject.trim() ? "Subject is required." : undefined,
    message: touched.message && !form.message.trim() ? "Message is required." : touched.message && form.message.trim().length < 10 ? "Message must be at least 10 characters." : undefined,
  };
  const hasErrors = Object.values(errors).some(Boolean);

  const submitMutation = trpc.contact.submit.useMutation({
    onSuccess: () => {
      setSubmitted(true);
      setForm({ name: "", email: "", subject: "", message: "" });
      setTouched({ name: false, email: false, subject: false, message: false });
    },
    onError: (err) => {
      toast.error("Failed to send message. Please try again.");
      console.error(err);
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Touch all fields to reveal errors
    setTouched({ name: true, email: true, subject: true, message: true });
    if (!form.name.trim() || !form.email.trim() || !form.subject.trim() || form.message.trim().length < 10) {
      toast.error("Please fix the errors before submitting.");
      return;
    }
    submitMutation.mutate(form);
  };

  const fieldBorder = (field: keyof typeof errors) =>
    errors[field] ? "1px solid #f87171" : touched[field] && form[field] ? "1px solid #22c55e" : "1px solid #1e3a5f";

  return (
    <div className="min-h-screen" style={{ background: "linear-gradient(135deg, #060e1a 0%, #0a1628 50%, #0d1f3c 100%)" }}>
      {/* Hero */}
      <div className="relative py-16 text-center overflow-hidden">
        <div className="absolute inset-0 opacity-10" style={{ backgroundImage: "radial-gradient(circle at 50% 50%, #C41E3A 0%, transparent 70%)" }} />
        <div className="relative z-10">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full text-sm font-semibold mb-4"
            style={{ background: "rgba(196,30,58,0.15)", border: "1px solid rgba(196,30,58,0.3)", color: "#f87171" }}>
            <Mail className="w-4 h-4" />
            Contact Us
          </div>
          <h1 className="text-4xl md:text-5xl font-black text-white mb-4">
            We're Here to <span style={{ color: "#C41E3A" }}>Help</span>
          </h1>
          <p className="text-lg max-w-xl mx-auto" style={{ color: "#94a3b8" }}>
            Questions about grading, trades, orders, or anything else? Send us a message and we'll get back to you within 24-48 hours.
          </p>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-4 pb-16">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">

          {/* Left: Contact Info */}
          <div className="space-y-6">
            <Card style={{ background: "#0d1f3c", border: "1px solid #1e3a5f" }}>
              <CardHeader>
                <CardTitle className="text-white text-lg">Get in Touch</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-start gap-3">
                  <div className="w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0"
                    style={{ background: "rgba(196,30,58,0.15)", border: "1px solid rgba(196,30,58,0.3)" }}>
                    <Mail className="w-4 h-4" style={{ color: "#C41E3A" }} />
                  </div>
                  <div>
                    <p className="text-white text-sm font-semibold">Email</p>
                    <p style={{ color: "#94a3b8", fontSize: "13px" }}>support@sportcardsonline.com</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0"
                    style={{ background: "rgba(196,30,58,0.15)", border: "1px solid rgba(196,30,58,0.3)" }}>
                    <MessageSquare className="w-4 h-4" style={{ color: "#C41E3A" }} />
                  </div>
                  <div>
                    <p className="text-white text-sm font-semibold">Response Time</p>
                    <p style={{ color: "#94a3b8", fontSize: "13px" }}>24-48 hours on business days</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0"
                    style={{ background: "rgba(196,30,58,0.15)", border: "1px solid rgba(196,30,58,0.3)" }}>
                    <MapPin className="w-4 h-4" style={{ color: "#C41E3A" }} />
                  </div>
                  <div>
                    <p className="text-white text-sm font-semibold">Location</p>
                    <p style={{ color: "#94a3b8", fontSize: "13px" }}>United States</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Quick FAQ */}
            <Card style={{ background: "#0d1f3c", border: "1px solid #1e3a5f" }}>
              <CardHeader>
                <CardTitle className="text-white text-lg">Quick Answers</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {FAQ_ITEMS.map((item, i) => (
                  <div key={i} className="rounded-lg overflow-hidden" style={{ border: "1px solid #1e3a5f" }}>
                    <button
                      className="w-full flex items-center justify-between px-3 py-2.5 text-left"
                      style={{ background: openFaq === i ? "rgba(196,30,58,0.1)" : "transparent" }}
                      onClick={() => setOpenFaq(openFaq === i ? null : i)}
                    >
                      <span className="text-white text-sm font-medium pr-2">{item.q}</span>
                      <ChevronDown
                        className="w-4 h-4 flex-shrink-0 transition-transform"
                        style={{ color: "#94a3b8", transform: openFaq === i ? "rotate(180deg)" : "rotate(0deg)" }}
                      />
                    </button>
                    {openFaq === i && (
                      <div className="px-3 pb-3">
                        <p style={{ color: "#94a3b8", fontSize: "13px", lineHeight: "1.5" }}>{item.a}</p>
                      </div>
                    )}
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>

          {/* Right: Contact Form */}
          <div className="lg:col-span-2">
            <Card style={{ background: "#0d1f3c", border: "1px solid #1e3a5f" }}>
              <CardHeader>
                <CardTitle className="text-white text-xl">Send Us a Message</CardTitle>
                <p style={{ color: "#94a3b8", fontSize: "14px" }}>
                  Fill out the form below and we'll get back to you as soon as possible.
                </p>
              </CardHeader>
              <CardContent>
                {submitted ? (
                  /* ── Success State ── */
                  <div className="text-center py-14 animate-in fade-in zoom-in duration-500">
                    <div className="w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-5"
                      style={{ background: "rgba(74,222,128,0.15)", border: "2px solid rgba(74,222,128,0.4)" }}>
                      <CheckCircle2 className="w-10 h-10" style={{ color: "#4ade80" }} />
                    </div>
                    <h3 className="text-white text-2xl font-bold mb-2">Message Sent!</h3>
                    <p style={{ color: "#94a3b8" }} className="mb-2 max-w-sm mx-auto">
                      Thanks for reaching out. We'll get back to you within 24-48 business hours.
                    </p>
                    <p style={{ color: "#64748b", fontSize: "13px" }} className="mb-8">
                      A confirmation email has been sent to your inbox.
                    </p>
                    <Button
                      onClick={() => setSubmitted(false)}
                      variant="outline"
                      className="gap-2"
                      style={{ borderColor: "#1e3a5f", color: "#94a3b8", background: "transparent" }}
                    >
                      <Mail className="w-4 h-4" />
                      Send Another Message
                    </Button>
                  </div>
                ) : (
                  <form onSubmit={handleSubmit} className="space-y-5" noValidate>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {/* Name */}
                      <div className="space-y-1">
                        <Label className="text-white text-sm">Your Name <span style={{ color: "#f87171" }}>*</span></Label>
                        <Input
                          value={form.name}
                          onChange={(e) => setForm({ ...form, name: e.target.value })}
                          onBlur={() => setTouched((t) => ({ ...t, name: true }))}
                          placeholder="John Smith"
                          style={{ background: "#060e1a", border: fieldBorder("name"), color: "white" }}
                          className="placeholder:text-slate-600 transition-colors"
                        />
                        <FieldError msg={errors.name} />
                      </div>
                      {/* Email */}
                      <div className="space-y-1">
                        <Label className="text-white text-sm">Email Address <span style={{ color: "#f87171" }}>*</span></Label>
                        <Input
                          type="email"
                          value={form.email}
                          onChange={(e) => setForm({ ...form, email: e.target.value })}
                          onBlur={() => setTouched((t) => ({ ...t, email: true }))}
                          placeholder="john@example.com"
                          style={{ background: "#060e1a", border: fieldBorder("email"), color: "white" }}
                          className="placeholder:text-slate-600 transition-colors"
                        />
                        <FieldError msg={errors.email} />
                      </div>
                    </div>

                    {/* Subject */}
                    <div className="space-y-1">
                      <Label className="text-white text-sm">Subject <span style={{ color: "#f87171" }}>*</span></Label>
                      <Input
                        value={form.subject}
                        onChange={(e) => setForm({ ...form, subject: e.target.value })}
                        onBlur={() => setTouched((t) => ({ ...t, subject: true }))}
                        placeholder="e.g. Question about my order, Grading dispute, Trade issue..."
                        style={{ background: "#060e1a", border: fieldBorder("subject"), color: "white" }}
                        className="placeholder:text-slate-600 transition-colors"
                      />
                      <FieldError msg={errors.subject} />
                    </div>

                    {/* Message */}
                    <div className="space-y-1">
                      <div className="flex items-center justify-between">
                        <Label className="text-white text-sm">Message <span style={{ color: "#f87171" }}>*</span></Label>
                        <span style={{ fontSize: "12px", color: form.message.length > MESSAGE_MAX * 0.9 ? "#f87171" : "#475569" }}>
                          {form.message.length} / {MESSAGE_MAX}
                        </span>
                      </div>
                      <Textarea
                        value={form.message}
                        onChange={(e) => {
                          if (e.target.value.length <= MESSAGE_MAX) setForm({ ...form, message: e.target.value });
                        }}
                        onBlur={() => setTouched((t) => ({ ...t, message: true }))}
                        placeholder="Describe your question or issue in detail. Include order numbers, card names, or other relevant information..."
                        rows={6}
                        style={{ background: "#060e1a", border: fieldBorder("message"), color: "white", resize: "vertical" }}
                        className="placeholder:text-slate-600 transition-colors"
                      />
                      <FieldError msg={errors.message} />
                    </div>

                    <div className="flex items-center justify-between pt-2">
                      <p style={{ color: "#475569", fontSize: "12px" }}>
                        * Required fields. We respond within 24-48 business hours.
                      </p>
                      <Button
                        type="submit"
                        disabled={submitMutation.isPending || hasErrors}
                        className="font-bold px-8 transition-all"
                        style={{
                          background: submitMutation.isPending || hasErrors ? "#7f1d2a" : "#C41E3A",
                          color: "white",
                          border: "none",
                          opacity: hasErrors ? 0.7 : 1,
                        }}
                      >
                        {submitMutation.isPending ? (
                          <span className="flex items-center gap-2">
                            <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                            Sending...
                          </span>
                        ) : (
                          <span className="flex items-center gap-2">
                            <Mail className="w-4 h-4" />
                            Send Message
                          </span>
                        )}
                      </Button>
                    </div>
                  </form>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
