import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Award, ShoppingBag, Pencil, Trash2, Plus, Tag, Printer } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { Link } from "wouter";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { LABEL_BACKGROUNDS, LABEL_BORDER_COLORS, buildPrintPage, type LabelBackground, type LabelBorderColor } from "@/components/SlabLabel";

export default function MyStore() {
  const { isAuthenticated } = useAuth();
  const { data: cards, isLoading, refetch } = trpc.cards.myCards.useQuery();
  const updateCard = trpc.cards.update.useMutation();
  const deleteCard = trpc.cards.delete.useMutation();
  const [editingPrice, setEditingPrice] = useState<{ id: number; price: string } | null>(null);
  const [selectedCards, setSelectedCards] = useState<number[]>([]);
  const [bulkLabelColor, setBulkLabelColor] = useState("dark");

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="max-w-md w-full mx-4">
          <CardContent className="p-8 text-center">
            <ShoppingBag className="w-16 h-16 text-primary mx-auto mb-4" />
            <h2 className="text-2xl font-bold mb-2">Sign In to Manage Your Store</h2>
            <Button size="lg" className="w-full" asChild><a href={getLoginUrl()}>Sign In</a></Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const handleUpdatePrice = async (id: number) => {
    if (!editingPrice) return;
    try {
      await updateCard.mutateAsync({ id, data: { price: editingPrice.price } });
      toast.success("Price updated!");
      setEditingPrice(null);
      refetch();
    } catch (e: any) { toast.error(e.message); }
  };

  const handleDelete = async (id: number) => {
    if (!confirm("Remove this card from your store?")) return;
    try {
      await deleteCard.mutateAsync({ id });
      toast.success("Card removed");
      refetch();
    } catch (e: any) { toast.error(e.message); }
  };

  const handleBulkLabelColor = async () => {
    for (const id of selectedCards) {
      await updateCard.mutateAsync({ id, data: { labelColor: bulkLabelColor } });
    }
    toast.success(`Label color updated for ${selectedCards.length} card(s)`);
    setSelectedCards([]);
    refetch();
  };
  const [printBg, setPrintBg] = useState<LabelBackground>("black-silk");
  const [printBorder, setPrintBorder] = useState<LabelBorderColor>("red");

  const handlePrintLabel = (card: any) => {
    const w = window.open("", "_blank");
    if (!w) return;
    const labelData = [{
      playerName: card.playerName ?? undefined,
      cardCompany: card.manufacturer ?? card.setName?.split(" ")[0] ?? undefined,
      year: card.year ?? undefined,
      setName: card.setName ?? undefined,
      cardNumber: card.cardNumber ?? undefined,
      overallGrade: card.aiGrade ? parseFloat(card.aiGrade) : undefined,
      gradeLabel: card.aiGradeLabel ?? undefined,
      centering: card.aiCentering ?? undefined,
      corners: card.aiCorners ?? undefined,
      edges: card.aiEdges ?? undefined,
      surface: card.aiSurface ?? undefined,
      certNumber: card.aiCertNumber ?? undefined,
      cardId: card.id,
      background: printBg,
      borderColor: printBorder,
    }];
    const html = buildPrintPage(labelData, window.location.origin);
    w.document.write(html);
    w.document.close();
  };

  const activeCards = cards?.filter(c => c.status === "active") || [];
  const draftCards = cards?.filter(c => c.status === "draft") || [];

  return (
    <div className="min-h-screen py-8">
      <div className="container">
        <div className="mb-8 flex items-center justify-between flex-wrap gap-4">
          <div>
            <h1 className="text-4xl font-bold mb-1 flex items-center gap-3" style={{ fontFamily: "Oswald, sans-serif" }}>
              <ShoppingBag className="w-9 h-9 text-primary" />My Store
            </h1>
            <p className="text-muted-foreground">{activeCards.length} active listings · {draftCards.length} drafts</p>
          </div>
          <div className="flex gap-3">
            {selectedCards.length > 0 && (
              <div className="flex items-center gap-2">
                <select value={bulkLabelColor} onChange={e => setBulkLabelColor(e.target.value)} className="border rounded px-2 py-1 text-sm bg-background">
                  {LABEL_BACKGROUNDS.map(b => <option key={b.value} value={b.value}>{b.label}</option>)}
                </select>
                <Button size="sm" onClick={handleBulkLabelColor} className="gap-1"><Tag className="w-3 h-3" />Apply Label Color ({selectedCards.length})</Button>
              </div>
            )}
            {/* Print label style pickers */}
            <div className="flex items-center gap-1.5">
              <select value={printBg} onChange={e => setPrintBg(e.target.value as LabelBackground)} className="border rounded px-2 py-1 text-xs bg-background" title="Label background">
                {LABEL_BACKGROUNDS.map(b => <option key={b.value} value={b.value}>{b.label}</option>)}
              </select>
              <select value={printBorder} onChange={e => setPrintBorder(e.target.value as LabelBorderColor)} className="border rounded px-2 py-1 text-xs bg-background" title="Border color">
                {LABEL_BORDER_COLORS.map(b => <option key={b.value} value={b.value}>{b.label} Border</option>)}
              </select>
            </div>
            <Button asChild><Link href="/collection"><Plus className="w-4 h-4 mr-2" />Add from Collection</Link></Button>
          </div>
        </div>

        {isLoading ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
            {Array.from({ length: 8 }).map((_, i) => <Card key={i} className="animate-pulse"><CardContent className="p-3"><div className="aspect-[3/4] bg-muted rounded mb-2" /><div className="h-4 bg-muted rounded" /></CardContent></Card>)}
          </div>
        ) : cards && cards.length > 0 ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
            {cards.map((card) => {
              const isSelected = selectedCards.includes(card.id);
              const labelBg = LABEL_BACKGROUNDS.find(b => b.value === (card.labelColor || "black-silk")) ?? LABEL_BACKGROUNDS[1];
              return (
                <Card key={card.id} className={`group transition-all cursor-pointer ${isSelected ? "ring-2 ring-primary" : "hover:border-primary/50"}`}
                  onClick={() => setSelectedCards(p => isSelected ? p.filter(id => id !== card.id) : [...p, card.id])}>
                  <CardContent className="p-3">
                    <div className="aspect-[3/4] bg-muted rounded-lg mb-2 overflow-hidden relative">
                      {card.frontImageUrl ? <img src={card.frontImageUrl} alt={card.title} className="w-full h-full object-cover" /> : <div className="w-full h-full flex items-center justify-center"><Award className="w-8 h-8 text-muted-foreground/50" /></div>}
                      <Badge variant={card.status === "active" ? "default" : card.status === "auction" ? "secondary" : "outline"} className="absolute top-2 left-2 text-xs capitalize">{card.status}</Badge>
                      {isSelected && <div className="absolute inset-0 bg-primary/20 flex items-center justify-center"><div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center text-white font-bold">✓</div></div>}
                    </div>
                    {/* SCG Slab Label Preview */}
                    {card.aiGrade && (
                      <div className="rounded text-center py-1 mb-2 text-xs font-bold" style={{ backgroundImage: `url('${labelBg.url}')`, backgroundSize: "cover", color: labelBg.textColor }}>
                        SCG {card.aiGradeLabel} {card.aiGrade}
                      </div>
                    )}
                    <h3 className="font-semibold text-xs mb-1 line-clamp-1">{card.title}</h3>
                    <p className="text-xs text-muted-foreground mb-2">{card.playerName}</p>
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-bold text-secondary">${parseFloat(card.price || "0").toFixed(2)}</span>
                    </div>
                    <div className="flex gap-1" onClick={e => e.stopPropagation()}>
                      <Dialog>
                        <DialogTrigger asChild>
                          <Button size="sm" variant="outline" className="flex-1 text-xs" onClick={() => setEditingPrice({ id: card.id, price: card.price || "" })}>
                            <Pencil className="w-3 h-3 mr-1" />Price
                          </Button>
                        </DialogTrigger>
                        <DialogContent>
                          <DialogHeader><DialogTitle>Update Price</DialogTitle></DialogHeader>
                          <Input type="number" step="0.01" value={editingPrice?.price || ""} onChange={e => setEditingPrice(p => p ? { ...p, price: e.target.value } : null)} placeholder="Price in USD" />
                          <Button onClick={() => handleUpdatePrice(card.id)}>Save Price</Button>
                        </DialogContent>
                      </Dialog>
                      <Button size="sm" variant="outline" className="text-xs gap-1" onClick={() => handlePrintLabel(card)}><Printer className="w-3 h-3" /></Button>
                      <Button size="sm" variant="ghost" className="text-xs text-red-400" onClick={() => handleDelete(card.id)}><Trash2 className="w-3 h-3" /></Button>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        ) : (
          <div className="text-center py-16">
            <ShoppingBag className="w-16 h-16 text-muted-foreground/50 mx-auto mb-4" />
            <h3 className="text-xl font-semibold mb-2">No cards in your store</h3>
            <p className="text-muted-foreground mb-4">Grade cards and add them to your store to start selling.</p>
            <div className="flex gap-3 justify-center">
              <Button asChild><Link href="/grade">Grade Cards</Link></Button>
              <Button variant="outline" asChild><Link href="/collection">My Collection</Link></Button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
