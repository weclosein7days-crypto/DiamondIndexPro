import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";

const TIER_COLORS: Record<string, string> = {
  bronze: "text-amber-600",
  silver: "text-gray-300",
  gold: "text-yellow-400",
  platinum: "text-slate-300",
  diamond: "text-cyan-300",
};

const TIER_BG: Record<string, string> = {
  bronze: "from-amber-900/40 to-amber-800/20 border-amber-700/40",
  silver: "from-gray-700/40 to-gray-600/20 border-gray-500/40",
  gold: "from-yellow-900/40 to-yellow-800/20 border-yellow-600/40",
  platinum: "from-slate-700/40 to-slate-600/20 border-slate-400/40",
  diamond: "from-cyan-900/40 to-cyan-800/20 border-cyan-500/40",
};

const ALL_TIERS = [
  {
    name: "bronze",
    label: "Bronze",
    emoji: "🥉",
    monthlyMin: 0,
    depositBonusPct: 0,
    weeklyBonus: 0,
    monthlyBonus: 0,
    tierReachBonus: 0,
    perks: ["25 free credits on signup", "Access to all free games"],
  },
  {
    name: "silver",
    label: "Silver",
    emoji: "🥈",
    monthlyMin: 50,
    depositBonusPct: 3,
    weeklyBonus: 5,
    monthlyBonus: 15,
    tierReachBonus: 10,
    perks: ["3% bonus on every deposit", "+5 credits weekly reward", "+15 credits monthly reward", "Silver badge on profile"],
  },
  {
    name: "gold",
    label: "Gold",
    emoji: "🥇",
    monthlyMin: 150,
    depositBonusPct: 5,
    weeklyBonus: 15,
    monthlyBonus: 40,
    tierReachBonus: 25,
    perks: ["5% bonus on every deposit", "+15 credits weekly reward", "+40 credits monthly reward", "Gold badge on profile", "Priority grading queue"],
  },
  {
    name: "platinum",
    label: "Platinum",
    emoji: "💎",
    monthlyMin: 400,
    depositBonusPct: 8,
    weeklyBonus: 40,
    monthlyBonus: 100,
    tierReachBonus: 75,
    perks: ["8% bonus on every deposit", "+40 credits weekly reward", "+100 credits monthly reward", "Platinum badge", "Free auction listing per week", "Dedicated support"],
  },
  {
    name: "diamond",
    label: "Diamond",
    emoji: "💠",
    monthlyMin: 1000,
    depositBonusPct: 12,
    weeklyBonus: 100,
    monthlyBonus: 300,
    tierReachBonus: 200,
    perks: ["12% bonus on every deposit", "+100 credits weekly reward", "+300 credits monthly reward", "Diamond badge", "2 free auction listings per week", "VIP support", "Early access to new features"],
  },
];

export default function LoyaltyProgram() {
  const { user, loading: authLoading } = useAuth();
  const { data: account, isLoading } = trpc.credits.myAccount.useQuery(undefined, {
    enabled: !!user,
  });

  if (authLoading || isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-2 border-yellow-400 border-t-transparent rounded-full" />
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center gap-6 text-center px-4">
        <div className="text-6xl">🏆</div>
        <h1 className="text-3xl font-bold text-yellow-400">SCO Loyalty Program</h1>
        <p className="text-gray-400 max-w-md">
          Earn bonus credits every time you deposit. The more you play, the more you earn. Five tiers — Bronze through Diamond.
        </p>
        <Button
          className="bg-yellow-500 hover:bg-yellow-400 text-black font-bold px-8 py-3 text-lg"
          onClick={() => (window.location.href = getLoginUrl("/loyalty"))}
        >
          Sign In to View Your Status
        </Button>
        <div className="grid grid-cols-2 md:grid-cols-5 gap-3 mt-8 w-full max-w-3xl">
          {ALL_TIERS.map((tier) => (
            <div
              key={tier.name}
              className={`rounded-xl border bg-gradient-to-b p-4 text-center ${TIER_BG[tier.name]}`}
            >
              <div className="text-3xl mb-1">{tier.emoji}</div>
              <div className={`font-bold text-sm ${TIER_COLORS[tier.name]}`}>{tier.label}</div>
              <div className="text-xs text-gray-400 mt-1">
                {tier.monthlyMin === 0 ? "Free" : `$${tier.monthlyMin}/mo`}
              </div>
              {tier.depositBonusPct > 0 && (
                <div className="text-xs text-green-400 mt-1">+{tier.depositBonusPct}% bonus</div>
              )}
            </div>
          ))}
        </div>
      </div>
    );
  }

  const loyalty = (account as any)?.loyaltyStatus;
  const currentTier = loyalty?.tier ?? "bronze";
  const tierConfig = ALL_TIERS.find((t) => t.name === currentTier) ?? ALL_TIERS[0];
  const nextTier = ALL_TIERS.find((t) => t.monthlyMin > tierConfig.monthlyMin);
  const monthlyDeposits = loyalty?.monthlyDeposits ?? 0;
  const weeklyDeposits = loyalty?.weeklyDeposits ?? 0;
  const progressToNext = loyalty?.progressToNext ?? 0;
  const totalBonusEarned = loyalty?.totalLoyaltyBonusEarned ?? 0;

  return (
    <div className="min-h-screen bg-background text-foreground">
      <div className="max-w-5xl mx-auto px-4 py-10">
        {/* Header */}
        <div className="text-center mb-10">
          <div className="text-5xl mb-3">{tierConfig.emoji}</div>
          <h1 className="text-3xl font-bold text-yellow-400">SCO Loyalty Program</h1>
          <p className="text-gray-400 mt-2">Earn bonus credits every time you deposit</p>
        </div>

        {/* Current Status Card */}
        <Card className={`mb-8 border bg-gradient-to-br ${TIER_BG[currentTier]}`}>
          <CardContent className="p-6">
            <div className="flex flex-col md:flex-row items-center gap-6">
              <div className="text-center">
                <div className="text-6xl mb-2">{tierConfig.emoji}</div>
                <Badge className={`text-sm font-bold px-3 py-1 ${TIER_COLORS[currentTier]} bg-black/30`}>
                  {tierConfig.label} Member
                </Badge>
              </div>
              <div className="flex-1 w-full">
                <div className="grid grid-cols-3 gap-4 mb-4">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-white">${monthlyDeposits.toFixed(0)}</div>
                    <div className="text-xs text-gray-400">This Month</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-white">${weeklyDeposits.toFixed(0)}</div>
                    <div className="text-xs text-gray-400">This Week</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-green-400">+{totalBonusEarned}</div>
                    <div className="text-xs text-gray-400">Bonus Credits Earned</div>
                  </div>
                </div>
                {nextTier ? (
                  <div>
                    <div className="flex justify-between text-xs text-gray-400 mb-1">
                      <span>{tierConfig.label}</span>
                      <span>{nextTier.emoji} {nextTier.label} at ${nextTier.monthlyMin}/mo</span>
                    </div>
                    <Progress value={progressToNext} className="h-3" />
                    <div className="text-xs text-gray-400 mt-1 text-right">
                      ${Math.max(0, nextTier.monthlyMin - monthlyDeposits).toFixed(0)} more this month to reach {nextTier.label}
                    </div>
                  </div>
                ) : (
                  <div className="text-center text-cyan-300 font-bold mt-2">
                    💠 You've reached the highest tier — Diamond!
                  </div>
                )}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Current Tier Perks */}
        <Card className="mb-8 border-yellow-700/30 bg-black/30">
          <CardHeader>
            <CardTitle className="text-yellow-400">Your {tierConfig.label} Perks</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {tierConfig.perks.map((perk, i) => (
                <div key={i} className="flex items-center gap-2 text-sm text-gray-200">
                  <span className="text-green-400">✓</span>
                  {perk}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* All Tiers Comparison */}
        <h2 className="text-xl font-bold text-white mb-4">All Loyalty Tiers</h2>
        <div className="grid grid-cols-1 md:grid-cols-5 gap-4 mb-10">
          {ALL_TIERS.map((tier) => {
            const isCurrentTier = tier.name === currentTier;
            return (
              <Card
                key={tier.name}
                className={`border bg-gradient-to-b ${TIER_BG[tier.name]} ${isCurrentTier ? "ring-2 ring-yellow-400" : ""}`}
              >
                <CardContent className="p-4 text-center">
                  <div className="text-3xl mb-2">{tier.emoji}</div>
                  <div className={`font-bold text-sm mb-1 ${TIER_COLORS[tier.name]}`}>{tier.label}</div>
                  {isCurrentTier && (
                    <Badge className="text-xs bg-yellow-500 text-black mb-2">Current</Badge>
                  )}
                  <div className="text-xs text-gray-400 mb-3">
                    {tier.monthlyMin === 0 ? "Free to start" : `$${tier.monthlyMin}+/month`}
                  </div>
                  <Separator className="mb-3 opacity-30" />
                  <div className="space-y-1 text-left">
                    {tier.depositBonusPct > 0 && (
                      <div className="text-xs text-green-400">+{tier.depositBonusPct}% per deposit</div>
                    )}
                    {tier.weeklyBonus > 0 && (
                      <div className="text-xs text-blue-400">+{tier.weeklyBonus} weekly credits</div>
                    )}
                    {tier.monthlyBonus > 0 && (
                      <div className="text-xs text-purple-400">+{tier.monthlyBonus} monthly credits</div>
                    )}
                    {tier.tierReachBonus > 0 && (
                      <div className="text-xs text-yellow-400">+{tier.tierReachBonus} on reaching tier</div>
                    )}
                    {tier.depositBonusPct === 0 && (
                      <div className="text-xs text-gray-500">Base tier — deposit to level up</div>
                    )}
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* How It Works */}
        <Card className="border-gray-700/40 bg-black/20">
          <CardHeader>
            <CardTitle className="text-white">How It Works</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-sm text-gray-300">
              <div>
                <div className="text-yellow-400 font-bold mb-2">1. Deposit Credits</div>
                <p>Purchase credits at the Bank or Game Room. Every dollar deposited counts toward your monthly total.</p>
              </div>
              <div>
                <div className="text-yellow-400 font-bold mb-2">2. Earn Bonuses</div>
                <p>Higher tiers earn a % bonus on every deposit, plus weekly and monthly threshold rewards automatically added to your account.</p>
              </div>
              <div>
                <div className="text-yellow-400 font-bold mb-2">3. Level Up</div>
                <p>Hit the monthly deposit threshold and your tier upgrades instantly — plus you get a one-time tier-up bonus. Tiers reset monthly.</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
