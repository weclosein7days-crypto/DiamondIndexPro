import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import { CartProvider } from "./contexts/CartContext";
import Home from "./pages/Home";
import CardTest from "./pages/CardTest";
import CardDetail from "./pages/CardDetail";
import CardProfile from "./pages/CardProfile";
import Auctions from "./pages/Auctions";
import AuctionDetail from "./pages/AuctionDetail";
import MyCollection from "./pages/MyCollection";
import HouseCollection from "./pages/HouseCollection";
import GradeCards from "./pages/GradeCards";
import Trades from "./pages/Trades";
import Orders from "./pages/Orders";
import Credits from "./pages/Credits";
import CreditRoom from "./pages/CreditRoom";
import GameRoom from "./pages/GameRoom";
import KidsCorner from "./pages/KidsCorner";
import KidsCornerParent from "./pages/KidsCornerParent";
import PokerTable from "./pages/PokerTable";
import PrizeShowcase from "./pages/PrizeShowcase";
import TournamentLobby from "./pages/TournamentLobby";
import Roulette from "./pages/Roulette";
import Blackjack from "./pages/Blackjack";
import SpinWheel from "./pages/SpinWheel";
import Messages from "./pages/Messages";
import Admin from "./pages/Admin";
import Dashboard from "./pages/Dashboard";
import Contact from "./pages/Contact";
import Referral from "./pages/Referral";
import LoyaltyProgram from "./pages/LoyaltyProgram";
import VaultRoom from "./pages/VaultRoom";
import Blog from "./pages/Blog";
import BlogPost from "./pages/BlogPost";
import ContentDashboard from "./pages/ContentDashboard";
import FlowCharts from "./pages/FlowCharts";
import HowItWorks from "./pages/HowItWorks";
import LiveCardSearch from "./pages/LiveCardSearch";
import WhyWeCollect from "./pages/WhyWeCollect";
import NavBar from "./components/NavBar";
import SportsTicker from "./components/SportsTicker";
import { MobileBottomNav } from "./components/MobileBottomNav";
import { CompsPanel, ValuesPanel } from "./components/CompsPanel";
import { useState } from "react";

function Router() {
  const [mobileCompsOpen, setMobileCompsOpen] = useState(false);
  const [mobileValuesOpen, setMobileValuesOpen] = useState(false);
  return (
    <div className="min-h-screen bg-background text-foreground">
      <NavBar />
      <main className="pt-14 lg:pb-8 pb-[74px]">
        <Switch>
          <Route path="/" component={Home} />
          {/* /arena redirects to home — the Arena IS the homepage */}
          <Route path="/arena">{() => { window.location.replace("/"); return null; }}</Route>
          <Route path="/arena/:id" component={CardDetail} />
          <Route path="/card/:id" component={CardProfile} />
          <Route path="/marketplace">{() => { window.location.replace("/"); return null; }}</Route>
          <Route path="/marketplace/:id">{({ id }: any) => { window.location.replace(`/arena/${id}`); return null; }}</Route>
          <Route path="/auctions" component={Auctions} />
          <Route path="/auctions/:id" component={AuctionDetail} />
          <Route path="/collection" component={HouseCollection} />
          <Route path="/my-collection" component={MyCollection} />
          <Route path="/store">{() => { window.location.replace("/collection"); return null; }}</Route>
          <Route path="/grade" component={GradeCards} />
          <Route path="/trades" component={Trades} />
          <Route path="/orders" component={Orders} />
          <Route path="/credits" component={CreditRoom} />
          <Route path="/credits-legacy" component={Credits} />
          <Route path="/game-room" component={GameRoom} />
          <Route path="/kids-corner" component={KidsCorner} />
          <Route path="/kids-corner/parent" component={KidsCornerParent} />
          <Route path="/game-room/poker" component={PokerTable} />
          <Route path="/game-room/showcase" component={PrizeShowcase} />
          <Route path="/game-room/tournaments" component={TournamentLobby} />
          <Route path="/game-room/roulette" component={Roulette} />
          <Route path="/game-room/blackjack" component={Blackjack} />
          <Route path="/game-room/spin" component={SpinWheel} />
          <Route path="/messages" component={Messages} />
          <Route path="/dashboard" component={Dashboard} />
          <Route path="/admin" component={Admin} />
          <Route path="/contact" component={Contact} />
          <Route path="/referral" component={Referral} />
          <Route path="/loyalty" component={LoyaltyProgram} />
          <Route path="/vault" component={VaultRoom} />
          <Route path="/blog" component={Blog} />
          <Route path="/blog/:slug" component={BlogPost} />
          <Route path="/content-dashboard" component={ContentDashboard} />
          <Route path="/card-test" component={CardTest} />
          <Route path="/flowcharts" component={FlowCharts} />
          <Route path="/how-it-works" component={HowItWorks} />
          <Route path="/find-cards" component={LiveCardSearch} />
          <Route path="/why-we-collect" component={WhyWeCollect} />
          <Route path="/404" component={NotFound} />
          <Route component={NotFound} />
        </Switch>
      </main>
      <SportsTicker />
      <MobileBottomNav
        onComps={() => setMobileCompsOpen(true)}
        onValues={() => setMobileValuesOpen(true)}
      />
      <CompsPanel open={mobileCompsOpen} onClose={() => setMobileCompsOpen(false)} />
      <ValuesPanel open={mobileValuesOpen} onClose={() => setMobileValuesOpen(false)} />
    </div>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="dark">
        <CartProvider>
          <TooltipProvider>
            <Toaster />
            <Router />
          </TooltipProvider>
        </CartProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
