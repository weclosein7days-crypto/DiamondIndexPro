/**
 * Tiered shipping fee rules — LOCKED
 *
 * Under $100  → $4.50  (USPS Ground Advantage, $100 insurance included)
 * $100–$500   → $7.00  (USPS Ground Advantage + declared value insurance)
 * $500+       → $14.95 (USPS Priority Mail + full declared value insurance)
 *
 * eBay dropship cards: always $0 (eBay seller ships, free shipping enforced at import)
 */
export function getShippingFee(cardPrice: number, isDropship = false): number {
  if (isDropship) return 0;
  if (cardPrice < 100) return 4.50;
  if (cardPrice < 500) return 7.00;
  return 14.95;
}

export function getShippingLabel(cardPrice: number, isDropship = false): string {
  if (isDropship) return "Free Shipping (eBay)";
  if (cardPrice < 100) return "USPS Ground Advantage ($100 insured)";
  if (cardPrice < 500) return "USPS Ground Advantage (insured)";
  return "USPS Priority Mail (fully insured)";
}
