# CardVault - Sports Cards Online Rebuild TODO

## Core Infrastructure
- [x] Install additional dependencies (framer-motion, recharts, shippo, stripe, etc.)
- [x] Migrate drizzle schema from zip
- [x] Run database migrations (43 tables created)
- [x] Migrate server/db.ts helpers
- [x] Migrate server/routers.ts (all tRPC procedures)
- [x] Migrate server router files (admin, affiliate, collection)
- [x] Migrate shared types and constants
- [x] Migrate server services (email, storage, marketPrice, ebayDropship, etc.)
- [x] Migrate server _core additions (env, etc.)
- [x] Copy documentation files (DESIGN_RULES, LOCKED_DECISIONS, PROJECT_LOG, POKER_SYSTEM_DESIGN)

## Frontend Components
- [x] Migrate index.css (global styles/theme)
- [x] Migrate App.tsx (routing)
- [x] Migrate NavBar component
- [x] Migrate Footer component
- [x] Migrate SportsTicker component
- [x] Migrate BettingTicker component
- [x] Migrate GameTimesTicker component
- [x] Migrate MobileBottomNav component
- [x] Migrate HeroSection component
- [x] Migrate CardCarousel component
- [x] Migrate CardPopup component
- [x] Migrate CardProfileDrawer component
- [x] Migrate CartDrawer component
- [x] Migrate CompsPanel component
- [x] Migrate AIChatBox component
- [x] Migrate DashboardLayout component
- [x] Migrate all other components
- [x] Migrate all UI components (shadcn)
- [x] Migrate contexts (CartContext, ThemeContext)
- [x] Migrate hooks

## Pages
- [x] Migrate Home page
- [x] Migrate Marketplace/Arena page
- [x] Migrate CardDetail page
- [x] Migrate CardProfile page
- [x] Migrate Auctions page
- [x] Migrate AuctionDetail page
- [x] Migrate HouseCollection page
- [x] Migrate MyCollection page
- [x] Migrate GradeCards page
- [x] Migrate Trades page
- [x] Migrate Orders page
- [x] Migrate CreditRoom/Credits pages
- [x] Migrate GameRoom page
- [x] Migrate PokerTable page
- [x] Migrate Roulette page
- [x] Migrate Blackjack page
- [x] Migrate SpinWheel page
- [x] Migrate TournamentLobby page
- [x] Migrate PrizeShowcase page
- [x] Migrate KidsCorner pages
- [x] Migrate Messages page
- [x] Migrate Dashboard page
- [x] Migrate Admin page
- [x] Migrate Contact page
- [x] Migrate Referral page
- [x] Migrate LoyaltyProgram page
- [x] Migrate VaultRoom page
- [x] Migrate Blog/BlogPost pages
- [x] Migrate ContentDashboard page
- [x] Migrate NotFound page

## Final Steps
- [x] Verify build compiles without TypeScript errors (0 errors)
- [x] Run tests (58 tests, 9 test files, all passing)
- [x] Save checkpoint

## Pending (Post-Launch)
- [ ] Add eBay API credentials (EBAY_CLIENT_ID, EBAY_CLIENT_SECRET) for card importing
- [ ] Add Shippo API key (SHIPPO_API_KEY) for shipping labels
- [ ] Add SMTP credentials for email notifications
- [ ] Claim Stripe sandbox at https://dashboard.stripe.com/claim_sandbox/YWNjdF8xVEpLQmpMS01vc2FMMVJvLDE3NzYxMjc0OTQv100ojHym3Xy

## Comparison Fixes
- [x] Kids Corner promo banner present on homepage top section
- [x] Remove athlete ranking cards section from Kids Corner (the grid showing Jordan #23, Clark #22, Ruth #3, Griffey #24, Bird #33, Magic #32, etc.)

## Kids Corner Redesign
- [x] Kids Corner: Cool login/signup flow for kids (username + avatar picker, no email required)
- [x] Kids Corner: Persistent header with scoreboard (level, XP bar, credits, streak)
- [x] Kids Corner: Right-side motivational level-up tracker (never disappears, shows what to do next)
- [x] Kids Corner: Arcade room layout - games in windowed frames (no full-screen takeover)
- [x] Kids Corner: Hover-to-preview game cards in arcade grid
- [x] Kids Corner: Remove all credit purchase / money UI from kids view
- [x] Kids Corner: PARENTS CORNER link in header → parent CRM dashboard
- [x] Parents Corner: View kid's activity, progress, credits balance
- [x] Parents Corner: How to add credits / reward hours for good behavior
- [x] Parents Corner: Manage rewards and level-up bonuses

## Spin Wheel & Kids Showcase
- [x] Redesign spin wheel segments: All-Star (10pts), TD (7pts), Field Goal (3pts), Free Throw (1pt), x2 Multiplier, Timeout/Tech/Foul/Injury (lose wager)
- [x] Add credit wager system (1-5 credits) before each spin with scaled payouts
- [x] Balance wheel so it's fun and up-and-down (not a credit printer)
- [x] Build Kids Showcase: 100 house cards (H badge) kids can buy with credits
- [x] Cards claimed from showcase go to kid's collection display shelf
- [ ] Cards can later be traded between kids
- [ ] Track daily play time and questions answered for level-up progress

## Card Image Processing Pipeline
- [ ] Check PSA compliance rules already in codebase
- [ ] Build server-side image processor: auto-detect card/slab face, crop, add 1/8" border frame
- [ ] Fetch front AND back images from eBay listings where available
- [ ] Store processed images in S3 with front/back variants
- [ ] Auto-refresh logic: if eBay listing sold/image dead, find replacement automatically
- [ ] Apply PSA compliance rules: no shipping claims, no PSA branding violations

## Kids Corner Full Rebuild
- [x] Redesign spin wheel: sports segments (All-Star 10pts, TD 7pts, Field Goal 3pts, Free Throw 1pt, x2 Multiplier, Timeout/Tech/Foul/Injury lose wager), credit wager 1-5
- [x] Pull real card images from house cards DB + eBay for spin wheel faces
- [x] Build Kids Showcase: 100 house cards with real photos + H badge
- [x] Add player search in Kids Showcase
- [x] Wish List: kids pick up to 5 cards, syncs to Parents Corner
- [x] Parents Corner: shows kid wish list with real card photos, activity stats, credits, add-credits reward system

## Kids Trading & Play Timer
- [x] Kids-to-kids trade request flow: send/accept/decline trade offers for showcase cards
- [x] Trade DB schema: kidsTradeRequests table
- [x] Trade tRPC procedures: sendTradeRequest, acceptTrade, declineTrade, listMyTrades
- [x] Trade UI in KidsCorner: Trade button on owned cards, incoming/outgoing trade panel
- [x] Daily play-time tracker: server-side session start/end recording
- [x] 1-hour daily limit enforcement: lock Kids Corner after 60 min, show countdown timer
- [ ] Parent Zone: grant bonus hour button (adds 60 min to today's allowance)
- [ ] Parent Zone: view today's play time and session history
- [x] Play-time DB schema: kidsPlaySessions table

## Kids Games — Animations & Sound Effects
- [x] Heads or Tails: Maverick OR Caitlin physically flips the coin (they rotate turns), other watches + trash talks
- [x] Heads or Tails: 3D CSS coin flip animation, table surface, rolling landing
- [x] Heads or Tails: character dialogue (trash talk, hype, commiserate) based on outcome
- [x] Rock Paper Scissors: ALL THREE players throw simultaneously (kid + Maverick + Caitlin)
- [x] Rock Paper Scissors: animated hand gestures per player, countdown 3-2-1-Shoot!
- [x] Rock Paper Scissors: character trash talk and reactions based on who wins/loses
- [x] 3-Handed Go Fish: animated card dealing to all three players
- [x] 3-Handed Go Fish: Maverick + Caitlin as AI opponents with distinct personalities
- [x] 3-Handed Go Fish: ask-for-cards dialogue with character speech bubbles
- [x] 3-Handed Go Fish: Go Fish! reactions, book collection animation
- [x] Replace 'Roulette' with 'GAME TIME' in Kids Corner homepage banner text
- [x] Appie and Giffy: pre-seed named profiles with starter card collections on first login
- [x] Each kid gets unique starter pack: 5 cards from different sports on signup
- [x] Per-kid card collection persisted server-side (kidsCollection table) tied to kid profile
- [x] Card collection syncs between devices via DB (not just localStorage)
- [x] Trade UI: Appie can browse Giffy's collection and vice versa, send trade offers
- [x] Rewrite GAME TIME: correct War rules (1 card flip per turn, tie=3 blind+flip 4th, shot clock, 8-min timer)
- [x] GAME TIME: wager 1-5 credits, 52×wager payout to winner
- [x] GAME TIME: Maverick and Caitlin play as opponents with trash talk and reactions
- [x] GAME TIME: WAR tie scenario — both lay 3 more blind cards + 1 face-up
- [x] GAME TIME: 5-second shot clock, 8-minute timed game, most cards wins
- [x] Daily 25-credit bonus: auto-grant on first login each day
- [x] 1-hour daily play limit: timer counts down, locks Kids Corner after 60 min
- [x] Parent credit request: parents can request extra credits, auto-approved immediately
- [x] Add all games (GAME TIME, Go Fish, RPS, Heads/Tails, Trade Center) to KidsCorner arcade grid
- [ ] Sound effects: Web Audio API synthesized tones (coin clink, card deal, cheer, groan)

## Mascot Entrance & Exit Animations
- [x] Walk-on animation: Maverick and Caitlin walk onto screen when kid enters Kids Corner
- [x] Dynamic greeting based on time of day + school year calendar
- [x] School year greeting: "About time you got here! Did you get your schoolwork done?"
- [x] Weekend/summer greeting: "Hey {name}! Ready to play?"
- [x] Walk-off animation: characters wave goodbye when kid exits
- [x] Exit dialogue: "Bye {name}! We'll see you tomorrow!" as they walk off screen
- [x] MascotExitOverlay component: Maverick walks off left, Caitlin walks off right
- [x] Personalized farewell: rotating goodbye lines that include the kid's name
- [x] Exit overlay blocks the logout until animation completes (or skip button)
- [x] Greetings rotate so kid sees different ones each visit

## Parent-Side Kids Calendar System (scaffold now, data entry next session)
- [ ] DB schema: kidsCalendarEvents table (title, date, time, location, type, directions_url, kid_id)
- [ ] DB schema: kidsScheduleTodos table (task, due_date, completed, kid_id)
- [ ] ESPN-style ticker in Kids Corner: scrolls fav team scores + today's schedule items + special events
- [ ] Special event display: shows event name, time, location with directions link
- [ ] Directions link: Google Maps deep link based on event location address
- [ ] School level detection: ask kid their grade → determine middle vs high school
- [ ] Parent Zone: calendar event entry form (add/edit/delete events)
- [ ] Parent Zone: to-do list manager for kids
- [ ] Parent Zone: school selector (populate school address for directions)

## Educational Trivia System
- [x] Research Common Core K-8 learning standards for age-appropriate questions
- [x] Seed 75 sports-themed school questions (math, reading, science, history) by age group 6-7, 8-9, 10-11, 12-13 (DOB-based age calc)
- [x] Spaced repetition engine: wrong answers rephrase and re-queue 10 questions later
- [x] AI auto-generator: LLM creates new questions when bank runs low
- [x] 1-question-per-minute pop-up overlay in KidsCorner with animated sports reveal
- [x] Track per-kid question history, streaks, and mastery in DB
- [x] Parents Corner: learning stats panel (subjects mastered, accuracy rate, questions answered today)

## Kids Corner Mascot Integration
- [x] Upload custom mascot image (Maverick boy + Caitlin girl) to CDN
- [x] Build MascotCharacter component: Maverick + Caitlin with speech bubbles, bounce/wave/cheer animations
- [x] Login screen: both characters welcome the kid by name
- [x] Spin wheel: characters sit courtside, react to wins (jump up) and losses (head drop)
- [x] Trivia popup: one character hosts each question with a speech bubble
- [x] Card pull: both characters hype the reveal with excitement animation
- [x] Level-up: full celebration with both characters cheering
- [x] Idle state: characters sit on the scoreboard watching, occasionally wave
- [ ] Homepage Kids Corner banner: full mascot image with CTA overlay (next session)
- [x] Rock Paper Scissors: characters play along / react to outcome

## Card Import Rules & Auto-Flow (PRIORITY)
- [ ] Lock all rules into LOCKED_DECISIONS.md (H/E badge, status banners, auto-list, pricing)
- [ ] H badge (bottom-right corner): house/manual cards (isMainStore=true)
- [ ] E badge (bottom-right corner): eBay-sourced/dropship cards (isMainStore=false)
- [ ] Status banner overlays on card placeholder: AUCTION, LISTED, TRADE, SHIPPING, IN COLLECTION
- [ ] Auto-flow: any import (eBay, upload, grade) → lands in Collection first
- [ ] Auto-list from Collection → Marketplace (status = 'active') immediately on import
- [ ] Admin can reassign card status: listed, auction, traded, shipping, bank, casino, draft
- [ ] Run eBay import to populate database (all sports, $10 min, free shipping, 20% markup, s-l1600)
- [ ] Verify marketplace shows cards with H/E badges and status banners

## Server-Side Image Processor Pipeline
- [ ] Research PSA compliance rules (no shipping claims, no PSA logo misuse, etc.)
- [ ] Install sharp + canvas npm packages for server-side image processing
- [ ] Build card face detector: identify card/slab rectangle via edge detection
- [ ] Build crop engine: tight crop to card face with configurable padding
- [ ] Build frame engine: add 1/8-inch white border around cropped card
- [ ] Build eBay image fetcher: pull front + back images from eBay listing gallery
- [ ] Build PSA compliance filter: strip/flag images with shipping claims or violations
- [ ] Build S3 storage pipeline: save front_url and back_url per card
- [ ] Add tRPC procedures: processCardImage, processAllHouseCards, getProcessingStatus
- [ ] Add admin UI panel: trigger pipeline, show progress, preview before/after
- [ ] Write vitest tests for image processor

## Label Display Fixes
- [x] Reduce outer slab border from 10px to 5px
- [x] Reduce inner label border from 3px to 1.5px
- [x] Reduce player name font from 32px to 16px
- [x] Reduce brand/year/cert text from 13px to 7px
- [x] Reduce grade number from 44px to 22px
- [x] Reduce grade name from 10px to 5.5px
- [x] Reduce accent bar from 14px to 7px

## Game Room Fixes
- [ ] Responsive font size for long player names in SlabFrame (clamp-based scaling)
- [ ] Rename "War" game to kid-friendly name
- [ ] Add sound effects to all games (flip, win, lose, correct answer)
- [ ] Auto-fit all games in popup frames so no scrolling is needed

## Trivia & Game Room Overhaul
- [ ] Replace 8 stale trivia questions with 50+ age-specific questions (sports + pop culture, ages 6-8, 9-11, 12+)
- [ ] Replace brain icon on trivia with kid-friendly icon (lightning bolt or star)
- [ ] Neon arcade atmosphere: flashing lights, animated borders, arcade glow effects
- [ ] Animated "WHAT TO DO NEXT" turn guides for all games
- [ ] Go Fish: flash rank cards to pick, flash Appie/Giffy target, flash action button
- [ ] GameTime: auto-fit in popup, add sound effects, rename War to Card Battle
- [ ] Responsive font for long player names in SlabFrame

## Arcade Room Full Overhaul
- [ ] Rebuild game room as neon arcade with cabinet UI per game (glowing screen, marquee, coin slot)
- [ ] Add racing game with arrow key controls
- [ ] Add card-catching action game
- [ ] Fix all game popups to auto-fit (no scroll)
- [ ] Add sound to GameTime / Card Battle
- [ ] Overhaul trivia: 50+ age-specific questions, replace brain icon

## Kids Corner Game Room Fixes (Priority)
- [ ] Rename "War" / "GAME TIME" to "CARD BATTLE" everywhere in KidsCorner game title display
- [ ] Use real playing card visuals (suits ♠♥♦♣, ranks A/K/Q/J/10, face card art) in Card Battle and Go Fish
- [ ] Rebuild Kids Corner game selection grid as neon arcade cabinets (matching main Game Room style)
- [ ] Add sound effects to Card Battle (flip sound, win fanfare, lose sound)
- [ ] Fix game popups to auto-fit without scrolling (no min-h-screen)

## Admin Card Management
- [ ] Admin-only delete button on each marketplace card (only visible to admin role)
- [ ] Full edit modal for admin: edit grade, price, set, year, player name, status, badge, cert#
- [ ] Inline editing on admin panel card spreadsheet (click any cell to edit)

## Admin Card Management (Apr 7)
- [x] Admin-only delete button (pencil+trash on hover) on every marketplace card grid tile and list view
- [x] Full edit modal on marketplace card (admin only): grade, price, set, year, player name, sport, status, card#, manufacturer, description
- [x] Admin panel spreadsheet: click row opens CardProfileDrawer with full inline editing (already existed)
- [x] Backend: cards.update and cards.delete now allow admin role to bypass ownership check
- [x] eBay badge fix: all 541 ebay_import cards now show E badge (not H)
- [x] Card label condensed: height reduced from 22% to 13%, rows tighter, all font sizes preserved
- [x] PSA-style slab border: outer border reduced to 2px (was 5px), inner border 1px

## Kids Corner Game Replacements
- [ ] Replace Spin Wheel with Card Flip Memory Match using real house cards from DB
- [ ] Update Card Pull to reveal real cards from house inventory with animated reveal
- [ ] Surprise rack rip popup: every 100 game plays, show animated card pack rip with 1 real house card reveal

## Dispute Flow (Apr 8)
- [x] disputes table created in database schema
- [x] disputes router registered in server/routers.ts (openDispute, listDisputes, updateDisputeStatus)
- [x] Report a Problem button in Orders.tsx (buyer-facing, shows for paid/shipped/delivered orders)
- [x] ReportProblemModal with reason dropdown and description textarea
- [x] Order status changes to "disputed" when dispute is opened
- [x] Admin Disputes tab in Admin panel with status filter and resolution controls
- [x] Owner notification sent when new dispute is opened
- [x] 6 new vitest tests for dispute flow (64 total passing)
- [x] Fixed nested anchor tags in KidsCorner.tsx (Parents Corner link at lines 873 and 928)

## Admin Quick-Delete from Card Pages (Apr 8)
- [ ] Admin Delete button on AuctionDetail page (visible only to admin role)
- [ ] Admin Delete button on CardProfile page (visible only to admin role)
- [ ] Delete confirms with a dialog, then deletes card + redirects to previous page
- [ ] Works for both auction cards and marketplace cards

## Admin Quick-Delete from Card Pages (Apr 8) — COMPLETED
- [x] Admin Delete button on AuctionDetail page (visible only to admin role)
- [x] Admin Delete button on CardProfile page (visible only to admin role, in Owner Actions section)
- [x] Delete confirms with AlertDialog, then deletes card + redirects to previous page
- [x] AuctionDetail: cancels auction record + deletes card, redirects to /auctions
- [x] CardProfile: deletes card directly, redirects to /marketplace
- [x] auctions.adminDelete procedure added to server/routers.ts
- [x] All 64 tests still passing

## Auctions Bulk Delete (Apr 8) — COMPLETED
- [x] Admin-only checkboxes on each auction card in the Auctions grid
- [x] Select All / Deselect All toggle
- [x] Floating action bar appears when 1+ cards selected (shows count + Delete Selected button)
- [x] Bulk delete: cancel each auction + delete underlying card
- [x] auctions.adminBulkDelete tRPC procedure
- [x] Confirmation dialog before bulk delete

## Multi-task batch (Apr 8)
- [ ] Revert Kids Corner nav to plain text (remove Google-style colored letters)
- [ ] eBay card trade block: popup when E-badge card clicked in trade flow
- [ ] Bulk-delete checkboxes on Marketplace grid (admin only)
- [ ] Bulk-delete on House Collection (admin only)

## Nav + Trade + Marketplace Bulk Delete (Apr 8)
- [x] Restructure nav: Game Room + How It Works moved into Marketplace dropdown
- [x] Remove standalone Game Room tab and Info tab from top nav
- [x] Kids Corner last with Google-style colored letters
- [x] eBay card trade block: popup when E-badge card clicked in trade flow
- [x] Bulk-delete checkboxes on Marketplace grid (admin only)
- [x] House Collection bulk-delete already implemented (verified)

## House Collection Split + Label Colors (Apr 8)
- [ ] Split House Collection admin page into eBay tab and House tab
- [ ] Label color management on House tab: background + border color picker
- [ ] Apply label color to single card or bulk-select multiple cards
- [ ] Label colors carry through to marketplace, auction, card profile pages
- [ ] Label color choice available on print label dialog
- [ ] Lock all business rules as skills (eBay trade block, blurry card import filter, daily re-import, image URL check)

## Multi-task batch (Apr 8)
- [ ] Research free sports blog posting sites for daily auto-posting
- [ ] Set up daily auto-post of SCO blog posts to free sports sites
- [ ] Fix YouTube channel link in blog video player
- [ ] Create scanner/printer research PDF
- [ ] Build PSA replica label image (satirical)
- [ ] House Collection: eBay tab vs House tab split
- [ ] Label color management on House tab (bg + border, single + bulk)

## Smart Marketplace & Daily Report (Apr 8)
- [ ] Add 3rd row of cards to Marketplace display
- [ ] Smart Marketplace API: sport-weighted slots (25% WNBA, 25% NBA, 15% Football, 15% Baseball, 5% Hockey, 5% Soccer)
- [ ] WNBA cards pull from house inventory only (not eBay)
- [ ] $500 price cap on Marketplace display (higher-value cards searchable)
- [ ] Hot-player scoring based on news/market trends (auto-updated daily at 3am)
- [ ] Per-visitor personalization: track search history, show relevant cards on return
- [ ] Daily card rotation (fresh content each day, seeded by date)
- [ ] 3am daily operations report job
- [ ] Report covers: emails sent, marketplace rotations, cards added/deleted, eBay file changes, fund releases, search trend suggestions, to-do for the day
- [ ] Email report to weclosein@gmail.com with that day's date in subject line

## User Follow-Up Issues (Apr 8 evening)
- [ ] Add 3rd row (Smart Rotation / Today's Picks) to Home.tsx between UpAndComing and Showcase
- [ ] Apply sport-weighted % rules to main Marketplace card list (getActiveCards): 25% basketball, 15% football, 15% baseball, 5% hockey, 5% soccer, 10% other
- [ ] $500 cap on main Marketplace list (currently only on featured strip)
- [ ] Email credentials (SMTP_USER / SMTP_PASS) still not set — daily report job cannot run
- [ ] Daily 3am operations report job still not built (was in backlog)
- [ ] Printer/scanner research PDF still not built (was in backlog)

## Apr 8 Evening Fixes (completed)
- [x] Add 3rd row (Smart Rotation / Today's Picks) to Home.tsx between UpAndComing and Showcase
- [x] Apply sport-weighted % rules to main Marketplace card list (getActiveCards): 25% basketball, 15% football, 15% baseball, 5% hockey, 5% soccer, 10% other
- [x] $500 cap on main Marketplace list (currently only on featured strip)

## Apr 9 Sprint
- [ ] Preview Tags modal on Admin blog post row
- [ ] PDF daily orders report attached to 3am email
- [ ] YouTube OAuth secrets wired (YOUTUBE_CLIENT_ID, YOUTUBE_CLIENT_SECRET, YOUTUBE_REFRESH_TOKEN)

## Admin Panel Inventory Tabs
- [x] Add dedicated "🏠 House" tab to Admin panel — shows only house/SCO cards with search, sport, and status filters
- [x] Add dedicated "📦 eBay" tab to Admin panel — shows only eBay imported cards with source price and eBay item ID columns

## Why We Collect Page
- [x] Create WhyWeCollect.tsx page with Matt's family story, video embed, Chasing Cardboard credit, donation CTA
- [x] Add route /why-we-collect to App.tsx
- [x] Add centered "This is Why We Collect" hero button to HeroSection.tsx linking to /why-we-collect
