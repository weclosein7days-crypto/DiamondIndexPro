/**
 * Fetch real card images from eBay Browse API for Kids Showcase
 * 100 cards: 20 WNBA, 20 NBA, 20 NFL, 20 Baseball, 10 Soccer, 10 Hockey
 */
import * as dotenv from 'dotenv';
dotenv.config();

const CLIENT_ID = process.env.EBAY_CLIENT_ID;
const CLIENT_SECRET = process.env.EBAY_CLIENT_SECRET;

async function getEbayToken() {
  const credentials = Buffer.from(`${CLIENT_ID}:${CLIENT_SECRET}`).toString('base64');
  const resp = await fetch('https://api.ebay.com/identity/v1/oauth2/token', {
    method: 'POST',
    headers: {
      'Authorization': `Basic ${credentials}`,
      'Content-Type': 'application/x-www-form-urlencoded',
    },
    body: 'grant_type=client_credentials&scope=https://api.ebay.com/oauth/api_scope',
  });
  const data = await resp.json();
  return data.access_token;
}

async function searchCards(token, query, limit = 5) {
  const params = new URLSearchParams({
    q: query + ' sports card',
    category_ids: '212',  // Sports Trading Cards
    limit: String(limit),
    filter: 'conditions:{NEW|USED_EXCELLENT|USED_VERY_GOOD},itemLocationCountry:US',
    fieldgroups: 'STANDARD',
  });
  const resp = await fetch(`https://api.ebay.com/buy/browse/v1/item_summary/search?${params}`, {
    headers: {
      'Authorization': `Bearer ${token}`,
      'X-EBAY-C-MARKETPLACE-ID': 'EBAY_US',
      'Content-Type': 'application/json',
    },
  });
  const data = await resp.json();
  return data.itemSummaries || [];
}

const CARD_SEARCHES = {
  WNBA: [
    'Caitlin Clark WNBA rookie card',
    'Angel Reese WNBA rookie card',
    'Paige Bueckers WNBA card',
    'Breanna Stewart WNBA card',
    'A\'ja Wilson WNBA card',
    'Sabrina Ionescu WNBA card',
    'Diana Taurasi WNBA card',
    'Kelsey Plum WNBA card',
    'Zia Cooke WNBA card',
    'Aliyah Boston WNBA card',
    'Rhyne Howard WNBA card',
    'Arike Ogunbowale WNBA card',
    'Skylar Diggins WNBA card',
    'Jonquel Jones WNBA card',
    'Dearica Hamby WNBA card',
    'Napheesa Collier WNBA card',
    'Chelsea Gray WNBA card',
    'Jewell Loyd WNBA card',
    'Brittney Griner WNBA card',
    'Candace Parker WNBA card',
  ],
  NBA: [
    'LeBron James NBA card',
    'Stephen Curry NBA card',
    'Kevin Durant NBA card',
    'Giannis Antetokounmpo NBA card',
    'Luka Doncic NBA card',
    'Jayson Tatum NBA card',
    'Nikola Jokic NBA card',
    'Joel Embiid NBA card',
    'Zion Williamson NBA card',
    'Victor Wembanyama NBA rookie card',
    'Anthony Edwards NBA card',
    'Ja Morant NBA card',
    'Devin Booker NBA card',
    'Trae Young NBA card',
    'Tyler Herro NBA card',
    'Donovan Mitchell NBA card',
    'Damian Lillard NBA card',
    'Kawhi Leonard NBA card',
    'Paul George NBA card',
    'Scottie Barnes NBA card',
  ],
  NFL: [
    'Patrick Mahomes NFL card',
    'Josh Allen NFL card',
    'Lamar Jackson NFL card',
    'Justin Jefferson NFL card',
    'Tyreek Hill NFL card',
    'Davante Adams NFL card',
    'Travis Kelce NFL card',
    'Cooper Kupp NFL card',
    'Jalen Hurts NFL card',
    'Joe Burrow NFL card',
    'Justin Herbert NFL card',
    'Caleb Williams NFL rookie card',
    'Marvin Harrison Jr NFL rookie card',
    'CJ Stroud NFL card',
    'Brock Purdy NFL card',
    'Puka Nacua NFL card',
    'Ja\'Marr Chase NFL card',
    'Stefon Diggs NFL card',
    'Saquon Barkley NFL card',
    'Derrick Henry NFL card',
  ],
  Baseball: [
    'Mike Trout baseball card',
    'Shohei Ohtani baseball card',
    'Ronald Acuna Jr baseball card',
    'Juan Soto baseball card',
    'Mookie Betts baseball card',
    'Fernando Tatis Jr baseball card',
    'Julio Rodriguez baseball card',
    'Bobby Witt Jr baseball card',
    'Gunnar Henderson baseball card',
    'Jackson Holliday rookie baseball card',
    'Paul Skenes rookie baseball card',
    'Elly De La Cruz baseball card',
    'Yordan Alvarez baseball card',
    'Vladimir Guerrero Jr baseball card',
    'Pete Alonso baseball card',
    'Bryce Harper baseball card',
    'Freddie Freeman baseball card',
    'Nolan Arenado baseball card',
    'Aaron Judge baseball card',
    'Cody Bellinger baseball card',
  ],
  Soccer: [
    'Lionel Messi soccer card',
    'Cristiano Ronaldo soccer card',
    'Kylian Mbappe soccer card',
    'Erling Haaland soccer card',
    'Vinicius Jr soccer card',
    'Pedri soccer card',
    'Jude Bellingham soccer card',
    'Bukayo Saka soccer card',
    'Christian Pulisic soccer card',
    'Gio Reyna soccer card',
  ],
  Hockey: [
    'Connor McDavid hockey card',
    'Nathan MacKinnon hockey card',
    'Auston Matthews hockey card',
    'Leon Draisaitl hockey card',
    'Cale Makar hockey card',
    'Sidney Crosby hockey card',
    'Alex Ovechkin hockey card',
    'David Pastrnak hockey card',
    'Nikita Kucherov hockey card',
    'Jack Hughes hockey card',
  ],
};

async function main() {
  console.log('Getting eBay token...');
  const token = await getEbayToken();
  console.log('Token obtained. Fetching cards...\n');

  const allCards = [];
  
  for (const [sport, queries] of Object.entries(CARD_SEARCHES)) {
    console.log(`Fetching ${sport} cards (${queries.length} players)...`);
    for (const query of queries) {
      try {
        const items = await searchCards(token, query, 1);
        if (items.length > 0) {
          const item = items[0];
          const imageUrl = item.image?.imageUrl || item.thumbnailImages?.[0]?.imageUrl || '';
          if (imageUrl) {
            allCards.push({
              id: `house_${allCards.length + 1}`,
              name: item.title?.replace(/\s+/g, ' ').trim() || query,
              player: query.split(' ').slice(0, 2).join(' '),
              sport,
              imageUrl,
              price: item.price?.value ? parseFloat(item.price.value) : 0,
              ebayItemId: item.itemId,
              isHouseCard: true,
            });
            process.stdout.write('.');
          } else {
            process.stdout.write('x');
          }
        } else {
          process.stdout.write('-');
        }
        // Small delay to avoid rate limiting
        await new Promise(r => setTimeout(r, 200));
      } catch (e) {
        process.stdout.write('E');
      }
    }
    console.log(` (${allCards.filter(c => c.sport === sport).length} found)`);
  }

  console.log(`\nTotal cards found: ${allCards.length}`);
  
  // Write to a JSON file for use in the app
  import('fs').then(fs => {
    fs.writeFileSync('/home/ubuntu/cardvault/house_cards.json', JSON.stringify(allCards, null, 2));
    console.log('Saved to house_cards.json');
  });
}

main().catch(console.error);
