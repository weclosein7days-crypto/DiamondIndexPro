/**
 * Full eBay PSA 9/10 import for all 6 sports
 * - 15-20 players per sport
 * - Multiple card variations per player (base, prizm, refractor, auto, rookie, parallel)
 * - PSA 9 or PSA 10 only
 * - Front + back images where available
 * - $10 minimum after 20% markup
 * - Skips cards with other grading labels (BGS, SGC, etc.) to keep PSA-only
 */

import mysql from 'mysql2/promise';

const SPORTS_PLAYERS = {
  basketball: [
    "Victor Wembanyama", "Cooper Flagg", "LeBron James", "Stephen Curry",
    "Nikola Jokic", "Jayson Tatum", "Luka Doncic", "Giannis Antetokounmpo",
    "Kevin Durant", "Anthony Edwards", "Cade Cunningham", "Scottie Barnes",
    "Paolo Banchero", "Scoot Henderson", "Brandon Miller", "Zaccharie Risacher",
    "Alex Sarr", "Donovan Mitchell", "Tyrese Haliburton", "Shai Gilgeous-Alexander"
  ],
  wnba: [
    "Caitlin Clark", "Angel Reese", "Paige Bueckers", "A'ja Wilson",
    "Breanna Stewart", "Sabrina Ionescu", "Diana Taurasi", "Kelsey Plum",
    "Arike Ogunbowale", "Napheesa Collier", "Aliyah Boston", "Rhyne Howard",
    "Shakira Austin", "Kamilla Cardoso", "Kate Martin", "Rickea Jackson"
  ],
  baseball: [
    "Shohei Ohtani", "Paul Skenes", "Aaron Judge", "Elly De La Cruz",
    "James Wood", "Jackson Holliday", "Wyatt Langford", "Julio Rodriguez",
    "Ronald Acuna Jr", "Fernando Tatis Jr", "Juan Soto", "Gunnar Henderson",
    "Bobby Witt Jr", "Corbin Carroll", "Jackson Chourio", "Evan Carter",
    "Colton Cowser", "Yoshinobu Yamamoto", "Roki Sasaki", "Pete Crow-Armstrong"
  ],
  football: [
    "Cam Ward", "Ashton Jeanty", "Travis Hunter", "Patrick Mahomes",
    "Josh Allen", "Lamar Jackson", "Sauce Gardner", "Brock Purdy",
    "Caleb Williams", "Marvin Harrison Jr", "Malik Nabers", "Rome Odunze",
    "Brian Thomas Jr", "Bo Nix", "Drake Maye", "Jayden Daniels",
    "CJ Stroud", "Puka Nacua", "Jalen Hurts", "Joe Burrow"
  ],
  hockey: [
    "Connor McDavid", "Connor Bedard", "Sidney Crosby", "Auston Matthews",
    "Nathan MacKinnon", "Cale Makar", "Matvei Michkov", "Leo Carlsson",
    "Adam Fantilli", "Will Smith", "Gabe Perreault", "Macklin Celebrini",
    "David Reinbacher", "Brayden Yager", "Zach Benson", "Matthew Knies",
    "Logan Cooley", "Wyatt Johnston", "Shane Wright", "Juraj Slafkovsky"
  ],
  soccer: [
    "Lionel Messi", "Kylian Mbappe", "Jude Bellingham", "Lamine Yamal",
    "Erling Haaland", "Vinicius Jr", "Pedri", "Gavi",
    "Florian Wirtz", "Jamal Musiala", "Cavan Sullivan", "Christian Pulisic",
    "Gio Reyna", "Ricardo Pepi", "Folarin Balogun", "Yunus Musah",
    "Tyler Adams", "Weston McKennie", "Sergino Dest", "Brenden Aaronson"
  ]
};

const CARD_VARIATIONS = [
  "PSA 10 Prizm",
  "PSA 10 Rookie",
  "PSA 10 Refractor",
  "PSA 10 Auto",
  "PSA 10 Base",
  "PSA 9 Prizm",
  "PSA 9 Rookie",
  "PSA 9 Auto",
  "PSA 10 Silver Prizm",
  "PSA 10 Optic"
];

const SPORT_MAP = {
  basketball: 'basketball',
  wnba: 'basketball',
  baseball: 'baseball',
  football: 'football',
  hockey: 'hockey',
  soccer: 'soccer'
};

async function getEbayToken() {
  const clientId = process.env.EBAY_CLIENT_ID;
  const clientSecret = process.env.EBAY_CLIENT_SECRET;
  if (!clientId || !clientSecret) throw new Error('Missing eBay credentials');
  const creds = Buffer.from(`${clientId}:${clientSecret}`).toString('base64');
  const res = await fetch('https://api.ebay.com/identity/v1/oauth2/token', {
    method: 'POST',
    headers: {
      'Authorization': `Basic ${creds}`,
      'Content-Type': 'application/x-www-form-urlencoded'
    },
    body: 'grant_type=client_credentials&scope=https://api.ebay.com/oauth/api_scope'
  });
  const data = await res.json();
  if (!data.access_token) throw new Error(`eBay auth failed: ${JSON.stringify(data)}`);
  return data.access_token;
}

async function searchEbay(token, query, limit = 5) {
  const params = new URLSearchParams({
    q: query,
    limit: String(limit),
    filter: 'conditions:{USED},price:[10..5000],priceCurrency:USD',
    sort: 'price'
  });
  const res = await fetch(`https://api.ebay.com/buy/browse/v1/item_summary/search?${params}`, {
    headers: { 'Authorization': `Bearer ${token}`, 'X-EBAY-C-MARKETPLACE-ID': 'EBAY_US' }
  });
  if (!res.ok) return [];
  const data = await res.json();
  return data.itemSummaries || [];
}

async function getItemDetails(token, itemId) {
  try {
    const res = await fetch(`https://api.ebay.com/buy/browse/v1/item/${itemId}`, {
      headers: { 'Authorization': `Bearer ${token}`, 'X-EBAY-C-MARKETPLACE-ID': 'EBAY_US' }
    });
    if (!res.ok) return null;
    return await res.json();
  } catch { return null; }
}

function extractPlayerName(title) {
  // Try to extract player name from title
  const cleaned = title.replace(/PSA\s*\d+\.?\d*/gi, '').replace(/BGS|SGC|CSG|HGA/gi, '').trim();
  return cleaned.split(' ').slice(0, 3).join(' ');
}

function isValidPSACard(title) {
  const t = title.toUpperCase();
  // Must have PSA
  if (!t.includes('PSA')) return false;
  // Must be PSA 9 or PSA 10 (not PSA 8 or lower)
  const psaMatch = t.match(/PSA\s*(\d+\.?\d*)/);
  if (!psaMatch) return false;
  const grade = parseFloat(psaMatch[1]);
  if (grade < 9) return false;
  // Must NOT have other grading companies
  if (t.includes('BGS') || t.includes('SGC') || t.includes('CSG') || t.includes('HGA') || t.includes('BECKETT')) return false;
  return true;
}

function mapSport(sportKey) {
  return SPORT_MAP[sportKey] || 'basketball';
}

function getSportCategory(sportKey) {
  const cats = {
    basketball: 'NBA',
    wnba: 'WNBA',
    baseball: 'MLB',
    football: 'NFL',
    hockey: 'NHL',
    soccer: 'Soccer'
  };
  return cats[sportKey] || sportKey.toUpperCase();
}

async function sleep(ms) {
  return new Promise(r => setTimeout(r, ms));
}

async function main() {
  const conn = await mysql.createConnection(process.env.DATABASE_URL);
  const token = await getEbayToken();
  console.log('eBay token obtained');

  let totalInserted = 0;
  let totalSkipped = 0;

  for (const [sportKey, players] of Object.entries(SPORTS_PLAYERS)) {
    console.log(`\n=== ${sportKey.toUpperCase()} (${players.length} players) ===`);
    const sport = mapSport(sportKey);
    const category = getSportCategory(sportKey);

    for (const player of players) {
      // Search for 2-3 variations per player
      const queries = [
        `${player} PSA 10 rookie card`,
        `${player} PSA 10 prizm card`,
        `${player} PSA 9 auto card`
      ];

      for (const query of queries) {
        try {
          const items = await searchEbay(token, query, 3);
          await sleep(200);

          for (const item of items) {
            const title = item.title || '';
            if (!isValidPSACard(title)) { totalSkipped++; continue; }

            const rawPrice = parseFloat(item.price?.value || '0');
            if (!rawPrice) { totalSkipped++; continue; }

            const markedUpPrice = rawPrice * 1.20;
            if (markedUpPrice < 10) { totalSkipped++; continue; }

            // Get front image
            const frontImageUrl = item.image?.imageUrl || item.thumbnailImages?.[0]?.imageUrl || null;
            if (!frontImageUrl) { totalSkipped++; continue; }

            // Try to get back image from item details
            let backImageUrl = null;
            let extraImages = [];
            if (item.itemId) {
              const details = await getItemDetails(token, item.itemId);
              await sleep(150);
              if (details?.additionalImages?.length > 0) {
                backImageUrl = details.additionalImages[0]?.imageUrl || null;
                extraImages = details.additionalImages.slice(1, 4).map(i => i.imageUrl).filter(Boolean);
              }
            }

            // Extract grade from title
            const gradeMatch = title.match(/PSA\s*(\d+\.?\d*)/i);
            const grade = gradeMatch ? gradeMatch[1] : '9';

            // Extract year from title
            const yearMatch = title.match(/\b(19|20)\d{2}\b/);
            const year = yearMatch ? yearMatch[0] : new Date().getFullYear().toString();

            // Extract set name
            const setPatterns = ['Prizm', 'Optic', 'Topps Chrome', 'Bowman Chrome', 'Select', 'Mosaic', 'Contenders', 'Donruss', 'Panini', 'Upper Deck', 'O-Pee-Chee', 'Finest'];
            let setName = category + ' Cards';
            for (const pat of setPatterns) {
              if (title.toLowerCase().includes(pat.toLowerCase())) {
                setName = `${year} ${pat}`;
                break;
              }
            }

            // Check for duplicate (same title + sport)
            const [existing] = await conn.execute(
              'SELECT id FROM cards WHERE title = ? AND sport = ? LIMIT 1',
              [title.substring(0, 255), sport]
            );
            if (existing.length > 0) { totalSkipped++; continue; }

            await conn.execute(
              `INSERT INTO cards (
                title, playerName, sport, price, frontImageUrl, backImageUrl, extraImageUrls,
                sellerEmail, storeName, status, isMainStore, source, sourcePrice,
                aiGrade, aiGradeLabel, year, setName, condition, labelColor, createdAt, updatedAt
              ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())`,
              [
                title.substring(0, 255),
                player,
                sport,
                markedUpPrice.toFixed(2),
                frontImageUrl,
                backImageUrl,
                extraImages.length > 0 ? JSON.stringify(extraImages) : null,
                'sco@sportcardsonline.com',
                'SCO House',
                'active',
                false,  // sourced, not main store
                'ebay_import',
                rawPrice.toFixed(2),
                grade,
                grade === '10' ? 'GEM MINT' : 'MINT',
                year,
                setName,
                'graded',
                'dark',
              ]
            );
            totalInserted++;
            console.log(`  ✓ ${player} — ${title.substring(0, 60)} — $${markedUpPrice.toFixed(2)}`);
          }
        } catch (err) {
          console.warn(`  ✗ Error for "${query}": ${err.message}`);
        }
        await sleep(300);
      }
    }
  }

  await conn.end();
  console.log(`\n=== DONE ===`);
  console.log(`Inserted: ${totalInserted}`);
  console.log(`Skipped:  ${totalSkipped}`);
}

main().catch(console.error);
