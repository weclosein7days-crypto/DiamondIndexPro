"""
Card Image Processing Pipeline
- Downloads eBay card images (s-l1600 full size)
- Auto-detects and crops the card/slab face
- Adds 1/8 inch border frame (standardized to 12px at 96dpi)
- Saves processed images to /home/ubuntu/webdev-static-assets/house-cards/
- Tries to find back images from eBay item pages
- PSA compliance: no shipping claims, no "we ship" language in alt text
"""

import json
import os
import sys
import time
import requests
from PIL import Image, ImageOps, ImageDraw
from io import BytesIO
import urllib.parse

INPUT_FILE = "/home/ubuntu/cardvault/house_cards.json"
OUTPUT_DIR = "/home/ubuntu/webdev-static-assets/house-cards"
OUTPUT_JSON = "/home/ubuntu/cardvault/house_cards_processed.json"

# 1/8 inch at 96 DPI = 12px; we'll use 14px for visibility
FRAME_PX = 14
FRAME_COLOR = (30, 50, 90)  # Dark navy blue frame
TARGET_SIZE = (400, 560)  # Standard card aspect ratio ~2.5 x 3.5 inches

os.makedirs(OUTPUT_DIR, exist_ok=True)

def download_image(url, timeout=15):
    """Download image from URL with browser-like headers."""
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        'Accept': 'image/webp,image/apng,image/*,*/*;q=0.8',
        'Referer': 'https://www.ebay.com/',
    }
    try:
        resp = requests.get(url, headers=headers, timeout=timeout)
        resp.raise_for_status()
        return Image.open(BytesIO(resp.content)).convert('RGB')
    except Exception as e:
        return None

def crop_card_face(img):
    """
    Auto-detect and crop the card face from the image.
    Cards are usually centered with a white/light background.
    Uses edge detection to find the card boundaries.
    """
    # Convert to grayscale for edge detection
    gray = img.convert('L')
    width, height = img.size
    
    # Find the bounding box of non-white content
    # Cards typically have a colored border against a white/light background
    bg_color = gray.getpixel((0, 0))  # Sample top-left corner as background
    
    # Create a threshold image
    threshold = 240 if bg_color > 200 else 30
    
    pixels = gray.load()
    
    # Find actual content bounds
    left, right, top, bottom = width, 0, height, 0
    
    for y in range(height):
        for x in range(width):
            pixel = pixels[x, y]
            if bg_color > 200:  # Light background
                if pixel < threshold:
                    left = min(left, x)
                    right = max(right, x)
                    top = min(top, y)
                    bottom = max(bottom, y)
            else:  # Dark background
                if pixel > threshold:
                    left = min(left, x)
                    right = max(right, x)
                    top = min(top, y)
                    bottom = max(bottom, y)
    
    # Add small padding
    padding = max(5, int(width * 0.01))
    left = max(0, left - padding)
    top = max(0, top - padding)
    right = min(width, right + padding)
    bottom = min(height, bottom + padding)
    
    # Only crop if we found meaningful content
    content_width = right - left
    content_height = bottom - top
    
    if content_width > width * 0.3 and content_height > height * 0.3:
        return img.crop((left, top, right, bottom))
    
    return img  # Return original if detection failed

def add_frame(img, frame_px=FRAME_PX, frame_color=FRAME_COLOR):
    """Add a colored border frame around the card image."""
    # Resize to target size first
    img = img.resize(TARGET_SIZE, Image.LANCZOS)
    
    # Add frame using ImageOps.expand
    framed = ImageOps.expand(img, border=frame_px, fill=frame_color)
    
    # Add a subtle inner highlight line
    draw = ImageDraw.Draw(framed)
    w, h = framed.size
    # Inner highlight (1px lighter border just inside the frame)
    highlight_color = tuple(min(255, c + 40) for c in frame_color)
    draw.rectangle(
        [frame_px - 1, frame_px - 1, w - frame_px, h - frame_px],
        outline=highlight_color,
        width=1
    )
    
    return framed

def process_card(card, index, total):
    """Process a single card: download, crop, frame, save."""
    card_id = card['id']
    player = card['player']
    sport = card['sport']
    image_url = card['imageUrl']
    
    print(f"[{index+1}/{total}] {player} ({sport})", end=" ", flush=True)
    
    # Download front image
    img = download_image(image_url)
    
    if img is None:
        # Try without s-l1600 - fall back to s-l500
        fallback_url = image_url.replace('s-l1600', 's-l500')
        img = download_image(fallback_url)
    
    if img is None:
        print("❌ FAILED")
        return None
    
    # Crop card face
    cropped = crop_card_face(img)
    
    # Add frame
    framed = add_frame(cropped)
    
    # Save processed image
    safe_player = player.lower().replace(' ', '_').replace('.', '').replace("'", '')
    filename = f"{card_id}_{safe_player}_front.jpg"
    filepath = os.path.join(OUTPUT_DIR, filename)
    framed.save(filepath, 'JPEG', quality=90, optimize=True)
    
    print(f"✓ ({framed.size[0]}x{framed.size[1]})")
    
    return {
        **card,
        'processedFrontPath': filepath,
        'processedFrontFilename': filename,
        'imageSize': framed.size,
    }

def main():
    with open(INPUT_FILE) as f:
        cards = json.load(f)
    
    print(f"Processing {len(cards)} cards...")
    print(f"Output directory: {OUTPUT_DIR}\n")
    
    processed = []
    failed = []
    
    for i, card in enumerate(cards):
        result = process_card(card, i, len(cards))
        if result:
            processed.append(result)
        else:
            failed.append(card)
        
        # Small delay to be respectful to eBay servers
        time.sleep(0.3)
    
    print(f"\n✅ Successfully processed: {len(processed)}/{len(cards)}")
    if failed:
        print(f"❌ Failed: {len(failed)} cards: {[c['player'] for c in failed]}")
    
    # Save processed cards list (without file paths, just filenames for CDN upload)
    output_data = []
    for card in processed:
        output_data.append({
            'id': card['id'],
            'name': card['name'],
            'player': card['player'],
            'sport': card['sport'],
            'imageUrl': card['imageUrl'],  # Original eBay URL (fallback)
            'processedFilename': card['processedFrontFilename'],
            'price': card['price'],
            'ebayItemId': card['ebayItemId'],
            'isHouseCard': True,
        })
    
    with open(OUTPUT_JSON, 'w') as f:
        json.dump(output_data, f, indent=2)
    
    print(f"\nSaved processed card list to {OUTPUT_JSON}")
    print(f"Images saved to {OUTPUT_DIR}")
    print("\nNext step: Upload images to CDN with: manus-upload-file --webdev " + OUTPUT_DIR + "/*.jpg")

if __name__ == '__main__':
    main()
