/*
 * Diamond Index™ — Platform Showcase Page
 * Highlights: Grading Flow · 3D Viewer · Label System · Certification
 * Aesthetic: Financial authority — dark navy, white, gold accents
 */

import { useEffect, useRef, useState } from "react";
import { Link } from "wouter";

// ── Label images (uploaded to storage) ────────────────────────────────────────
const LABEL_5 = "/manus-storage/DI-front-label-5diamonds_fa73ea4a.png";
const LABEL_3 = "/manus-storage/DI-front-label-3diamonds_729cf5d6.png";
const LABEL_1 = "/manus-storage/DI-front-label-1diamond_3f532ff1.png";

// ── Grading steps data ────────────────────────────────────────────────────────
const GRADING_STEPS = [
  {
    step: "01",
    title: "Capture",
    desc: "Frame your card in the live viewfinder. The system captures a high-resolution image for analysis.",
    icon: "📷",
  },
  {
    step: "02",
    title: "Analyze",
    desc: "AI evaluates Centering, Edges, Surface, Corners, and Eye Appeal across 7 sub-criteria each.",
    icon: "🔬",
  },
  {
    step: "03",
    title: "Score",
    desc: "A numeric score and 1–5 diamond tier are calculated using the VRC-7 standard methodology.",
    icon: "💎",
  },
  {
    step: "04",
    title: "Certify",
    desc: "A unique Cert ID and QR code are generated. Your card is registered in the Diamond Index™ registry.",
    icon: "✦",
  },
];

// ── Category scores for the animated breakdown demo ───────────────────────────
const CATEGORIES = [
  { name: "Centering", score: 9.4, weight: "25%" },
  { name: "Edges", score: 9.1, weight: "20%" },
  { name: "Surface", score: 9.6, weight: "25%" },
  { name: "Corners", score: 9.3, weight: "20%" },
  { name: "Eye Appeal", score: 9.5, weight: "10%" },
];

// ── Animated score bar ─────────────────────────────────────────────────────────
function ScoreBar({ score, delay = 0 }: { score: number; delay?: number }) {
  const [width, setWidth] = useState(0);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setTimeout(() => setWidth((score / 10) * 100), delay);
          observer.disconnect();
        }
      },
      { threshold: 0.3 }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, [score, delay]);

  return (
    <div ref={ref} className="h-1.5 bg-white/10 rounded-full overflow-hidden">
      <div
        className="h-full rounded-full transition-all duration-1000 ease-out"
        style={{
          width: `${width}%`,
          background: "linear-gradient(90deg, #C9A84C, #F0D080)",
        }}
      />
    </div>
  );
}

// ── Diamond dots ───────────────────────────────────────────────────────────────
function DiamondDots({ count }: { count: number }) {
  return (
    <div className="flex gap-1">
      {[1, 2, 3, 4, 5].map((i) => (
        <span
          key={i}
          style={{
            display: "inline-block",
            width: 10,
            height: 10,
            background: i <= count ? "#C9A84C" : "rgba(255,255,255,0.15)",
            clipPath: "polygon(50% 0%, 100% 50%, 50% 100%, 0% 50%)",
          }}
        />
      ))}
    </div>
  );
}

// ── Fade-in on scroll ──────────────────────────────────────────────────────────
function FadeIn({
  children,
  delay = 0,
  className = "",
}: {
  children: React.ReactNode;
  delay?: number;
  className?: string;
}) {
  const [visible, setVisible] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setTimeout(() => setVisible(true), delay);
          observer.disconnect();
        }
      },
      { threshold: 0.15 }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, [delay]);

  return (
    <div
      ref={ref}
      className={className}
      style={{
        opacity: visible ? 1 : 0,
        transform: visible ? "translateY(0)" : "translateY(24px)",
        transition: "opacity 0.8s ease, transform 0.8s ease",
      }}
    >
      {children}
    </div>
  );
}

// ── Label carousel ─────────────────────────────────────────────────────────────
const LABELS = [
  { src: LABEL_5, grade: "5 Diamonds", tier: "PRISTINE" },
  { src: LABEL_3, grade: "3 Diamonds", tier: "EXCELLENT" },
  { src: LABEL_1, grade: "1 Diamond", tier: "GOOD" },
];

function LabelCarousel() {
  const [active, setActive] = useState(0);

  useEffect(() => {
    const t = setInterval(() => setActive((p) => (p + 1) % LABELS.length), 3200);
    return () => clearInterval(t);
  }, []);

  return (
    <div className="relative w-full max-w-2xl mx-auto">
      {LABELS.map((l, i) => (
        <div
          key={i}
          style={{
            position: i === 0 ? "relative" : "absolute",
            top: 0,
            left: 0,
            width: "100%",
            opacity: active === i ? 1 : 0,
            transition: "opacity 0.9s ease",
            pointerEvents: active === i ? "auto" : "none",
          }}
        >
          <img
            src={l.src}
            alt={l.grade}
            className="w-full rounded-lg"
            style={{ boxShadow: "0 8px 48px rgba(0,0,0,0.5)" }}
          />
          <div className="mt-3 flex items-center justify-between px-2">
            <span style={{ color: "#C9A84C", fontSize: 13, letterSpacing: 2 }}>
              {l.tier}
            </span>
            <DiamondDots count={LABELS.length - i + (i === 2 ? -2 : i === 1 ? -1 : 0)} />
            <span style={{ color: "rgba(255,255,255,0.5)", fontSize: 13 }}>
              {l.grade}
            </span>
          </div>
        </div>
      ))}
      {/* dot nav */}
      <div className="flex justify-center gap-2 mt-6">
        {LABELS.map((_, i) => (
          <button
            key={i}
            onClick={() => setActive(i)}
            style={{
              width: active === i ? 24 : 8,
              height: 8,
              borderRadius: 4,
              background: active === i ? "#C9A84C" : "rgba(255,255,255,0.2)",
              border: "none",
              cursor: "pointer",
              transition: "all 0.3s ease",
            }}
          />
        ))}
      </div>
    </div>
  );
}

// ── Main page ──────────────────────────────────────────────────────────────────
export default function Showcase() {
  return (
    <div style={{ background: "#060d1e", color: "#fff", minHeight: "100vh", fontFamily: "'Inter', sans-serif" }}>

      {/* ── Nav ── */}
      <nav style={{
        position: "sticky", top: 0, zIndex: 50,
        background: "rgba(6,13,30,0.92)", backdropFilter: "blur(12px)",
        borderBottom: "1px solid rgba(255,255,255,0.06)",
        padding: "0 2rem",
        display: "flex", alignItems: "center", justifyContent: "space-between",
        height: 64,
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <div style={{
            width: 32, height: 32,
            background: "linear-gradient(135deg, #1a3a6b, #0a163c)",
            clipPath: "polygon(50% 0%, 100% 50%, 50% 100%, 0% 50%)",
            display: "flex", alignItems: "center", justifyContent: "center",
            border: "1.5px solid rgba(201,168,76,0.6)",
          }}>
            <span style={{ fontSize: 11, fontWeight: 700, color: "#C9A84C" }}>DI</span>
          </div>
          <span style={{ fontWeight: 700, fontSize: 15, letterSpacing: 1 }}>Diamond Index™</span>
        </div>
        <div style={{ display: "flex", gap: 32, fontSize: 13, color: "rgba(255,255,255,0.65)" }}>
          <a href="#grading" style={{ color: "inherit", textDecoration: "none" }}>Grading</a>
          <a href="#labels" style={{ color: "inherit", textDecoration: "none" }}>Labels</a>
          <a href="#breakdown" style={{ color: "inherit", textDecoration: "none" }}>Breakdown</a>
          <a href="#verify" style={{ color: "inherit", textDecoration: "none" }}>Verify</a>
        </div>
        <Link href="/">
          <span style={{
            padding: "8px 20px", borderRadius: 6, fontSize: 13, fontWeight: 600, cursor: "pointer",
            background: "linear-gradient(135deg, #C9A84C, #a07830)",
            color: "#fff", textDecoration: "none",
          }}>
            Open Platform →
          </span>
        </Link>
      </nav>

      {/* ── Hero ── */}
      <section style={{
        minHeight: "92vh", display: "flex", flexDirection: "column",
        alignItems: "center", justifyContent: "center",
        textAlign: "center", padding: "6rem 2rem 4rem",
        background: "radial-gradient(ellipse 80% 60% at 50% 0%, rgba(26,58,107,0.4) 0%, transparent 70%)",
      }}>
        <FadeIn>
          <div style={{
            display: "inline-block", padding: "4px 16px", borderRadius: 20,
            border: "1px solid rgba(201,168,76,0.4)",
            color: "#C9A84C", fontSize: 12, letterSpacing: 3, marginBottom: 28,
          }}>
            VRC-7 CERTIFIED GRADING STANDARD
          </div>
        </FadeIn>

        <FadeIn delay={100}>
          <h1 style={{
            fontSize: "clamp(2.8rem, 7vw, 5.5rem)", fontWeight: 800,
            lineHeight: 1.05, letterSpacing: -1, marginBottom: 24,
            background: "linear-gradient(135deg, #ffffff 0%, rgba(255,255,255,0.7) 100%)",
            WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent",
          }}>
            Diamond Index™
          </h1>
        </FadeIn>

        <FadeIn delay={200}>
          <p style={{ fontSize: "clamp(1.1rem, 2.5vw, 1.4rem)", color: "rgba(255,255,255,0.55)", maxWidth: 560, lineHeight: 1.6, marginBottom: 16 }}>
            Know What It's Worth — Instantly
          </p>
          <p style={{ fontSize: 15, color: "rgba(255,255,255,0.35)", maxWidth: 480, lineHeight: 1.7 }}>
            A smarter standard for card value. AI-powered grading, certified labels, and a public verification registry — built for collectors who take it seriously.
          </p>
        </FadeIn>

        {/* thin gold line */}
        <FadeIn delay={350}>
          <div style={{
            width: "min(480px, 80vw)", height: 1, margin: "40px auto",
            background: "linear-gradient(90deg, transparent, #C9A84C, transparent)",
          }} />
        </FadeIn>

        <FadeIn delay={400}>
          <div style={{ display: "flex", gap: 16, justifyContent: "center", flexWrap: "wrap" }}>
            <Link href="/grade">
              <span style={{
                padding: "14px 32px", borderRadius: 8, fontSize: 15, fontWeight: 600, cursor: "pointer",
                background: "linear-gradient(135deg, #C9A84C, #a07830)",
                color: "#fff", textDecoration: "none", display: "inline-block",
              }}>
                Grade a Card
              </span>
            </Link>
            <a href="#grading" style={{
              padding: "14px 32px", borderRadius: 8, fontSize: 15, fontWeight: 600, cursor: "pointer",
              border: "1px solid rgba(255,255,255,0.2)", color: "rgba(255,255,255,0.8)",
              textDecoration: "none", display: "inline-block",
            }}>
              See How It Works
            </a>
          </div>
        </FadeIn>

        {/* Stats row */}
        <FadeIn delay={550}>
          <div style={{
            display: "flex", gap: "clamp(24px, 5vw, 64px)", marginTop: 72,
            borderTop: "1px solid rgba(255,255,255,0.07)", paddingTop: 40,
            flexWrap: "wrap", justifyContent: "center",
          }}>
            {[
              { val: "5", label: "Diamond Tiers" },
              { val: "VRC-7", label: "Grading Standard" },
              { val: "5", label: "Grading Categories" },
              { val: "3D", label: "Slab Viewer" },
            ].map((s) => (
              <div key={s.label} style={{ textAlign: "center" }}>
                <div style={{ fontSize: "clamp(1.6rem, 4vw, 2.2rem)", fontWeight: 700, color: "#C9A84C" }}>{s.val}</div>
                <div style={{ fontSize: 12, color: "rgba(255,255,255,0.4)", letterSpacing: 1, marginTop: 4 }}>{s.label}</div>
              </div>
            ))}
          </div>
        </FadeIn>
      </section>

      {/* ── Grading Flow ── */}
      <section id="grading" style={{ padding: "7rem 2rem", maxWidth: 1100, margin: "0 auto" }}>
        <FadeIn>
          <div style={{ textAlign: "center", marginBottom: 64 }}>
            <div style={{ color: "#C9A84C", fontSize: 11, letterSpacing: 4, marginBottom: 16 }}>THE PROCESS</div>
            <h2 style={{ fontSize: "clamp(1.8rem, 4vw, 2.8rem)", fontWeight: 700, marginBottom: 16 }}>
              From Card to Certified — in Seconds
            </h2>
            <p style={{ color: "rgba(255,255,255,0.45)", fontSize: 16, maxWidth: 500, margin: "0 auto" }}>
              The Diamond Index™ grading flow is methodical, transparent, and built on a published standard.
            </p>
          </div>
        </FadeIn>

        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))", gap: 24 }}>
          {GRADING_STEPS.map((s, i) => (
            <FadeIn key={s.step} delay={i * 100}>
              <div style={{
                background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.07)",
                borderRadius: 12, padding: "32px 28px",
                transition: "border-color 0.3s",
              }}
                onMouseEnter={(e) => (e.currentTarget.style.borderColor = "rgba(201,168,76,0.3)")}
                onMouseLeave={(e) => (e.currentTarget.style.borderColor = "rgba(255,255,255,0.07)")}
              >
                <div style={{ fontSize: 28, marginBottom: 16 }}>{s.icon}</div>
                <div style={{ color: "#C9A84C", fontSize: 11, letterSpacing: 3, marginBottom: 8 }}>STEP {s.step}</div>
                <div style={{ fontSize: 18, fontWeight: 700, marginBottom: 12 }}>{s.title}</div>
                <div style={{ color: "rgba(255,255,255,0.5)", fontSize: 14, lineHeight: 1.7 }}>{s.desc}</div>
              </div>
            </FadeIn>
          ))}
        </div>
      </section>

      {/* thin divider */}
      <div style={{ width: "60%", height: 1, margin: "0 auto", background: "linear-gradient(90deg, transparent, rgba(201,168,76,0.2), transparent)" }} />

      {/* ── Label System ── */}
      <section id="labels" style={{ padding: "7rem 2rem", maxWidth: 1100, margin: "0 auto" }}>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 64, alignItems: "center" }}>
          <FadeIn>
            <div>
              <div style={{ color: "#C9A84C", fontSize: 11, letterSpacing: 4, marginBottom: 16 }}>CERTIFICATION LABELS</div>
              <h2 style={{ fontSize: "clamp(1.8rem, 4vw, 2.6rem)", fontWeight: 700, marginBottom: 20, lineHeight: 1.2 }}>
                Five Tiers.<br />One Standard.
              </h2>
              <p style={{ color: "rgba(255,255,255,0.5)", fontSize: 15, lineHeight: 1.8, marginBottom: 32 }}>
                Every graded card receives a Diamond Index™ front label with a 1–5 diamond rating. The label is generated programmatically — cert ID, diamond count, and VRC-7 standard are embedded at grading time.
              </p>
              <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
                {[
                  { diamonds: 5, tier: "PRISTINE", desc: "Near-perfect condition. Exceptional in all categories." },
                  { diamonds: 4, tier: "ELITE", desc: "Outstanding condition with minimal wear." },
                  { diamonds: 3, tier: "EXCELLENT", desc: "Above average. Strong across all criteria." },
                  { diamonds: 2, tier: "GOOD", desc: "Solid condition with visible but minor flaws." },
                  { diamonds: 1, tier: "FAIR", desc: "Significant wear. Authenticated and certified." },
                ].map((t) => (
                  <div key={t.tier} style={{ display: "flex", alignItems: "center", gap: 16 }}>
                    <DiamondDots count={t.diamonds} />
                    <div>
                      <span style={{ color: "#C9A84C", fontSize: 12, fontWeight: 700, letterSpacing: 2 }}>{t.tier}</span>
                      <span style={{ color: "rgba(255,255,255,0.35)", fontSize: 12, marginLeft: 12 }}>{t.desc}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </FadeIn>

          <FadeIn delay={150}>
            <LabelCarousel />
          </FadeIn>
        </div>
      </section>

      {/* thin divider */}
      <div style={{ width: "60%", height: 1, margin: "0 auto", background: "linear-gradient(90deg, transparent, rgba(201,168,76,0.2), transparent)" }} />

      {/* ── Grading Breakdown ── */}
      <section id="breakdown" style={{ padding: "7rem 2rem", maxWidth: 1100, margin: "0 auto" }}>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 64, alignItems: "center" }}>
          {/* Score card */}
          <FadeIn>
            <div style={{
              background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.08)",
              borderRadius: 16, padding: "40px 36px",
            }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 32 }}>
                <div>
                  <div style={{ fontSize: 11, letterSpacing: 3, color: "rgba(255,255,255,0.4)", marginBottom: 8 }}>FINAL SCORE</div>
                  <div style={{ fontSize: 56, fontWeight: 800, color: "#C9A84C", lineHeight: 1 }}>9.4</div>
                </div>
                <div style={{ textAlign: "right" }}>
                  <DiamondDots count={5} />
                  <div style={{ fontSize: 11, letterSpacing: 2, color: "rgba(255,255,255,0.4)", marginTop: 8 }}>PRISTINE</div>
                </div>
              </div>

              <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
                {CATEGORIES.map((c, i) => (
                  <div key={c.name}>
                    <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 8 }}>
                      <span style={{ fontSize: 13, color: "rgba(255,255,255,0.7)" }}>{c.name}</span>
                      <div style={{ display: "flex", gap: 12, alignItems: "center" }}>
                        <span style={{ fontSize: 11, color: "rgba(255,255,255,0.3)" }}>wt {c.weight}</span>
                        <span style={{ fontSize: 14, fontWeight: 700, color: "#C9A84C" }}>{c.score}</span>
                      </div>
                    </div>
                    <ScoreBar score={c.score} delay={i * 120} />
                  </div>
                ))}
              </div>

              <div style={{
                marginTop: 32, paddingTop: 24, borderTop: "1px solid rgba(255,255,255,0.06)",
                display: "flex", justifyContent: "space-between", alignItems: "center",
              }}>
                <div style={{ fontSize: 11, color: "rgba(255,255,255,0.3)", letterSpacing: 1 }}>CERT ID</div>
                <div style={{ fontSize: 13, color: "rgba(255,255,255,0.6)", fontFamily: "monospace" }}>DI-0618-2026A</div>
              </div>
            </div>
          </FadeIn>

          <FadeIn delay={150}>
            <div>
              <div style={{ color: "#C9A84C", fontSize: 11, letterSpacing: 4, marginBottom: 16 }}>GRADING BREAKDOWN</div>
              <h2 style={{ fontSize: "clamp(1.8rem, 4vw, 2.6rem)", fontWeight: 700, marginBottom: 20, lineHeight: 1.2 }}>
                Five Categories.<br />Transparent Scoring.
              </h2>
              <p style={{ color: "rgba(255,255,255,0.5)", fontSize: 15, lineHeight: 1.8, marginBottom: 32 }}>
                Every card is evaluated across five categories with defined sub-criteria and published weight percentages. No black box. No guessing. The VRC-7 standard is documented and consistent.
              </p>
              <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
                {[
                  { cat: "Centering", weight: "25%", note: "Front and back alignment" },
                  { cat: "Edges", weight: "20%", note: "Chipping, nicks, wear" },
                  { cat: "Surface", weight: "25%", note: "Scratches, print defects, stains" },
                  { cat: "Corners", weight: "20%", note: "Fraying, bends, rounding" },
                  { cat: "Eye Appeal", weight: "10%", note: "Overall visual impression" },
                ].map((c) => (
                  <div key={c.cat} style={{
                    display: "flex", justifyContent: "space-between", alignItems: "center",
                    padding: "12px 16px", borderRadius: 8,
                    background: "rgba(255,255,255,0.02)", border: "1px solid rgba(255,255,255,0.05)",
                  }}>
                    <div>
                      <div style={{ fontSize: 14, fontWeight: 600 }}>{c.cat}</div>
                      <div style={{ fontSize: 12, color: "rgba(255,255,255,0.35)", marginTop: 2 }}>{c.note}</div>
                    </div>
                    <div style={{ fontSize: 13, color: "#C9A84C", fontWeight: 700 }}>{c.weight}</div>
                  </div>
                ))}
              </div>
            </div>
          </FadeIn>
        </div>
      </section>

      {/* thin divider */}
      <div style={{ width: "60%", height: 1, margin: "0 auto", background: "linear-gradient(90deg, transparent, rgba(201,168,76,0.2), transparent)" }} />

      {/* ── 3D Viewer + Verify ── */}
      <section id="verify" style={{ padding: "7rem 2rem", maxWidth: 1100, margin: "0 auto" }}>
        <FadeIn>
          <div style={{ textAlign: "center", marginBottom: 64 }}>
            <div style={{ color: "#C9A84C", fontSize: 11, letterSpacing: 4, marginBottom: 16 }}>VERIFICATION SYSTEM</div>
            <h2 style={{ fontSize: "clamp(1.8rem, 4vw, 2.8rem)", fontWeight: 700, marginBottom: 16 }}>
              Scan. Verify. Trust.
            </h2>
            <p style={{ color: "rgba(255,255,255,0.45)", fontSize: 16, maxWidth: 500, margin: "0 auto" }}>
              Every Diamond Index™ label carries a QR code that links to a public verification page — showing the card, score, and certification status in real time.
            </p>
          </div>
        </FadeIn>

        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))", gap: 24 }}>
          {[
            {
              icon: "◈",
              title: "3D Slab Viewer",
              desc: "Every verified card features an interactive Three.js slab you can rotate in any direction. Gold trim, realistic reflections, card texture applied to the face.",
            },
            {
              icon: "⬡",
              title: "QR Verification",
              desc: "Self-hosted QR codes generated at grading time. No third-party APIs. Scan any Diamond Index™ label to reach the live verification page instantly.",
            },
            {
              icon: "✦",
              title: "Public Registry",
              desc: "Every cert ID is registered in the Diamond Index™ registry. Buyers can verify authenticity before purchase — building trust in every transaction.",
            },
          ].map((f, i) => (
            <FadeIn key={f.title} delay={i * 120}>
              <div style={{
                background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.07)",
                borderRadius: 12, padding: "36px 28px", height: "100%",
              }}
                onMouseEnter={(e) => (e.currentTarget.style.borderColor = "rgba(201,168,76,0.3)")}
                onMouseLeave={(e) => (e.currentTarget.style.borderColor = "rgba(255,255,255,0.07)")}
              >
                <div style={{ fontSize: 32, color: "#C9A84C", marginBottom: 20 }}>{f.icon}</div>
                <div style={{ fontSize: 18, fontWeight: 700, marginBottom: 12 }}>{f.title}</div>
                <div style={{ color: "rgba(255,255,255,0.5)", fontSize: 14, lineHeight: 1.8 }}>{f.desc}</div>
              </div>
            </FadeIn>
          ))}
        </div>
      </section>

      {/* ── CTA ── */}
      <section style={{
        padding: "7rem 2rem", textAlign: "center",
        background: "linear-gradient(180deg, transparent 0%, rgba(26,58,107,0.15) 100%)",
      }}>
        <FadeIn>
          <div style={{ color: "#C9A84C", fontSize: 11, letterSpacing: 4, marginBottom: 20 }}>GET STARTED</div>
          <h2 style={{ fontSize: "clamp(2rem, 5vw, 3.2rem)", fontWeight: 700, marginBottom: 20 }}>
            Ready to Grade Your Collection?
          </h2>
          <p style={{ color: "rgba(255,255,255,0.45)", fontSize: 16, maxWidth: 460, margin: "0 auto 40px" }}>
            The Diamond Index™ platform is live. Grade a card, get certified, and join the registry.
          </p>
          <div style={{ width: "min(320px, 80vw)", height: 1, margin: "0 auto 40px", background: "linear-gradient(90deg, transparent, #C9A84C, transparent)" }} />
          <Link href="/grade">
            <span style={{
              padding: "16px 40px", borderRadius: 8, fontSize: 16, fontWeight: 700, cursor: "pointer",
              background: "linear-gradient(135deg, #C9A84C, #a07830)",
              color: "#fff", textDecoration: "none", display: "inline-block",
              boxShadow: "0 8px 32px rgba(201,168,76,0.25)",
            }}>
              Grade a Card Now →
            </span>
          </Link>
        </FadeIn>
      </section>

      {/* ── Footer ── */}
      <footer style={{
        borderTop: "1px solid rgba(255,255,255,0.06)",
        padding: "32px 2rem",
        display: "flex", justifyContent: "space-between", alignItems: "center",
        flexWrap: "wrap", gap: 16,
        color: "rgba(255,255,255,0.3)", fontSize: 13,
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <div style={{
            width: 24, height: 24,
            background: "linear-gradient(135deg, #1a3a6b, #0a163c)",
            clipPath: "polygon(50% 0%, 100% 50%, 50% 100%, 0% 50%)",
            border: "1px solid rgba(201,168,76,0.4)",
          }} />
          <span>Diamond Index™ — VRC-7 Certified Grading</span>
        </div>
        <div style={{ display: "flex", gap: 24 }}>
          <Link href="/"><span style={{ color: "inherit", textDecoration: "none", cursor: "pointer" }}>Home</span></Link>
          <Link href="/grade"><span style={{ color: "inherit", textDecoration: "none", cursor: "pointer" }}>Grade</span></Link>
          <Link href="/vault"><span style={{ color: "inherit", textDecoration: "none", cursor: "pointer" }}>Vault</span></Link>
        </div>
      </footer>
    </div>
  );
}
