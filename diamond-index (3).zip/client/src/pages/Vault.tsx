/**
 * My Vault — Diamond Index™
 * Shows all graded cards for the logged-in user.
 * Each card has: front image, score, diamond rating, tier, date.
 * Clicking a card opens a detail modal with full breakdown + social share.
 */

import { useState, Suspense, lazy } from "react";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { DIAMOND_SINGLE } from "@/lib/diamondRating";

// Lazy-load the 3D slab to avoid blocking the vault page load
const CardSlab3D = lazy(() => import("@/components/CardSlab3D"));

const DARK = "#060d1e";
const GOLD = "#c9a84c";
const BLUE = "#1a3a6b";

// Tier color map
const TIER_COLORS: Record<string, string> = {
  PRISTINE: "#f0d060",
  ELITE: "#c9a84c",
  SUPERIOR: "#7eb8f7",
  PREMIUM: "#a0b4c8",
  STANDARD: "#6b7f94",
};

type Card = {
  id: number;
  cardName: string | null;
  cardSet: string | null;
  cardYear: string | null;
  cardNumber: string | null;
  manufacturer: string | null;
  frontImageKey: string | null;
  backImageKey: string | null;
  overallScore: string | null;
  diamondRating: number | null;
  gradeTier: string | null;
  centeringScore: string | null;
  edgesScore: string | null;
  cornersScore: string | null;
  surfaceScore: string | null;
  eyeAppealScore: string | null;
  status: "in_vault" | "sent_to_partner" | "slab_ordered" | string;
  certId: string | null;
  qrCodeUrl: string | null;
  slabFrontUrl?: string | null;
  slabBackUrl?: string | null;
  slabCompositeUrl?: string | null;
  createdAt: Date;
};

function statusLabel(status: string) {
  if (status === "sent_to_partner") return { label: "Sent to Partner", color: "#60a5fa" };
  if (status === "slab_ordered") return { label: "Slab Ordered", color: "#4ade80" };
  return { label: "In Vault", color: GOLD };
}

// ─── Diamond Row ─────────────────────────────────────────────────────────────

function DiamondRow({ rating, size = 18 }: { rating: number; size?: number }) {
  return (
    <div style={{ display: "flex", gap: "3px", alignItems: "center" }}>
      {Array.from({ length: 5 }, (_, i) => (
        <img
          key={i}
          src={DIAMOND_SINGLE}
          alt="◆"
          style={{
            width: size, height: size,
            opacity: i < rating ? 1 : 0.18,
            filter: i < rating ? "drop-shadow(0 0 4px rgba(201,168,76,0.6))" : "none",
          }}
        />
      ))}
    </div>
  );
}

// ─── Share Modal ──────────────────────────────────────────────────────────────

function ShareModal({ card, onClose }: { card: Card; onClose: () => void }) {
  const [copied, setCopied] = useState(false);
  const cardLabel = [card.cardYear, card.cardName, card.cardSet].filter(Boolean).join(" · ") || "Sports Card";
  const score = card.overallScore ? parseFloat(card.overallScore).toFixed(1) : "—";
  const tier = card.gradeTier ?? "GRADED";
  const diamonds = "◆".repeat(card.diamondRating ?? 0) + "◇".repeat(5 - (card.diamondRating ?? 0));
  const shareText = `Just had my ${cardLabel} graded by Diamond Index™ — ${score} | ${tier} ${diamonds} 🏆 Know what your cards are worth. #DiamondIndex #SportsCards #CardGrading`;
  const shareUrl = typeof window !== "undefined" ? window.location.origin + "/vault" : "https://diamondindex.com/vault";

  const twitterUrl = `https://twitter.com/intent/tweet?text=${encodeURIComponent(shareText)}&url=${encodeURIComponent(shareUrl)}`;
  const facebookUrl = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(shareUrl)}&quote=${encodeURIComponent(shareText)}`;

  const copyLink = () => {
    navigator.clipboard.writeText(`${shareText}\n${shareUrl}`).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };

  return (
    <div
      style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.75)", zIndex: 1000, display: "flex", alignItems: "center", justifyContent: "center", padding: "1rem" }}
      onClick={onClose}
    >
      <div
        style={{ background: "#0d1829", border: "1px solid rgba(201,168,76,0.25)", borderRadius: "12px", padding: "2rem", maxWidth: "420px", width: "100%", position: "relative" }}
        onClick={e => e.stopPropagation()}
      >
        <button onClick={onClose} style={{ position: "absolute", top: "1rem", right: "1rem", background: "none", border: "none", color: "rgba(255,255,255,0.5)", fontSize: "1.2rem", cursor: "pointer" }}>✕</button>

        <div style={{ fontFamily: "'Barlow Condensed', sans-serif", fontWeight: 700, fontSize: "0.65rem", letterSpacing: "0.2em", color: GOLD, textTransform: "uppercase", marginBottom: "0.5rem" }}>
          Share Your Grade
        </div>
        <div style={{ fontFamily: "'Barlow Condensed', sans-serif", fontWeight: 800, fontSize: "1.3rem", color: "#fff", marginBottom: "1.25rem" }}>
          {cardLabel}
        </div>

        {/* Preview text */}
        <div style={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)", borderRadius: "8px", padding: "0.875rem 1rem", marginBottom: "1.5rem", fontFamily: "'Barlow', sans-serif", fontSize: "0.82rem", color: "rgba(200,215,230,0.85)", lineHeight: 1.6 }}>
          {shareText}
        </div>

        {/* Share buttons */}
        <div style={{ display: "flex", flexDirection: "column", gap: "0.75rem" }}>
          <a
            href={twitterUrl}
            target="_blank"
            rel="noopener noreferrer"
            style={{ display: "flex", alignItems: "center", gap: "0.75rem", background: "#000", border: "1px solid rgba(255,255,255,0.15)", borderRadius: "6px", padding: "0.75rem 1.25rem", color: "#fff", textDecoration: "none", fontFamily: "'Barlow Condensed', sans-serif", fontWeight: 600, fontSize: "0.85rem", letterSpacing: "0.08em" }}
          >
            <span style={{ fontSize: "1.1rem" }}>𝕏</span>
            Share on X (Twitter)
          </a>
          <a
            href={facebookUrl}
            target="_blank"
            rel="noopener noreferrer"
            style={{ display: "flex", alignItems: "center", gap: "0.75rem", background: "#1877f2", borderRadius: "6px", padding: "0.75rem 1.25rem", color: "#fff", textDecoration: "none", fontFamily: "'Barlow Condensed', sans-serif", fontWeight: 600, fontSize: "0.85rem", letterSpacing: "0.08em" }}
          >
            <span>f</span>
            Share on Facebook
          </a>
          <button
            onClick={copyLink}
            style={{ display: "flex", alignItems: "center", gap: "0.75rem", background: copied ? "rgba(34,197,94,0.15)" : "rgba(255,255,255,0.07)", border: `1px solid ${copied ? "rgba(34,197,94,0.4)" : "rgba(255,255,255,0.15)"}`, borderRadius: "6px", padding: "0.75rem 1.25rem", color: copied ? "#4ade80" : "#fff", fontFamily: "'Barlow Condensed', sans-serif", fontWeight: 600, fontSize: "0.85rem", letterSpacing: "0.08em", cursor: "pointer", width: "100%" }}
          >
            <span>{copied ? "✓" : "⎘"}</span>
            {copied ? "Copied!" : "Copy Link"}
          </button>
        </div>
      </div>
    </div>
  );
}

// ─── Detail Modal ─────────────────────────────────────────────────────────────

function CardDetailModal({ card, onClose, onDeleted }: { card: Card; onClose: () => void; onDeleted?: (id: number) => void }) {
  const [showShare, setShowShare] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(false);
  const deleteCard = trpc.vault.deleteCard.useMutation({
    onSuccess: () => {
      if (onDeleted) onDeleted(card.id);
      onClose();
    },
    onError: (err) => {
      setConfirmDelete(false);
      // toast is imported via sonner in Vault.tsx — use alert as fallback
      alert(err.message ?? "Failed to delete card. Please try again.");
    },
  });
  const cardLabel = [card.cardYear, card.cardName, card.cardSet].filter(Boolean).join(" · ") || "Sports Card";
  const score = card.overallScore ? parseFloat(card.overallScore).toFixed(1) : "—";
  const tier = card.gradeTier ?? "GRADED";
  const tierColor = TIER_COLORS[tier] ?? "#a0b4c8";

  const categories = [
    { label: "Centering", value: card.centeringScore, weight: "40%" },
    { label: "Edges", value: card.edgesScore, weight: "15%" },
    { label: "Corners", value: card.cornersScore, weight: "15%" },
    { label: "Surface", value: card.surfaceScore, weight: "20%" },
    { label: "Eye Appeal", value: card.eyeAppealScore, weight: "10%" },
  ];

  return (
    <>
      <div
        style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.8)", zIndex: 900, display: "flex", alignItems: "center", justifyContent: "center", padding: "1rem" }}
        onClick={onClose}
      >
        <div
          style={{ background: "#0d1829", border: "1px solid rgba(201,168,76,0.2)", borderRadius: "16px", padding: "2rem", maxWidth: "560px", width: "100%", maxHeight: "90vh", overflowY: "auto", position: "relative" }}
          onClick={e => e.stopPropagation()}
        >
          <button onClick={onClose} style={{ position: "absolute", top: "1rem", right: "1rem", background: "none", border: "none", color: "rgba(255,255,255,0.5)", fontSize: "1.2rem", cursor: "pointer" }}>✕</button>

          {/* Card label */}
          <div style={{ fontFamily: "'Barlow Condensed', sans-serif", fontWeight: 600, fontSize: "0.62rem", letterSpacing: "0.2em", color: GOLD, textTransform: "uppercase", marginBottom: "0.4rem" }}>
            Diamond Index™ — Grading Report
          </div>
          <div style={{ fontFamily: "'Barlow Condensed', sans-serif", fontWeight: 800, fontSize: "1.4rem", color: "#fff", marginBottom: "0.25rem" }}>
            {cardLabel}
          </div>
          {card.cardNumber && (
            <div style={{ fontFamily: "'Barlow', sans-serif", fontSize: "0.75rem", color: "rgba(160,180,200,0.7)", marginBottom: "1.25rem" }}>
              #{card.cardNumber}{card.manufacturer ? ` · ${card.manufacturer}` : ""}
            </div>
          )}

          {/* 3D Slab — shows the real uploaded card image */}
          <div style={{ marginBottom: "1.5rem", borderRadius: "10px", overflow: "hidden", border: "1px solid rgba(201,168,76,0.15)" }}>
            <div style={{ fontFamily: "'Barlow Condensed', sans-serif", fontWeight: 600, fontSize: "0.55rem", letterSpacing: "0.22em", color: "rgba(201,168,76,0.5)", textTransform: "uppercase", padding: "0.5rem 0 0.25rem", textAlign: "center", background: "#060d1e" }}>
              Graded Slab
            </div>
            <Suspense fallback={
              <div style={{ height: 280, background: "#060d1e", display: "flex", alignItems: "center", justifyContent: "center" }}>
                <div style={{ color: "rgba(201,168,76,0.4)", fontSize: "0.75rem", fontFamily: "'Barlow', sans-serif", letterSpacing: "0.1em" }}>Loading slab...</div>
              </div>
            }>
              <CardSlab3D
                frontImageUrl={card.frontImageKey ?? null}
                backImageUrl={card.backImageKey ?? null}
                certId={card.certId ?? "DI-0000-0000"}
                score={card.overallScore ? parseFloat(card.overallScore) : undefined}
                diamondRating={card.diamondRating ?? 3}
                cardName={card.cardName ?? ""}
                cardYear={card.cardYear ?? ""}
                cardSet={card.cardSet ?? ""}
                centeringScore={card.centeringScore ? parseFloat(card.centeringScore) : 90}
                edgesScore={card.edgesScore ? parseFloat(card.edgesScore) : 90}
                surfaceScore={card.surfaceScore ? parseFloat(card.surfaceScore) : 90}
                cornersScore={card.cornersScore ? parseFloat(card.cornersScore) : 90}
                eyeAppealScore={card.eyeAppealScore ? parseFloat(card.eyeAppealScore) : 90}
                height={280}
              />
            </Suspense>
          </div>

          {/* Score + diamonds */}
          <div style={{ display: "flex", alignItems: "center", gap: "1.5rem", marginBottom: "1.5rem", padding: "1.25rem", background: "rgba(255,255,255,0.04)", borderRadius: "10px", border: "1px solid rgba(255,255,255,0.08)" }}>
            <div style={{ textAlign: "center" }}>
              <div style={{ fontFamily: "'Barlow Condensed', sans-serif", fontWeight: 900, fontSize: "3rem", color: "#fff", lineHeight: 1 }}>{score}</div>
              <div style={{ fontFamily: "'Barlow', sans-serif", fontSize: "0.65rem", color: "rgba(160,180,200,0.6)", marginTop: "0.25rem" }}>Overall</div>
            </div>
            <div>
              <DiamondRow rating={card.diamondRating ?? 0} size={22} />
              <div style={{ fontFamily: "'Barlow Condensed', sans-serif", fontWeight: 700, fontSize: "0.85rem", color: tierColor, letterSpacing: "0.12em", marginTop: "0.5rem" }}>
                {tier}
              </div>
            </div>
          </div>

          {/* Category breakdown */}
          <div style={{ marginBottom: "1.5rem" }}>
            <div style={{ fontFamily: "'Barlow Condensed', sans-serif", fontWeight: 600, fontSize: "0.62rem", letterSpacing: "0.18em", color: "rgba(160,180,200,0.5)", textTransform: "uppercase", marginBottom: "0.75rem" }}>
              Category Breakdown
            </div>
            {categories.map(cat => {
              const val = cat.value ? parseFloat(cat.value) : null;
              const pct = val ? (val / 100) * 100 : 0;
              return (
                <div key={cat.label} style={{ display: "flex", alignItems: "center", gap: "0.75rem", marginBottom: "0.6rem" }}>
                  <div style={{ width: "80px", fontFamily: "'Barlow', sans-serif", fontSize: "0.75rem", color: "rgba(180,200,220,0.8)" }}>{cat.label}</div>
                  <div style={{ flex: 1, height: "4px", background: "rgba(255,255,255,0.08)", borderRadius: "2px", overflow: "hidden" }}>
                    <div style={{ height: "100%", width: `${pct}%`, background: `linear-gradient(90deg, ${BLUE}, ${GOLD})`, borderRadius: "2px", transition: "width 0.8s ease" }} />
                  </div>
                  <div style={{ width: "36px", textAlign: "right", fontFamily: "'Barlow Condensed', sans-serif", fontWeight: 600, fontSize: "0.8rem", color: "#fff" }}>
                    {val !== null ? val.toFixed(1) : "—"}
                  </div>
                  <div style={{ width: "28px", textAlign: "right", fontFamily: "'Barlow', sans-serif", fontSize: "0.62rem", color: "rgba(160,180,200,0.4)" }}>{cat.weight}</div>
                </div>
              );
            })}
          </div>

          {/* Certification ID + QR */}
          {card.certId && (
            <div style={{ marginBottom: "1.5rem", padding: "1rem", background: "rgba(255,255,255,0.03)", borderRadius: "10px", border: "1px solid rgba(201,168,76,0.15)" }}>
              <div style={{ fontFamily: "'Barlow Condensed', sans-serif", fontWeight: 600, fontSize: "0.58rem", letterSpacing: "0.2em", color: "rgba(160,180,200,0.5)", textTransform: "uppercase", marginBottom: "0.5rem" }}>Certification ID</div>
              <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: "1rem" }}>
                <div>
                  <div style={{ fontFamily: "'Barlow Condensed', sans-serif", fontWeight: 700, fontSize: "1.05rem", color: GOLD, letterSpacing: "0.1em", marginBottom: "0.4rem" }}>{card.certId}</div>
                  <a
                    href={`/verify/${card.certId}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    style={{ fontFamily: "'Barlow', sans-serif", fontSize: "0.7rem", color: "#60a5fa", textDecoration: "none", borderBottom: "1px solid rgba(96,165,250,0.3)" }}
                  >
                    Verify Authenticity →
                  </a>
                </div>
                {card.qrCodeUrl && (
                  <img src={card.qrCodeUrl} alt="QR Code" style={{ width: "64px", height: "64px", borderRadius: "4px", border: "1px solid rgba(255,255,255,0.1)" }} />
                )}
              </div>
            </div>
          )}
          {/* Status */}
          {(() => {
            const st = statusLabel(card.status);
            return (
              <div style={{ display: "flex", alignItems: "center", gap: "0.5rem", marginBottom: "1.5rem" }}>
                <div style={{ width: "6px", height: "6px", borderRadius: "50%", background: st.color }} />
                <div style={{ fontFamily: "'Barlow', sans-serif", fontSize: "0.75rem", color: "rgba(160,180,200,0.7)" }}>
                  {st.label} · {new Date(card.createdAt).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}
                </div>
              </div>
            );
          })()}
          {/* Action buttons */}
          <div style={{ display: "flex", gap: "0.75rem", flexWrap: "wrap" }}>
            <button
              onClick={() => setShowShare(true)}
              style={{ flex: 1, minWidth: "120px", fontFamily: "'Barlow Condensed', sans-serif", fontWeight: 700, fontSize: "0.8rem", letterSpacing: "0.1em", textTransform: "uppercase", padding: "0.875rem", background: GOLD, color: DARK, border: "none", borderRadius: "6px", cursor: "pointer" }}
            >
              Share Grade
            </button>
            {card.certId && (
              <a
                href={`/verify/${card.certId}`}
                target="_blank"
                rel="noopener noreferrer"
                style={{ flex: 1, minWidth: "120px", fontFamily: "'Barlow Condensed', sans-serif", fontWeight: 700, fontSize: "0.8rem", letterSpacing: "0.1em", textTransform: "uppercase", padding: "0.875rem", background: "transparent", color: "#60a5fa", border: "1px solid rgba(96,165,250,0.25)", borderRadius: "6px", cursor: "pointer", textDecoration: "none", display: "flex", alignItems: "center", justifyContent: "center" }}
              >
                Verify
              </a>
            )}
          </div>

          {/* Delete section */}
          {!confirmDelete ? (
            <div style={{ marginTop: "1rem", display: "flex", justifyContent: "flex-end" }}>
              <button
                onClick={() => setConfirmDelete(true)}
                style={{ fontFamily: "'Barlow Condensed', sans-serif", fontWeight: 600, fontSize: "0.72rem", letterSpacing: "0.08em", textTransform: "uppercase", padding: "0.5rem 1rem", background: "transparent", color: "rgba(248,113,113,0.55)", border: "1px solid rgba(248,113,113,0.2)", borderRadius: "5px", cursor: "pointer", transition: "all 0.2s ease" }}
              >
                Delete Card
              </button>
            </div>
          ) : (
            <div style={{ marginTop: "1rem", padding: "1rem", background: "rgba(239,68,68,0.07)", border: "1px solid rgba(239,68,68,0.25)", borderRadius: "8px" }}>
              <div style={{ fontFamily: "'Barlow Condensed', sans-serif", fontWeight: 700, fontSize: "0.82rem", color: "#f87171", letterSpacing: "0.06em", marginBottom: "0.4rem" }}>
                Permanently delete this card?
              </div>
              <div style={{ fontFamily: "'Barlow', sans-serif", fontSize: "0.72rem", color: "rgba(200,200,200,0.6)", marginBottom: "0.875rem", lineHeight: 1.5 }}>
                This action cannot be undone. The card and its certification record will be removed from your vault.
              </div>
              <div style={{ display: "flex", gap: "0.6rem" }}>
                <button
                  onClick={() => deleteCard.mutate({ id: card.id })}
                  disabled={deleteCard.isPending}
                  style={{ fontFamily: "'Barlow Condensed', sans-serif", fontWeight: 700, fontSize: "0.78rem", letterSpacing: "0.08em", textTransform: "uppercase", padding: "0.6rem 1.25rem", background: "rgba(239,68,68,0.85)", color: "#fff", border: "none", borderRadius: "5px", cursor: deleteCard.isPending ? "not-allowed" : "pointer", opacity: deleteCard.isPending ? 0.7 : 1 }}
                >
                  {deleteCard.isPending ? "Deleting…" : "Yes, Delete"}
                </button>
                <button
                  onClick={() => setConfirmDelete(false)}
                  disabled={deleteCard.isPending}
                  style={{ fontFamily: "'Barlow Condensed', sans-serif", fontWeight: 600, fontSize: "0.78rem", letterSpacing: "0.08em", textTransform: "uppercase", padding: "0.6rem 1.25rem", background: "transparent", color: "rgba(200,200,200,0.7)", border: "1px solid rgba(255,255,255,0.12)", borderRadius: "5px", cursor: "pointer" }}
                >
                  Cancel
                </button>
              </div>
            </div>
          )}

          {/* Generated Slab Renders */}
          {(card.slabFrontUrl || card.slabBackUrl || card.slabCompositeUrl) && (
            <div style={{ marginTop: "0.75rem", padding: "1rem", background: "rgba(255,255,255,0.03)", border: "1px solid rgba(201,168,76,0.15)", borderRadius: "8px" }}>
              <div style={{ fontFamily: "'Barlow Condensed', sans-serif", fontWeight: 700, fontSize: "0.62rem", letterSpacing: "0.2em", color: GOLD, textTransform: "uppercase", marginBottom: "0.75rem" }}>
                Certified Slab Renders
              </div>
              {card.slabCompositeUrl && (
                <div style={{ marginBottom: "0.75rem" }}>
                  <div style={{ fontFamily: "'Barlow', sans-serif", fontSize: "0.65rem", color: "rgba(160,180,200,0.5)", marginBottom: "0.4rem", letterSpacing: "0.06em", textTransform: "uppercase" }}>3D Mock — Front &amp; Back</div>
                  <img src={card.slabCompositeUrl} alt="Slab Composite" style={{ width: "100%", borderRadius: "6px", border: "1px solid rgba(255,255,255,0.08)" }} />
                  <a href={card.slabCompositeUrl} download style={{ display: "inline-block", marginTop: "0.4rem", fontFamily: "'Barlow Condensed', sans-serif", fontWeight: 600, fontSize: "0.7rem", letterSpacing: "0.08em", textTransform: "uppercase", color: "#60a5fa", textDecoration: "none" }}>↓ Download Composite</a>
                </div>
              )}
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "0.75rem" }}>
                {card.slabFrontUrl && (
                  <div>
                    <div style={{ fontFamily: "'Barlow', sans-serif", fontSize: "0.65rem", color: "rgba(160,180,200,0.5)", marginBottom: "0.4rem", letterSpacing: "0.06em", textTransform: "uppercase" }}>Front Slab</div>
                    <img src={card.slabFrontUrl} alt="Front Slab" style={{ width: "100%", borderRadius: "6px", border: "1px solid rgba(255,255,255,0.08)" }} />
                    <a href={card.slabFrontUrl} download style={{ display: "inline-block", marginTop: "0.4rem", fontFamily: "'Barlow Condensed', sans-serif", fontWeight: 600, fontSize: "0.7rem", letterSpacing: "0.08em", textTransform: "uppercase", color: "#60a5fa", textDecoration: "none" }}>↓ Download</a>
                  </div>
                )}
                {card.slabBackUrl && (
                  <div>
                    <div style={{ fontFamily: "'Barlow', sans-serif", fontSize: "0.65rem", color: "rgba(160,180,200,0.5)", marginBottom: "0.4rem", letterSpacing: "0.06em", textTransform: "uppercase" }}>Back Slab</div>
                    <img src={card.slabBackUrl} alt="Back Slab" style={{ width: "100%", borderRadius: "6px", border: "1px solid rgba(255,255,255,0.08)" }} />
                    <a href={card.slabBackUrl} download style={{ display: "inline-block", marginTop: "0.4rem", fontFamily: "'Barlow Condensed', sans-serif", fontWeight: 600, fontSize: "0.7rem", letterSpacing: "0.08em", textTransform: "uppercase", color: "#60a5fa", textDecoration: "none" }}>↓ Download</a>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* List on Partner Marketplace */}
          <div style={{ marginTop: "0.75rem", padding: "1rem", background: "rgba(96,165,250,0.06)", border: "1px solid rgba(96,165,250,0.18)", borderRadius: "8px" }}>
            <div style={{ fontFamily: "'Barlow Condensed', sans-serif", fontWeight: 700, fontSize: "0.78rem", color: "#60a5fa", textTransform: "uppercase", letterSpacing: "0.08em", marginBottom: "0.4rem" }}>
              ◆ List on a Partner Marketplace
            </div>
            <div style={{ fontFamily: "'Barlow', sans-serif", fontSize: "0.72rem", color: "rgba(148,163,184,0.8)", lineHeight: 1.5, marginBottom: "0.65rem" }}>
              Send your certified card data to SportCardsOnline.com — a Diamond Index™ recommended marketplace. Your card will be listed in their vault with a direct link back here.
            </div>
            <a
              href="https://sportscardsonline.com"
              target="_blank"
              rel="noopener noreferrer"
              style={{ display: "inline-block", fontFamily: "'Barlow Condensed', sans-serif", fontWeight: 700, fontSize: "0.75rem", letterSpacing: "0.08em", textTransform: "uppercase", padding: "0.55rem 1.1rem", background: "rgba(96,165,250,0.12)", color: "#60a5fa", border: "1px solid rgba(96,165,250,0.3)", borderRadius: "5px", textDecoration: "none", cursor: "pointer" }}
            >
              Go to SportCardsOnline.com →
            </a>
          </div>
        </div>
      </div>

      {showShare && <ShareModal card={card} onClose={() => setShowShare(false)} />}
    </>
  );
}

// ─── Card Tile ────────────────────────────────────────────────────────────────

function CardTile({ card, onClick, isGrader = false }: { card: Card; onClick: () => void; isGrader?: boolean }) {
  const cardLabel = [card.cardYear, card.cardName].filter(Boolean).join(" · ") || "Sports Card";
  const score = card.overallScore ? parseFloat(card.overallScore).toFixed(1) : "—";
  const tier = card.gradeTier ?? "GRADED";
  const tierColor = TIER_COLORS[tier] ?? "#a0b4c8";

  return (
    <div
      onClick={onClick}
      style={{
        background: "linear-gradient(145deg, #0d1829 0%, #0a1220 100%)",
        border: "1px solid rgba(201,168,76,0.15)",
        borderRadius: "12px",
        overflow: "hidden",
        cursor: "pointer",
        transition: "transform 0.2s ease, box-shadow 0.2s ease",
      }}
      onMouseEnter={e => {
        (e.currentTarget as HTMLDivElement).style.transform = "translateY(-3px)";
        (e.currentTarget as HTMLDivElement).style.boxShadow = "0 12px 40px rgba(201,168,76,0.12)";
      }}
      onMouseLeave={e => {
        (e.currentTarget as HTMLDivElement).style.transform = "translateY(0)";
        (e.currentTarget as HTMLDivElement).style.boxShadow = "none";
      }}
    >
      {/* Card image */}
      <div style={{ aspectRatio: "2.5/3.5", background: "rgba(255,255,255,0.04)", position: "relative", overflow: "hidden" }}>
        {card.frontImageKey ? (
          <img src={card.frontImageKey} alt={cardLabel} style={{ width: "100%", height: "100%", objectFit: "cover" }} />
        ) : (
          <div style={{ width: "100%", height: "100%", display: "flex", alignItems: "center", justifyContent: "center" }}>
            <img src={DIAMOND_SINGLE} alt="card" style={{ width: "48px", opacity: 0.3 }} />
          </div>
        )}
        {/* Tier badge */}
        <div style={{ position: "absolute", top: "8px", right: "8px", background: "rgba(6,13,30,0.85)", border: `1px solid ${tierColor}40`, borderRadius: "4px", padding: "2px 8px", fontFamily: "'Barlow Condensed', sans-serif", fontWeight: 700, fontSize: "0.6rem", letterSpacing: "0.12em", color: tierColor }}>
          {tier}
        </div>
      </div>

      {/* Card info */}
      <div style={{ padding: "0.875rem" }}>
        <div style={{ fontFamily: "'Barlow Condensed', sans-serif", fontWeight: 700, fontSize: "0.9rem", color: "#fff", marginBottom: "0.25rem", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
          {cardLabel}
        </div>
        {card.cardSet && (
          <div style={{ fontFamily: "'Barlow', sans-serif", fontSize: "0.68rem", color: "rgba(160,180,200,0.55)", marginBottom: "0.625rem", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
            {card.cardSet}
          </div>
        )}

        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <DiamondRow rating={card.diamondRating ?? 0} size={14} />
          <div style={{ fontFamily: "'Barlow Condensed', sans-serif", fontWeight: 800, fontSize: "1.1rem", color: "#fff" }}>
            {score}
          </div>
        </div>

        {/* Grader-only: cert ID + quick print */}
        {isGrader && card.certId && (
          <div style={{ marginTop: "0.5rem", paddingTop: "0.5rem", borderTop: "1px solid rgba(255,255,255,0.06)" }}>
            <div style={{ fontFamily: "'Barlow', sans-serif", fontSize: "0.62rem", color: GOLD, letterSpacing: "0.08em", marginBottom: "0.35rem" }}>
              {card.certId}
            </div>
            <div style={{ display: "flex", gap: "0.4rem" }}>
              <a
                href={`/verify/${card.certId}`}
                target="_blank"
                rel="noopener noreferrer"
                onClick={e => e.stopPropagation()}
                style={{ flex: 1, textAlign: "center", fontFamily: "'Barlow Condensed', sans-serif", fontWeight: 700, fontSize: "0.6rem", letterSpacing: "0.1em", padding: "0.3rem 0.5rem", background: "rgba(96,165,250,0.12)", border: "1px solid rgba(96,165,250,0.3)", borderRadius: "4px", color: "#60a5fa", textDecoration: "none" }}
              >
                VERIFY
              </a>
              <button
                onClick={e => { e.stopPropagation(); window.print(); }}
                style={{ flex: 1, fontFamily: "'Barlow Condensed', sans-serif", fontWeight: 700, fontSize: "0.6rem", letterSpacing: "0.1em", padding: "0.3rem 0.5rem", background: "rgba(201,168,76,0.12)", border: "1px solid rgba(201,168,76,0.3)", borderRadius: "4px", color: GOLD, cursor: "pointer" }}
              >
                PRINT
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

// ─── Empty State ──────────────────────────────────────────────────────────────

function EmptyVault() {
  return (
    <div style={{ textAlign: "center", padding: "5rem 2rem" }}>
      <img src={DIAMOND_SINGLE} alt="vault" style={{ width: "56px", opacity: 0.25, marginBottom: "1.5rem" }} />
      <div style={{ fontFamily: "'Barlow Condensed', sans-serif", fontWeight: 700, fontSize: "1.3rem", color: "rgba(255,255,255,0.4)", marginBottom: "0.75rem" }}>
        Your Vault is Empty
      </div>
      <div style={{ fontFamily: "'Barlow', sans-serif", fontSize: "0.85rem", color: "rgba(160,180,200,0.4)", marginBottom: "2rem" }}>
        Grade your first card to see it here.
      </div>
      <a
        href="/grade"
        style={{ display: "inline-block", fontFamily: "'Barlow Condensed', sans-serif", fontWeight: 700, fontSize: "0.85rem", letterSpacing: "0.12em", textTransform: "uppercase", padding: "0.875rem 2.5rem", background: GOLD, color: DARK, borderRadius: "6px", textDecoration: "none" }}
      >
        Grade a Card
      </a>
    </div>
  );
}

// ─── Main Page ────────────────────────────────────────────────────────────────

const CARDS_PER_PAGE = 8;

export default function Vault() {
  const { user, loading: authLoading, isAuthenticated } = useAuth();
  const [selectedCard, setSelectedCard] = useState<Card | null>(null);
  const [page, setPage] = useState(1);
  const utils = trpc.useUtils();

  const { data: cards = [], isLoading } = trpc.vault.listCards.useQuery(undefined, {
    enabled: isAuthenticated,
  });

  const handleCardDeleted = (deletedId: number) => {
    // Optimistically remove from the tRPC cache
    utils.vault.listCards.setData(undefined, (prev) =>
      prev ? prev.filter((c) => c.id !== deletedId) : prev
    );
    setSelectedCard(null);
    // Adjust page if the last card on current page was deleted
    setPage((p) => {
      const remaining = (cards.length - 1);
      const maxPage = Math.max(1, Math.ceil(remaining / CARDS_PER_PAGE));
      return Math.min(p, maxPage);
    });
  };

  // Redirect to login if not authenticated
  if (!authLoading && !isAuthenticated) {
    window.location.href = getLoginUrl("/vault");
    return null;
  }

  const totalPages = Math.ceil(cards.length / CARDS_PER_PAGE);
  const paginatedCards = cards.slice((page - 1) * CARDS_PER_PAGE, page * CARDS_PER_PAGE);

  return (
    <div style={{ minHeight: "100vh", background: DARK }}>
      <Header />

      <main style={{ maxWidth: "1200px", margin: "0 auto", padding: "3rem 1.5rem 5rem" }}>
        {/* Page header */}
        <div style={{ marginBottom: "2.5rem" }}>
          <div style={{ fontFamily: "'Barlow Condensed', sans-serif", fontWeight: 600, fontSize: "0.65rem", letterSpacing: "0.22em", color: GOLD, textTransform: "uppercase", marginBottom: "0.5rem" }}>
            Diamond Index™
          </div>
          <h1 style={{ fontFamily: "'Barlow Condensed', sans-serif", fontWeight: 900, fontSize: "2.8rem", color: "#fff", margin: 0, letterSpacing: "0.02em" }}>
            My Vault
          </h1>
          <div style={{ fontFamily: "'Barlow', sans-serif", fontSize: "0.85rem", color: "rgba(160,180,200,0.6)", marginTop: "0.5rem" }}>
            {cards.length > 0 ? `${cards.length} graded card${cards.length !== 1 ? "s" : ""}` : "Your certified card collection"}
          </div>
        </div>

        {/* Orange accent line */}
        <div style={{ height: "1px", background: "linear-gradient(90deg, transparent, #e87722 30%, #e87722 70%, transparent)", marginBottom: "2.5rem", opacity: 0.6 }} />

        {/* Content */}
        {authLoading || isLoading ? (
          <div style={{ textAlign: "center", padding: "4rem", color: "rgba(160,180,200,0.5)", fontFamily: "'Barlow', sans-serif" }}>
            Loading your vault…
          </div>
        ) : cards.length === 0 ? (
          <EmptyVault />
        ) : (
          <>
            {/* Card grid */}
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(200px, 1fr))", gap: "1.25rem", marginBottom: "2.5rem" }}>
              {paginatedCards.map(card => (
                <CardTile key={card.id} card={card as Card} onClick={() => setSelectedCard(card as Card)} isGrader={user?.role === "grader" || user?.role === "admin"} />
              ))}
            </div>

            {/* Pagination */}
            {totalPages > 1 && (
              <div style={{ display: "flex", justifyContent: "center", gap: "0.5rem" }}>
                {Array.from({ length: totalPages }, (_, i) => i + 1).map(p => (
                  <button
                    key={p}
                    onClick={() => setPage(p)}
                    style={{
                      width: "36px", height: "36px",
                      background: p === page ? GOLD : "rgba(255,255,255,0.06)",
                      border: `1px solid ${p === page ? GOLD : "rgba(255,255,255,0.12)"}`,
                      borderRadius: "6px",
                      color: p === page ? DARK : "rgba(255,255,255,0.7)",
                      fontFamily: "'Barlow Condensed', sans-serif",
                      fontWeight: 700, fontSize: "0.85rem",
                      cursor: "pointer",
                    }}
                  >
                    {p}
                  </button>
                ))}
              </div>
            )}
          </>
        )}
        {/* Upgrade CTA — shown only to regular users (not graders/admins) */}
        {user && user.role !== "grader" && user.role !== "admin" && (
          <div style={{ maxWidth: "700px", margin: "3rem auto 0", padding: "1.75rem 2rem", background: "rgba(201,168,76,0.06)", border: "1px solid rgba(201,168,76,0.18)", borderRadius: "12px", display: "flex", alignItems: "center", justifyContent: "space-between", gap: "1.5rem", flexWrap: "wrap" }}>
            <div>
              <div style={{ fontFamily: "'Barlow Condensed', sans-serif", fontWeight: 800, fontSize: "1rem", color: GOLD, letterSpacing: "0.05em", marginBottom: "0.4rem" }}>
                ◆ BECOME A CERTIFIED GRADER
              </div>
              <div style={{ fontSize: "0.8rem", color: "rgba(160,180,200,0.8)", lineHeight: 1.6, maxWidth: "380px" }}>
                Earn per scan. Run live events. Access pro tools, batch grading, and label printing.
              </div>
            </div>
            <a
              href="/grader-program"
              style={{ display: "inline-block", fontFamily: "'Barlow Condensed', sans-serif", fontWeight: 800, fontSize: "0.82rem", letterSpacing: "0.12em", textTransform: "uppercase", padding: "0.75rem 1.75rem", background: GOLD, color: DARK, borderRadius: "6px", textDecoration: "none", whiteSpace: "nowrap", flexShrink: 0 }}
            >
              Apply Now
            </a>
          </div>
        )}
      </main>

      <Footer />

      {/* Detail modal */}
      {selectedCard && (
        <CardDetailModal
          card={selectedCard}
          onClose={() => setSelectedCard(null)}
          onDeleted={handleCardDeleted}
        />
      )}
    </div>
  );
}
