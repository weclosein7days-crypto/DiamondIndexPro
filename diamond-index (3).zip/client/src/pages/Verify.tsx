/**
 * Diamond Index™ — Public Card Verification Page
 * Route: /verify/:certId
 *
 * This page loads when a user scans the QR code on a graded slab.
 * No authentication required — fully public.
 *
 * Sections:
 *   1. Minimal header (Diamond Index™ branding)
 *   2. Verified Authentic badge
 *   3. Card identity (player, set, year)
 *   4. Card images (front + back)
 *   5. Grade panel (score, diamonds, tier, cert ID)
 *   6. Category breakdown with score bars
 *   7. Grading metadata + registry note
 *
 * Design: dark navy (#060d1e), gold accents, financial platform aesthetic.
 */

import { lazy, Suspense } from "react";
import { useRoute } from "wouter";
import { trpc } from "@/lib/trpc";
import { DIAMOND_SINGLE } from "@/lib/diamondRating";
import Footer from "@/components/Footer";

// Lazy-load the 3D viewer to avoid blocking the initial page render
const CardSlab3D = lazy(() => import("@/components/CardSlab3D"));

// ─── Design tokens ────────────────────────────────────────────────────────────
const DARK       = "#060d1e";
const DARK2      = "#0a1628";
const GOLD       = "#c9a84c";
const GOLD_DIM   = "rgba(201,168,76,0.18)";
const GOLD_MID   = "rgba(201,168,76,0.45)";
const WHITE      = "#ffffff";
const SILVER     = "rgba(180,200,220,0.65)";
const SILVER_DIM = "rgba(160,180,200,0.35)";
const GREEN      = "#4ade80";
const ORANGE     = "#e87722";

const TIER_COLORS: Record<string, { text: string; glow: string }> = {
  PRISTINE:  { text: "#f0d060", glow: "rgba(240,208,96,0.25)" },
  ELITE:     { text: "#c9a84c", glow: "rgba(201,168,76,0.2)" },
  SUPERIOR:  { text: "#7eb8f7", glow: "rgba(126,184,247,0.2)" },
  PREMIUM:   { text: "#a0b4c8", glow: "rgba(160,180,200,0.15)" },
  STANDARD:  { text: "#6b7f94", glow: "rgba(107,127,148,0.12)" },
};

const CATEGORIES = [
  { key: "centeringScore",  label: "Centering",  weight: 40 },
  { key: "surfaceScore",    label: "Surface",     weight: 20 },
  { key: "edgesScore",      label: "Edges",       weight: 15 },
  { key: "cornersScore",    label: "Corners",     weight: 15 },
  { key: "eyeAppealScore",  label: "Eye Appeal",  weight: 10 },
] as const;

// ─── Sub-components ───────────────────────────────────────────────────────────

function DiamondRow({ rating, size = 22 }: { rating: number; size?: number }) {
  return (
    <div style={{ display: "flex", gap: "5px", alignItems: "center", justifyContent: "center" }}>
      {Array.from({ length: 5 }, (_, i) => (
        <img
          key={i}
          src={DIAMOND_SINGLE}
          alt={i < rating ? "◆" : "◇"}
          style={{
            width: size, height: size,
            opacity: i < rating ? 1 : 0.15,
            filter: i < rating
              ? "drop-shadow(0 0 6px rgba(130,210,255,0.7)) drop-shadow(0 0 12px rgba(130,210,255,0.3))"
              : "none",
            transition: "opacity 0.2s",
          }}
        />
      ))}
    </div>
  );
}

function ScoreBar({ score, color = GOLD }: { score: number; color?: string }) {
  return (
    <div style={{
      flex: 1,
      height: "4px",
      background: "rgba(255,255,255,0.07)",
      borderRadius: "2px",
      overflow: "hidden",
    }}>
      <div style={{
        height: "100%",
        width: `${Math.min(score, 100)}%`,
        background: `linear-gradient(90deg, #1a3a6b, ${color})`,
        borderRadius: "2px",
        transition: "width 0.6s ease",
      }} />
    </div>
  );
}

function Divider() {
  return (
    <div style={{
      height: "1px",
      background: `linear-gradient(90deg, transparent, ${GOLD_MID}, transparent)`,
      margin: "0",
    }} />
  );
}

// ─── Loading skeleton ─────────────────────────────────────────────────────────

function LoadingState() {
  return (
    <div style={{ textAlign: "center", padding: "6rem 0", color: SILVER_DIM }}>
      <div style={{
        width: "40px", height: "40px", margin: "0 auto 1.5rem",
        border: `2px solid ${GOLD_DIM}`,
        borderTop: `2px solid ${GOLD}`,
        borderRadius: "50%",
        animation: "spin 1s linear infinite",
      }} />
      <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
      <div style={{
        fontFamily: "'Barlow Condensed', sans-serif",
        fontWeight: 600, fontSize: "0.8rem",
        letterSpacing: "0.22em", textTransform: "uppercase",
        color: SILVER_DIM,
      }}>
        Verifying Certificate…
      </div>
    </div>
  );
}

// ─── Not found state ──────────────────────────────────────────────────────────

function NotFoundState({ certId }: { certId: string }) {
  return (
    <div style={{ textAlign: "center", padding: "6rem 0" }}>
      <img src={DIAMOND_SINGLE} alt="" style={{ width: "52px", opacity: 0.15, marginBottom: "2rem" }} />
      <div style={{
        fontFamily: "'Barlow Condensed', sans-serif",
        fontWeight: 800, fontSize: "1.6rem",
        color: "rgba(255,255,255,0.3)", marginBottom: "1rem",
      }}>
        Certificate Not Found
      </div>
      <div style={{
        fontFamily: "'Barlow', sans-serif", fontSize: "0.9rem",
        color: SILVER_DIM, maxWidth: "420px", margin: "0 auto", lineHeight: 1.6,
      }}>
        The certification ID{" "}
        <span style={{ color: GOLD, fontFamily: "'Barlow Condensed', sans-serif", fontWeight: 700 }}>
          {certId}
        </span>{" "}
        does not match any card in the Diamond Index™ registry. If you believe this is an error, contact support.
      </div>
    </div>
  );
}

// ─── Main page ────────────────────────────────────────────────────────────────

export default function Verify() {
  const [, params] = useRoute("/verify/:certId");
  const certId = params?.certId ?? "";

  const { data: card, isLoading } = trpc.verify.getCard.useQuery(
    { certId },
    { enabled: !!certId }
  );

  const score     = card?.overallScore ? parseFloat(card.overallScore) : null;
  const scoreStr  = score !== null ? score.toFixed(1) : "—";
  const tier      = (card?.gradeTier ?? "GRADED").toUpperCase();
  const tierStyle = TIER_COLORS[tier] ?? { text: "#a0b4c8", glow: "rgba(160,180,200,0.12)" };
  const diamonds  = card?.diamondRating ?? 0;
  const gradedOn  = card?.createdAt
    ? new Date(card.createdAt).toLocaleDateString("en-US", { month: "long", day: "numeric", year: "numeric" })
    : null;

  const cardTitle = card
    ? [card.cardYear, card.cardName, card.cardSet].filter(Boolean).join(" · ") || "Sports Card"
    : "";

  return (
    <div style={{ minHeight: "100vh", background: DARK, color: WHITE, fontFamily: "'Barlow', sans-serif" }}>

      {/* ── HEADER ─────────────────────────────────────────────────────────── */}
      <header style={{
        borderBottom: `1px solid ${GOLD_DIM}`,
        padding: "1rem 1.5rem",
      }}>
        <div style={{ maxWidth: "860px", margin: "0 auto", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <a href="/" style={{ textDecoration: "none" }}>
            <div style={{
              fontFamily: "'Barlow Condensed', sans-serif",
              fontWeight: 900, fontSize: "1.25rem",
              color: WHITE, letterSpacing: "0.04em",
            }}>
              Diamond Index<span style={{ color: GOLD }}>™</span>
            </div>
            <div style={{
              fontFamily: "'Barlow', sans-serif",
              fontSize: "0.58rem", color: SILVER_DIM,
              letterSpacing: "0.2em", textTransform: "uppercase",
            }}>
              Certification Authority
            </div>
          </a>
          <div style={{
            fontFamily: "'Barlow Condensed', sans-serif",
            fontWeight: 600, fontSize: "0.6rem",
            letterSpacing: "0.22em", color: SILVER_DIM,
            textTransform: "uppercase",
          }}>
            Card Verification
          </div>
        </div>
      </header>

      {/* Orange accent line */}
      <div style={{
        height: "1px",
        background: `linear-gradient(90deg, transparent, ${ORANGE} 30%, ${ORANGE} 70%, transparent)`,
        opacity: 0.45,
      }} />

      {/* ── MAIN CONTENT ───────────────────────────────────────────────────── */}
      <main style={{ maxWidth: "860px", margin: "0 auto", padding: "2.5rem 1.5rem 5rem" }}>

        {isLoading && <LoadingState />}
        {!isLoading && !card && <NotFoundState certId={certId} />}

        {!isLoading && card && (
          <>
            {/* ── 1. VERIFIED AUTHENTIC BADGE ─────────────────────────────── */}
            <div style={{
              display: "flex", alignItems: "center", justifyContent: "center",
              gap: "0.75rem", marginBottom: "2.5rem",
              padding: "0.9rem 1.5rem",
              background: "rgba(74,222,128,0.07)",
              border: "1px solid rgba(74,222,128,0.22)",
              borderRadius: "10px",
            }}>
              {/* Pulsing dot */}
              <div style={{ position: "relative", width: "10px", height: "10px", flexShrink: 0 }}>
                <div style={{
                  position: "absolute", inset: 0,
                  borderRadius: "50%", background: GREEN,
                  boxShadow: `0 0 8px ${GREEN}`,
                }} />
                <div style={{
                  position: "absolute", inset: "-4px",
                  borderRadius: "50%",
                  background: "rgba(74,222,128,0.15)",
                  animation: "pulse 2s ease-in-out infinite",
                }} />
                <style>{`@keyframes pulse { 0%,100%{opacity:0.3;transform:scale(1)} 50%{opacity:0.8;transform:scale(1.4)} }`}</style>
              </div>
              <div>
                <div style={{
                  fontFamily: "'Barlow Condensed', sans-serif",
                  fontWeight: 700, fontSize: "0.85rem",
                  letterSpacing: "0.16em", color: GREEN,
                  textTransform: "uppercase",
                }}>
                  Verified Authentic
                </div>
                <div style={{
                  fontFamily: "'Barlow', sans-serif",
                  fontSize: "0.7rem", color: "rgba(74,222,128,0.55)",
                  marginTop: "1px",
                }}>
                  This card is registered in the Diamond Index™ Certification Registry
                </div>
              </div>
            </div>

            {/* ── 2. CARD IDENTITY ────────────────────────────────────────── */}
            <div style={{ marginBottom: "2rem" }}>
              <div style={{
                fontFamily: "'Barlow Condensed', sans-serif",
                fontWeight: 600, fontSize: "0.6rem",
                letterSpacing: "0.22em", color: GOLD,
                textTransform: "uppercase", marginBottom: "0.5rem",
              }}>
                Diamond Index™ — Grading Certificate
              </div>
              <h1 style={{
                fontFamily: "'Barlow Condensed', sans-serif",
                fontWeight: 900, fontSize: "clamp(1.6rem, 4vw, 2.4rem)",
                color: WHITE, margin: "0 0 0.4rem", lineHeight: 1.1,
              }}>
                {cardTitle}
              </h1>
              {(card.cardNumber || card.manufacturer) && (
                <div style={{
                  fontFamily: "'Barlow', sans-serif",
                  fontSize: "0.82rem", color: SILVER,
                }}>
                  {[card.cardNumber ? `#${card.cardNumber}` : null, card.manufacturer]
                    .filter(Boolean).join(" · ")}
                </div>
              )}
            </div>

            <Divider />

            {/* ── 3. 3D SLAB VIEWER ────────────────────────────────────── */}
            <div style={{ margin: "2rem 0 1.5rem" }}>
              <Suspense fallback={
                <div style={{
                  height: "420px",
                  background: "rgba(10,22,40,0.6)",
                  borderRadius: "12px",
                  display: "flex", alignItems: "center", justifyContent: "center",
                  border: `1px solid ${GOLD_DIM}`,
                }}>
                  <div style={{ color: SILVER_DIM, fontSize: "0.75rem", letterSpacing: "0.15em", textTransform: "uppercase" }}>
                    Loading 3D Viewer…
                  </div>
                </div>
              }>
                <CardSlab3D
                  frontImageUrl={(card as any).frontImageUrl ?? null}
                  backImageUrl={(card as any).backImageUrl ?? null}
                  certId={card.certId ?? certId}
                  score={score}
                  diamondRating={card.diamondRating ?? 3}
                  cardName={card.cardName ?? ""}
                  cardYear={card.cardYear ?? ""}
                  cardSet={card.cardSet ?? ""}
                  centeringScore={card.centeringScore ? parseFloat(card.centeringScore) : 90}
                  edgesScore={card.edgesScore ? parseFloat(card.edgesScore) : 90}
                  surfaceScore={card.surfaceScore ? parseFloat(card.surfaceScore) : 90}
                  cornersScore={card.cornersScore ? parseFloat(card.cornersScore) : 90}
                  eyeAppealScore={card.eyeAppealScore ? parseFloat(card.eyeAppealScore) : 90}
                  height={420}
                />
              </Suspense>
            </div>

            {/* ── 4. IMAGES + GRADE PANEL ──────────────────────────────────── */}
            <div style={{
              display: "grid",
              gridTemplateColumns: "minmax(0, 1fr) minmax(0, 1.1fr)",
              gap: "1.5rem",
              margin: "2rem 0",
              alignItems: "start",
            }}>
              {/* Card images */}
              <div style={{ display: "flex", flexDirection: "column", gap: "0.75rem" }}>
                {/* Front */}
                {(card as any).frontImageUrl ? (
                  <div style={{
                    aspectRatio: "2.5/3.5",
                    background: "rgba(255,255,255,0.03)",
                    borderRadius: "10px", overflow: "hidden",
                    border: `1px solid ${GOLD_DIM}`,
                    boxShadow: "0 8px 32px rgba(0,0,0,0.4)",
                  }}>
                    <img
                      src={(card as any).frontImageUrl}
                      alt="Card Front"
                      style={{ width: "100%", height: "100%", objectFit: "cover" }}
                    />
                  </div>
                ) : (
                  <div style={{
                    aspectRatio: "2.5/3.5",
                    background: "rgba(255,255,255,0.03)",
                    borderRadius: "10px",
                    border: `1px solid rgba(255,255,255,0.06)`,
                    display: "flex", alignItems: "center", justifyContent: "center",
                  }}>
                    <div style={{ textAlign: "center" }}>
                      <img src={DIAMOND_SINGLE} alt="" style={{ width: "32px", opacity: 0.2, marginBottom: "0.5rem" }} />
                      <div style={{ fontFamily: "'Barlow', sans-serif", fontSize: "0.65rem", color: SILVER_DIM }}>
                        Front Image
                      </div>
                    </div>
                  </div>
                )}

                {/* Back */}
                {(card as any).backImageUrl && (
                  <div style={{
                    aspectRatio: "2.5/3.5",
                    background: "rgba(255,255,255,0.03)",
                    borderRadius: "10px", overflow: "hidden",
                    border: `1px solid ${GOLD_DIM}`,
                    boxShadow: "0 8px 32px rgba(0,0,0,0.4)",
                  }}>
                    <img
                      src={(card as any).backImageUrl}
                      alt="Card Back"
                      style={{ width: "100%", height: "100%", objectFit: "cover" }}
                    />
                  </div>
                )}
              </div>

              {/* Grade panel */}
              <div style={{ display: "flex", flexDirection: "column", gap: "1rem" }}>

                {/* Score + tier */}
                <div style={{
                  padding: "1.75rem 1.5rem",
                  background: DARK2,
                  borderRadius: "12px",
                  border: `1px solid ${GOLD_DIM}`,
                  textAlign: "center",
                  boxShadow: `0 0 40px ${tierStyle.glow}`,
                }}>
                  <div style={{
                    fontFamily: "'Barlow Condensed', sans-serif",
                    fontWeight: 600, fontSize: "0.58rem",
                    letterSpacing: "0.22em", color: SILVER_DIM,
                    textTransform: "uppercase", marginBottom: "0.5rem",
                  }}>
                    Overall Score
                  </div>
                  <div style={{
                    fontFamily: "'Barlow Condensed', sans-serif",
                    fontWeight: 900, fontSize: "4.5rem",
                    color: WHITE, lineHeight: 1,
                    marginBottom: "0.25rem",
                    textShadow: `0 0 40px ${tierStyle.glow}`,
                  }}>
                    {scoreStr}
                  </div>
                  <div style={{
                    fontFamily: "'Barlow', sans-serif",
                    fontSize: "0.65rem", color: SILVER_DIM,
                    marginBottom: "1.25rem",
                  }}>
                    out of 100
                  </div>
                  <DiamondRow rating={diamonds} size={26} />
                  <div style={{
                    fontFamily: "'Barlow Condensed', sans-serif",
                    fontWeight: 700, fontSize: "1.1rem",
                    color: tierStyle.text,
                    letterSpacing: "0.18em",
                    marginTop: "0.85rem",
                    textTransform: "uppercase",
                  }}>
                    {tier}
                  </div>
                </div>

                {/* Cert ID */}
                <div style={{
                  padding: "1rem 1.25rem",
                  background: "rgba(201,168,76,0.05)",
                  borderRadius: "10px",
                  border: `1px solid ${GOLD_DIM}`,
                }}>
                  <div style={{
                    fontFamily: "'Barlow Condensed', sans-serif",
                    fontWeight: 600, fontSize: "0.58rem",
                    letterSpacing: "0.22em", color: SILVER_DIM,
                    textTransform: "uppercase", marginBottom: "0.4rem",
                  }}>
                    Certification ID
                  </div>
                  <div style={{
                    fontFamily: "'Barlow Condensed', sans-serif",
                    fontWeight: 800, fontSize: "1.2rem",
                    color: GOLD, letterSpacing: "0.1em",
                  }}>
                    {card.certId}
                  </div>
                  <div style={{
                    fontFamily: "'Barlow', sans-serif",
                    fontSize: "0.65rem", color: SILVER_DIM,
                    marginTop: "0.3rem",
                  }}>
                    VRC.7 Standard · Diamond Index™
                  </div>
                </div>

                {/* Graded date */}
                {gradedOn && (
                  <div style={{
                    padding: "0.85rem 1.25rem",
                    background: "rgba(255,255,255,0.02)",
                    borderRadius: "10px",
                    border: "1px solid rgba(255,255,255,0.06)",
                  }}>
                    <div style={{
                      fontFamily: "'Barlow Condensed', sans-serif",
                      fontWeight: 600, fontSize: "0.58rem",
                      letterSpacing: "0.22em", color: SILVER_DIM,
                      textTransform: "uppercase", marginBottom: "0.4rem",
                    }}>
                      Graded On
                    </div>
                    <div style={{
                      fontFamily: "'Barlow Condensed', sans-serif",
                      fontWeight: 700, fontSize: "0.95rem",
                      color: SILVER,
                    }}>
                      {gradedOn}
                    </div>
                  </div>
                )}

                {/* QR code */}
                {card.qrCodeUrl && (
                  <div style={{
                    padding: "1rem",
                    background: "rgba(255,255,255,0.02)",
                    borderRadius: "10px",
                    border: "1px solid rgba(255,255,255,0.06)",
                    display: "flex", alignItems: "center", gap: "1rem",
                  }}>
                    <img
                      src={card.qrCodeUrl}
                      alt="Verification QR Code"
                      style={{
                        width: "72px", height: "72px",
                        borderRadius: "6px",
                        border: `1px solid ${GOLD_DIM}`,
                        flexShrink: 0,
                      }}
                    />
                    <div>
                      <div style={{
                        fontFamily: "'Barlow Condensed', sans-serif",
                        fontWeight: 700, fontSize: "0.72rem",
                        letterSpacing: "0.14em", color: SILVER,
                        textTransform: "uppercase", marginBottom: "0.3rem",
                      }}>
                        Scan to Verify
                      </div>
                      <div style={{
                        fontFamily: "'Barlow', sans-serif",
                        fontSize: "0.65rem", color: SILVER_DIM, lineHeight: 1.5,
                      }}>
                        This QR code is permanently linked to this card's certification record.
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>

            <Divider />

            {/* ── 5. CATEGORY BREAKDOWN ───────────────────────────────────── */}
            <div style={{ margin: "2rem 0" }}>
              <div style={{
                fontFamily: "'Barlow Condensed', sans-serif",
                fontWeight: 600, fontSize: "0.62rem",
                letterSpacing: "0.22em", color: SILVER_DIM,
                textTransform: "uppercase", marginBottom: "1.25rem",
              }}>
                Category Breakdown
              </div>

              <div style={{
                display: "grid",
                gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))",
                gap: "0.75rem",
              }}>
                {CATEGORIES.map(cat => {
                  const raw = card[cat.key as keyof typeof card];
                  const val = raw != null ? parseFloat(String(raw)) : null;
                  const pct = val ?? 0;
                  const color = pct >= 95 ? "#7eb8f7"
                    : pct >= 88 ? GOLD
                    : pct >= 80 ? "#a0b4c8"
                    : "#6b7f94";

                  return (
                    <div key={cat.key} style={{
                      padding: "1rem 1.25rem",
                      background: DARK2,
                      borderRadius: "10px",
                      border: "1px solid rgba(255,255,255,0.06)",
                    }}>
                      <div style={{
                        display: "flex", alignItems: "center",
                        justifyContent: "space-between", marginBottom: "0.6rem",
                      }}>
                        <div style={{
                          fontFamily: "'Barlow', sans-serif",
                          fontSize: "0.78rem", color: SILVER,
                        }}>
                          {cat.label}
                        </div>
                        <div style={{ display: "flex", alignItems: "center", gap: "0.5rem" }}>
                          <span style={{
                            fontFamily: "'Barlow Condensed', sans-serif",
                            fontWeight: 700, fontSize: "1.05rem",
                            color: color,
                          }}>
                            {val !== null ? val.toFixed(1) : "—"}
                          </span>
                          <span style={{
                            fontFamily: "'Barlow', sans-serif",
                            fontSize: "0.6rem", color: SILVER_DIM,
                          }}>
                            {cat.weight}%
                          </span>
                        </div>
                      </div>
                      <ScoreBar score={pct} color={color} />
                    </div>
                  );
                })}
              </div>
            </div>

            <Divider />

            {/* ── 6. REGISTRY NOTE ────────────────────────────────────────── */}
            <div style={{
              margin: "2rem 0",
              padding: "1.5rem",
              background: "rgba(201,168,76,0.04)",
              borderRadius: "10px",
              border: `1px solid ${GOLD_DIM}`,
            }}>
              <div style={{
                fontFamily: "'Barlow Condensed', sans-serif",
                fontWeight: 700, fontSize: "0.7rem",
                letterSpacing: "0.18em", color: GOLD,
                textTransform: "uppercase", marginBottom: "0.75rem",
              }}>
                About This Certificate
              </div>
              <p style={{
                fontFamily: "'Barlow', sans-serif",
                fontSize: "0.82rem", color: SILVER,
                lineHeight: 1.7, margin: 0,
              }}>
                This card was graded under the Diamond Index™ VRC.7 Standard — a multi-factor evaluation
                covering centering, edges, corners, surface condition, and eye appeal. The certification
                record is immutable and permanently stored in the Diamond Index™ registry. The unique
                Certification ID and QR code on this slab are the authoritative identifiers for this card.
              </p>
              <div style={{
                marginTop: "1rem",
                display: "flex", alignItems: "center", gap: "0.5rem",
              }}>
                <img src={DIAMOND_SINGLE} alt="" style={{ width: "14px", opacity: 0.5 }} />
                <span style={{
                  fontFamily: "'Barlow Condensed', sans-serif",
                  fontWeight: 600, fontSize: "0.65rem",
                  letterSpacing: "0.14em", color: SILVER_DIM,
                  textTransform: "uppercase",
                }}>
                  Diamond Index™ Certification Authority · {gradedOn ?? ""}
                </span>
              </div>
            </div>
          </>
        )}
      </main>

      <Footer />
    </div>
  );
}
