/**
 * CardCameraCapture — reusable camera capture modal
 * Same flow as GradeCards: 5s countdown → front shot → 7s flip countdown → back shot → preview → save
 * Used for admin photo replacement on existing cards.
 */
import { useState, useRef, useCallback, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Camera, RotateCcw, Check, X } from "lucide-react";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";

interface CardCameraCaptureProps {
  open: boolean;
  onClose: () => void;
  cardId: number;
  cardTitle: string;
  onSaved?: (frontUrl: string, backUrl: string) => void;
}

type CaptureStep = "idle" | "front" | "back" | "preview" | "saving";

function CountdownOverlay({ count, label }: { count: number; label: string }) {
  return (
    <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/60 z-10">
      <div
        className="text-8xl font-black text-white mb-3 tabular-nums"
        style={{ textShadow: "0 0 40px rgba(196,30,58,0.8)", fontFamily: "Oswald, sans-serif" }}
      >
        {count}
      </div>
      <p className="text-white/80 text-sm font-semibold text-center px-4 max-w-xs">{label}</p>
    </div>
  );
}

export default function CardCameraCapture({ open, onClose, cardId, cardTitle, onSaved }: CardCameraCaptureProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const countdownRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const autoCaptureFrontRef = useRef(false);
  const autoCaptureBackRef = useRef(false);

  const [step, setStep] = useState<CaptureStep>("idle");
  const [cameraReady, setCameraReady] = useState(false);
  const [countdown, setCountdown] = useState<number | null>(null);
  const [countdownLabel, setCountdownLabel] = useState("");
  const [frontImage, setFrontImage] = useState<string | null>(null);
  const [backImage, setBackImage] = useState<string | null>(null);

  const uploadImage = trpc.cards.uploadImage.useMutation();
  const updateCardImages = trpc.admin.updateCardImages.useMutation();

  // Cleanup camera on close
  useEffect(() => {
    if (!open) {
      stopCamera();
      resetState();
    }
  }, [open]);

  useEffect(() => {
    return () => {
      stopCamera();
      if (countdownRef.current) clearInterval(countdownRef.current);
    };
  }, []);

  const stopCamera = useCallback(() => {
    streamRef.current?.getTracks().forEach(t => t.stop());
    streamRef.current = null;
    setCameraReady(false);
  }, []);

  const resetState = useCallback(() => {
    if (countdownRef.current) clearInterval(countdownRef.current);
    setStep("idle");
    setCountdown(null);
    setCountdownLabel("");
    setFrontImage(null);
    setBackImage(null);
    autoCaptureFrontRef.current = false;
    autoCaptureBackRef.current = false;
  }, []);

  const startCamera = useCallback(async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "environment", width: { ideal: 1280 }, height: { ideal: 720 } }
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play();
        setCameraReady(true);
      }
    } catch {
      toast.error("Camera access denied. Please allow camera permissions.");
    }
  }, []);

  const capturePhoto = useCallback((): string | null => {
    const video = videoRef.current;
    const canvas = canvasRef.current;
    if (!video || !canvas) return null;
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    const ctx = canvas.getContext("2d");
    if (!ctx) return null;
    ctx.drawImage(video, 0, 0);
    return canvas.toDataURL("image/jpeg", 0.92);
  }, []);

  const startCountdown = useCallback((seconds: number, label: string, onComplete: () => void) => {
    setCountdown(seconds);
    setCountdownLabel(label);
    let remaining = seconds;
    countdownRef.current = setInterval(() => {
      remaining -= 1;
      if (remaining <= 0) {
        clearInterval(countdownRef.current!);
        setCountdown(null);
        setCountdownLabel("");
        onComplete();
      } else {
        setCountdown(remaining);
      }
    }, 1000);
  }, []);

  // Watch for auto-capture triggers
  useEffect(() => {
    if (autoCaptureFrontRef.current && cameraReady && step === "front") {
      autoCaptureFrontRef.current = false;
      const photo = capturePhoto();
      if (!photo) return;
      setFrontImage(photo);
      setStep("back");
      // 7 seconds to flip, then auto-capture back
      startCountdown(7, "Flip your card over for the back photo...", () => {
        autoCaptureBackRef.current = true;
      });
    }
  });

  useEffect(() => {
    if (autoCaptureBackRef.current && cameraReady && step === "back") {
      autoCaptureBackRef.current = false;
      const photo = capturePhoto();
      if (!photo) return;
      setBackImage(photo);
      stopCamera();
      setStep("preview");
    }
  });

  const handleBegin = async () => {
    resetState();
    setStep("front");
    await startCamera();
    // 5s countdown then auto-capture front
    startCountdown(5, "Hold the FRONT of your card up to the camera...", () => {
      autoCaptureFrontRef.current = true;
    });
  };

  const handleRetake = () => {
    stopCamera();
    resetState();
  };

  const handleSave = async () => {
    if (!frontImage || !backImage) return;
    setStep("saving");
    try {
      // Upload front
      const frontBase64 = frontImage.split(",")[1];
      const frontResult = await uploadImage.mutateAsync({
        base64: frontBase64,
        filename: `card-${cardId}-front-${Date.now()}.jpg`,
        mimeType: "image/jpeg",
      });

      // Upload back
      const backBase64 = backImage.split(",")[1];
      const backResult = await uploadImage.mutateAsync({
        base64: backBase64,
        filename: `card-${cardId}-back-${Date.now()}.jpg`,
        mimeType: "image/jpeg",
      });

      // Update card record
      await updateCardImages.mutateAsync({
        cardId,
        frontImageUrl: frontResult.url,
        backImageUrl: backResult.url,
      });

      toast.success("Photos updated successfully!");
      onSaved?.(frontResult.url, backResult.url);
      onClose();
    } catch (err) {
      toast.error("Failed to save photos. Please try again.");
      setStep("preview");
    }
  };

  return (
    <Dialog open={open} onOpenChange={(o) => { if (!o) onClose(); }}>
      <DialogContent className="bg-[#0d1f3c] border-white/10 text-white max-w-lg w-full p-0 overflow-hidden">
        <DialogHeader className="p-4 border-b border-white/10">
          <DialogTitle className="text-white text-base font-bold flex items-center gap-2">
            <Camera className="w-4 h-4 text-[#c41e3a]" />
            Replace Photos — {cardTitle}
          </DialogTitle>
        </DialogHeader>

        <div className="p-4">
          {/* IDLE — Start button */}
          {step === "idle" && (
            <div className="text-center py-8">
              <Camera className="w-12 h-12 mx-auto mb-4 text-white/20" />
              <p className="text-white/60 text-sm mb-2">Same flow as grading:</p>
              <ol className="text-white/50 text-xs text-left max-w-xs mx-auto mb-6 space-y-1">
                <li>1. 5s countdown → front photo auto-captured</li>
                <li>2. 7s countdown → flip card for back photo</li>
                <li>3. Preview both shots → save or retake</li>
              </ol>
              <Button onClick={handleBegin} className="bg-[#c41e3a] hover:bg-[#a01830] text-white gap-2">
                <Camera className="w-4 h-4" /> Start Camera
              </Button>
            </div>
          )}

          {/* FRONT / BACK — Live camera view */}
          {(step === "front" || step === "back") && (
            <div className="relative rounded-xl overflow-hidden bg-black" style={{ aspectRatio: "16/9" }}>
              <video ref={videoRef} className="w-full h-full object-cover" autoPlay playsInline muted />
              {countdown !== null && <CountdownOverlay count={countdown} label={countdownLabel} />}
              {/* Step indicator */}
              <div className="absolute top-2 left-2 bg-black/60 text-white text-xs font-bold px-2 py-1 rounded">
                {step === "front" ? "📷 FRONT" : "🔄 BACK"}
              </div>
            </div>
          )}
          <canvas ref={canvasRef} className="hidden" />

          {/* PREVIEW — Show both shots */}
          {step === "preview" && frontImage && backImage && (
            <div>
              <p className="text-white/60 text-sm text-center mb-4">Review your photos before saving</p>
              <div className="grid grid-cols-2 gap-3 mb-4">
                <div>
                  <p className="text-xs text-white/40 text-center mb-1">FRONT</p>
                  <img src={frontImage} alt="Front" className="w-full rounded-lg border border-white/10 object-contain bg-black" style={{ aspectRatio: "3/4" }} />
                </div>
                <div>
                  <p className="text-xs text-white/40 text-center mb-1">BACK</p>
                  <img src={backImage} alt="Back" className="w-full rounded-lg border border-white/10 object-contain bg-black" style={{ aspectRatio: "3/4" }} />
                </div>
              </div>
              <div className="flex gap-3">
                <Button variant="outline" onClick={handleRetake} className="flex-1 border-white/20 text-white hover:bg-white/10 gap-2">
                  <RotateCcw className="w-4 h-4" /> Retake
                </Button>
                <Button onClick={handleSave} className="flex-1 bg-green-600 hover:bg-green-700 text-white gap-2">
                  <Check className="w-4 h-4" /> Save Photos
                </Button>
              </div>
            </div>
          )}

          {/* SAVING */}
          {step === "saving" && (
            <div className="text-center py-8">
              <div className="w-8 h-8 border-2 border-[#c41e3a] border-t-transparent rounded-full animate-spin mx-auto mb-4" />
              <p className="text-white/60 text-sm">Uploading photos...</p>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
