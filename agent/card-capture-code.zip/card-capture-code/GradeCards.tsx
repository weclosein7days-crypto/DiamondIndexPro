import { trpc } from "@/lib/trpc";
import { useRef, useState, useEffect, useCallback } from "react";
import { SlabFrame } from "@/components/SlabFrame";
import { LABEL_BACKGROUNDS, LABEL_BORDER_COLORS, type LabelBackground, type LabelBorderColor } from "@/components/SlabLabel";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import {
  Camera, RotateCcw, CheckCircle, Award, AlertCircle, Loader2,
  ChevronRight, Timer, Layers, Info, Star, Palette
} from "lucide-react";

// --- Types ------------------------------------------------------------------
type CaptureStep = "setup" | "front" | "back" | "preview" | "grading" | "result";
type CardOrientation = "portrait" | "landscape";

interface CapturedCard {
  frontImage: string;
  backImage: string;
  frontOrientation: CardOrientation;
  cardIndex: number;
}

interface GradeResult {
  overallGrade: number;
  gradeLabel: string;
  centering: string;
  corners: string;
  edges: string;
  surface: string;
  certNumber: string;
  estimatedValueLow: number;
  estimatedValueHigh: number;
  notes: string;
  playerName?: string;
  year?: string;
  setName?: string;
  cardNumber?: string;
  sport?: string;
  suggestedPrice?: number | null;
  marketPriceData?: {
    marketAvg: number | null;
    sources: { ebay: number | null; scp: number | null; beckett: number | null };
    multiplier: number;
    gradeCategory: string;
  } | null;
}

// --- Constants ---------------------------------------------------------------
const TIMER_OPTIONS = [5, 7, 10];
const CARD_COUNT_OPTIONS = Array.from({ length: 10 }, (_, i) => i + 1);

// --- Grade color helper -------------------------------------------------------
function gradeColor(grade: number) {
  if (grade >= 9.5) return "text-yellow-400";
  if (grade >= 8.5) return "text-green-400";
  if (grade >= 7) return "text-blue-400";
  if (grade >= 5) return "text-orange-400";
  return "text-red-400";
}

// --- Countdown overlay -------------------------------------------------------
function CountdownOverlay({ count, label }: { count: number; label: string }) {
  return (
    <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/60 z-20 rounded-lg">
      <div className="text-8xl font-black text-white mb-2" style={{ fontFamily: "Oswald, sans-serif", textShadow: "0 0 30px rgba(220,38,38,0.8)" }}>
        {count}
      </div>
      <div className="text-white/80 text-sm font-medium">{label}</div>
    </div>
  );
}

// --- Card Guide Frame ---------------------------------------------------------
function CardGuideFrame({ orientation }: { orientation: CardOrientation }) {
  // Portrait: 5:7 ratio | Landscape: 7:5 ratio
  const isLandscape = orientation === "landscape";
  return (
    <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-10">
      <div
        className="border-2 border-dashed border-white/70 rounded-sm"
        style={{
          width: isLandscape ? "75%" : "55%",
          aspectRatio: isLandscape ? "7/5" : "5/7",
          boxShadow: "0 0 0 9999px rgba(0,0,0,0.35)",
        }}
      >
        {/* Corner markers */}
        {["top-0 left-0", "top-0 right-0", "bottom-0 left-0", "bottom-0 right-0"].map((pos, i) => (
          <div key={i} className={`absolute ${pos} w-4 h-4 border-white`} style={{
            borderTopWidth: pos.includes("top") ? 3 : 0,
            borderBottomWidth: pos.includes("bottom") ? 3 : 0,
            borderLeftWidth: pos.includes("left") ? 3 : 0,
            borderRightWidth: pos.includes("right") ? 3 : 0,
          }} />
        ))}
        <div className="absolute inset-0 flex items-center justify-center">
          <span className="text-white/50 text-xs font-medium bg-black/40 px-2 py-0.5 rounded">
            {orientation === "landscape" ? "<-> Landscape" : "<-> Portrait"}
          </span>
        </div>
      </div>
    </div>
  );
}

// --- Main Component -----------------------------------------------------------
export default function GradeCards() {
  const { isAuthenticated } = useAuth();
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const countdownRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // Setup state
  const [mode, setMode] = useState<"single" | "multi">("single");
  const [cardCount, setCardCount] = useState(1);
  const [timerBetweenShots, setTimerBetweenShots] = useState(5);
  const [knownIssues, setKnownIssues] = useState("");

  // Camera state
  const [step, setStep] = useState<CaptureStep>("setup");
  const [cameraReady, setCameraReady] = useState(false);
  const [countdown, setCountdown] = useState<number | null>(null);
  const [countdownLabel, setCountdownLabel] = useState("");
  const [currentCardIndex, setCurrentCardIndex] = useState(0); // 0-based
  const [capturingSide, setCapturingSide] = useState<"front" | "back">("front");
  const [frontOrientation, setFrontOrientation] = useState<CardOrientation>("portrait");
  const [capturedCards, setCapturedCards] = useState<CapturedCard[]>([]);
  const [currentFrontImage, setCurrentFrontImage] = useState<string | null>(null);

  // Grading state
  const [gradingIndex, setGradingIndex] = useState(0);
  const [gradeResults, setGradeResults] = useState<(GradeResult | null)[]>([]);
  const [savedCards, setSavedCards] = useState<number[]>([]);

  // Per-card label style state (indexed by card index)
  const [cardLabelBg, setCardLabelBg] = useState<Record<number, LabelBackground>>({});
  const [cardLabelBorder, setCardLabelBorder] = useState<Record<number, LabelBorderColor>>({});
  const getLabelBg = (i: number): LabelBackground => cardLabelBg[i] ?? "black-silk";
  const getLabelBorder = (i: number): LabelBorderColor => cardLabelBorder[i] ?? "red";

  const gradeCard = trpc.grading.gradeCard.useMutation();
  const saveToCollection = trpc.grading.saveToCollection.useMutation();

  // -- Camera start/stop -----------------------------------------------------
  const startCamera = useCallback(async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "environment", width: { ideal: 1280 }, height: { ideal: 720 } }
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play();
        setCameraReady(true);
      }
    } catch (err) {
      toast.error("Camera access denied. Please allow camera permissions.");
    }
  }, []);

  const stopCamera = useCallback(() => {
    streamRef.current?.getTracks().forEach(t => t.stop());
    streamRef.current = null;
    setCameraReady(false);
  }, []);

  useEffect(() => {
    return () => {
      stopCamera();
      if (countdownRef.current) clearInterval(countdownRef.current);
    };
  }, [stopCamera]);

  // -- Detect orientation from image -----------------------------------------
  const detectOrientation = (dataUrl: string): Promise<CardOrientation> => {
    return new Promise((resolve) => {
      const img = new Image();
      img.onload = () => {
        resolve(img.width > img.height ? "landscape" : "portrait");
      };
      img.src = dataUrl;
    });
  };

  // -- Capture photo from camera ---------------------------------------------
  const capturePhoto = useCallback((): string | null => {
    const video = videoRef.current;
    const canvas = canvasRef.current;
    if (!video || !canvas) return null;
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    const ctx = canvas.getContext("2d");
    if (!ctx) return null;
    ctx.drawImage(video, 0, 0);
    return canvas.toDataURL("image/jpeg", 0.92);
  }, []);

  // -- Start countdown then execute action -----------------------------------
  const startCountdown = useCallback((seconds: number, label: string, onComplete: () => void) => {
    setCountdown(seconds);
    setCountdownLabel(label);
    let remaining = seconds;
    countdownRef.current = setInterval(() => {
      remaining -= 1;
      if (remaining <= 0) {
        clearInterval(countdownRef.current!);
        setCountdown(null);
        setCountdownLabel("");
        onComplete();
      } else {
        setCountdown(remaining);
      }
    }, 1000);
  }, []);

  // -- Auto-capture: fires after countdown completes -------------------------
  const autoCaptureFront = useCallback(async () => {
    const photo = capturePhoto();
    if (!photo) return;
    const orientation = await detectOrientation(photo);
    setFrontOrientation(orientation);
    setCurrentFrontImage(photo);
    setCapturingSide("back");
    // 7 seconds for user to flip the card, then auto-capture back
    startCountdown(7, "Flip your card over for the back photo...", () => {
      // auto-capture back
      autoCaptureFrontRef.current = false;
      autoCaptureBackRef.current = true;
    });
  }, [capturePhoto, startCountdown]);

  const autoCaptureBackRef = useRef(false);
  const autoCaptureFrontRef = useRef(false);

  // Watch for auto-capture triggers
  useEffect(() => {
    if (autoCaptureBackRef.current) {
      autoCaptureBackRef.current = false;
      const photo = capturePhoto();
      if (!photo || !currentFrontImage) return;
      const newCard: CapturedCard = {
        frontImage: currentFrontImage,
        backImage: photo,
        frontOrientation,
        cardIndex: currentCardIndex,
      };
      setCapturedCards(prev => {
        const updated = [...prev, newCard];
        const totalCards = mode === "single" ? 1 : cardCount;
        const nextIndex = currentCardIndex + 1;
        if (nextIndex >= totalCards) {
          stopCamera();
          setStep("preview");
          setGradingIndex(0);
          setGradeResults(new Array(updated.length).fill(null));
        } else {
          setCurrentCardIndex(nextIndex);
          setCapturingSide("front");
          setCurrentFrontImage(null);
          startCountdown(10, `Get Card ${nextIndex + 1} ready -- place it in front of the camera...`, () => {
            autoCaptureFrontRef.current = true;
          });
        }
        return updated;
      });
    }
  });

  // Separate effect for front auto-capture trigger
  useEffect(() => {
    if (autoCaptureFrontRef.current && cameraReady && step === "front") {
      autoCaptureFrontRef.current = false;
      autoCaptureFront();
    }
  });

  // -- Begin session: start camera then auto-start 5s front countdown --------
  const handleBegin = async () => {
    setStep("front");
    setCurrentCardIndex(0);
    setCapturingSide("front");
    setCurrentFrontImage(null);
    setCapturedCards([]);
    setGradeResults([]);
    setSavedCards([]);
    await startCamera();
    // Start 5-second countdown then auto-capture front
    startCountdown(5, "Hold the FRONT of your card up to the camera...", () => {
      autoCaptureFrontRef.current = true;
    });
  };

  // -- Reset everything ------------------------------------------------------
  const handleReset = () => {
    stopCamera();
    if (countdownRef.current) clearInterval(countdownRef.current);
    setStep("setup");
    setCountdown(null);
    setCurrentCardIndex(0);
    setCapturingSide("front");
    setCurrentFrontImage(null);
    setCapturedCards([]);
    setGradeResults([]);
    setSavedCards([]);
    setFrontOrientation("portrait");
  };

  // -- Grade a card ----------------------------------------------------------
  const handleGradeCard = async (index: number) => {
    const card = capturedCards[index];
    if (!card) return;
    setStep("grading");
    try {
      const result = await gradeCard.mutateAsync({
        frontImageUrl: card.frontImage,
        backImageUrl: card.backImage,
      } as any);
      // Backend spreads gradeData directly into the return value using snake_case keys
      const r = result as any;
      setGradeResults(prev => {
        const updated = [...prev];
        updated[index] = {
          overallGrade: Number(r.overall_grade ?? 8),
          gradeLabel: String(r.grade_label ?? "NM-MT"),
          centering: String(r.centering_score ?? "8.5"),
          corners: String(r.corners_score ?? "8.5"),
          edges: String(r.edges_score ?? "8.5"),
          surface: String(r.surface_score ?? "8.5"),
          certNumber: String(r.cert_number ?? `SCG-${Date.now()}`),
          estimatedValueLow: Number(r.estimated_value_low ?? 0),
          estimatedValueHigh: Number(r.estimated_value_high ?? 0),
          notes: String(r.notes ?? ""),
          playerName: r.player_name ?? undefined,
          year: r.year ?? undefined,
          setName: r.set_name ?? undefined,
          cardNumber: r.card_number ?? undefined,
          sport: r.sport ?? undefined,
          suggestedPrice: r.suggested_price ?? null,
          marketPriceData: r.market_price_data ?? null,
        };
        return updated;
      });
      setStep("result");
    } catch (err: any) {
      toast.error(err.message ?? "Grading failed. Please try again.");
      setStep("preview");
    }
  };

  // -- Save to collection ----------------------------------------------------
  const handleSaveToCollection = async (index: number) => {
    const card = capturedCards[index];
    const result = gradeResults[index];
    if (!card || !result) return;
    try {
      await saveToCollection.mutateAsync({
        frontImageUrl: card.frontImage,
        backImageUrl: card.backImage,
        overallGrade: String(result.overallGrade),
        gradeLabel: result.gradeLabel,
        centeringScore: result.centering,
        cornersScore: result.corners,
        edgesScore: result.edges,
        surfaceScore: result.surface,
        certNumber: result.certNumber,
        estimatedValueLow: String(result.estimatedValueLow),
        estimatedValueHigh: String(result.estimatedValueHigh),
        playerName: result.playerName ?? "Unknown Player",
        cardTitle: result.playerName ? `${result.year ?? ""} ${result.setName ?? ""} ${result.playerName}`.trim() : "Graded Card",
        year: result.year ?? "",
        setName: result.setName ?? "",
        cardNumber: result.cardNumber ?? "",
        sport: (result.sport as any) ?? "baseball",
        labelBg: getLabelBg(index),
        labelBorder: getLabelBorder(index),
      });
      setSavedCards(prev => [...prev, index]);
      toast.success("Card saved to your collection!");
    } catch (err: any) {
      toast.error(err.message ?? "Failed to save card.");
    }
  };

  // --- Auth gate ------------------------------------------------------------
  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="max-w-md w-full mx-4">
          <CardContent className="p-8 text-center">
            <Camera className="w-16 h-16 text-primary mx-auto mb-4" />
            <h2 className="text-2xl font-bold mb-2">Sign In to Grade Cards</h2>
            <p className="text-muted-foreground mb-6">Create an account to start grading your sports cards with SCG AI technology.</p>
            <Button size="lg" className="w-full" asChild><a href={getLoginUrl()}>Sign In to Grade</a></Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  // --- SETUP SCREEN (Wizard Step 1) ----------------------------------------
  if (step === "setup") {
    return (
      <div className="min-h-screen bg-[#0a1628] py-6 pb-24">
        <div className="max-w-md mx-auto px-4">
          {/* Wizard Header */}
          <div className="text-center mb-6">
            <div className="inline-flex items-center gap-2 bg-[#C41E3A]/20 border border-[#C41E3A]/30 rounded-full px-4 py-1.5 mb-3">
              <Award className="w-4 h-4 text-[#C41E3A]" />
              <span className="text-xs font-bold text-[#C41E3A] uppercase tracking-wider">SCG — Sport Cards Grading</span>
            </div>
            <h1 className="text-3xl font-black text-white mb-1" style={{ fontFamily: "Oswald, sans-serif" }}>Grade Your Card</h1>
            <p className="text-white/50 text-sm">AI-powered · 1 second · Free</p>
          </div>

          {/* Step Progress */}
          <div className="flex items-center gap-2 mb-6">
            {["Choose Mode", "Capture", "Grade", "Results"].map((label, i) => (
              <div key={i} className="flex items-center gap-2 flex-1">
                <div className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-black shrink-0 ${
                  i === 0 ? "bg-[#C41E3A] text-white" : "bg-white/10 text-white/30"
                }`}>{i + 1}</div>
                <div className={`text-xs hidden sm:block ${
                  i === 0 ? "text-white font-semibold" : "text-white/30"
                }`}>{label}</div>
                {i < 3 && <div className="flex-1 h-px bg-white/10" />}
              </div>
            ))}
          </div>

          {/* Mode Selection */}
          <div className="mb-5">
            <p className="text-xs text-white/50 uppercase tracking-wider font-bold mb-3">How many cards?</p>
            <div className="grid grid-cols-2 gap-3">
              <button
                onClick={() => setMode("single")}
                className={`p-4 rounded-xl border-2 text-left transition-all ${
                  mode === "single"
                    ? "border-[#C41E3A] bg-[#C41E3A]/10 text-white"
                    : "border-white/10 hover:border-white/30 text-white/60"
                }`}
              >
                <Camera className="w-5 h-5 mb-2 text-[#C41E3A]" />
                <div className="font-bold text-sm">Single Card</div>
                <div className="text-xs opacity-60 mt-0.5">Front + back</div>
              </button>
              <button
                onClick={() => setMode("multi")}
                className={`p-4 rounded-xl border-2 text-left transition-all ${
                  mode === "multi"
                    ? "border-[#C41E3A] bg-[#C41E3A]/10 text-white"
                    : "border-white/10 hover:border-white/30 text-white/60"
                }`}
              >
                <Layers className="w-5 h-5 mb-2 text-[#C41E3A]" />
                <div className="font-bold text-sm">Multiple Cards</div>
                <div className="text-xs opacity-60 mt-0.5">Batch 1–10 cards</div>
              </button>
            </div>
          </div>

          {/* Multi-card options */}
          {mode === "multi" && (
            <div className="grid grid-cols-2 gap-3 mb-5">
              <div>
                <label className="text-xs text-white/50 uppercase tracking-wider font-bold mb-2 block">Number of Cards</label>
                <Select value={String(cardCount)} onValueChange={v => setCardCount(Number(v))}>
                  <SelectTrigger className="bg-white/5 border-white/10 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {CARD_COUNT_OPTIONS.map(n => (
                      <SelectItem key={n} value={String(n)}>{n} card{n > 1 ? "s" : ""}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="text-xs text-white/50 uppercase tracking-wider font-bold mb-2 block">Timer Between Shots</label>
                <Select value={String(timerBetweenShots)} onValueChange={v => setTimerBetweenShots(Number(v))}>
                  <SelectTrigger className="bg-white/5 border-white/10 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {TIMER_OPTIONS.map(t => (
                      <SelectItem key={t} value={String(t)}>{t} seconds</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          )}

          {/* Known Issues */}
          <div className="mb-5">
            <label className="text-xs text-white/50 uppercase tracking-wider font-bold mb-2 block">
              Known Issues <span className="text-white/30 normal-case font-normal">(optional)</span>
            </label>
            <textarea
              value={knownIssues}
              onChange={e => setKnownIssues(e.target.value)}
              placeholder="e.g. slight bend on top-left corner..."
              className="w-full h-16 text-sm bg-white/5 border border-white/10 text-white rounded-lg p-3 resize-none focus:outline-none focus:ring-2 focus:ring-[#C41E3A]/50 placeholder:text-white/20"
            />
          </div>

          {/* Quick Tips */}
          <div className="bg-white/5 border border-white/10 rounded-xl p-4 mb-5">
            <div className="flex items-start gap-3">
              <Timer className="w-4 h-4 text-[#C41E3A] mt-0.5 shrink-0" />
              <div className="text-xs text-white/50 space-y-1">
                {mode === "single" ? (
                  <>
                    <p><span className="text-white font-semibold">1.</span> Align card to guide frame</p>
                    <p><span className="text-white font-semibold">2.</span> Tap "Take Front Photo"</p>
                    <p><span className="text-white font-semibold">3.</span> Flip card — back auto-captures</p>
                  </>
                ) : (
                  <>
                    <p><span className="text-white font-semibold">Front→Back:</span> {timerBetweenShots}s between sides</p>
                    <p><span className="text-white font-semibold">Card→Card:</span> 7s to swap cards</p>
                    <p><span className="text-white font-semibold">Auto-stop</span> after all {cardCount} card{cardCount !== 1 ? "s" : ""}</p>
                  </>
                )}
              </div>
            </div>
          </div>

          <Button
            size="lg"
            className="w-full text-base font-black bg-[#C41E3A] hover:bg-[#a01830] text-white h-12"
            onClick={handleBegin}
          >
            <Camera className="w-5 h-5 mr-2" />
            Start Camera
          </Button>

          <p className="text-center text-white/20 text-xs mt-3">
            Make sure your camera is accessible and lighting is even
          </p>
        </div>

        {/* Philosophy Section — below the fold */}
        <div className="mt-12">
          <PhilosophySection />
        </div>
      </div>
    );
  }

  // --- CAMERA SCREENS (front / back) ---------------------------------------
  if (step === "front" || step === "back") {
    const isFront = step === "front";
    const totalCards = mode === "single" ? 1 : cardCount;
    // Back is always portrait — cards are standard portrait size regardless of front orientation
    const guideOrientation: CardOrientation = isFront ? frontOrientation : "portrait";
    // Camera viewer is always portrait aspect ratio so the viewer size is consistent front-to-back
    const viewerAspectRatio = "5/7";

    return (
      <div className="min-h-screen bg-[#0a1628] py-4 pb-24">
        <div className="max-w-sm mx-auto px-4">

          {/* Progress bar */}
          <div className="flex items-center justify-between mb-3">
            <div className="text-sm text-white/60">
              Card <span className="font-bold text-white">{currentCardIndex + 1}</span> of <span className="font-bold text-white">{totalCards}</span>
              <span className="mx-2 text-white/30">*</span>
              <span className={`font-bold ${isFront ? "text-[#E8C547]" : "text-blue-400"}`}>{isFront ? "FRONT" : "BACK"}</span>
            </div>
            <Button variant="ghost" size="sm" className="text-white/40 hover:text-white h-7 px-2" onClick={handleReset}>
              <RotateCcw className="w-3.5 h-3.5 mr-1" />Reset
            </Button>
          </div>

          {/* Step indicator dots */}
          {totalCards > 1 && (
            <div className="flex gap-1 mb-3 justify-center">
              {Array.from({ length: totalCards }).map((_, i) => (
                <div key={i} className={`h-1.5 rounded-full transition-all ${
                  i < currentCardIndex ? "w-6 bg-green-500" :
                  i === currentCardIndex ? "w-8 bg-[#C41E3A]" :
                  "w-4 bg-white/20"
                }`} />
              ))}
            </div>
          )}

          {/* Instruction banner */}
          <div className={`rounded-xl px-4 py-2.5 mb-3 text-center text-sm font-semibold ${
            isFront
              ? "bg-[#E8C547]/10 border border-[#E8C547]/30 text-[#E8C547]"
              : "bg-blue-500/10 border border-blue-500/30 text-blue-300"
          }`}>
            {isFront
              ? " Hold the FRONT of your card up to the camera"
              : " Flip the card -- show the BACK to the camera"}
          </div>

          {/* Compact camera viewer -- fixed height so it fits on screen */}
          <div
            className="relative bg-black rounded-2xl overflow-hidden mb-3 mx-auto"
            style={{ width: "100%", maxWidth: 320, aspectRatio: viewerAspectRatio }}
          >
            <video ref={videoRef} className="w-full h-full object-cover" autoPlay playsInline muted />
            <CardGuideFrame orientation={guideOrientation} />
            {countdown !== null && <CountdownOverlay count={countdown} label={countdownLabel} />}
            {!cameraReady && (
              <div className="absolute inset-0 flex items-center justify-center bg-black/80">
                <div className="text-center text-white">
                  <Loader2 className="w-8 h-8 animate-spin mx-auto mb-2" />
                  <p className="text-sm">Starting camera...</p>
                </div>
              </div>
            )}
          </div>
          <canvas ref={canvasRef} className="hidden" />

          {/* Countdown message */}
          {countdown !== null && (
            <div className="text-center py-2 mb-3">
              <p className="text-white/60 text-sm animate-pulse">{countdownLabel}</p>
            </div>
          )}

          {/* Auto-capture status -- no manual button needed */}
          {countdown === null && cameraReady && (
            <div className={`w-full text-center py-3 rounded-xl font-semibold text-sm ${
              isFront
                ? "bg-[#E8C547]/10 border border-[#E8C547]/30 text-[#E8C547]"
                : "bg-blue-500/10 border border-blue-500/30 text-blue-300"
            }`}>
              <Loader2 className="w-4 h-4 inline mr-2 animate-spin" />
              {isFront ? "Preparing front capture..." : "Preparing back capture..."}
            </div>
          )}

          {/* Helper tip */}
          <p className="text-center text-white/30 text-xs mt-3">
            {isFront
              ? "Tip: Fill the frame, keep the card flat and well-lit."
              : "Tip: Keep the same lighting. Back photo completes this card."}
          </p>
        </div>
      </div>
    );
  }

  // --- PREVIEW SCREEN ------------------------------------------------------
  if (step === "preview" || step === "result") {
    const allGraded = capturedCards.length > 0 && capturedCards.every((_, i) => gradeResults[i] !== null);
    const allSaved  = capturedCards.length > 0 && capturedCards.every((_, i) => savedCards.includes(i));
    return (
      <div className="min-h-screen bg-[#0a1628] py-6 pb-24">
        <div className="max-w-3xl mx-auto px-4">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-black text-white" style={{ fontFamily: "Oswald, sans-serif" }}>
              {step === "result" ? "Grade Results" : `${capturedCards.length} Card${capturedCards.length > 1 ? "s" : ""} Captured`}
            </h2>
            <Button variant="outline" size="sm" className="border-white/20 text-white hover:bg-white/10" onClick={handleReset}><RotateCcw className="w-4 h-4 mr-1" />Start Over</Button>
          </div>

          <div className="space-y-6">
            {capturedCards.map((card, index) => {
              const result = gradeResults[index];
              const isSaved = savedCards.includes(index);

              return (
                <div key={index} className={`bg-[#0d1f3c] border rounded-2xl overflow-hidden ${isSaved ? "border-green-500/40" : "border-white/10"}`}>
                  {/* Card Photos + Slab */}
                  {result ? (
                    <div className="grid grid-cols-2 gap-0">
                      <div className="p-3">
                        <SlabFrame
                          imageUrl={card.frontImage}
                          altText="Front"
                          grade={result.overallGrade}
                          gradeLabel={result.gradeLabel}
                          playerName={result.playerName}
                          certNumber={result.certNumber}
                          labelBg={getLabelBg(index)}
                          labelBorder={getLabelBorder(index)}
                          showScoLabel={true}
                          className="w-full"
                        />
                      </div>
                      <div className="relative">
                        <img src={card.backImage} alt="Back" className="w-full object-cover" style={{ aspectRatio: "5/7" }} />
                        <span className="absolute top-2 left-2 bg-blue-500 text-white text-[10px] font-black px-2 py-0.5 rounded-full">BACK</span>
                      </div>
                    </div>
                  ) : (
                    <div className="grid grid-cols-2 gap-0">
                      <div className="relative">
                        <img src={card.frontImage} alt="Front" className="w-full object-cover" style={{ aspectRatio: "5/7" }} />
                        <span className="absolute top-2 left-2 bg-[#E8C547] text-black text-[10px] font-black px-2 py-0.5 rounded-full">FRONT</span>
                      </div>
                      <div className="relative">
                        <img src={card.backImage} alt="Back" className="w-full object-cover" style={{ aspectRatio: "5/7" }} />
                        <span className="absolute top-2 left-2 bg-blue-500 text-white text-[10px] font-black px-2 py-0.5 rounded-full">BACK</span>
                      </div>
                    </div>
                  )}

                  {/* Grade Result */}
                  {result ? (
                    <div className="p-4">
                      {/* Overall Grade */}
                      <div className="flex items-center justify-between mb-4">
                        <div>
                          <div className="text-xs text-white/40 uppercase tracking-wider mb-1">SCG Overall Grade</div>
                          <div className={`text-5xl font-black ${gradeColor(result.overallGrade)}`} style={{ fontFamily: "Oswald, sans-serif" }}>
                            {result.overallGrade}
                          </div>
                          <div className="text-sm font-semibold text-white/60">{result.gradeLabel}</div>
                        </div>
                        <div className="text-right">
                          <div className="text-xs text-white/40 mb-1">Est. Value</div>
                          <div className="text-lg font-bold text-green-400">
                            ${result.estimatedValueLow}-${result.estimatedValueHigh}
                          </div>
                          <div className="text-xs text-white/30">CERT# {result.certNumber}</div>
                        </div>
                      </div>

                      {/* Sub-scores */}
                      <div className="grid grid-cols-4 gap-2 mb-4">
                        {[
                          { label: "Centering", val: result.centering },
                          { label: "Corners",   val: result.corners },
                          { label: "Edges",     val: result.edges },
                          { label: "Surface",   val: result.surface },
                        ].map(({ label, val }) => (
                          <div key={label} className="bg-white/5 border border-white/10 rounded-lg p-2 text-center">
                            <div className="text-lg font-bold text-[#E8C547]">{val}</div>
                            <div className="text-xs text-white/40">{label}</div>
                          </div>
                        ))}
                      </div>

                      {/* Card Info */}
                      {result.playerName && (
                        <div className="text-sm text-white/60 mb-3">
                          <span className="font-semibold text-white">{result.playerName}</span>
                          {result.year && ` * ${result.year}`}
                          {result.setName && ` * ${result.setName}`}
                        </div>
                      )}

                      {/* Market Auto-Price */}
                      {result.suggestedPrice && (
                        <div className="bg-green-500/10 border border-green-500/30 rounded-lg p-3 mb-3">
                          <div className="flex items-center justify-between">
                            <div>
                              <div className="text-xs text-green-400/70 uppercase tracking-wider mb-0.5">SCO Suggested Price</div>
                              <div className="text-xl font-black text-green-400">${result.suggestedPrice.toFixed(2)}</div>
                            </div>
                            {result.marketPriceData && (
                              <div className="text-right text-xs text-white/40 space-y-0.5">
                                {result.marketPriceData.sources.ebay && <div>eBay: ${result.marketPriceData.sources.ebay.toFixed(0)}</div>}
                                {result.marketPriceData.sources.scp && <div>SCP: ${result.marketPriceData.sources.scp.toFixed(0)}</div>}
                                {result.marketPriceData.sources.beckett && <div>Beckett: ${result.marketPriceData.sources.beckett.toFixed(0)}</div>}
                                <div className="text-green-400/60">{Math.round(result.marketPriceData.multiplier * 100)}% multiplier</div>
                              </div>
                            )}
                          </div>
                        </div>
                      )}

                      {/* Notes */}
                      {result.notes && (
                        <p className="text-xs text-white/40 bg-white/5 border border-white/10 rounded p-2 mb-3">{result.notes}</p>
                      )}

                      {/* Label Style Picker */}
                      {!isSaved && (
                        <div className="bg-white/5 border border-white/10 rounded-xl p-3 mb-3">
                          <div className="flex items-center gap-2 mb-3">
                            <Palette className="w-4 h-4 text-[#E8C547]" />
                            <span className="text-sm font-bold text-white">Choose Label Style</span>
                            <span className="text-xs text-white/40 ml-auto">Live preview on left</span>
                          </div>
                          <div className="grid grid-cols-2 gap-3">
                            <div>
                              <div className="text-xs text-white/50 mb-1.5 uppercase tracking-wider">Background</div>
                              <Select
                                value={getLabelBg(index)}
                                onValueChange={v => setCardLabelBg(prev => ({ ...prev, [index]: v as LabelBackground }))}
                              >
                                <SelectTrigger className="bg-white/10 border-white/20 text-white text-xs h-8">
                                  <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                  {LABEL_BACKGROUNDS.map(bg => (
                                    <SelectItem key={bg.value} value={bg.value}>{bg.label}</SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                            </div>
                            <div>
                              <div className="text-xs text-white/50 mb-1.5 uppercase tracking-wider">Border Color</div>
                              <div className="flex gap-1.5 flex-wrap">
                                {LABEL_BORDER_COLORS.map(bc => (
                                  <button
                                    key={bc.value}
                                    title={bc.label}
                                    onClick={() => setCardLabelBorder(prev => ({ ...prev, [index]: bc.value as LabelBorderColor }))}
                                    className={`w-7 h-7 rounded-full border-2 transition-all ${
                                      getLabelBorder(index) === bc.value
                                        ? "border-white scale-110 shadow-lg"
                                        : "border-white/20 hover:border-white/60"
                                    }`}
                                    style={{ backgroundColor: bc.hex }}
                                  />
                                ))}
                              </div>
                            </div>
                          </div>
                        </div>
                      )}

                      {/* Actions */}
                      <div className="flex gap-2">
                        {isSaved ? (
                          <div className="flex items-center gap-2 text-green-400 font-semibold text-sm bg-green-500/10 border border-green-500/30 rounded-lg px-4 py-2 w-full justify-center">
                            <CheckCircle className="w-4 h-4" /> Saved to Collection!
                          </div>
                        ) : (
                          <>
                            <Button
                              className="flex-1 bg-green-600 hover:bg-green-700 text-white font-bold"
                              onClick={() => handleSaveToCollection(index)}
                              disabled={saveToCollection.isPending}
                            >
                              {saveToCollection.isPending ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <CheckCircle className="w-4 h-4 mr-2" />}
                              Send to My Collection
                            </Button>
                            <Button variant="outline" className="border-white/20 text-white hover:bg-white/10" onClick={() => handleGradeCard(index)}>
                              <RotateCcw className="w-4 h-4 mr-1" />Re-Grade
                            </Button>
                          </>
                        )}
                      </div>
                    </div>
                  ) : (
                    <div className="p-4 flex gap-2">
                      <Button
                        className="flex-1 bg-[#C41E3A] hover:bg-[#a01830] text-white font-bold"
                        onClick={() => handleGradeCard(index)}
                        disabled={gradeCard.isPending}
                      >
                        {gradeCard.isPending && gradingIndex === index ? (
                          <><Loader2 className="w-4 h-4 animate-spin mr-2" />Grading...</>
                        ) : (
                          <><Star className="w-4 h-4 mr-2" />Grade This Card</>
                        )}
                      </Button>
                      <Button variant="ghost" className="text-red-400 hover:text-red-300" onClick={() => {
                        setCapturedCards(prev => prev.filter((_, i) => i !== index));
                        setGradeResults(prev => prev.filter((_, i) => i !== index));
                      }}>
                        Delete
                      </Button>
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          {/* Bottom action bar */}
          <div className="mt-6 space-y-3">
            {/* Grade All -- shown when multiple ungraded cards */}
            {capturedCards.some((_, i) => !gradeResults[i]) && capturedCards.length > 1 && (
              <Button
                size="lg"
                className="w-full bg-[#C41E3A] hover:bg-[#a01830] text-white font-bold"
                onClick={async () => {
                  for (let i = 0; i < capturedCards.length; i++) {
                    if (!gradeResults[i]) {
                      setGradingIndex(i);
                      await handleGradeCard(i);
                    }
                  }
                }}
              >
                <Star className="w-5 h-5 mr-2" />Grade All {capturedCards.length} Cards
              </Button>
            )}
            {/* Send All to Collection -- shown when all graded but some not yet saved */}
            {allGraded && !allSaved && capturedCards.length > 1 && (
              <Button
                size="lg"
                className="w-full bg-green-600 hover:bg-green-700 text-white font-bold"
                disabled={saveToCollection.isPending}
                onClick={async () => {
                  for (let i = 0; i < capturedCards.length; i++) {
                    if (!savedCards.includes(i)) await handleSaveToCollection(i);
                  }
                }}
              >
                <CheckCircle className="w-5 h-5 mr-2" />Send All {capturedCards.length} Cards to My Collection
              </Button>
            )}
          </div>
        </div>
      </div>
    );
  }

  // --- GRADING SPINNER -----------------------------------------------------
  if (step === "grading") {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="relative w-24 h-24 mx-auto mb-6">
            <div className="absolute inset-0 rounded-full border-4 border-primary/20" />
            <div className="absolute inset-0 rounded-full border-4 border-primary border-t-transparent animate-spin" />
            <Award className="absolute inset-0 m-auto w-10 h-10 text-primary" />
          </div>
          <h3 className="text-2xl font-black mb-2" style={{ fontFamily: "Oswald, sans-serif" }}>Analyzing Card...</h3>
          <p className="text-muted-foreground text-sm">SCG AI is checking centering, corners, edges, and surface</p>
        </div>
      </div>
    );
  }

  return null;
}

// --- Philosophy Section Component --------------------------------------------
function PhilosophySection() {
  return (
    <div className="mt-16 border-t border-border pt-12">
      <div className="container max-w-4xl">
        <div className="text-center mb-10">
          <div className="inline-flex items-center gap-2 bg-primary/10 border border-primary/20 rounded-full px-4 py-1.5 mb-4">
            <Award className="w-4 h-4 text-primary" />
            <span className="text-sm font-semibold text-primary uppercase tracking-wider">Our Grading Standard</span>
          </div>
          <h2 className="text-4xl font-black mb-3" style={{ fontFamily: "Oswald, sans-serif" }}>
            Why SCG Is Different.
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Firm. Fair. Fast. And finally -- on your side.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-10">
          {[
            { number: "01", title: "Firm & Fair -- Always", body: "SCG grades every card the same way: honestly, consistently, and without bias. A $5 card and a $5,000 card go through the exact same process. No favoritism. No manipulation. Just the facts." },
            { number: "02", title: "A Collective Standard", body: "Our grading system is built on the combined guidelines of PSA, Beckett, and SGC. We took the best of each and built a fair, averaged standard that doesn't punish your card for being shiny, chrome, or holographic." },
            { number: "03", title: "1-Second AI Analysis", body: "SCG uses AI fingerprinting, automatic measurement, and surface scanning to analyze your card in about one second. We check centering, corners, edges, and surface -- and we never penalize glare, chrome finishes, or natural card sheen." },
            { number: "04", title: "You Grade What You Show", body: "We can only grade what the camera sees. If you hide a bent corner or a scratch, you're only fooling yourself -- the buyer will ask for more photos. Show us the corners, edges, front, and back. Tell us the faults. That's how you get the most accurate grade." },
          ].map(({ number, title, body }) => (
            <div key={number} className="relative bg-card border border-border rounded-xl p-6 hover:border-primary/40 transition-colors">
              <div className="text-6xl font-black text-primary/10 absolute top-4 right-4 leading-none" style={{ fontFamily: "Oswald, sans-serif" }}>{number}</div>
              <div className="text-primary font-black text-sm uppercase tracking-widest mb-2">{number}</div>
              <h3 className="text-xl font-bold mb-3" style={{ fontFamily: "Oswald, sans-serif" }}>{title}</h3>
              <p className="text-muted-foreground text-sm leading-relaxed">{body}</p>
            </div>
          ))}
        </div>

        <div className="bg-[#0a1628] border border-white/10 rounded-2xl p-8 text-white relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-primary/20 to-transparent pointer-events-none" />
          <div className="relative">
            <h3 className="text-3xl font-black mb-4" style={{ fontFamily: "Oswald, sans-serif" }}>
              The Truth About the Big Grading Companies
            </h3>
            <div className="space-y-4 text-white/80 text-sm leading-relaxed">
              <p>We sent <strong className="text-white">10 cards to each of the top 3 grading companies</strong>. They all came back with different grades. We sent some back for a regrade -- and got completely different results again. So the next time someone tells you AI grading isn't fair, remember: the companies charging you $50-$150 per card aren't 100% consistent either.</p>
              <p>Here's what nobody talks about: some of the biggest grading companies also <strong className="text-white">offer to vault and sell your cards after grading</strong>. Think about that. A card worth $200 earns them 10% -- that's $20. But a card worth $10,000 earns them $1,000. Is there any incentive to grade that $10,000 card a 9 instead of a 10 if it goes into their vault? We're not saying they do -- we're saying the conflict of interest exists. And you deserve to know it.</p>
              <p><strong className="text-white">You can look at a card and tell the difference between good, bad, and excellent.</strong> Centering, edges, corners, clarity -- you already know what to look for. SCG gives you a professional, AI-powered second opinion in seconds, not 90 days. And we're not vaulting your cards. We're not selling them for you. We're just grading them -- fairly, quickly, and on your terms.</p>
            </div>
            <div className="mt-6 pt-6 border-t border-white/10">
              <p className="text-lg font-bold text-white" style={{ fontFamily: "Oswald, sans-serif" }}>Stop waiting 90 days. Stop paying $100 per card. Take the ball back to your court.</p>
              <p className="text-white/60 text-xs mt-1">SCG -- Sport Cards Grading. Built for collectors, by collectors.</p>
            </div>
          </div>
        </div>

        <div className="mt-6 p-4 bg-muted/30 rounded-lg border border-border">
          <p className="text-xs text-muted-foreground text-center leading-relaxed">
            <strong>Disclaimer:</strong> SCG grades cards as shown in the submitted photographs. We cannot assess defects not visible to the camera. For the most accurate grade, photograph all four corners, both edges, the full front, and the full back under good, even lighting. Self-reporting known issues (bent corners, scratches, creases) helps us provide the most honest and accurate grade possible.
          </p>
        </div>
      </div>
    </div>
  );
}
